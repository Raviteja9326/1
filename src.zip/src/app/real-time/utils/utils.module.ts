import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { GridstackItemComponent } from './gridstack-item/gridstack-item.component';
import { GridstackComponent } from './gridstack/gridstack.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
  ],
  declarations: [
    GridstackComponent,
    GridstackItemComponent
  ],
  exports: [
    GridstackComponent,
    GridstackItemComponent
  ]
})
export class UtilsModule { }