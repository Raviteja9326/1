import { Component, Inject, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { KeyschemaNameComponent } from '../keyschema-name/keyschema-name.component';
@Component({
  selector: 'app-editwidget',
  templateUrl: './editwidget.component.html',
  styleUrls: ['./editwidget.component.scss'],
})
export class EditwidgetComponent implements OnInit {
  fields: any[] = [];
  display: any;
  type: any;
  value: any;
  dataApi: any;
  label: any;
  navUrl: any;
  icon: any;
  filterKey: any;
  filterType: any;
  filterValue: any;
  formObject: Boolean = false;
  keyschName: any;
  filtercontent: any;
  constructor(
    private dialogRef: MatDialogRef<EditwidgetComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    console.log('data', this.data);
    this.fields = this.data;
    this.filtercontent = {
      text: {
        type: 'text',
        group: 'text',
        options: {},
      },
      number: {
        type: 'number',
        group: 'range',
        options: {},
      },
      boolean: {
        type: 'boolean',
        group: 'equal',
        options: {
          list: [
            {
              label: 'Active',
              value: true,
            },
            {
              label: 'In Active',
              value: false,
            },
          ],
        },
      },
    };
  }
  filter(row: any, data: any) {
    if (data.value != undefined) {
      row.filterValue = data.value;
    }
    console.log('event', data);
  }
  getFilterContent(filterType: string) {
    // console.log('getFilterContent', filterType);
    if (filterType === 'range') {
      return this.filtercontent.number;
    } else if (filterType === 'text') {
      return this.filtercontent.text;
    } else if (filterType === 'equal') {
      return this.filtercontent.text;
    }
  }
  addTableRow(field: any) {
    console.log('asd', field);
    const newRow = {};
    if (field.schemaRef != undefined) {
      const schemaware = this.fields.find((e) => e.key == field.schemaRef.ref);
      field.schema = schemaware.value.map((e) => {
        return {
          ...e,
          type: field.schemaRef.type,
          value: field.schemaRef.value,
        };
      });
    }
    for (const schema of field.schema) {
      newRow[schema.key] = schema.value;
    }
    field.value.push(newRow);
  }
  addTableObj(schema: any, row: any) {
    const newRow = {};
    for (const column of schema) {
      newRow[column.key] = '';
    }
    row.push(newRow);
  }

  removeTableObj(field: any, index: number): void {
    const valueschema = field.valueschema;
    const value = field.value[valueschema.label];

    if (Array.isArray(value)) {
      value.splice(index, 1);
    }
  }
  removeTableRow(field: any, index: number) {
    field.value.splice(index, 1);
  }

  removeKey(field: any, index: number): void {
    field.value.splice(index, 1);
  }
  addKey(field: any) {
    const dialogRef = this.dialog.open(KeyschemaNameComponent, {
      width: 'auto',
      height: 'auto',
    });
    dialogRef.afterClosed().subscribe((data) => {
      if (data == undefined) {
        return;
      }
      console.log('data', data);
      field.value[data] = JSON.parse(JSON.stringify(field.valueschema.value));
    });
  }
  save() {
    const formValues: any = {};
    this.fields.forEach((field) => {
      formValues[field.key] = field.value;
    });
    this.dialogRef.close(formValues);
  }
  close() {
    this.dialogRef.close();
  }
}
