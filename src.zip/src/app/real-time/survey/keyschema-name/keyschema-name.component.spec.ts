import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyschemaNameComponent } from './keyschema-name.component';

describe('KeyschemaNameComponent', () => {
  let component: KeyschemaNameComponent;
  let fixture: ComponentFixture<KeyschemaNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeyschemaNameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KeyschemaNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
