import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { EditwidgetComponent } from './editwidget/editwidget.component';
import { AddwidgetComponent } from './addwidget/addwidget.component';
import { AllModule } from 'src/app/shared/all_modules';
import { MaterialModule } from 'src/app/shared/material.module';
import { KeyschemaNameComponent } from './keyschema-name/keyschema-name.component';
import { UtilsModule } from '../utils/utils.module';
import { WidgetModule } from '../widget/widget.module';
import { SurveyComponent } from './survey.component';
import { SurveyRoutingModule } from './survey-routing.module';


@NgModule({
  declarations: [
    EditwidgetComponent,
    AddwidgetComponent,
    SurveyComponent,
    KeyschemaNameComponent
  ],
  imports: [
    CommonModule,
    SurveyRoutingModule,
    AllModule,
    UtilsModule,
    WidgetModule
  ]
})
export class SurveyModule { }
