import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { TEXT_REGEX_1 } from 'src/app/core/constants/regex.constants';

@Component({
  selector: 'app-addwidget',
  templateUrl: './addwidget.component.html',
  styleUrls: ['./addwidget.component.scss'],
})
export class AddwidgetComponent implements OnInit {
  name: string = '';
  myform: FormGroup;
  submitted: boolean = false;
  constructor(private dialogRef: MatDialogRef<AddwidgetComponent>) {}

  ngOnInit(): void {
    this.myform = new FormGroup({
      name: new FormControl({ value: '', disabled: false }, [
        Validators.required,
        Validators.pattern(TEXT_REGEX_1),
      ]),
    });
  }
  get f() {
    return this.myform.controls;
  }

  saveName() {
    this.submitted = true;
    if (this.myform.invalid) {
      console.log('is it here', this.myform.invalid);
      return;
    }
    this.dialogRef.close(this.name);
  }
  close() {
    this.submitted = false;
    this.dialogRef.close();
  }
}
