import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddwidgetComponent } from './addwidget/addwidget.component';
import { EditwidgetComponent } from './editwidget/editwidget.component';
import { KeyschemaNameComponent } from './keyschema-name/keyschema-name.component';
import { SurveyComponent } from './survey.component';

const routes: Routes = [
{
  path: '',component:SurveyComponent,children:[
    {path:'addwidget',component:AddwidgetComponent},
    {path:'editwidget',component:EditwidgetComponent},
    {path:'keyschema',component:KeyschemaNameComponent}
  ]
}
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SurveyRoutingModule { }
