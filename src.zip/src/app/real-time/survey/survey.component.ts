import {
  AfterViewInit,
  Component,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Chart, registerables } from 'chart.js';
import { surveyRealTime } from 'src/app/core/interfaces/surveyRealTime';
import { Column } from 'src/app/core/interfaces/column.interface';
import { WebsocketService } from 'src/app/core/services/websocket.service';
import { RealTime } from 'src/app/core/interfaces/realtime.interface'; 


Chart.register(...registerables);

@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.scss'],
})

export class SurveyComponent implements OnInit, AfterViewInit {

  tableColumns: Array<Column>;
  @ViewChild('threeDSceneContainer') threeDSceneContainer: any;
  tableData: surveyRealTime[] = [
    
  ];

  realTimeData: RealTime = {
    "bitDepth":1731.0480612323236,
    "wellDepth":396.7066100291992,
    "weightOnBit":42889.216907514754,
    "hookLoad":1901352.3818759676,
    "pump1Speed":79.36658134451123,
    "pump2Speed":78.69083338077483,
    "densityIn":10.486596218166262,
    "densityOut":10.957929918925064,
    "flowIn":362.85696471409767,
    "rotaryTorque":1.329326970712929,
    "topDriveSpeed":28.46284829366307
  };

  modelWidth: any = 0;
  modelHeight: any = 0;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    // private dashService: DashbaordService,
    private websocketService: WebsocketService
  ) { }

  ngOnInit() {

    this.tableColumns = [
      { columnDef: "hookLoad", header: "Hook Load", cell: (element: Record<string, any>) => `${element['hookLoad']}`},
      { columnDef: "rotaryTorque", header: "Rotary Torque", cell: (element: Record<string, any>) => `${element['rotaryTorque']}`},
      { columnDef: "topDriveSpeed", header: "TopDrive Speed", cell: (element: Record<string, any>) => `${element['topDriveSpeed']}`},
    ];
  }
  ngAfterViewInit() {
    this.createGradientChart();
    setTimeout(() => {
      const parentDiv = this.threeDSceneContainer.nativeElement;
      this.modelWidth = parentDiv.clientWidth;
      this.modelHeight = parentDiv.clientHeight;
    }, 1000
    )
    
    this.loading_kafha_consumer_sigin();

    //websocket logic for real time data
    const connection = this.websocketService.streamData("ws://20.163.251.47", "/real-time/listen");
    connection.getMessages().subscribe((data) => {

      console.log("STREAM Data: " + JSON.stringify(data));

      this.realTimeData = data.body.result;

      if (this.tableData.length >= 7) {

        this.tableData.shift();
        this.tableData = [...this.tableData];
      }

      let dataObject: RealTime = {
        "bitDepth":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "wellDepth":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "weightOnBit":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "hookLoad":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "pump1Speed":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "pump2Speed":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "densityIn":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "densityOut":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "flowIn":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "rotaryTorque":parseFloat(this.realTimeData.bitDepth.toFixed(2)),
        "topDriveSpeed":parseFloat(this.realTimeData.bitDepth.toFixed(2))
      };

      this.tableData.push(dataObject);
      this.tableData = [...this.tableData];
      console.log("this.realTimeData: " + JSON.stringify(this.realTimeData));
      console.log("Length of table data: " + this.tableData.length);
    });
  }


  /**
   * Below function for displaying charts
   **/
  createGradientChart(): void {
    const myChart1Canvas = document.getElementById('myChart1') as HTMLCanvasElement;
    const myChart1Ctx = myChart1Canvas.getContext('2d');

    // Define gradient
    var gradientStroke = myChart1Ctx.createLinearGradient(500, 0, 100, 0);
    gradientStroke.addColorStop(1, "rgba(255, 182, 107, 0.3)");
    gradientStroke.addColorStop(0.6, "rgba(254, 176, 110, 0.3)");
    gradientStroke.addColorStop(0.3, "rgba(255, 59, 70, 0.6)");
    gradientStroke.addColorStop(0, "rgba(255, 59, 83, 0.8)");

    var gradientStrokeLine = myChart1Ctx.createLinearGradient(500, 0, 100, 0);
    gradientStrokeLine.addColorStop(1, "rgba(255, 182, 107, 1)");
    gradientStrokeLine.addColorStop(0.6, "rgba(254, 176, 110, 1)");
    gradientStrokeLine.addColorStop(0.3, "rgba(255, 59, 70, 1)");
    gradientStrokeLine.addColorStop(0, "rgba(255, 59, 83, 1)");

    // Chart data
    const myChart1Data = {
      labels: ["0.1", "0.08", "0.06", "0.04", "0", "-0.04", "-0.06", "0.008", "0.1"],
      datasets: [{
        label: 'Survey', // Name the series
        data: [1000, 2000, 4000, 8000], // Specify the data values array
        fill: true,
        borderColor: gradientStroke,
        backgroundColor: gradientStroke,
        borderWidth: 2 // Specify bar border width
      },
      ],
    };

    // Create the chart
    const chart1 = new Chart(myChart1Ctx, {
      type: 'line',
      data: myChart1Data,
      options: {
        responsive: true, // Instruct chart js to respond nicely.
        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          x1: {

            grid: {
              display: false,
            },
            position: 'top',
            title: {
              text: 'East Ft',
              display: true,
              font: {
                size: 10,
                weight: "bold"
              },
              color: 'white'
            },

            ticks: {
              font: {
                size: 10,
                weight: "bold"
              },
              color: '#7D7D7D',
            },
          },

          y: {
            grid: {
              color: 'rgba(255, 182, 107, 0.1)',
            },
            position: 'right',
            title: {
              display: true,
              text: 'North IT',
              font: {
                size: 10,
                weight: "bold"
              },
              color: 'white'
            },
            border: {
              dash: [4, 4],
            },
            ticks: {
              font: {
                size: 10,
                weight: "bold"
              },
              color: '#7D7D7D'
            }
          },
        },
        plugins: {
          legend: {
            display: false,
            labels: {
              // This more specific font property overrides the global property
              font: {
                size: 10,
              },
              color: 'white'
            }
          },

        }
      },
    });
    const myChart2Canvas = document.getElementById('myChart2') as HTMLCanvasElement;
    const myChart2Ctx = myChart2Canvas.getContext('2d');
    // Define gradient
    var gradientStroke = myChart2Ctx.createLinearGradient(500, 0, 100, 0);
    gradientStroke.addColorStop(1, "rgba(255, 182, 107, 0.3)");
    gradientStroke.addColorStop(0.6, "rgba(254, 176, 110, 0.3)");
    gradientStroke.addColorStop(0.3, "rgba(255, 59, 70, 0.6)");
    gradientStroke.addColorStop(0, "rgba(255, 59, 83, 0.8)");

    var gradientStrokeLine = myChart2Ctx.createLinearGradient(500, 0, 100, 0);
    gradientStrokeLine.addColorStop(1, "rgba(255, 182, 107, 1)");
    gradientStrokeLine.addColorStop(0.6, "rgba(254, 176, 110, 1)");
    gradientStrokeLine.addColorStop(0.3, "rgba(255, 59, 70, 1)");
    gradientStrokeLine.addColorStop(0, "rgba(255, 59, 83, 1)");
    // Chart data
    const myChart2Data = {
      labels: ["10000", "6000", "4000", "2000"],
      datasets: [{
        label: 'Survey',
        data: [1000, 2000, 4000, 8000], // Specify the data values array
        fill: true,
        borderColor: gradientStroke,
        backgroundColor: gradientStroke, // Set gradient as background
        borderWidth: 1,
      },
      ],
    };

    // Create the chart
    /**
    * Below function for myChart2
 */
    const chart2 = new Chart(myChart2Ctx, {
      type: 'line',
      data: myChart2Data,
      options: {

        responsive: true, // Instruct chart js to respond nicely.

        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          x1: {

            grid: {
              display: false,
            },
            position: 'top',
            title: {
              display: true,
              text: 'H disp Ft',
              font: {
                size: 10,
                weight: "bold"
              },
              color: 'white'
            },

            ticks: {
              font: {
                size: 10,
                weight: "bold"
              },
              color: '#7D7D7D',
            },
          },

          y: {
            grid: {
              color: 'rgba(255, 182, 107, 0.1)',
            },
            position: 'right',
            title: {
              display: true,
              text: 'TVD ft',
              font: {
                size: 10,
                weight: "bold"
              },
              color: 'white'
            },
            border: {
              dash: [4, 4],
            },

            ticks: {
              font: {
                size: 10,
                weight: "bold"
              },
              color: '#7D7D7D'
            }
          },
        },
        plugins: {
          legend: {
            display: false,
            labels: {
              // This more specific font property overrides the global property
              font: {
                size: 10,
              },
              color: 'white'
            }
          },

        }
      },
    });

    //   const myChart3Canvas = document.getElementById('myChart3') as HTMLCanvasElement;
    //   const myChart3Ctx = myChart3Canvas.getContext('2d');

    //     // Define gradient
    //     var gradientStroke = myChart3Ctx.createLinearGradient(500, 0, 100, 0);

    // gradientStroke.addColorStop(1, "rgba(255, 182, 107, 0.3)");
    // gradientStroke.addColorStop(0.6, "rgba(254, 176, 110, 0.3)");
    // gradientStroke.addColorStop(0.3, "rgba(255, 59, 70, 0.6)");
    // gradientStroke.addColorStop(0, "rgba(255, 59, 83, 0.8)");

    // var gradientStrokeLine = myChart3Ctx.createLinearGradient(500, 0, 100, 0);
    // gradientStrokeLine.addColorStop(1, "rgba(255, 182, 107, 1)");
    // gradientStrokeLine.addColorStop(0.6, "rgba(254, 176, 110, 1)");
    // gradientStrokeLine.addColorStop(0.3, "rgba(255, 59, 70, 1)");
    // gradientStrokeLine.addColorStop(0, "rgba(255, 59, 83, 1)");

    // // Chart data
    // const myChart3Data = {
    //   labels: ["10000", "8000", "6000", "4000", "2000", "0"],

    //   datasets: [{
    //     label: 'Survey', // Name the series
    //     data: [0, 1000, 2000, 4000, 8000, 16000], // Specify the data values array
    //     fill: true,
    //     borderColor: gradientStrokeLine,
    //     backgroundColor: gradientStroke, // Set gradient as background
    //     borderWidth: 1,
    //   },
    //   ],
    // };

    // // Create the chart
    // const chart3 = new Chart(myChart3Ctx, {
    //   type: 'line',
    //   data: myChart3Data,
    //   options: {
    //     responsive: true, // Instruct chart js to respond nicely.
    //     maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
    //     scales: {
    //       x: {
    //         grid: {
    //           display: false
    //         }
    //       },
    //       x1: {

    //         grid: {
    //           display: false,
    //         },
    //         position: 'top',
    //         title: {
    //           display: true,
    //           text: 'VS Ft',
    //           font: {
    //             size: 10,
    //             weight: "bold"
    //           },
    //           color: 'white'
    //         },

    //         ticks: {
    //           font: {
    //             size: 10,
    //             weight: "bold"
    //           },
    //           color: '#7D7D7D',
    //         },
    //       },

    //       y: {
    //         grid: {
    //           color: 'rgba(255, 182, 107, 0.1)',
    //         },
    //         position: 'right',
    //         title: {
    //           display: true,
    //           text: 'TVD Ft',
    //           font: {
    //             size: 10,
    //             weight: "bold"
    //           },
    //           color: 'white'
    //         },
    //         border: {
    //           dash: [4, 4],
    //         },

    //         ticks: {
    //           font: {
    //             size: 10,
    //             weight: "bold"
    //           },
    //           color: '#7D7D7D'
    //         }
    //       },
    //     },
    //     plugins: {
    //       legend: {
    //         display: false,
    //         labels: {
    //           // This more specific font property overrides the global property
    //           font: {
    //             size: 10,
    //           },
    //           color: 'white'
    //         }
    //       },

    //     }
    //   },
    // });
  }

  loading_kafha_consumer() {
    // consumer.on('message', (message) => {
    //   console.log('Received message:', message.value);
    // });
  }

  loading_kafha_consumer_error() {
    // consumer.on('error', (error) => {
    //   console.error('Error in Kafka Consumer:', error);
    // });
  }

  loading_kafha_consumer_sigin() {
    // process.on('SIGINT', () => {
    //   consumer.close(true, () => {
    //     console.log('Kafka Consumer has been closed.');
    //     process.exit();

    //   });

    // });
  }
}

