import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
// import { WidgetService } from 'client/app/services/widget.service';
import { ToastrService } from 'ngx-toastr';
// import { EditwidgetComponent } from '../../dashboard/editwidget/editwidget.component';
import { CardInput } from '../models/cardinput';
import { EditwidgetComponent } from '../../survey/editwidget/editwidget.component';


@Component({
  selector: 'app-cardwidget',
  templateUrl: './cardwidget.component.html',
  styleUrls: ['./cardwidget.component.scss']
})
export class CardwidgetComponent implements OnInit {

  @Input() content: any;
  cardInput: CardInput;
  cardType = 'basic';
  @Input() id: any;
  @Input() editMode: any;
  @Output() onEdit?: any = new EventEmitter();
  fields: any[] = [
    {
      key: 'value',
      type: 'string',
      value: '',
      label: 'Value',
    },
    {
      key: 'dataApi',
      type: 'string',
      value: '',
      label: 'Data Api',
    },
    {
      key: 'label',
      type: 'string',
      value: '',
      label: 'Label',
    },
    {
      key: 'navUrl',
      type: 'string',
      value: '',
      label: 'Nav Url',
    },
    {
      key: 'tab',
      type: 'string',
      value: '',
      label: 'Tab',
    },
    {
      key: 'icon',
      type: 'string',
      value: '',
      label: 'Icon',
    },
    {
      key: 'navFilter',
      type: 'array',
      value: [],
      label: 'Nav Filter',
      schema: [
        {
          key: 'filterKey',
          type: 'string',
          value: '',
          label: 'Filter Key',
        },
        {
          key: 'filterType',
          type: 'enum',
          value: '',
          label: 'Filter Type',
          option: [
            {
              type: 'text',
            },
            {
              type: 'range',
            },
            {
              type: 'equal',
            },
          ],
        },
        {
          key: 'filterValue',
          type: 'any',
          value: {},
          label: 'Filter Value',
        },
      ],
    },
  ];
  constructor(
    private router: Router,
    private dialog: MatDialog,
    private toastservice: ToastrService
  ) {}

  ngOnInit(): void {
    // this.cardInput = JSON.parse(this.content);
    // var filterObj = {
    //   offset: 0,
    //   limit: 0,
    //   filter: this.cardInput.navFilter,
    // };
    // this.fields.map((e1) => {
    //   var cardInputKeys = [];
    //   cardInputKeys = Object.keys(this.cardInput);
    //   cardInputKeys.filter((e2) => {
    //     if (e1.key == e2) {
    //       e1.value = this.cardInput[e2];
    //     }
    //   });
    // });
    // console.log(this.fields);
    // this.cardService
    //   .getChartDataWithFilter(this.cardInput.dataApi, filterObj)
    //   .subscribe((data: any) => {
    //     this.cardInput.value = data.body.result.count;
    //   });
  }
  navigate() {
    if (this.editMode) {
      const dialogRef = this.dialog.open(EditwidgetComponent, {
        data: this.fields,
        width: 'auto',
        height: 'auto',
        maxHeight: '80vh',
      });
      dialogRef.afterClosed().subscribe((data) => {
        console.log('data', data);
        this.onEdit.emit({
          id: this.id,
          config: { ...data, type: this.cardType },
        });
      });
    } else {
      var state = {
        filter: this.cardInput.navFilter,
        tab: undefined,
      };
      if (this.cardInput.tab != undefined) {
        state.tab = this.cardInput.tab;
      }
      this.router
        .navigate([this.cardInput.navUrl], {
          state,
        })
        .then((data) => {
          console.log('redirected successfully', data);
        })
        .catch((error) => {
          this.toastservice.error('error not found');
          console.log('error not found', error);
        });
    }
  }

}

