import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardwidgetComponent } from './cardwidget.component';

describe('CardwidgetComponent', () => {
  let component: CardwidgetComponent;
  let fixture: ComponentFixture<CardwidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CardwidgetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CardwidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
