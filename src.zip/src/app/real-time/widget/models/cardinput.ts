export class CardInput {
  type: any;
  label: string;
  value: any;
  icon: string;
  navUrl: any;
  dataApi: any;
  navFilter: any;
  columnFormat: any;
  tab: string;
  constructor({
    type = null,
    label = null,
    value = null,
    dataApi = undefined,
    navUrl = undefined,
    navFilter = undefined,
    icon = undefined,
    columnFormat = undefined,
    tab = undefined,
  } = {}) {
    this.type = type;
    this.label = label;
    this.value = value;
    this.navUrl = navUrl;
    this.dataApi = dataApi;
    this.navFilter = navFilter;
    this.icon = icon;
    this.columnFormat = columnFormat;
    this.tab = tab;
  }
  export() {
    return JSON.stringify(this);
  }
}
