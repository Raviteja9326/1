import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CardwidgetComponent } from './cardwidget/cardwidget.component';
import { TablewidgetComponent } from './tablewidget/tablewidget.component';
import { MaterialModule } from 'src/app/shared/material.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule
  ],
  declarations: [
    CardwidgetComponent,
    TablewidgetComponent
  ],
  exports: [
    CardwidgetComponent,
    TablewidgetComponent
  ]
})
export class WidgetModule { }