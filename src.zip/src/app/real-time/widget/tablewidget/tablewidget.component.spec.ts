import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TablewidgetComponent } from './tablewidget.component';

describe('TablewidgetComponent', () => {
  let component: TablewidgetComponent;
  let fixture: ComponentFixture<TablewidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TablewidgetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TablewidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
