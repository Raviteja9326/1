import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { CardInput } from '../models/cardinput';
import { EditwidgetComponent } from '../../survey/editwidget/editwidget.component';

@Component({
  selector: 'app-tablewidget',
  templateUrl: './tablewidget.component.html',
  styleUrls: ['./tablewidget.component.scss'],
})
export class TablewidgetComponent implements OnInit {
  @Input() content: any;
  cardInput: CardInput;
  displayedColumns: string[] = [];
  dataSource: MatTableDataSource<any>;
  columnFormat: any;
  @Input() editMode: any;
  @Input() id: any;
  @Output() onEdit?: any = new EventEmitter();
  cardType = 'table';
  fields: any[] = [
    {
      key: 'dataApi',
      type: 'string',
      value: '',
      label: 'Data Api',
    },
    {
      key: 'label',
      type: 'string',
      value: '',
      label: 'Label',
    },
    {
      key: 'columnFormat',
      type: 'array',
      value: [],
      label: 'Column Format',
      schema: [
        {
          key: 'key',
          type: 'string',
          value: '',
          label: 'Key',
        },
        {
          key: 'text',
          type: 'string',
          value: '',
          label: 'Name',
        },
        {
          key: 'color',
          type: 'string',
          value: '',
          label: 'Color',
        },
      ],
    },
    {
      key: 'navFilter',
      type: 'object',
      value: {},
      label: 'Nav Filter',
      keyschema: {
        type: 'string',
        value: '',
        label: 'keySchema',
      },
      valueschema: {
        type: 'array',
        value: [],
        label: 'Table filter',
        schema: [
          {
            key: 'filterKey',
            type: 'string',
            value: '',
            label: 'Filter Key',
          },
          {
            key: 'filterType',
            type: 'enum',
            value: '',
            label: 'Filter Type',
            option: [
              {
                type: 'text',
              },
              {
                type: 'range',
              },
              {
                type: 'equal',
              },
            ],
          },
          {
            key: 'filterValue',
            type: 'any',
            value: null,
            label: 'Filter Value',
          },
        ],
      },
    },
    {
      key: 'value',
      type: 'array',
      value: [],
      label: 'value',
      schema: [],
      schemaRef: { ref: 'columnFormat', type: 'string', value: '' },
    },
  ];
  constructor(
    private router: Router,
    // private tableService: WidgetService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.cardInput = JSON.parse(this.content);
    this.fields.map((e1) => {
      var cardInputKeys = [];
      cardInputKeys = Object.keys(this.cardInput);
      cardInputKeys.filter((e2) => {
        if (e1.key == e2) {
          e1.value = this.cardInput[e2];
        }
      });
      if (e1.schemaRef != undefined) {
        const schemaware = this.fields.find((e) => e.key == e1.schemaRef.ref);
        e1.schema = schemaware.value.map((e) => {
          return {
            ...e,
            type: e1.schemaRef.type,
            value: e1.schemaRef.value,
          };
        });
      }
    });
    console.log('cardd', this.fields);
    // this.displayedColumns = this.cardInput.columnFormat.map((e) => e.key);
    // this.tableService
    //   .getTableDataWithFilter(this.cardInput.dataApi, this.cardInput.navFilter)
    //   .subscribe((data: any) => {
    //     const tabledata = data.body.result.reduce((acc, current) => {
    //       for (let key in current) {
    //         const keysplit = key.split('_');
    //         const i = parseInt(keysplit[1]);
    //         acc[i][keysplit[0]] = current[key];
    //       }
    //       return acc;
    //     }, this.cardInput.value);
    //     this.dataSource = new MatTableDataSource(tabledata);
    //   });
  }

  navigate() {
    if (this.editMode) {
      const dialogRef = this.dialog.open(EditwidgetComponent, {
        data: this.fields,
        width: 'auto',
        height: 'auto',
        maxHeight: '80vh',
      });
      dialogRef.afterClosed().subscribe((data) => {
        data.navFilter.valueFormat = {
          valueType: 'count',
        };
        console.log('object data', data);
        this.onEdit.emit({
          id: this.id,
          config: { ...data, type: this.cardType },
        });
      });
    } else {
      return;
      // this.router.navigate([this.cardInput.navUrl], {
      //   state: {
      //     filter: this.cardInput.navFilter,
      //   },
      // });
    }
  }
}
