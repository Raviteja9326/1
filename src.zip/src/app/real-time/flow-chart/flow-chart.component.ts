import { Component, ElementRef, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import * as joint from 'jointjs';

@Component({
  selector: 'app-flow-chart',
  templateUrl: './flow-chart.component.html',
  styleUrls: ['./flow-chart.component.scss']
})
export class FlowChartComponent {
  @ViewChild('umlDiagram', { static: true }) umlDiagram!: ElementRef;

  ngAfterViewInit() {
    const umlDiagramElement: HTMLElement = this.umlDiagram.nativeElement;
    const graph = new joint.dia.Graph();
    const paper = new joint.dia.Paper({
      el: umlDiagramElement,
      model: graph,
      width: 800,
      height: 800,
      gridSize: 12,
    });



    // Create example nodes
    const node1 = new joint.shapes.basic.Rect({
      position: { x: 525, y: 50 },
      size: { width: 100, height: 50 },
      attrs: {
        rect: {
          rx: 20,
          ry: 20,
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          text: 'Start',
        },
      },
    });

    const node2 = new joint.shapes.basic.Rect({
      position: { x: 500, y: 150 },
      size: { width: 150, height: 50 },
      attrs: {
        rect: {
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "1 wallpath main",
            preserveSpaces: true
          }
        }
      },

    });

    const node3 = new joint.shapes.basic.Rect({
      position: { x: 500, y: 250 },
      size: { width: 150, height: 50 },
      attrs: {
        rect: {
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "2 BHA & Drill string design main",
            preserveSpaces: true
          }
        }
      }
    });

    const node4 = new joint.shapes.basic.Path({
      position: { x: 500, y: 350 },
      size: { width: 150, height: 70 },
      attrs: {
        path: { d: 'M 30 0 L 60 30 30 60 0 30 z', stroke: '#2b9de4', "stroke-width": 2 },
        text: { text: 'Has drilling motor', 'ref-y': -50 }
      }
    })


    const node5 = new joint.shapes.basic.Rect({
      position: { x: 425, y: 500 },
      size: { width: 150, height: 50 },
      attrs: {
        rect: {
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "3T&D main rotary BHA",
            preserveSpaces: true
          }
        }
      }
    });
    const node6 = new joint.shapes.basic.Rect({
      position: { x: 595, y: 500 },
      size: { width: 150, height: 50 },
      attrs: {
        rect: {
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "3T&D main DH BHA",
            preserveSpaces: true
          }
        }
      }
    });

    const node7 = new joint.shapes.basic.Rect({
      position: { x: 425, y: 600 },
      size: { width: 150, height: 50 },
      attrs: {
        rect: {
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "4 Hydrolic main rotary BHA",
            preserveSpaces: true
          }
        }
      }
    });
    const node8 = new joint.shapes.basic.Rect({
      position: { x: 595, y: 600 },
      size: { width: 150, height: 50 },
      attrs: {
        rect: {
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "4 Hydrolic DH BHA",
            preserveSpaces: true
          }
        }
      }
    });
    const node9 = new joint.shapes.basic.Rect({
      position: { x: 525, y: 700 },
      size: { width: 100, height: 50 },
      attrs: {
        rect: {
          rx: 20, ry: 20,
          stroke: '#2b9de4',
          "stroke-width": 3
        },
        text: {
          fontFamily: "sans-serif",
          textWrap: {
            text: "End",
            preserveSpaces: true
          }
        }
      }
    });

    // Create links between the nodes
    const link1 = new joint.shapes.standard.Link({
      source: { id: node1.id },
      target: { id: node2.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        }
      }

    });

    const link2 = new joint.shapes.standard.Link({
      source: { id: node2.id },
      target: { id: node3.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
    });

    const link3 = new joint.shapes.standard.Link({
      source: { id: node3.id },
      target: { id: node4.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
    });
    const link4 = new joint.shapes.standard.Link({
      source: { id: node4.id },
      target: { id: node5.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
      labels: [{
        attrs: {
          text: {
            text: 'No'
          }
        }
      }],
    });
    const link5 = new joint.shapes.standard.Link({
      source: { id: node4.id },
      target: { id: node6.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
      labels: [{
        attrs: {
          text: {
            text: 'Yes'
          }
        }
      }],
    });
    const link6 = new joint.shapes.standard.Link({
      source: { id: node5.id },
      target: { id: node7.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
    });
    const link7 = new joint.shapes.standard.Link({
      source: { id: node6.id },
      target: { id: node8.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
    });
    const link8 = new joint.shapes.standard.Link({
      source: { id: node7.id },
      target: { id: node9.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
    });
    const link9 = new joint.shapes.standard.Link({
      source: { id: node8.id },
      target: { id: node9.id },
      attrs: {
        line: {
          stroke: '#2b9de4',
          'stroke-width': 2,
        },
      },
    });

    // adding to to the graph
    graph.addCells([node1, node2, node3, node4, node5, node6,
      node7, node8, node9, link1, link2, link3, link4,
      link5, link6, link7, link8, link9]);

  }
}
