import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlowChartComponent } from './flow-chart.component';

const routes: Routes = [
  {
    path: '',component:FlowChartComponent,children:[]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlowChartRoutingModule { }
