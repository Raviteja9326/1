import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FlowChartRoutingModule } from './flow-chart-routing.module';
import { FlowChartComponent } from './flow-chart.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    FlowChartComponent
  ],
  imports: [
    CommonModule,
    FlowChartRoutingModule,
    AllModule
  ]
})
export class FlowChartModule { }
