import { Component, OnInit, Input, ViewChild, AfterViewInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Column } from '../../core/interfaces/column.interface';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MaterialsService } from 'src/app/core/services/materials.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent<T> implements OnInit, AfterViewInit, OnChanges {
  @Input()
  tableColumns: Array<Column> = [];

  @Input()
  tableData: Array<T> = [];

  @Input()
  updateColumn: boolean;

  @Input()
  actionColumn: boolean;

  @Input()
  deleteColumn: boolean;

  @Input()
  hidePaginator: boolean;

  @Output()
  updateRow = new EventEmitter<any>();

  @Output()
  deleteRow = new EventEmitter<any>();

  displayedColumns: Array<string> = [];
  dataSource: MatTableDataSource<T> = new MatTableDataSource();
  // Properties for the paginator
  pageSize = 5; // Number of items to be displayed per page
  currentPageIndex = 0; // Current page index
  pageSizeOptions: number[] = [5, 10, 25, 100]; // Options for the page size dropdown
  totalItemsCount = 0; // Total number of items in the data source

  // Reference to the MatPaginator instance
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  _value: any = ''; // for search string value
  ColumnOfTable: any = [];
  displayNoRecords: boolean = false;// for showing no record
  constructor(private materials: MaterialsService) { }// constructor ends

  ngOnInit(): void {
   // this.MaterialsList();
    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if (this.updateColumn)
      this.displayedColumns.push("update");
    if (this.deleteColumn)
      this.displayedColumns.push("delete");
    this.dataSource = new MatTableDataSource(this.tableData);
    this.totalItemsCount = this.dataSource.data.length;

  }
  ngOnChanges() {
    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if (this.updateColumn)
      this.displayedColumns.push("update");
    if (this.deleteColumn)
      this.displayedColumns.push("delete");
    this.dataSource = new MatTableDataSource(this.tableData);
    this.totalItemsCount =  this.dataSource.data.length;
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;

  }

  ngAfterViewInit() {
    console.log(this.sort, this.paginator);
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  updateRowMethod(row) {
    this.updateRow.emit(row);
  }
  deleteRowMethod(row) {
    this.deleteRow.emit(row);
  }

  applyFilter(event: Event) {
    /* Global search implemented on all columns */
    var result = [];
    let filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();
    for (let el of this.tableData) {
      this.displayedColumns.forEach(col => {
        this.ColumnOfTable = el[`${col}`];
        this.ColumnOfTable = JSON.stringify(this.ColumnOfTable)
        let a = this.ColumnOfTable.toLocaleLowerCase().includes(filterValue);
        if (a == true && result.indexOf(el) == -1) {
          result.push(el);
        }
        this.ColumnOfTable = JSON.parse(this.ColumnOfTable)
      })
    }
    if (result.length == 0) {
      this.dataSource = new MatTableDataSource<any>([]);
      this.dataSource.paginator = this.paginator;
    }
    if (result.length !== 0) {
      this.dataSource = new MatTableDataSource<any>(result);
      this.paginator.length = result.length;
      this.dataSource.paginator = this.paginator;
      this.dataSource['sort'] = this.sort;
    }
    if (this._value == '') {
      this.currentPageIndex = 0;
      this.pageSize = 5;
    }

  }

  /* materials list function*/
  MaterialsList() {

    // this.hidePaginator = true;
    this.materials.reportsColumn.subscribe(res => {
      console.log(res)
      if (res !== '0') {
        this.displayedColumns = res.map((c) => c.columnDef);
        console.log(this.displayedColumns)
      }
    });
    this.materials.reportsData.subscribe(res => {
      console.log(res)
      if (res !== '0') {
        this.tableData = res;
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.totalItemsCount = res.length
        this.displayNoRecords = false;
        console.log(this.dataSource)
      } else if (res.length == 0) {
        this.displayNoRecords = true;
      }
    });
   
  }// function ends
  




}