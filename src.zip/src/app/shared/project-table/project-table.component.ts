import { Component, OnInit, Input, ViewChild, AfterViewInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Column } from '../../core/interfaces/column.interface';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { StorageService } from 'src/app/core/services/storage.service';
import Swal from 'sweetalert2';
import { AllinoneService } from 'src/app/core/services/allinone.service';
import { Router } from '@angular/router';
import { MenulistService } from 'src/app/core/services/menulist.service';
import { setuplist } from 'src/app/core/interfaces/menulist.interface';
@Component({
  selector: 'app-project-table',
  templateUrl: './project-table.component.html',
  styleUrls: ['./project-table.component.scss']
})
export class ProjectTableComponent<T> implements OnInit, AfterViewInit, OnChanges {
  @Input()
  tableColumns: Array<Column> = [];
  @Input()
  tableData: Array<T> = [];
  @Input()
  updateColumn: boolean;
  @Input()
  deleteColumn: boolean;
  @Output()
  updateRow = new EventEmitter<any>();
  @Output()
  deleteRow = new EventEmitter<any>();
  displayedColumns: Array<string> = [];
  dataSource: MatTableDataSource<T> = new MatTableDataSource();
  pageSize = 20;
  currentPageIndex = 0;
  pageSizeOptions: number[] = [20,,40,60,100];
  totalItemsCount = 0;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  ColumnOfTable: any = [];
  displayNoRecords: boolean = false;
  selectedRowIndex: number = 1;
  initialized: boolean = false;
  savedWells:any;
  constructor(private store:StorageService, private resuable:AllinoneService, private route:Router, private menu:MenulistService) {}
  ngOnInit(): void {
    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if (this.updateColumn)
      this.displayedColumns.push("update");
    if (this.deleteColumn)
      this.displayedColumns.push("delete");
    this.dataSource = new MatTableDataSource(this.tableData);
    this.totalItemsCount = this.dataSource.data.length;
  }
  ngOnChanges() {
    this.getTableData(this.tableData)
    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.updateColumn)
    this.displayedColumns.push("update");
    if(this.deleteColumn)
    this.displayedColumns.push("delete");
    this.dataSource = new MatTableDataSource(this.tableData);
    this.totalItemsCount =  this.dataSource.data.length;
  }
  getTableData(data:any) {
    if(data.length !=0){
     this.onRowClick(this.selectedRowIndex, data[this.selectedRowIndex], false);
    }
    else {
      this.savedWells = this.store.getWellName();
      this.restorelastData(this.savedWells)
    }
  }
  restorelastData(data:any) {
    if(data != null){
      this.onRowClick(data.rowIndex, data[data.rowIndex], false);
     }
  }
  onRowClick(index: number, row:any, statement:boolean) {
    console.log(index, row, statement)
    if (statement == true) {
    Swal.fire({
      title: `Do you want to make well status Active?`,
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
      text: '',
    }).then((result) => {
      if (result.isConfirmed) {
        this.selectedRowIndex = index;
        const obj2 = Object.assign({}, row, {rowIndex: this.selectedRowIndex});
        this.resuable.getWellData(obj2);
        this.menu.getmenusdata(setuplist)
        this.route.navigate(['/dashboard/jobinfo/jobinformation'])
      }
    })
  }
  else if(this.initialized == false){
    this.selectedRowIndex = index;
    const obj3 = Object.assign({}, row, {rowIndex: this.selectedRowIndex});
    this.resuable.getWellData(obj3);
  }
  }
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  updateRowMethod(row) {
    this.updateRow.emit(row);
  }
  deleteRowMethod(row) {
    this.deleteRow.emit(row);
  }
}