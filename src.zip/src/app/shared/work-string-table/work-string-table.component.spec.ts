import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkStringTableComponent } from './work-string-table.component';

describe('WorkStringTableComponent', () => {
  let component: WorkStringTableComponent;
  let fixture: ComponentFixture<WorkStringTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkStringTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkStringTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
