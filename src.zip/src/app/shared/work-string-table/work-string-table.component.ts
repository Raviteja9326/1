import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

export interface PeriodicElement {
  description: string;
  qty: number;
  bottom: string;
  top: string;
  od: number;
  minid:number;
  max0:number;
  item:number;
  total:number;
  acc:number;
  nw:number;
  adj:number;
  totalweight:number;
  Acc:number
}

export interface GroupBy {
  initial: string;
  isGroupBy: boolean;
}

const ELEMENT_DATA: (PeriodicElement | GroupBy)[] = [
  {initial: 'Drillstring', isGroupBy: true},
  {description: "E756.7", qty: 1, bottom: 'NC26', top: 'NC26', od:2.375, minid:1.750,max0:3.050,item:90.2,total:1.23,acc:90,nw:6.65,adj: 1.23,totalweight:32.91,Acc:12.78},
  {initial: 'BHA', isGroupBy: true},
  {description: "E756.7", qty: 2, bottom: 'NC26', top: 'NC26', od:2.375, minid:1.750,max0:3.050,item:90.2,total:1.23,acc:90,nw:6.65,adj: 1.23,totalweight:32.91,Acc:12.78},
];


@Component({
  selector: 'app-work-string-table',
  templateUrl: './work-string-table.component.html',
  styleUrls: ['./work-string-table.component.scss']
})
export class WorkStringTableComponent implements OnInit {

 isChecked: boolean = false;
  displayedColumns: string[] = [ 'description','qty','bottom','top','od','minid','max0','item','total','acc','nw','adj','totalweight','Acc','group','centralizers','Actions'];
  dataSource = ELEMENT_DATA;

  isGroup(index, item): boolean{
    return item.isGroupBy;
  }
  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  singleView(data){
   if(data.initial =="Drillstring"){
    this.route.navigate(['/dashboard/workstring/drillstring']);
   }
   else if(data.initial =="BHA"){
    this.route.navigate(['/dashboard/workstring/bha']);
   }
  }

}
