import { Component, OnInit, AfterViewInit, Input, ViewChild, ElementRef, OnChanges, ChangeDetectionStrategy } from '@angular/core';
import * as THREE from "three";
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

@Component({
  selector: 'app-model',
  templateUrl: './model.component.html',
  styleUrls: ['./model.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ModelComponent implements OnInit, OnChanges{
  @ViewChild('modelContainer', { static: true }) modelContainer: ElementRef;
  @Input('modelWidth') modelWidth: any;
  @Input('modelHeight')modelHeight:any;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private model: THREE.Object3D;
  originalModel: THREE.Object3D;
  showWireframeFlag: boolean = false;
  xAnimationValue: number;
  yAnimationValue: number = 0.005;
  startAnimation: boolean = true;

  ngOnInit() {
   
  
  }

  ngOnChanges(){
    this.initScene();
    this.loadModel();
    this.animate();
    this.addControls();
  }
  private initScene() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    this.renderer = new THREE.WebGLRenderer();
    this.renderer.setSize(this.modelWidth-10, this.modelHeight);
    this.modelContainer.nativeElement.appendChild(this.renderer.domElement);

    this.camera.position.z = 6;
  }

  private loadModel() {
    const loader = new OBJLoader();
    loader.load('assets/3d-objects/objects/hook.obj', (object) => {
      console.log("Model",object);
      // Calculate the object's bounding box
    const bbox = new THREE.Box3().setFromObject(object);

    // Calculate the center of the bounding box
    const center = new THREE.Vector3();
    bbox.getCenter(center);
      this.model = object;
      this.originalModel = object.clone();
      const scaleFactor = 4; // Increase for larger object, decrease for smaller object
      this.model.scale.set(scaleFactor, scaleFactor, scaleFactor);
      this.model.position.sub(center);
      // Add margin from the top of the object
      const marginFromTop = -2; // Adjust this value as needed
      this.model.position.y += marginFromTop;
      this.scene.add(this.model);
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.5); // Color, Intensity
      this.scene.add(ambientLight);
      const directionalLight = new THREE.DirectionalLight(0xffffff, 1); // Color, Intensity
      directionalLight.position.set(0, 1, 0); // Direction of light (x, y, z)

      
      this.scene.add(directionalLight);
    });
  }

  private animate() {
    requestAnimationFrame(this.animate.bind(this));
    if (this.model) {
     // this.model.rotation.x += 0.005;
      this.model.rotation.y += this.yAnimationValue;
    }
    this.renderer.render(this.scene, this.camera);
  }

  private addControls(){
          // Set up OrbitControls
    const controls = new OrbitControls(this.camera, this.renderer.domElement);
    controls.enableDamping = true; // Add smooth damping effect
    controls.dampingFactor = 0.1;
    controls.rotateSpeed = 0.5; // Adjust rotation speed
    controls.zoomSpeed = 0.5; // Adjust zoom speed
    controls.autoRotate = true;
    controls.enableZoom = true;
    controls.enablePan = true;

  }

  showWireframe(){

    this.showWireframeFlag = true;
    // Create a wireframe material
    const wireframeMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff, // Wireframe color
      wireframe: true, // Enable wireframe mode
    });
    this.model.traverse(function (child) {
      if (child instanceof THREE.Mesh) {
        child.material = wireframeMaterial;
      }
    });
  }

  showSolid(){
    this.showWireframeFlag = false;
    let originalMaterial;
    this.originalModel.traverse(function (child) {
      if (child instanceof THREE.Mesh) {
        originalMaterial = child.material;
      }
    });
    this.model.traverse(function (child) {
      if (child instanceof THREE.Mesh) {
        child.material = originalMaterial;
      }
    });
  }

  toggleRotation(){
    if(this.xAnimationValue==0){
    this.startAnimation = true;
     this.xAnimationValue = 0.005;
     this.yAnimationValue = 0.005;
    }
    else{
      this.startAnimation = false;
     this.xAnimationValue = 0;
     this.yAnimationValue = 0;
    }
     }
}
