import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Column } from 'src/app/core/interfaces/column.interface';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { jobInfo } from 'src/app/core/interfaces/jobInfo.interface';
interface UserData {
  id: number;
  [key: string]: any; // Allow dynamic columns
}

@Component({
  selector: 'app-job-info-editable-table',
  templateUrl: './job-info-editable-table.component.html',
  styleUrls: ['./job-info-editable-table.component.scss'],
})
export class JobInfoEditableTableComponent<T> implements OnInit,OnChanges{
  @Input() tableData: Array<T>=[];//to get table data
  @Input() tableColumns: Column[];//to get table columns
  @Input() actionColumn: boolean;//flag to show actions column
  @Input() cloneColumn: boolean;//flag to show clone button
  @Input() activateColumn: boolean;//flag to show activate button
  @Input() redirectColumn: boolean;//flag to show redirect button
  @Input() deleteColumn: boolean;//flag to show delete button
  @Output()
  actionEvent = new EventEmitter<any>();
  @Output()
  getTableEvent = new EventEmitter<any>();
  @ViewChild('inputRef') inputRef!: ElementRef;

  actionButtons: any[] = [];
  dataSource :Array<any>=[] ;
  displayedColumns: Array<string> = [];
  editableCell: { rowIndex: number; column: string } | null = null;
  draggedRowIndex: number;
  personnelData: jobInfo[] = [];

  constructor(private changeDetectorRef: ChangeDetectorRef){


  }//end of constructor

  isCellEditable(rowIndex: number, column: string): boolean {

    return (
      this.editableCell !== null &&
      this.editableCell.rowIndex === rowIndex &&
      this.editableCell.column === column
    );
  }

  onCellClick(rowIndex: number, column: string) {

    this.editableCell = { rowIndex, column };
    setTimeout(() => {
      if(this.inputRef.nativeElement)
        this.inputRef.nativeElement.focus();
    }, 0);
  }

  onBlur(rowIndex: number, column: string,row) {

    console.log("column field",column, this.dataSource);

    this.editableCell = null;
    this.getTableEvent.emit({data:this.dataSource});
  }
  ngOnInit(): void {

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
  
    this.setActionButtons();
   
  }
  ngOnChanges(){

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  }

  cloneWellPathMethod(element){

    console.log("cloned",element);
    this.actionEvent.emit({'action':"clone",'data':element});
  }

  activateWellPath(element){

    console.log("activated row");
    this.actionEvent.emit({'action':"activate",'data':element});
  }

  viewSurveyPoints(element){

    console.log("view survey points");
    this.actionEvent.emit({'action':"viewpoints",'data':element});
  }

  /**
   * Below function will send the action event for value changed.
   */
  valueChanged (event) {

    this.actionEvent.emit({});
  } //end of 'valueChanged' function


  deletePersonnelRecord (element,i){

    console.log("delete personnel record");
    this.actionEvent.emit({'action':"delete",'data':element});
    this.dataSource.splice(i,1);
    this.dataSource = [...this.dataSource];
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  }

  drop(event: CdkDragDrop<any[]>) {

    moveItemInArray(this.dataSource,this.draggedRowIndex, event.currentIndex);
    moveItemInArray(this.actionButtons, this.draggedRowIndex, event.currentIndex);
    this.getTableEvent.emit({data:this.dataSource});
  }

  isRowDisabled(row: any): boolean {
    // Add your condition here based on the row value
    // For example, disable rows with a specific name
    return row.added === true;
  }

  onDragStarted(index: number) {
    
    this.draggedRowIndex = index;
  }


  
  

  setActionButtons(){

    this.actionButtons = this.dataSource.map((item:any)=>{
      if(item.active)
        return {active:true,delete:false}
      else
        return {active:false,delete:true}
      }
    );
  }
}
