import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Column } from 'src/app/core/interfaces/column.interface';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
interface UserData {
  id: number;
  [key: string]: any; // Allow dynamic columns
}

@Component({
  selector: 'app-temperature-editable-table',
  templateUrl: './temperature-editable-table.component.html',
  styleUrls: ['./temperature-editable-table.component.scss'],
})
export class TemperatureEditableTableComponent<T> implements OnInit,OnChanges{
  @Input() tableData: Array<T>=[];//to get table data
  @Input() tableColumns: Column[];//to get table columns
  @Input() actionColumn: boolean;//flag to show actions column
  @Input() cloneColumn: boolean;//flag to show clone button
  @Input() activateColumn: boolean;//flag to show activate button
  @Input() redirectColumn: boolean;//flag to show redirect button
  @Input() deleteColumn: boolean;//flag to show delete button
  @Input() kellyBushing;// KellyBushing value for calculation
  @Input() groundLevel;//GroundLevel value for calculation
  @Output()
  actionEvent = new EventEmitter<any>();
  @Output()
  deleteEvent = new EventEmitter<any>();
  @Output()
  updateEvent = new EventEmitter<any>();
  @Output()
  getTableEvent = new EventEmitter<any>();
  @ViewChild('inputRef') inputRef!: ElementRef;

  actionButtons: any[] = [];
  dataSource :Array<any>=[] ;
  displayedColumns: Array<string> = [];
  editableCell: { rowIndex: number; column: string } | null = null;
  draggedRowIndex: number;
  originalValueListHashMap: any = [];

  constructor(private changeDetectorRef: ChangeDetectorRef){


  }//end of constructor

  isCellEditable(rowIndex: number, column: string): boolean {

    return (
      this.editableCell !== null &&
      this.editableCell.rowIndex === rowIndex &&
      this.editableCell.column === column
    );
  }

  onCellClick(rowIndex: number, column: string,row:any) {
    this.originalValueListHashMap[rowIndex] = {...row};
    this.editableCell = { rowIndex, column };
    setTimeout(() => {
      if(this.inputRef)
      this.inputRef.nativeElement.focus();
    }, 0);
  }
  

  onBlur(rowIndex: number, column: string,row) {
    
    if(column=='MeasuredDepth'){
      row.TrueVerticalDepth = row.MeasuredDepth;
      row.TVDSS = parseInt(row.MeasuredDepth)- this.kellyBushing;
      row.CourseLength = parseInt(row.MeasuredDepth)-(this.kellyBushing-this.groundLevel);
    }

    if(this.originalValueListHashMap[rowIndex][column]!=row[column]){
      row.isUpdated = true;
    }
    this.editableCell = null;
    console.log("updated",this.dataSource);
    this.getTableEvent.emit({data:this.dataSource});
  }
  ngOnInit(): void {

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
    console.log("Inputres",this.inputRef )

  
   
   
  }
  ngOnChanges(){

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
    this.kellyBushing = this.kellyBushing;
    this.groundLevel = this.groundLevel;
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  }

  cloneWellPathMethod(element){

    console.log("cloned",element);
    this.actionEvent.emit({'action':"clone",'data':element});
  }

  activateWellPath(element){

    console.log("activated row");
    this.actionEvent.emit({'action':"activate",'data':element});
  }

  viewSurveyPoints(element){

    console.log("view survey points");
    this.actionEvent.emit({'action':"viewpoints",'data':element});
  }

  deleteTemperature(element,i){

    console.log("delete temperature");
    this.deleteEvent.emit({'action':"delete",'data':element});
    // if (element.isNewlyAdded)
      this.dataSource.splice(i,1);
    this.dataSource = [...this.dataSource];
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  }

  updateTemperature (element) {

    console.log("delete temperature");
    this.updateEvent.emit({'action':"delete",'data':element});
    this.dataSource = [...this.dataSource];
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  } //end of 'updateTemperature' function


  drop(event: CdkDragDrop<any[]>) {

    moveItemInArray(this.dataSource,this.draggedRowIndex, event.currentIndex);
    moveItemInArray(this.actionButtons, this.draggedRowIndex, event.currentIndex);
    this.getTableEvent.emit({data:this.dataSource});
  }

  isRowDisabled(row: any): boolean {
    // Add your condition here based on the row value
    // For example, disable rows with a specific name
    return row.added === true;
  }

  onDragStarted(index: number) {
    
    this.draggedRowIndex = index;
  }

  setActionButtons(){
    if(this.dataSource?.length>0){
    this.actionButtons = this.dataSource.map((item:any)=>{
      if(item.active)
        return {active:true,delete:false}
      else
        return {active:false,delete:true}
      }
    );}
  }
 
  valueChangeEvent ($event) {

    this.actionEvent.emit({});
  }
  
}
