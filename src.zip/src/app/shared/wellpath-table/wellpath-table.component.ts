import { Subject } from 'rxjs';
import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Column } from 'src/app/core/interfaces/column.interface';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { WellPathsService } from 'src/app/core/services/wellPaths.service';
import { Router } from '@angular/router';
import { WellIntervalService } from 'src/app/core/services/wellinterval.service';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as _ from 'lodash';
interface UserData {
  id: number;
  [key: string]: any; // Allow dynamic columns
}

@Component({
  selector: 'app-wellpath-table',
  templateUrl: './wellpath-table.component.html',
  styleUrls: ['./wellpath-table.component.scss'],
})
export class WellPathTableComponent<T> implements OnInit, OnChanges {
  @Input() tableData: Array<any> = [];//to get table data
  @Input() tableColumns: Column[];//to get table columns
  @Input() actionColumn: boolean;//flag to show actions column
  @Input() cloneColumn: boolean;//flag to show clone button
  @Input() activateColumn: boolean;//flag to show activate button
  @Input() redirectColumn: boolean;//flag to show redirect button
  @Input() deleteColumn: boolean;//flag to show delete button
  @Input() kellyBushing;// KellyBushing value for calculation
  @Input() groundLevel;//GroundLevel value for calculation
  @Input() tableType; // table type

  @Output()
  actionEvent = new EventEmitter<any>();//event emitter for actions on well path table
  @Output()
  getTableEvent = new EventEmitter<any>();// event emitter for detecting change on table

  @ViewChild('inputRef') inputRef!: ElementRef;

  actionButtons: any[] = [];
  dataSource: Array<any> = [];
  displayedColumns: Array<string> = [];
  editableCell: { rowIndex: number; column: string } | null = null;
  draggedRowIndex: number;
  originalValueListHashMap: any = [];
  allMaterials: any[];
  materialModel: any = [];
  materialModels: any = [];
  allCasingTypes: any[] = [];
  constructor(private changeDetectorRef: ChangeDetectorRef,
    private wellInterval: WellIntervalService,
    private toastr: ToastrService,
    private fb: FormBuilder) {

  }//end of constructor


  isCellEditable(rowIndex: number, column: string): boolean {

    return (
      this.editableCell !== null &&
      this.editableCell.rowIndex === rowIndex &&
      this.editableCell.column === column
    );
  }

  onCellClick(rowIndex: number, column: string, row: any) {
    this.originalValueListHashMap[rowIndex] = { ...row };
    this.editableCell = { rowIndex, column };
    if (column == "MaterialName") {
      row.MaterialName = this.allMaterials.find(item => item.MaterialId === row.MaterialId);

    }
    if (column == "TypeName") {
      row.TypeName = this.allCasingTypes.find(item => item.WellIntervalTypeId === row.Type);
    }
    console.log(row)
    setTimeout(() => {
      if (this.inputRef)
        this.inputRef.nativeElement.focus();
    }, 0);
  }

  onBlur(rowIndex: number, column: string, row) {

    if (column == 'MeasuredDepth') {
      row.TrueVerticalDepth = row.MeasuredDepth;
      row.TVDSS = parseInt(row.MeasuredDepth) - this.kellyBushing;
      row.CourseLength = parseInt(row.MeasuredDepth) - (this.kellyBushing - this.groundLevel);
    }

    if (this.originalValueListHashMap[rowIndex][column] != row[column]) {
      row.isUpdated = true;
    }
    this.editableCell = null;
    console.log("updated", this.dataSource);
    this.getTableEvent.emit({ data: this.dataSource });
  }
  ngOnInit(): void {

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if (this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
    console.log(this.tableData)
    this.getWellIntervalMaterials();
    this.getCasingTypeColumn();

  }

  ngOnChanges() {

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if (this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
    this.kellyBushing = this.kellyBushing;
    this.groundLevel = this.groundLevel;
    this.setActionButtons();
    this.getTableEvent.emit({ data: this.dataSource });

    if (this.tableData.length !== 0) {
      this.tableData.forEach(ele => {
        if (ele?.['MaterialName']) {
          this.materialModels.push({ MaterialName: ele.MaterialName, MaterialId: ele.materialId })
        }
      })
    }

  }

  lithologyFormationsChange(rowIndex, column, rowData) {
    if (rowData.MaterialName?.MaterialName !== undefined) {
      let selectedLithology = rowData.MaterialName;
      rowData.MaterialId = selectedLithology?.MaterialId;
      rowData.MaterialName = selectedLithology?.MaterialName;
    }
    let selectedcasingType = rowData;
    if (selectedcasingType?.TypeName?.WellIntervalTypeId !== undefined) {
      rowData.Type = selectedcasingType?.TypeName?.WellIntervalTypeId;
      rowData.TypeName = selectedcasingType?.TypeName.Name;
    }

    console.log("lithology", rowData);
    if (this.originalValueListHashMap[rowIndex][column] != rowData[column]) {
      rowData.isUpdated = true;
    }
    else {
      rowData.isUpdated = false;
    }
    console.log(this.dataSource);
    this.editableCell = null;
    this.getTableEvent.emit({ data: this.dataSource });
  }

  lithologyPercentageChange(rowIndex, column, rowData) {

    this.editableCell = null;
    let selectedLithology = rowData;
    rowData.MaterialId = selectedLithology?.MaterialId;
    rowData.MaterialName = selectedLithology?.MaterialName;

    let selectedcasingType = rowData;
      rowData.Type = selectedcasingType?.TypeName?.WellIntervalTypeId;
      rowData.TypeName = selectedcasingType?.TypeName.Name;

    if (this.originalValueListHashMap[rowIndex][column] != rowData[column]) {
      rowData.isUpdated = true;
    }
    this.getTableEvent.emit({ data: this.dataSource });
  }

  cloneWellPathMethod(element) {

    console.log("cloned", element);
    this.actionEvent.emit({ 'action': "clone", 'data': element });
  }

  activateWellPath(element) {

    console.log("activated row");
    this.actionEvent.emit({ 'action': "activate", 'data': element });
  }

  viewSurveyPoints(element) {

    console.log("view survey points");
    this.actionEvent.emit({ 'action': "viewpoints", 'data': element });
  }

  deleteWellPath(element, i) {

    console.log("delete well path");
    this.actionEvent.emit({ 'action': "delete", 'data': element });
    //this.dataSource.splice(i,1);
    this.dataSource = [...this.dataSource];
    this.setActionButtons();
    this.getTableEvent.emit({ data: this.dataSource });
  }

  drop(event: CdkDragDrop<any[]>) {

    moveItemInArray(this.dataSource, this.draggedRowIndex, event.currentIndex);
    moveItemInArray(this.actionButtons, this.draggedRowIndex, event.currentIndex);
    this.getTableEvent.emit({ data: this.dataSource });
  }

  isRowDisabled(row: any): boolean {
    // Add your condition here based on the row value
    // For example, disable rows with a specific name
    return row.added === true;
  }

  onDragStarted(index: number) {

    this.draggedRowIndex = index;
  }

  setActionButtons() {
    if (this.dataSource?.length > 0) {
      this.actionButtons = this.dataSource.map((item: any) => {
        if (item.Active)
          return { Active: true, delete: false }
        else
          return { Active: false, delete: true }
      }
      );
    }
  }

  valueChangeEvent() {

    this.actionEvent.emit({});
  }

  getWellIntervalMaterials() {
    this.wellInterval.getMaterialsList().subscribe({
      next: (data) => {
        console.log(data);
        if (data.result.length !== 0) {
          this.allMaterials = [...data.result]
        }
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });
  }

  getCasingTypeColumn() {
    this.wellInterval.getCasingTypeColumn().subscribe({
      next: (data) => {
        console.log(data);
        if (data.result.length !== 0) {
          this.allCasingTypes = [...data.result]
        }
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });
  }


}
