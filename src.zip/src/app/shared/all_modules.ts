import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './material.module';
import { RouterModule } from '@angular/router';
import { TableComponent } from './table/table.component';
import { SurveyEditableTableComponent } from './survey-points-editable-table/survey-editable-table.component';
import { CommonModule } from '@angular/common';
import { NumericOnlyDirective } from '../core/directives/numeric-only.directive';
import { WellPathTableComponent } from './wellpath-table/wellpath-table.component';
import { TemperatureEditableTableComponent } from './temperature-editable-table/temperature-editable-table.component';
import { JobInfoEditableTableComponent } from './job-info-editable-table/job-info-editable-table.component';
import { WellUiTableComponent } from './well-ui-table/well-ui-table.component';
import { ProjectTableComponent } from './project-table/project-table.component';
import { ForamationsEditableTableComponent } from './formations-editable-table/formations-editable-table.component';
import { ModelComponent } from './model/model.component';
import { WorkStringTableComponent } from './work-string-table/work-string-table.component';
import { TortuosityEditableTableComponent } from './tortuosity-editable-table/tortuosity-editable-table.component';
// import { NgxTranslateModule } from '../translate/translate.module';
const Modules = [
  FormsModule,
  ReactiveFormsModule,
  MaterialModule,
  RouterModule,
  CommonModule,
  // NgxTranslateModule
]

const Declarations = [
  TableComponent,
  SurveyEditableTableComponent,
  NumericOnlyDirective,
  WellPathTableComponent,
  TemperatureEditableTableComponent,
  JobInfoEditableTableComponent,
  WellUiTableComponent,
  ProjectTableComponent,
  ForamationsEditableTableComponent,
  ModelComponent,
  WorkStringTableComponent,
  TortuosityEditableTableComponent
]

@NgModule({
  declarations: [...Declarations],
  imports: [...Modules],
  exports:[...Modules, ...Declarations]
})
export class AllModule { }
