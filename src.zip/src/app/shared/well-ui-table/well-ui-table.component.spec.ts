import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellUiTableComponent } from './well-ui-table.component';

describe('WellUiTableComponent', () => {
  let component: WellUiTableComponent;
  let fixture: ComponentFixture<WellUiTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WellUiTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WellUiTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
