import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Column } from 'src/app/core/interfaces/column.interface';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { element } from 'protractor';
import { LithilogiesService } from 'src/app/core/services/lithilogies.service';

@Component({
  selector: 'app-formations-editable-table',
  templateUrl: './formations-editable-table.component.html',
  styleUrls: ['./formations-editable-table.component.scss'],
})
export class ForamationsEditableTableComponent<T> implements OnInit,OnChanges{
  @Input() tableData: Array<T>=[];//to get table data
  @Input() tableColumns: Column[];//to get table columns
  @Input() actionColumn: boolean;//flag to show actions column
  @Input() cloneColumn: boolean;//flag to show clone button
  @Input() activateColumn: boolean;//flag to show activate button
  @Input() redirectColumn: boolean;//flag to show redirect button
  @Input() deleteColumn: boolean;//flag to show delete button
  @Input() kellyBushing;// KellyBushing value for calculation
  @Input() groundLevel;//GroundLevel value for calculation
  @Input() tableType;//formations table-->formations/percent dialog table-->percentage
  @Output()
  actionEvent = new EventEmitter<any>();
  @Output()
  getTableEvent = new EventEmitter<any>();
  @ViewChild('inputRef') inputRef!: ElementRef;

  actionButtons: any[] = [];
  dataSource :Array<any>=[] ;
  displayedColumns: Array<string> = [];
  editableCell: { rowIndex: number; column: string } | null = null;
  draggedRowIndex: number;
  originalValueListHashMap: any = [];
  lithologyList: any[];

  constructor(private changeDetectorRef: ChangeDetectorRef, private lithologyService:LithilogiesService){


  }//end of constructor

  isCellEditable(rowIndex: number, column: string): boolean {

    return (
      this.editableCell !== null &&
      this.editableCell.rowIndex === rowIndex &&
      this.editableCell.column === column
    );
  }

  onCellClick(rowIndex: number, column: string,row:any) {
    this.originalValueListHashMap[rowIndex] = {...row};
    this.editableCell = { rowIndex, column };
    if(column == "LithologyName"){
      row.LithologyName =  this.lithologyList.find(item=>item.LithologyId===row.Lithology);
    }
    setTimeout(() => {
      if(this.inputRef)
      this.inputRef.nativeElement.focus();
    }, 0);
  }

  onBlur(rowIndex: number, column: string,row) {
    if(column=='MeasuredDepth'){
      row.TVD = row.MeasuredDepth;
    }

    if(this.originalValueListHashMap[rowIndex][column]!=row[column]){
      row.isUpdated = true;
    }
    this.editableCell = null;
    console.log("updated",this.dataSource);
    this.getTableEvent.emit({data:this.dataSource});
  }
  ngOnInit(): void {
    this.getLithologyDropDownList();
    console.log("editable cell" , this.editableCell)
    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;




  }
  ngOnChanges(){

    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    if(this.actionColumn)
      this.displayedColumns.push("actions");
    this.dataSource = this.tableData;
    this.kellyBushing = this.kellyBushing;
    this.groundLevel = this.groundLevel;
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  }

  getLithologyDropDownList(){
    this.lithologyService.getLithologiesList().subscribe({
      next:(data)=>{
        this.lithologyList = [...data.result];
      }}
    );
  }
  cloneWellPathMethod(element){

    console.log("cloned",element);
    this.actionEvent.emit({'action':"clone",'data':element});
  }

  activateWellPath(element){

    console.log("activated row");
    this.actionEvent.emit({'action':"activate",'data':element});
  }

  viewSurveyPoints(element){

    console.log("view survey points");
    this.actionEvent.emit({'action':"viewpoints",'data':element});
  }

  deleteWellPath(element,i){

    console.log("delete well path");
    this.actionEvent.emit({'action':"delete",'data':element});
    //this.dataSource.splice(i,1);
    this.dataSource = [...this.dataSource];
    this.setActionButtons();
    this.getTableEvent.emit({data:this.dataSource});
  }

  drop(event: CdkDragDrop<any[]>) {

    moveItemInArray(this.dataSource,this.draggedRowIndex, event.currentIndex);
    moveItemInArray(this.actionButtons, this.draggedRowIndex, event.currentIndex);
    this.getTableEvent.emit({data:this.dataSource});
  }

  isRowDisabled(row: any): boolean {
    // Add your condition here based on the row value
    // For example, disable rows with a specific name
    return row.added === true;
  }

  onDragStarted(index: number) {
    this.draggedRowIndex = index;
  }

  setActionButtons(){
    if(this.dataSource?.length>0){
    this.actionButtons = this.dataSource.map((item:any)=>{
      if(item && item.active)
        return {active:true,delete:false}
      else
        return {active:false,delete:true}
      }
    );}
  }
  valueChangeEvent () {

    this.actionEvent.emit({});
  }
  showPercentagePopup(payload,rowIndex){

    this.actionEvent.emit({'action':"setConcentration",'data':payload,index:rowIndex});
  }

  lithologyFormationsChange(rowIndex, column,rowData){

    let selectedLithology = rowData;
    console.log("lithology",rowData);
    rowData.LithologyConcentration = 123/* [
      {Lithology:rowData.Lithology,Percentage:100}
    ] */;
    rowData.Lithology = selectedLithology.LithologyName.LithologyId;
    rowData.LithologyName = selectedLithology.LithologyName.LithologyName;
    if(this.originalValueListHashMap[rowIndex][column]!=rowData[column]){
      rowData.isUpdated = true;
    }
    else{
      rowData.isUpdated = false;
    }
    console.log(this.dataSource);
    this.editableCell = null;
    this.getTableEvent.emit({data:this.dataSource});
  }

  lithologyPercentageChange(rowIndex,column,rowData){

    this.editableCell = null;
    let selectedLithology = rowData;
    rowData.Lithology = selectedLithology.LithologyName.LithologyId;
    rowData.LithologyName = selectedLithology.LithologyName.LithologyName;
    if(this.originalValueListHashMap[rowIndex][column]!=rowData[column]){
      rowData.isUpdated = true;
    }
    this.getTableEvent.emit({data:this.dataSource});
  }
}
