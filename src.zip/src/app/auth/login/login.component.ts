// import { GlobalSharedService } from './../../core/services/globalShared.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { StorageService } from 'src/app/core/services/storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private route: Router, private auth:AuthService, private storage:StorageService) {
    this.storage.clear();
   }

  ngOnInit(): void {
    this.loginWithToken();
  }

  login() {
    this.route.navigate(['/dashboard/projects']);
  }

 async loginWithToken(){
    const loginobj = {};
    loginobj['email'] = "admin@birlasoft.com",
    loginobj['password'] = "Admin123@123"
    // service call of login api
  this.auth.useremaillogin(loginobj).subscribe({
     next: (data) => {
      this.storage.setToken(data.result[0].accessToken);
     },
     error: (error) => {
       console.log(error);
     }
   });
  }
}