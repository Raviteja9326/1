import { Component, HostListener, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { filelist, planslist, reportslist, setuplist } from 'src/app/core/interfaces/menulist.interface';
import { MenulistService } from 'src/app/core/services/menulist.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  filesmenu:any;

  constructor(private menu:MenulistService) {
    this.getsubcribemenus();
  }

  ngOnInit(): void {}

  getsubcribemenus(){
    this.menu.menuData.subscribe(res=>{
      this.filesmenu = res;
      console.log(this.filesmenu)
    })
  }
}
