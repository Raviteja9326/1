import { Component, OnInit } from '@angular/core';
import { filelist, planslist, realtimelist, reportslist, setuplist } from 'src/app/core/interfaces/menulist.interface';
import { AllinoneService } from 'src/app/core/services/allinone.service';
import { MenulistService } from 'src/app/core/services/menulist.service';
import { StorageService } from 'src/app/core/services/storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnInit {

  selectedNavItem: any = 'file';
  well: any;
  filesmenu: any = filelist;
  setupmenu: any = setuplist;
  planmenu: any = planslist;
  report: any = reportslist;
  realtimemenu:any = realtimelist;

  constructor(private resuable: AllinoneService, private menulist: MenulistService, private store: StorageService) {
    this.getMenutolocal();
  }

  ngOnInit(): void {
    this.resuable.reportsData.subscribe(res => {
      this.well = res?.WellName
    })
  }

  getMenutolocal() {
    if (this.store.getmenu() != null) {
      this.selectedNavItem = this.store.getmenu();
      this.sendMenutosidebar(this.selectedNavItem.Name)
      this.onNavItemClicked(this.selectedNavItem.Name.toLowerCase())
    }
    else {
      this.sendMenutosidebar(this.selectedNavItem)
      this.onNavItemClicked(this.selectedNavItem.toLowerCase())
    }
  }

  onNavItemClicked(item: string) {
    this.selectedNavItem = item;
    this.sendMenutosidebar(this.selectedNavItem)
  }

  sendMenutosidebar(res) {
    if (res.toLowerCase() === "file") {
      return this.menulist.getmenusdata(this.filesmenu);
    }
   else if (res.toLowerCase() === "setup") {
      return this.menulist.getmenusdata(this.setupmenu);
    }
  // else if (res.toLowerCase() ==='plan') {
  //   return this.menulist.getmenusdata(this.planmenu);
  //   }
    else if (res.toLowerCase() ==='realtime') {
      return this.menulist.getmenusdata(this.realtimemenu);
      }
  // else  if (res.toLowerCase() === 'reports') {
  //     return this.menulist.getmenusdata(this.report);
  //   }
  }
}
