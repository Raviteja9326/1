import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';


const routes: Routes = [
{path:'',component:HomeComponent, children:[
{path:'wells', data: {preload: false}, loadChildren:()=> import('../planning/wells/wells.module').then(m=>m.WellsModule)},
{path:'catalogs', data: {preload: false}, loadChildren:()=> import('../planning/catalogs/catalogs.module').then(m=>m.CatalogsModule)},
{path:'jobinfo', data: {preload: false}, loadChildren:()=> import('../planning/job-info/job-info.module').then(m=>m.JobInfoModule)},
{path:'projects', data: {preload: false}, loadChildren:()=> import('../planning/project/project.module').then(m=>m.ProjectModule)},
{path:'survey',data: {preload: false},loadChildren: () => import("../real-time/survey/survey.module").then(m => m.SurveyModule) },
{path:'flowchart',data: {preload: false},loadChildren: () => import("../real-time/flow-chart/flow-chart.module").then(m => m.FlowChartModule) },
{path:'realtime',data: {preload: false},loadChildren: () => import("../real-time/survey/survey.module").then(m => m.SurveyModule) },
{path:'workstring', data: {preload: false}, loadChildren:()=> import('../planning/workstring/workstring.module').then(m=>m.WorkstringModule)},
{path:'fluids', data: {preload: false}, loadChildren:()=> import('../planning/fluids/fluids.module').then(m=>m.FluidsModule)},
]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
