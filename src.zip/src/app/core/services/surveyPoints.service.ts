import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { retry, timeout } from "rxjs/operators";
import { HttpMethodService } from "./httpMethod.service";

@Injectable({
    providedIn:'root'
})

export class SurveyPointsService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Lithologies.
     */
    getSurveyPointsList(wellpath,trajectoryPath){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.getMethod(this.endPoint,api.getSurveyPointsApi+"/"+wellpath+"/"+trajectoryPath)
    }//end of getSurveyPointsList


    addSurveyPointsList(payload){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.postMethod(this.endPoint,api.addSurveyPointApi,payload);
    }

    updateSurveyPointsList(payload){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.putMethod(this.endPoint,api.updateSurveyPointApi,payload);
    }

    deleteSurveyPointsList(payload){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        let reqUrl = api.deleteSurveyPointApi;
        return this.httpMethod.postMethod(this.endPoint,reqUrl,payload);
    }
    /**
     * Below code will be removed later. It is just a temporary adjustment
     */

    loginApiCall() {

        return this.httpMethod.getMethod(this.endPoint,"/api/v1/login/verifyUser?email=admin@birlasoft.com&password=Admin123@123");


      }
}//end of class