import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { retry, timeout } from "rxjs/operators";
import { HttpMethodService } from "./httpMethod.service";


@Injectable({
    providedIn:'root'
})

export class JobInfoService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Lithologies.
     */
    getJobInfoList(jobInfoID){

        let jobInfoPersonnelEndpoint = api.getPersonnelJobInfoApi;
        jobInfoPersonnelEndpoint = jobInfoPersonnelEndpoint.replace("{jobInfoId}", jobInfoID);

        return this.httpMethod.getMethod(this.endPoint, jobInfoPersonnelEndpoint);
    }//end of getLithologiesList

    postJobInfoPersonnelList(data1:any, jobInfoID){

        let jobInfoPersonnelEndpoint = api.postPersonnelDetailsApi;
        jobInfoPersonnelEndpoint = jobInfoPersonnelEndpoint.replace("{jobInfoId}", jobInfoID);
        return this.httpMethod.postMethod( api.serviceEndpoint,jobInfoPersonnelEndpoint,data1)
    }

    saveGeneralJobInfo(data: any){
        console.log(data,"employye added")
        return this.httpMethod.postMethod(this.endPoint,api.postGenaralJobInfoApi,data)
    }

    /**
     * Below function will delete record.
     */
    deletePersonnelRecord (jobInfoId, PersonnelTimeSheetId) {

        let deleteEndpoint = api.deletePersonnelDetailsApi;
        deleteEndpoint = deleteEndpoint.replace(":id", PersonnelTimeSheetId);
        deleteEndpoint = deleteEndpoint.replace(":jobInfoId", jobInfoId);
        return this.httpMethod.deleteMethod(this.endPoint, deleteEndpoint);
    } //end of deleteTemperatureRecord function



      /* get wellpaths list */
      getProjectNameList() {

    return this.httpMethod.getMethod(this.endPoint, api.getProjectNameApi)

  }// end of function


}//end of class




