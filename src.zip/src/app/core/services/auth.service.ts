import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpClient) {}

  useremaillogin(data): Observable<any> {
    const headers = new HttpHeaders({
      'SkipInterceptor': 'true', // Skip the interceptor for login request
    });
    return this.http.get<any>(`${api.serviceEndpoint}${api.loginTokenApi}/verifyUser?email=${data.email}&password=${data.password}`,{ headers })
  }
}
