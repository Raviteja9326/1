import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root',
})
export class AllinoneService {

  public reportsData = new BehaviorSubject(undefined);

  constructor(private store:StorageService){}

  getWellData(list) {
    this.store.setWellName(list);
    return this.reportsData.next(list);
  }
}
