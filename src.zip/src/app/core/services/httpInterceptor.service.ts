import { Injectable } from "@angular/core";
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { StorageService } from "./storage.service";

@Injectable()
export class GlobalInterceptor implements HttpInterceptor {
  constructor(
    private userAuthService: StorageService,
    private router: Router,
    private toast: ToastrService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const skipInterceptor = req.headers.get('SkipInterceptor');

    if (skipInterceptor && skipInterceptor === 'true') {
      // Skip token inclusion for requests with SkipInterceptor flag set to true
      return next.handle(req);
    }

    const token = this.userAuthService.getToken();

    // Clone the request and set the token in headers
    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });

    return next.handle(authReq).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401 || error.status === 403) {
          this.toast.error('Access Denied');
          this.router.navigate(['/login']);
          sessionStorage.clear();
          this.userAuthService.clear();
        }
        return throwError(()=>error);
      })
    );
  }
}
