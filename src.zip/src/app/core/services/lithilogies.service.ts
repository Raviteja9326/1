import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { HttpMethodService } from "./httpMethod.service";


@Injectable({
    providedIn:'root'
})

export class LithilogiesService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Lithologies.
     */
    getLithologiesList(){

        return this.httpMethod.getMethod(this.endPoint,api.getLithologiesApi)
    }//end of getLithologiesList

}//end of class