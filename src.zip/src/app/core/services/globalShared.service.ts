import { Injectable } from "@angular/core";
// import { User } from '../models/User.model';


@Injectable({ providedIn: 'root' })
export class GlobalSharedService {

    loggedInUser: any;
    TOKEN_KEY: string = "jwtToken";
    USER: string = "user";
    USERSHOW: string = "mail";
    service:string = 'service';
    userName: string;
    userShow: string;
    currentURL: string = '';

    constructor() {

        this.currentURL = window.location.href;
        console.log("this.currentURL: " + this.currentURL);

        if (this.currentURL) {

          let urlSplitArray = this.currentURL.split("/");
          this.currentURL = urlSplitArray[2];
        } //end of if condition checking for the presence of url
    }

    getLoggedInUser() {

        let userDetailsPropertyName = this.currentURL + "_userDetails";

        // if (this.loggedInUser) {

        //     console.log("Logged in user details 1: " + JSON.stringify(this.loggedInUser));
        //     return this.loggedInUser;
        // } else if (localStorage.getItem(userDetailsPropertyName)) {

            this.setLoggedInUser(JSON.parse(localStorage.getItem(userDetailsPropertyName)));

            console.log("Logged in user details 2: " + JSON.stringify(this.loggedInUser));
            return this.loggedInUser;
        // } //end of if...else condtion checking for loggedInUser
    } //end of 'getLoggedInUser'

    getLoggedInUserName() {

        let userDetailsPropertyName = this.currentURL + "_userDetails";

        if (this.userName) {

            console.log("Logged in user details 1: " + JSON.stringify(this.userName));
            return this.userName;
        } else if (localStorage.getItem(userDetailsPropertyName)) {

            this.setLoggedInUserName(JSON.parse(localStorage.getItem(userDetailsPropertyName)));

            console.log("Logged in user details 2: " + JSON.stringify(this.userName));
            return this.userName;
        } //end of if...else condtion checking for loggedInUser
    } //end of 'getLoggedInUser'


    setLoggedInUser(user: any) {
        this.loggedInUser = user;
        let userDetailsPropertyName = this.currentURL + "_userDetails";
        sessionStorage.setItem(userDetailsPropertyName, JSON.stringify(user));
    } //end of 'setLoggedInUser'

    setLoggedInUserName(userName: string) {

        let userDetailsPropertyName = this.currentURL + "_userDetails";
        this.userName = userName;
        sessionStorage.setItem(userDetailsPropertyName, JSON.stringify(userName));
    } //end of 'setLoggedInUser'

    setLoggedInUserToShow(userShow: string) {

        this.userShow = userShow;
        let userDetailsPropertyName = this.currentURL + "_mail";
        sessionStorage.setItem(this.USERSHOW, JSON.stringify(userShow));
        localStorage.setItem(userDetailsPropertyName, JSON.stringify(userShow));
    } //end of 'setLoggedInUser'

    getLoggedInUserToShow() {

        let userDetailsPropertyName = this.currentURL + "_mail";
        let userNameParamName = this.currentURL + "_userDetails";
        let userDetails = localStorage.getItem(userNameParamName);
        let userDetailsJSON = userDetails ? JSON.parse(userDetails) : {};
        localStorage.setItem(userDetailsPropertyName, '"' + userDetailsJSON.userName + '"')
        console.log("getLoggedInUserToShow", localStorage.getItem(userDetailsPropertyName))

        if (this.userShow) {

            console.log("Logged in user details 1: " + JSON.stringify(this.userShow));
            return this.userShow;
        } else if (localStorage.getItem(userDetailsPropertyName)) {

            // console.log("localStorage: " + JSON.stringify(localStorage));
            this.setLoggedInUserToShow(JSON.parse(localStorage.getItem(userDetailsPropertyName)));

            console.log("Logged in user details 2: " + JSON.stringify(this.userShow));
            return this.userShow;
        }
    }

    getJwtToken() {

        return (sessionStorage.getItem(this.currentURL + "_JWTToken"));
    } //end of 'getJwtToken'


    setJwtToken(token) {

        console.log("Set jwt token function called." + token);
        if (token)
            sessionStorage.setItem(this.currentURL + "_JWTToken", "" + token);
    } //end of 'setJwtToken'


    removeUser() {

        let userDetailsPropertyName = this.currentURL + "_userDetails";
        sessionStorage.removeItem(this.USER);
        localStorage.removeItem(userDetailsPropertyName);
    } //end of 'removeUser'


    removeJwtToken() {

        sessionStorage.removeItem(this.TOKEN_KEY);
    } //end of 'removeJwtToken'


    isAdminRoleVisible() {

        return (this.loggedInUser.usertypename == "ADMIN");
    } //end of 'isAdminRoleVisible'
}
