import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class ConnectionService {

  endPoint: string;
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

     this.endPoint = `${api.serviceEndpoint}`;
  }

//Function to fetch connection list
  getConnectionList() {

    return this.httpMethod.getMethod(this.endPoint,api.getConnectionsApi)
  }
}
