import { Injectable } from "@angular/core";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { retry, timeout } from "rxjs/operators";
@Injectable({
  providedIn: 'root'
})
export class HttpMethodService {

  constructor(private httpService: HttpClient) {}

  /**
   *
   * This function will call GET APIs.
   */
  getMethod(endpoint, apiConstant) {
    return this.httpService.get<any>(endpoint + apiConstant).pipe(timeout(60000), retry(1))
  }//end of getMethod


  /**
   *
   * This function will call POST APIs.
   */
  postMethod(endpoint, apiConstant, payload) {
    return this.httpService.post<any>(endpoint + apiConstant, payload).pipe(timeout(60000))
  }//end of postMethod


  /**
   *
   * This function will call PUT APIs.
   */
  putMethod(endpoint, apiConstant, payload?) {
    return this.httpService.put<any>(endpoint + apiConstant, payload).pipe(timeout(60000), retry(1))
  }//end of putMethod


  /**
   *
   * This function will call DELETE APIs.
   */
  deleteMethod(endpoint, apiConstant) {
    return this.httpService.delete<any>(endpoint + apiConstant).pipe(timeout(60000), retry(1))
  }//end of putMethod


}//end of class