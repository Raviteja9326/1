import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class MenulistService {

  public menuData = new BehaviorSubject<any>('');
  constructor(private store:StorageService) {}

  getmenusdata(data) {
    console.log(data)
   this.store.menu(data);
   return this.menuData.next(data)
  }
}
