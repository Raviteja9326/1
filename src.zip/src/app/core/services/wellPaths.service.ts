/*This is well paths service, to write functions for API call of materials catalog
*/
import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
@Injectable({
  providedIn: 'root'
})
export class WellPathsService {
  endPoint: string;
  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends


 
  /* get wellpaths list */
  getWellPathsList() {

    return this.httpMethod.getMethod(this.endPoint, api.getWellPathsApi)

  }// end of function

  // /* add wellpaths list */
  // postWellPathsList(data) {

  //   return this.http.post("v1/wellPath/", data)

  // }// end of function

  /* add wellpaths */
  addWellPathsList(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.addWellPathsApi, payload)

  }// end of function

  /* activate wellpaths */
  activateWellpathsList(statusHeaderId: number, payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateWellPathsApi + `${statusHeaderId}/status`, payload);
  }// end of function

  /* update wellpaths */
  updateWellpathsList(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateWellPathsApi, payload);
  }// end of function

  /* delete wellpaths */
  deleteWellpathsList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteWellPathApi,payload);
  }// end of function

}