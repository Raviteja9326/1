/**
 * This file helps to create interface for Project data types.
 */

export interface Project {
    ProjectId?:number;
    ProjectName?: string;
    Baseonwell?: string;
    WellName?: string;
    Lease?: string;
    Field?: string;
    UniqueWellID?: string;
    WellLicense?: string;
    APINumber?: string;
    RigName?: string;
    OperatingCompany?: string;
    RigContractor?: string;
    JobType?: string;
    Country?: string;
    Region?: string;
    GeoLatitude?: string;
    GeoLongitude?: string;
    TimeZoneId?: string;
    SpudDate?: string;
  }
