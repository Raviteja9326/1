/**
 * This file helps to create interface for Well Path type.
 */

export interface WellPath {

  AutoImport?: boolean,
  WitsmlChannelKey?: string,
  TrajectoryUid?: string,
  AutoImportFrequencyInMinutes?: number,
  MdUnit?: number,
  AzimuthUnit?: number,
  InclinationUnit?: number,
  Active?: boolean,
  Key?: string,
  PlanedSurveyCollectionId?: number,
  SurveyCollectionId?: number,
  WellPathCollectionId?: number,
  TieOnPoint?: number,
  Name?: string;
  isAdded?: boolean;
  isUpdated?: boolean;
}
