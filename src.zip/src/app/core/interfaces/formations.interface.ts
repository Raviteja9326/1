/**
 * This file helps to create interface for Formations type.
 */

export interface Formations {
    Lithology:string;
    FormationName: string;
    Porosity:number;
    Permeability:number;
    MeasuredDepth:number;
    TVD:number;
    PorePressureGradient:number;
    WellBoreStabilityGradient:number;
    FormationIntegrityTest:number;
    FracturePressureGradient:number;
    LeakOffTest:number;
    MinHorizontalStress:number;
    MaxHorizontalStress:number;
    DirectionMinHorizontalStress:number;
    UCS:number;
    MSE:number;
    Order:number;
    Description:string;
    isAdded:boolean;
    isUpdated:boolean;
    LithologyConcentration:any;
    FormationHeaderId?:number;
    FormationId?:number;
    FormationsSourceType: number;
  }
