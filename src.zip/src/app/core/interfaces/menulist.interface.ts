export const filelist = {
    Name :'File',
    file: [
        { menuName: 'Projects', menuImg: 'layers.png', menuPath: '/dashboard/projects', isActive:'1' }
    ],
};

export const setuplist = {
    Name :'Setup',
    file: [
        { menuName: 'Jobs Info', menuImg: 'info.png', menuPath: '/dashboard/jobinfo/jobinformation',isActive:'1', submenu:[
            { submenuName: 'General', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Personnel', menuImg: '', menuPath: '',isActive:'1'}
        ]},
        { menuName: 'Surface Equipment', menuImg: 'milling-machine.png', menuPath: '',isActive:'0' },
        { menuName: 'Wells', menuImg: 'oil-well.png', menuPath: '/dashboard/wells',isActive:'1', submenu:[
            { submenuName: 'Well Paths', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Well Intervals', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Temperature', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Formations', menuImg: '', menuPath: '',isActive:'1'},
        ] },
        { menuName: 'Fluids', menuImg: 'water-drop.png', menuPath: '/dashboard/fluids',isActive:'1' },
        { menuName: 'Work String', menuImg:'string.png', menuPath: '/dashboard/workstring',isActive:'1' },
        { menuName: 'Catalogs', menuImg: 'catalogue.png', menuPath: '/dashboard/catalogs',isActive:'1', submenu:[
            { submenuName: 'Materials', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Lithologies', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Connections', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Custom Connections', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Centeralizers', menuImg: '', menuPath: '',isActive:'1'},
            { submenuName: 'Custom Tools', menuImg: '', menuPath: '',isActive:'1'},
        ] },
        { menuName: 'Units', menuImg: 'cost.png', menuPath: '',isActive:'0' },
        { menuName: 'System Preferences', menuImg: 'window.png', menuPath: '',isActive:'0' },
    ],
};

export const realtimelist = {
    Name :'realtime',
    file: [
        { menuName: 'Survey', menuImg: 'New_Project.png', menuPath: '/dashboard/survey', isActive:'1' },
        { menuName: 'Flowchart', menuImg: 'New_Project.png', menuPath: '/dashboard/flowchart', isActive:'1' }
    ],
};

export const planslist = {
    Name :'Plans',
    file: []
};


export const reportslist = {
    Name :'Reports',
    file: []
};