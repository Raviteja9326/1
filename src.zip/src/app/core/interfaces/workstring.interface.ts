/**
 * This file helps to create interface for Project data types.
 */

export interface Workstring {

}