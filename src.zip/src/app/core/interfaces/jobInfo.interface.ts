export class jobInfo{

        Name : string;
        EmployeeNumber: string;
        PersonnelRole: number;
        PersonnelRoleName: string;
        PersonnelTimeSheetId : number;
        DateIn: Date;
        DateOut: Date;
        isNewlyAdded:boolean;
        isDeleted:boolean;
        isUpdated:boolean;

        constructor() {
                this.Name = null;
                this.EmployeeNumber = null;
                this.PersonnelRole = 0;
                this.PersonnelTimeSheetId = 0;
                this.PersonnelRoleName = "";
                this.isNewlyAdded = false;
                this.isDeleted = false;
                this.isUpdated = false;
        }
}