/**
 * This file helps to create interface for Column type.
 */

export interface Column {
  columnDef: string; 
  header: string; 
  cell?: Function; 
  isLink?: boolean;
  url?: string;
  sticky?:boolean;
  editable?:boolean;
  inputType?:string;
}