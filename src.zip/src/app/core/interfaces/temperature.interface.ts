/**
 * This interface is used in temperature component.
 */

export class temperature {
    
    localRecordId: number;
    TrueVerticalDepth: number;
    Temperature: number;
    GeothermalGradient: number;
    TemperatureHeaderId: number;
    TemperatureConfigurationId : number;
    isNewlyAdded: boolean;
    isUpdated: boolean;
    isDeleted: boolean;

    constructor () {
        this.localRecordId = 0;
        this.TrueVerticalDepth = 0;
        this.Temperature= 0;
        this.GeothermalGradient= 0;
        this.TemperatureHeaderId= 1;
        this.TemperatureConfigurationId = 0;
        this.isNewlyAdded= false;
        this.isUpdated= false;
        this.isDeleted = false;
    } //end of constructor
} //end of temperature interface class