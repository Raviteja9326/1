export interface Tortuosity {
  "StartingMD":number,
  "EndingMD":number
  "InterpolationStep":number,
  "TortuosityMethod":number,
  "Amplitude":number,
  "Period":number,
  "Phase":number,
  "Shift":number ;
  "RetainOriginalPoints":number;
  "SurveyHeaderId":number,
  "isAdded":boolean;
  "isUpdated":boolean;
  

 }