/**
 * This file will hold the details of all the timezone.
 */

export enum Timezone {

    "US & Canada" = 1,

}