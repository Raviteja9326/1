export class GlobalConstants {

    appVersion: string = "v1.0";
} //end of 'GlobalConstants' class