//  ALLOWS
//  A-Z,a-z
//  0-9

import { FormControl } from '@angular/forms';

//  [!@#$%^&\*-/_.]
export const TEXT_REGEX_1 = '^[a-zA-Z0-9!@#$%^&*\\-/_.]+$';
//  ALLOWS
//  A-Z,a-z
//  0-9
//  [.-_]
export const TEXT_REGEX_2 = '^[A-Za-z0-9._-]+$';
//  ALLOWS
//  A-Z,a-z
//  0-9
//  [.-_]
// SPACE
export const TEXT_REGEX_3 = '^[A-Za-z0-9._ -]+$';
//  ALLOWS
//  A-Z,a-z
//  0-9
//  [!@#$%^&\*-/_.]
//space
export const TEXT_REGEX_4 = '^[a-zA-Z0-9!@#$%^)(&*\\-/_ .]+$';
export const TEXT_REGEX_5 = '^[a-zA-Z0-9!@#$%^)(&*\\-/_.]+$';
//Email
export const emailRegex =
  '^[a-zA-Z0-9._%+-]+@(?!.*.com.*.com)([a-zA-Z0-9-]+.)+[a-zA-Z]{2,}$';

//IP ADDRESS
export const IP_REGEX =
  '^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?).){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$';
// DOMAIN ADDRESS
export const DOMAIN_REGEX =
  '^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?.)+[a-zA-Z]{2,}$';
//
export const validateHostAddress = (c: FormControl) => {
  console.log('sdsd', c.value);
  if (c.value == null) return null;
  return c.value.match(DOMAIN_REGEX) || c.value.match(IP_REGEX)
    ? null
    : { pattern: true };
};
