import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MudRoutingModule } from './mud-routing.module';
import { MudComponent } from './mud.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    MudComponent
  ],
  imports: [
    CommonModule,
    MudRoutingModule,
    AllModule
  ]
})
export class MudModule { }
