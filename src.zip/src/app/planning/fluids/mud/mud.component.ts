import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mud',
  templateUrl: './mud.component.html',
  styleUrls: ['./mud.component.scss']
})
export class MudComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
