import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-underbalanced',
  templateUrl: './underbalanced.component.html',
  styleUrls: ['./underbalanced.component.scss']
})
export class UnderbalancedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
