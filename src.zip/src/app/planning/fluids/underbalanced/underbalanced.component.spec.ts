import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderbalancedComponent } from './underbalanced.component';

describe('UnderbalancedComponent', () => {
  let component: UnderbalancedComponent;
  let fixture: ComponentFixture<UnderbalancedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnderbalancedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UnderbalancedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
