import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UnderbalancedComponent } from './underbalanced.component';

const routes: Routes = [
  {path: '', component: UnderbalancedComponent,children:[]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UnderbalancedRoutingModule { }
