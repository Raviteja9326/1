import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UnderbalancedRoutingModule } from './underbalanced-routing.module';
import { UnderbalancedComponent } from './underbalanced.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    UnderbalancedComponent
  ],
  imports: [
    CommonModule,
    UnderbalancedRoutingModule,
    AllModule
  ]
})
export class UnderbalancedModule { }
