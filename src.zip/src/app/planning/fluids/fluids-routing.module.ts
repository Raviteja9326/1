import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FluidsComponent } from './fluids.component';

const routes: Routes = [{
  path: '', component: FluidsComponent, children: [
    { path: "mud",data: { preload: false }, loadChildren: () => import("./mud/mud.module").then(m => m.MudModule)},
    { path: 'cement',data: { preload: false }, loadChildren: () => import("./cement/cement.module").then(m => m.CementModule)},
    { path: 'underbalanced',data: { preload: false }, loadChildren: () => import("./underbalanced/underbalanced.module").then(m => m.UnderbalancedModule) }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FluidsRoutingModule { }
