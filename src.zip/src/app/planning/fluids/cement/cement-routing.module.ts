import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CementComponent } from './cement.component';

const routes: Routes = [
  {path: '', component: CementComponent,children:[]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CementRoutingModule { }
