import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CementRoutingModule } from './cement-routing.module';
import { CementComponent } from './cement.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    CementComponent
  ],
  imports: [
    CommonModule,
    CementRoutingModule,
    AllModule
  ]
})
export class CementModule { }
