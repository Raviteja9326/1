import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fluids',
  templateUrl: './fluids.component.html',
  styleUrls: ['./fluids.component.scss']
})
export class FluidsComponent implements OnInit {

  isLinear: boolean = false;

  constructor(private route: Router) { }

  ngOnInit(): void {
    this.onStepClick({selectedIndex:0})
  }

  onStepClick(event) {
    if (event.selectedIndex == 0) {
      this.route.navigate(['/dashboard/fluids/mud']);
    }
    else if (event.selectedIndex == 1) {
      this.route.navigate(['/dashboard/fluids/cement']);
    }
    else if (event.selectedIndex == 2) {
      this.route.navigate(['/dashboard/fluids/underbalanced']);
    }
  }

}
