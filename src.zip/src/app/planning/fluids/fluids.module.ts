import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FluidsRoutingModule } from './fluids-routing.module';
import { FluidsComponent } from './fluids.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    FluidsComponent
  ],
  imports: [
    CommonModule,
    FluidsRoutingModule,
    AllModule
  ]
})
export class FluidsModule { }
