import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WellsRoutingModule } from './wells-routing.module';
import { WellsComponent } from './wells.component';
import { AllModule } from '../../shared/all_modules';



@NgModule({
  declarations: [
    WellsComponent
  ],
  imports: [
    CommonModule,
    WellsRoutingModule,
    AllModule
  ]
})
export class WellsModule { }
