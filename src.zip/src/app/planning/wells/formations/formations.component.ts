import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { lastValueFrom } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { PercentageDialogComponent } from './percentage-dialog/percentage-dialog.component';
import { Formations } from 'src/app/core/interfaces/formations.interface';
import { FormationsService } from 'src/app/core/services/formations.service';


@Component({
  selector: 'app-formations',
  templateUrl: './formations.component.html',
  styleUrls: ['./formations.component.scss']
})
export class FormationsComponent implements OnInit {
  loading:boolean = false;
  loadMessage:string = ""
  sourceTypeModel: any ;
  sourceTypeList: any[] = [];
  tableData: Formations[]

  tableColumns = [
    { columnDef: "LithologyName", header: "Lithology", editable:true, inputType:'dropdown', cell: (element: Record<string, any>) => `${element['LithologyName']}` },
    { columnDef: "FormationName", header: "Name", editable:true, inputType:'text', cell: (element: Record<string, any>) => `${element['FormationName']}` },
    { columnDef: "Porosity", header: "Porosity", editable:true, inputType:'number', cell: (element: Record<string, any>) => `${element['Porosity']}` },
    { columnDef: "Permeability", header: "Permeability<br/> (mD)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['Permeability']}` },
    { columnDef: "MeasuredDepth", header: "MD<br/> (ft)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['MeasuredDepth']}` },
    { columnDef: "TVD", header: "TVD<br/> (ft)", inputType:'number', cell: (element: Record<string, any>) => `${element['TVD']}` },
    { columnDef: "PorePressureGradient", header: "PPG<br/> (ppg)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['PorePressureGradient']}` },
    { columnDef: "WellBoreStabilityGradient", header: "WBSG<br/> (ppg)", editable:true, inputType:'number', cell: (element: Record<string, any>) => `${element['WellBoreStabilityGradient']}` },
    { columnDef: "FormationIntegrityTest", header: "FIT<br/> (ppg)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['FormationIntegrityTest']}` },
    { columnDef: "FracturePressureGradient", header: "FPG<br/> (ppg)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['FracturePressureGradient']}` },
    { columnDef: "LeakOffTest", header: "LOT<br/> (ppg)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['LeakOffTest']}` },
    { columnDef: "MinHorizontalStress", header: "MinHS<br/> (ppg)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['MinHorizontalStress']}` },
    { columnDef: "MaxHorizontalStress", header: "MaxHS<br/> (ppg)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['MaxHorizontalStress']}` },
    { columnDef: "DirectionMinHorizontalStress", header: "DMaxHS<br/> (°)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['DirectionMinHorizontalStress']}` },
    { columnDef: "UCS", header: "UCS<br/> (psi)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['UCS']}` },
    { columnDef: "MSE", header: "MSE<br/>(psi)", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['MSE']}` },
    { columnDef: "Description", header: "Description", editable:true,  inputType:'text', cell: (element: Record<string, any>) => `${element['Description']}` },
  ]
  originalData: any;
  isChanged: boolean;
  kellyBushing: number = 0;
  groundLevel: number = 0;
  currentData: any=[];
  deleteList: any = [];

  constructor(private formationsService: FormationsService, private toastr: ToastrService
    ,private route: Router, private dialog: MatDialog){


  }//end of cnstructor


  ngOnInit(): void {
    this.getSourceTypesList();
   
  }

  addRow() {

    /**
     * called after clicking on add button
     */
    console.log("added row");
    let formationsObj : Formations ={
      Lithology:"",
      FormationName: "",
      Porosity:0,
      Permeability:0,
      MeasuredDepth:0,
      TVD:0,
      PorePressureGradient:0,
      WellBoreStabilityGradient:0,
      FormationIntegrityTest:0,
      FracturePressureGradient:0,
      LeakOffTest:0,
      MinHorizontalStress:0,
      MaxHorizontalStress:0,
      DirectionMinHorizontalStress:0,
      UCS:0,
      MSE:0,
      isAdded:true,
      isUpdated:false,
      LithologyConcentration:[],
      Order:123,
      Description:"",
      FormationsSourceType:this.sourceTypeModel
    };
    this.tableData.push(formationsObj);
    this.tableData = [...this.tableData];
  }//end of function



  save() {
    this.loading = true;
    let updatedData = _.filter(this.currentData,(item)=> {
            return item.isUpdated && !(_.has(item,'isAdded'))
     });
    updatedData = _.map(updatedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded','isUpdated','TVD','LithologyName']);
    });


    let addedData = _.filter(this.currentData, { isAdded: true });
    addedData = _.map(addedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded','isUpdated','TVD','LithologyName']);
    });

    console.log("save", updatedData,addedData);
    if(updatedData.length>0 || addedData.length>0 || this.deleteList.length>0){
      this.saveAPIcall(updatedData,addedData)
    }
    else{
      this.getFormationsList(this.sourceTypeModel);
    }

  }

  async saveAPIcall(updatedData,addedData){

    /**
     * this method calls the save sformations api
     * First call will be update/save, second call will be delete
     * This Function is a combination of two APIs
     */

    /**
     * Synchronous calls for save
     */
    let savePayload = {
      "addFormations":[...addedData],
      "updateFormations":[...updatedData]
    }


    this.saveFormations(savePayload)
    .then(async (data)=>{
      console.log("call delete",data);
      if(this.deleteList.length>0){
        let list = this.deleteList.map((item)=>{
          return item.FormationId;
        });
        return this.deleteFormations(list);
      }
    })
    .then((data)=>{
      console.log("delete completed",data);
      this.deleteList = [];
      this.getFormationsList(this.sourceTypeModel);
      this.toastr.success("Formations Saved Successfully");
    })


  }

  async saveFormations(savePayload){
    let data;
    if(savePayload.addFormations.length>0 || savePayload.updateFormations.length>0){
      try{
      data = lastValueFrom(await this.formationsService.saveFormationsList(savePayload));
      }
     catch(error){
      data = error;
      this.toastr.error("Something went wrong during save");
     }
    }
    return data;
  }



  reset() {
    this.loading = true;
    this.getFormationsList(this.sourceTypeModel);
  }//end of function

  getTableData(event){

    /**
     * emitter event call to check updated data in table
     */
    console.log(event)
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function

  checkChanges(data){

    /**
     * this function compares original data and changes made in
     * table
     */
    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged",isDataChanged, data);
    this.currentData = data;
    setTimeout(()=>{
      this.isChanged = isDataChanged;
    });

    return isDataChanged;
  }//end of function

  getFormationsList(sourceType){

    /**
     * This service will get all foramations
     */

    this.formationsService.getFormationsList(sourceType).subscribe({
      next:(data)=>{

          console.log("formations list",data);
          this.tableData = data.result.data.map(item=>{return {...item, TVD:item.MeasuredDepth}});
          this.originalData = JSON.parse(JSON.stringify(this.tableData));
          this.deleteList = [];
      },
      error:(error)=>{
        this.loading = false;
        this.toastr.error("Something went wrong");
      }
    });//end of service call
  }//end of function

  operateAction(eve){

    let operation = eve.action;
    let payload = eve.data;
    switch(operation){
      case 'delete': this.deleteMethod(payload);break;
      case 'setConcentration' : this.showConcentrationPopup(payload,eve.index);break;//to show percentage popup
    }
  }//end of function

  deleteMethod(payload){
    this.loading = true;
    let index = this.tableData.indexOf(payload);
    if(index>-1){
      this.tableData.splice(index,1);
      this.tableData = [...this.tableData];
      if(!payload.isAdded){
        this.deleteList.push(payload);
      }
    }


  }//end of function

   async deleteFormations(list){
    let data;
    let reqObj = {
      "deletedIds" : list
    };
    try{
    data = await lastValueFrom(this.formationsService.deleteFormationsList(reqObj));
    }
    catch(error){
    console.log("error in delete",error);
    this.toastr.error("Something went wrong during delete");
    data = error;
    }
    return data
  }
  getSourceTypesList() {
  
    
    //call API to get source types above list is hardcoded for now
    this.formationsService.getFormationsSourceTypeList().subscribe({
      next:(data)=>{
       
        this.sourceTypeList = data.result.map((item)=>{
          return {label:item.Name,value:item.FormationSourceTypeId};
        });
        this.sourceTypeModel = 2;
        this.getFormationsList(this.sourceTypeModel);
      }
    });

  }// function ends

  showConcentrationPopup(payload,index){
    let originalPayload = JSON.parse(JSON.stringify(payload));
    const dialogRef = this.dialog.open(PercentageDialogComponent, {
      width: '400px', // Specify the width of the dialog box
      data:payload
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.action === 'save') {
          console.log('User clicked the save button.');
          console.log('Additional data from dialog:', result);
          /**
           * below code is commented because dialog box data is not sent to api
           */
          this.tableData[index].LithologyConcentration = originalPayload.LithologyConcentration;
          // this.tableData[index].LithologyConcentration = result.data;
          this.tableData[index].isUpdated = true;
          this.tableData = [...this.tableData];
        }
      }
      else {
        console.log('Dialog was closed without any action.');
        this.tableData[index].LithologyConcentration = originalPayload.LithologyConcentration;
        this.tableData = [...this.tableData];
      }
    });
  }
}