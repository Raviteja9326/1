import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllModule } from 'src/app/shared/all_modules';
import { HttpClientModule } from '@angular/common/http';
import { FormationsComponent } from './formations.component';
import { FormationsRoutingModule } from './formations-routing.module';
import { PercentageDialogComponent } from './percentage-dialog/percentage-dialog.component';

@NgModule({
  declarations: [
    FormationsComponent,
    PercentageDialogComponent
  ],
  imports: [
    CommonModule,
    AllModule,
    FormationsRoutingModule,
    HttpClientModule
  ]
})

export class FormationsModule {

}