import { Component, Inject, OnInit} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Column } from 'src/app/core/interfaces/column.interface';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-dialog-content',
  templateUrl: './percentage-dialog.component.html',
  styleUrls:['./percentage-dialog.component.scss']
})
export class PercentageDialogComponent implements OnInit {
  tableData: any =[];
  tableColumns: Column[];
  currentTableData: any = [];
  originalTableData: any[];
    constructor(
        private toastr: ToastrService,
        public dialogRef: MatDialogRef<PercentageDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
      ) {
        if(Array.isArray(data.LithologyConcentration))
          this.tableData = data.LithologyConcentration;
        else{
            this.tableData = [{Lithology:data.Lithology,LithologyName:data.LithologyName,Percentage:100}]
        }
        this.originalTableData = JSON.parse(JSON.stringify(this.tableData));
      }

      ngOnInit(): void {
        this.tableColumns = [
            { columnDef: "LithologyName", header: "Lithology", editable:true, inputType:'dropdown', cell: (element: Record<string, any>) => `${element['LithologyName']}` },
            { columnDef: "Percentage", header: "Percentage", editable:true, inputType:'number', cell: (element: Record<string, any>) => `${element['Percentage']}` },
        ];



      }

      getTableData(event){

        /**
         * emitter event call to check updated data in table
         */
        console.log(event)
        this.currentTableData = event.data;
      }//end of function

       addRow(){
        let percentObj = {
          "LithologyName":"",
          "Percentage":0,
          "Lithology":"",
        }
        this.tableData.push(percentObj);
        this.tableData = [...this.tableData];
      }

      save(action: string): void {

        let sumTotal = 0;
        this.currentTableData.forEach((lithology)=>{
          sumTotal = sumTotal+lithology.Percentage;
        });

        if( !isNaN(sumTotal) && sumTotal<=100){

          // Pass data to the parent component based on the button clicked
          this.originalTableData = JSON.parse(JSON.stringify(this.currentTableData));
          this.dialogRef.close({
            action: action,
            data:this.currentTableData
          });
        }
        else{
          this.toastr.error("Total Percentage cannot be greater than 100");
          console.log("check not 100",this.originalTableData);
          this.tableData = [...this.originalTableData];
        }
      }

      operateAction(eve){

        let operation = eve.action;
        let payload = eve.data;
        switch(operation){
          case 'delete': this.deleteMethod(payload);break;
        }
      }//end of function

      deleteMethod(payload){
        let index = this.tableData.indexOf(payload);
        if(index>-1){
          this.tableData.splice(index,1);
          this.tableData = [...this.tableData];
        }
      }//end of function

      onCloseClick(action){
        this.dialogRef.close({
          action: action,
          data:this.currentTableData
        });
      }
}
