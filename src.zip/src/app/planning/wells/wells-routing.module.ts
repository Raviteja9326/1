import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WellsComponent } from './wells.component';

const routes: Routes = [{
  path: '', component: WellsComponent, children: [
    { path: "temperature",data: { preload: false }, loadChildren: () => import("./temperature/temperature.module").then(m => m.TemperatureModule)},
    { path: 'well-paths',data: { preload: false }, loadChildren: () => import("./well-paths/well-paths.module").then(m => m.WellPathsModule)},
    { path: 'well-intervals',data: { preload: false }, loadChildren: () => import("./well-intervals/well-intervals.module").then(m => m.WellIntervalsModule) },
    { path: "formations",data: { preload: false }, loadChildren: () => import("./formations/formations.module").then(m => m.FormationsModule)},
  ]
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WellsRoutingModule { }
