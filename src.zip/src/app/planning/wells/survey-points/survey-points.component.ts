import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SurveyPoint } from 'src/app/core/interfaces/surveyPoint.interface';
import { SurveyPointsService } from 'src/app/core/services/surveyPoints.service';
import * as _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { lastValueFrom } from 'rxjs';
// import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { InspectionChartsComponent } from '../inspection-charts/inspection-charts.component';
import { WellPathsService } from 'src/app/core/services/wellPaths.service';
import { element } from 'protractor';
import { TortuosityModalComponent } from '../tortuosity-modal/tortuosity-modal.component';

@Component({
  selector: 'app-survey-points',
  templateUrl: './survey-points.component.html',
  styleUrls: ['./survey-points.component.scss']
})
export class SurveyPointsComponent implements OnInit {
  loading: boolean = false;
  loadMessage: string = ""
  trajectoryPathModel: any ;
  wellPathModel: any;
  wellpathList: any[] = [];
  trajectoryList: any[] = [
    { label: "Trajectory", value: 4 },
    { label: "Survey Points", value: 2 }
  ]
  tableData: SurveyPoint[]

  tableColumns = [
    { columnDef: "MeasuredDepth", header: "MD <br/>(ft)", editable: true, inputType: 'number', cell: (element: Record<string, any>) => `${element['MeasuredDepth']}` },
    { columnDef: "Inclination", header: "Inclination <br/> (°)", editable: true, inputType: 'number', cell: (element: Record<string, any>) => `${element['Inclination']}` },
    { columnDef: "Azimuth", header: "Azimuth <br/> (°)", editable: true, inputType: 'number', cell: (element: Record<string, any>) => `${element['Azimuth']}` },
    { columnDef: "TrueVerticalDepth", header: "TVD<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['TrueVerticalDepth']}` },
    { columnDef: "TVDSS", header: "TVDSS<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['TVDSS']}` },
    { columnDef: "NorthSouth", header: "North<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['NorthSouth']}` },
    { columnDef: "EastWest", header: "East<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['EastWest']}` },
    { columnDef: "LateralDistance", header: "L. Distance<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['LateralDistance']}` },
    { columnDef: "DogLegSeverity", header: "DLS<br/> (*/100ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['DogLegSeverity']}` },
    { columnDef: "BuildRate", header: "B. Rate<br/> (*/100f)t", inputType: 'number', cell: (element: Record<string, any>) => `${element['BuildRate']}` },
    { columnDef: "TurnRate", header: "T. Rate<br/> (*/100ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['TurnRate']}` },
    { columnDef: "ToolFace", header: "T. Face<br/> (°)", inputType: 'number', cell: (element: Record<string, any>) => `${element['ToolFace']}` },
    { columnDef: "VSec", header: "VS<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['VSec']}` },
    { columnDef: "HDisp", header: "H. Disp<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['HDisp']}` },
    { columnDef: "CourseLength", header: "CL<br/> (ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['CourseLength']}` },
    { columnDef: "Tortuosity", header: "Tort<br/>(°)", inputType: 'number', cell: (element: Record<string, any>) => `${element['Tortuosity']}` },
    { columnDef: "ABSTortuosity", header: "ABSTort<br/> (*/100ft)", inputType: 'number', cell: (element: Record<string, any>) => `${element['ABSTortuosity']}` },
    { columnDef: "DDI", header: "DDI", inputType: 'number', cell: (element: Record<string, any>) => `${element['DDI']}` },
  ]
  originalData: any;
  isChanged: boolean;
  kellyBushing: number = 0;
  groundLevel: number = 0;
  currentData: any=[];
  deleteList: any = [];

  constructor(private surveyPointsService: SurveyPointsService, private toastr: ToastrService
    , private dialog: MatDialog, private wellpathsService: WellPathsService) {


  }//end of cnstructor


  ngOnInit(): void {
    this.getWellPathList();
    this.trajectoryPathModel = 4;
  }

  addRow() {

    /**
     * called after clicking on add button
     */
    console.log("added row");
    let surevyPointObj: SurveyPoint = {
      MeasuredDepth: 0,
      Inclination: 0,
      Azimuth: 0,
      TrueVerticalDepth: 0,
      TVDSS: 0,
      NorthSouth: 0,
      EastWest: 0,
      LateralDistance: 0,
      DogLegSeverity: 0,
      BuildRate: 0,
      TurnRate: 0,
      ToolFace: 0,
      VSec: 0,
      HDisp: 0,
      CourseLength: 0,
      Tortuosity: 0,
      ABSTortuosity: 0,
      DDI: 0,
      isAdded:true,
      isUpdated:false,
      SurveyCollectionId:this.trajectoryPathModel,
      SurveyHeaderId: this.wellPathModel,
      Order:265
    }
    this.tableData.push(surevyPointObj);
    this.tableData = [...this.tableData];
  }//end of function

  showInspectionCharts() {
    const matDialogRef = this.dialog.open(InspectionChartsComponent, {
      width: '80%',
      height: '100vh',
      hasBackdrop: true,
      disableClose: true,
      panelClass: 'dialogbox-container',
      autoFocus: false,
      data: { SurveyHeaderId: this.wellPathModel, SurveyCollectionId : this.trajectoryPathModel},
      // maxHeight: '90vh'
    });
    matDialogRef.afterClosed().subscribe((response: any) => {
      if (response) {
        this.getSurveyPointsList();
      }
    });
    // this.route.navigateByUrl("/dashboard/wells/well-paths/inspection-charts");

  }//end of function

  save() {
    this.loading = true;
    let updatedData = _.filter(this.currentData, (item) => {
      return item.isUpdated && !(_.has(item, 'isAdded'))
    });
    updatedData = _.map(updatedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded', 'isUpdated']);
    });


    let addedData = _.filter(this.currentData, { isAdded: true });
    addedData = _.map(addedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded', 'isUpdated']);
    });

    console.log("save", updatedData,addedData);
    if(updatedData.length>0 || addedData.length>0 || this.deleteList.length>0){
      this.saveAPIcall(updatedData,addedData)
    }
    else {
      this.getSurveyPointsList();
    }

  }

  async saveAPIcall(updatedData,addedData){

    /**
     * this method calls the save survey points api
     * First call will be add, second call will be update
     * This Function is a combination of two APIs
     */

    /**
     * Add call
     */
    let addPayload = {
      "wellRows":[...addedData]
    }
    this.addSurveyPoints(addPayload)
    .then((data)=>{
      console.log("call update",data);
      if(updatedData.length>0){
        let updatePayload = {
          "wellRows":[...updatedData]
        }
        return this.updateSurveyPoints(updatePayload);
      }
    })
    .then((data)=>{
      console.log("call delete");
      if(this.deleteList.length>0){
        return this.deleteSurveyPoints(this.deleteList);
      }
    })
    .then((data)=>{
      console.log("delete completed",data);
      this.deleteList = [];
      this.getSurveyPointsList();
      this.toastr.success("Saved Successfully");
    })


  }

  async updateSurveyPoints(updatePayload){
    let data

    try{
    data = lastValueFrom(await this.surveyPointsService.updateSurveyPointsList(updatePayload));
    }
    catch(error){
      data = error;
      this.toastr.error("Something went wrong during update");
    }
    return data;

    try{
    data = lastValueFrom(await this.surveyPointsService.updateSurveyPointsList(updatePayload));
    }
    catch(error){
      data = error;
      this.toastr.error("Something went wrong during update");
    }
    return data;
   
  }

  async addSurveyPoints(addPayload){
    let data = "No data";
    if(addPayload.wellRows.length>0){
      try{
      data = await lastValueFrom(this.surveyPointsService.addSurveyPointsList(addPayload));
    }
    catch(e){
      data = e;
      this.toastr.error("Something went wrong during add");
    }
    }
    return data;
  }

  reset() {
    this.loading = true;
    this.getSurveyPointsList();
  }//end of function

  getTableData(event) {

    /**
     * emitter event call to check updated data in table
     */
    console.log(event)
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function

  checkChanges(data) {

    /**
     * this function compares original data and changes made in
     * table
     */
    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });

    return isDataChanged;
  }//end of function

  getSurveyPointsList() {

    /**
     * This service will get all the survey points for selected well Path
     */
    this.loading = true;
    this.loadMessage = "Please Wait...";
    this.surveyPointsService.getSurveyPointsList(this.wellPathModel,this.trajectoryPathModel).subscribe({
      next:(data)=>{

        sessionStorage.setItem("well-path", this.wellPathModel);
        
          let surveyData =  data.result.wellRows;
          this.kellyBushing = data.result.wellValue[0].KellyBushingTVD;
          this.groundLevel = data.result.wellValue[0].ElevationTVD;

          let firstRow = {
            MeasuredDepth:this.kellyBushing-this.groundLevel,
            Inclination: 0,
            Azimuth: 0,
            TrueVerticalDepth: this.kellyBushing-this.groundLevel,
            TVDSS: -this.kellyBushing,
            NorthSouth:0,
            EastWest:0,
            LateralDistance:0,
            DogLegSeverity:0,
            BuildRate:0,
            TurnRate : 0,
            ToolFace: 0,
            VSec : 0,
            HDisp : 0,
            CourseLength:this.kellyBushing-this.groundLevel,
            Tortuosity:0,
            ABSTortuosity:0,
            DDI: 0,
            Order:0
          }
          let secondRow = {
            MeasuredDepth:this.kellyBushing-this.groundLevel,
            Inclination: 0,
            Azimuth: 0,
            TrueVerticalDepth: this.kellyBushing-this.groundLevel,
            TVDSS: -this.groundLevel,
            NorthSouth:0,
            EastWest:0,
            LateralDistance:0,
            DogLegSeverity:0,
            BuildRate:0,
            TurnRate : 0,
            ToolFace: 0,
            VSec : 0,
            HDisp : 0,
            CourseLength:this.kellyBushing-this.groundLevel,
            Tortuosity:0,
            ABSTortuosity:0,
            DDI: 0,
            Order:0
          };
          surveyData.unshift(firstRow,secondRow);
          this.tableData = data.result.wellRows;
          this.originalData = JSON.parse(JSON.stringify(this.tableData));
          this.loading = false;
          this.loadMessage = "";
          this.deleteList = [];
      },
      error: (error) => {
        this.loading = false;
        this.toastr.error("Something went wrong");
        this.tableData = [];
        this.deleteList = [];
      }
    });//end of service call
  }//end of function

  operateAction(eve) {

    let operation = eve.action;
    let payload = eve.data;
    switch (operation) {
      case 'delete': this.deleteMethod(payload);
    }
  }//end of function

  deleteMethod(payload) {
    this.loading = true;
    let index = this.tableData.indexOf(payload);
    if(index>-1){
      this.tableData.splice(index,1);
      this.tableData = [...this.tableData];
      if(!payload.isAdded){
        this.deleteList.push(payload);
      }
    }


  }//end of function

  async deleteSurveyPoints(list){
    let data;
    let deleteList = list.map((item)=>{
        return item.SurveyId;
    });
      let deletePayload = {
        "wellRows": deleteList
      }
      try{
      data = await lastValueFrom(this.surveyPointsService.deleteSurveyPointsList(deletePayload));
    }
    catch(error){
      data = error;
      this.toastr.error("Something went wrong during delete");
    }
    return data;


  }
  getWellPathList() {

    this.wellpathsService.getWellPathsList().subscribe(res => {
      if (res) {
           this.wellpathList = res.result.map((wellpath)=>{
            return {'label':wellpath.Name,'value':wellpath.SurveyHeaderId};
          });
          this.wellPathModel = parseInt(sessionStorage.getItem("well-path"));
          this.getSurveyPointsList();
      } else {
        console.log('error')
      }
    }),
      (error) => {
        console.log("WellPaths", error.error.result);
        // this.tableData = error.error.result;

      };//end of service call

  }// function ends


  tortuosityModal(): void {
    const dialogRef = this.dialog.open(TortuosityModalComponent, {
      width: '85%',
      height:'100vh',
      data: '', 
      disableClose: false,
      autoFocus: false,
      panelClass:"myClass",
      position: {
        top: '50px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      this.getSurveyPointsList();
    });

  }




}