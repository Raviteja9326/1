import { AfterViewChecked, Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { InspectionChartsService } from 'src/app/core/services/inspectionCharts.service';
import { api } from 'src/app/core/constants/api.constants';
import { ChartData, GetParameters } from 'src/app/core/interfaces/inspectionChart.interface';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ExcelExportsService } from 'src/app/core/services/excelExport.service';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import canvasToBuffer from 'canvas-to-buffer';
import * as ExcelJS from 'exceljs';

@Component({
  selector: 'app-inspection-charts',
  templateUrl: './inspection-charts.component.html',
  styleUrls: ['./inspection-charts.component.scss']
})
export class InspectionChartsComponent implements OnInit, OnDestroy {
  canvas: any;
  ctx: CanvasRenderingContext2D;
  isSurveyTab: boolean = true;
  isTrajectoryTab: boolean = false;
  isSvsTTab: boolean = false;
  chartData: ChartData[]
  isLinear: boolean = false;
  orginalColor: string = '#007ee7';
  correctedColor: string = 'red';
  extrapoltedColor: string = 'red';
  // Survey variables
  @ViewChild('tortusity') tortusity: ElementRef | undefined;
  @ViewChild('inclination') inclination: ElementRef | undefined;
  @ViewChild('azimuth') azimuth: ElementRef | undefined;
  @ViewChild('dls') dls: ElementRef | undefined;
  @ViewChild('northsouth') northsouth: ElementRef | undefined;
  @ViewChild('eastwest') eastwest: ElementRef | undefined;
  @ViewChild('turnrate') turnrate: ElementRef | undefined;
  @ViewChild('buildrate') buildrate: ElementRef | undefined;
  @ViewChild('ddi') ddi: ElementRef | undefined;

  survaryVariablesArray = ['tortusity', 'inclination', 'azimuth',
    'dls', 'northsouth', 'eastwest',
    'turnrate', 'buildrate', 'ddi'];

  // Tragectory variables
  @ViewChild('tortusityForTragectory') tortusityForTragectory: ElementRef | undefined;
  @ViewChild('inclinationForTragectory') inclinationForTragectory: ElementRef | undefined;
  @ViewChild('azimuthForTragectory') azimuthForTragectory: ElementRef | undefined;
  @ViewChild('dlsForTragectory') dlsForTragectory: ElementRef | undefined;
  @ViewChild('northsouthForTragectory') northsouthForTragectory: ElementRef | undefined;
  @ViewChild('eastwestForTragectory') eastwestForTragectory: ElementRef | undefined;
  @ViewChild('turnrateForTragectory') turnrateForTragectory: ElementRef | undefined;
  @ViewChild('buildrateForTragectory') buildrateForTragectory: ElementRef | undefined;
  @ViewChild('ddiForTragectory') ddiForTragectory: ElementRef | undefined;

  TragectoryVariablesArray = ['tortusityForTragectory', 'inclinationForTragectory', 'azimuthForTragectory',
    'dlsForTragectory', 'northsouthForTragectory', 'eastwestForTragectory',
    'turnrateForTragectory', 'buildrateForTragectory', 'ddiForTragectory'];

  // Survey vs Tragectory variables
  @ViewChild('tortusityForSurveyVSTragectory') tortusityForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('inclinationForSurveyVSTragectory') inclinationForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('azimuthForSurveyVSTragectory') azimuthForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('dlsForSurveyVSTragectory') dlsForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('northsouthForSurveyVSTragectory') northsouthForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('eastwestForSurveyVSTragectory') eastwestForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('turnrateForSurveyVSTragectory') turnrateForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('buildrateForSurveyVSTragectory') buildrateForSurveyVSTragectory: ElementRef | undefined;
  @ViewChild('ddiForSurveyVSTragectory') ddiForSurveyVSTragectory: ElementRef | undefined;

  SurveyVSTragectoryVariablesArray = ['tortusityForSurveyVSTragectory', 'inclinationForSurveyVSTragectory', 'azimuthForSurveyVSTragectory',
    'dlsForSurveyVSTragectory', 'northsouthForSurveyVSTragectory', 'eastwestForSurveyVSTragectory',
    'turnrateForSurveyVSTragectory', 'buildrateForSurveyVSTragectory', 'ddiForSurveyVSTragectory'];


  selectedIndex: number;

  // Survey line variables
  tortusityLine: any;
  inclinationLine: any;
  azimuthLine: any;
  dlsLine: any;
  northsouthLine: any;
  eastwestLine: any;
  turnrateLine: any;
  buildrateLine: any;
  ddiLine: any;


  // Tragectory line variables
  tortusityForTragectoryLine: any;
  inclinationForTragectoryLine: any;
  azimuthForTragectoryLine: any;
  dlsForTragectoryLine: any;
  northsouthForTragectoryLine: any;
  eastwestForTragectoryLine: any;
  turnrateForTragectoryLine: any;
  buildrateForTragectoryLine: any;
  ddiForTragectoryLine: any;


  // Survey line variables
  tortusityForSurveyVSTragectoryLine: any;
  inclinationForSurveyVSTragectoryLine: any;
  azimuthForSurveyVSTragectoryLine: any;
  dlsForSurveyVSTragectoryLine: any;
  northsouthForSurveyVSTragectoryLine: any;
  eastwestForSurveyVSTragectoryLine: any;
  turnrateForSurveyVSTragectoryLine: any;
  buildrateForSurveyVSTragectoryLine: any;
  ddiForSurveyVSTragectoryLine: any;

  constructor(private inspectionChartsService: InspectionChartsService,
    private excelService: ExcelExportsService,
    public dialogRef: MatDialogRef<InspectionChartsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GetParameters) { }


  async ngOnInit(): Promise<void> {
    console.log(' mat data is ', this.data);
    this.selectedIndex = 0;
    const data = await this.inspectionChartsService.getData(api.getSurveysApi, this.data).toPromise();
    this.chartData = data.result;
    console.log('chart data is', this.chartData);
    await this.drawChart(this.survaryVariablesArray);

  }

  /*
    ** will be triggered when tab is changed
  */
  async selectWellPath(event) {

    this.chartData = [];
    const tabValue = event.selectedIndex;
    this.selectedIndex = tabValue;
    if (tabValue == 0) {
      this.isSurveyTab = true;
      this.isTrajectoryTab = false;
      this.isSvsTTab = false;
      this.orginalColor = '#007ee7';
      this.correctedColor = 'red';
      this.extrapoltedColor = 'red';
      const data = await this.inspectionChartsService.getData(api.getSurveysApi, this.data).toPromise();
      this.chartData = data.result;
      await this.destroyChart(this.survaryVariablesArray);
      await this.drawChart(this.survaryVariablesArray);
    }
    else if (tabValue == 1) {
      this.isSurveyTab = false;
      this.isTrajectoryTab = true;
      this.isSvsTTab = false;
      this.orginalColor = '#3bb143';
      this.correctedColor = 'yellow';
      this.extrapoltedColor = 'yellow';
      const data = await this.inspectionChartsService.getData(api.getTrajectoriesApi, this.data).toPromise();
      this.chartData = data.result;
      await this.destroyChart(this.TragectoryVariablesArray);
      await this.drawChart(this.TragectoryVariablesArray);
    }
    else {
      this.isSurveyTab = false;
      this.isTrajectoryTab = false;
      this.isSvsTTab = true;
      this.orginalColor = '#007ee7';
      this.correctedColor = 'red';
      this.extrapoltedColor = 'red';
      const data = await this.inspectionChartsService.getData(api.getSurveyVsSurveysApi, this.data).toPromise();
      this.chartData = data.result;
      await this.destroyChart(this.SurveyVSTragectoryVariablesArray);
      await this.drawChart(this.SurveyVSTragectoryVariablesArray);
    }

  }




  /*
   ** to destroy chart
 */
  async drawChart(array: Array<string>) {

    console.log('chart data is ', this.chartData);
    for (const variableName of array) {
      if (variableName.includes("tortusity")) {
        this.canvas = this[variableName].nativeElement;
        this.ctx = this.canvas.getContext('2d');
        this.ctx.clearRect(0, 0, 100, 100);
        this.tortusityMethod(variableName);
      }
      else {
        this.canvas = this[variableName].nativeElement;
        this.ctx = this.canvas.getContext('2d');
        this.ctx.clearRect(0, 0, 100, 100);
        this.genericChartMethod(variableName);

      }


    }
  }
  /*
    ** create a line chart for tortusity
  */
  tortusityMethod(variableName: string) {
    // debugger
    const labels = [];
    //create Y-axis label
    for (let i = 0; i < 7000; i += 1000) {
      labels.push(i.toString());
    }
    if (this[variableName + 'Line']) {
      this[variableName + 'Line'].destroy();
    }
    this[variableName + 'Line'] = new Chart(this.ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'S Original',
          data: this.chartData[variableName],
          //backgroundColor: "rgb(115 185 243 / 65%)",
          borderColor: this.orginalColor,
          // fill: true,
        },
        {
          label: 'S Corrected',
          data: this.chartData[variableName],
          //backgroundColor: "#47a0e8",
          borderColor: this.correctedColor,
          //fill: false,

        },
        {
          label: 'S Extrapolated',
          data: this.chartData[variableName],
          backgroundColor: this.extrapoltedColor,
          //borderColor: "#007ee7",
          //fill: false,
          borderDash: [5, 5],
        }
        ],
        labels: labels
      },

      options: {
        indexAxis: 'y',
        maintainAspectRatio: false,
        responsive: true,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            display: false,
            position: 'top',
            align: 'end',
            labels: {
              color: 'darkred',
              boxHeight: 2,
            }
          },
          title: {
            display: true,
            text: variableName,
            padding: {
              top: 10,
              bottom: 10
            },
            color: 'white',
            font: {
              family: 'Serif',
              size: 14,
              weight: 'bold',
              lineHeight: 1.9,
            },
          },
        },
        scales: {
          x: {
            position: 'bottom',
            ticks: {
              maxTicksLimit: 3,
              color: 'white'
            },
            // title: {
            //   display: true,
            //   text: variableName,
            //   color: 'white',
            //   font: {
            //     family: 'Serif',
            //     size: 14,
            //     weight: 'bold',
            //     lineHeight: 1.9,
            //   },
            //   padding: { top: 2, bottom: 0 }
            // },
            min: -2000,
            max: 2000
          },
          x2: {
            position: 'top',
            ticks: {
              maxTicksLimit: 3,
              color: 'white'
            },
            min: -2000,
            max: 2000
          },
          y: {
            position: 'right',
            min: -2000,
            max: 2000,
            ticks: {
              maxTicksLimit: 3,
              color: 'white'
            },
          }
        }
      },
    });
    // this.tortusityLine.update();
  }

  /*
 ** create a line chart for inclination 
 */
  genericChartMethod(variableName) {

    const labels = [];
    for (let i = 0; i < 7000; i += 1000) {
      labels.push(i.toString());
    }
    if (this[variableName + 'Line']) {
      // debugger
      this[variableName + 'Line'].destroy();
    }
    this[variableName + 'Line'] = new Chart(this.ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'S Original',
          data: this.chartData[variableName],
          backgroundColor: this.orginalColor,
          borderColor: this.orginalColor,
          // fill: true,

        },
        {
          label: 'S Corrected',
          data: this.chartData[variableName],
          backgroundColor: this.correctedColor,
          borderColor: this.correctedColor,
          // fill: true,
        },
        {
          label: 'S Extrapolated',
          data: this.chartData[variableName],
          backgroundColor: this.extrapoltedColor,
          borderColor: this.extrapoltedColor,
          fill: false,
          borderDash: [5, 5],
        }

        ],
        labels: labels
      },
      options: {
        indexAxis: 'y',
        maintainAspectRatio: false,
        responsive: true,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          title: {
            display: true,
            text: variableName,
            padding: {
              top: 10,
              bottom: 5
            },
            color: 'white',
            font: {
              family: 'Serif',
              size: 14,
              weight: 'bold',
              lineHeight: 1.9,
            },
          },
          legend: {
            display: false,
            position: 'chartArea',
            align: 'start',
            labels: {
              color: 'darkred',
              boxHeight: 2,
            }
          }
        },
        scales: {
          x: {
            position: 'bottom',
            ticks: {
              maxTicksLimit: 3,
              color: 'white'
            },
            // title: {
            //   display: true,
            //   text: variableName,
            //   color: 'white',
            //   font: {
            //     family: 'Serif',
            //     size: 14,
            //     weight: 'bold',
            //     lineHeight: 1.9,
            //   },
            //   padding: { top: 0, bottom: 2 }
            // },
            min: -2000,
            max: 2000
          },
          x2: {
            position: 'top',
            ticks: {
              maxTicksLimit: 3,
              color: 'white'
            },
            min: -2000,
            max: 2000
          },
          y: {
            ticks: {
              display: false,
              color: 'white' //this will remove only the label
            }
          }
        }
      }

    });
    // this.inclinationLine.update();


  }

  /*
    ** to destroy chart
  */

  async destroyChart(array: Array<string>) {

    for (const variableName of array) {
      this[variableName + 'Line'] = null;
    }
  }
  /*

 ** Export data in excelsheet function

  */

  async exportToExcel(chartName: string): Promise<void> {

    let chartType;
    if (this.selectedIndex == 1) {
      chartType = 'Trajectory';

    } else if (this.selectedIndex == 0) {
      chartType = 'Survey';

    } else {
      chartType = 'TrajectoryvsSurvey';

    }
    const data = await this.inspectionChartsService.getExcelData(chartType, chartName, this.data).toPromise();
    this.excelService.exportAsExcelFile(data.result, chartType + ' ' + chartName);


  }

  /*
    ** Export data in excelsheet function
     */
  onCloseClick(): void {
    this.dialogRef.close();
  }
  ngOnDestroy(): void {

    this.destroyChart(this.survaryVariablesArray);
    this.destroyChart(this.TragectoryVariablesArray);
    this.destroyChart(this.SurveyVSTragectoryVariablesArray);
  }

  async exportToExcelImage() {
    // Get the chart image as a base64 URL
    const chartImageDataURL = this.tortusity.nativeElement.toDataURL('image/png');

    // Prepare the data for the Excel file
    const worksheetData = this.chartData['tortusity'];

    // Create a workbook and worksheet
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');

    // Add the data to the worksheet
    worksheet.addRows(worksheetData);

    // Convert base64 image data to a buffer
    //  const imageData = this.dataURLToBuffer(chartImageDataURL);

    // Add the image to the worksheet
    const imageId = workbook.addImage({
      base64: chartImageDataURL,
      extension: 'png',
    });


    const imgCell = worksheet.getCell('A1');
    const imgCol = parseInt(imgCell.col.toString());
    const imgRow = parseInt(imgCell.row.toString());

    worksheet.addImage(imageId, {
      tl: { col: imgCol, row: imgRow },
      ext: { width: 640, height: 480 },
      editAs: 'oneCell',
    });


    // Set background color for the cell containing the image
    imgCell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFFFFFFF' }, // Set to white (FFFFFF) or any other color you prefer
    };

    // Save the Excel file
    const excelBuffer = await workbook.xlsx.writeBuffer();
    this.saveExcelFile(excelBuffer, 'chart_data121.xlsx');
  }

  private dataURLToBuffer(dataURL: string): Promise<ArrayBuffer> {
    return fetch(dataURL)
      .then(response => response.blob())
      .then(blob => new Promise<ArrayBuffer>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as ArrayBuffer);
        reader.onerror = reject;
        reader.readAsArrayBuffer(blob);
      }));
  }

  private saveExcelFile(buffer: ArrayBuffer, fileName: string) {
    const data = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
  }

}
