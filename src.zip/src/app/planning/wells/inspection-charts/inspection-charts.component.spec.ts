import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InspectionChartsComponent } from './inspection-charts.component';

describe('InspectionChartsComponent', () => {
  let component: InspectionChartsComponent;
  let fixture: ComponentFixture<InspectionChartsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InspectionChartsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InspectionChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
