import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wells',
  templateUrl: './wells.component.html',
  styleUrls: ['./wells.component.scss']
})
export class WellsComponent implements OnInit {

  isLinear: boolean = false;

  constructor(private route: Router) { }

  ngOnInit(): void {
    this.onStepClick({selectedIndex:0})
  }

  onStepClick(event) {
    if (event.selectedIndex == 0) {
      this.route.navigate(['/dashboard/wells/well-paths']);
    }
    else if (event.selectedIndex == 1) {
      this.route.navigate(['/dashboard/wells/formations']);
    }
    else if (event.selectedIndex == 2) {
      this.route.navigate(['/dashboard/wells/well-intervals']);
    }
    else if (event.selectedIndex == 3) {
      this.route.navigate(['/dashboard/wells/temperature']);
    }
  }
}
