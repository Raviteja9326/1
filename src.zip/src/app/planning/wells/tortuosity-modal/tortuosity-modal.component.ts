import { Component, OnInit } from '@angular/core';
import { Tortuosity } from 'src/app/core/interfaces/tortuosity.interface';
import { Column } from 'src/app/core/interfaces/column.interface';
import * as _ from 'lodash';
import { TortuosityService } from 'src/app/core/services/tortuosity.service';
import { MatDialog } from '@angular/material/dialog';

import { ToastrService } from 'ngx-toastr';
import { SurveyPointsService } from 'src/app/core/services/surveyPoints.service';

@Component({
  selector: 'app-tortuosity-modal',
  templateUrl: './tortuosity-modal.component.html',
  styleUrls: ['./tortuosity-modal.component.scss']
})
export class TortuosityModalComponent implements OnInit {
  loading:boolean = false;
  trajectoryPathModel: any ;

tableData:Tortuosity[] =[];
tableColumns=[
    { columnDef: 'StartingMD', header: 'From<br/>(ft)',inputType:'number',cell: (element: Record<number, any>) => `${element['StartingMD']}`,editable:true },
    { columnDef: 'EndingMD', header: 'To<br/>(ft)',  inputType:'number',cell: (element: Record<number, any>) => `${element['EndingMD']}`, isLink: true, url: 'abc',editable:true},
    { columnDef: 'InterpolationStep', header: 'Interpolation Step<br/>(ft)',inputType:'number', cell: (element: Record<number, any>) => `${element['InterpolationStep']}`,editable:true },
    { columnDef: 'TortuosityMethod', header: 'Tortuosity<br/>Method',  cell: (element: Record<number, any>) => `${element['TortuosityMethod']}`,editable:true },
    { columnDef: 'Amplitude', header: 'Amplitude<br/> (°)',  inputType:'number',cell: (element: Record<number, any>) => `${element['Amplitude']}`,editable:true },
    { columnDef: 'Period', header: 'Period<br/>(ft)',  inputType:'number',cell: (element: Record<number, any>) => `${element['Period']}`,editable:true },
    { columnDef: 'Phase', header: 'Phase<br/> (°)',  inputType:'number',cell: (element: Record<number, any>) => `${element['Phase']}` ,editable:true},
    { columnDef: 'Shift', header: 'Shift<br/> (°)',inputType:'number', cell: (element: Record<number, any>) => `${element['Shift']}`,editable:true },
    { columnDef: 'RetainOriginalPoints', header: 'Retain Original',inputType:'checkbox', cell: (element: Record<number, any>) => `${element['RetainOriginalPoints']}`,editable:true },
 
]

  originalData: any;
  isChanged: boolean;
  currentData: any=[];

  constructor(private tortuosityService:TortuosityService,private dialog: MatDialog,private toastr: ToastrService,private surveyPointsService: SurveyPointsService ) { }

  ngOnInit(): void {
   this.getTortuosityData();
  }

  
  addRow() {

    /**
     * called after clicking on add button
     */
    console.log("added row");
    let tortuosityObj : Tortuosity ={
      StartingMD:0,
      EndingMD:0,
      InterpolationStep:0,
      TortuosityMethod:0,
      Amplitude:0,
      Period:0,
      Phase:0,
      Shift:0,
      RetainOriginalPoints:1,
      SurveyHeaderId:1,
      isAdded:true,
      isUpdated:false,
      
    }
    this.tableData.push(tortuosityObj);
    this.tableData = [...this.tableData];
  }//end of function

  reset() {
    
    this.getTortuosityData();
  }//end of function

  getTableData(event){

    /**
     * emitter event call to check updated data in table
     */
    console.log("to display current table ",event)
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function


  checkChanges(data){

    /**
     * this function compares original data and changes made in
     * table
     */
    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged",isDataChanged, data);
    this.currentData = data;
    setTimeout(()=>{
      this.isChanged = isDataChanged;
    });

    return isDataChanged;
  }//end of function

  operateAction(eve){

    let operation = eve.action;
    let payload = eve.data;
    switch(operation){
      case 'delete': this.deleteMethod(payload);
    }
  }//end of function


  deleteMethod(payload){
    let SurveyTortuosityId = payload.SurveyTortuosityId;
    let index = this.tableData.indexOf(payload);
    if(index>-1){
      this.tableData.splice(index,1);
      this.tableData = [...this.tableData];
      if(!payload.isAdded){
              this.tortuosityService.deleteTortuosity(SurveyTortuosityId).subscribe({
            next: (data) =>{
               console.log(data);
               this.toastr.success("Record deleted successfully");
            },
            error:(error) =>{
              console.error(error)
              this.toastr.error("Something went wrong during delete");
          
            }
          })
      }
    }
    
  }//end of function


  


  applyTortuosity() {
    this.loading = true;
    let updatedData = _.filter(this.currentData,(item)=> {
            return item.isUpdated && !(_.has(item,'isAdded'))
     });
   
    updatedData = _.map(updatedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded','isUpdated']);
    });
    

    let addedData = _.filter(this.currentData, { isAdded: true });
  
    addedData = _.map(addedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded','isUpdated']);
    });

   
    if(updatedData.length>0 || addedData.length>0){
      this.saveAPIcall(updatedData,addedData)
    }
    else{
      this.getTortuosityData();
    }

  }


  saveAPIcall(updatedData,addedData)
  {
    console.log("added",addedData);
    console.log("updated",updatedData);

    let id = parseInt(sessionStorage.getItem("well-path"));
       if(addedData.length > 0 )
        {
          addedData[0].SurveyHeaderId = id;
          let tortuosityData =addedData[0]
          let data={tortuosityData}
               
              this.tortuosityService.postTortuosity(data).subscribe({
                next: (data) =>{
                  console.log(data.result);
                  this.toastr.success("Tortuosity applied successfully");
                  this.dialog.closeAll();
            
                },
                error:(error) =>{
                  console.error(error)
                  this.loading = false;
              
                }
              })
        }else if(updatedData.length > 0){

          updatedData.SurveyHeaderId = id;
          let tortuosityData =updatedData

          let data={tortuosityData}
         
          this.tortuosityService.updateTortuosity(data).subscribe({
            next: (data) =>{
              console.log(data.result);
              this.toastr.success("Tortuosity updated successfully");
              this.dialog.closeAll();
            },
            error:(error) =>{
              console.error(error)
              this.loading = false;
          
            }
          })
        }
            
  }

 
//   surveyCall(){

//     let id = parseInt(sessionStorage.getItem("well-path"));
//     this.trajectoryPathModel = 4;
// this.surveyPointsService

//     this.surveyPointsService.getSurveyPointsList(id,this.trajectoryPathModel).subscribe({
//       next: (data) =>{
//          this.tableData = data.result;
//       },
//       error:(error) =>{
//         console.error(error)
//         this.loading = false;
    
//       }
//     })

//   }

  

  getTortuosityData(){

    let id = parseInt(sessionStorage.getItem("well-path"));
    this.tortuosityService.getTortuosityList(id).subscribe({
      next: (data) =>{
         this.tableData = data.result;
      },
      error:(error) =>{
        console.error(error)
        this.loading = false;
    
      }
    })

  }




}
