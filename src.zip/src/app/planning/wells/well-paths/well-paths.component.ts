import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Column } from 'src/app/core/interfaces/column.interface';
import { WellPath } from 'src/app/core/interfaces/wellPath.interface';
import { WellPathsService } from 'src/app/core/services/wellPaths.service';
import * as _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { lastValueFrom } from 'rxjs';
import { settings } from 'cluster';
import { WarningDialogComponent } from './warning-dialog/warning-dialog.component';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-well-paths',
  templateUrl: './well-paths.component.html',
  styleUrls: ['./well-paths.component.scss']
})
export class WellPathsComponent implements OnInit {
  tableData: any = [
    // { wellpaths: 'Test', active: true },
    // { wellpaths: 'Test 2', active: false },
    // { wellpaths: 'Test 3', active: false },
  ];
  tableDataNew: any = [];

  tableColumns: Column[] = [
    { columnDef: "Name", header: "Well Paths", sticky: true, editable: true, cell: (element: Record<string, any>) => `${element['Name']}` }
  ]
  originalData: any;
  isChanged: boolean;
  currentData: any = [];
  deleteList: any = [];

  constructor(private route: Router, private dialog: MatDialog,
    private wellpaths: WellPathsService, private toastr: ToastrService) {


  }//end of constructor

  ngOnInit(): void {
    this.getWellPathList();
    this.originalData = JSON.parse(JSON.stringify(this.tableData));
  }

  /**
  * get all wellpath list
  */
  getWellPathList() {

    this.wellpaths.getWellPathsList().subscribe({
      next: (res) => {
        if (res) {
          console.log(res)
          this.tableData = res.result
          this.originalData = JSON.parse(JSON.stringify(this.tableData));
          this.deleteList = [];
        } else {
          console.log('error')
        }
      },
      error: (error) => {
        console.log("WellPaths", error.error.result);

      }
    })//end of service call

  }// function ends

  /**
   * called after clicking on add button
   */
  addRow() {

    console.log("added row");
    let wellPathObj: WellPath = {
      "AutoImport": true,
      "WitsmlChannelKey": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
      "TrajectoryUid": "ase",
      "AutoImportFrequencyInMinutes": 1,
      "MdUnit": 1,
      "AzimuthUnit": 12,
      "InclinationUnit": 21,
      "Active": false,
      "Key": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
      "PlanedSurveyCollectionId": 1,
      "SurveyCollectionId": 2,
      "WellPathCollectionId": 1,
      "TieOnPoint": 2,
      "isAdded": true,
    }
    this.tableData.push(wellPathObj);
    this.tableData = [...this.tableData];
  }//end of function

  /**
    * save well paths
    */
  save() {


    let updatedData = _.filter(this.currentData, (item) => {
      return item.isUpdated && !(_.has(item, 'isAdded'))
    });
    updatedData = _.map(updatedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded', 'isUpdated']);
    });


    let addedData = _.filter(this.currentData, { isAdded: true });
    addedData = _.map(addedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded', 'isUpdated']);
    });

    console.log("save", updatedData, addedData);
    if (updatedData.length > 0 || addedData.length > 0 || this.deleteList.length > 0) {
      this.saveAPIcall(updatedData, addedData)
    }
    else {
      this.getWellPathList();
    }

  }// function ends

  /**
      * this method calls the save wellpaths api
      * First call will be add, second call will be update
      * This Function is a combination of two APIs
      */
  saveAPIcall(updatedData, addedData) {

    /**
     * Add call
     */
    let addPayload = {
      "wellRows": [...addedData]
    }
    this.addWellPaths(addPayload)
      .then((data) => {
        console.log("call update", data);
        if (updatedData.length > 0) {
          var updatePayload = {
            "wellRows": [...updatedData],
          }
          return this.updateWellPaths(updatePayload);
        }
      })
      .then((data) => {
        console.log("call delete");
        if (this.deleteList.length > 0) {
          return this.deleteWellPath(this.deleteList);
        }
      })
      .then((data) => {
        console.log("delete completed", data);
        this.deleteList = [];
        this.getWellPathList();
        this.toastr.success("Well Paths Saved Successfully");
      })
      .catch((error) => {
        this.toastr.error("Something went wrong during delete");
        this.getWellPathList();
      })







  }// function ends

  async addWellPaths(addPayload) {

    let data = null;
    if (addPayload.wellRows.length > 0) {
      data = lastValueFrom(await this.wellpaths.addWellPathsList(addPayload));
    }
    return data;

  }//end of function

  async updateWellPaths(updatePayload) {
    let data;
    try {
      data = lastValueFrom(await this.wellpaths.updateWellpathsList(updatePayload));
    }
    catch (error) {
      data = error;
      this.toastr.error("Something went wrong during update");
    }
    return data;
  }

  async deleteWellPath(list){
    let data;
    let deleteList = list.map(item => item.SurveyHeaderId);
    let deletePayload = {
      "wellRows": deleteList
    }
    try{
    data = await lastValueFrom(this.wellpaths.deleteWellpathsList(deletePayload));
    }
    catch (e) {
      data = e;
      this.toastr.error("Something went wrong during delete");
    }

    return data;
  }
  /**
   * To refresh the well path table
   */
  reset() {
    this.getWellPathList();
  }//end of function


  /**
   * emitter event call to check updated data in table
   */
  getTableData(event) {

    let isChanged = this.checkChanges(event.data);
    return isChanged;

  }//end of function

  /**
   * this function compares original data and changes made in
   * table
   */
  checkChanges(data) {

    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });
    return isDataChanged;

  }//end of function

  operateAction(eve) {

    let operation = eve.action;
    let payload = eve.data;
    switch (operation) {
      case 'viewpoints': this.showSurveyPoints(payload); break;
      case 'delete': this.deleteMethod(payload); break;
      case 'clone': this.showWarningForClone(payload); break;//this.cloneMethod(payload); break;
      case 'activate': this.showWarningForActivate(payload);//this.ActivateWellPath(payload);
    }
  }//end of function

  showWarningForActivate(payload) {

    const dialogRef = this.dialog.open(WarningDialogComponent, {
      width: '400px', // Specify the width of the dialog box
      data: {
        title: "Warning",
        content: "Activating a Well path will reset unsaved changes if any. Please save the changes before proceeding. Are you sure you want to proceed?"
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.action === 'yes') {
          console.log('User clicked the yes button.');
          console.log('Additional data from dialog:', result.additionalData);
          this.ActivateWellPath(payload);
        }
        else if (result.action === 'no') {
          console.log('User clicked the Cancel button.');
        }
      }
      else {
        console.log('Dialog was closed without any action.');
      }
    });
  }

  showWarningForClone(payload) {

    const dialogRef = this.dialog.open(WarningDialogComponent, {
      width: '400px', // Specify the width of the dialog box
      data: {
        title: "Warning",
        content: "Cloning a Well path will reset unsaved changes if any. Please save the changes before proceeding. Are you sure you want to proceed?"
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.action === 'yes') {
          console.log('User clicked the yes button.');
          console.log('Additional data from dialog:', result.additionalData);
          this.cloneMethod(payload);
        }
        else if (result.action === 'no') {
          console.log('User clicked the Cancel button.');
        }
      }
      else {
        console.log('Dialog was closed without any action.');
      }
    });
  }

  showSurveyPoints(payload) {
    sessionStorage.setItem("well-path", payload.SurveyHeaderId);
    sessionStorage.setItem("well-path-name", payload.Name);
    this.route.navigateByUrl('dashboard/wells/well-paths/survey-points');

  }//end of function

  /**
* Method to clone the well path
*/
  cloneMethod(payload) {

    console.log("cloned row");
    console.log("cloned row", payload);
    let wellPathObj: WellPath = {
      "AutoImport": true,
      "WitsmlChannelKey": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
      "TrajectoryUid": "ase",
      "AutoImportFrequencyInMinutes": 1,
      "MdUnit": 1,
      "AzimuthUnit": 12,
      "InclinationUnit": 21,
      "Active": false,
      "Key": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
      "PlanedSurveyCollectionId": 1,
      "SurveyCollectionId": 2,
      "WellPathCollectionId": 1,
      "TieOnPoint": 2,
      "Name": payload.Name
    }
    this.tableData.push(wellPathObj);
    this.tableData = [...this.tableData];
    let clonePayload = {
      "wellRows": [wellPathObj]
    }
    this.cloneApiCall(clonePayload);

  }// method ends

  /**
* Clone wellpath Api call
*/

  cloneApiCall(clonePayload) {
    /**
 * Add call
 */
    this.wellpaths.addWellPathsList(clonePayload).subscribe({
      next: (data) => {
        console.log(data);
        this.toastr.success("Well Path Cloned Successfully");
        this.getWellPathList();
      },
      error: (error) => {
        console.log(error);
      }

    });

  }

  /**
         * call activate wellpath API
         */
  ActivateWellPath(activatePayload) {

    let status = {
      "Active": 1,
    };
    let statusHeaderId = activatePayload.SurveyHeaderId
    this.wellpaths.activateWellpathsList(statusHeaderId, status).subscribe({
      next: (data) => {
        console.log(data);
        this.toastr.success("Well Path Activated Successfully");
        this.getWellPathList();
      },
      error: (error) => {
        console.log(error);
      }
    });

  }// end of the function


  deleteMethod(payload) {

      let index = this.tableData.indexOf(payload);
      if (index > -1) {
        this.tableData.splice(index, 1);
        this.tableData = [...this.tableData];
        if (!payload.isAdded) {
          this.deleteList.push(payload);
        }
      }


  }//end of function
}