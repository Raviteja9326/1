import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllModule } from 'src/app/shared/all_modules';
import { WellPathsRoutingModule } from './well-paths-routing.module';
import { WellPathsComponent } from './well-paths.component';
import { SurveyPointsComponent } from '../survey-points/survey-points.component';
import { InspectionChartsComponent } from '../inspection-charts/inspection-charts.component';
import { WarningDialogComponent } from './warning-dialog/warning-dialog.component';
import { TortuosityModalComponent } from '../tortuosity-modal/tortuosity-modal.component';
@NgModule({
  declarations: [
    WellPathsComponent,
    SurveyPointsComponent,
    InspectionChartsComponent,
    WarningDialogComponent,
    TortuosityModalComponent
  ],
  imports: [
    CommonModule,
    AllModule,
    WellPathsRoutingModule
  ]
})

export class WellPathsModule {

}