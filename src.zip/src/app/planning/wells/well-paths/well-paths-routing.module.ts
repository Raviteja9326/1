import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SurveyPointsComponent } from '../survey-points/survey-points.component';
import { WellPathsComponent } from './well-paths.component';
import { InspectionChartsComponent } from '../inspection-charts/inspection-charts.component';
const routes: Routes = [
    {
        path: '',
        component: WellPathsComponent
    
    },
    {
        path: 'survey-points',
        component: SurveyPointsComponent,
     
    },
    {
        path: 'inspection-charts',
        component: InspectionChartsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class WellPathsRoutingModule { }
