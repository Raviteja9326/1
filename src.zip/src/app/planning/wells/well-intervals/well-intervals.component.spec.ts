import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellIntervalsComponent } from './well-intervals.component';

describe('WellIntervalsComponent', () => {
  let component: WellIntervalsComponent;
  let fixture: ComponentFixture<WellIntervalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WellIntervalsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WellIntervalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
