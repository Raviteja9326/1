import { Component, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { WellInterval } from 'src/app/core/interfaces/well-Interval.interface';
import { WellIntervalService } from 'src/app/core/services/wellinterval.service';

@Component({
  selector: 'app-open-holes',
  templateUrl: './open-holes.component.html',
  styleUrls: ['./open-holes.component.scss']
})
export class OpenHolesComponent implements OnInit {
  dataSourceHoles: Array<any> = [];
  isChanged: boolean;
  allWellIntervals: Array<{}>;
  wellIntervalModel: any;
  openHolesModel: string = 'Open Holes';
  casingType: Array<string>;
  currentData: Array<{}>;
  originalData: Array<{}>;
  deleteList: [];
  deletePermitted: boolean = false;
  OpenHoleIntervalIds = [];
  deletePayload: object;
  payloadOpenHole: object;
  clonePermitted: boolean = false;
  wellIntervalID: number;
  constructor(private route: Router, private wellInterval: WellIntervalService, private toastr: ToastrService) {
    this.casingType = ['Casing', 'Open Holes']
  }

  tableColumnsHoles: Array<WellInterval> = [
    { columnDef: 'MeasuredDepth', header: 'Measured Depth', editable: true, cell: (element: Record<string, any>) => `${element['MeasuredDepth']}` },
    { columnDef: 'HoleDiameter', header: 'Hole Diameter', editable: true, cell: (element: Record<string, any>) => `${element['HoleDiameter']}` },
    { columnDef: 'FrictionFactor', header: "Friction Factor", editable: true, cell: (element: Record<string, any>) => `${element['FrictionFactor']}` },
    // { columnDef: 'Action', header: 'Action', cell: (element: Record<string, any>) => `${element['Action']}` }
  ];

  tableDataHoles: any = [
    // { MD: 1, HoleDiameter: '12', FrictionFactor: 1.0061 },
    // { MD: 2, HoleDiameter: '13', FrictionFactor: 1.0071 },
    // {MD: 3, HoleDiameter: '14', FrictionFactor: 1.0081},
    // {MD: 4, HoleDiameter: '15', FrictionFactor: 1.0091},
  ];
  ngOnInit(): void {
    this.wellintervalLists();
    this.setWellIntervalModel();
    this.showOpenHolesList();
    this.originalData = JSON.parse(JSON.stringify(this.tableDataHoles));
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log(changes)
    this.setWellIntervalModel();
  }
  operateAction(eve) {

    let operation = eve.action;
    let payload = eve.data;
    switch (operation) {
      // case 'viewpoints': this.showSurveyPoints(payload); break;
      case 'delete': this.deleteMethod(payload); break;
      case 'clone': this.cloneMethod(payload); break;
      // case 'activate': this.ActivateWellPath(payload);
    }
  }//end of function

  /* add empty row for well interval */
  addRow() {

    console.log("added row");
    let OpenHolesObj: any = {
      "MeasuredDepth": '',
      "HoleDiameter": '',
      "Order": '',
      "FrictionFactor": '',
      "isAdded": true
    }
    this.tableDataHoles.push(OpenHolesObj);
    this.tableDataHoles = [...this.tableDataHoles];

  }// function ends


  /**
* Method to clone the well path
*/
  cloneMethod(payload) {

    console.log("cloned row");
    console.log("cloned row", payload);
    this.tableDataHoles.push(payload);
    this.tableDataHoles = JSON.parse(JSON.stringify(this.tableDataHoles))
    this.tableDataHoles = [...this.tableDataHoles]
    // this.tableDataHoles.push(wellIntervalHolesObj);

    let resultAdded = [];

    resultAdded.push({ MeasuredDepth: JSON.parse(payload.MeasuredDepth), HoleDiameter: JSON.parse(payload.HoleDiameter), order: 9, FrictionFactor: JSON.parse(payload.FrictionFactor) })

    this.payloadOpenHole = {
      "addOpenHoles": [...resultAdded],
      "updateOpenHoles": []
    }
    this.clonePermitted = true;
    // this.cloneApiCall(payloadOpenHole);

  }// method ends

  /**
  * Clone wellpath Api call
  */

  cloneApiCall(clonePayload) {
    /**
  * Add call
  */
    // this.wellIntervalID = this.wellInterval.intervalData?.WellboreSectionId
    // this.wellInterval.addOpenHolesList(this.wellIntervalID, clonePayload).subscribe({
    //   next: (data) => {
    //     console.log(data);
    //     this.toastr.success("Open Hole Cloned Successfully");
    //     this.showOpenHolesList();
    //     this.clonePermitted = false;
    //   },
    //   error: (error) => {
    //     console.log(error);
    //     this.toastr.error("Something Went Wrong");
    //   }
    // });

  }

  deleteMethod(payload) {

    if (payload) {
      let index = this.tableDataHoles.indexOf(payload);
      if (index > -1) {
        this.tableDataHoles.splice(index, 1);
        this.tableDataHoles = [...this.tableDataHoles];
        this.deletePermitted = false;
        // this.toastr.success("Open Hole Deleted Successfully");
      }
    }
    if (payload.OpenHoleIntervalId !== null || undefined || '') {
      this.deletePermitted = true;
      this.OpenHoleIntervalIds.push(payload.OpenHoleIntervalId);
      this.deletePayload = {
        deletedIds: [...this.OpenHoleIntervalIds],
        type: 'openHole'
      }
    }
  }//end of function


  deleteApiCall(deletePayload) {

    this.wellIntervalID = this.wellInterval.intervalData?.WellboreSectionId
    this.wellInterval.deleteOpenHolesList(this.wellIntervalID, deletePayload).subscribe({
      next: (data) => {
        console.log(data);
        this.showOpenHolesList();
        this.toastr.success("Open Hole Deleted Successfully");
        this.deletePermitted = false;
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });

  }
  getTableData(event) {

    /**
     * emitter event call to check updated data in table
     */
    console.log(event)
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function

  checkChanges(data) {

    /**
     * this function compares original data and changes made in
     * table
     */
    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });
    return isDataChanged;
  }//end of function
  resetHoles() {
    this.showOpenHolesList();
  }

  save() {
    if (this.clonePermitted) {
      this.cloneApiCall(this.payloadOpenHole);
    }
    else if (this.deletePermitted) {
      this.deleteApiCall(this.deletePayload);
    }
      let updatedData = _.filter(this.currentData, (item: any) => {
        return item.isUpdated && !(_.has(item, 'isAdded'))
      });
      updatedData = _.map(updatedData, (item) => {
        // Use _.omit to remove the unwanted keys from each object
        return _.omit(item, ['isAdded', 'isUpdated']);
      });


      let addedData = _.filter(this.currentData, { isAdded: true });
      addedData = _.map(addedData, (item) => {
        // Use _.omit to remove the unwanted keys from each object
        return _.omit(item, ['isAdded', 'isUpdated']);
      });

      console.log("save", updatedData, addedData);
      if (updatedData?.length > 0 || addedData?.length > 0 || this.deleteList?.length > 0) {
        this.saveHoles(updatedData, addedData)
      }
      else {
        this.showOpenHolesList();
      }
  }


  saveHoles(updatedData, addedData) {
    /* api call for casing list here */


    this.wellIntervalID = this.wellInterval.intervalData?.WellboreSectionId
    let resultAdded = [];
    let resultUpdated = [];
    if (addedData.length !== 0) {
      addedData.forEach(element => {
        resultAdded.push({ MeasuredDepth: JSON.parse(element.MeasuredDepth), HoleDiameter: JSON.parse(element.HoleDiameter), order: 9, FrictionFactor: JSON.parse(element.FrictionFactor) })
      });
    } else if (updatedData.length !== 0) {
      updatedData.forEach(element => {
        resultUpdated.push({ MeasuredDepth: JSON.parse(element.MeasuredDepth), HoleDiameter: JSON.parse(element.HoleDiameter), order: 9, FrictionFactor: JSON.parse(element.FrictionFactor), OpenHoleIntervalId: element.OpenHoleIntervalId })
      });
    }
    let payloadOpenHole: any = {
      "addOpenHoles": [...resultAdded],
      "updateOpenHoles": [...resultUpdated]
    }

    this.wellInterval.addOpenHolesList(this.wellIntervalID, payloadOpenHole).subscribe({
      next: (data) => {
        console.log(data);
        this.showOpenHolesList();
        this.toastr.success("Open Hole Details Saved Successfully");
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });
  }


  showOpenHolesList() {
    /* api call for casing list here */
    this.wellIntervalID = this.wellInterval.intervalData?.WellboreSectionId
    let type = 'open_hole'
    this.wellInterval.getOpenHolesList(this.wellIntervalID, type).subscribe({
      next: (data) => {
        console.log(data);
        if (data.result.length !== 0) {
          this.tableDataHoles = data.result;
        }
        this.originalData = JSON.parse(JSON.stringify(this.tableDataHoles));
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
        this.tableDataHoles = [];
      }

    });

  }//end of function


  wellintervalLists() {
    this.wellInterval.wellIntervalsData.subscribe(res => {
      if (res.length !== 0 && res !== '0') {
        this.allWellIntervals = res
      }
    })
  }

  setWellIntervalModel() {
    this.wellIntervalModel = this.wellInterval.intervalData?.Name
    console.log(this.wellIntervalModel)

  }
  selectionChangeForOpenHoles(event) {
    if (event.value == 'Casing') {
      this.route.navigateByUrl("/dashboard/wells/well-intervals/casing");
    }

  }

  wellIntervalSelection(event) {
    let x = this.wellInterval.intervalData
    console.log(x);
    this.allWellIntervals.forEach(ele => {
      let name = ele['Name'];
      if (name == event) {
        this.wellInterval.intervalData = ele;
      }
    })
    this.showOpenHolesList();
  }


}
