import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenHolesComponent } from './open-holes.component';

describe('OpenHolesComponent', () => {
  let component: OpenHolesComponent;
  let fixture: ComponentFixture<OpenHolesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenHolesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpenHolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
