import { map } from 'rxjs/operators';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { WellInterval } from 'src/app/core/interfaces/well-Interval.interface';
import { WellIntervalService } from 'src/app/core/services/wellinterval.service';
import { MatDialog } from '@angular/material/dialog';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'lodash';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-well-intervals',
  templateUrl: './well-intervals.component.html',
  styleUrls: ['./well-intervals.component.scss']
})
export class WellIntervalsComponent implements OnInit {
  // updateColumn: boolean = true;
  // deleteColumn: boolean = true;
  actionColumn: boolean = true;
  tableData: Array<{}> = [
    // { Name: 'Test 1', active: true },
    // { Name: 'Test 2', active: false },
    // { Name: 'Test 3', active: false },
  ];
  // @Input() tableData: Array<any> = [];//to get table data
  // @Input() tableColumns: any[];//to get table columns
  // @Input() actionColumn: boolean;//flag to show actions column
  @Input() cloneColumn: boolean;//flag to show clone button
  @Input() activateColumn: boolean;//flag to show activate button
  @Input() redirectColumn: boolean;//flag to show redirect button
  @Input() kellyBushing;// KellyBushing value for calculation
  @Input() groundLevel;//GroundLevel value for calculation
  @Output()
  actionEvent = new EventEmitter<any>();
  @Output()
  getTableEvent = new EventEmitter<any>();
  @ViewChild('inputRef') inputRef!: ElementRef;

  actionButtons: any[] = [];
  displayedColumns: Array<any> = [];
  editableCell: { rowIndex: number; column: string } | null = null;
  draggedRowIndex: number;
  originalValueListHashMap: any = [];
  clonePermitted: boolean = false;
  deletePermitted: boolean = false;
  activatePermitted: boolean = false;
  clonePayload: object;
  deletePayload: object;
  activatePayload: object;
  WellboreSectionIds: Array<number> = [];
  @Output()
  updateRow = new EventEmitter<any>();

  @Output()
  deleteRow = new EventEmitter<any>();



  originalData: any;
  isChanged: boolean;
  currentData: any = [];
  deleteList: Array<{}> = [];

  @ViewChild('stepper') stepper: MatStepper
  constructor(private WellInterval: WellIntervalService,
    private dialog: MatDialog,
    private route: Router,
    private toastr: ToastrService) { }

  tableColumns: Column[] = [
    { columnDef: "Name", header: "Well Intervals", sticky: true, editable: true, cell: (element: Record<string, any>) => `${element['Name']}` }
  ]
  @Output()
  wellIntervalsList = new EventEmitter<any>();

  ngOnInit(): void {
    this.WellInterval.setIntervals(true);
    this.emitWellIntervals();
    this.getWellintervalList();
    this.originalData = JSON.parse(JSON.stringify(this.tableData))


  }

  emitWellIntervals() {
    this.WellInterval.getwellIntervalsdata(this.tableData)
  }

  save() {

    if (this.clonePermitted) {
      this.cloneApiCall(this.clonePayload);
    }
    if (this.deletePermitted) {
      this.deleteApiCall(this.deletePayload);
    }
    if (this.activatePermitted) {
      this.ActivateWellPath(this.activatePayload);
    }
    let updatedData = _.filter(this.currentData, (item) => {
      return item.isUpdated && !(_.has(item, 'isAdded'))
    });
    updatedData = _.map(updatedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded', 'isUpdated']);
    });


    let addedData = _.filter(this.currentData, { isAdded: true });
    addedData = _.map(addedData, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded', 'isUpdated']);
    });

    console.log("save", updatedData, addedData);
    if (updatedData.length > 0 || addedData.length > 0 || this.deleteList.length > 0) {
      this.saveAPIcall(updatedData, addedData)
    }
    else {
      this.getWellintervalList();
    }

  }

  saveAPIcall(updatedData, addedData) {

    /**
        * Add call
        */

    let resultAdded = [];
    let resultUpdated = [];
    if (addedData.length !== 0) {
      addedData.forEach(element => {
        resultAdded.push({ Name: element.Name })
      });
    } else if (updatedData.length !== 0) {
      updatedData.forEach(element => {
        resultUpdated.push({ Name: element.Name, WellboreSectionId: element.WellboreSectionId })
      });
    }
    let addPayload = {
      "addWellIntervals": [...resultAdded],
      "updateWellIntervals": [...resultUpdated]
    }
    this.WellInterval.addWellintervalList(addPayload).subscribe({
      next: (res) => {
        if (res) {
          console.log(res)
          this.getWellintervalList();
          this.toastr.success("Well Interval Details Saved Successfully");
          this.deleteList = [];
        } else {
          console.log('error')
          this.toastr.error("Something Went Wrong");
        }
      },
      error: (error) => {
        console.log("WellIntervals", error.error.result);
      }
    })//end of service call

  }

  /* add empty row for well interval */
  addRow() {

    console.log("added row");

    console.log("added row");
    let wellintervalObj: WellInterval = {
      "Active": false,
      "Key": "568596CF-9899-42A5-973F-E99393CA24B4",
      "ManagedByWellActivity": true,
      "WellboreSectionHeaderId": 3,
      "WellboreSectionId": 4,
      "isAdded": true
    }

    // this.tableData.push({});
    // this.tableData = [...this.tableData];
    this.tableData.push(wellintervalObj);
    this.tableData = [...this.tableData];

  }// function ends

  /**
     * To refresh the well path table
     */
  reset() {
    this.getWellintervalList();// for resetting of table

  }//end of function

  /* api call for well interval list */
  getWellintervalList() {

    this.WellInterval.getWellintervalList().subscribe({
      next: (res) => {
        if (res) {
          console.log(res)
          this.tableData = res.result
          this.originalData = JSON.parse(JSON.stringify(this.tableData));
          this.WellInterval.getwellIntervalsdata(this.tableData)
          this.deleteList = [];
        } else {
          console.log('error')
        }
      },
      error: (error) => {
        console.log("WellIntervals", error.error.result);
        // this.toastr.error("Something Went Wrong");
        this.tableData = [];
      }
    })//end of service call

  }


  operateAction(eve) {

    let operation = eve.action;
    let payload = eve.data;
    switch (operation) {
      case 'viewpoints': this.viewCasingList(payload); break;
      case 'delete': this.deleteMethod(payload); break;
      case 'clone': this.cloneWellBoreMethod(payload); break;
      case 'activate': this.ActivateWellPath(payload);
    }
  }//end of function

  viewCasingList(payload) {

    console.log(payload)
    this.WellInterval.intervalData = payload
    this.route.navigateByUrl("/dashboard/wells/well-intervals/casing");

  }//end of function
  /**
 * emitter event call to check updated data in table
 */
  getTableData(event) {

    let isChanged = this.checkChanges(event.data);
    return isChanged;

  }//end of function

  /**
* this function compares original data and changes made in
* table
*/
  checkChanges(data) {

    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });
    return isDataChanged;

  }//end of function


  deleteRowMethod(row) {
    this.deleteRow.emit(row);
  }


  /**
* Method to clone the well path
*/
  cloneWellBoreMethod(payload) {

    console.log("cloned row");
    console.log("cloned row", payload);
    this.tableData.push(payload);
    this.tableData = JSON.parse(JSON.stringify(this.tableData))
    // this.originalData = JSON.parse(JSON.stringify(this.tableData))
    this.tableData = [...this.tableData]
    // this.tableDataHoles.push(wellIntervalHolesObj);

    this.clonePayload = {
      "addWellIntervals": [{ Name: payload.Name }],
      "updateWellIntervals": [],
    }
    this.clonePermitted = true;
    // this.cloneApiCall(clonePayload);

  }// method ends

  /**
  * Clone wellpath Api call
  */

  cloneApiCall(clonePayload) {
    /**
  * Add call
  */
    this.WellInterval.addWellintervalList(clonePayload).subscribe({
      next: (data) => {
        console.log(data);
        this.toastr.success("Open Hole Cloned Successfully");
        this.getWellintervalList();
        this.clonePermitted = false;
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });

  }

  deleteMethod(payload) {
    this.deletePayload = payload;
    if (payload) {
      let index = this.tableData.indexOf(payload);
      if (index > -1) {
        this.tableData.splice(index, 1);
        this.tableData = [...this.tableData];
        // this.toastr.success("Well Interval Deleted Successfully");
      }
    }

    /**
     * call delete API
     */
    this.deletePermitted = true;
    this.WellboreSectionIds.push(payload.WellboreSectionId);
    this.deletePayload = {
      deletedIds: [...this.WellboreSectionIds]
    }


  }//end of function

  deleteApiCall(payload) {

    this.WellInterval.deleteWellIntervalList(payload).subscribe({
      next: (data) => {
        console.log(data);
        this.getWellintervalList();
        this.toastr.success("Well Interval Deleted Successfully");
        this.deletePermitted = false;
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });
  }


  /**
       * call activate wellpath API
       */
  ActivateWellPath(activatePayload) {

    let status = {
      "Active": 1,
    };
    let id = activatePayload.WellboreSectionId
    this.WellInterval.activateWellInterval(id, status).subscribe({
      next: (data) => {
        console.log(data);
        this.toastr.success("Well Interval Activated Successfully");
        this.getWellintervalList();
      },
      error: (error) => {
        console.log(error);
        this.toastr.error("Something Went Wrong");
      }
    });

  }// end of the function




}
