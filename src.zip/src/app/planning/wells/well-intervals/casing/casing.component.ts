import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { WellInterval } from 'src/app/core/interfaces/well-Interval.interface';
import { WellIntervalService } from 'src/app/core/services/wellinterval.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'lodash';

@Component({
  selector: 'app-casing',
  templateUrl: './casing.component.html',
  styleUrls: ['./casing.component.scss']
})
export class CasingComponent implements OnInit {
  displayedColumns: Array<any> = [];
  isChanged: boolean;
  allWellIntervals: Array<{}>;
  wellIntervalModel: any;
  casingModel: string = 'Casing';
  casingType: Array<string>;
  currentData: Array<{}>;
  originalData: Array<{}>;
  deleteList: [];
  materialId: number;
  wellIntervalID: number;
  deletePermitted: boolean = false;
  deletePayload: object;
  CasingIntervalIds: any[] = [];
  payloadCloneCasing: object;
  clonePermitted: boolean = false;
  constructor(private wellInterval: WellIntervalService, private route: Router, private toastr: ToastrService) {
    this.casingType = ['Casing', 'Open Holes']
  }// end of constructor

  tableColumnsCasing: Array<WellInterval> = [
    { columnDef: 'TypeName', header: 'Type', editable: true, dropdown: true, cell: (element: Record<string, any>) => `${element['TypeName']}` },
    { columnDef: 'MaterialName', header: 'Material Name', editable: true, dropdown: true, cell: (element: Record<string, any>) => `${element['MaterialName']}` },
    { columnDef: 'OuterDiameter', header: 'Outer Diameter', editable: true, dropdown: false, cell: (element: Record<string, any>) => `${element['OuterDiameter']}` },
    { columnDef: 'NominalWeight', header: 'Nominal Weight', editable: true, dropdown: false, cell: (element: Record<string, any>) => `${element['NominalWeight']}` },
    { columnDef: 'InnerDiameter', header: 'Inner Diameter', editable: true, dropdown: false, cell: (element: Record<string, any>) => `${element['InnerDiameter']}` },
    { columnDef: 'SettingDepth', header: 'Setting Depth', editable: true, dropdown: false, cell: (element: Record<string, any>) => `${element['SettingDepth']}` },
    { columnDef: 'HangerDepth', header: 'Hanger Depth', editable: true, dropdown: false, cell: (element: Record<string, any>) => `${element['HangerDepth']}` },
    { columnDef: 'FrictionFactor', header: "Friction Factor", editable: true, dropdown: false, cell: (element: Record<string, any>) => `${element['FrictionFactor']}` },
  ];

  tableDataCasing: any = [
  ];
  ngOnInit(): void {

    this.wellintervalLists();
    this.setWellIntervalModel();
    if (this.wellInterval.intervalData?.WellboreSectionId !== undefined) {
      this.showCasingList();
    }
    this.displayedColumns = this.tableColumnsCasing.map((c) => c.columnDef);
    this.originalData = JSON.parse(JSON.stringify(this.tableDataCasing));

  }




  /* add empty row for well interval */
  addRow() {

    console.log("added row");
    console.log("added row");
    let CasingObj: any = {
      "Type": '',
      "OuterDiameter": '',
      "NominalWeight": '',
      "MaterialId": '',
      "SettingDepth": '',
      "HangerDepth": '',
      "Order": 9,
      "FrictionFactor": '',
      "isAdded": true
    }
    this.tableDataCasing.push(CasingObj);
    this.tableDataCasing = [...this.tableDataCasing];

  }// function ends

  /**
   * emitter event call to check updated data in table
   */
  getTableData(event) {

    console.log(event)
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function

  /**
   * this function compares original data and changes made in
   * table
   */
  checkChanges(data) {

    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });

    return isDataChanged;

  }//end of function

  deleteRowMethod(row) {
    // this.deleteRow.emit(row);
  }

  resetCasing() {
    this.showCasingList();
  }

  save() {

    if (this.clonePermitted) {
      this.cloneApiCall(this.payloadCloneCasing);
    }
    else if (this.deletePermitted) {
      this.deleteApiCall(this.deletePayload);
    }
      let updatedData = _.filter(this.currentData, (item: any) => {
        return item.isUpdated && !(_.has(item, 'isAdded'))
      });
      updatedData = _.map(updatedData, (item) => {
        // Use _.omit to remove the unwanted keys from each object
        return _.omit(item, ['isAdded', 'isUpdated']);
      });


      let addedData = _.filter(this.currentData, { isAdded: true });
      addedData = _.map(addedData, (item) => {
        // Use _.omit to remove the unwanted keys from each object
        return _.omit(item, ['isAdded', 'isUpdated']);
      });

      console.log("save", updatedData, addedData);
      if (updatedData?.length > 0 || addedData?.length > 0 || this.deleteList?.length > 0) {
        this.saveCasing(updatedData, addedData)
      }
      else {
        this.showCasingList();
      }
  }

  saveCasing(updatedData, addedData) {
    /* api call for casing list here */
    let id = this.wellInterval.intervalData?.WellboreSectionId
    let resultAdded = [];
    let resultUpdated = [];
    if (addedData.length !== 0) {
      addedData.forEach(element => {
        resultAdded.push({
          Type: element.Type, OuterDiameter: JSON.parse(element.OuterDiameter),
          order: 9, FrictionFactor: JSON.parse(element.FrictionFactor), InnerDiameter: JSON.parse(element.OuterDiameter),
          NominalWeight: JSON.parse(element.NominalWeight), MaterialId: JSON.parse(element.MaterialId),
          SettingDepth: JSON.parse(element.SettingDepth), HangerDepth: JSON.parse(element.HangerDepth)
        })
      });
    } else if (updatedData.length !== 0) {
      updatedData.forEach(element => {
        resultUpdated.push({
          Type: element.Type, OuterDiameter: JSON.parse(element.OuterDiameter),
          InnerDiameter: JSON.parse(element.OuterDiameter), order: 9,
          FrictionFactor: JSON.parse(element.FrictionFactor), NominalWeight: JSON.parse(element.NominalWeight),
          MaterialId: JSON.parse(element.MaterialId), SettingDepth: JSON.parse(element.SettingDepth),
          HangerDepth: JSON.parse(element.HangerDepth), WellIntervalId: JSON.parse(element.WellIntervalId)
        })
      });
    }
    let payloadCasing: any = {
      "addCasings": [...resultAdded],
      "updateCasings": [...resultUpdated]
    }

    this.wellInterval.addCasingList(id, payloadCasing).subscribe({
      next: (data) => {
        console.log(data);
        this.showCasingList();
        this.toastr.success("Casing Details Saved Successfully");
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });
  }
  operateAction(eve) {

    let operation = eve.action;
    let payload = eve.data;
    this.materialId = eve;
    switch (operation) {
      // case 'viewpoints': this.showSurveyPoints(payload); break;
      case 'delete': this.deleteMethod(payload); break;
      case 'clone': this.cloneMethod(payload); break;
      // case 'activate': this.ActivateWellPath(payload);
    }
  }//end of function

  /**
* Method to clone the casing row
*/
  cloneMethod(payload) {

    console.log("cloned row");
    console.log("cloned row", payload);
    this.tableDataCasing.push(payload);
    this.tableDataCasing = JSON.parse(JSON.stringify(this.tableDataCasing))
    this.tableDataCasing = [...this.tableDataCasing]
    // this.tableDataHoles.push(wellIntervalHolesObj);

    let resultAdded = [];

    resultAdded.push({
      Type: payload.Type, OuterDiameter: JSON.parse(payload.OuterDiameter),
      order: 9, FrictionFactor: JSON.parse(payload.FrictionFactor), InnerDiameter: JSON.parse(payload.OuterDiameter),
      NominalWeight: JSON.parse(payload.NominalWeight), MaterialId: JSON.parse(payload.MaterialId),
      SettingDepth: JSON.parse(payload.SettingDepth), HangerDepth: JSON.parse(payload.HangerDepth)
    })

    this.payloadCloneCasing = {
      "addCasings": [...resultAdded],
      "updateCasings": []
    }
    this.clonePermitted = true;
    // this.cloneApiCall(clonePayload);

  }// method ends

  /**
  * Clone casing Api call
  */

  cloneApiCall(clonePayload) {
    /**
  * Add call
  */
    // let id = this.wellInterval.intervalData?.WellboreSectionId
    // this.wellInterval.addCasingList(id, clonePayload).subscribe({
    //   next: (data) => {
    //     console.log(data);
    //     this.toastr.success("Casing Cloned Successfully");
    //     this.showCasingList();
    //     this.clonePermitted = false;
    //   },
    //   error: (error) => {
    //     console.log(error);
    //     this.toastr.error("Something Went Wrong");
    //   }

    // });

  }

  deleteMethod(payload) {

    if (payload) {
      let index = this.tableDataCasing.indexOf(payload);
      if (index > -1) {
        this.tableDataCasing.splice(index, 1);
        this.tableDataCasing = [...this.tableDataCasing];
        console.log(this.originalData)
      }
      if (payload.WellIntervalId !== null || undefined || '') {
        this.CasingIntervalIds.push(payload.WellIntervalId);
        this.deletePayload = {
          deletedIds: [...this.CasingIntervalIds],
          type: 'casing'
        }
        this.deletePermitted = true;
      }


      // this.deleteApiCall(payload);
    }

  }//end of function
  deleteApiCall(deletePayload) {
    /**
       * call delete API
       */
    this.wellIntervalID = this.wellInterval.intervalData?.WellboreSectionId
    this.wellInterval.deleteOpenHolesList(this.wellIntervalID, deletePayload).subscribe({
      next: (data) => {
        console.log(data);
        this.showCasingList();
        this.toastr.success("Casing Deleted Successfully");
        this.deletePermitted = false;
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
      }

    });
  }

  /* To get well intervals names list using observable */
  wellintervalLists() {
    this.wellInterval.wellIntervalsData.subscribe(res => {
      if (res.length !== 0 && res !== '0') {
        this.allWellIntervals = res;
        console.log( this.allWellIntervals)
      }
    })

  }
  setWellIntervalModel() {

    this.wellIntervalModel = this.wellInterval.intervalData?.Name
    console.log(this.wellIntervalModel)

  }

  wellIntervalSelection(event) {
    let x = this.wellInterval.intervalData
    console.log(x);
    this.allWellIntervals.forEach(ele => {
      let name = ele['Name'];
      if (name == event) {
        this.wellInterval.intervalData = ele;
      }
    })
    this.showCasingList();

  }

  /* Change detection function for open holes and casing dropdown */
  selectionChangeForHoles(event) {
    console.log(event);
    if (event.value == 'Open Holes')
      // this.wellIntervalModel = this.wellInterval.intervalData?.Name
      this.route.navigateByUrl("/dashboard/wells/well-intervals/open-holes");
  }

  showCasingList() {
    /* api call for casing list here */
    let id = this.wellInterval.intervalData?.WellboreSectionId;
    let type = 'casing';
    this.wellInterval.getCasingList(id, type).subscribe({
      next: (data) => {
        console.log(data);
        if (data.result.length !== 0) {
          this.tableDataCasing = data.result
          this.originalData = JSON.parse(JSON.stringify(this.tableDataCasing));
          this.wellInterval.setIntervals(data.result)
        }
      },
      error: (error) => {
        console.log(error);
        // this.toastr.error("Something Went Wrong");
        this.tableDataCasing = [];
      }

    });

  }//end of function



}

