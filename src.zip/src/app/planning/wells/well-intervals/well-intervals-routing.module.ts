import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WellIntervalsComponent } from './well-intervals.component';

import { CasingComponent } from './casing/casing.component';

import { OpenHolesComponent } from './open-holes/open-holes.component';



const routes: Routes = [
  {path: '', component: WellIntervalsComponent},
  {path: 'casing', component: CasingComponent},
  {path: 'open-holes', component: OpenHolesComponent}
]



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class WellIntervalsRoutingModule { }