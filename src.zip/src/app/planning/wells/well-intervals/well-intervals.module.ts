import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WellIntervalsRoutingModule } from './well-intervals-routing.module';
import { WellIntervalsComponent } from './well-intervals.component';
import { AllModule } from 'src/app/shared/all_modules';
import { CasingComponent } from './casing/casing.component';
import { OpenHolesComponent } from './open-holes/open-holes.component';


@NgModule({
  declarations: [
    WellIntervalsComponent,
    CasingComponent,
    OpenHolesComponent
  ],
  imports: [
    CommonModule,
    WellIntervalsRoutingModule,
    AllModule,
  ]
})
export class WellIntervalsModule { }
