import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, NgModel } from '@angular/forms';
import {Chart,registerables} from 'chart.js';
import { ToastrService } from 'ngx-toastr';
import { temperature } from 'src/app/core/interfaces/temperature.interface';
import { TemperatureService } from 'src/app/core/services/temperature.service';

import * as XLSX from 'xlsx';


//For registering chart
Chart.register(...registerables);

@Component({
  selector: 'app-temperature',
  templateUrl: './temperature.component.html',
  styleUrls: ['./temperature.component.scss']
})

export class TemperatureComponent implements OnInit {

  temperatureData: temperature[] = [];
  deletedRecords: temperature[] = [];
  updatedRecords: temperature[] = [];

  dataFromDialog: any;
  dialog: any;
  rows: any[] = [];
  showEditable: boolean = true;
  editRowId: any;
  VOForm: FormGroup;
  isEditableNew: boolean = true;
  TrueVerticalDepth:number;
  Temperature:number;
  canvas:any;
  ctx:any;
  yData:any[];
  xData:any[];
  temperatures:any;
  fileName= 'ExcelSheet.xlsx';
  update_temperatures:any=[];
  add_temperatures:any=[];
  GeothermalGradient:number;
  TemperatureConfigurationId:number;

  @ViewChild('myChart' ) myChart:any;
  @ViewChild('tvdft') _ngModeltvdft: NgModel;

  tableData: any[] = [];

  tableColumns = [
    { columnDef: "TrueVerticalDepth", header: "TVD.Ft", sticky: true, cell: (element: Record<number, any>) => `${element['TrueVerticalDepth']}`,editable:true },
    { columnDef: "Temperature", header: "Temperature", sticky: true, cell: (element: Record<number, any>) => `${element['Temperature']}`,editable:true }
  ]


  constructor(private temperatureService: TemperatureService,private toastr: ToastrService) {

  }


  ngOnInit(): void {
    this.myChart = null;
    this.getTemprature();
  } //end of ngOnInit function


  /**
   * Service call to get Tempratur list
   */
  getTemprature () {

    this.temperatureService.getTemperatureList().subscribe({

      next: (data) => {

        let result = data.result;
        this.temperatureData = [];

        result.forEach((record, index) => {

          this.temperatureData.push({
            TrueVerticalDepth: record.TrueVerticalDepth,
            Temperature: record.Temperature,
            GeothermalGradient: record.GeothermalGradient,
            TemperatureHeaderId: record.TemperatureHeaderId,
            TemperatureConfigurationId : record.TemperatureConfigurationId,
            isNewlyAdded: false,
            isUpdated: false,
            isDeleted: false,
            localRecordId: (index + 1)
          }); //end of push function
        }); //end of forEach loop

        this.temperatureData = [...this.temperatureData];

        this.charts({});

        console.log("this.temperatureData: " + JSON.stringify(this.temperatureData));
      },
      error: (error) => {

        console.log("Tempratures",error.error.result);
        this.temperatureData = error.error.result;
        this.toastr.error("Something went wrong during add");

      } //end of error
    }); //end of service call
  } //end of 'getTemprature' function


  /**
   * Below function will add a new row in the table.
   */
  addRow () {

    let temperatureRecord: temperature = new temperature();
    temperatureRecord.isNewlyAdded = true;
    temperatureRecord.localRecordId = this.temperatureData.length + 1;
    this.temperatureData.push(temperatureRecord);
    this.temperatureData = [...this.temperatureData];
  } //end of 'addRow' function


  /**
   * Below function will calculate gradient and show on the UI.
   */
  calculateGradientValue () {

    let resultData: temperature[] = [];

    this.temperatureData.forEach((record, index) => {

      if (index > 0) {

        let temperatureDifference = record.Temperature - this.temperatureData[index - 1].Temperature;
        let distanceDifference = record.TrueVerticalDepth - this.temperatureData[index - 1].TrueVerticalDepth;
        let gradient = temperatureDifference / distanceDifference;
        record.GeothermalGradient = gradient;
        // var gradient1 = gradient.toFixed(2)
        // record.GeothermalGradient = gradient1
        // record.GeothermalGradient =   Math.round(gradient);
          record.GeothermalGradient = JSON.parse(gradient.toFixed(2))  ;

        // record.GeothermalGradient = parseInt(Math.round(gradient * 100) / 100).toFixed(2);

      } else {

        record.GeothermalGradient = 0;
      } //end of if...else condition checking for the index

      resultData.push(record);
    }); //end of forEach loop iterating on 'this.temperatureData'

    this.temperatureData = [];
    this.temperatureData = [...resultData];

    console.log("this.temperatureData: " + JSON.stringify(this.temperatureData));

    this.tableColumns = [
      { columnDef: "TrueVerticalDepth", header: "TVD.Ft", sticky: true, cell: (element: Record<number, any>) => `${element['TrueVerticalDepth']}`,editable:true },
      { columnDef: "Temperature", header: "Temperature", sticky: true, cell: (element: Record<number, any>) => `${element['Temperature']}`,editable:true },
      { columnDef: "GeothermalGradient", header: "Gradient", sticky: true, cell: (element: Record<number, any>) => `${element['GeothermalGradient']}`,editable:true }
    ];
  } //end of 'calculateGradientValue' funtion


  /**
   * Below function will find newly added data for the well.
   */
  findNewlyAddedData () {

    let newData: temperature [] = [];

    this.temperatureData.forEach((record) => {

      if (record.isNewlyAdded == true) {

        newData.push(record);
      } //end of if condition checking it the record is newly added or not
    }); //end of forEach loop iterating on temperatureData

    return newData;
  } //end of 'saveNewlyAddedData' function


  /**
   * Below function will add the updated records.
   */
  addUpdatedRecords (event) {

    let tempRecord: temperature = event.data;
    // delete tempRecord.isDeleted;
    // delete tempRecord.isNewlyAdded;
    // delete tempRecord.isUpdated;

    console.log("Updated record: " + JSON.stringify(tempRecord));

    //Below line will remove updated record if it is already available in the array
    this.updatedRecords = this.updatedRecords.filter(record => record.localRecordId != tempRecord.localRecordId)

    this.updatedRecords.push(tempRecord);
  } //end of 'findUpdatedRecords' function


  /**
   * Below function will save new records.
   */
  saveNewRecords () {

    let newData = this.findNewlyAddedData();

    let addRecords = [];

    newData.forEach((record) => {

      delete record.isDeleted;
      delete record.isNewlyAdded;
      delete record.isUpdated;
      delete record.TemperatureConfigurationId;
      delete record.localRecordId;

      addRecords.push(record);
    }); //end of forEach loop


    let updatedRecords = [];

    this.updatedRecords.forEach((record) => {

      let newFlag = record.isNewlyAdded;

      delete record.isDeleted;
      delete record.isNewlyAdded;
      delete record.isUpdated;
      delete record.localRecordId;

      console.log("RECORD: " + JSON.stringify(record));
      if (record.TemperatureConfigurationId) {

        updatedRecords.push(record);
      } else {

        // addRecords.push(record);
      }
    }); //end of forEach loop

    console.log("newData: " + JSON.stringify(newData));

    let saveRecords = {
      "add_temperatures" : addRecords,
      "update_temperatures": updatedRecords
    }

     this.temperatureService.postTemperatureList(saveRecords).subscribe({

      next: (data) => {
        console.log("Tempratures",data);
        this.toastr.success("Temperature Saved Successfully");

        // this.temperatureData = data;
      },
      error: (error) => {
        console.log("Tempratures",error);
        this.toastr.error("Something went wrong during update");

        // this.temperatureData = error.error.result;
      }
    }); //end of service call
  } //end of 'saveNewRecords' function


  /**
   * Below code is for chart which display chart accorfing to the data
   */
  charts(event:any) {

    console.log("row" , event)

    if (this.myChart) {

      this.myChart.destroy();
    }

    let labels = [];
    let data = [];

    this.rows = [];
    this.rows = [...this.temperatureData];
    // this.rows = event.data;

    console.log("Table data: " + JSON.stringify(this.temperatureData));

    for (let index = 0; index < this.rows.length && this.rows.length > 1; index ++) {

      if (this.rows[index].TrueVerticalDepth && this.rows[index].Temperature) {

        labels.push(this.rows[index].TrueVerticalDepth);
        data.push(this.rows[index].Temperature);
      }
    } //end of for loop iterating on 'rows.length'

    if (labels.length > 1 && data.length > 1) {

      if (this.myChart) {

        this.myChart.destroy();

        this.myChart = new Chart("myChart", {

          type: 'line',
          data: {
            labels: data,
            datasets: [{
                label: 'Temperature Chart' , // Name the series
                data: labels, // Specify the data values array
                fill: true,
                borderColor: 'white', // Add custom color border (Line)
                borderWidth: 1, // Specify bar border width
                // backgroundColor:"red",
                 backgroundColor: 'rgba(255,255,255,0.1)'
            }]
          },

          options: {
            responsive: true, // Instruct chart js to respond nicely.
            maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
            scales: {
              // y1: {
              //   type: 'linear',
              //   display: true,
              //   position: 'right',

              // },

              x: {
                title: {
                  display:true,
                  text: 'Temprature',
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: 'white'
                },
                ticks: {
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D',
                },
              },
              x1: {
                position:'top',
                title: {
                  display:true,
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D'
                },
                ticks: {
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D',
                },
              },

              y: {

                position:'right',
                title: {
                  display:true,
                  text: 'True Vertical Depth',
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: 'white'
                },
                ticks: {
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D'
                }
              },
            },
            plugins: {
              legend: {
                  labels: {
                      // This more specific font property overrides the global property
                      font: {
                          size: 20,
                      },
                      color: 'white'
                  }
              },

          }
          },
        });
      } else {

        this.myChart = new Chart("myChart", {

          type: 'line',
          data: {
            labels: data,
            datasets: [{
                label: 'Temperature Chart' , // Name the series
                data: labels, // Specify the data values array
                fill: true,
                borderColor: 'white', // Add custom color border (Line)
                borderWidth: 1, // Specify bar border width
                // backgroundColor:"red",
                 backgroundColor: 'rgba(255,255,255,0.1)'
            }]
          },
          options: {
            responsive: true, // Instruct chart js to respond nicely.
            maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
            scales: {
              // y1: {
              //   type: 'linear',
              //   display: true,
              //   position: 'right',

              // },

              x: {
                title: {
                  display:true,
                  text: 'Temprature',
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: 'white'
                },
                ticks: {
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D',
                },
              },
              x1: {
                position:'top',
                title: {
                  display:true,
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D'
                },
                ticks: {
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D',
                },
              },

              y: {

                position:'right',
                title: {
                  display:true,
                  text: 'True Vertical Depth',
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: 'white'
                },
                ticks: {
                  font: {
                    size: 12,
                    weight: "bold"
                  },
                  color: '#7D7D7D'
                }
              },
            },
            plugins: {
              legend: {
                  labels: {
                      // This more specific font property overrides the global property
                      font: {
                          size: 20,
                      },
                      color: 'white'
                  }
              },
          }
          },
        });
      }
    }
  } //end of chart rendering function

  /**
   * Below function will save the data/changes.
   */
  save() {

    console.log("Save function is start......",this.temperatureData)
    this.GeothermalGradient = 5;

    this.add_temperatures = [...this.temperatureData]
    this.update_temperatures.push({});
    let obj = {
      "add_temperatures" : this.add_temperatures,
       "update_temperatures":this.update_temperatures
    }

     this.temperatureService.postTemperatureList(obj).subscribe({

      next: (data) => {
        console.log("Tempratures",data);
        this.toastr.success("Survey Points Saved Successfully");

        // this.temperatureData = data;
      },
      error: (error) => {
        console.log("Tempratures",error);
        this.toastr.error("Something went wrong during update");

        // this.temperatureData = error.error.result;
      }
    }); //end of service call
  } //end of 'save' function


  /**
   * Below function will export the details available in the table.
   */
  export() {

     let element = document.getElementById('excel-table');
     const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
    //  delete (ws['actions'])
     ws['!cols'] = [];
     ws['!cols'][2] = { hidden: true };
    //  ws['!cols'][3] = { hidden: true };
     /* generate workbook and add the worksheet */
     const wb: XLSX.WorkBook = XLSX.utils.book_new();
     XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

     /* save to file */
     XLSX.writeFile(wb, this.fileName);
  } //end of export function


  /**
   * Below function will delete record.
   */
  deleteRecord(event) {

    console.log("Delete event received: " + JSON.stringify(event));
    let deletedRecord: temperature = event.data;

    if (deletedRecord.isNewlyAdded) {


    } else {

      deletedRecord.isDeleted = true;

      for (let index = 0; index < this.temperatureData.length; index ++) {

        if (this.temperatureData[index].TemperatureConfigurationId == deletedRecord.TemperatureConfigurationId) {

          // this.temperatureData.splice(index,1);
        } // end of inner if condition matching TemperatureConfigurationId
      } //end of for loop

      this.deletedRecords.push(deletedRecord);
    } //end of if...else condition checking if the record is newly added or not

    this.charts({});
  } //end of deleteRecord


  /**
   * Below function will delete records.
   */
  deleteRecords() {

    console.log("DELETE RECORD FUNCTION: " + JSON.stringify(this.deletedRecords));
    for (let index = 0; index < this.deletedRecords.length; index ++) {

      this.temperatureService.deleteTemperatureRecord(this.deletedRecords[index].TemperatureConfigurationId).subscribe({

        next: (data) => {
          console.log("Tempratures",data);
          this.toastr.success("Tempratures Deleted Successfully");

          // this.temperatureData = data;
        },
        error: (error) => {
          console.log("Tempratures",error);
          this.toastr.error("Something went wrong");

          // this.temperatureData = error.error.result;
        }
      }); //end of service call
    } //end of for loop
  } //end of 'deleteRecords' function


  reset() {

  }

  gradient()
  {

  }
}