import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TemperatureRoutingModule } from './temperature-routing.module';
import { TemperatureComponent } from './temperature.component';
import { AllModule } from 'src/app/shared/all_modules';



@NgModule({
  declarations: [
    TemperatureComponent
  ],
  imports: [
    CommonModule,
    TemperatureRoutingModule,
    AllModule
  ]
})
export class TemperatureModule { }
