import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-tools',
  templateUrl: './custom-tools.component.html',
  styleUrls: ['./custom-tools.component.scss']
})
export class CustomToolsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
