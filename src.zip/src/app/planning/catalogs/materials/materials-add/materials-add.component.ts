/*  materials catalog Add/ Update Component
 */
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MaterialsService } from 'src/app/core/services/materials.service';

@Component({
  selector: 'app-materials-add',
  templateUrl: './materials-add.component.html',
  styleUrls: ['./materials-add.component.scss']
})
export class MaterialsAddComponent implements OnInit {
  status: string; //Flag To Add/ Update the table

  constructor(public dialogRef: MatDialogRef<MaterialsAddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { name: 'Suresh', animal: 'Tommy' },
    private materials: MaterialsService
  ) { }// constructor ends

  ngOnInit(): void {
    this.materials.materialStatus ? this.status = 'Add Materials' : this.status = 'Update Materials'
  }
  onNoClick(): void {

    /*To close add materials dialog */
    this.dialogRef.close();
    
  }
}
