 /*  materials catalog Delete Component
  */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-materials-delete',
  templateUrl: './materials-delete.component.html',
  styleUrls: ['./materials-delete.component.scss']
})
export class MaterialsDeleteComponent implements OnInit {

  constructor() { }// constructor ends

  ngOnInit(): void {
  }

}
