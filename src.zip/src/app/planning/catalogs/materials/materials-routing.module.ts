 /*  materials catalog Module routing
  */
import { MaterialsDeleteComponent } from './materials-delete/materials-delete.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaterialsListComponent } from './materials-list/materials-list.component';
import { MaterialsAddComponent } from './materials-add/materials-add.component';

const routes: Routes = [
  { path: '', component: MaterialsListComponent},
  { path: 'add-materials', component: MaterialsAddComponent },
  { path: 'delete-materials', component: MaterialsDeleteComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MaterialsRoutingModule { }
