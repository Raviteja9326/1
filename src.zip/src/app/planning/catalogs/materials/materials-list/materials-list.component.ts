/*  materials catalog List Component
 */
import { Component, OnInit } from '@angular/core';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Element } from 'src/app/core/interfaces/tableElements.interface';
import { MaterialsAddComponent } from '../materials-add/materials-add.component';
import { MatDialog } from '@angular/material/dialog';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-materials-list',
  templateUrl: './materials-list.component.html',
  styleUrls: ['./materials-list.component.scss']
})
export class MaterialsListComponent implements OnInit {
  /*  Basic table setup for materials catalog 
  */
  updateColumn: boolean = true;
  deleteColumn: boolean = true;
  tableData: Array<Element> = [];
  name: string;
  animal: string;
  displayedColumn: Array<Column> = [];
  tableColumns: Array<Column> = [
    { columnDef: 'MaterialId', header: 'Material Id', cell: (element: Record<string, any>) => `${element['MaterialId']}` },
    // { columnDef: 'MaterialName', header: 'MaterialName', cell: (element: Record<string, any>) => `${element['MaterialName']}` },
    { columnDef: 'Grade', header: 'Grade', cell: (element: Record<string, any>) => `${element['Grade']}` },
    { columnDef: 'Density', header: 'Density (ppg)', cell: (element: Record<string, any>) => `${element['Density']}` },
    { columnDef: 'SpecificHeatCapacity', header: `Specific Heat Capacity (Btu/(Ib-\xB0F))`, cell: (element: Record<string, any>) => `${element['SpecificHeatCapacity']}` },
    { columnDef: 'ThermalConductivity', header: 'Thermal Conductivity', cell: (element: Record<string, any>) => `${element['ThermalConductivity']}` },
    { columnDef: 'ModulusOfElasticity', header: 'Modulus Of Elasticity', cell: (element: Record<string, any>) => `${element['ModulusOfElasticity']}` },
    { columnDef: 'PoissonRatio', header: "Poisson's Ratio", cell: (element: Record<string, any>) => `${element['PoissonRatio']}` },
    { columnDef: 'ThermalExpansionCoefficient', header: 'Thermal Expansion Coefficient', cell: (element: Record<string, any>) => `${element['ThermalExpansionCoefficient']}` },
    { columnDef: 'YieldStress', header: 'Yield Stress', cell: (element: Record<string, any>) => `${element['YieldStress']}` },
    { columnDef: 'AnisotropicFactor', header: 'Anisotropic Factor', cell: (element: Record<string, any>) => `${element['AnisotropicFactor']}` },
    // { columnDef: 'Usage', header: 'Usage', cell: (element: Record<string, any>) => `${element['Usage']}` },
    // { columnDef: 'Symbol', header: 'Symbol', cell: (element: Record<string, any>) => `${element['Symbol']}` },
    // { columnDef: 'Action', header: 'Action', cell: (element: Record<string, any>) => `${element['Action']}` }
  ];
  constructor(private materials: MaterialsService,
    public dialog: MatDialog,
    private toastr: ToastrService) { }// constructor ends

  ngOnInit(): void {

    this.getMaterialsList();

  }

  /* Add Materials Dialog */
  openDialog(): void {

    this.materials.materialStatus = true
    const dialogRef = this.dialog.open(MaterialsAddComponent, {
      data: { name: this.name, animal: this.animal },
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
      this.materials.materialStatus = false
    });

  }// dialog ends

  /* Materials List function */
  getMaterialsList() {

    this.materials.getMaterialsList().subscribe({
      next: (res) => {
        if (res) {
          this.tableData = res.result;
        }
      },
      error: (error) => {
        this.toastr.error("Something Went Wrong");
      }//end of service call
    })

  }//  Function ends




}
