/*  materials catalog Module
 */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaterialsRoutingModule } from './materials-routing.module';
import { MaterialsAddComponent } from './materials-add/materials-add.component';
import { MaterialsDeleteComponent } from './materials-delete/materials-delete.component';
import { MaterialsListComponent } from './materials-list/materials-list.component';
import { AllModule } from 'src/app/shared/all_modules';

@NgModule({
  declarations: [
    MaterialsAddComponent,
    MaterialsDeleteComponent,
    MaterialsListComponent
  ],
  imports: [
    CommonModule,
    MaterialsRoutingModule,
    AllModule
  ]
})
export class MaterialsModule { }