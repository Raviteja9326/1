import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-connections',
  templateUrl: './custom-connections.component.html',
  styleUrls: ['./custom-connections.component.scss']
})
export class CustomConnectionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
