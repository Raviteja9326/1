import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CatalogsRoutingModule } from './catalogs-routing.module';
import { CatalogsComponent } from './catalogs.component';
import { MaterialsComponent } from './materials/materials.component';
import { CustomConnectionsComponent } from './custom-connections/custom-connections.component';
import { CentralizersComponent } from './centralizers/centralizers.component';
import { CustomToolsComponent } from './custom-tools/custom-tools.component';
import { AllModule } from 'src/app/shared/all_modules';
import { ConnectionsComponent } from './connections/connections.component';

@NgModule({
  declarations: [
    CatalogsComponent,
    MaterialsComponent,
    ConnectionsComponent,
    CustomConnectionsComponent,
    CentralizersComponent,
    CustomToolsComponent
  ],
  imports: [
    CommonModule,
    AllModule,
    CatalogsRoutingModule
  ]
})
export class CatalogsModule { }
