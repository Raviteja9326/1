import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centralizers',
  templateUrl: './centralizers.component.html',
  styleUrls: ['./centralizers.component.scss']
})
export class CentralizersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
