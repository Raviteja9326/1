import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CentralizersComponent } from './centralizers.component';

describe('CentralizersComponent', () => {
  let component: CentralizersComponent;
  let fixture: ComponentFixture<CentralizersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CentralizersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CentralizersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
