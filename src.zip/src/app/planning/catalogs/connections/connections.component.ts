import { Component, OnInit} from '@angular/core';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Connection } from 'src/app/core/interfaces/connectionElements.interface';
import { ConnectionService } from 'src/app/core/services/connection.service';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.scss']
})
export class ConnectionsComponent implements OnInit {
  tableColumns:  Array<Column>;
  tableData: Connection[] = [];

 
  constructor(private connectionService:ConnectionService) { }

  ngOnInit(): void {

   this.tableColumns=[
      { columnDef: 'ConnectionName', header: 'Connection Name', cell: (element: Record<string, any>) => `${element['ConnectionName']}` },
      { columnDef: 'tpr', header: 'Taper (inches/ft)', cell: (element: Record<string, any>) => `${element['tpr']}`},
      { columnDef: 'Drg', header: 'Relif Groove ,in', cell: (element: Record<string, any>) => `${element['Drg']}` },
      { columnDef: 'C', header: 'Pitch At Guage Point, in', cell: (element: Record<string, any>) => `${element['C']}` },
      { columnDef: 'S', header: 'Recommended Make Up Stress,psi', cell: (element: Record<string, any>) => `${element['S']}` },
      { columnDef: 'H', header: 'Thread Height', cell: (element: Record<string, any>) => `${element['H']}` },
      { columnDef: 'Srs', header: 'Root Truncation', cell: (element: Record<string, any>) => `${element['Srs']}` },
      { columnDef: 'BBBDia', header: 'Box Bore Back', cell: (element: Record<string, any>) => `${element['BBBDia']}` },
      { columnDef: 'Lpc', header: 'Length Of The Pin', cell: (element: Record<string, any>) => `${element['Lpc']}` },
      { columnDef: 'Qc', header: 'Nominal CounerBore', cell: (element: Record<string, any>) => `${element['Qc']}` },
      { columnDef: 'p', header: 'Lead Of Thread', cell: (element: Record<string, any>) => `${element['p']}` },
      { columnDef: 'f', header: 'Mating Surface friction coeff', cell: (element: Record<string, any>) => `${element['f']}` },
      { columnDef: 'Theta', header: '1/2 included Angle of Thread', cell: (element: Record<string, any>) => `${element['Theta']}` },

  ]

    this.connectionService.getConnectionList().subscribe({

        next: (data) => {
         this.tableData = data.result;
        },
        error: (error) => {
          console.log("coonn error",error.error.result);
          this.tableData = error.error.result;
        }
      
      });
  }

    

}
