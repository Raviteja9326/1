import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { LithologiesRoutingModule } from './lithologies-routing.module';

import { HttpClientModule } from '@angular/common/http';
import { AllModule } from 'src/app/shared/all_modules';
import { LithologiesComponent } from './lithologies.component';


@NgModule({
  declarations: [
   LithologiesComponent
  ],
  imports: [
    CommonModule,
    LithologiesRoutingModule,
    AllModule,
    HttpClientModule
  ],
 
})

export class LithologiesModule { 
   
}