import { Component, OnInit } from '@angular/core';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Lithology } from 'src/app/core/interfaces/lithology.interface';
import { LithilogiesService } from 'src/app/core/services/lithilogies.service';


@Component({
    selector: 'app-lithologies',
    templateUrl: './lithologies.component.html',
    styleUrls: ['./lithologies.component.scss']
})

export class LithologiesComponent implements OnInit {

    tableColumns:  Array<Column>;
    tableData: Lithology[] = [];
    constructor(private lithologiesService: LithilogiesService){

    }
    ngOnInit(): void {

      /**
       * Column definitions
       */
      this.tableColumns = [
      {columnDef:"LithologyName",header:"Lithology",cell: (element: Record<string, any>) => `${element['LithologyName']}`},
      {columnDef:"PoissonsRatio",header:"Poisson's Ratio",cell: (element: Record<string, any>) => `${element['PoissonsRatio']}`},
      {columnDef:"ModulusOfElasticity",header:"Young's Modulus, psi",cell: (element: Record<string, any>) => `${element['ModulusOfElasticity']}`},
      {columnDef:"PeakFrictionAngle",header:"Peak Friction Angle, °",cell: (element: Record<string, any>) => `${element['PeakFrictionAngle']}`},
      {columnDef:"PeakCohesion",header:"Peak Cohesion, psi",cell: (element: Record<string, any>) => `${element['PeakCohesion']}`},
      {columnDef:"ThermalExpansionCoefficient",header:"Thermal Expansion Coefficient",cell: (element: Record<string, any>) => `${element['ThermalExpansionCoefficient']}`},
      {columnDef:"BiotsCoefficient",header:"Biot's Coefficient",cell: (element: Record<string, any>) => `${element['BiotsCoefficient']}`},
      {columnDef:"TensileStrength",header:"Tensile Strength",cell: (element: Record<string, any>) => `${element['TensileStrength']}`},
      {columnDef:"CompressiveStrength",header:"UCS",cell: (element: Record<string, any>) => `${element['CompressiveStrength']}`},
      {columnDef:"Density",header:"Density",cell: (element: Record<string, any>) => `${element['Density']}`},
      {columnDef:"CompressionalSlowness",header:"VP",cell: (element: Record<string, any>) => `${element['CompressionalSlowness']}`},
      {columnDef:"ShearSlowness",header:"VS",cell: (element: Record<string, any>) => `${element['ShearSlowness']}`},
      {columnDef:"GammaRay",header:"GR",cell: (element: Record<string, any>) => `${element['GammaRay']}`},
      {columnDef:"SpecificHeatCapacity",header:"Specific Heat Capacity",cell: (element: Record<string, any>) => `${element['SpecificHeatCapacity']}`},
      {columnDef:"ThermalConductivity",header:"Thermal Conductivity",cell: (element: Record<string, any>) => `${element['ThermalConductivity']}`},
      {columnDef:"YieldStress",header:"Yield Stress",cell: (element: Record<string, any>) => `${element['YieldStress']}`},
      {columnDef:"AnisotropicFactor",header:"Anisotropic Factor",cell: (element: Record<string, any>) => `${element['AnisotropicFactor']}`},
    ];

    /**
     * Service call to get Lithologies list
     */
      this.lithologiesService.getLithologiesList().subscribe({

        next: (data) => {
          console.log("Lithologies",data.result);
          this.tableData = data.result;
        },
        error: (error) => {
          console.log("Lithologies",error.error.result);
          this.tableData = error.error.result;
        }

      });
     //end of service call


    }

}