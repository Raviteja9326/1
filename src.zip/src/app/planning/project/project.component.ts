import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subject, takeUntil } from 'rxjs';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Project } from 'src/app/core/interfaces/project.interface';
import { ProjectService } from 'src/app/core/services/project.service';
import { ProjectAddInfoComponent } from './project-add-info/project-add-info.component';
import { DatePipe } from '@angular/common';
import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent implements OnInit, OnDestroy {

  isLinear:boolean = false;
  private readonly _destroying$ = new Subject<void>();
  tableColumns:  Array<Column>;
  tableData: Project[] = [];

  constructor(public dialog: MatDialog, private proj:ProjectService, private datePipe: DatePipe,private ngxLoader: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.getapicallofprojectlist();
  }

tabledynamicData(){
  this.tableColumns = [
    {columnDef:"ProjectName",header:"Project Name",cell: (element: Record<string, any>) => `${element['ProjectName']}`},
    {columnDef:"WellName",header:"Well Name",cell: (element: Record<string, any>) => `${element['WellName']}`},
    {columnDef:"Lease",header:"Lease",cell: (element: Record<string, any>) => `${element['Lease']}`},
    {columnDef:"Field",header:"Field",cell: (element: Record<string, any>) => `${element['Field']}`},
    {columnDef:"UniqueWellID",header:"Unique Well ID",cell: (element: Record<string, any>) => `${element['UniqueWellID']}`},
    {columnDef:"WellLicense",header:"Well License",cell: (element: Record<string, any>) => `${element['WellLicense']}`},
    {columnDef:"APINumber",header:"Api Number",cell: (element: Record<string, any>) => `${element['APINumber']}`},
    {columnDef:"RigName",header:"Rig Name",cell: (element: Record<string, any>) => `${element['RigName']}`},
    {columnDef:"OperatingCompany",header:"Operator Company",cell: (element: Record<string, any>) => `${element['OperatingCompany']}`},
    {columnDef:"RigContractor",header:"Rig contactor",cell: (element: Record<string, any>) => `${element['RigContractor']}`},
    {columnDef:"JobType",header:"Job Type",cell: (element: Record<string, any>) => `${element['JobType']}`},
    {columnDef:"Country",header:"Country",cell: (element: Record<string, any>) => `${element['Country']}`},
    {columnDef:"Region",header:"Region",cell: (element: Record<string, any>) => `${element['Region']}`},
    {columnDef:"GeoLatitude",header:"Latitude",cell: (element: Record<string, any>) => `${element['GeoLatitude']}`},
    {columnDef:"GeoLongitude",header:"Longitude",cell: (element: Record<string, any>) => `${element['GeoLongitude']}`},
    {columnDef:"TimeZoneId",header:"TimeZone",cell: (element: Record<string, any>) => `${element['TimeZoneId']}`},
    {columnDef:"SpudDate",header:"Spud Date",cell: (element: Record<string, any>) => { const spudDate = new Date(element['SpudDate']);
  return this.datePipe.transform(spudDate, 'mediumDate');
  }},
  ];
}

getapicallofprojectlist() {
  this.ngxLoader.start();
  this.tabledynamicData();
  this.proj.GetprojectApi().pipe(takeUntil( this._destroying$)).subscribe({
    next: (data) => {
    this.tableData = data.result;
    this.ngxLoader.stop();
  },
  error: (error) => {
    console.log("Project",error.error.result);
    this.tableData = [];
  }
  });
  }

  addProjects(){
    const projectData = this.tableData;
    const dialogRef = this.dialog.open(ProjectAddInfoComponent, {
      width: 'auto',
      disableClose: false,
      autoFocus: false,
      data: {projectData},
      position: {
        top: '10px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getapicallofprojectlist();
    });
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }

}
