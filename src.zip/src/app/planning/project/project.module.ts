import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectRoutingModule } from './project-routing.module';
import { ProjectComponent } from './project.component';
import { AllModule } from 'src/app/shared/all_modules';
import { ProjectAddInfoComponent } from './project-add-info/project-add-info.component';


@NgModule({
  declarations: [
    ProjectComponent,
    ProjectAddInfoComponent
  ],
  imports: [
    CommonModule,
    ProjectRoutingModule,
    AllModule
  ],
})
export class ProjectModule { }
