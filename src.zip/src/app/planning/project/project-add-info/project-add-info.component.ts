import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable, startWith,map, Subject, takeUntil } from 'rxjs';
import { Country } from 'src/app/core/enum/country.enum';
import { Region } from 'src/app/core/enum/region.enum';
import { ProjectService } from 'src/app/core/services/project.service';

@Component({
  selector: 'app-project-add-info',
  templateUrl: './project-add-info.component.html',
  styleUrls: ['./project-add-info.component.scss']
})
export class ProjectAddInfoComponent implements OnInit, OnDestroy {

  countryKeys: string[] = Object.values(Country).filter(value => typeof value === 'string') as string[];
  regionKeys: string[] = Object.values(Region).filter(value => typeof value === 'string') as string[];
  private readonly _destroying$ = new Subject<void>();
  projects: any[] = [];
  projectsfilter: Observable<any[]>;
  borewellfilter: Observable<any[]>;

  constructor(private _fb:FormBuilder, public dialogRef: MatDialogRef < ProjectAddInfoComponent> , @Inject(MAT_DIALOG_DATA) public data: any = [], private proj:ProjectService, private ngxLoader: NgxUiLoaderService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getprojectlist()
  }

  project_form = this._fb.group({
    ProjectName:["",[Validators.required]],
    WellName:["",[Validators.required]],
    borewellName:["",[Validators.required]],
    Lease:["",[Validators.required]],
    Field:["",[Validators.required]],
    UniqueWellID:["",[Validators.required]],
    WellLicense:["",[Validators.required]],
    APINumber:["",[Validators.required]],
    RigName:["",[Validators.required]],
    OperatingCompany:["",[Validators.required]],
    RigContractor:["",[Validators.required]],
    JobType:["",[Validators.required]],
    Country:["",[Validators.required]],
    Region:["",[Validators.required]],
    GeoLatitude:["",[Validators.required]],
    GeoLongitude:["",[Validators.required]],
    TimeZoneId:["",[Validators.required]],
    SpudDate:["",[Validators.required]]
  })


  onCancel()
  {
    this.dialogRef.close();
  }

   getprojectlist(){
    this.projects = this.data.projectData;
    this.projectsfilter = this.project_form.controls.ProjectName.valueChanges.pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value?.['ProjectName']),
      map(projectName => projectName ? this.doFilter(projectName) : this.projects.slice())
    );
    this.borewellfilter = this.project_form.controls.borewellName.valueChanges.pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value?.['borewellName']),
      map(borewellName => borewellName ? this.doFilterwell(borewellName) : this.projects.slice())
    );
   }

   doFilter(value: string): any[] { // Specify the return type explicitly
    const filterValue = value.toLowerCase();
    return this.projects.filter(option =>
      option.ProjectName.toLowerCase().includes(filterValue)
    );
  }

  doFilterwell(value: string): any[] { // Specify the return type explicitly
    const filterValue = value.toLowerCase();
    return this.projects.filter(option =>
      option.WellName.toLowerCase().includes(filterValue)
    );
  }

  displayFn(project: any): string {
    return project && project.ProjectName ? project.ProjectName : '';
  }

  displayFnwell(project: any): string {
    return project && project.WellName ? project.WellName : '';
  }

  projectsubmit(){
    if (!this.project_form.valid) {
      Object.keys(this.project_form.controls).forEach(field => {
        const control = this.project_form.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    }
    else if (this.project_form.valid) {
      console.log(this.project_form.value)
    this.ngxLoader.start();


    const data = {
      wellData: {
        'IsActivationByWellActivityEnabled' : 0,
    'IsMarkedForReprocessing' : 1,
    'WellId' : this.project_form.value.borewellName['WellId'],
    'TimeZoneId' : '1',
    'UseKPIGroups' : 1,
    'WPTSId' : 1,
    'JobType' : 1,
    'Region' : 1,
    'Country' : 1,
    'WellName' : this.project_form.value.WellName,
    'Lease' : this.project_form.value.Lease,
    'Field' : this.project_form.value.Field,
    'WellLicense' : this.project_form.value.WellLicense,
    'APINumber' : this.project_form.value.APINumber,
    'RigName' : this.project_form.value.RigName,
    'OperatingCompany' : this.project_form.value.OperatingCompany,
    'RigContractor' : this.project_form.value.RigContractor,
    'GeoLatitude' : this.project_form.value.GeoLatitude,
    'GeoLongitude' : this.project_form.value.GeoLongitude,
      },
      projectData: {
        'Name' : this.project_form.value.ProjectName
      }
    };
console.log(this.project_form.value.ProjectName)
    this.proj.PostprojectApi(data).pipe(takeUntil( this._destroying$)).subscribe({
      next: (data) => {
        this.onCancel();
        this.ngxLoader.stop();
        this.toastr.success(data.message);

    },
    error: (error) => {
      console.log("Project",error.error.result);
      this.ngxLoader.stop();
    }
    });
  }
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
