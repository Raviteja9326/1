import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BhaTableComponent } from './bha-table.component';

describe('BhaTableComponent', () => {
  let component: BhaTableComponent;
  let fixture: ComponentFixture<BhaTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BhaTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BhaTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
