import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WorkstringComponent } from './workstring.component';
import { DrillstringTableComponent } from './drillstring-table/drillstring-table.component';
import { BhaTableComponent } from './bha-table/bha-table.component';

const routes: Routes = [
  {path:'', component:WorkstringComponent, children:[]},
  {path:'drillstring', component:DrillstringTableComponent},
  {path:'bha', component:BhaTableComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorkstringRoutingModule { }
