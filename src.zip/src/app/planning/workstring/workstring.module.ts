import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WorkstringRoutingModule } from './workstring-routing.module';
import { WorkstringComponent } from './workstring.component';
import { AllModule } from 'src/app/shared/all_modules';
import { DrillstringTableComponent } from './drillstring-table/drillstring-table.component';
import { BhaTableComponent } from './bha-table/bha-table.component';


@NgModule({
  declarations: [
    WorkstringComponent,
    DrillstringTableComponent,
    BhaTableComponent
  ],
  imports: [
    CommonModule,
    WorkstringRoutingModule,
    AllModule
  ]
})
export class WorkstringModule { }
