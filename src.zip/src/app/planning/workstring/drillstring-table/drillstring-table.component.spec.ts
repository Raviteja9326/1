import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrillstringTableComponent } from './drillstring-table.component';

describe('DrillstringTableComponent', () => {
  let component: DrillstringTableComponent;
  let fixture: ComponentFixture<DrillstringTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrillstringTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DrillstringTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
