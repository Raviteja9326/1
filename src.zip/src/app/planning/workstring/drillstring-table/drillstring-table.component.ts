import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

export interface PeriodicElement {
  description: string;
  qty: number;
  bottom: string;
  top: string;
  od: number;
  minid:number;
  max0:number;
  item:number;
  total:number;
  acc:number;
  nw:number;
  adj:number;
  totalweight:number;
  Acc:number
}

const ELEMENT_DATA: PeriodicElement [] = [
  {description: "E756.7", qty: 1, bottom: 'NC26', top: 'NC26', od:2.375, minid:1.750,max0:3.050,item:90.2,total:1.23,acc:90,nw:6.65,adj: 1.23,totalweight:32.91,Acc:12.78},
  {description: "E756.7", qty: 2, bottom: 'NC26', top: 'NC26', od:2.375, minid:1.750,max0:3.050,item:90.2,total:1.23,acc:90,nw:6.65,adj: 1.23,totalweight:32.91,Acc:12.78},
];


@Component({
  selector: 'app-drillstring-table',
  templateUrl: './drillstring-table.component.html',
  styleUrls: ['./drillstring-table.component.scss']
})
export class DrillstringTableComponent implements OnInit {

 isChecked: boolean = false;
  displayedColumns: string[] = [ 'description','qty','bottom','top','od','minid','max0','item','total','acc','nw','adj','totalweight','Acc','group','centralizers','Actions'];
  dataSource = ELEMENT_DATA;

  constructor(private route:Router) { }

  ngOnInit(): void {
  }



}
