import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkstringComponent } from './workstring.component';

describe('WorkstringComponent', () => {
  let component: WorkstringComponent;
  let fixture: ComponentFixture<WorkstringComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkstringComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkstringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
