import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-info-delete-popup',
  templateUrl: './job-info-delete-popup.component.html',
  styleUrls: ['./job-info-delete-popup.component.scss']
})
export class JobInfoDeletePopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
