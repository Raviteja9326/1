import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobInfoDeletePopupComponent } from './job-info-delete-popup.component';

describe('JobInfoDeletePopupComponent', () => {
  let component: JobInfoDeletePopupComponent;
  let fixture: ComponentFixture<JobInfoDeletePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobInfoDeletePopupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobInfoDeletePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
