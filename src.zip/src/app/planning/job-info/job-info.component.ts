import { Component, OnInit } from '@angular/core';
import {MatTabsModule} from '@angular/material/tabs'
@Component({
  selector: 'app-job-info',
  templateUrl: './job-info.component.html',
  styleUrls: ['./job-info.component.scss'],
 
})
export class JobInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
