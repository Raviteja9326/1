import { Component, OnInit } from '@angular/core';
import { FormBuilder} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { JobInfoDetailsComponent } from '../job-info-details/job-info-details.component';
import { JobInfoService } from 'src/app/core/services/job-info-form.service';
import {FormGroup, FormControl} from '@angular/forms'
import { jobInfo } from 'src/app/core/interfaces/jobInfo.interface';
import { MenulistService } from 'src/app/core/services/menulist.service';
import { ToastrService } from 'ngx-toastr';
import { roleDefinitions } from '../../../core/constants/role.constants';
import { Country } from '../../../core/enum/country.enum';
import { Region } from '../../../core/enum/region.enum';
import {JobType} from '../../../core/enum/jobType.enum';
import {Timezone} from '../../../core/enum/timezone.enum';


// import { roleDefinitions } from '../../../core/constants/role.constants';
// import { ToastrService } from 'ngx-toastr';
interface wellpath{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-job-info-list',
  templateUrl: './job-info-list.component.html',
  styleUrls: ['./job-info-list.component.scss']
})

export class JobInfoListComponent implements OnInit {

  countryKeys: string[];
  countryList: object = {};
  country = Country;

  regionKeys: string[];
  regionList: object = {};
  region = Region;


  jobtypeKeys: string[];
  jobtypeList: object = {};
  jobtype = JobType;


  timezoneKeys: string[];
  timezoneList: object = {};
  timezone = Timezone;



  jobpathList: any[] = [];
  loading:boolean = false;
  isLinear:boolean = false;
  selectedNavItem: string = 'file';
  regForm = new FormGroup({
    // WellId: new FormControl(''),
    // ProjectId : new FormControl(''),
    ProjectName : new FormControl(''),
    jobPathModel: new FormControl(''),
    WellName: new FormControl(''),
    Lease: new FormControl(''),
    Field : new FormControl(''),
    UniqueWellID: new FormControl(''),
    WellLicense: new FormControl(''),
    APINumber : new FormControl(''),
    RigName: new FormControl(''),
    OperatingCompany: new FormControl(''),
    RigContractor : new FormControl(''),
    JobType: new FormControl(''),
    Country: new FormControl(''),
    Region: new FormControl(''),
    GeoLatitude:new FormControl(''),
  GeoLongitude:new FormControl(''),
  TimeZoneId:new FormControl(''),
  SpudDate: new FormControl(''),

  });

  ProjectName:any;
  WellName:any;
  Lease:any;
  Field:any;
  UniqueWellID:any;
  WellLicense:any;
  APINumber:any;
  RigName:any;
  OperatorCompany:any;
  RigContractor:any;
  JobType:any;
  Country:any;
  Region:any;
  selectedCountryId: string;
  selectedRegionId: string;
  selectedProjectId: number = 0;
  selectedWellId: number = 0;
  selectedJobTypeId: string;
  selectedTimezoneId: string;
  GeoLatitude:any;
  GeoLongitude:any;
  TimeZoneId:any;
  SpudDate:any;
  isEditableNew: boolean = true;
  personnelData: jobInfo[] = [];
  deletedRecords: jobInfo[] = [];
  projectList:boolean = false;

  
  roles = {
    0: 'Creator',
    1: 'Reviewer',
    2: 'Approver',
    3: 'CFS Operator',
    4: 'Client Representative',
    5: 'Crew',
    6: 'DAQ Operator',
    7: 'Data Engineer',
    8: 'DD Coordinator',
    9: 'Derrickhand'
}; //end of 'roles'


  tableData: any[] = [];

  tableColumns = [
    { columnDef: "Name", header: "Name", sticky: true,editable:true, cell: (element: Record<string, any>) => `${element['Name']}` },
    { columnDef: "EmployeeNumber", header: "Employee Number",editable:true, sticky: true, cell: (element: Record<string, any>) => `${element['EmployeeNumber']}` },
    { columnDef: "PersonnelRoleName", header: "Personnel Role", sticky: true,editable:true, cell: (element: Record<string, any>) => `${element['PersonnelRoleName']}` }
  ]

  constructor(public dialog: MatDialog, private _fb: FormBuilder,
    private route:Router, private _dialog: MatDialog,
    private jobInfoService : JobInfoService, private menu:MenulistService, private toastr: ToastrService,
    ) {

      this.regForm = this._fb.group({
        // ProjectId:[""],
        // WellId:[""],
      ProjectName:[""],
      jobPathModel:[""],
      WellName:[""],
      Lease:[""],
      Field:[""],
      UniqueWellID:[""],
      WellLicense:[""],
      APINumber:[""],
      RigName:[""],
      OperatingCompany:[""],
      RigContractor:[""],
      JobType:[""],
      Country:[""],
      Region:[""],
      GeoLatitude:[""],
      GeoLongitude:[""],
      TimeZoneId:[""],
      SpudDate:[""],
      
    });

    
    /**
   * Below function will bind enum country data.
   */

    this.countryKeys = Object.keys(this.country).filter((f) => !isNaN(Number(f)));
    // this.countryKeys.forEach ((value, index) => {

    //   this.countryList[value] = this.country[value]
    // }); //end of forEach loop

    console.log("Country data: " + JSON.stringify(this.countryList));
    console.log("this.countryKeys",this.countryKeys)



     /**
   * Below function will bind enum region data.
   */

    this.regionKeys = Object.keys(this.region).filter((f) => !isNaN(Number(f)));
    // this.countryKeys.forEach ((value, index) => {

    //   this.countryList[value] = this.country[value]
    // }); //end of forEach loop

    console.log("Region data: " + JSON.stringify(this.regionList));
    console.log("this.regionKeys",this.regionKeys)




    
     /**
   * Below function will bind enum jobtype data.
   */
    this.jobtypeKeys = Object.keys(this.jobtype).filter((f) => !isNaN(Number(f)));
    // this.countryKeys.forEach ((value, index) => { 

    //   this.countryList[value] = this.country[value] 
    // }); //end of forEach loop 

    console.log("Jobtype data: " + JSON.stringify(this.jobtypeList));
    console.log("this.jobtypeKeys",this.jobtypeKeys)


      /**
   * Below function will bind enum jobtype data.
   */
      this.timezoneKeys = Object.keys(this.timezone).filter((f) => !isNaN(Number(f)));
      // this.countryKeys.forEach ((value, index) => { 
  
      //   this.countryList[value] = this.country[value] 
      // }); //end of forEach loop 
  
      console.log("Timezone data: " + JSON.stringify(this.timezoneList));
      console.log("this.timezoneKeys",this.timezoneKeys)



  } //end of constructor

  ngOnInit (): void {

    this.getJobInfoPersonnelDetails (this.selectedWellId);
    this.getProjectNameApi();

  } //end of 'ngOnInit' function


  countryChange(country){
    console.log("country change-",country)
  }


  regionChange(region){
    console.log("region change-",region)

  }


  jobtypeChange(jobtype){
    console.log("jobtype change-",jobtype)

  }


  timezoneChange(timezone){
    console.log("timezone change-",timezone)

  }


  projectChange(jobpath){

    console.log("job change-: ",jobpath)
    this.selectedProjectId =  jobpath.ProjectId;
    this.selectedWellId = jobpath.WellId;
    this.selectedRegionId = "" + jobpath.Region;
    this.selectedCountryId = "" + jobpath.Country;
    this.selectedJobTypeId = "" + jobpath.JobType;
    this.selectedTimezoneId = "" + jobpath.Timezone;
    console.log("Type of this.selectedCountryId: " + typeof this.selectedCountryId);
    console.log("countryKeys: " + JSON.stringify(this.countryKeys));
    this.regForm.get('WellName').patchValue(jobpath.WellName);
    this.regForm.get('Lease').patchValue(jobpath.Lease);
    this.regForm.get('Field').patchValue(jobpath.Field);
    this.regForm.get('WellLicense').patchValue(jobpath.WellLicense);
    this.regForm.get('APINumber').patchValue(jobpath.APINumber);
    this.regForm.get('RigName').patchValue(jobpath.RigName);
    this.regForm.get('RigContractor').patchValue(jobpath.RigContractor);
    this.regForm.get('Country').patchValue(this.selectedCountryId);
    this.regForm.get('Region').patchValue(this.selectedRegionId);
    this.regForm.get('GeoLatitude').patchValue(jobpath.GeoLatitude);
    this.regForm.get('GeoLongitude').patchValue(jobpath.GeoLongitude);
    this.regForm.get('TimeZoneId').patchValue(jobpath.TimeZoneId);
    this.regForm.get('SpudDate').patchValue(jobpath.SpudDate);
    this.regForm.get('OperatingCompany').patchValue(jobpath.OperatingCompany);
    this.regForm.get('UniqueWellID').patchValue(jobpath.UniqueWellID);
    this.regForm.get('JobType').patchValue(this.selectedJobTypeId );

    this.getJobInfoPersonnelDetails (this.selectedWellId);
  }



  personnelselected(){

    if(this.selectedWellId>0){
      
      console.log("perssonel selected-:",this.selectedWellId)
      this.getJobInfoPersonnelDetails(this.selectedWellId)
    }
  }




  getProjectNameApi() {

    this.jobInfoService.getProjectNameList().subscribe(res => {
      if (res) {

          this.jobpathList = res.result.map((jobpath)=>{
            console.log("this.jobpathList",this.jobpathList,jobpath)
            return {'viewValue':jobpath.ProjectName,'value':jobpath.ProjectName,'data':jobpath};

          });





          console.log(this.jobpathList)
          // this.jobPathModel = sessionStorage.getItem('well-path-name');
      } else {
        console.log('error')
      }
    }),
      (error) => {
        console.log("WellPaths", error.error.result);
        // this.tableData = error.error.result;

      };//end of service call

  }// function ends






  onStepClick(event) {
    console.log(event)
  }

  /**
   * Below function will fetch personnel details according to the job info ID.
   */
  getJobInfoPersonnelDetails (jobInfoID) {

    this.personnelData = [];

    this.jobInfoService.getJobInfoList(jobInfoID).subscribe({

      next: (data) => {

        console.log("Project-list",data.result);
        this.personnelData = [];
        let details = data.result;

        for (let index = 0; index < details.length; index ++) {

          console.log("details: " + JSON.stringify(details));

          let personnelRecord = new jobInfo();

          personnelRecord.DateIn = details[index].DateIn;
          personnelRecord.DateOut = details[index].DateOut;
          personnelRecord.EmployeeNumber = details[index].EmployeeNumber;
          personnelRecord.Name = details[index].Name;
          personnelRecord.PersonnelRole = details[index].PersonnelRole;
          personnelRecord.PersonnelRoleName = this.roles[details[index].PersonnelRole];
          personnelRecord.PersonnelTimeSheetId = details[index].PersonnelTimeSheetId;

          console.log("personnelRecord: " + JSON.stringify(personnelRecord));

          this.personnelData.push(personnelRecord);
        } //end of for loop
      }, error: (error) => {

        console.log("Tempratures",error.error.result);
        // this.tableData = error.error.result;
      }
    }); //end of getJobInfoList function call
  } //end of 'getJobInfoPersonnelDetails' function


  /**
   * Below is the value change event
   */
  valueChanged (event) {

    console.log("EVENT RECEIVED: " + JSON.stringify(event));

    if (event.data.isNewlyAdded == false && event.action == 'delete' && event.data.PersonnelTimeSheetId != 0) {

      this.deletedRecords.push(event.data);
      console.log("this.deletedRecords: " + JSON.stringify(this.deletedRecords));
    } //end of if condition checking if the record is already deleted or not
  } //end of 'valueChanged' function


  /**
   * Below function for add row in personnal tab.
   */
  AddRow() {

    if (this.personnelData.length < 10) {

      let personnelRecord: jobInfo = new jobInfo();
      let personnelDataLength = this.personnelData.length;
      personnelRecord.PersonnelRole = this.personnelData.length;
      console.log("this.personnelData.length: " + this.personnelData.length);
      personnelRecord.PersonnelRoleName = this.roles[personnelRecord.PersonnelRole];

      this.personnelData.push(personnelRecord);
      this.personnelData = [...this.personnelData];

      console.log("this.personnelData: " + JSON.stringify(this.personnelData));
    } else {

      //Message saying Only 10 records can be added
      this.loading = false;
       this.toastr.error("Only 10 records can be added");
    } //end of if condition checking for the length of records
  } //end of 'AddRow' function


    /**
     * Below function will save records.
     */
    save() {


      let saveRecords = [];
      let details = this.personnelData.map((item)=>{
        return {...item, PersonnelRole:roleDefinitions.rolesId[item.PersonnelRoleName]}
      });

      details.forEach((record) => {

        delete record.DateIn;
        delete record.DateOut;
        delete record.PersonnelRoleName;
        delete record.isDeleted;
        delete record.isNewlyAdded;
        delete record.isUpdated;
        
        if (record.PersonnelTimeSheetId == 0)
          delete record.PersonnelTimeSheetId;

        saveRecords.push(record);
      });


      console.log("Saving new record");
      


      let payload = {
        details: saveRecords
      };

      this.jobInfoService.postJobInfoPersonnelList(payload, this.selectedWellId).subscribe({

        next: (data) => {

          console.log("Tempratures",data);
          this.getJobInfoPersonnelDetails (this.selectedWellId);
          // this.temperatureData = data;
          this.toastr.success("Data Saved Successfully");

        },

        error: (error) => {

          console.log("Tempratures",error);
          this.loading = false;
          // this.toastr.error("Something went wrong during Save");

          // this.temperatureData = error.error.result;

        }

      }); //end of service call
    } //end of 'saveNewRecords' function


  /**
   * Below function will delete records.
   */
  deleteRecords() {

    console.log("DELETE RECORD FUNCTION: " + JSON.stringify(this.deletedRecords));
    for (let index = 0; index < this.deletedRecords.length; index ++) {

      this.jobInfoService.deletePersonnelRecord(this.selectedWellId, this.deletedRecords[index].PersonnelTimeSheetId).subscribe({

        next: (data) => {
          console.log("Tempratures",data);
          // this.temperatureData = data;
          this.toastr.success("Data Deleted Successfully");
        },
        error: (error) => {
          console.log("Tempratures",error);
          this.loading = false;
          // this.toastr.error("Something went wrong during Delete");
          // this.temperatureData = error.error.result;
        }
      }); //end of service call
    } //end of for loop
  } //end of 'deleteRecords' function

  getsubcribemenus(){
    localStorage.setItem('additem',this.selectedNavItem.toString())
    this.route.navigate(['/dashboard/projects']);
    this.toastr.success("Job Info Saved Successfully");
    // localStorage.setItem('')
}

  onGeneralFormSubmit(){
    console.log("regForm",this.regForm)
    this.getsubcribemenus();
      if(this.regForm.valid){
        console.log(this.regForm.value['jobPathModel']);

        let reqObj = {
          "ProjectId" : this.regForm.value['jobPathModel']['ProjectId'],
          "WellId":this.regForm.value['jobPathModel']['WellId'],
          "WellName" : this.regForm.value['WellName'],
          "Field"  : this.regForm.value['Field'],
          "Lease" : this.regForm.value['Lease'],
          "OperatingCompany" : this.regForm.value['OperatingCompany'],
          "RigName" : this.regForm.value['RigName'],
          "RigContractor" : this.regForm.value['RigContractor'],
          "JobType" : this.regForm.value['JobType'],
          "Region" : this.regForm.value['Region'],
          "Country"  : this.regForm.value['Country'],
          "GeoLatitude" : this.regForm.value['GeoLatitude'],
          "GeoLongitude" : this.regForm.value['GeoLongitude'],
          "WPTSId" : 1,
          "WellLicense" : this.regForm.value['WellLicense'],
          "APINumber" : this.regForm.value['APINumber'],
          "UniqueWellID":this.regForm.value['UniqueWellID'],
          "IsMarkedForReprocessing" : 1,
          "IsActivationByWellActivityEnabled" : 0,
          "TimeZoneId" : this.regForm.value['TimeZoneId'],
          "SpudDate": this.regForm.value['SpudDate'],
          "UseKPIGroups" : 1
        } //end of 'reqObj'

        console.log("JOB INFO PAYLOAD: " + JSON.stringify(reqObj));
        this.jobInfoService.saveGeneralJobInfo(reqObj).subscribe({
          next: (val: any) =>{
            // alert('Employee Added successfully')
            this.toastr.success("Job Info Saved Successfully");
            // this._dialogRef.close()
          },
          error:(err:any) =>{
            console.error(err)
            this.loading = false;
        this.toastr.error("Something went wrong during Save");
          }
        })
        // this._dialogRef.close(true)
      }
  }
}