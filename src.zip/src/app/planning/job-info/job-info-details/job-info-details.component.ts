import { DialogRef } from '@angular/cdk/dialog';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { JobInfoService } from 'src/app/core/services/job-info-form.service';

@Component({
  selector: 'app-job-info-details',
  templateUrl: './job-info-details.component.html',
  styleUrls: ['./job-info-details.component.scss']
})
export class JobInfoDetailsComponent implements OnInit {
 

  constructor(private _fb:FormBuilder){

  }

  ngOnInit(): void {
  }

}
