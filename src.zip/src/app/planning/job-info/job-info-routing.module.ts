import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JobInfoComponent } from './job-info.component';
import { JobInfoListComponent } from './job-info-list/job-info-list.component';
import { JobInfoDetailsComponent } from './job-info-details/job-info-details.component';
import { JobInfoDeletePopupComponent } from './job-info-delete-popup/job-info-delete-popup.component';

const routes: Routes = [
  {path:'', component:JobInfoComponent, children:[
  {path:'jobinformation', component:JobInfoListComponent}]},
  {path:'jobdetails', component:JobInfoDetailsComponent},
  {path:'jobdelete', component:JobInfoDeletePopupComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class JobinfoRoutingModule { }
