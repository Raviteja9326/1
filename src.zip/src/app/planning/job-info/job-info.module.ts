import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { AllModule } from 'src/app/shared/all_modules';
import { JobInfoComponent } from './job-info.component';
import { JobInfoListComponent } from './job-info-list/job-info-list.component';
import { JobInfoDetailsComponent } from './job-info-details/job-info-details.component';
import { JobInfoDeletePopupComponent } from './job-info-delete-popup/job-info-delete-popup.component';
import { JobinfoRoutingModule } from './job-info-routing.module';

@NgModule({
    declarations: [
      JobInfoComponent,
      JobInfoListComponent,
      JobInfoDetailsComponent,
      JobInfoDeletePopupComponent
    ],
    imports: [
      CommonModule,
      AllModule,
      HttpClientModule,
      JobinfoRoutingModule
    ]
  })

  export class JobInfoModule { }