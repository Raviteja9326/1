const sonarqubeScanner =  require('sonarqube-scanner');
sonarqubeScanner(
    {
        serverUrl:  'https://sonarqube.cummins.com',
        options : {
            'sonar.sources':  'server/',
            'sonar.login': '4419d3c19bd19377e6f543d5d8f58ff3621af02a',
            'sonar.tests':  '__test__/',
            'sonar.inclusions'  :  '**', // Entry point of your code
            'sonar.test.inclusions':  '__test__/**/*.test.js',
            'sonar.javascript.lcov.reportPaths':  'coverage/lcov.info',
            'sonar.testExecutionReportPaths':  'coverage/test-reporter.xml'
        }
    }, () => {});