import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'substractDate',
  pure: true
})
export class SubstractDatePipe implements PipeTransform {

  transform(EntryTime, EndDate): string {
    const entryDate = new Date(EntryTime);
    const endDate = new Date(EndDate);
    const timeDiff = this.calculateTimeDiff(entryDate,endDate);
    console.log(timeDiff)
    return timeDiff
  }

  calculateTimeDiff(EntryTime,EndDate) {
    let timeDiff = EndDate.getTime() - EntryTime.getTime();
    if (timeDiff < 0) {
      timeDiff = 0;
    }
    const hours = Math.floor(timeDiff / 3600000);
    const minutes = Math.floor((timeDiff % 3600000) / 60000);
    const mins = String(minutes).padStart(2, "0");
    const hrs = String(hours).padStart(2, "0");
    return  hrs + ":" + mins;
  }

}