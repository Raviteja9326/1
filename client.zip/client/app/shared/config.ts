import { AbstractControl, FormGroup } from "@angular/forms";

export const Creditianls = {
   "redirectUri" : "https://wy-graylingpoc.azurewebsites.net",
   "redirectUriendpoint" : "https://wy-graylingpoc.azurewebsites.net/api/v1",
   "redirectUriloginendpoint" : "https://wy-graylingpoc.azurewebsites.net/api",
  // "redirectUri" : "http://localhost:4200",
  // "redirectUriendpoint" : "http://localhost:3000/api/v1",
  // "redirectUriloginendpoint" : "http://localhost:3000/api",
}

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

  export function MustMatch(controlName: string, matchingControlName: string) {
    return (updateforgotpasswordform: FormGroup) => {
        const control = updateforgotpasswordform.controls[controlName];
        const matchingControl = updateforgotpasswordform.controls[matchingControlName];

        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            // return if another validator has already found an error on the matchingControl
            return;
        }

        // set error on matchingControl if validation fails
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ mustMatch: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
  }

export const ngxUiLoaderConfig:any = {
  "bgsColor": "red",
  "bgsOpacity": 0.5,
  "bgsPosition": "bottom-right",
  "bgsSize": 60,
  "bgsType": "ball-spin-clockwise",
  "blur": 5,
  "delay": 0,
  "fastFadeOut": true,
  "fgsColor": "#11c15b",
  "fgsPosition": "center-center",
  "fgsSize": 40,
  "fgsType": "ball-spin-clockwise",
  "gap": 24,
  "logoPosition": "center-center",
  "logoSize": 60,
  "logoUrl": "assets/img/favicon.png",
  "masterLoaderId": "master",
  "overlayBorderRadius": "0",
  "overlayColor": "rgb(78 52 46 / 81%)",
  "pbColor": "red",
  "pbDirection": "ltr",
  "pbThickness": 3,
  "hasProgressBar": false,
  "text": "",
  "textColor": "#FFFFFF",
  "textPosition": "center-center",
  "maxTime": -1,
  "minTime": 500
};
