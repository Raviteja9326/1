import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'est'
})
export class ESTPipe implements PipeTransform {
  transform(value: any): any {
    const systemTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const datePipe = new DatePipe('en-US');
    return datePipe.transform(value, 'yyyy-MM-dd HH:mm','EDT');
  }
}