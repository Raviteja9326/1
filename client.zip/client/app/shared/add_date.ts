import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'AddDate',
  pure: true
})
export class AddDatePipe implements PipeTransform {

  transform(nowDate, substractDate): string {
    const nowDates = new Date(nowDate);
    const substractDates = new Date(substractDate);
    const timeDiff = this.calculateTimeDiff(nowDates,substractDates);
    return timeDiff;
  }

  calculateTimeDiff(nowDate, substractDate) {
    const timeDiff = nowDate.getTime() - substractDate.getTime();
    const hoursDiff = Math.abs(Math.floor(timeDiff / (1000 * 60 * 60)));
    const minsDiff = Math.abs(Math.floor((timeDiff / (1000 * 60)) % 60));
    const mins = String(minsDiff).padStart(2, "0");
    const hrs = String(hoursDiff).padStart(2, "0");
    return  hrs + ":" + mins;

  }

}