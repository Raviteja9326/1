import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddDatePipe } from './add_date';
import { SubstractDatePipe } from './substract_date ';
import { MinutesToHoursPipe } from './minutes-to-hours.pipe';
import { RemoveSpacesPipe } from './remove-spaces.pipe';
import { ESTPipe } from './est.pipe';
@NgModule({
  declarations: [AddDatePipe,SubstractDatePipe,MinutesToHoursPipe,RemoveSpacesPipe,ESTPipe],
  imports: [
    CommonModule
  ],
  exports:[AddDatePipe,SubstractDatePipe,MinutesToHoursPipe,RemoveSpacesPipe,ESTPipe]
})
export class Sub_Add_PipeModule { }
