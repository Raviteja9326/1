// import the required animation functions from the angular animations module
import { trigger, state, animate, transition, style, group, query, animateChild, AnimationTriggerMetadata } from '@angular/animations';

export class Totalexpand {
static search_animations = Totalexpand.getAnimations();

static getAnimations(): Array<AnimationTriggerMetadata> {
    return [
    trigger('clearExpand', [
        transition(':enter', [
            style({ width: '0', opacity: 0 }),
            group([
                animate(200, style({ width: '*' })),
                animate('100ms 100ms', style({ opacity: '{{finalOpacity}}' }))
            ])
        ], { params: { finalOpacity: 1 } }),
        transition(':leave', [
            group([
                animate(200, style({ width: '0px' })),
                animate('100ms', style({ opacity: 0 }))
            ])
        ]),
        // TODO: opacity is not good enough. When hidden, button should also be disabled and aria-hidden (or removed completely)
        state('1', style({ opacity: '*' })),
        state('0', style({ opacity: '0' })),
        transition('1<=>0', animate(200)),
    ]),

    trigger('searchExpand', [
        state('1', style({ width: '*', backgroundColor: '*', margin: '*' })),
        state('0', style({ width: '60px', backgroundColor: 'transparent', color: 'white', margin: '0' })),
        transition('0=>1', [
            group([
                style({ width: '60px', backgroundColor: 'transparent' }),
                animate(200, style({ width: '*', backgroundColor: '*', color: '*' })),
                query('@inputExpand', [
                    style({ width: '0' }),
                    animate(200, style({
                        width: '*',
                        margin: '*',
                    })),
                ]),
                query('@clearExpand', [
                    animateChild(),
                ])
            ])
        ]),
        transition('1=>0', [
            group([
                style({ width: '*' }),
                animate(200, style({
                    backgroundColor: 'transparent',
                    width: '40px',
                    color: 'white',
                })),
                query('@clearExpand', [
                    animateChild(),
                ]),
                query('@inputExpand', [
                    animate(200, style({
                        width: '0',
                        backgroundColor: 'transparent',
                        opacity: '0',
                        margin: '0',
                    }))
                ]),
            ])
        ]),
    ]),

    trigger('inputExpand', [
        state('0', style({ width: '0', margin: '0' })),
        // Without this transition, the input animates to an incorrect width
        transition('0=>1', []),
    ])]
}
}