import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SkeletonModule } from 'primeng/skeleton';
import { ComponentsModule } from '../modals/components.module';
import { MaterialModule } from './material.module';
import { Sub_Add_PipeModule } from './sub_add_pipe_module';
import { HighchartsChartModule } from 'highcharts-angular';
import { NgApexchartsModule } from "ng-apexcharts";
import { NgxPaginationModule } from 'ngx-pagination';
import { MatCardModule } from '@angular/material/card';
const Modules = [
  FormsModule,
  ReactiveFormsModule,
  MaterialModule,
  SkeletonModule,
  HighchartsChartModule,
  Sub_Add_PipeModule,
  ComponentsModule,
  NgApexchartsModule,
  NgxPaginationModule,
  MatCardModule
]

@NgModule({
  imports: [...Modules],
  exports:[...Modules]
})
export class AllModule { }
