export interface Regional {
    RegionID?: number;
    RegionName?: string;
    Site?: any;
}

export interface Region {
    facilityName: any;
    RegionID?: number;
    RegionName?: string;
}