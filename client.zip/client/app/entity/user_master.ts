export interface UserMaster {
    WWID?: string;
    UserName?: string;
    Site?: any;
    FirstName?:any,
    RoleName?:any,
    
}
