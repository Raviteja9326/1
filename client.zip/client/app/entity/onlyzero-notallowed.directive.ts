import { Directive } from '@angular/core';
import { AbstractControl, ValidatorFn } from '@angular/forms';

export function notZero(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null =>
    control.value?.toLowerCase() !== '0'
      ? null : { zeroValue: control.value };
}
@Directive({
  selector: '[appOnlyzeroNotallowed]'
})
export class OnlyzeroNotallowedDirective {

  constructor() { }


  validate(control: AbstractControl): { [key: string]: any } | null {
    return notZero()(control);
  }
}
