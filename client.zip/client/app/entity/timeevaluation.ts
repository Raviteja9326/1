export interface TimeEvaluation {
    index?: number;
    vehicleLicence?: string;
    incomingTime?: string;
    waitingTime?: string;
    outgoingTime?: string;
}