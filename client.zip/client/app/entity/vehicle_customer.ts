export interface vechicleCustomer {
    CustomerID?: number;
    VehicleID?: any;
}