import { Component } from '@angular/core';

@Component({
  selector: 'app-occupancy-waiting',
  templateUrl: './occupancy-waiting.component.html',
  styleUrls: ['./occupancy-waiting.component.scss']
})
export class OccupancyWaitingComponent {

  isLinear:boolean = false;
  dataShow:boolean = false;
  onStepClick(event) {
    console.log('Step clicked:', event.selectedIndex);
    if(event.selectedIndex == 0){
      this.dataShow = false;
    }
    else if(event.selectedIndex == 1){
      this.dataShow = true;
    }
  }

}
