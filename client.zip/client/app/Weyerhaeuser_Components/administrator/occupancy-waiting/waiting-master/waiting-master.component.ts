import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { Totalexpand } from 'client/app/shared/search';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AlertmasterService } from 'client/app/services/alertmaster.service';
import { WaitingTimeModalComponent } from 'client/app/modals/waitingtime-modal/waitingtime-modal.component';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
@Component({
  selector: 'app-waiting-master',
  templateUrl: './waiting-master.component.html',
  styleUrls: ['./waiting-master.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class WaitingMasterComponent implements OnInit, OnDestroy {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: [] = []
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  pageIndex = 1;
  pageSize = 20;
  totalItems = 0;
  displayedColumns: string[] = [
    "alertName",
    'bayName',
    'roleName',
    "minThreshold",
    "avgWaiting",
    "maxThresholdWarning" ,
    'maxThreshold',
    "isActive",
    "Actions"
  ];
  sitedata: any;
  userdata: any;
  constructor(public dialog: MatDialog,private adminService: FacilitymasterService, private alert_cust: AlertmasterService,private toastr: ToastrService, private route:Router,private formBuilder: FormBuilder,private storage: StorageService) {this.userdata = this.storage.getvariable(); }
  ngOnInit(): void {
    this.getsites();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  pageChanged(event: PageEvent) {
    console.log(event)
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex + 1;
    this.getalertMaster();
  }

  roleForm = this.formBuilder.group({
    facilityId: [''],
  });

  async getsites() {
    await this.adminService
      .getfacilitymaster()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          res.elements.map((res) => {
            this.sitedata = res;
          });
        },
        error: (error) => {
          this.toastr.error(error.error.message);
        },
      });
    await this.roleForm.setValue({
      facilityId: this.userdata,
    });
    this.getalertMaster();
  }

  getWaitingTimeAlert1(event) {
    console.log(event);
    console.log(this.roleForm.value.facilityId)
    this.getalertMaster();
  }

  alert_modal(): void {
    const alrtadd:boolean = true;
    const dialogRef = this.dialog.open(WaitingTimeModalComponent, {
      width: '530px',
      data: {alrtadd},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getalertMaster();
    });
  }
  alert_master_modal_update(alrtData): void {
    const alrtupd:boolean = true;
    const dialogRef = this.dialog.open(WaitingTimeModalComponent, {
      width: '530px',
      data: {alrtupd,alrtData},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getalertMaster();
    });
  }
  getalertMaster() {
    this.isLoading = true;
    const obj = {};
    let data = {};

    data['pageIndex'] = this.pageIndex;
    data['pageSize'] = this.pageSize;
    obj['alertType'] = "timeAlert";
    obj['facilityId'] = this.roleForm.value.facilityId;

    this.alert_cust.getAlertList(data,obj).pipe(takeUntil(this._destroying$)).subscribe( {next: (res) => {
      console.log(res)
      this.ELEMENT_DATA = res.elements;
      if (res['elements'].length != 0) {
        this.isLoading = false;
        this.displayNoRecords = false;
        this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
        setTimeout(() => {
          this.dataSource.sort = this.sort;
          this.totalItems = this.dataSource.data.length;
          this.dataSource.paginator = this.paginator;
        });
      }
      else if (res['elements'].length == 0) {
        this.isLoading = false;
        this.displayNoRecords = true;
        this.ELEMENT_DATA = [];
        this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
      }
    },error: (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
  }})
  }
  close() {
      this._value = '';
      this.pageIndex = 1;
      this.pageSize = 20;
      this.getalertMaster();
  }
  onSearchClicked() {
    this.expanded = true;
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
}


