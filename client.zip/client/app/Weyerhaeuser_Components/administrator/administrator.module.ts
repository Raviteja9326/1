import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AdministratorRoutingModule } from './administrator-routing.module';
import { AdministratorComponent } from './administrator.component';
import { UsermasterComponent } from './usermaster/usermaster.component';
import { RolemasterComponent } from './role-access/rolemaster/rolemaster.component';
import { RoleAccessComponent } from './role-access/role-access.component';
import { AccessMasterComponent } from './role-access/access-master/access-master.component';
import { AllModule } from 'client/app/shared/all_modules';
import { FacilityMasterComponent } from './facility-master/facility-master.component';
import { CameraMasterComponent } from './camera-master/camera-master.component';
import { BayMasterComponent } from './bay-master/bay-master.component';
import { PenaltyMasterComponent } from './penalty-master/penalty-master.component';
import { OccupancyWaitingComponent } from './occupancy-waiting/occupancy-waiting.component';
import { WaitingMasterComponent } from './occupancy-waiting/waiting-master/waiting-master.component';
import { OccupancyMasterComponent } from './occupancy-waiting/occupancy-master/occupancy-master.component';



@NgModule({
  declarations: [
    AdministratorComponent,
    UsermasterComponent,
    RolemasterComponent,
    AccessMasterComponent,
    RoleAccessComponent,
    FacilityMasterComponent,
    CameraMasterComponent,
    BayMasterComponent,
    PenaltyMasterComponent,
    OccupancyWaitingComponent,
    WaitingMasterComponent,
    OccupancyMasterComponent
  ],
  imports: [
    CommonModule,
    AdministratorRoutingModule,
    AllModule
  ],
  providers: [DatePipe]
})
export class AdministratorModule { }
