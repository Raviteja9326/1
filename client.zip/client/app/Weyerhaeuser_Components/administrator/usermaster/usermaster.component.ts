import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { UsermasterService } from 'client/app/services/usermaster.service';
import { Totalexpand } from 'client/app/shared/search';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { UserModalComponent } from 'client/app/modals/user-modal/user-modal.component';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-usermaster',
  templateUrl: './usermaster.component.html',
  styleUrls: ['./usermaster.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class UsermasterComponent implements OnInit, OnDestroy {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: [] = [];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  pageIndex = 0;
  pageSize = 5;
  totalItems = 0;
  currentDate = new Date();
  displayedColumns: string[] = [
    'fullName',
    'email',
    'facility',
    'roleName',
    'createdDate',
    'isActive',
    'Actions',
  ];
  constructor(
    public dialog: MatDialog,
    private User_cust: UsermasterService,
    private toastr: ToastrService,
    private route: Router,
    private datePipe: DatePipe
  ) {}
  ngOnInit(): void {
    this.getUser_master();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }
  user_Modal(): void {
    const useradd: boolean = true;
    const dialogRef = this.dialog.open(UserModalComponent, {
      width: '530px',
      data: { useradd },
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px',
      },
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntil(this._destroying$))
      .subscribe((result: any) => {
        this.getUser_master();
      });
  }
  Usermaster_Modal_update(userData): void {
    const userupdate: boolean = true;
    const dialogRef = this.dialog.open(UserModalComponent, {
      width: '530px',
      data: { userupdate, userData },
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px',
      },
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntil(this._destroying$))
      .subscribe((result: any) => {
        this.getUser_master();
      });
  }
  Usermaster_Modal_view(userDataview): void {
    // const userview:boolean = true;
    // const dialogRef = this.dialog.open(UserModalComponent, {
    //   width: '530px',
    //   data: {userview,userDataview},
    //   disableClose: true,
    //   autoFocus: false,
    //   position: {
    //     top: '20px'
    //   }
    // });
    // dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
    //   this.getUser_master();
    // });
  }
  getUser_master() {
    this.isLoading = true;
    const timedate = {};
    timedate['time'] = this.datePipe.transform(
      this.currentDate,
      'yyyy-MM-dd HH:mm:ss'
    );
    (timedate['stamp'] = Intl.DateTimeFormat().resolvedOptions().timeZone),
      this.User_cust.getUsermaster(timedate)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            res.elements.map((res) => {
              this.ELEMENT_DATA = res;
            });
            if (res['elements'].length != 0) {
              this.isLoading = false;
              this.displayNoRecords = false;
              this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
              setTimeout(() => {
                this.dataSource.sort = this.sort;
                this.totalItems = this.dataSource.data.length;
                this.dataSource.paginator = this.paginator;
                this.dataSource.filterPredicate = (data: any, filter: string) =>
                  data.fullName.toLowerCase().indexOf(filter) != -1 ||
                  data.email.indexOf(filter) != -1 ||
                  data.roleName.toLowerCase().indexOf(filter) != -1;
              });
            } else if (res['elements'].length == 0) {
              this.isLoading = false;
              this.displayNoRecords = true;
              this.ELEMENT_DATA = [];
            }
          },
          error: (error) => {
            this.toastr.error(error.error.message);
            this.route.navigate(['/dashboard/errors']);
          },
        });
  }
  close() {
    this._value = '';
    this.getUser_master();
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search');
    }
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
}
