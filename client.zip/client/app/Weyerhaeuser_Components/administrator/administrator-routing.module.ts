import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdministratorComponent } from './administrator.component';
import { UsermasterComponent } from './usermaster/usermaster.component';
import { RoleAccessComponent } from './role-access/role-access.component';
import { FacilityMasterComponent } from './facility-master/facility-master.component';
import { CameraMasterComponent } from './camera-master/camera-master.component';
import { BayMasterComponent } from './bay-master/bay-master.component';
import { PenaltyMasterComponent } from './penalty-master/penalty-master.component';
import { OccupancyWaitingComponent } from './occupancy-waiting/occupancy-waiting.component';

const routes: Routes = [{path:'',component:AdministratorComponent,children:[
  {path:"usermaster", component:UsermasterComponent},
  {path:"roleaccessmaster", component:RoleAccessComponent},
  {path:"facilitymaster", component:FacilityMasterComponent},
  {path:"cameramaster", component:CameraMasterComponent},
  {path:"baymaster", component:BayMasterComponent},
  {path:"penaltymaster", component:PenaltyMasterComponent},
  {path:"occupancywaitingmaster", component:OccupancyWaitingComponent}
]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministratorRoutingModule { }
