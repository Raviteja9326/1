import { Component, OnDestroy, OnInit,ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RoleModalComponent } from 'client/app/modals/role-modal/role-modal.component';
import {RoleService} from 'client/app/services/role.service';
import { Totalexpand } from 'client/app/shared/search';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-rolemaster',
  templateUrl: './rolemaster.component.html',
  styleUrls: ['./rolemaster.component.scss'],
  animations: [Totalexpand.search_animations]
})
export class RolemasterComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  dataSource:any;
  _value:string = "";
  expanded:boolean = false;
  isLoading = true;
  displayNoRecords = false;
  constructor(public dialog: MatDialog,private roleService:RoleService,private toastr: ToastrService, private route:Router) { }
  ngOnInit(): void {
    this.getRoles();
  }
  getRoles()
  {
    this.isLoading = true;
     this.roleService.getRoles().pipe(takeUntil( this._destroying$)).subscribe({next:(res:any)=>{
     this.isLoading = false;
     if (res.length === 0) {
        this.displayNoRecords = true;
     } else {
       this.displayNoRecords = false;
       }
       this.dataSource = res.elements;
     },error: (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
  }})
  }
  rolemaster_Modal(): void {
    const dialogRef = this.dialog.open(RoleModalComponent, {
      width: '530px',
      data: '',
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getRoles();
    });
  }
  rolemaster_Modal_update(roleData): void {
    const dataupdate:boolean = true;
    const dialogRef = this.dialog.open(RoleModalComponent, {
      width: '530px',
      data: {dataupdate,roleData},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getRoles();
    });
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
