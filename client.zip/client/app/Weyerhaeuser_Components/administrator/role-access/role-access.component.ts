import { Component } from '@angular/core';
@Component({
  selector: 'app-role-access',
  templateUrl: './role-access.component.html',
  styleUrls: ['./role-access.component.scss']
})
export class RoleAccessComponent{
  isLinear:boolean = false;
  dataShow:boolean = false;
  onStepClick(event) {
    console.log('Step clicked:', event.selectedIndex);
    if(event.selectedIndex == 0){
      this.dataShow = false;
    }
    else if(event.selectedIndex == 1){
      this.dataShow = true;
    }
  }
}
