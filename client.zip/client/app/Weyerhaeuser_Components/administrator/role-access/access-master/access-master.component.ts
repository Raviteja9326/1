import { Component, Input, OnChanges, OnDestroy, OnInit,SimpleChanges,ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { AccessMasterService } from 'client/app/services/access-master.service';
import { Totalexpand } from 'client/app/shared/search';
import {MatAccordion} from '@angular/material/expansion';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AccessModalComponent } from 'client/app/modals/access-modal/access-modal.component';
@Component({
  selector: 'app-access-master',
  templateUrl: './access-master.component.html',
  styleUrls: ['./access-master.component.scss'],
  animations: [Totalexpand.search_animations]
})
export class AccessMasterComponent  implements OnInit , OnDestroy, OnChanges {
  private readonly _destroying$ = new Subject<void>();
  dataSource:any;
  isLoading = true;
  _value:string = "";
  expanded:boolean = false;
  displayNoRecords = false;
  panelOpenState = [];
  displayedColumns: string[] = ['Id', 'Role','AccessData', 'Actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Input() callApi:boolean = false;
  constructor(public dialog: MatDialog, private accessService:AccessMasterService, private toastr: ToastrService, private route:Router) {
    console.log(this.callApi)
  }
  ngOnInit(): void {}
  ngOnChanges(changes: SimpleChanges) {
    console.log(changes.callApi.currentValue)
    if(changes.callApi.currentValue === true){
      this.getAccessList();
    }
  }
  getAccessList(){
    this.isLoading = true;
    this.accessService.getAccessDetail().pipe(takeUntil( this._destroying$)).subscribe({next:(res)=>{
      console.log(res)
      if (res.length != 0) {
        this.dataSource = res;
        this.panelOpenState = new Array(res.length).fill(false);
      } else if(res.length == 0) {
        this.dataSource = []
       }
       this.isLoading = false
        },error: (error) => {
          this.toastr.error(error.error.message);
          this.route.navigate(['/dashboard/errors']);
      }})
  }
  accessmaster_Modal_update(accessData): void {
    const dataupdate:boolean = true;
    const dialogRef = this.dialog.open(AccessModalComponent, {
      width: '600px',
      data: {dataupdate,accessData},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getAccessList();
    });
  }
  show(index){
    this.panelOpenState[index] = true;
    for(let i=0;i<this.panelOpenState.length;i++){
      if(i!=index)
        this.panelOpenState[i] = false;
    }
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
  close() {
    this._value = '';
    this.getAccessList();
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search')
    }
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    console.log(filterValue);
    this.dataSource = this.dataSource.find(item => console.log(item.Role.roleName));
  }
}
