import { Component } from '@angular/core';

@Component({
  selector: 'app-administrator',
  templateUrl: './administrator.component.html',
  styleUrls: ['./administrator.component.sass']
})
export class AdministratorComponent {
  constructor(){
    sessionStorage.setItem('memuPath', 'Administration');
  }
}
