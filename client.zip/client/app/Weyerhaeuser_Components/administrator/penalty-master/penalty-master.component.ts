import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { Totalexpand } from 'client/app/shared/search';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { PenaltymasterService } from 'client/app/services/penalty-master.service';
import { PenaltyModalComponent } from 'client/app/modals/penalty-modal/penalty-modal.component';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
@Component({
  selector: 'app-penalty-master',
  templateUrl: './penalty-master.component.html',
  styleUrls: ['./penalty-master.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class PenaltyMasterComponent implements OnInit, OnDestroy {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: [] = []
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  pageIndex = 0;
  pageSize = 5;
  totalItems = 0;
  displayedColumns: string[] = [

    "bayName",
    "penalty",
    "description",
    'createdDate'
    // "Actions"
  ];
  constructor(public dialog: MatDialog, private facility_cust: PenaltymasterService,private toastr: ToastrService, private route:Router) { }
  ngOnInit(): void {
    this.facility_master();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }
  facility_Modal(): void {
    const facadd:boolean = true;
    const dialogRef = this.dialog.open(PenaltyModalComponent, {
      width: '530px',
      data: {facadd},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.facility_master();
    });
  }
  facility_Modal_update(facData): void {
    const facupd:boolean = true;
    const dialogRef = this.dialog.open(PenaltyModalComponent, {
      width: '530px',
      data: {facupd,facData},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.facility_master();
    });
  }

  facility_master() {
    this.isLoading = true;
    this.facility_cust.getfacilitymaster().pipe(takeUntil(this._destroying$)).subscribe( {next: (res) => {
      res.elements.map(res => {
        this.ELEMENT_DATA = res;
        console.log(2, res)
      })
      if (res['elements'].length != 0) {
        this.isLoading = false;
        this.displayNoRecords = false;
        this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
        setTimeout(() => {
          this.dataSource.sort = this.sort;
          this.totalItems = this.dataSource.data.length;
          this.dataSource.paginator = this.paginator;
        });
      }
      else if (res['elements'].length == 0) {
        this.isLoading = false;
        this.displayNoRecords = true;
        this.ELEMENT_DATA = [];
      }
    },error: (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
  }})
  }
  close() {
    this._value = '';
    this.facility_master();
  }
  onSearchClicked() {
    this.expanded = true;
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
}
