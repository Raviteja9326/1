import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CameraMasterComponent } from './camera-master.component';

describe('CameraMasterComponent', () => {
  let component: CameraMasterComponent;
  let fixture: ComponentFixture<CameraMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CameraMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CameraMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
