import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { CameraMasterService } from 'client/app/services/camera-master.service';
import { Totalexpand } from 'client/app/shared/search';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CameraModalComponent } from 'client/app/modals/camera-modal/camera-modal.component';
@Component({
  selector: 'app-camera-master',
  templateUrl: './camera-master.component.html',
  styleUrls: ['./camera-master.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class CameraMasterComponent implements OnInit, OnDestroy {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: [] = []
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  pageIndex = 0;
  pageSize = 5;
  totalItems = 0;
  displayedColumns: string[] = [
    "cameraId",
    "cameraName",
    'facilityName',
    "locationDescription",
    "Actions"
  ];
  constructor(public dialog: MatDialog, private camera_cust: CameraMasterService, private toastr: ToastrService, private route:Router) { }
  ngOnInit(): void {
    this.camera_master();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }
  camera_Modal(): void {
    const camadd:boolean = true;
    const dialogRef = this.dialog.open(CameraModalComponent, {
      width: '530px',
      data: {camadd},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.camera_master();
    });
  }
  camera_Modal_update(camData): void {
    const camupd:boolean = true;
    const dialogRef = this.dialog.open(CameraModalComponent, {
      width: '530px',
      data: {camupd,camData},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.camera_master();
    });
  }
  camera_master() {
    this.isLoading = true;
    this.camera_cust.getcameramaster().pipe(takeUntil(this._destroying$)).subscribe({next: (res) => {
      console.log(res)
      this.ELEMENT_DATA =res.data
      if (res['data'].length != 0) {
        this.isLoading = false;
        this.displayNoRecords = false;
        this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
        setTimeout(() => {
          this.dataSource.sort = this.sort;
          this.totalItems = this.dataSource.data.length;
          this.dataSource.paginator = this.paginator;
        });
      }
      else if (res['elements'].length == 0) {
        this.isLoading = false;
        this.displayNoRecords = true;
        this.ELEMENT_DATA = [];
      }
    },error: (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
  }})
  }
  close() {
    this._value = '';
    this.camera_master();
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search')
    }
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
}
