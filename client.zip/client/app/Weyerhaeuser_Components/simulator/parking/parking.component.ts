import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { Totalexpand } from 'client/app/shared/search';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { SimulatorService } from 'client/app/services/simulator.service';
import { SimulatorModalComponent } from 'client/app/modals/simulator-modal/simulator-modal.component';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-parking',
  templateUrl: './parking.component.html',
  styleUrls: ['./parking.component.scss'],
  animations: [Totalexpand.search_animations]
})
export class ParkingComponent implements OnInit, OnDestroy, OnChanges {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  pageIndex: number = 1;
  pageSize: number = 20;
  totalItems: number;
  currentDate = new Date();
  @Input() EntryData:boolean = false;
  displayedColumns: string[] = [
    "Sr.No",
    "vehicleLicence",
    "BayName",
    'receivedTimeStamp'
  ];
  constructor(public dialog: MatDialog, private sim_cust: SimulatorService, private toastr: ToastrService, private route:Router, private datePipe:DatePipe) { }
  ngOnInit(): void {}
  ngOnChanges(changes: SimpleChanges) {
    console.log(changes.EntryData.currentValue)
    this.EntryData = changes.EntryData.currentValue;
     if(this.EntryData == true){
      this.getUser_master("Parking Exit", 1,20)
     }
   }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this._value != '') {
      this.paginator.length = this.ELEMENT_DATA.metadata.total;
      this.dataSource.paginator = this.paginator;
      this.dataSource['sort'] = this.sort;
    }
    else if (this._value == '') {
      this.pageIndex = 1;
      this.pageSize = 20;
      this.getUser_master("Parking Exit",this.pageIndex,this.pageSize)
    }
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.getUser_master("Parking Exit",this.pageIndex,this.pageSize)
  }
  user_Modal(): void {
    const parkingadd:boolean = true;
    const dialogRef = this.dialog.open(SimulatorModalComponent, {
      width: '530px',
      data: {parkingadd},
      disableClose: true,
      autoFocus: false,
      position: {
        top: '20px'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil( this._destroying$)).subscribe((result:any) => {
      this.getUser_master("Parking Exit",1, 20)
    });
  }
  refreshdata(){
    this.getUser_master("Parking Exit",1, 20)
  }
  getUser_master(data,data1,data2) {
    this.isLoading = true;
    const timedate = {};
    timedate['pageindex'] = data1;
    timedate['pagesize'] = data2;
    timedate['status'] = data,
    timedate['time'] = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd HH:mm:ss');
    timedate['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    console.log(timedate)
    this.sim_cust.getallsimulator2(timedate).pipe(takeUntil(this._destroying$)).subscribe({next: (res) => {
    this.ELEMENT_DATA = res
      if (res['data'].length != 0) {
        this.isLoading = false;
        this.displayNoRecords = false;
        this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA.data);
        setTimeout(() => {
          this.dataSource.sort = this.sort;
          this.totalItems = this.ELEMENT_DATA.metadata.total;
          this.pageIndex = this.ELEMENT_DATA.metadata.current_page - 1;
          this.dataSource.filterPredicate =
            (data: any, filter: string) => data.vehicleLicence.indexOf(filter) != -1 || data.BayName.toLowerCase().indexOf(filter) != -1;
        });
      }
      else if (res['data'].length == 0) {
        this.ELEMENT_DATA = [];
        this.dataSource = null;
        this.isLoading = false;
        this.displayNoRecords = true;
      }
    },error: (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
  }})
  }
  close() {
    this._value = '';
    this.getUser_master("Parking Exit",1, 20)
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search')
    }
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
}
