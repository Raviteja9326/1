import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulator',
  templateUrl: './simulator.component.html',
  styleUrls: ['./simulator.component.scss']
})
export class SimulatorComponent {
  selectedOption = 'Tarping In';
  selectedOption2 = 'Exit';
  isLinear:boolean = false;
  dataentry:boolean = true;
  databay:boolean = false;
  datatraping:boolean = false;
  dataexit:boolean = false;
  onStepClick(event) {
    if(event.selectedIndex == 0){
      this.dataentry = true;
      this.databay = false;
      this.datatraping = false;
      this.dataexit = false;
    }
    else if(event.selectedIndex == 1){
      this.dataentry = false;
      this.databay = true;
      this.datatraping = false;
      this.dataexit = false;
    }
    else if(event.selectedIndex == 2){
      this.dataentry = false;
      this.databay = false;
      this.datatraping = true;
      this.dataexit = false;
    }
    else if(event.selectedIndex == 3){
      this.dataentry = false;
      this.databay = false;
      this.datatraping = false;
      this.dataexit = true;
    }
  }

}
