import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BayComponent } from './bay/bay.component';
import { EntryComponent } from './entry/entry.component';
import { ExistbayComponent } from './existbay/existbay.component';
import { ParkingComponent } from './parking/parking.component';
import { SimulatorComponent } from './simulator.component';
import { TrappingbayComponent } from './trappingbay/trappingbay.component';

const routes: Routes = [
  {path:'',component:SimulatorComponent,children:[
    {path:'entry',component:EntryComponent},
    {path:'parking',component:ParkingComponent},
    {path:'bay',component:BayComponent},
    {path:'trappingbay',component:TrappingbayComponent},
    {path:'existbay',component:ExistbayComponent},
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SimulatorRoutingModule { }
