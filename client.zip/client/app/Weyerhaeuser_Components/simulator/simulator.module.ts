import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { SimulatorRoutingModule } from './simulator-routing.module';
import { BayComponent } from './bay/bay.component';
import { EntryComponent } from './entry/entry.component';
import { ExistbayComponent } from './existbay/existbay.component';
import { ParkingComponent } from './parking/parking.component';
import { SimulatorComponent } from './simulator.component';
import { TrappingbayComponent } from './trappingbay/trappingbay.component';
import { AllModule } from 'client/app/shared/all_modules';
import { OnlyzeroNotallowedDirective } from 'client/app/entity/onlyzero-notallowed.directive';


@NgModule({
  declarations: [
    SimulatorComponent,
    EntryComponent,
    ParkingComponent,
    BayComponent,
    TrappingbayComponent,
    ExistbayComponent,
    OnlyzeroNotallowedDirective,

  ],
  imports: [
    CommonModule,
    SimulatorRoutingModule,
    AllModule
  ],
  providers: [DatePipe]
})
export class SimulatorModule { }
