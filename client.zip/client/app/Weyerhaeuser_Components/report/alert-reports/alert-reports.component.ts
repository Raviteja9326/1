import { VehiclecustomerService } from './../../../services/vehiclecustomer.service';
import { FacilitymasterService } from './../../../services/facilitymaster.service';
import { AfterViewInit, Component, OnInit, SimpleChanges, ViewChild, } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatSelect } from '@angular/material/select';
import { Region } from 'client/app/entity/regional_site';
import { AllinoneService } from 'client/app/services/allinone.service';
import dayjs from 'dayjs/esm';
import { LocaleConfig } from 'ngx-daterangepicker-material';
import { ReplaySubject, Subject, takeUntil } from 'rxjs';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
@Component({
  selector: 'app-alert-reports',
  templateUrl: './alert-reports.component.html',
  styleUrls: ['./alert-reports.component.scss'],
})
export class AlertReportsComponent implements OnInit, AfterViewInit {
  dateSelectionFlag: boolean = false;
  // @ViewChild('heading', { static: false }) childReference: AlertTypeComponent;
  clickSubject: Subject<any> = new Subject();
  isLinear:boolean = false;
  clickSubjectpdf: Subject<any> = new Subject();
  clickSubjectexcel: Subject<any> = new Subject();
  viewReport_bol1: boolean = false;
  hideFlag: boolean = true;
  visible: Boolean = false;
  colum:number = 1;
  progressCard: any = '';
  RegionData: any = [];
  SitesData: any = [];
  locale: LocaleConfig = {
    format: 'YYYY-MM-DDTHH:mm:ss.SSSZ',
    displayFormat: 'MM-DD-YYYY',
    separator: ' To ',
    cancelLabel: 'Cancel',
    applyLabel: 'Okay',
  };
  ranges: any = {
    Today: [dayjs(), dayjs()],
    Yesterday: [dayjs().subtract(1, 'days'), dayjs().subtract(1, 'days')],
    'Last 7 Days': [dayjs().subtract(6, 'days'), dayjs()],
    'Last 30 Days': [dayjs().subtract(29, 'days'), dayjs()],
    'This Month': [dayjs().startOf('month'), dayjs().endOf('month')],
    'Last Month': [
      dayjs().subtract(1, 'month').startOf('month'),
      dayjs().subtract(1, 'month').endOf('month'),
    ],
  };
  invalidDates: dayjs.Dayjs[] = [
    dayjs(),
    dayjs().add(2, 'days'),
    dayjs().add(3, 'days'),
    dayjs().add(5, 'days'),
  ];
  selected: any;
  maxDate: dayjs.Dayjs = dayjs().add(0, 'days');
  minDate: dayjs.Dayjs;
  private readonly _destroying$ = new Subject<void>();
  currentDate: Date = new Date();
  resultData: any;
  hideRequired: boolean = true;
  dataForExcel = [];
  regionFilterCtrl: FormControl = new FormControl();
  public filteredRegions: ReplaySubject<Region[]> = new ReplaySubject<Region[]>(
    1
  );
  @ViewChild('regionSelect') regionSelect: MatSelect;
  displayExcelData: boolean = false;
  siteFilterCtrl: FormControl = new FormControl();
  public filteredSites: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('siteSelect') siteSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  protected _onDestroy2 = new Subject<void>();
  changeEndDate: boolean = true;
  prevPayload: any;
  prevSelectedDate: any;
  vehicleselect: any = '';
  vehicleId: any;
  facilitySelect: any = '';
  facilityId: any;
  datestart: any = '';
  date1: any;
  date2: any;
  dateend: any = '';
  alertsType: any = '';
  datalabels: any;
  alertsStatus: any = '';
  showstep:boolean = true;
  constructor(private Facilitymaster: FacilitymasterService, private vehicle_cust: VehiclecustomerService, private formBuilder: FormBuilder, private allone: AllinoneService, private datepipe: DatePipe, private toastr: ToastrService,
    private storageService: StorageService) {
    this.allone.getAlertdata('0');
    this.onSelectionChange('occupancy Alerts');
    this.allone.siteSource$.subscribe((data)=>{
      this.facilitySelect = {"facilityId":this.storageService.getvariable(),"facilityName":this.storageService.getSiteName()};
      this.getVehicle();
    });

  }
  ngOnInit(): void {
    this.getRegion();
  }
  clearInput() {
    this.selected = "";
    this.colum = 1;
    this.viewReport_bol1 = false;
  }
  onStepClick(event) {
    this.clearInput();
    if(event.selectedIndex == 0){
      this.onSelectionChange('occupancy Alerts');
      this.showstep = true;
    }
    else if(event.selectedIndex == 1){
      this.onSelectionChange('waiting Time Alerts');
      this.showstep = false;
    }
  }
 ngOnChanges(changes: SimpleChanges) {
    console.log('changes', changes);
    if (this.facilitySelect) {
      this.getVehicle();
    }
  }
 ngAfterViewInit() {
    setInterval(() => {
      this.progressCard = sessionStorage.getItem('loading');
    }, 1);
    this.setInitialValue();
  }
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
    this._onDestroy2.next();
    this._onDestroy2.complete();
    this.clickSubject.unsubscribe();
    this._destroying$.next(undefined);
    this._destroying$.complete();
    this.allone.clickSubjectAlert.unsubscribe();
    
  }
  reportsForm = this.formBuilder.group({
    siteName: [''],
    alertType: [''],
  })
  notify_data(event) {
    this.datalabels = event;
  }
  generatePDF() {
    if (this.datalabels == false) {
      this.toastr.warning('No data available for the selected criteria.');
      return;
    }
    let el = document.getElementById('mydiv');
    let el1 = document.getElementById('mydiv1');
    let el2 = document.getElementById('mydiv2');
    let el3 = document.getElementById('mydiv3');

    let totalcnt = "";
    if (this.alertsStatus == 'waiting Time Alerts') {
      var sGraph = document.getElementById('graph').innerHTML;
      el1 = document.getElementById('mydiv1');
      el1.style.display = 'none';
      el.style.display = 'block';
      totalcnt = document.getElementById('totalcnt1').innerHTML;
    }
    else{
      el3 = document.getElementById('mydiv3');
      el3.style.display = 'none';
      el2.style.display = 'block';
      totalcnt = document.getElementById('totalcnt2').innerHTML;
    }
    var sTable = document.getElementById('table').innerHTML;
    if (this.alertsStatus == 'waiting Time Alerts') {
      el1.style.display = 'block';
      el.style.display = 'none';
    }
    else{
      el3.style.display = 'block';
      el2.style.display = 'none';
    }


    let x = this.facilitySelect.facilityName;
    let y = (this.datepipe.transform(this.datestart, 'MM-dd-yyyy', "UTC"));
    let z = (this.datepipe.transform(this.dateend, 'MM-dd-yyyy', "UTC"));
    if (this.vehicleselect == "" || undefined) {
      var w = 'All Trucks';
    } else {
      w = this.vehicleselect.vehicleLicence;
    }
    if (this.alertsStatus == 'waiting Time Alerts') {
      var v = "Waiting Time Alerts";
    } else if (this.alertsStatus == 'occupancy Alerts') {
      v = "Occupancy Alerts";
    }
    let u = y + " " + "to" + " " + z
    var Filename = "Site Selected : " + x + "," + " Truck No. : " + w + "," + " Date Selected : From " + u + "," + " Alert Type: " + v;
    var style = "<style>";
    style = style + "table {width: 100%;font: 18px Calibri;}";
    style = style + "table, th, td{border: solid 1px #DDD; border-collapse: collapse; page-break: avoid !important;";
    style = style + "padding: 2px 3px; text-align: center;}";
    style = style + "mat-paginator div {display: none;}";
    style = style + "app-alert-type div {height: fit-content !important; margin-bottom:1px; display: flex; page-break: avoid !important;}";
    style = style + "</style>";
    let name = "Alert Report";
    var title = "<title>" + name + "</title>";
    var printWindow = window.open('newWin.html', 'NewWindow', 'menubar=0,scrollbars=1,height=768,width=1366, top=10');
    printWindow.document.write('<html moznomarginboxes mozdisallowselectionprint><head>' + "<h4 style='color: black; text-align: center; font-size:18px;'>" + Filename);
    printWindow.document.write(title);
    printWindow.document.write(style);
    printWindow.document.write('</h4>');
    printWindow.document.write('</head><body>');
    if (this.alertsStatus == 'waiting Time Alerts') {
      printWindow.document.write(sGraph);
    }
    printWindow.document.write("<br><br> <b>Alerts Total Count :" + totalcnt + "</b>")
    printWindow.document.write(sTable);
    printWindow.document.write('</body></html>');
    setTimeout(function () {
      printWindow.print();
      printWindow.close();
    }, 100);


  }
  protected setInitialValue() {}
  protected filterRegions() {
    if (!this.RegionData) {
      return;
    }
    // get the search keyword
    let search = this.regionFilterCtrl.value;
    if (!search) {
      this.filteredRegions.next(this.RegionData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredRegions.next(
      this.RegionData.filter(
        (region) => region.facilityName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  protected filterSites() {
    if (!this.SitesData) {
      return;
    }
    // get the search keyword
    let search = this.siteFilterCtrl.value;
    if (!search) {
      this.filteredSites.next(this.SitesData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredSites.next(
      this.SitesData.filter(
        (site: any) => site.vehicleLicence.toLowerCase().indexOf(search) > -1
      )
    );
  }
  isInvalidDate = (m: dayjs.Dayjs) => {
    return this.invalidDates.some(d => d.isSame(m, 'day'))
  }

  getRegion() {
    this.RegionData = [];
    this.Facilitymaster.getfacilitymaster().subscribe((res) => {
      if (res.elements.length !== 0) {
        res.elements[0].forEach(((x) => {
          if (x.isActive == true) {
            this.RegionData.push(x)
          }
        }));
        this.filteredRegions.next(this.RegionData.slice());
        this.regionFilterCtrl.valueChanges
          .pipe(takeUntil(this._onDestroy))
          .subscribe(() => {
            this.filterRegions();
          });
      } else if (res.elements.length == 0) {
        this.RegionData = [];
        this.filteredRegions.next(this.RegionData.slice());
      }
    });
  }
  getVehicle() {
    this.SitesData = [];
    let data = {};
    (data['facilityId'] = this.facilitySelect.facilityId),
      this.vehicle_cust.getVehicleforReport(data).subscribe((res: any) => {
        if (res.elements.length !== 0) {
          res.elements.forEach((x) => {
            this.SitesData.push(x);
          });
          this.filteredSites.next(this.SitesData.slice());
          this.siteFilterCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
              this.filterSites();
            });
        } else if (res.elements.length == 0) {
          this.SitesData = [];
          // this.vehicleselect = "";
          this.filteredSites.next(this.SitesData.slice());
        }
      });
  }
  onSelectionChange(ID: any) {
    if (ID.facilityId) {
      this.facilitySelect = ID;
      this.getVehicle();
    } else if (ID.vehicleLicence || ID == "") {
      this.vehicleselect = ID
    }
    if (ID == 'occupancy Alerts') {
      this.alertsType = ID;
    } else if (ID == 'waiting Time Alerts') {
      this.alertsType = ID;

    }
    this.visible = false;
  }
  reportsubmit() {
    console.log(this.selected);
   if (this.selected.startDate == null || this.selected.startDate == "") {
      this.dateSelectionFlag = true;
    }
    else if (this.reportsForm.valid && this.selected.startDate != null || this.selected.startDate == "") {
      this.allone.clickSubjectAlert.next({
        facilityId:this.facilitySelect,
        date1: this.datestart,
        date2: this.dateend,
        vehicleId: this.vehicleselect,
        alerts:this.alertsType

      });
      this.viewReport_bol1 = true;
      this.alertsStatus = this.alertsType;
      this.colum = 2;
    }
  }

  rangeClicked($eve) {
    if ($eve.startDate !== null && $eve.endDate !== null) {
      this.datestart = $eve.startDate;
      this.dateend = new Date($eve.endDate).toISOString();
      this.dateSelectionFlag = false;
    }
   else if(this.dateSelectionFlag){
    console.log(this.dateSelectionFlag)
      !this.datestart|| !this.dateend? this.dateSelectionFlag=true:this.dateSelectionFlag=false
    }
  }


  dateSelect($eve) {
    let startDate1 = $eve.dates[0].$d;
    let endDate1 = $eve.dates[1].$d;
    if(this.dateSelectionFlag)
      !startDate1 || !endDate1? this.dateSelectionFlag=true:this.dateSelectionFlag=false
  }



  exportExcel() {
    let res = this.allone.getAlertSource();
      if(res){
        if(res.elements?.length>0){

          let x = [];
          let i = 1;
          x = res.elements;
          if (this.alertsStatus == 'waiting Time Alerts') {
            this.resultData = [];
            this.dataForExcel = [];
            x.forEach((ele) => {
              let obj = {};
              obj['SrNo.'] = i++;
              (obj['Truck No.'] = ele.vehicleLicence),
                (obj['Alert Name'] = ele.alertName),
                (obj['Waiting Time'] = ele.parameterValue),
                (obj['Raised On'] = this.datepipe.transform(
                  ele.entryTime,
                  'MM-dd-yyyy HH:mm', "EDT"
                )),
                this.resultData.push(obj);
              // ele.entryTime = (this.datepipe.transform(ele.entryTime, 'yyyy-MM-dd HH:mm')),
            });
          } else if (this.alertsStatus == 'occupancy Alerts') {
            this.resultData = [];
            this.dataForExcel = [];
            x.forEach((ele) => {
              let obj = {};
              obj['SrNo.'] = i++;
              (obj['Alert Name'] = ele.alertName),
                (obj['Occupancy Value'] = ele.parameterValue),
                (obj['Raised On'] = this.datepipe.transform(
                  ele.entryTime,
                  'MM-dd-yyyy HH:mm', "EDT"
                )),
                this.resultData.push(obj);
              // ele.entryTime = (this.datepipe.transform(ele.entryTime, 'yyyy-MM-dd HH:mm')),
            });
          }
          //console.log(this.resultData);
          // this.resultData = this.dataSourceOriginal.elements;
          // });
          //Create a workbook with a worksheet
          let workbook = new Workbook();
          let worksheet = workbook.addWorksheet('Alert report');
          //add column name
          if (this.alertsStatus == 'waiting Time Alerts') {
            var header = [
              'Sr.No.',
              'Truck No.',
              'Alert Name',
              'Waiting Time (Mins)',
              'Date & Time',
            ];
          } else if (this.alertsStatus == 'occupancy Alerts') {
            var header = ['Sr.No.', 'Alert Name', 'Occupancy Value', 'Date & Time'];
          }
    
          let siteRow = worksheet.addRow(['Site Name', this.facilitySelect.facilityName]);
          siteRow.eachCell((cell, number) => {
            cell.font = {
              bold: true,
              color: { argb: '00000' },
              size: 12,
            };
          });
          let headerRow = worksheet.addRow(header);
          headerRow.eachCell((cell, number) => {
            cell.font = {
              bold: true,
              color: { argb: '00000' },
              size: 12,
            };
          });
          this.resultData.forEach((row: any) => {
            this.dataForExcel.push(Object.values(row));
          });
          this.dataForExcel.forEach((d) => {
            let row = worksheet.addRow(d);
          });
          worksheet.getColumn(3).width = 20;
          worksheet.addRow([]);
          let title = 'Alert Report';
          workbook.xlsx.writeBuffer().then((data) => {
            let blob = new Blob([data], {
              type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            });
            fs.saveAs(blob, title + '.xlsx');
          });
        
      }
    else{
        this.toastr.warning('No data available for the selected criteria.');
        return;
      
    }
    }
      else{
        this.toastr.warning('No data available for the selected criteria.');
        return;
      }
   
   
  }
}


