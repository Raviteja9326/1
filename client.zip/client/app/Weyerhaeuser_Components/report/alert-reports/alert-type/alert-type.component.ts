import { BayMasterService } from 'client/app/services/bay-master.service';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import * as Highcharts from 'highcharts';
import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ChartComponent,
  ApexLegend
} from "ng-apexcharts";
import { AllinoneService } from 'client/app/services/allinone.service';
export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  labels: string[];
  plotOptions: ApexPlotOptions;
  legend: ApexLegend;
};
@Component({
  selector: 'app-alert-type',
  templateUrl: './alert-type.component.html',
  styleUrls: ['./alert-type.component.scss']
})
export class AlertTypeComponent implements OnInit {
  @Input('clickSubject') clickSubject: Subject<any>;
  @Input('clickSubjectpdf') clickSubjectpdf: Subject<any>;
  @Input() facilityId: any;
  @Input() date1: any;
  @Input() date2: any;
  @Input() vehicleId: any;
  @Input() alerts;
  alertsStatus: any = '';
  public colors = ['#488A99', '#7cbb87', '#fdcf65', '#f18585'];
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  heights: string = '100%';
  heights2: string = '100%';
  private readonly _destroying$ = new Subject<void>();
  @Input() occupancyupdate = '';
  highcharts = Highcharts;
  loading: boolean = true;
  viewReport_bol = false;
  dateocupancy2: any = [];
  dateLables: boolean = true;
  names: any;
  bayId: any;
  occupied: any;
  unoccupied: any;
  x: any;
  y: any;
  z: any;
  w: any;
  a: any;
  constructor(private allone: AllinoneService, private userser: StorageService, private Bay_cust: BayMasterService,
    private toastr: ToastrService, private route: Router, private datepipe: DatePipe) { }


 
  private subscriptions = new Subscription();

  ngOnInit(): void {
    this.subscriptions = this.allone.clickSubjectAlert.subscribe(e => {
      // console.log(e, 'event fired')
      if (e) {
        this.getalerttypes();
      }
    })
    this.getalerttypes();
  }

  getUsername() {
    this.names = this.userser.getuser();
  }
  getalerttypes() {
    // this.viewReport_bol = true;
    this.loading = true;
    this.subscriptions.add(this.allone.alertGraphStubSource$.subscribe({
      next: (res) => {
        // console.log(22, res)
        if (res !== undefined) {
          if (res?.totalAlert && res?.totalAlert?.length !== 0) {
            this.x = res.totalAlert[0].Parking;
            this.y = res.totalAlert[0].Loading;
            this.z = res.totalAlert[0].Tarping;
            this.a = res.totalAlert[0].turnAround;
            this.alertsStatus = this.alerts;
            this.chartInit();
            this.dateLables = true;
            this.loading = false
          } else if (res?.totalAlert && res?.totalAlert?.length == 0) {
            this.loading = false
            this.dateLables = false
            this.alertsStatus = this.alerts
          }
        }
      }, error: (error) => {
        this.loading = false;
        this.toastr.error(error.error.message)
      }
    })), (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
    }
  }


  public openPDF(): void {
    let DATA: any = document.getElementById('capture');
    // document.getElementById("capture").style.overflow = "visible";
    // document.getElementById("capture").style.width = "100%";
    // document.getElementById("capture").style.height = "100%";
    // document.getElementById("capture").style.maxHeight = "100%";
    // setTimeout(() => {
    //   html2canvas(DATA).then((canvas) => {
    //     let fileWidth = 210;
    // let fileHeight = (canvas.height * fileWidth) / canvas.width;
    // let fileHeight = (canvas.height * fileWidth) / canvas.width;;
    // let pagesplit = true
    // const FILEURI = canvas.toDataURL('image/png');
    // let PDF = new jsPDF('p', 'mm', 'a4');
    // var width = PDF.internal.pageSize.getWidth();
    // var height = canvas.height * width / canvas.width
    // let position = 3;
    // PDF.addImage(FILEURI, 'PNG', 0, position, width, height);
    // PDF.addPage();
    //     PDF.save('angular-demo.pdf');
    //   });
    // }, 1000);
    // window.location.reload();
    // document.getElementById("capture").style.display = "none";
  }







  chartInit() {
    this.linechartOptions = {
      chart: {
        type: 'column',
        backgroundColor: '#fff',
        zooming: { type: 'x' },
        marginTop: 30,
        height: (8.2 / 23.2 * 100) + '%'
      },
      accessibility: {
        enabled: false,
      },
      credits: {
        text: '',
        href: '',
      },
      title: {
        text: ''
      },
      subtitle: {
        text: ''
      },
      xAxis: {
        categories: ['Type Of Alerts'],
        crosshair: true,
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
      },
      yAxis: {
        min: 0,
        tickInterval: 5,
        title: {
          text: 'Number Of Alerts',
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          },
        },
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px; font-weight:600">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0;font-weight:600">{series.name}: </td>' +
          '<td style="padding:0; font-weight:600"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: false,
        useHTML: true,
        valueDecimals: 0,
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        x: 0,
        y: 25,
        floating: false,
        itemMarginTop: 5,
        itemMarginBottom: 5,
        itemStyle: {
          lineHeight: '10px',
        }
      },
      plotOptions: {
        column: {
          groupPadding: 0.9,
          pointPadding: 0.2,
          borderWidth: 0,
          pointWidth: 10,
        }
      },
      series: [{
        type: 'column',
        name: 'Parking',
        color: '#008357',
        data: [this.x]
      }, {
        type: 'column',
        name: 'Loading',
        color: '#0da4eb',
        data: [this.y]
      }, {
        type: 'column',
        name: 'Tarping',
        color: '#ffa042',
        data: [this.z]
      },{
        type: 'column',
        name: 'Total Turn Around',
        color: '#ff0000',
        data: [this.a]
      }]
    }
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    // this.clickSubject.unsubscribe();
    this.subscriptions.unsubscribe();

  }


}
