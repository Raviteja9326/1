import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { AlertmasterService } from 'client/app/services/alertmaster.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Totalexpand } from 'client/app/shared/search';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import * as fs from 'file-saver';
import { ToastrService } from 'ngx-toastr';
import { Workbook } from 'exceljs';
import { AllinoneService } from 'client/app/services/allinone.service';

@Component({
  selector: 'app-alert-evaluation',
  templateUrl: './alert-evaluation.component.html',
  styleUrls: ['./alert-evaluation.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class AlertEvaluationComponent implements OnInit {
  @Input('clickSubject') clickSubject: Subject<any>;
  @Input('clickSubjectpdf') clickSubjectpdf: Subject<any>;
  @Input('clickSubjectexcel') clickSubjectexcel: Subject<any>;
  @Output() viewReport_bolEmit = new EventEmitter<any>();
  reportEvent: any;
  @Input() facilityId: any;
  @Input() date1: any;
  @Input() date2: any;
  @Input() vehicleId: any;
  @Input() timeupdate = '';
  @Input() alerts;
  alertsStatus: any = '';
  localDate: any;
  latestDate: any;
  intervalId = null;
  dataSource: MatTableDataSource<any>;
  dataSource1: MatTableDataSource<any>;
  dataSourceOriginal: any;
  dataForExcel = [];
  resultData: any;
  result: any;
  private readonly _destroying$ = new Subject<void>();
  protected _onDestroy2 = new Subject<void>();
  date = new Date();
  largeScreen: string = 'max-heght_table';
  opt_screen: string;
  displayNoRecords: boolean = false;
  displayNoRecords2: boolean = false;
  _value = '';
  pageIndex: number = 1;
  pageSize: number = 20;
  pageNo: number = 0;
  totalItems: number;
  ELEMENT_DATA: any;
  loading: boolean = true;
  expanded: boolean = false;
  fullscreen_bol: boolean = false;
  @ViewChild(MatSort) sort: MatSort;
  @Output('matSortChange')
  sortChange: EventEmitter<Sort>;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild('fullScreen') divRef;
  @ViewChild('capture') divRef1;
  viewReport_bol: boolean = false;
  PDF_Width: any = 0;
  pageHeight: any = 0;
  prevSize = 0;
  currSize = 0;
  timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  displayedColumns1: string[] = [
    'vehicleLicence',
    'alertName',
    'parameterValue',
    'entryTime',
  ];
  displayedColumns2: string[] = ['alertName', 'parameterValue', 'entryTime'];
  facilitySelect: { facilityId: any; facilityName: any; };
  constructor(
    private alertmaster: AlertmasterService,
    private allone: AllinoneService,
    private toastr: ToastrService,
    private route: Router,
    private datepipe: DatePipe,
    private userser: StorageService,
    
  ) {
    this.allone.siteSource$.subscribe((data)=>{
      this.facilitySelect = {"facilityId":this.userser.getvariable(),"facilityName":this.userser.getSiteName()};
    });
  }
  private subscriptions = new Subscription();

  ngOnInit(): void {
    this.subscriptions = this.allone.clickSubjectAlert.subscribe((e) => {
      //console.log(e, 'event fired');
      if (e) {
        this.facilityId = e.facilityId;
        this.date1 = e.date1;
        this.date2 = e.date2;
        this.vehicleId = e.vehicleId;
        this.alerts = e.alerts;
        this.pageIndex = 1;
        this.pageSize = 20;

        this.getReportLists();
      } else {
        this.toastr.warning('Fields are mandatory');
      }
    });
    this.getReportLists();
    // this.clickSubjectpdf.subscribe(event => {
    //   //console.log(event, 'event fired')
    //   if (event) {
    //     this.generatePDFtable();
    //   } else {
    //     this.toastr.warning('Fields are mandatory')
    //   }
    // })
    
  }

  ngOnChanges(changes: SimpleChanges) {
    // this.getReportLists
    //console.log('changes', changes);
    // this.pageIndex = 1;
    // this.pageSize = 20;
  }

  ngAfterViewInit(): void {
    this.intervalId = setInterval(() => {
      this.date = new Date();
    })
    if(this.dataSource)
    {this.dataSource.sort = this.sort;}

    if(this.dataSource1)

      {this.dataSource1.sort = this.sort;}
    // this.intervalId = setInterval(() => {
    //   this.localDate = this.datepipe.transform(sessionStorage.getItem('vehiclemove'), 'yyyy-MM-dd HH:mm');
    //   this.latestDate = this.datepipe.transform(this.timeupdate, 'yyyy-MM-dd HH:mm');
    //   this.calldataback(this.latestDate, this.localDate);
    // }, 25000)
  }
  // calldataback(arg1, arg2) {
  //   if (arg1 > arg2) {
  //     this.getJobcard();
  //     sessionStorage.setItem('vehiclemove', this.latestDate);
  //   }
  // }

  applyFilter(event: Event) {
    this.result = [];
    let filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();
    for (let el of this.ELEMENT_DATA.elements) {
      let EvehicleLicence = el.vehicleLicence;
      let EincomingTime = this.datepipe.transform(
        el.incomingTime,
        'dd-MM-YYYY HH:mm'
      );
      let EwaitingTime = JSON.stringify(el.waitingTime);
      let EoutgoingTime = this.datepipe.transform(
        el.outgoingTime,
        'dd-MM-YYYY HH:mm'
      );
      let a = EvehicleLicence.toLocaleLowerCase().includes(filterValue);
      let b = EincomingTime.toLocaleLowerCase().includes(filterValue);
      let c = EwaitingTime.toLocaleLowerCase().includes(filterValue);
      if (EoutgoingTime !== null) {
        var d = EoutgoingTime.toLocaleLowerCase().includes(filterValue);
      }
      if (a == true || b == true || c == true || d == true) {
        this.result.push(el);
      }
    }
    if (this.result.length == 0) {
      this.dataSource1 = new MatTableDataSource<any>([]);
      this.dataSource1.paginator = this.paginator;
    }
    if (this.result.length !== 0) {
      this.dataSource1 = new MatTableDataSource<any>(this.result);
      this.paginator.length = this.ELEMENT_DATA.metadata.total;
      this.dataSource1.paginator = this.paginator;
      this.dataSource1['sort'] = this.sort;
    }
    if (this._value == '') {
      this.pageIndex = 1;
      this.pageSize = 20;
      this.getReportLists();
    }
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;

    this.getReportLists();
  }

  getReportLists() {
    this.loading = true;
    this.alertsStatus = this.alerts;
    this.dataSourceOriginal = [];
    this.viewReport_bol = true;
    //console.log(111, this.date2);
    let pageIndx = this.pageIndex;
    let pageSize = this.pageSize;
    const data = {};
    if (this.alerts == 'waiting Time Alerts') {
      data['alertType'] = 'timeAlert';
    } else if (this.alerts == 'occupancy Alerts')
      [(data['alertType'] = 'occupancyAlert')];
    (data['facilityId'] = this.facilityId.facilityId),
      (data['from_date'] = this.datepipe.transform(
        this.date1,
        'yyyy-MM-dd',
        'UTC'
      )),
      (data['to_date'] = this.datepipe.transform(
        this.date2,
        'yyyy-MM-dd',
        'UTC'
      )),
      (data['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone);
    (data['vehicleLicence'] = this.vehicleId.vehicleLicence), //console.log(data);
      (this.totalItems = 0);
    this.alertmaster
      .getAlertReport(pageIndx, pageSize, data)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          if (res != null) {
            /* console.log(res)
             debugger; */
            this.totalItems = res.metadata.total;
            this.ELEMENT_DATA = res;
            this.allone.setSubsSource(res);
            if (res.elements.length !== 0) {
              this.viewReport_bolEmit.emit(true);
              this.loading = false;
              this.displayNoRecords = false;
              this.dataSource1 = new MatTableDataSource<any>(
                this.ELEMENT_DATA.elements
              );
              this.dataSource1.sort = this.sort
              //Make blank export table
              this.dataSource = new MatTableDataSource<any>([]);
              this.dataSourceOriginal = [];
              this.totalItems = res.metadata.total;
              //console.log(this.dataSource);
              setTimeout(() => {
                this.dataSource1.sort = this.sort;
                this.pageIndex = res.metadata.current_page - 1;
              });
              // debugger;
              // if (this.currSize != this.totalItems) {
              //   this.prevSize = 11;
              // }
              // if (this.prevSize == 11) {
                // this.currSize = this.totalItems;
                // this.prevSize = 11;

                pageIndx = 1;
                this.alertmaster
                  .getAlertReport(pageIndx, this.totalItems, data)
                  .pipe(takeUntil(this._destroying$))
                  .subscribe({
                    next: (res) => {
                      if (res != null) {
                        // debugger;
                        this.ELEMENT_DATA = res;
                        this.allone.setAlertGraphStub(res);
                        this.allone.setAlertSource(res);
                        if (res.elements.length !== 0) {
                          // if (this.prevSize == 11) {
                            this.prevSize = this.totalItems;
                            this.dataSource = new MatTableDataSource<any>(
                              this.ELEMENT_DATA.elements
                            );
                            this.dataSourceOriginal =
                              this.ELEMENT_DATA.elements;
                          // }
                        }
                      }
                    },
                  }
                  );
              // }
            }
            else{
              this.allone.setAlertGraphStub(res);
              this.allone.setAlertSource(res);
            }
          }
          if (res.elements.length == 0) {
            this.dataSource = new MatTableDataSource<any>([]);
            this.dataSource1 = new MatTableDataSource<any>([]);
            this.allone.setAlertSource(res);
            this.allone.setAlertGraphStub(res);
            this.viewReport_bolEmit.emit(false);
            this.ELEMENT_DATA = [];
            this.totalItems = 0;
            this.pageSize = 20;
            this.pageIndex = 0;
            this.displayNoRecords = true;
            this.loading = false;
            this.alertsStatus = this.alerts;
            this.currSize = 0;
          }
        },
      }),
      (error) => {
        this.toastr.error(error.error.message);
        this.route.navigate(['/dashboard/errors']);
      };
  }

  openFullscreen() {
    const body = document.getElementsByTagName('body')[0];
    if (this.fullscreen_bol == false) {
      this.largeScreen = 'large';
      this.opt_screen = 'fullscreen';
      this.fullscreen_bol = true;
      body.classList.add('open');
    } else if (this.fullscreen_bol == true) {
      this.largeScreen = 'max-heght_table';
      this.opt_screen = '';
      this.fullscreen_bol = false;
      body.classList.remove('open');
    }
  }

  close() {
    this._value = '';
    if (this._value == '') {
      this.pageIndex = 1;
      this.pageSize = 20;
      this.getReportLists();
    }
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      //console.log('search');
    }
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }

  // generatePDFtable() {
  //   const doc = new jsPDF('l', 'pt');
  //   doc.setFontSize(15);
  //   doc.setTextColor(10);
  //   let x = this.facilityId.facilityName;
  //   let y = (this.datepipe.transform(this.date1, 'yyyy-MM-dd', "UTC"));
  //   let z = (this.datepipe.transform(this.date2, 'yyyy-MM-dd', "UTC"));
  //   if (this.vehicleId == "") {
  //     var w = 'All Trucks';
  //   } else {
  //     w = this.vehicleId.vehicleLicence;
  //   }
  //   let u = y + " " + "to" + " " + z
  //   doc.text("Site Selected" + ":" + " " + x + "          " + "Date Selected" + ":" + " " + u + "          " + "Truck No." + ":" + " " + w, 80, 50);
  //   autoTable(doc, {
  //     html: '#my-table', theme: 'plain', startY: 70,
  //     columnStyles: {
  //       0: {
  //         halign: 'center',
  //         valign: 'middle'
  //       },
  //       1: {
  //         halign: 'center',
  //         valign: 'middle'
  //       },
  //       2: {
  //         halign: 'center',
  //         valign: 'middle'
  //       },
  //       3: {
  //         halign: 'center',
  //         valign: 'middle'
  //       },
  //       4: {
  //         halign: 'center',
  //         valign: 'middle'
  //       }
  //     },
  //     headStyles: { lineWidth: 1, minCellHeight: 10, fillColor: "black", textColor: "white", halign: 'center', valign: 'middle' },
  //     // valign: 'middle',minCellHeight: 10,lineColor:[255,45,45]// can be added in head style
  //     // bodyStyles: {minCellHeight: 30}, //imp
  //     head: [],
  //     body: [],
  //     didParseCell: (hookData) => {
  //       if (hookData.section === 'head') {
  //         if (hookData.column.dataKey === 0 || 1 || 2 || 3 || 4) {
  //           hookData.cell.styles.valign = 'middle';
  //         }
  //       }
  //     },
  //   })
  //   doc.save('AlertReportTable.pdf')
  // }

  exportExcel() {
    if (this.displayNoRecords == true) {
      this.toastr.warning('No data available for the selected criteria.');
      return;
    }
    if (this.ELEMENT_DATA.elements?.length !== 0) {
      let x = [];
      let i = 1;
      x = this.dataSourceOriginal;
      if (this.alertsStatus == 'waiting Time Alerts') {
        this.resultData = [];
        this.dataForExcel = [];
        x.forEach((ele) => {
          let obj = {};
          obj['SrNo.'] = i++;
          (obj['Truck No.'] = ele.vehicleLicence),
            (obj['Alert Name'] = ele.alertName),
            (obj['Waiting Time'] = ele.parameterValue),
            (obj['Raised On'] = this.datepipe.transform(
              ele.entryTime,
              'MM-dd-yyyy HH:mm', "EDT"
            )),
            this.resultData.push(obj);
          // ele.entryTime = (this.datepipe.transform(ele.entryTime, 'yyyy-MM-dd HH:mm')),
        });
      } else if (this.alertsStatus == 'occupancy Alerts') {
        this.resultData = [];
        this.dataForExcel = [];
        x.forEach((ele) => {
          let obj = {};
          obj['SrNo.'] = i++;
          (obj['Alert Name'] = ele.alertName),
            (obj['Occupancy Value'] = ele.parameterValue),
            (obj['Raised On'] = this.datepipe.transform(
              ele.entryTime,
              'MM-dd-yyyy HH:mm', "EDT"
            )),
            this.resultData.push(obj);
          // ele.entryTime = (this.datepipe.transform(ele.entryTime, 'yyyy-MM-dd HH:mm')),
        });
      }
      //console.log(this.resultData);
      // this.resultData = this.dataSourceOriginal.elements;
      // });
      //Create a workbook with a worksheet
      let workbook = new Workbook();
      let worksheet = workbook.addWorksheet('Alert report');
      //add column name
      if (this.alertsStatus == 'waiting Time Alerts') {
        var header = [
          'Sr.No.',
          'Truck No.',
          'Alert Name',
          'Waiting Time (Mins)',
          'Date & Time',
        ];
      } else if (this.alertsStatus == 'occupancy Alerts') {
        var header = ['Sr.No.', 'Alert Name', 'Occupancy Value', 'Date & Time'];
      }

      let siteRow = worksheet.addRow(['Site Name', this.facilitySelect.facilityName]);
      siteRow.eachCell((cell, number) => {
        cell.font = {
          bold: true,
          color: { argb: '00000' },
          size: 12,
        };
      });
      let headerRow = worksheet.addRow(header);
      headerRow.eachCell((cell, number) => {
        cell.font = {
          bold: true,
          color: { argb: '00000' },
          size: 12,
        };
      });
      this.resultData.forEach((row: any) => {
        this.dataForExcel.push(Object.values(row));
      });
      this.dataForExcel.forEach((d) => {
        let row = worksheet.addRow(d);
      });
      worksheet.getColumn(3).width = 20;
      worksheet.addRow([]);
      let title = 'Alert Report';
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        fs.saveAs(blob, title + '.xlsx');
      });
    }
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    this.subscriptions.unsubscribe();
    this.clickSubject.unsubscribe();
    this.clickSubjectpdf.unsubscribe();
    this.clickSubjectexcel.unsubscribe();
    clearInterval(this.intervalId);
  }
}
