import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportRoutingModule } from './report-routing.module';
import { ReportComponent } from './report.component';
import { AlertTableComponent } from './alert-occupancy/alert-table/alert-table.component';
import { AllModule } from 'client/app/shared/all_modules';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { AlertOccupancyComponent } from './alert-occupancy/alert-occupancy.component';
import { DatePipe } from '@angular/common';
import { AlertEvaluationComponent } from './alert-reports/alert-evaluation/alert-evaluation.component';
import { AlertReportsComponent } from './alert-reports/alert-reports.component';
import { AlertTypeComponent } from './alert-reports/alert-type/alert-type.component';
import { PenaltyreportComponent } from './penaltyreport/penaltyreport.component';
import { PenaltygraphComponent } from './penaltyreport/penaltygraph/penaltygraph.component';
import { PenaltygraphtableComponent } from './penaltyreport/penaltygraphtable/penaltygraphtable.component';
import { PenaltytableComponent } from './penaltyreport/penaltytable/penaltytable.component';
import { AverageWaitingtimeTableComponent } from './alert-occupancy/average-waitingtime-table/average-waitingtime-table.component';
import { AverageWaitingtimeGraphComponent } from './alert-occupancy/average-waitingtime-graph/average-waitingtime-graph.component';
import { AverageWaitingtimeWeekwiseComponent } from './alert-occupancy/average-waitingtime-weekwise/average-waitingtime-weekwise.component';

@NgModule({
  declarations: [ReportComponent, AlertTableComponent, AlertOccupancyComponent,AlertReportsComponent,
    AlertTypeComponent, AlertEvaluationComponent, PenaltyreportComponent, PenaltygraphComponent, PenaltygraphtableComponent, PenaltytableComponent,
    AverageWaitingtimeTableComponent, AverageWaitingtimeGraphComponent,AverageWaitingtimeWeekwiseComponent],
  imports: [
    CommonModule,
    ReportRoutingModule,
    AllModule,
    NgxDaterangepickerMd.forRoot(),
  ],
  providers: [DatePipe],
})
export class ReportModule {}
