import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportComponent } from './report.component';
import { AlertOccupancyComponent } from './alert-occupancy/alert-occupancy.component';
import { AlertReportsComponent } from './alert-reports/alert-reports.component';
import { PenaltyreportComponent } from './penaltyreport/penaltyreport.component';
const routes: Routes = [
  {path:'',component:ReportComponent,children:[
        {path:'alertoccupancy',component:AlertOccupancyComponent},
        {path:'alertreport',component:AlertReportsComponent},
        {path:'penaltyreport',component:PenaltyreportComponent},
     ]}
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
