import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import Highcharts from 'highcharts';

@Component({
  selector: 'app-penaltygraph',
  templateUrl: './penaltygraph.component.html',
  styleUrls: ['./penaltygraph.component.scss']
})
export class PenaltygraphComponent implements OnInit {

  @Input() penaltygraph:any;
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  loading: boolean = true;
  dateLables: any = [];
  dateocupancy: any;
  dateocupancy2: any = [];
  heights: string = '100%';
  heights2: string = '100%';

  constructor(private datepipe: DatePipe) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.loading = true;
      this.dateLables = [];
      this.dateocupancy = [];
      this.dateocupancy2 = [];
    if(changes.penaltygraph.currentValue != undefined || null){
    this.dateocupancy = changes.penaltygraph.currentValue?.data?changes.penaltygraph.currentValue?.data:[];
     if(this.dateocupancy !=0){
      for (let dateTime of  this.dateocupancy) {
        this.dateLables.push(this.datepipe.transform(dateTime.date, 'MMM d','UTC'));
        this.dateocupancy2.push(dateTime.totalPenalty);
      };
      this.graphsbydate();
    }
    setTimeout(()=>{
      this.loading = false;
    },1000);
  }
  }
  graphsbydate(){
    console.log(this.dateLables, this.dateocupancy2)
    this.linechartOptions = {
      chart: {
        type: 'column',
        zooming: { type: 'x' },
        height: (16 / 23.2 * 100) + '%'
    },
    title: {
        text: ''
    },
    credits: {
      text: '',
      href: '',
    },
    subtitle: {
        text: ''
    },
    accessibility: {
      enabled: false,
    },
    xAxis: {
        type: 'category',
        categories: [...this.dateLables],
        gridLineWidth: 0.5,
        lineWidth: 0,
        lineColor: 'transparent',
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    yAxis: {
      gridLineWidth: 0.5,
        title: {
            text: ''
        },
        labels: {
          enabled: true,
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    legend: {
        enabled: false
    },
    plotOptions: {
      column: {
        pointPadding: 0.2,
        borderWidth: 0,
        pointWidth: 25
    },
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: false,
            },
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span>{point.name}</span> <b>{point.y} USD</b><br/>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
        style :{
          color: '#000',
          fontWeight: '600',
          fontFamily: '"Roboto", sans-serif',
        }
    },

    series: [
        {
           type : 'column',
            name: 'Penalty Charges',
            colorByPoint: false,
            data: [...this.dateocupancy2],
            color: '#15b695'
        }
    ],
}
}

}
