import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { AllinoneService } from 'client/app/services/allinone.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { PenaltymasterService } from 'client/app/services/penalty-master.service';
import { VehiclecustomerService } from 'client/app/services/vehiclecustomer.service';
import * as moment from 'moment';
import 'moment-timezone';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { ToastrService } from 'ngx-toastr';
import { ReplaySubject, Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-penaltyreport',
  templateUrl: './penaltyreport.component.html',
  styleUrls: ['./penaltyreport.component.scss']
})
export class PenaltyreportComponent implements OnInit {
  dateSelectionFlag:boolean = false;
  private readonly _destroying$ = new Subject<void>();
  selected: any;
  penaltytable:any;
  penaltygraphtable:any;
  sitedata: any;
  vehicleData: any;
  ranges: any;
  maxDate: any;
  minDate: any;
  datestart: any = '';
  dateend: any = '';
  hideicons:boolean = false;
  systemTimezone:any;
  regionFilterCtrl: FormControl = new FormControl();
  public filteredRegions: ReplaySubject<any[]> = new ReplaySubject<any[]>(
    1
  );
  truckFilterCtrl: FormControl = new FormControl();
  public filteredTrucks: ReplaySubject<any[]> = new ReplaySubject<any[]>(
    1
  );
  resultData1:any=[];
  resultData2:any=[];
  protected _onDestroy = new Subject<void>();
  protected _onDestroy1 = new Subject<void>();
  facilityID: { facilityId: any; facilityName: any; };
  penaltytable_pdf: any = [];
  show: boolean = false;
  constructor(private adminService: FacilitymasterService, private toastr: ToastrService, private vehicle:VehiclecustomerService, private formBuilder: FormBuilder, private penalty:PenaltymasterService, private route:Router, private storageService: StorageService,private allone:AllinoneService, private datepipe: DatePipe) {
    this.allone.siteSource$.subscribe((data)=>{
    this.facilityID = {"facilityId":this.storageService.getvariable(),"facilityName":this.storageService.getSiteName()};
    this.getTruckNumber(this.facilityID.facilityId);
    });
    this.systemTimezone = "America/New_York";
    moment.tz.setDefault(this.systemTimezone);
    this.showcoverstions();
   }

   showcoverstions(){
    const currentDateTime = moment();
    const estOffset = moment().tz(this.systemTimezone).utcOffset();
    this.selected = {
      startDate: moment()?.hour(0).minute(0),
      endDate: currentDateTime
    };
    this.ranges = {
      'Today': [moment().utcOffset(estOffset).hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'Yesterday': [moment().utcOffset(estOffset).subtract(1, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).subtract(1, 'days').endOf('day').hour(23).minute(59).format('YYYY-MM-DD HH:mm')],
  'Last 7 Days': [moment().utcOffset(estOffset).subtract(6, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'Last 30 Days': [moment().utcOffset(estOffset).subtract(29, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'This Month': [moment().utcOffset(estOffset).startOf('month').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).endOf('month').format('YYYY-MM-DD HH:mm')],
  'Last Month': [moment().utcOffset(estOffset).subtract(1, 'month').startOf('month').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).subtract(1, 'month').endOf('month').format('YYYY-MM-DD HH:mm')]
    };
    this.maxDate = currentDateTime.format('YYYY-MM-DD HH:mm');
  }
  formatDates() {
    try{
    const formattedStartDate = this.selected.startDate.format('YYYY-MM-DD HH:mm');
    const formattedEndDate = this.selected.endDate.format('YYYY-MM-DD HH:mm');
    this.selected.startDate = formattedStartDate;
    this.selected.endDate = formattedEndDate;}
    catch(e){}
  }
  onDateRangeChanged() {
    const estOffset = moment().tz(this.systemTimezone).utcOffset();
 try{//check if today
    if(this.selected.endDate.format("YYYY-MM-DD")!=moment().utcOffset(estOffset).format("YYYY-MM-DD")){
      this.selected = {
        startDate:this.selected.startDate,
        endDate: this.selected.endDate.hour(23).minute(59)
      }
    }}
    catch(e){}
    this.formatDates();
    this.datestart = this.selected.startDate;
    this.dateend = this.selected.endDate;
  }

  ngOnInit(): void {
    this.getsites();
  }

  reportsForm = this.formBuilder.group({
    //siteName: ['', [Validators.required]],
    truck: ['']
  })

  async getsites() {
    await this.adminService.getfacilitymaster().pipe(takeUntil(this._destroying$)).subscribe({
       next: (res: any) => {
        this.sitedata = [];
        res.elements[0].map(res => {
           if(res.isActive == true){
            this.sitedata.push(res);
          }
         });
         this.filteredRegions.next(this.sitedata.slice());
         this.regionFilterCtrl.valueChanges
         .pipe(takeUntil(this._onDestroy))
         .subscribe(() => {
           this.filterRegions();
         });
       }, error: (error) => {
         this.toastr.error(error.error.message);
       }
     })
   }
   protected filterRegions() {
    console.log(this.sitedata);
    if (!this.sitedata) {
      return;
    }
    // get the search keyword
    let search = this.regionFilterCtrl.value;
    if (!search) {
      this.filteredRegions.next(this.sitedata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredRegions.next(
      this.sitedata.filter(
        (region) => region.facilityName.toLowerCase().indexOf(search) > -1
      )
    );
  }
   async getTruckNumber(data) {
    const dataid = {};
    dataid['facilityId'] = data,
    await this.vehicle.getVehicleforReport(dataid).pipe(takeUntil(this._destroying$)).subscribe({
       next: (res: any) => {
        if(res.elements.length !=0){
          this.vehicleData = res.elements;
        }
        else if(res.elements.length ==0){
          this.vehicleData = [];
        }
        this.filteredTrucks.next(this.vehicleData.slice());
        this.truckFilterCtrl.valueChanges
        .pipe(takeUntil(this._onDestroy1))
        .subscribe(() => {
          this.filterTrucks();
        });
       }, error: (error) => {
         this.toastr.error(error.error.message);
       }
     })
   }
   protected filterTrucks() {
    console.log(this.vehicleData);
    if (!this.vehicleData) {
      return;
    }
    // get the search keyword
    let search = this.truckFilterCtrl.value;
    if (!search) {
      this.filteredTrucks.next(this.vehicleData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredTrucks.next(
      this.vehicleData.filter(
        (truck) => truck.vehicleLicence.toLowerCase().indexOf(search) > -1
      )
    );
  }

  generatePDF() {
    let resultData = this.penaltytable?.data?this.penaltytable?.data:[];
    if (resultData.length==0) {
      this.toastr.warning('No data available for the selected criteria.');
      return;
    }
    let displayTable = document.getElementById('display-table');
    let pdfTable = document.getElementById('pdf-table');
    let displayTableGraph = document.getElementById('display-table-graph');
    let pdfTableGraph = document.getElementById('pdf-table-graph');

    pdfTable.style.display = 'block';
    displayTable.style.display = 'none';
    pdfTableGraph.style.display = 'block';
    displayTableGraph.style.display = 'none';

    var sGraph = document.getElementById('graph').innerHTML;
    var sGraphTable = document.getElementById('graphtable').innerHTML;
    var sTable = document.getElementById('table').innerHTML;

    pdfTable.style.display = 'none';
    displayTable.style.display = 'block';
    pdfTableGraph.style.display = 'none';
    displayTableGraph.style.display = 'block';
    let x = this.facilityID.facilityName;
    let y = (this.datepipe.transform(this.datestart, 'yyyy-MM-dd'));
    let z = (this.datepipe.transform(this.dateend, 'yyyy-MM-dd'));
    // if (this.bayID1 == "" || undefined || this.bayID1?.length==0) {
    //   var w = 'All Bays';
    // } else {
    //   w = this.bayID1;
    // }
    let w = this.reportsForm.value.truck?this.reportsForm.value.truck:'All Trucks';

    let u = y + " " + "to" + " " + z
    var Filename = "Site Selected : " + x + "," + " Truck Number : " + w + "," +" Date Selected : From " + u ;

    var style = "<style>";
    style = style + "table {width: 100%;font: 18px Calibri;}";
    style = style + "table, th, td{border: solid 1px #DDD; border-collapse: collapse; page-break: avoid !important;";
    style = style + "padding: 2px 3px; text-align: center;}";
    style = style + "mat-paginator div {display: none;}";
    style = style + "app-penaltygraph div {height: fit-content !important; width:100%; margin-bottom:1px; display: block; page-break: avoid !important;}";
    style = style + "app-penaltygraphtable div{margin-bottom:50px;}"
    style = style + "</style>";
    var title = "<title>" + name + "</title>";
    var printWindow = window.open('newWin.html', 'NewWindow', 'menubar=0,scrollbars=1,height=768,width=1366');
    printWindow.document.write('<html moznomarginboxes mozdisallowselectionprint><head>' + "<h4 style='color: black; text-align: center; font-size:18px;'>"+ Filename);
    printWindow.document.write(title);
    printWindow.document.write(style);
    printWindow.document.write('</h4>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(sGraph);
    // let tablename = "Total Penalty Charges"
    // printWindow.document.write("<h4 style='color: black; text-align: left; font-size:18px;'>" + tablename);
    // printWindow.document.write("</h4>");
    printWindow.document.write("<div><b>Total Count: "+this.penaltygraphtable.data.length+"</b></div>");
    printWindow.document.write(sGraphTable);
    printWindow.document.write("<div><b>Total Penalty Charges Count: "+ this.penaltytable_pdf.data.length+"</b></div>");
    printWindow.document.write(sTable);
    printWindow.document.write('</body></html>');
    setTimeout(function () {
      printWindow.print();
      printWindow.close();
    }, 100);
  }
  dateSelect($eve) {
    let startDate1 = $eve.dates[0].$d;
    let endDate1 = $eve.dates[1].$d;
    !startDate1 || !endDate1? this.dateSelectionFlag=true:this.dateSelectionFlag=false
  }
  penaltysubmit(){
    console.log(this.selected)
    if (!this.reportsForm.valid) {
      Object.keys(this.reportsForm.controls).forEach(field => {
        const control = this.reportsForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    }
    else if(this.selected.startDate == null){
      // this.toastr.error("Please Select Date Selection");
      this.dateSelectionFlag = true;
     }
    else if (this.reportsForm.valid && this.selected.startDate != null) {
      this.gettablegraph();
      this.hideicons = true;
     }
  }

 async gettablegraph(){
    let obj = {};
    obj['facilityId'] = this.facilityID.facilityId;
    obj['from_date'] = this.datestart,
    obj['to_date']= this.dateend,
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
    obj['vehicleLicence'] = this.reportsForm.value.truck;
      await this.penalty.getpenaltytable(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
        if(res.data.length !=0){
         this.penaltygraphtable = res
        }
        else if(res.data.length ==0){
          this.penaltygraphtable = [];
        }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });


      this.gettable();
  }
  async gettable(){
    this.show = false;
    let obj = {};
    obj['facilityId'] = this.facilityID.facilityId;
    obj['from_date'] = this.datestart,
    obj['to_date']= this.dateend,
    obj['vehicleLicence'] = this.reportsForm.value.truck;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
    obj['pageindex'] = 1;
    obj['pagesize'] = 20;
      await  this.penalty.getpenaltytablegrapgh(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
        if(res.data.length !=0){
         this.penaltytable = res
        }
        else if(res.data.length ==0){
          this.penaltytable = [];
        }
        //data for pdf
     if(res?.metadata?.total){
      let obj_pdf = {};
      obj_pdf['facilityId'] = this.facilityID.facilityId;
      obj_pdf['from_date'] = this.datestart,
      obj_pdf['to_date']= this.dateend,
      obj_pdf['vehicleLicence'] = this.reportsForm.value.truck;
      obj_pdf['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
      obj_pdf['pageindex'] = 1;
      obj_pdf['pagesize'] = res?.metadata?.total;
     this.penalty.getpenaltytablegrapgh(obj_pdf).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          this.penaltytable_pdf = {...res};
          this.show = true;
        }
        , error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
       });}
       else{
        this.show = true;
       }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async exportExcel() {
    if(this.hideicons){
    this.resultData1 = this.penaltytable?.data?this.penaltytable_pdf?.data:[];
    this.resultData2 = this.penaltygraphtable?.data?this.penaltygraphtable?.data:[];
    if(this.resultData1.length==0){
      this.toastr.warning("No data available for the selected criteria.");
      return;
    }

    //Create a workbook with a worksheet
    let workbook = new Workbook();
    let worksheet1 = workbook.addWorksheet('Penalty Table Data');
    let worksheet2 = workbook.addWorksheet('Penalty Graph Table Data');
    //add column name
    let header1 = [
      'Date',
      'Truck No.',
      'Delay',
      'Penalty',
      'Max Threshold',
      'Total Time',
    ];
    let siteRow1 = worksheet1.addRow(['Site Name',this.facilityID.facilityName]);
    let header2 = [
      'Date',
      'Total Penalty'
    ];
    let siteRow2 = worksheet2.addRow(['Site Name',this.facilityID.facilityName]);

    let headerRow1 = worksheet1.addRow(header1);


    headerRow1.eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
    });
    siteRow1.eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
    });
    siteRow2.eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
    });
    this.resultData1.forEach((row: any) => {
      let refactored = {...row};
      refactored.date = this.datepipe.transform(refactored.date,"MM-dd-yyyy HH:mm", "EDT");
      refactored.penalty = parseFloat(refactored.penalty).toFixed(2);
      worksheet1.addRow([refactored.date,refactored.vehicleLicence,refactored.delayTime,refactored.penalty,refactored.maxThreshold,refactored.totalTime]);
    });


    worksheet1.getColumn(1).width = 20;
    worksheet1.getColumn(2).width = 15;
    worksheet1.getColumn(5).width = 20;
    worksheet1.getColumn(6).width = 20;
    worksheet1.addRow([]);

    let headerRow2 = worksheet2.addRow(header2);
    headerRow2.eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
    });
    this.resultData2.forEach((row: any) => {
      let modifiedItem = {...row};
      modifiedItem.date = this.datepipe.transform(modifiedItem.date,"MM-dd-yyyy");
      modifiedItem.totalPenalty = parseFloat(modifiedItem.totalPenalty).toFixed(2);
      worksheet2.addRow([modifiedItem.date,modifiedItem.totalPenalty]);
    });
    worksheet2.getColumn(1).width = 20;
    worksheet2.getColumn(2).width = 15;
    worksheet2.addRow([]);

    let title = 'Penalty Charges Report';
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fs.saveAs(blob, title + '.xlsx');
    });}

  }
  async pageChange(eve){
    console.log("event emitted",eve);
    let pageIndex = eve.pageIndex;
    let pageSize = eve.pageSize;
    let obj = {};
    obj['facilityId'] = this.facilityID.facilityId;
    obj['from_date'] = this.datestart,
    obj['to_date']= this.dateend,
    obj['vehicleLicence'] = this.reportsForm.value.truck;
    obj['pageindex'] = pageIndex;
    obj['pagesize'] = pageSize;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
      await this.penalty.getpenaltytablegrapgh(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
        if(res.data.length !=0){
         this.penaltytable = {...res};
        }
        else if(res.data.length ==0){
          this.penaltytable = [];
        }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
}
