import { Component, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-penaltygraphtable',
  templateUrl: './penaltygraphtable.component.html',
  styleUrls: ['./penaltygraphtable.component.scss'],
  providers:[MatSort]
})
export class PenaltygraphtableComponent implements OnInit {

  @Input() penaltygraphtable:any;
  dataSource: MatTableDataSource<any>;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  pageIndex = 0;
  pageSize = 5;
  totalItems = 0;
  ELEMENT_DATA: any = []

  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  displayedColumns: string[] = [
    "Sr.No.",
    "date",
    "totalPenalty"
  ];
  dataSourcePDF:  MatTableDataSource<any>;

  constructor(private sort: MatSort) { }
  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    if(this.dataSource?.sort)
    this.dataSource.sort = this.sort;
  }
  ngOnInit(): void {
  }

  pageChanged(event) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.isLoading = true;
    console.log(changes.penaltygraphtable?.currentValue)
    if(changes.penaltygraphtable?.currentValue != undefined || null) {
          this.ELEMENT_DATA = changes.penaltygraphtable?.currentValue;
            this.displayNoRecords = false;
          this.dataSource = new MatTableDataSource(this.ELEMENT_DATA?.data?this.ELEMENT_DATA?.data:[]);
          this.dataSourcePDF = this.ELEMENT_DATA?.data?this.ELEMENT_DATA?.data:[];
          this.totalItems = this.ELEMENT_DATA?.data?this.ELEMENT_DATA.data.length:0;
          if(this.totalItems==0){
            this.displayNoRecords = true;
          }
          setTimeout(() => {
            this.dataSource.sort = this.sort;
            
            this.dataSource.paginator = this.paginator;
          });
          setTimeout(()=>{
            this.isLoading = false;  
          },1000);
    }
  }

}
