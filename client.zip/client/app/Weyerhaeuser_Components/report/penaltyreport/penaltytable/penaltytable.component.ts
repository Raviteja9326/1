import { AfterViewInit, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-penaltytable',
  templateUrl: './penaltytable.component.html',
  styleUrls: ['./penaltytable.component.scss'],
  providers:[MatSort]
})
export class PenaltytableComponent implements OnInit, OnChanges {

  @Input() penaltytable:any;
  @Input() penaltytable_pdf: any;
  dataSource: MatTableDataSource<any>;
  dataSourcePDF: MatTableDataSource<any>;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  pageIndex = 0;
  pageSize = 20;
  totalItems = 0;
  ELEMENT_DATA: any = []
  //@ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  displayedColumns: string[] = [
    "Sr.No.",
    "date",
    "vehicleLicence",
    "delayTime",
    "penalty",
    "maxThreshold",
    "totalTime"
  ];
@Output() pageChangeEvent = new EventEmitter<any>();
  constructor(private sort: MatSort) { 

  }
  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    if(this.dataSource?.sort)
    this.dataSource.sort = this.sort;
  }
  ngOnInit(): void {
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.pageChangeEvent.emit({"pageIndex":(this.pageIndex+1),"pageSize":this.pageSize});
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.isLoading = true;
    console.log("changes detected",changes.penaltytable?.currentValue)
    if(changes.penaltytable?.currentValue != undefined || null) {
          this.ELEMENT_DATA = changes.penaltytable?.currentValue;
          this.dataSourcePDF = this.penaltytable_pdf?.data?this.penaltytable_pdf?.data:[];
            this.displayNoRecords = false;
          this.dataSource = new MatTableDataSource(this.ELEMENT_DATA?.data?this.ELEMENT_DATA?.data:[]);
          this.totalItems = this.ELEMENT_DATA?.metadata?.total?this.ELEMENT_DATA?.metadata?.total:0;
          if(this.totalItems==0){
            this.displayNoRecords = true;
          }
          setTimeout(() => {
            this.dataSource.sort = this.sort;
            
          //  this.dataSource.paginator = this.paginator;
          });
          setTimeout(()=>{
            this.isLoading = false;
          },1000);
    }
  }

}
