import { DatePipe } from '@angular/common';
import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
  SimpleChanges,
  AfterViewInit,
} from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AllinoneService } from 'client/app/services/allinone.service';
import { ReportsService } from 'client/app/services/reports.service';
import { Totalexpand } from 'client/app/shared/search';
import { Subject, Subscription, takeUntil } from 'rxjs';
import dayjs from 'dayjs/esm';
import autoTable from 'jspdf-autotable';
import jsPDF from 'jspdf';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-alert-table',
  templateUrl: './alert-table.component.html',
  styleUrls: ['./alert-table.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class AlertTableComponent implements OnInit, OnDestroy,AfterViewInit {
  dataSource: MatTableDataSource<any>;
  dataSource1: MatTableDataSource<any>;
  dataSourceOriginal: any;
  displayNoRecords: boolean = false;
  _value: string = '';
  expanded: boolean = false;
  ELEMENT_DATA: any;
  isLoading: boolean = false;
  region: any;
  site: any;
  options: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild('capture') divRef1;
  pageIndex = 1;
  pageSize: number = 20;
  totalItems: number;
  PDF_Width: any = 0;
  pageHeight: any = 0;
  prevSize = 0;
  currSize = 0;
  displayedColumns: string[] = [
    // 'Sr',
    'vehicleLicence',
    'bayName',
    'entryTime',
    'exitTime',
    'waitingTime',
  ];
  alertData: any;
  dataForExcel = [];
  private readonly _destroying$ = new Subject<void>();
  element_string: string;
  element_split: string[];
  element_replace: void;
  @Input() id1: any = '';
  @Input() id2 = '';
  @Input() id3 = '';
  @Input() id4: any = '';
  @Input() id5 = '';
  @Input() id6 = '';
  @Input('clickSubjectpdf') clickSubjectpdf: Subject<any>;
  w = [];
  SR: any = 0;
  srNumber: number;
  bayId = [];
  serviceSubscription: Subscription;

  constructor(
    private allone: AllinoneService,
    private reports: ReportsService,
    private datepipe: DatePipe,
    private toastr: ToastrService,
    private route: Router
  ) {}
ngAfterViewInit(){
  if(this.dataSource1?.sort)
  this.dataSource1.sort = this.sort;
}
  ngOnInit(): void {
    this.pageIndex = 1;
    this.pageSize = 20;
    // this.getreports();
     this.serviceSubscription =  this.allone.clickSubject.subscribe((e) => {
      if(e){
      this.id1 = e.facilityID;
      this.id2 = e.startDate;
      this.id3 = e.endDate;
      this.id4 = e.bayID;
      this.id5 = e.min?e.min:0;
      this.id6 = e.max?e.max:0;
      this.pageSize = 20;
      this.pageIndex = 1;
      this.getholiday_master();
      }
     });
    // this.clickSubjectpdf.subscribe((e) => {
    //   if(this.ELEMENT_DATA.length > 0)
    //   {
    //   this.generatePDFtable();
    //   }
    // });
    // this.getholiday_master();
  }

  time = new Date();

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  pageChanged(event: PageEvent) {
    console.log(event);
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex + 1;
    this.getreports();
    this.getholiday_master();
  }

  ngOnChanges(changes: SimpleChanges) {
  //  console.log("changes", changes);
    // if (changes.id2 || changes.id3 || changes.id5 || changes.id6) {
    //   this.getholiday_master();
    // }
    // this.getholiday_master();
 
  }

  getreports() {}

  @Input('clickSubject') clickSubject: Subject<any>;

  getholiday_master() {
    sessionStorage.clear;
    const obj = {};
    let data = {};
    this.dataSourceOriginal = [];
    this.ELEMENT_DATA = [];
    this.isLoading = true;
    // debugger;
    if (this.id4=="") {
      this.bayId = [];
    } else {
      this.bayId = [];
      for(let i = 0; i<this.id4.length; i++){
        if(this.id4[i].bayId == undefined)
        {
          // this.bayId.push([]);
          break;
        }
        else{
      this.bayId.push(this.id4[i].bayId);
        }
      }
      console.log(this.id4.length)
    }
    console.log(this.bayId, '+', this.id5, '+', this.id6);
  
    let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    data['pageIndex'] = this.pageIndex;
    data['pageSize'] = this.pageSize;
    obj['bayId'] = this.bayId;
    obj['facilityId'] = this.id1.facilityId;
    obj['from_date'] = this.datepipe.transform(this.id2, 'yyyy-MM-dd',"UTC");
    obj['to_date'] = this.datepipe.transform(this.id3, 'yyyy-MM-dd',"UTC");
    obj['timezone'] = timezone;
    obj['time'] = this.datepipe.transform(this.time, 'HH:mm:ss');
    obj['min'] = this.id5;
    obj['max'] = this.id6;
    // debugger;
    this.reports
      .reportsalerts(data, obj)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          if (res != null) {
            this.totalItems = res.metadata.total;
            // this.pageSize = this.totalItems;
            // data['pageIndex'] = this.pageIndex;
            // data['pageSize'] = this.pageSize;
            // this.reports
            // .reportsalerts(data, obj)
            // .pipe(takeUntil(this._destroying$))
            // .subscribe({
            //   next: (res) => {
            //     if (res != null) {
            // this.totalItems = res.metadata.total;
            this.ELEMENT_DATA = res.elements;
            this.spans = [];
            // this.ELEMENT_DATA = res.elements;
            sessionStorage.setItem('waitingpdf', JSON.stringify(this.ELEMENT_DATA));
            this.cacheSpan('vehicleLicence', (d) => d.vehicleLicence);
            if (res.elements.length !== 0) {
              this.ELEMENT_DATA = res.elements;
              // this.isLoading = false;
              this.displayNoRecords = false;
              this.dataSource1 = new MatTableDataSource<any>(this.ELEMENT_DATA);

              //Make blank export table
              this.dataSource = new MatTableDataSource<any>([]);
              this.dataSourceOriginal = [];

              setTimeout(() => {
                this.pageIndex = res.metadata.current_page;
                this.dataSource1.sort = this.sort;
                this.totalItems = res.metadata.total;
              });
              // debugger;
              if (this.currSize != this.totalItems) {
                this.prevSize = 11;
              }
              // if (this.prevSize == 11) 
              {
                this.currSize = this.totalItems;
                this.prevSize = 11;

                data['pageIndex'] = 1;
                data['pageSize'] = this.totalItems;

                this.reports
                .reportsalerts(data, obj)
                .pipe(takeUntil(this._destroying$))
                .subscribe({
                  next: (res) => {
                      if (res != null) {
                        // debugger;
                        this.ELEMENT_DATA = res.elements;
                        // this.allone.setSubsSource(res);
                        if (res.elements.length !== 0) {
                          if (this.prevSize == 11) {
                            this.prevSize = this.totalItems;
                            this.dataSource = new MatTableDataSource<any>(
                              this.ELEMENT_DATA
                            );
                            this.isLoading = false;
                            this.dataSourceOriginal = this.ELEMENT_DATA;
                            sessionStorage.setItem('data', JSON.stringify(this.ELEMENT_DATA));
                            this.spans = [];
                            this.cacheSpan('vehicleLicence', (d) => d.vehicleLicence);
                          }
                        }
                      }
                    },
                  });
              }
            }
            else{
            sessionStorage.setItem('data', '');
            this.isLoading = false;
            this.displayNoRecords = true;
            this.ELEMENT_DATA = [];
            this.dataSource = new MatTableDataSource<any>([]);
            this.totalItems = 0;
            this.pageSize = 20;
            this.pageIndex = 1;
            this.dataSource1 = new MatTableDataSource<any>([]);
            this.currSize = 0;
            }
            // this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
            

            // }
            // }
            // }
            // );
          } else if (res == null) {
            // debugger;
            sessionStorage.setItem('data', '');
            this.isLoading = false;
            this.displayNoRecords = true;
            this.ELEMENT_DATA = [];
            this.dataSource = new MatTableDataSource<any>([]);
            this.totalItems = 0;
            this.pageSize = 20;
            this.pageIndex = 1;
            this.dataSource1 = new MatTableDataSource<any>([]);
            this.currSize = 0;
          }
        },
        error: (error) => {
          this.toastr.error(error.error.message);
        },
      });
  }
  close() {
    this._value = '';
    this.getreports();
  }

  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search');
    }
  }

  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    if (this.serviceSubscription) {
      this.serviceSubscription.unsubscribe();
    }
  }

  spanningColumns = ['vehicleLicence'];

  spans = [];
  sr = [];
  indx = 0;
  x = [];
  cacheSpan(key, accessor) {
    for (let i = 0; i < this.ELEMENT_DATA.length; ) {
      let currentValue = accessor(this.ELEMENT_DATA[i]);
      let count = 1;
      for (let j = i + 1; j < this.ELEMENT_DATA.length; j++) {
        if (currentValue != accessor(this.ELEMENT_DATA[j])) {
          break;
        }

        count++;
      }

      if (!this.spans[i]) {
        this.spans[i] = {};
      }
      this.spans[i][key] = count;
      i += count;
    }
  }

  number(i, v1, v2) {
    alert(i + '-' + v1 + '-' + v2);
  }

  getRowSpan(col: string | number, index: string | number) {
    return this.spans[index] && this.spans[index][col];
  }

  generatePDFtable() {
    var sTable = document.getElementById('table').innerHTML;
    let x = this.id1.facilityName;
    let y = this.datepipe.transform(this.id2, 'yyyy-MM-dd', 'UTC');
    let z = this.datepipe.transform(this.id3, 'yyyy-MM-dd', 'UTC');
    if (this.id4 == '') {
      this.w = ['All Bays'];
    } else {
      for (let i = 0; i < this.id4.length; i++) {
        this.w.push(this.id4[i].bayName);
      }
      console.log(this.w);
    }
    let u = y + ' ' + 'to' + ' ' + z;
    var Filename =
      'Site Selected : ' +
      x +
      ',' +
      ' Bay ID : ' +
      this.w +
      ',' +
      ' Date Selected : From ' +
      u;
    var style = '<style>';
    style = style + 'table {width: 100%;font: 18px Calibri;}';
    style =
      style +
      'table, th, td{border: solid 1px #DDD; border-collapse: collapse; page-break: avoid !important;';
    style = style + 'padding: 2px 3px; text-align: center;}';
    style = style + 'mat-paginator {display: none;}';
    style =
      style +
      'average-waitingtime-table div {height: fit-content !important; margin-bottom:1px; display: flex; page-break: avoid !important;}';
    style = style + '</style>';
    var title = '<title>' + name + '</title>';
    var printWindow = window.open(
      'newWin.html',
      'NewWindow',
      'menubar=0,scrollbars=1,height=768,width=1366, top=10'
    );
    printWindow.document.write(
      '<html moznomarginboxes mozdisallowselectionprint><head>' +
        "<h4 style='color: black; text-align: center; font-size:18px;'>" +
        Filename
    );
    printWindow.document.write(title);
    printWindow.document.write(style);
    printWindow.document.write('</h4>');
    printWindow.document.write('</head><body>');

    printWindow.document.write(sTable);

    printWindow.document.write('</body></html>');
    setTimeout(function () {
      printWindow.print();
      printWindow.close();
    }, 100);
  }
}
