import { AlertmasterService } from 'client/app/services/alertmaster.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { Subject, Subscription, takeUntil } from 'rxjs';
import * as Highcharts from 'highcharts';
import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ChartComponent,
  ApexLegend
} from "ng-apexcharts";
import { AllinoneService } from 'client/app/services/allinone.service';
import { ReportsService } from 'client/app/services/reports.service';
export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  labels: string[];
  plotOptions: ApexPlotOptions;
  legend: ApexLegend;
};
@Component({
  selector: 'average-waitingtime-weekwise',
  templateUrl: './average-waitingtime-weekwise.component.html',
  styleUrls: ['./average-waitingtime-weekwise.component.scss']
})
export class AverageWaitingtimeWeekwiseComponent implements OnInit {
  @Input('clickSubject') clickSubject: Subject<any>;
  @Input('clickSubjectpdf') clickSubjectpdf: Subject<any>;
  @Input() facilityId: any;
  @Input() date1: any;
  @Input() date2: any;
  @Input() bayId: any;
  @Input() month:any;
  @Input() year:any="";
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  @Output() viewReport_bolEmit = new EventEmitter<any>();
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  heights: string = '100%';
  heights2: string = '100%';
  private readonly _destroying$ = new Subject<void>();
  @Input() occupancyupdate = '';
  highcharts = Highcharts;
  loading: boolean = true;
  viewReport_bol = false;
  dateocupancy2: any = [];
  dateLables: boolean = false;
  names: any;
  occupied: any;
  unoccupied: any;
  x: any;
  y: any;
  z: any;
  w: any;
  ELEMENT_DATA: any[];
  monthList: any;
  monthsMap:any =  {"January":1, "February":2, "March":3, "April":4, "May":5, "June":6,
    "July":7, "August":8, "September":9, "October":10, "November":11, "December":12}
  constructor(private allone: AllinoneService, private userser: StorageService, private Bay_cust: BayMasterService,
    private toastr: ToastrService, private route: Router, private datepipe: DatePipe, private reports: ReportsService,) { }
  private subscriptions = new Subscription();

  ngOnInit(): void {
    // this.clickSubject.subscribe(e => {
    //   console.log(e, 'event fired')
    //   if (e) {
    //   this.getweekwisedata();
    //   } else {
    //     this.toastr.warning('Fields are mandatory')
    //   }
    // })
    //this.getalerttypes();
    
    this.loading = false
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log('changes', changes);
    
      this.getweekwisedata();
    
    // this.getholiday_master();
    // this.getRowSpan;
  }
  ngAfterViewInit(): void {
    //  this.intervalId = setInterval(()=>{
    //     this.localDate = this.datepipe.transform(sessionStorage.getItem('parkingcount'), 'yyyy-MM-dd HH:mm');
    //     this.latestDate = this.datepipe.transform(this.occupancyupdate, 'yyyy-MM-dd HH:mm');
    //     this.calldataback(this.latestDate, this.localDate);
    //   },25000)
  }
  // calldataback(arg1,arg2){
  //   if(arg1 > arg2){
  //     this.getslots();
  //   }
  // }

 

  getUsername() {
    this.names = this.userser.getuser();
  }
  getweekwisedata() {

    sessionStorage.clear;
    let modifiedBayId = [];
    if (this.bayId=="") {
     modifiedBayId = [];
   } else {
     modifiedBayId = [];
     for(let i = 0; i<this.bayId.length; i++){
       if(this.bayId[i].bayId == undefined)
       {
         // this.bayId.push([]);
         break;
       }
       else{
     modifiedBayId.push(this.bayId[i].bayId);
       }
     }
   }
    this.ELEMENT_DATA = [];
    this.loading = true;
    let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const obj = {};
    let data = {};
    obj['bayId'] = modifiedBayId;
    obj['facilityId'] = this.facilityId.facilityId;
    obj['month'] = this.monthsMap[this.month];
    obj['year'] = this.year;
    obj['timezone'] = timezone;

    this.reports
      .weekwiseAlerts(data, obj)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          // this.ELEMENT_DATA = res.elements;
          // console.log(333, res['elements'].length);
          if (res != null) {
            this.ELEMENT_DATA = Object.values(res.data);
            if (res.length !== 0) {
              this.monthList = this.ELEMENT_DATA.map((item)=>{
                return "W"+item.week;
              });
              this.x =  this.ELEMENT_DATA.map((item)=>{
                return {name:item?.PARKINGCOUNT?item?.PARKINGCOUNT:0,y:item.PARKING?item.PARKING:0};
              });
              this.y = this.ELEMENT_DATA.map((item)=>{
                return {name:item?.LOADINGCOUNT?item?.LOADINGCOUNT:0,y:item.LOADING?item.LOADING:0};
              });
              this.z = this.ELEMENT_DATA.map((item)=>{
                return {name:item?.TARPINGCOUNT?item?.TARPINGCOUNT:0,y:item.TARPING?item.TARPING:0};
              });
              this.w = this.ELEMENT_DATA.map((item)=>{
                return {name:item?.TotalCOUNT?item?.TotalCOUNT:0,y:item.Total?item.Total:0};
              });
              this.dateLables = true;

              this.chartInit();
             
              this.loading = false
            }
          } 
          else if (
            res == null
          ) {
            this.loading = false;
            this.dateLables = false;
            this.ELEMENT_DATA = [];
           
          }
        },
        error: (error) => {
          this.toastr.error(error.error.message);
        },
      });
  }

  chartInit() {
    var that = this;
    this.linechartOptions = {
      chart: {
        type: 'column',
        backgroundColor: '#fff',
        zooming: { type: 'x' },
        marginTop: 30,
        height: (8.2 / 23.2 * 100) + '%'
      },
      
      accessibility: {
        enabled: false,
      },
      credits: {
        text: '',
        href: '',
      },
      title: {
        text: 'Waiting Time Evaluation of '+that.month+" "+that.year
      },
      subtitle: {
        text: ''
      },
      xAxis: {
        categories: this.monthList,
      title: {
        text: 'Week',
        style: {
          color: '#000',
          fontWeight: '600',
          fontFamily: "'Open Sans', sans-serif",
        },
      },
      crosshair: true,
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
      },
      yAxis: {
        min: 0,
        tickInterval: 10,
        title: {
          text: 'Waiting Time(HH:MM)',
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          },
        },
        labels: {
          formatter: function () {
            var time:any = this.value;
            var hours1 = parseInt((parseInt(time)/60).toString());
            var mins1=parseInt(((parseInt(time)%60)).toString());
            return hours1 + ':' + mins1;
        },
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          }
        }
      },
      tooltip: {
        formatter:function(){
          let tooltipLabel=""
          tooltipLabel = '<span style="font-size:10px; font-weight:600">'+this.x+'</span><table>'
                      // this.points.forEach((point,i)=>{
                        var time:any = this.point.y;
                        var hours1 = parseInt((parseInt(time)/60).toString());
                        var mins1=parseInt(((parseInt(time)%60)).toString());
                        tooltipLabel+='<tr><td style="color:'+this.point.color+';padding:0;font-weight:600">'+this.point.series.name+' Time:</td>' +
                        '<td style="padding:0; font-weight:600"><b>'+hours1+":"+mins1+'</b></td></tr><tr><td style="color:'+this.point.color+';"><b>Count of Trucks:</b></td><td><b> '+this.point.name+'</b></td></tr>';
                        
                      // });
               tooltipLabel +='</table>'      
                       return tooltipLabel;
        },
      
       /*  pointFormat: '<tr><td style="color:{series.color};padding:0;font-weight:600">{series.name}: </td>' +
          '<td style="padding:0; font-weight:600"><b>{point.y}</b></td></tr>', */
        
        shared: false,
        useHTML: true,
        valueDecimals: 0,
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        x: 0,
        y: 25,
        floating: false,
        itemMarginTop: 5,
        itemMarginBottom: 5,
        itemStyle: {
          lineHeight: '10px',
        }
      },
      plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
      series: [{
        type: 'column',
        name: 'Parking',
        color: '#008357',
        data:  this.x
      }, {
        type: 'column',
        name: 'Loading',
        color: '#0da4eb',
        data: this.y
      }, {
        type: 'column',
        name: 'Tarping',
        color: '#ffa042',
        data:  this.z
      },
      {
        type: 'column',
        name: 'Tarping',
        color: '#ff0000',
        data:  this.w
      }]
    }
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    // this.clickSubject.unsubscribe();
    this.subscriptions.unsubscribe();
  }


}
