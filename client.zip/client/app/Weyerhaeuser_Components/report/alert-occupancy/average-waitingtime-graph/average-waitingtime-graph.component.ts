import { AlertmasterService } from 'client/app/services/alertmaster.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import * as Highcharts from 'highcharts';
import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ChartComponent,
  ApexLegend
} from "ng-apexcharts";
import { AllinoneService } from 'client/app/services/allinone.service';
export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  labels: string[];
  plotOptions: ApexPlotOptions;
  legend: ApexLegend;
};
@Component({
  selector: 'average-waitingtime-graph',
  templateUrl: './average-waitingtime-graph.component.html',
  styleUrls: ['./average-waitingtime-graph.component.scss']
})
export class AverageWaitingtimeGraphComponent implements OnInit {
  @Input('clickSubject') clickSubject: Subject<any>;
  @Input('clickSubjectpdf') clickSubjectpdf: Subject<any>;
  @Input() facilityId: any;
  @Input() date1: any;
  @Input() date2: any;
  @Input() bayId: any;
  @Input() year:any="";
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  @Output() viewReport_bolEmit = new EventEmitter<any>();
  @Output() callWeekwise = new EventEmitter<any>();
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  heights: string = '100%';
  heights2: string = '100%';
  private readonly _destroying$ = new Subject<void>();
  @Input() occupancyupdate = '';
  highcharts = Highcharts;
  loading: boolean = true;
  viewReport_bol = false;
  dateocupancy2: any = [];
  dateLables: boolean = true;
  names: any;
  occupied: any;
  unoccupied: any;
  x: any;
  y: any;
  z: any;
  w: any;
  monthList: string[];
  constructor(private allone: AllinoneService, private userser: StorageService, private Bay_cust: BayMasterService,
    private toastr: ToastrService, private route: Router, private datepipe: DatePipe) { }
  private subscriptions = new Subscription();

  ngOnInit(): void {
    this.allone.clickSubjectMonth.subscribe(e => {
      console.log(e, 'event fired')
      if (e) {
        this.facilityId = e.facilityID;
        this.bayId = e.bayID;
        this.date1 = e.startMonth;
        this.date2 = e.endMonth;
        this.year = e.year;
        this.getalerttypes();
      } 
    })
    //this.getalerttypes();

  }
  ngOnChanges(changes: SimpleChanges) {
    // console.log('changes', changes);
    // if(changes.date1 || changes.date2)
    //this.getalerttypes();
    
    // this.getholiday_master();
    // this.getRowSpan;
  }
  ngAfterViewInit(): void {
    //  this.intervalId = setInterval(()=>{
    //     this.localDate = this.datepipe.transform(sessionStorage.getItem('parkingcount'), 'yyyy-MM-dd HH:mm');
    //     this.latestDate = this.datepipe.transform(this.occupancyupdate, 'yyyy-MM-dd HH:mm');
    //     this.calldataback(this.latestDate, this.localDate);
    //   },25000)
  }
  // calldataback(arg1,arg2){
  //   if(arg1 > arg2){
  //     this.getslots();
  //   }
  // }

 

  getUsername() {
    this.names = this.userser.getuser();
  }
  getalerttypes() {
    this.viewReport_bol = true;
    this.subscriptions.add(this.allone.subs$.subscribe({
      next: (res) => {
        if (res !== undefined && !res.totalAlert) {
          if (res.length !== 0) {
            this.monthList = res.map((item)=>{
              return item.month;
            });
            this.x = res.map((item)=>{
              return {name:item?.PARKINGCOUNT?item?.PARKINGCOUNT:0,y:item.PARKING?item.PARKING:0};
            });
            this.y = res.map((item)=>{
              return {name:item?.LOADINGCOUNT?item?.LOADINGCOUNT:0,y:item.LOADING?item.LOADING:0};
            });
            this.z = res.map((item)=>{
              return {name:item?.TARPINGCOUNT?item?.TARPINGCOUNT:0,y:item.TARPING?item.TARPING:0};
            });
            this.w = res.map((item)=>{
              return {name:item?.TotalCOUNT?item?.TotalCOUNT:0,y:item.Total?item.Total:0};
            });;
          
            this.chartInit();
            this.dateLables = true;
            this.loading = false
          } else if (res.length == 0) {
            this.loading = false
            this.dateLables = false
          }
        }
      }, error: (error) => {
        this.loading = false;
        this.toastr.error(error.error.message)
      }
    })), (error) => {
      this.toastr.error(error.error.message);
      this.route.navigate(['/dashboard/errors']);
    }
  }


  public openPDF(): void {
    let DATA: any = document.getElementById('capture');
    // document.getElementById("capture").style.overflow = "visible";
    // document.getElementById("capture").style.width = "100%";
    // document.getElementById("capture").style.height = "100%";
    // document.getElementById("capture").style.maxHeight = "100%";
    // setTimeout(() => {
    //   html2canvas(DATA).then((canvas) => {
    //     let fileWidth = 210;
    // let fileHeight = (canvas.height * fileWidth) / canvas.width;
    // let fileHeight = (canvas.height * fileWidth) / canvas.width;;
    // let pagesplit = true
    // const FILEURI = canvas.toDataURL('image/png');
    // let PDF = new jsPDF('p', 'mm', 'a4');
    // var width = PDF.internal.pageSize.getWidth();
    // var height = canvas.height * width / canvas.width
    // let position = 3;
    // PDF.addImage(FILEURI, 'PNG', 0, position, width, height);
    // PDF.addPage();
    //     PDF.save('angular-demo.pdf');
    //   });
    // }, 1000);
    // window.location.reload();
    // document.getElementById("capture").style.display = "none";
  }

  





  chartInit() {
    var that = this;
    this.linechartOptions = {
      chart: {
        type: 'column',
        backgroundColor: '#fff',
        zooming: { type: 'x' },
        marginTop: 30,
        height: (8.2 / 23.2 * 100) + '%'
      },
      
      accessibility: {
        enabled: false,
      },
      credits: {
        text: '',
        href: '',
      },
      title: {
        text: 'Monthly Avg Waiting Time'
      },
      subtitle: {
        text: ''
      },
      xAxis: {
        categories: this.monthList,
      title: {
        text: 'Month',
        style: {
          color: '#000',
          fontWeight: '600',
          fontFamily: "'Open Sans', sans-serif",
        },
      },
      crosshair: true,
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
      },
      yAxis: {
        min: 0,
        tickInterval: 10,
        title: {
          text: 'Waiting Time(HH:MM)',
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          },
        },
        labels: {
          formatter: function () {
            var time:any = this.value;
            var hours1 = parseInt((parseInt(time)/60).toString());
            var mins1=parseInt(((parseInt(time)%60)).toString());
            return hours1 + ':' + mins1;
        },
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          }
        }
      },
      tooltip: {
        formatter:function(){
          let tooltipLabel=""
          tooltipLabel = '<span style="font-size:10px; font-weight:600">'+this.x+'</span><table>'
                      // this.points.forEach((point,i)=>{
                        var time:any = this.point.y;
                        var hours1 = parseInt((parseInt(time)/60).toString());
                        var mins1=parseInt(((parseInt(time)%60)).toString());
                        tooltipLabel+='<tr><td style="color:'+this.point.color+';padding:0;font-weight:600">'+this.point.series.name+' Time:</td>' +
                        '<td style="padding:0; font-weight:600"><b>'+hours1+":"+mins1+'</b></td></tr><tr><td style="color:'+this.point.color+';"><b>Count of Trucks:</b></td><td><b> '+this.point.name+'</b></td></tr>';
                        
                      //});
               tooltipLabel +='</table>'      
                       return tooltipLabel;
        },
      
       /*  pointFormat: '<tr><td style="color:{series.color};padding:0;font-weight:600">{series.name}: </td>' +
          '<td style="padding:0; font-weight:600"><b>{point.y}</b></td></tr>', */
        
        shared: false,
        useHTML: true,
        valueDecimals: 0,
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        x: 0,
        y: 25,
        floating: false,
        itemMarginTop: 5,
        itemMarginBottom: 5,
        itemStyle: {
          lineHeight: '10px',
        }
      },
      plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        },
        series:{
          events: {
            click: function (event) {
            console.log(event.point.category);
            that.callWeekwise.emit(event.point.category);
            }
        }
        }
    },
      series: [{
        type: 'column',
        name: 'Parking',
        color: '#008357',
        data:  this.x
      }, {
        type: 'column',
        name: 'Loading',
        color: '#0da4eb',
        data: this.y
      }, {
        type: 'column',
        name: 'Tarping',
        color: '#ffa042',
        data:  this.z
      },
      {
        type: 'column',
        name: 'Total Turn Around',
        color: '#ff0000',
        data:  this.w
      }]
    }
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    // this.clickSubject.unsubscribe();
    this.subscriptions.unsubscribe();
  }


}
