import { DatePipe } from '@angular/common';
import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
  SimpleChanges,
} from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AllinoneService } from 'client/app/services/allinone.service';
import { ReportsService } from 'client/app/services/reports.service';
import { Totalexpand } from 'client/app/shared/search';
import { Subject, Subscription, takeUntil } from 'rxjs';
import dayjs from 'dayjs/esm';
import autoTable from 'jspdf-autotable'
import jsPDF from 'jspdf';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'average-waitingtime-table',
  templateUrl: './average-waitingtime-table.component.html',
  styleUrls: ['./average-waitingtime-table.component.scss'],
  animations: [Totalexpand.search_animations],
})
export class AverageWaitingtimeTableComponent implements OnInit, OnDestroy {
  dataSource: MatTableDataSource<any>;
  displayNoRecords: boolean = false;
  _value: string = '';
  expanded: boolean = false;
  ELEMENT_DATA: any;
  isLoading: boolean = false;
  region: any;
  site: any;
  options: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild('capture') divRef1;
  pageIndex = 1;
  pageSize = 20;
  totalItems = 0;
  PDF_Width: any = 0;
  pageHeight: any = 0;
  displayedColumns: string[] = [
    // 'Sr',
    'month',
    'PARKING',
    'LOADING',
    'TARPING',
    'Total',
  ];
  alertData: any;
  dataForExcel = [];
  private readonly _destroying$ = new Subject<void>();
  element_string: string;
  element_split: string[];
  element_replace: void;
  @Input() facilityId:any = '';
  @Input() date1;
  @Input() date2;
  @Input() bayId:any = '';
  @Input() year:any="";
  @Input('clickSubjectpdf') clickSubjectpdf: Subject<any>;
  w =[];
  SR: any = 0;
  srNumber: number;
    serviceSubscription: Subscription;

  constructor(
    private allone: AllinoneService,
    private reports: ReportsService,
    private datepipe: DatePipe,
    private toastr: ToastrService,
    private route: Router
  ) {}

  ngOnInit(): void {
   
    this.allone.clickSubjectMonth.subscribe(e => {
      if (e) {
        this.facilityId = e.facilityID;
        this.bayId = e.bayID;
        this.date1 = e.startMonth;
        this.date2 = e.endMonth;
        this.year = e.year;
        this.pageSize = 20;
        this.pageIndex = 1;
        this.getholiday_master();
      } 
    })
    //this.getholiday_master();
  }

  ngOnChanges(changes: SimpleChanges) {
    // console.log('changes', changes);
    // if(changes.date1 || changes.date2)
    // this.getholiday_master();
    
    // this.getholiday_master();
    // this.getRowSpan;
  }
  time = new Date();

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  pageChanged(event: PageEvent) {
    console.log(event);
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex + 1;
    this.getreports();
    this.getholiday_master();
  }

  getreports() {}

  @Input('clickSubject') clickSubject: Subject<any>;

  getholiday_master() {

    sessionStorage.clear;
    let modifiedBayId = [];
     if (this.bayId=="") {
      modifiedBayId = [];
    } else {
      modifiedBayId = [];
      for(let i = 0; i<this.bayId.length; i++){
        if(this.bayId[i].bayId == undefined)
        {
          // this.bayId.push([]);
          break;
        }
        else{
      modifiedBayId.push(this.bayId[i].bayId);
        }
      }
    }
    this.ELEMENT_DATA = [];
    this.isLoading = true;
    let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const obj = {};
    let data = {};

    data['pageIndex'] = this.pageIndex;
    data['pageSize'] = this.pageSize;
    obj['bayId'] = modifiedBayId;
    obj['facilityId'] = this.facilityId.facilityId;
    obj['from_month'] = (this.date1.getMonth()+1);
    obj['to_month'] = (this.date2.getMonth()+1);
    obj['year'] = this.year;
    obj['timezone'] = timezone;
    obj['time'] = this.datepipe.transform(this.time, 'HH:mm:ss');
    // obj['min'] = this.id5;
    // obj['max'] = this.id6;
    this.reports
      .reportsalerts(data, obj)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          // this.ELEMENT_DATA = res.elements;
          // console.log(333, res['elements'].length);
          if (res != null || res.data) {
            this.ELEMENT_DATA = Object.values(res.data);
            if(this.ELEMENT_DATA.length>0){
            this.allone.setSubsSource(this.ELEMENT_DATA);
            this.isLoading = false;
            this.displayNoRecords = false;
          
            this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
            setTimeout(() => {
              this.dataSource.sort = this.sort;
              this.totalItems = this.dataSource.data.length;
              this.dataSource.paginator = this.paginator;
            });
            sessionStorage.setItem('data', JSON.stringify(this.ELEMENT_DATA));}
            else{
              this.isLoading = false;
            this.displayNoRecords = true;
            this.ELEMENT_DATA = [];
            sessionStorage.setItem('data', JSON.stringify(this.ELEMENT_DATA));
            this.allone.setSubsSource(this.ELEMENT_DATA);
            this.dataSource = new MatTableDataSource<any>([]);
            this.totalItems = 0;
          this.pageIndex = 0;
            }
          } 
          else if (
            res == null 
          ) {
            this.isLoading = false;
            this.displayNoRecords = true;
            this.ELEMENT_DATA = [];
            this.allone.setSubsSource(this.ELEMENT_DATA);
            this.dataSource = new MatTableDataSource<any>([]);
            this.totalItems = 0;
          this.pageIndex = 0;
          }
        },
        error: (error) => {
          this.toastr.error(error.error.message);
        },
      });
  }
  close() {
    this._value = '';
    this.getreports();
  }

  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search');
    }
  }

  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    if(this.serviceSubscription){
        this.serviceSubscription.unsubscribe();
      }
  }

  spanningColumns = ['vehicleLicence'];

  
  // cacheSpan1(key, accessor) {
  //   let ii = 1;
  //   for (let i = 0; i < this.ELEMENT_DATA.length; ) {
  //     let currentValue = accessor(this.ELEMENT_DATA[i]);
  //     let count = 1;
  //     for (let j = i + 1; j < this.ELEMENT_DATA.length; j++) {
  //       if (currentValue != accessor(this.ELEMENT_DATA[j])) {
  //         break;
  //       }

  //       count++;
  //     }

  //     if (!this.spans[i]) {
  //       this.spans[i] = {};
  //     }
  //     this.spans[i][key] = count;
  //     i += count;
  //     this.sr[this.indx++] = this.indx;
  //     console.log('indx:', this.indx, 'sr:', this.sr);
  //   }
  // }

  number(i, v1, v2) {
    alert(i + '-' + v1 + '-' + v2);
  }

  


  getHourMinute(minutes){
    var time =  minutes?minutes:0;
    var hours1 = parseInt((parseInt(time)/60).toString());
    var mins1 = parseInt(((parseInt(time)%60)).toString());
    return hours1 + ':' + mins1;
  }
}
