import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatSelect } from '@angular/material/select';
import { Region } from 'client/app/entity/regional_site';
import { AllinoneService } from 'client/app/services/allinone.service';
import { ReportsService } from 'client/app/services/reports.service';
import dayjs from 'dayjs/esm';
import { LocaleConfig } from 'ngx-daterangepicker-material';
import { ToastrService } from 'ngx-toastr';
import { ReplaySubject, Subject, takeUntil } from 'rxjs';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import { StorageService } from 'client/app/core/interceptor/storage.service';
pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-alert-occupancy',
  templateUrl: './alert-occupancy.component.html',
  styleUrls: ['./alert-occupancy.component.scss'],
})
export class AlertOccupancyComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  clickSubject: Subject<any> = new Subject();
  clickSubjectpdf: Subject<any> = new Subject();
  dateSelectionFlag:boolean = false;
  BayData: any[];
  min1: any = 0;
  max1: any = 0;
  monthRange:any;
  maxMonth: Date = new Date();
  minMonth: Date ;
  showAvgTable: boolean = false;
  showWeekWiseGraph: boolean = false;
  selectedMonth: any;
  startMonth: string;
  endMonth: string;
  selectedYear: any;
  startDatereport: any;
  endDatereport: any;
  bayID2: any;
  facilityID2: any;
  datalabels: any;
  notifyClick() {
    // this.hideicons = true;
    this.clickSubject.next(1);
    this.startDate1 = this.selected.startDate;
    this.endDate1 = this.selected.endDate;
  }
  time = new Date();
  id1: any;
  id2: any;
  id3: any;
  id4: any;
  id5: any;
  id6: any;
  startDate1: any = '';
  endDate1: any = '';
  facilityID1: any;
  bayID1: any = [];
  visible: Boolean = false;
  hideFlagTable: boolean = true;
  hideicons: boolean = false;
  progressCard: any = '';
  RegionData: Region[] = [];
  SitesData: [] = [];
  facilityName: [] = [];
  locale: LocaleConfig = {
    format: 'YYYY-MM-DDTHH:mm:ss.SSSZ',
    displayFormat: 'MM/DD/YYYY',
    separator: ' To ',
    cancelLabel: 'Cancel',
    applyLabel: 'Okay',
    clearLabel:'Clear'
  };
  ranges: any = {
    'Today': [dayjs(), dayjs()],
    'Yesterday': [dayjs().subtract(1, 'days'), dayjs().subtract(1, 'days')],
    'Last 7 Days': [dayjs().subtract(6, 'days'), dayjs()],
    'Last 30 Days': [dayjs().subtract(29, 'days'), dayjs()],
    'This Month': [dayjs().startOf('month'), dayjs().endOf('month')],
    'Last Month': [
      dayjs().subtract(1, 'month').startOf('month'),
      dayjs().subtract(1, 'month').endOf('month'),
    ],
  };
  invalidDates: dayjs.Dayjs[] = [
    dayjs(),
    dayjs().add(2, 'days'),
    dayjs().add(3, 'days'),
    dayjs().add(5, 'days'),
  ];
  selected: any;
  maxDate: dayjs.Dayjs = dayjs().add(0, 'days');
  minDate: dayjs.Dayjs;
  private readonly _destroying$ = new Subject<void>();
  resultData: any[] = [];
  dataForExcel = [];
  regionFilterCtrl: FormControl = new FormControl();
  public filteredRegions: ReplaySubject<Region[]> = new ReplaySubject<Region[]>(
    1
  );
  @ViewChild('regionSelect') regionSelect: MatSelect;
  displayExcelData: boolean = false;
  bayFilterCtrl: FormControl = new FormControl();
  public filteredBays: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('siteSelect') siteSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  protected _onDestroy2 = new Subject<void>();
  changeEndDate: boolean = true;
  prevPayload: any;
  prevSelectedDate: any;
  alarmsList: any = [];

  constructor(
    private adminService: FacilitymasterService,
    private bay: BayMasterService,
    private formBuilder: FormBuilder,
    private allone: AllinoneService,
    private toastr: ToastrService,
    private route: Router,
    private reports: ReportsService,
    private datepipe: DatePipe,
    private storageService: StorageService
  ) {
    this.allone.getAlertdata('0');
    this.allone.siteSource$.subscribe((data)=>{
      this.facilityID1 = {"facilityId":this.storageService.getvariable(),"facilityName":this.storageService.getSiteName()};
      this.getBays(this.facilityID1);
    })

  }

  ngOnInit(): void {
    this.getRegion();
    this.setMaxDate();
    this.minDate = dayjs(new Date(2022, 10, 1));
    let currentDate = new Date();
    this.minMonth = new Date(currentDate.getFullYear(),0,1);
  }
  setMaxDate(){
    let currentDate = new Date();
    currentDate.setHours(23);
    currentDate.setMinutes(59);
    currentDate.setSeconds(59);
    currentDate.toISOString();
    this.maxDate  = dayjs(currentDate);
    }
 
    resetMinMax(){
      this.reportsForm.get("min").patchValue("");
      this.reportsForm.get("max").patchValue("");
    }
  ngAfterViewInit() {
    setInterval(() => {
      this.progressCard = sessionStorage.getItem('loading');
    }, 1);
    this.setInitialValue();
    // this.reportsubmit();
  }
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
    this._onDestroy2.next();
    this._onDestroy2.complete();
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  reportsForm = this.formBuilder.group({
   // regionName: ['', [Validators.required]],
    siteName: [''],
    range: [''],
    min: [''],
    max: [''],
  });
  protected setInitialValue() {}
  protected filterRegions() {
    // console.log(this.RegionData);
    if (!this.RegionData) {
      return;
    }
    // get the search keyword
    let search = this.regionFilterCtrl.value;
    if (!search) {
      this.filteredRegions.next(this.RegionData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredRegions.next(
      this.RegionData.filter(
        (region) => region.facilityName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  protected filterBays() {
    // console.log(this.BayData);
    if (!this.BayData) {
      return;
    }
    // get the search keyword
    let search = this.bayFilterCtrl.value;
    if (!search) {
      this.filteredBays.next(this.BayData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBays.next(
      this.BayData.filter(
        (region) => region.bayName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  isInvalidDate = (m: any) => {
    return  m.diff(dayjs().add(1,"d").hour(0).minute(0).second(0),'d',true)>0;
  };

  getRegion() {
    this.RegionData = [];
    this.adminService.getfacilitymaster().subscribe((res) => {
      if (res.elements.length !== 0) {
        res.elements[0].forEach((x) => {
          if(x.isActive == true){
            this.RegionData.push(x);
          }
        });
        this.filteredRegions.next(this.RegionData.slice());
        this.regionFilterCtrl.valueChanges
          .pipe(takeUntil(this._onDestroy))
          .subscribe(() => {
            this.filterRegions();
          });
      } else if (res.elements.length == 0) {
        this.RegionData = [];
        this.filteredRegions.next(this.RegionData.slice());
      }
    });
  }

  getBays(id) {
    this.facilityID1 = id;
    this.BayData = [];
    this.bay.getbaybyid1(id.facilityId).subscribe((res) => {
      if (res.elements.length !== 0) {
        this.BayData = res.elements;
        this.filteredBays.next(this.BayData.slice());
        this.bayFilterCtrl.valueChanges
          .pipe(takeUntil(this._onDestroy))
          .subscribe(() => {
            this.filterBays();
          });
      } else if (res.elements.length == 0) {
        this.BayData = [];
        this.filteredBays.next(this.BayData.slice());
      }
    });
  }

  async getbay1(id) {
    this.bayID1 = id;
    // console.log(id);
  }

  // onSelectionChange(ID: any) {
  //   console.log(ID)
  //   if (ID.facilityId) {
  //  this.facilityID1 = ID;
  //     this.getBays(ID);
  //   } else if (ID || ID == "") {
  //     this.bayID1 = ID
  //   }
  //   this.visible = false
  // }

  reportsubmit() {
    // console.log(this.selected);
    const obj = {};
    // debugger;
   // this.clickSubject.next(1);
    if (!this.reportsForm.get('min')?.value) {
      this.min1 = 0;
    } else {
      this.min1 = this.reportsForm.get('min')?.value;
    }
    if (!this.reportsForm.get('max')?.value) {
      this.max1 = 0;
    } else {
      this.max1 = this.reportsForm.get('max')?.value;
    }

    let data = {};
     if (!this.reportsForm.valid) {
      Object.keys(this.reportsForm.controls).forEach((field) => {
        const control = this.reportsForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    }  else  if ((!this.selected?.startDate && !this.selected?.endDate ) && (!this.monthRange || !this.monthRange?.[0] && !this.monthRange?.[1]) ) {
        this.toastr.error("Month Selection or Date Selection is Required");
    } else if (this.reportsForm.valid) {
      this.bayID2 = this.bayID1;
      this.facilityID2 = this.facilityID1;
      if(this.monthRange?.[0] && this.monthRange?.[1]){
        this.showWeekWiseGraph = false;
        this.startMonth = this.monthRange[0];
        this.endMonth = this.monthRange[1];
        this.selectedYear = this.monthRange[0].getFullYear();
        this.allone.clickSubjectMonth.next({
          startMonth:this.startMonth,
          endMonth: this.endMonth,
          facilityID: this.facilityID2,
          bayID: this.bayID2,
          year: this.selectedYear
        });
        this.showAvgTable = true;
        this.hideicons = false;
        sessionStorage.setItem('loading', 'loading__bar');
      }
      else if(this.selected.startDate != null && this.selected.endDate!=null){
      this.startDate1 = this.selected.startDate;
      this.endDate1 = this.selected.endDate;
      this.hideicons = true;
      this.showAvgTable = false;
      this.showWeekWiseGraph = false;
      this.startDatereport = this.startDate1;
      this.endDatereport = this.endDate1;
      this.allone.clickSubject.next({
        startDate:this.startDate1,
        endDate: this.endDate1,
        facilityID: this.facilityID2,
        min: this.min1 ,
        max: this.max1 ,
        bayID: this.bayID2
      });
      sessionStorage.setItem('loading', 'loading__bar');
    }
      else if(this.selected.startDate || this.selected.endDate) {
        if(!this.selected.startDate)
          this.toastr.error("Start Date Selection is Required");
        else if(!this.selected.endDate)
        this.toastr.error("End Date Selection is Required");}
      else if(this.monthRange[0] || this.monthRange[1]){
        if(!this.monthRange[0])
        this.toastr.error("Start Month Selection is Required");
        else if(!this.monthRange[1])
        this.toastr.error("End Month Selection is Required");
      }
    }
  }

  // rangeClicked($eve) {
  //   console.log('I am range Click :', $eve.dates[1].$d);
  //   this.startDate1 = $eve.dates[0].$d;
  //   this.endDate1 = $eve.dates[1].$d;
  //   this.changeEndDate = true;
  //   if (
  //     $eve.label == 'Yesterday' ||
  //     $eve.label == 'Last 7 Days' ||
  //     $eve.label == 'Last 30 Days'
  //   ) {
  //     this.changeEndDate = false;
  //   } else {
  //     this.changeEndDate = true;
  //   }
  //   !this.startDate1 || !this.endDate1? this.dateSelectionFlag=true:this.dateSelectionFlag=false
  // }

  rangeClicked($eve) {
    // console.log("I am range Click");
    if ($eve.startDate !== null && $eve.endDate !== null) {
      this.startDate1 = $eve.startDate;
      this.endDate1 = new Date($eve.endDate).toISOString();
    }
    if(this.dateSelectionFlag)
      !this.startDate1|| !this.endDate1? this.dateSelectionFlag=true:this.dateSelectionFlag=false
  }


  dateSelect($eve) {
    let startDate1 = $eve.dates[0].$d;
    let endDate1 = $eve.dates[1].$d;
    if(this.dateSelectionFlag)
      !startDate1 || !endDate1? this.dateSelectionFlag=true:this.dateSelectionFlag=false
  }

  // dateSelect($eve) {
  //   let startDate1 = $eve.dates[0].$d;
  //   let endDate1 = $eve.dates[1].$d;

  //   !startDate1 || !endDate1? this.dateSelectionFlag=true:this.dateSelectionFlag=false
  // }


  async exportExcel() {
    if(this.hideicons){
      if(sessionStorage.getItem('data') == ""){
        this.toastr.warning("No data available for the selected criteria.");
        return;
      }
    this.resultData = JSON.parse(sessionStorage.getItem('data'));
    if(this.resultData.length==0){
      this.toastr.warning("No data available for the selected criteria.");
      return;
    }
    // console.log("resultData"+ this.resultData)
    //Create a workbook with a worksheet
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Data');
    //add column name
    let header = [
      'Truck No.',
      'Bay Name',
      'Entry Date & Time',
      'Exit Date & Time',
      'Total Waiting Time (min)',
    ];

    let siteRow = worksheet.addRow(['Site Name', this.facilityID1.facilityName]);
    siteRow.eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
    });

    let headerRow = worksheet.addRow(header);
    headerRow.eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
    });
    this.resultData.forEach((row: any) => {
      let refactored = {...row};
      refactored.entryTime = this.datepipe.transform(refactored.entryTime,"MM-dd-yyyy HH:mm", "EDT");
      refactored.exitTime = this.datepipe.transform(refactored.exitTime,"MM-dd-yyyy HH:mm", "EDT");
      worksheet.addRow([refactored.vehicleLicence,refactored.bayName,refactored.entryTime,refactored.exitTime,refactored.waitingTime]);
    });
    worksheet.getColumn(2).width = 15;
    worksheet.getColumn(3).width = 20;
    worksheet.getColumn(4).width = 20;
    worksheet.getColumn(5).width = 20;
    worksheet.addRow([]);
    let title = 'Waiting Time Evaluation Report';
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fs.saveAs(blob, title + '.xlsx');
    });}
    else if(this.showAvgTable){
      this.resultData = JSON.parse(sessionStorage.getItem('data'));
    if(this.resultData.length==0){
      this.toastr.warning("No data available for the selected criteria.");
      return;
    }

       //Create a workbook with a worksheet
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Data');

    worksheet.mergeCells('A1:A2');
    worksheet.mergeCells('B1:D1');
    worksheet.mergeCells('E1:E2');
    worksheet.getCell('A1').value = 'Month';
    worksheet.getCell('B1').value = 'Bay Wise Avg Waiting Time (HH:MM)';
    worksheet.getCell('E1').value = 'Total Turn around Time';
    worksheet.getCell('B2').value = 'Parking';
    worksheet.getCell('C2').value = 'Loading';
    worksheet.getCell('D2').value = 'Tarping';
    worksheet.getRow(1).eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
      cell.alignment = {
        horizontal:'center'
      }
    });
    worksheet.getRow(2).eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12
      };
      cell.alignment = {
        horizontal:'center'
      }
    });
    this.dataForExcel = this.resultData.map((item)=>{
      let modifiedItem ={...item};
      modifiedItem.month = modifiedItem.month;
      modifiedItem.PARKING = this.getHourMinute(modifiedItem.PARKING);
      modifiedItem.LOADING = this.getHourMinute(modifiedItem.LOADING);
      modifiedItem.TARPING = this.getHourMinute(modifiedItem.TARPING);
      modifiedItem.Total = this.getHourMinute(modifiedItem.Total);
      return [modifiedItem.month,modifiedItem.PARKING,modifiedItem.LOADING,modifiedItem.TARPING,modifiedItem.Total];
    })
    this.dataForExcel.forEach((d) => {
      let row = worksheet.addRow(d);
      row.alignment = {
        horizontal:'center'
      }
    });
    worksheet.getColumn(2).width = 15;
    worksheet.getColumn(3).width = 15;
    worksheet.getColumn(4).width = 15;
    worksheet.getColumn(5).width = 25;
    worksheet.addRow([]);
    let title = 'Waiting Time Evaluation Report';
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fs.saveAs(blob, title + '.xlsx');
    });}
    else if(this.showAvgTable){
      this.resultData = JSON.parse(sessionStorage.getItem('data'));
    if(this.resultData.length==0){
      this.toastr.error("No data available for the selected criteria.");
      return;
    }

       //Create a workbook with a worksheet
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Data');

    worksheet.mergeCells('A1:A2');
    worksheet.mergeCells('B1:D1');
    worksheet.mergeCells('E1:E2');
    worksheet.getCell('A1').value = 'Month';
    worksheet.getCell('B1').value = 'Bay Wise Avg Waiting Time (HH:MM)';
    worksheet.getCell('E1').value = 'Total Turn around Time';
    worksheet.getCell('B2').value = 'Parking';
    worksheet.getCell('C2').value = 'Loading';
    worksheet.getCell('D2').value = 'Tarping';
    worksheet.getRow(1).eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12,
      };
      cell.alignment = {
        horizontal:'center'
      }
    });
    worksheet.getRow(2).eachCell((cell, number) => {
      cell.font = {
        bold: true,
        color: { argb: '00000' },
        size: 12
      };
      cell.alignment = {
        horizontal:'center'
      }
    });

    this.dataForExcel = this.resultData.map((item)=>{
      let modifiedItem ={...item};
      modifiedItem.PARKING = this.getHourMinute(modifiedItem.PARKING);
      modifiedItem.LOADING = this.getHourMinute(modifiedItem.LOADING);
      modifiedItem.TARPING = this.getHourMinute(modifiedItem.TARPING);
      modifiedItem.Total = this.getHourMinute(modifiedItem.Total);
      return Object.values(modifiedItem);
    })
    this.dataForExcel.forEach((d) => {
      let row = worksheet.addRow(d);
      row.alignment = {
        horizontal:'center'
      }
    });
    }
  }
  getHourMinute(minutes){
    var time = minutes;
    var hours1 = parseInt((parseInt(time)/60).toString());
    var mins1 = parseInt(((parseInt(time)%60)).toString());
    return hours1 + ':' + mins1;
  }
  public generatePDF() {
    // if (this.hideicons == true) {
    //   this.hideFlagTable = false;
    //   var doc = new jsPDF('p', 'mm', 'a4');
    //   var DATA = document.getElementById('capture')! as HTMLCanvasElement;
    //   let fName = 'Waiting Time Evaluation Report';
    //   var opt = {
    //     margin: 0,
    //     filename: fName + '.pdf',
    //     image: { type: 'jpeg', quality: 0.98 },
    //     html2canvas: { scale: 2 },
    //     jsPDF: { unit: 'in', format: 'letter', orientation: 'landscape' }
    //   };

    if(sessionStorage.getItem('data') == "")
    {
      this.toastr.warning("No data available for the selected criteria.");
      return;
    }
    this.resultData = JSON.parse(sessionStorage.getItem('data'));
    // debugger;
    if(!this.resultData){
      this.toastr.warning("No data available for the selected criteria.");
      return;
    }
    else if(this.resultData.length ==0){
      this.toastr.warning("No data available for the selected criteria.");
      return;
    }{
    if(!this.monthRange)
    this.generatePDFDatetable()
     // this.clickSubjectpdf.next(1);
    else{
      this.generatePDFtable();
    }
    //sessionStorage.setItem('data', "");
  }
      // html2pdf().set(opt).from(DATA).save();
      // setTimeout(function () {
      //   window.location.reload();
      // }, 10000);
    // }
  }
  showWeekWiseData(eve){
    if(eve){
      this.selectedMonth = eve;
      this.showWeekWiseGraph = true;}
  }
  generatePDFtable() {
    var sGraph = document.getElementById('month-chart').innerHTML;
    var sTable = document.getElementById('table').innerHTML;
    var wTable;
    if(this.showWeekWiseGraph){
      wTable = document.getElementById('week-chart').innerHTML;
    }
    let x = this.facilityID1.facilityName;


    let y = (this.datepipe.transform(this.monthRange[0], 'MM-yyyy'));
    let z = (this.datepipe.transform(this.monthRange[1], 'MM-yyyy'));
    // if (this.bayID1 == "" || undefined || this.bayID1?.length==0) {
    //   var w = 'All Bays';
    // } else {
    //   w = this.bayID1;
    // }
    let w = [];
    if (this.bayID1 == "" || this.bayID1 == undefined || this.bayID1?.length == 0) {

      w = ['All Bays'];

    } else {

      for (let i = 0; i < this.bayID1.length; i++) {

        if(this.bayID1[i]==""){

          w.push('All Bays')

        }else{

          w.push(this.bayID1[i].bayName);

        }

      }

      // console.log(w)

    }
    let u = y + " " + "to" + " " + z
    var Filename = "Site Selected : " + x + "," + " Bay Name : " + w + "," +" Date Selected : From " + u ;
    var style = "<style>";
    style = style + "table {width: 100%;font: 18px Calibri;}";
    style = style + "table, th, td{border: solid 1px #DDD; border-collapse: collapse; page-break: avoid !important;";
    style = style + "padding: 2px 3px; text-align: center;}";
    style = style + "mat-paginator {display: none;}";
    style = style + "average-waitingtime-table div {height: fit-content !important; margin-bottom:1px; display: flex; page-break: avoid !important;}";
    style = style + "#week-graph {width: fit-content !important;height: 343px!important; margin-bottom:2px;display: flex; page-break: avoid !important;}"
    style = style + "#month-graph {width: fit-content !important;height: 343px!important;display: flex; page-break: avoid !important;}"
    style = style + "</style>";
    var title = "<title>" + name + "</title>";
    var printWindow = window.open('newWin.html', 'NewWindow', 'menubar=0,scrollbars=1,height=768,width=1366, top=10');
    printWindow.document.write('<html moznomarginboxes mozdisallowselectionprint><head>' + "<h4 style='color: black; text-align: center; font-size:18px;'>" + Filename);
    printWindow.document.write(title);
    printWindow.document.write(style);
    printWindow.document.write('</h4>');
    printWindow.document.write('</head><body>');
    if(this.showWeekWiseGraph){
      printWindow.document.write(wTable);
    }
    if(this.showAvgTable){
      printWindow.document.write(sGraph);
      printWindow.document.write(sTable);
    }


    printWindow.document.write('</body></html>');
    setTimeout(function () {
      printWindow.print();
      printWindow.close();
    }, 100);

  }

  generatePDFDatetable() {
    if (this.datalabels == false) {
      this.toastr.warning('No data available for the selected criteria.');
      return;
    }
    let totalcnt = "";

    let el = document.getElementById('mydiv');
    let el1 = document.getElementById('mydiv1');

    el.style.display = 'block';
    el1.style.display = 'none';
    // var sTable = document.getElementById('table').innerHTML;
    var sTable = document.getElementById('date-table').innerHTML;
    totalcnt = document.getElementById('totalcnt').innerHTML;
    el.style.display = 'none';
    el1.style.display = 'block';
    // console.log("date table inner html",sTable)
    let x = this.facilityID1.facilityName;
    let y = (this.datepipe.transform(this.startDate1, 'MM-dd-yyyy', "UTC"));
    let z = (this.datepipe.transform(this.endDate1, 'MM-dd-yyyy', "UTC"));
    let w = [];
    // if (this.bayID1 == "" || undefined || this.bayID1?.length==0) {
    //   w = ['All Bays'];
    // } else {
    //   for(let i = 0; i<this.bayID1.length; i++){
    //   w.push(this.bayID1[i].bayName);
    //   }
    //   // console.log(w)
    // }

    if (this.bayID1 == "" || this.bayID1 == undefined || this.bayID1?.length == 0) {

      w = ['All Bays'];

    } else {

      for (let i = 0; i < this.bayID1.length; i++) {

        if(this.bayID1[i]==""){

          w.push('All Bays')

        }else{

          w.push(this.bayID1[i].bayName);

        }

      }

      // console.log(w)

    }


    let u = y + " " + "to" + " " + z
    var Filename = "Site Selected : " + x + "," + " Bay Name : " + w + "," +" Date Selected : From " + u ;
    var style = "<style>";
    style = style + "table {width: 100%;font: 18px Calibri;}";
    style = style + "table, th, td{border: solid 1px #DDD; border-collapse: collapse; page-break: avoid !important;";
    style = style + "padding: 2px 3px; text-align: center;}";
    style = style + "mat-paginator {display: none;}";
    style = style + "app-alert-table div {height: fit-content !important; margin-bottom:1px; display: flex; page-break: avoid !important;}";
    style = style + "</style>";
    var title = "<title>" + name + "</title>";
    var printWindow = window.open('newWin.html', 'NewWindow', 'menubar=0,scrollbars=1,height=768,width=1366, top=10');
    printWindow.document.write('<html moznomarginboxes mozdisallowselectionprint><head>' + "<h4 style='color: black; text-align: center; font-size:18px;'>" + Filename);
    printWindow.document.write(title);
    printWindow.document.write(style);
    printWindow.document.write('</h4>');
    printWindow.document.write('</head><body>');
    printWindow.document.write("<br><br> <b>Alerts Total Count :" + totalcnt + "</b>")
    printWindow.document.write(sTable);


    printWindow.document.write('</body></html>');
    setTimeout(function () {
      printWindow.print();
      printWindow.close();
    }, 100);


  }

  clearInput() {
    // Clear the input field
    // this.reportsForm.get('range')?.reset();
    this.selected = "";
    this.monthRange = "";
    this.hideicons = false;
    this.showAvgTable = false;
    this.showWeekWiseGraph = false;
    // let el1 = document.getElementById('mydiv1');
    // el1.style.display = 'none';
  }


}
