import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { DtSimulatorRoutingModule } from './dt-simulator-routing.module';
import { DtSimulatorComponent } from '../../Weyerhaeuser_Components/dt-simulator/dt-simulator.component';
import { AllModule } from 'client/app/shared/all_modules';
import { DigitOnlyDirective } from '../../entity/onlynumber.directive';
import { Scenario1Component } from './scenario1/scenario1.component';
import { Scenario2Component } from './scenario2/scenario2.component';
import { Scenario3Component } from './scenario3/scenario3.component';

@NgModule({
  declarations: [
    DtSimulatorComponent,
    DigitOnlyDirective,
    Scenario1Component,
    Scenario2Component,
    Scenario3Component

  ],
  imports: [
    CommonModule,
    DtSimulatorRoutingModule,
    AllModule

  ],
  providers: [DatePipe]
})
export class DtSimulatorModule { }
