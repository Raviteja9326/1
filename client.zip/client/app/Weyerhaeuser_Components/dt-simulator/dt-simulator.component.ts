import { Component } from '@angular/core';

@Component({
  selector: 'app-dt-simulator',
  templateUrl: './dt-simulator.component.html',
  styleUrls: ['./dt-simulator.component.scss']
})
export class DtSimulatorComponent {
  isLinear:boolean = false;

  onStepClick(event) {
    if(event.selectedIndex == 0){

    }
    else if(event.selectedIndex == 1){

    }
    else if(event.selectedIndex == 2){

    }
  }
}
