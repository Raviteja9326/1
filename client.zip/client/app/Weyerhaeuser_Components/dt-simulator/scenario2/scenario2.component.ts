import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { SimulatorService } from 'client/app/services/simulator.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-scenario2',
  templateUrl: './scenario2.component.html',
  styleUrls: ['./scenario2.component.scss']
})
export class Scenario2Component implements OnInit {

  visible: boolean = false;
  loading: boolean = false;
  ELEMENT_DATA1: any;
  @Input() public monthAndYear: Date | null = null;
  @Output() public monthAndYearChange = new EventEmitter<Date | null>();
  destroy$: Subject<boolean> = new Subject<boolean>();
  displayNoRecords1: boolean;
  dataSource1: MatTableDataSource<any>;
  @ViewChild('sort1') sort1: MatSort;
  pageIndex1: number = 1;
  pageSize1: number = 20;
  totalItems1: number;
  date = new Date();
  public diffParking: any;
  displayedColumns1: string[] = [
    "vehicleLicence",
    "parkingstart",
    "parkingend",
    "parkingwaiting",
    "loadingstart",
    "loadingend",
    "loadingwaiting",
    "tarpingstart",
    "tarpingend",
    "tarpingwaiting"
  ];
  selectedTime: string;

  constructor(private formBuilder: FormBuilder, private simulator: SimulatorService, private toastr: ToastrService, private route: Router, private datepipe: DatePipe) { }

  dtform = this.formBuilder.group({
    truckstoretarp: ['', [Validators.required]],
    loadingslots: ['', [Validators.required]],
    tarpingslots: ['', [Validators.required]],
  })

  ngOnInit(): void {
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  public emitDateChange(
    event: MatDatepickerInputEvent<Date | null, unknown>
  ): void {
    this.monthAndYearChange.emit(event.value);
  }
  public monthChanged(value: any, widget: any): void {
    this.monthAndYear = value;
    widget.close();
  }

  get f() { return this.dtform.controls }

  userMastersubmit() {
    console.log(this.selectedTime)
    // this.check();
    if (!this.dtform.valid) {
      Object.keys(this.dtform.controls).forEach(field => {
        const control = this.dtform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.visible = false
    }
    else {
      this.simulateData();
    }
  }

  simulateData() {
    this.visible = true;
    const obj: any = {};
    this.simulator.simulatedata2(this.dtform.value).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        this.visible = false;
        this.loading = true;
        console.log(res)
        this.ELEMENT_DATA1 = res.data
        this.displayNoRecords1 = false;
        this.ELEMENT_DATA1.forEach(ele => {
          let parkingstart = new Date(ele.parkingstart);
          let parkingend = new Date(ele.parkingend);
          let loadingstart = new Date(ele.loadingstart);
          let loadingend = new Date(ele.loadingend);
          let tarpingstart = new Date(ele.tarpingstart);
          let tarpingend = new Date(ele.tarpingend);
          let diffParking = parkingend.getTime() - parkingstart.getTime();
          let diffLoading = loadingend.getTime() - loadingstart.getTime();
          let diffTarping = tarpingend.getTime() - tarpingstart.getTime();
          ele.parkingwaiting = Math.round(diffParking / 60000);
          ele.loadingwaiting = Math.round(diffLoading / 60000);
          ele.tarpingwaiting = Math.round(diffTarping / 60000);
        })
        console.log(this.ELEMENT_DATA1)
        this.dataSource1 = new MatTableDataSource<any>(this.ELEMENT_DATA1);
        setTimeout(() => {
          this.dataSource1.sort = this.sort1;
          this.totalItems1 = this.ELEMENT_DATA1.length;
          this.pageIndex1 = 0;
        });
      },
      error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    })
  }


  pageChanged1(event) {
    this.pageIndex1 = event.pageIndex + 1;
    this.pageSize1 = event.pageSize;
    this.simulateData();
  }
}
