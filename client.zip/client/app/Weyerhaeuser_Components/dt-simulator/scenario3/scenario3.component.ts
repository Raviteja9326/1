import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { SimulatorService } from 'client/app/services/simulator.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-scenario3',
  templateUrl: './scenario3.component.html',
  styleUrls: ['./scenario3.component.scss']
})
export class Scenario3Component implements OnInit {

  visible:boolean = false;
  loading:boolean = false;
  selectedTime: string;
  ELEMENT_DATA1: any;
  @Input() public monthAndYear: Date | null = null;
  @Output() public monthAndYearChange = new EventEmitter<Date | null>();
  destroy$: Subject<boolean> = new Subject<boolean>();
  displayNoRecords1: boolean;
  dataSource1: MatTableDataSource<any>;
  @ViewChild('sort1') sort1: MatSort;
  pageIndex1: number = 1;
  pageSize1: number = 20;
  totalItems1: number;
  date = new Date();
  displayedColumns1: string[] = [
    "Truck No",
    "parkingstart",
    "parkingend",
    "loadingstart",
    "loadingend",
    "tarpingstart",
    "tarpingend"
  ];

  constructor(private formBuilder: FormBuilder, private simulator: SimulatorService, private toastr: ToastrService, private route: Router, private datepipe:DatePipe) {}

  dtform = this.formBuilder.group({
    totaltrucks : ['',[Validators.required]],
    loadingslots : ['',[Validators.required]],
    tarpingslots : ['',[Validators.required]],
    loadingduration : ['',[Validators.required]],
    tarpingduration : ['',[Validators.required]],
  })

  get offer2Controllers() { return this.dtform.controls }

  ngOnInit(): void {}

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  check(){
    if(this.dtform.value.loadingslots > this.dtform.value.tarpingslots){
      this.toastr.error("Loading Slots Should not be Greater Than Tarping Slots");
      this.dtform.controls.loadingslots.patchValue('')
    }
  }

  userMastersubmit() {
    this.check();
    if (!this.dtform.valid) {
      Object.keys(this.dtform.controls).forEach(field => {
        const control = this.dtform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.visible = false
    }
      else {
        this.simulateData();
      }
    }

  simulateData(){
    const dates = this.datepipe.transform(this.date, 'yyyy-MM-dd') +' ' + this.selectedTime;
    this.visible = true;
    const obj:any = {};
    obj['starttime'] = this.datepipe.transform(dates, 'yyyy-MM-dd HH:mm', 'UTC')!;
    console.log(obj)
    this.simulator.simulatedata3(this.dtform.value, obj).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        this.visible = false;
        this.loading = true;
        console.log(res)
        this.ELEMENT_DATA1 = res.data
          this.displayNoRecords1 = false;
          this.dataSource1 = new MatTableDataSource<any>(this.ELEMENT_DATA1);
          setTimeout(() => {
            this.dataSource1.sort = this.sort1;
            this.totalItems1 = this.ELEMENT_DATA1.length;
            this.pageIndex1 = 0;
          });
      },
      error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
  })
}


pageChanged1(event) {
  this.pageIndex1 = event.pageIndex + 1;
  this.pageSize1 = event.pageSize;
  this.simulateData();
}
}
