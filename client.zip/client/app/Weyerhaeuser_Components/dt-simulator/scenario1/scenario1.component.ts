import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { SimulatorService } from 'client/app/services/simulator.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-scenario1',
  templateUrl: './scenario1.component.html',
  styleUrls: ['./scenario1.component.scss']
})
export class Scenario1Component implements OnInit {

  visible:boolean = false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  selected = '';
  gridColumns = 3;
  optionValue: any = 'one';
  DelayTime: any;
  TarpingSlots: any;
  TarpingTime: any;
  TruckEnter: any;
  SafetycheckTime: any;
  LoadingSlot: any;
  TarpingSlot: any;
  RemainTruck: any;
  expected_avg_time_load: any;
  expected_avg_time_park: any;
  expected_avg_tt_time: any;
  skeletonloader: boolean = false;
  loading: boolean;
  ELEMENT_DATA1: any;
  ELEMENT_DATA2: any;
  displayNoRecords1: boolean;
  displayNoRecords2: boolean;
  dataSource1: MatTableDataSource<any>;
  dataSource2: MatTableDataSource<any>;
  @ViewChild('sort1') sort1: MatSort;
  @ViewChild('sort2') sort2: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  pageIndex1: number = 1;
  pageIndex2: number = 1;
  pageSize1: number = 20;
  pageSize2: number = 20;
  totalItems1: number;
  totalItems2: number;
  displayedColumns1: string[] = [
    "Sr.No.",
    "vehicleLicence",
    "recivedTime",
    "new_wait_park",
    "status"
  ];
  displayedColumns2: string[] = [
    "Sr.No.",
    "vehicleLicence",
    "recivedTime",
    "new_wait_load",
    "status"
  ];

  constructor(private simulator: SimulatorService, private toastr: ToastrService, private route: Router) { }

  ngOnInit(): void {
  }

  simulateDtdata() {
    if (this.TarpingTime == null || this.TarpingTime == "") {
      this.toastr.error('Field Is Mandatory')
      return
    }
    if (this.TarpingTime == 0) {
      this.toastr.error('Set Tarping Time Cannot Be Zero')
      return
    }
    if (this.TarpingTime == 0) {
      this.toastr.error('Set Tarping Time Cannot Be Zero')
      return
    } else {
      const obj = {};
      // obj['tarping_slot'] = this.TarpingSlots,
      obj['tarping_waiting_time'] = this.TarpingTime,
        // obj['delay_loading'] = this.DelayTime,
        this.simulator.simulatedata(obj).pipe(takeUntil(this.destroy$)).subscribe({
          next: (res) => {
            console.log(res);
            if (res.data.expected_avg_time_load == null && res.data.expected_avg_time_park == null && res.data.expected_avg_tt_time == null && res.data.parking_state.length == 0 && res.data.loading_state.length == 0) {
              this.optionValue = '';
              this.TarpingTime ='';
              this.toastr.error('Insufficient Data Available');
              return;
            }
            if (res.data.expected_avg_time_load !== null) {
              this.expected_avg_time_load = res.data.expected_avg_time_load.toFixed();
            }
            if (res.data.expected_avg_time_park !== null) {
              this.expected_avg_time_park = res.data.expected_avg_time_park.toFixed();
            }
            if (res.data.expected_avg_tt_time !== null) {
              this.expected_avg_tt_time = res.data.expected_avg_tt_time.toFixed();
            }
            // this.expected_avg_tt_time = res.expected_avg_tt_time.toFixed(); //correction on API
            this.ELEMENT_DATA1 = res.data.parking_state;
            this.ELEMENT_DATA2 = res.data.loading_state;
            if (this.ELEMENT_DATA1.length !== 0) {
              this.loading = false;
              this.displayNoRecords1 = false;
              this.dataSource1 = new MatTableDataSource<any>(this.ELEMENT_DATA1);

              setTimeout(() => {
                this.dataSource1.sort = this.sort1;
                this.totalItems1 = this.ELEMENT_DATA1.length;
                this.pageIndex1 = 0;
                // this.totalItems = res.metadata.total;
                // this.pageIndex = res.metadata.current_page - 1;
              });
            }
            else if (this.ELEMENT_DATA1.length == 0) {
              this.dataSource1 = new MatTableDataSource<any>([]);
              this.ELEMENT_DATA1 = [];
              this.totalItems1 = 0;
              this.pageIndex1 = 0;
              this.displayNoRecords1 = true;
              this.loading = false;
            }
            if (this.ELEMENT_DATA2.length !== 0) {
              this.loading = false;
              this.displayNoRecords2 = false;
              this.dataSource2 = new MatTableDataSource<any>(this.ELEMENT_DATA2);
              console.log(this.dataSource2)
              setTimeout(() => {
                this.dataSource2.sort = this.sort2;
                this.totalItems2 = this.ELEMENT_DATA2.length;
                this.pageIndex2 = 0;
                // this.totalItems = res.metadata.total;
                // this.pageIndex = res.metadata.current_page - 1;
              });
            }
            else if (this.ELEMENT_DATA2.length == 0) {
              this.dataSource2 = new MatTableDataSource<any>([]);
              this.ELEMENT_DATA2 = [];
              this.totalItems2 = 0;
              this.pageIndex2 = 0;
              this.displayNoRecords2 = true;
              this.loading = false;
            }

          }, error: (error) => {
            this.toastr.error(error.error.message)
            this.route.navigate(['/dashboard/errors']);
          }

        });
    }
  }

  pageChanged1(event) {
    this.pageIndex1 = event.pageIndex + 1;
    this.pageSize1 = event.pageSize;
    this.simulateDtdata();
  }
  pageChanged2(event) {
    this.pageIndex2 = event.pageIndex + 1;
    this.pageSize2 = event.pageSize;
    this.simulateDtdata();
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

}
