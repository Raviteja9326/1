import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import{DtSimulatorComponent} from './dt-simulator.component'

const routes: Routes = [
  {path:'',component:DtSimulatorComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DtSimulatorRoutingModule { }