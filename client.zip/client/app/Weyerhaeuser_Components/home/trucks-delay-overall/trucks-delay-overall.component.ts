import { DatePipe } from '@angular/common';
import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { LandModalComponent } from 'client/app/modals/land-modal/land-modal.component';
import { HomeService } from 'client/app/services/home.service';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-trucks-delay-overall',
  templateUrl: './trucks-delay-overall.component.html',
  styleUrls: ['./trucks-delay-overall.component.scss']
})
export class TrucksDelayOverallComponent implements OnChanges {
  private readonly _destroying$ = new Subject<void>();
  @Input() allData: any;
  allDatas: any;
  @Input() park: any;
  @Input() land: any;
  @Input() tarp: any;
  @Input() exit: any;
  loading:boolean = true;
  items = ['types-1', 'types-2', 'types-3','types-4'];
  ngOnChanges(changes: SimpleChanges) {
    if(changes.park?.currentValue != undefined || null){
      this.loading = false;
    }
    else if(changes.land?.currentValue != undefined || null){
      this.loading = false;
    }
    else if(changes.tarp?.currentValue != undefined || null){
      this.loading = false;
    }
    else if(changes.exit?.currentValue != undefined || null){
      this.loading = false;
    }
    else if (changes.allData?.currentValue.dateend != undefined || null) {
      this.allDatas = this.allData
    }
  }
  constructor(public dialog: MatDialog, private landserv: HomeService, private route: Router, private datepipe: DatePipe, private toastr: ToastrService, private ngxService: NgxUiLoaderService) {}
  async getMaster_details(data) {
    console.log(data)
    let obj = {};
    obj['facilityId'] = this.allDatas.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.allDatas.datestart,
    obj['to_date'] = this.allDatas.dateend,
    obj['type']= "overWaiting";
    obj['status']= data.status;
     await this.landserv.getind(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          console.log(res)
          this.truck_Modal(data,res.data);
          this.ngxService.stop();
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
          this.ngxService.stop();
        }
      })
  }
  truck_Modal(data,data2): void {
    console.log(data, data2)
    if(data.status=="Parking In"){
      data.title = "Parking";
    }
    else if(data.status=="Loading In"){
      data.title = "Loading";
    }
    else if(data.status=="Tarping In"){
      data.title = "Tarping";
    }
    else if(data.status=="Exit"){
      data.title = "Turn Around";
    }
    const TrucksData: string = data;
    const TrucksData9: any = data2;
    this.ngxService.start();
    this.dialog.open(LandModalComponent, {
      width: '100%',
      height:'auto',
      data: {TrucksData,TrucksData9},
      disableClose: false,
      autoFocus: false,
      position: {
        top:'20px'
      }
    });
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
