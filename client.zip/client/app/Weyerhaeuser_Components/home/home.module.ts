import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { AllModule } from 'client/app/shared/all_modules';
import { TrucksDataComponent } from './trucks-data/trucks-data.component';
import { TrucksDelayComponent } from './trucks-delay/trucks-delay.component';
import { TrucksDelayOverallComponent } from './trucks-delay-overall/trucks-delay-overall.component';
import { PenalityChargesGraphComponent } from './penality-charges-graph/penality-charges-graph.component';
import { TrucksGraphComponent } from './trucks-graph/trucks-graph.component';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';


@NgModule({
  declarations: [
    HomeComponent,
    TrucksDataComponent,
    TrucksDelayComponent,
    TrucksDelayOverallComponent,
    PenalityChargesGraphComponent,
    TrucksGraphComponent,
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    AllModule,
    NgxDaterangepickerMd.forRoot(),
  ],
  providers: [DatePipe]
})
export class HomeModule { }
