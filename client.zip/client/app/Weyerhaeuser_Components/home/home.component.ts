import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { HomeService } from 'client/app/services/home.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, interval, takeUntil } from 'rxjs';
import * as moment from 'moment';
import 'moment-timezone';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnDestroy, OnInit {
  private readonly _destroying$ = new Subject<void>();
  sitedata: any;
  alerts: any;
  userdata: any;
  trucksData: any;
  minmax: any;
  penality: any;
  from_date: any;
  to_date: any;
  currentDate = new Date();
  bayId: any;
  graph: any;
  graph2: any;
  ranges: any = {}
  maxDate: any;
  minDate: any;
  datestart: any = '';
  dateend: any = '';
  park: any;
  land: any;
  tarp: any;
  exit: any;
  alerts2: any;
  alerts3: any;
  intervalId = null;
  selected: any;
  systemTimezone:any;
  constructor(private route: Router, private datepipe: DatePipe, private storage: StorageService, private landserv: HomeService, private toastr: ToastrService, private Bay_cust: BayMasterService) {
    this.systemTimezone = 'America/New_York';
    moment.tz.setDefault(this.systemTimezone);
    this.userdata = this.storage.getvariable();
    this.showcoverstions();
  }
  showcoverstions(){
    const currentDateTime = moment();
    const estOffset = moment().tz(this.systemTimezone).utcOffset();
    this.selected = {
      startDate: moment()?.hour(0).minute(0),
      endDate: currentDateTime
    };
    this.ranges = {
      'Today': [moment().utcOffset(estOffset).hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'Yesterday': [moment().utcOffset(estOffset).subtract(1, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).subtract(1, 'days').endOf('day').hour(23).minute(59).format('YYYY-MM-DD HH:mm')],
  'Last 7 Days': [moment().utcOffset(estOffset).subtract(6, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'Last 30 Days': [moment().utcOffset(estOffset).subtract(29, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'This Month': [moment().utcOffset(estOffset).startOf('month').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).endOf('month').format('YYYY-MM-DD HH:mm')],
  'Last Month': [moment().utcOffset(estOffset).subtract(1, 'month').startOf('month').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).subtract(1, 'month').endOf('month').format('YYYY-MM-DD HH:mm')]
    };
    this.maxDate = currentDateTime.format('YYYY-MM-DD HH:mm');
  }
  formatDates() {
    try{
    const formattedStartDate = this.selected.startDate.format('YYYY-MM-DD HH:mm');
    const formattedEndDate = this.selected.endDate.format('YYYY-MM-DD HH:mm');
    this.selected.startDate = formattedStartDate;
    this.selected.endDate = formattedEndDate;}
    catch(e){}
  }
  onDateRangeChanged() {
    const estOffset = moment().tz(this.systemTimezone).utcOffset();
 try{//check if today
    if(this.selected.endDate.format("YYYY-MM-DD")!=moment().utcOffset(estOffset).format("YYYY-MM-DD")){
      this.selected = {
        startDate:this.selected.startDate,
        endDate: this.selected.endDate.hour(23).minute(59)
      }
    }}
    catch(e){}

    this.formatDates();
    this.datestart = this.selected.startDate;
    this.dateend = this.selected.endDate;
    this.getbay_Master();
  }
  ngOnInit(): void {this.callapifor1min();}

  callapifor1min(){
    this.intervalId = setInterval(()=>{
      this.getbay_Master();
     },60000)
  }
  callApis() {
    this.getlandingDetails();
    this.getlandingminmax();
    this.getlandingpenalty();
    this.getalerts();
    this.getlandingover1();
    this.getlandingover2();
    this.getlandingover3();
    this.getlandingover4();
    this.getlandingpenaltygraph();
    this.getlandinggraph();
  }
  async getbay_Master() {
    const timedate = {};
    timedate['time'] = this.datepipe.transform(this.currentDate, 'yyyy-MM-dd HH:mm:ss');
    timedate['stamp'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
      this.Bay_cust?.getbay(timedate).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          res.elements.map(data => {
            data.map(data2 => {
              if (data2.facilityId == this.userdata && data2.bayName == "PARKING") {
                console.log('sadas', data2)
                this.bayId = data2.bayId
              }
            })
          });
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      })
    this.callApis();
  }
  async getlandingDetails() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      this.landserv.getlandDetails(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          if (res.data.length != 0) {
            this.trucksData = res.data
          }
          else if (res.data.length == 0) {
            this.trucksData = [];
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async getlandingminmax() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      this.landserv.getminmax(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          if (res.data.length != 0) {
            this.minmax = res.data
          }
          else if (res.data.length == 0) {
            this.minmax = [];
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async getlandingover1() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      obj['status'] = "Parking In"
    this.landserv.getoverall(obj).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        if (res.data.length != 0) {
          this.park = res.data
        }
        else if (res.data.length == 0) {
          this.park = [];
        }
      }, error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  async getlandingover2() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      obj['status'] = "Loading In"
    this.landserv.getoverall(obj).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        if (res.data.length != 0) {
          this.land = res.data
        }
        else if (res.data.length == 0) {
          this.land = [];
        }
      }, error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  async getlandingover3() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      obj['status'] = "Tarping In"
    this.landserv.getoverall(obj).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        if (res.data.length != 0) {
          this.tarp = res.data
        }
        else if (res.data.length == 0) {
          this.tarp = [];
        }
      }, error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  async getlandingover4() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      obj['status'] = "Exit"
    this.landserv.getoverall(obj).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        if (res.data.length != 0) {
          this.exit = res.data
        }
        else if (res.data.length == 0) {
          this.exit = [];
        }
      }, error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  async getlandingpenalty() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      this.landserv.getpenaltycharges(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          if (res.data.length != 0) {
            this.penality = res.data
          }
          else if (res.data.length == 0) {
            this.penality = [];
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async getalerts() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      this.landserv.gealerts(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          this.alerts = res.alerts.total;
          this.alerts2 = res.alerts.timeAlert;
          this.alerts3 = res.alerts.occupancyAlert;
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async getlandingpenaltygraph() {
    let obj = {};
    obj['facilityId'] = this.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.datestart,
    obj['to_date'] = this.dateend,
      obj['bayId'] = this.bayId;
    this.landserv.getpenalty(obj).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        if (res.elements.length != 0) {
          this.graph2 = res.elements;
          this.from_date = '';
          this.to_date = '';
        }
        else if (res.elements.length == 0) {
          this.graph2 = [];
        }
      }, error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  async getlandinggraph() {
    let obj3 = {};
    obj3['facilityId'] = this.userdata;
    obj3['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj3['from_date'] = this.datestart,
    obj3['to_date'] = this.dateend,
      obj3['bayId'] = this.bayId;
    this.landserv.getchart(obj3).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        console.log(res.elements)
        if (res.elements.length != 0) {
          this.graph = res.elements
          this.from_date = '';
          this.to_date = '';
        }
        else if (res.elements.length == 0) {
          this.graph = [];
        }
      }, error: (error) => {
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    clearInterval(this.intervalId);
  }
}
