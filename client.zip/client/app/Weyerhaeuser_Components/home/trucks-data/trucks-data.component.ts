import { DatePipe } from '@angular/common';
import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { LandModalComponent } from 'client/app/modals/land-modal/land-modal.component';
import { HomeService } from 'client/app/services/home.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { NgxUiLoaderService } from "ngx-ui-loader";
import moment from 'moment';

@Component({
  selector: 'app-trucks-data',
  templateUrl: './trucks-data.component.html',
  styleUrls: ['./trucks-data.component.scss'],
})
export class TrucksDataComponent implements OnChanges {
  private readonly _destroying$ = new Subject<void>();
  @Input() trucksData: any;
  @Input() penality: any;
  @Input() alerts: any;
  @Input() allData: any;
  @Input() alerts2: any;
  @Input() alerts3: any;
  allDatas: any;
  penalty: any;
  alert: any;
  loading: boolean = true;
  Entered: any;
  ParkingBay: any;
  LoadingBay: any;
  TarpingBay: any;
  TrucksExited: any;
  ngOnChanges(changes: SimpleChanges) {
    if (changes.trucksData?.currentValue != undefined || null) {
      for (let obj of this.trucksData) {
        if (obj.bayName == 'Total Trucks Entered') {
          this.Entered = obj;
        } else if (obj.bayName == 'Trucks in Parking Bay') {
          this.ParkingBay = obj;
        } else if (obj.bayName == 'Trucks in Loading Bay') {
          this.LoadingBay = obj;
        } else if (obj.bayName == 'Trucks in Tarping Bay') {
          this.TarpingBay = obj;
        } else if (obj.bayName == 'Total Trucks Exited') {
          this.TrucksExited = obj;
        }
      }
    } else if (changes.penality?.currentValue != undefined || null) {
      this.penalty = this.penality;
    }
    else if (changes.alerts?.currentValue != undefined || null) {
      this.alert = this.alerts;
      console.log(this.alerts.total)
    }
    else if (changes.allData?.currentValue.dateend != undefined || null) {
      this.allDatas = this.allData
    }
    this.loading = false;
  }
  constructor(public dialog: MatDialog, private landserv: HomeService, private route: Router, private datepipe: DatePipe, private toastr: ToastrService, private ngxService: NgxUiLoaderService) {}

  async getMaster_details(data,data2) {
    console.log(this.allDatas.datestart, this.allDatas.dateend)
    let obj = {};
    obj['facilityId'] = this.allDatas.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.allDatas.datestart,
    obj['to_date'] = this.allDatas.dateend,
    // obj['to_date']= this.datepipe.transform(this.allDatas.dateend, 'yyyy-MM-dd HH:mm:ss'),
    obj['status']= data,
    obj['type']= "",
     await this.landserv.getind(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          this.truck_Modal(data2,res.data);
          this.ngxService.stop();
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
          this.ngxService.stop();
        }
      })
  }
  truck_Modal(data,data2): void {
    console.log(data)
    const TrucksData: string = data;
    const TrucksData9: any = data2;
    this.ngxService.start();
    this.dialog.open(LandModalComponent, {
      width: '100%',
      maxWidth: '85vw',
      height: 'auto',
      data: { TrucksData, TrucksData9 },
      disableClose: false,
      autoFocus: false,
      position: {
        top: '20px',
      },
    });
  }
  truck_Modal2(data): void {
    console.log(data)
    const TrucksData2: string = data;
    this.dialog.open(LandModalComponent, {
      width: '100%',
      maxWidth: '85vw',
      height: 'auto',
      data: { TrucksData2 },
      disableClose: false,
      autoFocus: false,
      position: {
        top: '20px',
      },
    });
  }
  truck_Modal3(data,data2): void {
    console.log('ssssssssssssssss',data, data2)
    const alertpopup: boolean = true;
    const alertdata: string = data;
    const alertdata2: string = data2;
    this.dialog.open(LandModalComponent, {
      width: '100%',
      maxWidth: '85vw',
      height: 'auto',
      data: {alertpopup, alertdata, alertdata2},
      disableClose: false,
      autoFocus: false,
      position: {
        top: '20px',
      },
    });
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
