import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import dayjs from 'dayjs/esm';
import { LocaleConfig } from 'ngx-daterangepicker-material';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-penality-charges-graph',
  templateUrl: './penality-charges-graph.component.html',
  styleUrls: ['./penality-charges-graph.component.scss']
})
export class PenalityChargesGraphComponent implements OnChanges {
  @Input() graph2 = '';
  calender: string = 'Day';
  fullscreenIconClass = 'fa fa-expand-arrows-alt';
  isFullscreen = false;
  document: any;
  fullscreen_bol: boolean = false;
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  loading: boolean = true;
  heights: string = '100%';
  heights2: string = '100%';
  dateLables: any = [];
  dateocupancy: any = [];
  dateocupancy2: any = [];
  @ViewChild('fullScreen') divRef;
  systemTimezone:any;
  constructor(private datepipe: DatePipe) {
    this.document = window.document;
    this.systemTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.loading = true;
      this.dateLables = [];
      this.dateocupancy = [];
      this.dateocupancy2 = [];
    if(changes.graph2.currentValue != undefined || null){
    this.dateocupancy = changes.graph2.currentValue;
     if(this.dateocupancy !=0){
      for (let dateTime of  this.dateocupancy) {
        this.dateLables.push(this.datepipe.transform(dateTime.entryDate, 'MMM d','UTC'));
        this.dateocupancy2.push(dateTime.penalty);
      };
      this.graphsbydate();
    }
    this.loading = false;
  }
  }
  graphsbydate(){
    console.log(this.dateLables, this.dateocupancy2)
    this.linechartOptions = {
      chart: {
        type: 'column',
        zooming: { type: 'x' },
        height: (10.5 / 23.2 * 100) + '%'
    },
    title: {
        text: ''
    },
    credits: {
      text: '',
      href: '',
    },
    subtitle: {
        text: ''
    },
    accessibility: {
      enabled: false,
    },
    xAxis: {
        type: 'category',
        categories: [...this.dateLables],
        gridLineWidth: 0.5,
        lineWidth: 0,
        lineColor: 'transparent',
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    yAxis: {
      gridLineWidth: 0.5,
        title: {
            text: ''
        },
        labels: {
          enabled: true,
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    legend: {
        enabled: false
    },
    plotOptions: {
      column: {
        pointPadding: 0.2,
        borderWidth: 0,
        pointWidth: 25
    },
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: false,
            },
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span>{point.name}</span> <b>{point.y} USD</b><br/>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
        style :{
          color: '#000',
          fontWeight: '600',
          fontFamily: '"Roboto", sans-serif',
        }
    },

    series: [
        {
           type : 'column',
            name: 'Penalty Charges',
            colorByPoint: false,
            data: [...this.dateocupancy2],
            color: '#15b695'
        }
    ],
}
}
  openFullscreen() {
    if (this.fullscreen_bol == false) {
      this.heights = '';
      let elem = this.divRef.nativeElement;
      let methodToBeInvoked =
        elem.requestFullscreen ||
        elem.webkitRequestFullScreen ||
        elem['mozRequestFullscreen'] ||
        elem['msRequestFullscreen'];
      console.log(methodToBeInvoked);
      if (methodToBeInvoked) methodToBeInvoked.call(elem);
      this.fullscreen_bol = true;
      this.heights = 'calc(100vh - 100px)';
    } else if (this.fullscreen_bol == true) {
      this.heights = '';
      const document: any = window.document;
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
      this.fullscreen_bol = false;
    }
  }
  toggleFullscreen() {
    if (!this.isFullscreen) {
      this.enterFullscreen();
    } else {
      this.exitFullscreen();
    }
  }
  enterFullscreen() {
    this.isFullscreen = true;
    this.fullscreenIconClass = 'fa fa-compress-arrows-alt';
    this.document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.addEventListener('keydown', this.handleEscKey);
  }
  exitFullscreen() {
    this.isFullscreen = false;
    this.fullscreenIconClass = 'fa fa-expand-arrows-alt';
    this.document.removeEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.removeEventListener('keydown', this.handleEscKey);
  }

  handleFullscreenChange = () => {
    if (!this.document.fullscreenElement && !this.document.webkitFullscreenElement &&
        !this.document.mozFullScreenElement && !this.document.msFullscreenElement) {
      this.exitFullscreen();
      this.openFullscreen();
    }
  }
  handleEscKey = (event: KeyboardEvent) => {
    if (event.key === 'Escape') this.exitFullscreen();
    this.openFullscreen();
  }
}
