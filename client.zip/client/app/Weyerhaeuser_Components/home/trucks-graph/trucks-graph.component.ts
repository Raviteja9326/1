import { DatePipe } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-trucks-graph',
  templateUrl: './trucks-graph.component.html',
  styleUrls: ['./trucks-graph.component.scss']
})
export class TrucksGraphComponent implements OnChanges {
  @Input() graph = '';
  fullscreenIconClass = 'fa fa-expand-arrows-alt';
  isFullscreen = false;
  document: any;
  calender: string = 'Day';
  fullscreen_bol: boolean = false;
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  loading: boolean = true;
  heights: string = '100%';
  heights2: string = '100%';
  dateLables: any = [];
  dateocupancy: any = [];
  @ViewChild('fullScreen') divRef;
  thirtymins = [];
  sixtymins = [];
  nintyymins = [];
  hunmins = [];
  systemTimezone:any;
  constructor(private datepipe: DatePipe) {
    this.document = window.document;
    this.systemTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.loading = true;
      this.dateLables = [];
      this.dateocupancy = [];
      this.thirtymins=[];
      this.sixtymins=[];
      this.nintyymins=[];
      this.hunmins=[];
    if(changes.graph.currentValue != undefined || null){
    this.dateocupancy = changes.graph.currentValue;
     if(this.dateocupancy !=0){
      this.dateocupancy.map(res=> {
        this.dateLables.push(this.datepipe.transform(res.entryDate, 'MMM d','UTC'));
        this.thirtymins?.push({y:res['PARKING'],count:res['PARKINGCOUNT']});
        this.sixtymins?.push({y:res['LOADING'],count:res['LOADINGCOUNT']});
        this.nintyymins?.push({y:res['TARPING'],count:res['TARPINGCOUNT']});
      });
      this.graphsbydate();
    }
    this.loading = false;
  }
  }
  graphsbydate(){
    this.linechartOptions = {
      chart: {
        type: 'column',
        zooming: { type: 'x' },
        height: (10.5 / 23.2 * 100) + '%'
    },
    accessibility: {
      enabled: false,
    },
    credits: {
      text: '',
      href: '',
    },
    title: {
      text: ''
    },
    subtitle: {
      text: ''
    },
    xAxis: {
      gridLineWidth: 0.5,
      lineWidth: 0,
      lineColor: 'transparent',
        categories: [...this.dateLables],
        crosshair: true,
        labels:{
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    yAxis: {
       gridLineWidth: 0.5,
        min: 0,
        tickInterval: 100,
        title: {
            text: '',
            style:{
              color: '#000',
              fontWeight: '600',
              fontFamily: "'Open Sans', sans-serif",
            },
        },
        labels: {
          style: {
              color: '#000',
              fontWeight: '600',
              fontFamily: "'Open Sans', sans-serif",
          }
        }
    },
    tooltip: {
      style: {
        color: '#000',
        fontWeight: '600',
        fontFamily: "'Open Sans', sans-serif"
    },
    headerFormat: '<span style="font-size:13px; font-weight:600; margin-bottom:5px">{point.x} Avg Waiting Time Trend</span><table>',
    pointFormat: '<tr><td style="color:{series.color};padding:2px;font-weight:600">{series.name} : </td>' +
        '<td style="padding:2px">{point.y} Mins</td></tr>'
        +'<tr><td style="color:{series.color};padding:2px;font-weight:600">{series.name} Vehicle Count:</td><td style="padding:2px">{point.count}</td></tr>',
    footerFormat: '</table>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
    },
    legend: {
      enabled: true,
      align: 'center',
      verticalAlign: 'bottom',
      layout: 'horizontal',
      x: 0,
      y: 25,
      floating: false,
      itemMarginTop: 5,
      itemMarginBottom: 5,
      itemStyle: {
        lineHeight: '10px'
      }
    },
    plotOptions: {
        column: {
          stacking: 'normal',
          pointPadding: 0.2,
          borderWidth: 0,
          pointWidth: 25
        }
    },
    series: [ {
      type: 'column',
      name: 'Parking',
      color: '#07bb82',
      data: [...this.thirtymins]
    }, {
      type: 'column',
      name: 'Loading',
      color: '#0da4eb',
      data: [...this.sixtymins]
    }, {
      type: 'column',
      name: 'Tarping',
      color: '#ffa042',
      data: [...this.nintyymins]
    }]
    }
  }
  openFullscreen() {
    if (this.fullscreen_bol == false) {
      this.heights = '';
      let elem = this.divRef.nativeElement;
      let methodToBeInvoked =
        elem.requestFullscreen ||
        elem.webkitRequestFullScreen ||
        elem['mozRequestFullscreen'] ||
        elem['msRequestFullscreen'];
      console.log(methodToBeInvoked);
      if (methodToBeInvoked) methodToBeInvoked.call(elem);
      this.fullscreen_bol = true;
      this.heights = 'calc(100vh - 100px)';
    } else if (this.fullscreen_bol == true) {
      this.heights = '';
      const document: any = window.document;
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
      this.fullscreen_bol = false;
    }
  }
  toggleFullscreen() {
    if (!this.isFullscreen) {
      this.enterFullscreen();
    } else {
      this.exitFullscreen();
    }
  }
  enterFullscreen() {
    this.isFullscreen = true;
    this.fullscreenIconClass = 'fa fa-compress-arrows-alt';
    this.document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.addEventListener('keydown', this.handleEscKey);
  }
  exitFullscreen() {
    this.isFullscreen = false;
    this.fullscreenIconClass = 'fa fa-expand-arrows-alt';
    this.document.removeEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.removeEventListener('keydown', this.handleEscKey);
  }

  handleFullscreenChange = () => {
    if (!this.document.fullscreenElement && !this.document.webkitFullscreenElement &&
        !this.document.mozFullScreenElement && !this.document.msFullscreenElement) {
      this.exitFullscreen();
      this.openFullscreen();
    }
  }
  handleEscKey = (event: KeyboardEvent) => {
    if (event.key === 'Escape') this.exitFullscreen();
    this.openFullscreen();
  }
}
