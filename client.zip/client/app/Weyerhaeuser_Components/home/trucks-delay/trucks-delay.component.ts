import { DatePipe } from '@angular/common';
import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { LandModalComponent } from 'client/app/modals/land-modal/land-modal.component';
import { HomeService } from 'client/app/services/home.service';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-trucks-delay',
  templateUrl: './trucks-delay.component.html',
  styleUrls: ['./trucks-delay.component.scss']
})
export class TrucksDelayComponent implements OnChanges, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  @Input() allData: any;
  allDatas: any;
  @Input() minmax:any;
  loading:boolean = true;
  items = ['type-1', 'type-2', 'type-3','type-4'];
  ngOnChanges(changes: SimpleChanges) {
    if(changes.minmax?.currentValue != undefined || null){
      console.log(this.minmax)
      this.loading = false;
    }
    else if (changes.allData?.currentValue.dateend != undefined || null) {
      this.allDatas = this.allData
    }
  }
  constructor(public dialog: MatDialog, private landserv: HomeService, private route: Router, private datepipe: DatePipe, private toastr: ToastrService, private ngxService: NgxUiLoaderService) {}
  async getMaster_details(data) {
    console.log(data)
    let obj = {};
    obj['facilityId'] = this.allDatas.userdata;
    obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj['from_date'] = this.allDatas.datestart,
    obj['to_date'] = this.allDatas.dateend,
    obj['type']= "nearlyCrossed";
    if(data.bayName.toLowerCase() == "turn around"){
      obj['status']= 'exit';
    }
    else if(data.bayName.toLowerCase() != "turn around"){
      obj['status']= data.bayName.toLowerCase() +' ' +'in';
    }

     await this.landserv.getind(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          this.truck_Modal(data,res.data);
          this.ngxService.stop();
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
          this.ngxService.stop();
        }
      })
  }
  truck_Modal(data,data2): void {
    console.log(data, data2)
    const TrucksData: string = data;
    const TrucksData9: any = data2;
    this.ngxService.start();
    this.dialog.open(LandModalComponent, {
      width: '100%',
      height:'auto',
      data: {TrucksData,TrucksData9},
      disableClose: false,
      autoFocus: false,
      position: {
        top:'20px'
      }
    });
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
