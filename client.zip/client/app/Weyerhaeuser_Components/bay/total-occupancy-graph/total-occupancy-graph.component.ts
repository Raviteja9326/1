import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts';
import { ActivatedRoute } from '@angular/router';
import { DaterangepickerDirective } from 'ngx-daterangepicker-material';
import * as moment from 'moment';
import 'moment-timezone';
@Component({
  selector: 'app-total-occupancy-graph',
  templateUrl: './total-occupancy-graph.component.html',
  styleUrls: ['./total-occupancy-graph.component.scss'],
})
export class TotalOccupancyGraphComponent implements OnChanges, OnInit {
  @Input() graph = '';
  fullscreenIconClass = 'fa fa-expand-arrows-alt';
  isFullscreen = false;
  document: any;
  @Output() dataEvent = new EventEmitter<any>();
  calender: string = 'Day';
  fullscreen_bol: boolean = false;
  Highcharts: typeof Highcharts = Highcharts;
  linechartOptions: Highcharts.Options;
  loading: boolean = true;
  heights: string = '100%';
  heights2: string = '100%';
  dateLables: any = [];
  dateocupancy: any = [];
  @ViewChild('fullScreen') divRef;
  thirtymins = [];
  sixtymins = [];
  nintyymins = [];
  hunmins = [];
  greater = [];
  ranges: any;
  selected: any;
  maxDate: any;
  minDate: any;
  datestart: any = '';
  dateend: any = '';
  timePickerFlag: boolean = true;
  clickedStart: any;
  clickedEnd: any;
  @ViewChild(DaterangepickerDirective) picker: DaterangepickerDirective;
  testdata: string;
  constructor(private datepipe: DatePipe, private router: ActivatedRoute) {
    this.loading = true;
    this.document = window.document;
    moment.tz.setDefault('America/New_York');
    this.showcoverstions();
  }
  showcoverstions(){
    const currentDateTime = moment();
    const estOffset = moment().tz('America/New_York').utcOffset();
    this.selected = {
      startDate: moment()?.hour(0).minute(0),
      endDate: currentDateTime
    };
    this.ranges = {
      'Today': [moment().utcOffset(estOffset).hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'Yesterday': [moment().utcOffset(estOffset).subtract(1, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).subtract(1, 'days').endOf('day').hour(23).minute(59).format('YYYY-MM-DD HH:mm')],
  'Last 7 Days': [moment().utcOffset(estOffset).subtract(6, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'Last 30 Days': [moment().utcOffset(estOffset).subtract(29, 'days').startOf('day').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).format('YYYY-MM-DD HH:mm')],
  'This Month': [moment().utcOffset(estOffset).startOf('month').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).endOf('month').format('YYYY-MM-DD HH:mm')],
  'Last Month': [moment().utcOffset(estOffset).subtract(1, 'month').startOf('month').hour(0).minute(0).format('YYYY-MM-DD HH:mm'), moment().utcOffset(estOffset).subtract(1, 'month').endOf('month').format('YYYY-MM-DD HH:mm')]
    };
    this.maxDate = currentDateTime.format('YYYY-MM-DD HH:mm');
  }
  formatDates() {
    try{
    const formattedStartDate = this.selected.startDate.format('YYYY-MM-DD HH:mm');
    const formattedEndDate = this.selected.endDate.format('YYYY-MM-DD HH:mm');
    this.selected.startDate = formattedStartDate;
    this.selected.endDate = formattedEndDate;}
    catch(e){

    }
  }
  onDateRangeChanged() {
  const estOffset = moment().tz('America/New_York').utcOffset();
 //check if today
    try{if(this.selected.endDate.format("YYYY-MM-DD")!=moment().utcOffset(estOffset).format("YYYY-MM-DD")){
      this.selected = {
        startDate:this.selected.startDate,
        endDate: this.selected.endDate.hour(23).minute(59)
      }
    }
    }
    catch(e){

    }
    this.formatDates();
    this.datestart = this.selected.startDate;
    this.dateend = this.selected.endDate;
    this.dataEvent.emit({ startDate: this.datestart, endDate: this.dateend});
  }
  getRoutes() {
    this.router.paramMap.subscribe(params => {
      if (params.get('id') != "no") {
        this.testdata = params.get('id');
        const currentDateTime = moment();
        this.selected = {
          startDate: moment()?.hour(0).minute(0),
          endDate: currentDateTime
        };
      }
    });
  }
  ngOnInit(): void {
    this.getRoutes();
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.dateLables = [];
    this.dateocupancy = [];
    this.thirtymins=[];
    this.sixtymins=[];
    this.nintyymins=[];
    this.hunmins=[];
    this.greater=[];
    if(changes.graph.currentValue != undefined || null){
    this.dateocupancy = changes.graph.currentValue;
    console.log(this.dateocupancy)
     if(this.dateocupancy.length !=0){
      this.dateocupancy.map(res=> {
        this.dateLables.push(this.datepipe.transform(res.entrydate, 'MMM d','UTC'));
        if(this.testdata == "Loading"){
          this.thirtymins?.push(res['15 min']);
          this.sixtymins?.push(res['30 min']);
          this.nintyymins?.push(res['45 min']);
          this.hunmins?.push(res['> 45 min']);
        }
        else if(this.testdata != "Loading"){
          this.thirtymins?.push(res['30 min']);
          this.sixtymins?.push(res['60 min']);
          this.nintyymins?.push(res['90 min']);
          this.hunmins?.push(res['120 min']);
          this.greater?.push(res['> 120 min']);
        }
      });
      this.graphsbydate();
    }
    this.loading = false;
  }
  }
  // setMaxDate(){
  // let currentDate = new Date();
  // currentDate.setHours(23);
  // currentDate.setMinutes(59);
  // currentDate.setSeconds(59);
  // currentDate.toISOString();
  // this.maxDate  = dayjs(currentDate);
  // }
  graphsbydate(){
    if(this.testdata != "Loading"){
    this.linechartOptions = {
      chart: {
        type: 'column',
        backgroundColor: '#fff',
        zooming: { type: 'x' },
        height: (9.5 / 23.2 * 100) + '%'
    },
    accessibility: {
      enabled: false,
    },
    credits: {
      text: '',
      href: '',
    },
    title: {
      text: ''
    },
    subtitle: {
      text: ''
    },
    xAxis: {
      gridLineWidth: 0.5,
      lineWidth: 0,
      lineColor: 'transparent',
        categories: [...this.dateLables],
        crosshair: true,
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    yAxis: {
      gridLineWidth: 0.5,
        min: 0,
        tickInterval: 10,
        title: {
          text: '',
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          },
        },
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          }
        }
      },
      tooltip: {
        style: {
          color: '#000',
          fontWeight: '600',
          fontFamily: "'Open Sans', sans-serif"
        },
        headerFormat: '<span style="font-size:12px; font-weight:600">{point.key} Truck Count</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0;font-weight:600">{series.name}: </td>' +
          '<td style="padding:0;"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        x: 0,
        y: 25,
        floating: false,
        itemMarginTop: 5,
        itemMarginBottom: 5,
        itemStyle: {
          lineHeight: '10px'
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          pointPadding: 0.2,
          borderWidth: 0,
          pointWidth: 25,
        }
    },
    series: [{
      type: 'column',
      name: '30 Mins',
      color: '#07bb82',
      data: [...this.thirtymins]
    }, {
      type: 'column',
      name: '60 Mins',
      color: '#0da4eb',
      data: [...this.sixtymins]
    }, {
      type: 'column',
      name: '90 Mins',
      color: '#ffa042',
      data: [...this.nintyymins]
    }, {
      type: 'column',
      name: '120 Mins',
      color: '#000',
      data: [...this.hunmins]
    }, {
      type: 'column',
      name: '>120 Mins',
      color: '#fd5757',
      data: [...this.greater]
    }
  ]
    }
  }
 else if(this.testdata == "Loading"){
    this.linechartOptions = {
      chart: {
        type: 'column',
        backgroundColor: '#fff',
        zooming: { type: 'x' },
        height: (9.5 / 23.2 * 100) + '%'
    },
    accessibility: {
      enabled: false,
    },
    credits: {
      text: '',
      href: '',
    },
    title: {
      text: ''
    },
    subtitle: {
      text: ''
    },
    xAxis: {
      gridLineWidth: 0.5,
      lineWidth: 0,
      lineColor: 'transparent',
        categories: [...this.dateLables],
        crosshair: true,
        labels:{
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: '"Roboto", sans-serif',
          },
        }
    },
    yAxis: {
      gridLineWidth: 0.5,
        min: 0,
        tickInterval: 10,
        title: {
            text: '',
            style:{
              color: '#000',
              fontWeight: '600',
              fontFamily: "'Open Sans', sans-serif",
            },
        },
        labels: {
          style: {
              color: '#000',
              fontWeight: '600',
              fontFamily: "'Open Sans', sans-serif",
          }
        }
    },
    tooltip: {
      style: {
        color: '#000',
        fontWeight: '600',
        fontFamily: "'Open Sans', sans-serif"
    },
        headerFormat: '<span style="font-size:12px; font-weight:600">{point.key} Truck Count</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0;font-weight:600">{series.name}: </td>' +
            '<td style="padding:0;"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
    },
    legend: {
      enabled: true,
      align: 'center',
      verticalAlign: 'bottom',
      layout: 'horizontal',
      x: 0,
      y: 25,
      floating: false,
      itemMarginTop: 5,
      itemMarginBottom: 5,
      itemStyle: {
        lineHeight: '10px'
      }
    },
    plotOptions: {
        column: {
          stacking: 'normal',
          pointPadding: 0.2,
          borderWidth: 0,
          pointWidth: 25,
        }
    },
    series: [{
      type: 'column',
      name: '15 Mins',
      color: '#07bb82',
      data: [...this.thirtymins]
    }, {
      type: 'column',
      name: '30 Mins',
      color: '#0da4eb',
      data: [...this.sixtymins]
    }, {
      type: 'column',
      name: '45 Mins',
      color: '#ffa042',
      data: [...this.nintyymins]
    }, {
      type: 'column',
      name: '>45 Mins',
      color: '#000',
      data: [...this.hunmins]
    }
  ]
    }
  }
  }
  // rangeClicked(event) {
  //   console.log(this.selected)
  //   if(event.startDate != null){
  //   this.timePickerFlag = true;
  //   this.getTimepickerStatus(this.selected);
  //   this.dataEvent.emit(this.selected);
  //   this.clickedStart = "";
  //   }
  // }
  openFullscreen() {
    if (this.fullscreen_bol == false) {
      this.heights = '';
      let elem = this.divRef.nativeElement;
      let methodToBeInvoked =
        elem.requestFullscreen ||
        elem.webkitRequestFullScreen ||
        elem['mozRequestFullscreen'] ||
        elem['msRequestFullscreen'];
      console.log(methodToBeInvoked);
      if (methodToBeInvoked) methodToBeInvoked.call(elem);
      this.fullscreen_bol = true;
      this.heights = 'calc(100vh - 100px)';
    } else if (this.fullscreen_bol == true) {
      this.heights = '';
      const document: any = window.document;
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
      this.fullscreen_bol = false;
    }
  }
  // getTimepickerStatus(event){
  //   let start = event?.startDate;
  //   let end = event?.endDate;
  //   //console.log(start>end);
  //   try{
  //     if(start>end){
  //       end = event.endDate.add(1,"d");
  //     }
  //   }
  //   catch(e){

  //   }
  //   try{
  //     if(start.diff(dayjs().hour(0).minute(0),"d",true)<0 || end.diff(dayjs().hour(0).minute(0),"d",true)<0){

  //     this.timePickerFlag = false;

  //     let start1 = this.datepipe.transform(start,"MM-dd-yyyy",'UTC');
  //     let end1 = this.datepipe.transform(end,"MM-dd-yyyy",'UTC');
  //     let yesterday_start = (((dayjs().subtract(1, 'days').get('M'))+1)>10?((dayjs().subtract(1, 'days').get('M'))+1):("0"+(dayjs().subtract(1, 'days').get('M')+1)))
  //     +"-"+(dayjs().subtract(1, 'days').get('D')>10?dayjs().subtract(1, 'days').get('D'):"0"+dayjs().subtract(1, 'days').get('D'))
  //     +"-"+dayjs().subtract(1, 'days').get('y');

  //     if(start1!=yesterday_start && end1!=yesterday_start){
  //     this.selected = {
  //       startDate:dayjs(event.startDate.hour(0).minute(0)),
  //       endDate:dayjs(event.endDate.hour(0).minute(0))
  //     }}
  //     else{
  //       this.selected = {
  //         startDate:dayjs(event.startDate.hour(0).minute(0)),
  //         endDate:dayjs(event.endDate.hour(23).minute(59))
  //       }
  //     }


  //      const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].add("disableClass");
  //      collection[1]['classList'].add("disableClass");
  //     // collection[0]["style"].display = "none";
  //     // collection[1]["style"].display = "none";
  //     // this.selected.startDate = dayjs(event.startDate.hour(0).minute(0));
  //     // this.selected.endDate = dayjs(event.endDate.hour(0).minute(0));

  //   }
  //   else{
  //     this.timePickerFlag = true;
  //      const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].remove("disableClass");
  //      collection[1]['classList'].remove("disableClass");
  //     // collection[0]["style"].display = "block";
  //     // collection[1]["style"].display = "block";
  //     // this.selected.startDate = dayjs(event.startDate);
  //     // this.selected.endDate = dayjs(event.endDate);
  //     this.selected = {
  //       startDate:dayjs(event.startDate),
  //       endDate:dayjs(event.endDate)
  //     }
  //   }}
  //   catch(e){

  //   }
  // }

  // startDateChange(event){
  //   this.clickedStart = event.startDate;
  //   console.log(event?.startDate.diff(dayjs(),"d",true));
  //   try{if(event?.startDate.diff(dayjs().hour(0).minute(0),"d",true)<0){
  //     this.timePickerFlag = false;
  //     const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].add("disableClass");
  //      collection[1]['classList'].add("disableClass");
  //     // collection[0]["style"].display = "none";
  //     // collection[1]["style"].display = "none";
  //   }
  //   else{
  //     this.timePickerFlag = true;
  //     const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].remove("disableClass");
  //      collection[1]['classList'].remove("disableClass");
  //     // collection[0]["style"].display = "block";
  //     // collection[1]["style"].display = "block";
  //   }}
  //   catch(e){}
  // }
  // endDateChange(event){
  //   try{
  //   if(this.clickedStart){
  //   if(this.clickedStart.diff(dayjs().hour(0).minute(0),"d",true)<0){
  //     this.timePickerFlag = false;
  //     const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].add("disableClass");
  //      collection[1]['classList'].add("disableClass");
  //     // collection[0]["style"].display = "none";
  //     // collection[1]["style"].display = "none";
  //   }
  //   else{
  //     this.timePickerFlag = true;
  //     const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].remove("disableClass");
  //      collection[1]['classList'].remove("disableClass");
  //     // collection[0]["style"].display = "block";
  //     // collection[1]["style"].display = "block";
  //   }}
  //   else{
  //     const collection = document.getElementsByClassName("calendar-time");
  //      collection[0]['classList'].add("disableClass");
  //      collection[1]['classList'].add("disableClass");
  //     // collection[0]["style"].display = "none";
  //     // collection[1]["style"].display = "none";
  //   }}
  //   catch(e){
  //     console.log("class not found");
  //   }
  // }
  toggleFullscreen() {
    if (!this.isFullscreen) {
      this.enterFullscreen();
    } else {
      this.exitFullscreen();
    }
  }
  enterFullscreen() {
    this.isFullscreen = true;
    this.fullscreenIconClass = 'fa fa-compress-arrows-alt';
    this.document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.addEventListener('keydown', this.handleEscKey);
  }
  exitFullscreen() {
    this.isFullscreen = false;
    this.fullscreenIconClass = 'fa fa-expand-arrows-alt';
    this.document.removeEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.removeEventListener('keydown', this.handleEscKey);
  }

  handleFullscreenChange = () => {
    if (!this.document.fullscreenElement && !this.document.webkitFullscreenElement &&
        !this.document.mozFullScreenElement && !this.document.msFullscreenElement) {
      this.exitFullscreen();
      this.openFullscreen();
    }
  }
  handleEscKey = (event: KeyboardEvent) => {
    if (event.key === 'Escape') this.exitFullscreen();
    this.openFullscreen();
  }
}
