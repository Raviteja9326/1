import { BayMasterService } from 'client/app/services/bay-master.service';
import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ParkingyardService } from 'client/app/services/parkingyard.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import 'moment-timezone';
@Component({
  selector: 'app-bay',
  templateUrl: './bay.component.html',
  styleUrls: ['./bay.component.scss'],
})
export class BayComponent implements OnInit, OnDestroy, AfterViewInit {
  private readonly _destroying$ = new Subject<void>();
  userDetail: any;
  bayId: any;
  currentDate = new Date();
  menus: string;
  menus2: string;
  alramCount: number = 0;
  TruckCount: any;
  avgCount: any;
  slotavg: any;
  graph: any;
  graph2: any;
  from_date: any;
  to_date: any;
  selected: any;
  timeTable: any;
  pageIndex: number = 1;
  pageSize: number = 20;
  filter: any;
  search: any = "";
  sortColumn: any;
  sortOrder: any;
  intervalId = null;
  datestart: any = '';
  dateend: any = '';
  systemTimezone:any;
  constructor(private userser: StorageService, private route: Router, private parkingyard: ParkingyardService, private Bay_cust: BayMasterService, private toastr: ToastrService, private datePipe: DatePipe,private router: ActivatedRoute) {
    this.systemTimezone = "America/New_York";
    this.showcoverstions();
   }
   showcoverstions(){
    const currentDateTime = moment();
    this.selected = {
      startDate: moment().tz(this.systemTimezone).startOf('day'),
      endDate: currentDateTime.tz(this.systemTimezone)
    };
  }
  formatDates() {
    const formattedStartDate = this.selected.startDate.format('YYYY-MM-DD HH:mm');
    const formattedEndDate = this.selected.endDate.format('YYYY-MM-DD HH:mm');
    this.selected.startDate = formattedStartDate;
    this.selected.endDate = formattedEndDate;
  }
  onDateRangeChanged() {
    this.formatDates();
    this.datestart = this.selected.startDate;
    this.dateend = this.selected.endDate;
    console.log(this.datestart, this.dateend)
  }
  ngOnInit(): void {
    this.getUserDetails();
  }
  ngAfterViewInit(): void {
    this.intervalId = setInterval(()=>{
      this.getUserDetails();
     },60000)
   }
  getUserDetails() {
    this.userDetail = this.userser.getvariable();
    this.getRoutes();
    this.onDateRangeChanged();
  }
  getRoutes() {
    this.router.paramMap.subscribe(params => {
      console.log('jjjjjjj',params)
      if (params.get('id') == "Parking") {
        this.menus = 'PARKING';
        this.menus2 = 'Parking In';
        this.getbay_Master();
        clearInterval(this.intervalId);
      }
      else if (params.get('id') == "Loading") {
        this.menus = 'LOADING';
        this.menus2 = 'Loading In';
        this.getbay_Master();
        clearInterval(this.intervalId);
      }
      else if (params.get('id') == "Tarping") {
        this.menus = 'TARPING';
        this.menus2 = 'Tarping In';
        this.getbay_Master();
        clearInterval(this.intervalId);
      }
    });
  }
  async getbay_Master() {
    console.log("databayid", this.userDetail)
    this.bayId = '';
    const timedate = {};
    timedate['time'] = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd HH:mm:ss');
    timedate['stamp'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
      this.Bay_cust.getbay(timedate).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          console.log(res)
          res.elements.map(data => {
            data.map(data2 => {
              if (data2.facilityId == this.userDetail && data2.bayName == this.menus) {
                this.bayId = data2.bayId;
                console.log('sssssssssssssss',this.bayId)
              }
            })
          });
          this.getDashboardDetails();
          this.getDashboardGraph2();
          this.receiveData({ startDate: this.datestart, endDate: this.dateend });
          this.pageIndex = 1;
          this.pageSize = 20;
          const obj = {};
          this.pageIndex = 1;
          this.pageSize = 20;
          obj['pageindex'] = this.pageIndex;
          obj['pagesize'] = this.pageSize;
           this.receiveData2(obj)
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      })
  }
  async getDashboardDetails() {
    let obj = {};
    obj['facilityId'] = this.userDetail;
    obj['bayId'] = this.bayId;
    obj['status'] = this.menus2,
      obj['date'] =  this.datePipe.transform(this.currentDate, 'yyyy-MM-dd'),
      obj['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
       this.parkingyard.getdashboardDetails2(obj).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          this.alramCount = res.alertCount;
          this.avgCount = res.avgWaitingTime;
          this.slotavg = res.occupancyPercentage;
          this.TruckCount = { 'truckCount': res.truckCount, 'remaining': res.remaining };
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async getDashboardtable() {
    let obj2 = {};
    obj2['facilityId'] = this.userDetail;
    obj2['bayId'] = this.bayId;
    obj2['status'] = this.menus2,
    obj2['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj2['date'] = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd'),
    obj2['page'] = this.pageIndex,
    obj2['page_size'] = this.pageSize,
    obj2['filter'] = this.filter;
    obj2['search'] = this.search;
    obj2['sortColumn'] = this.sortColumn;
    obj2['sortOrder'] = this.sortOrder;
     this.parkingyard.getdashboardList(obj2).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res) => {
        this.timeTable = res;
      }, error: (error) => {
        console.log("12312321312312")
        this.toastr.error(error.error.message)
        this.route.navigate(['/dashboard/errors']);
      }
    });
  }
  async getDashboardGraph() {
    this.graph = [];
    let obj3 = {};
    obj3['facilityId'] = this.userDetail;
    obj3['filter'] = 'day',
    obj3['chart_type'] = 'truck_count',
    obj3['bayId'] = this.bayId;
    obj3['status'] = this.menus2,
    obj3['time'] = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd HH:mm:ss');
    obj3['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj3['from_date'] =  this.from_date,
    obj3['to_date'] = this.to_date,
       this.parkingyard.getGraph(obj3).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          console.log(res.elements)
          if (res.elements.length != 0) {
            this.graph = res.elements;
            this.from_date = '';
            this.to_date = '';
          }
          else if (res.elements.length == 0) {
            this.graph = [];
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  async getDashboardGraph2() {
    this.graph = [];
    let obj3 = {};
    obj3['facilityId'] = this.userDetail;
    obj3['filter'] = 'day',
      obj3['chart_type'] = 'max_waiting_time',
      obj3['bayId'] = this.bayId,
    obj3['status'] = this.menus2,
      obj3['time'] = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd HH:mm:ss'),
    obj3['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
    obj3['from_date'] = this.datestart,
    obj3['to_date'] = this.dateend,
       this.parkingyard.getGraph(obj3).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          console.log(res.elements)
          if (res.elements.length != 0) {
            this.graph2 = res.elements;
            this.from_date = '';
            this.to_date = '';
          }
          else if (res.elements.length == 0) {
            this.graph2 = [];
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
          this.route.navigate(['/dashboard/errors']);
        }
      });
  }
  receiveData(data: any) {
    console.log(data)
    if(this.bayId != ''){
      this.from_date = data.startDate;
      this.to_date = data.endDate;
     this.getDashboardGraph();
    }
  }
  receiveData2(data: any) {
    this.pageIndex = data?.pageindex;
    this.pageSize = data?.pagesize;
    this.filter = data?.filter;
    this.search = data?.search;
    this.sortColumn = data?.sortColumn;
    this.sortOrder = data?.sortOrder;
    this.getDashboardtable();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    clearInterval(this.intervalId);
  }
}
