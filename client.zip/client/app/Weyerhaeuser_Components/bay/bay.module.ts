import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AlarmsComponent } from './alarms/alarms.component';
import { SlotsComponent } from './slots/slots.component';
import { TimeEvaluationComponent } from './time-evaluation/time-evaluation.component';
import { FacilityMapComponent } from './facility-map/facility-map.component';
import { TotalOccupancyGraphComponent } from './total-occupancy-graph/total-occupancy-graph.component';
import { TimeCountComponent } from './time-count/time-count.component';
import { AllModule } from 'client/app/shared/all_modules';
import { BayComponent } from './bay.component';
import { BayRoutingModule } from './bay-routing.module';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { TotalMaxGraphComponent } from './total-max-graph/total-max-graph.component';
import { TotaltrucksComponent } from './totaltrucks/totaltrucks.component';

@NgModule({
  declarations: [
    BayComponent,
    AlarmsComponent,
    SlotsComponent,
    TimeEvaluationComponent,
    FacilityMapComponent,
    TotalOccupancyGraphComponent,
    TimeCountComponent,
    TotalMaxGraphComponent,
    TotaltrucksComponent
  ],
  imports: [
    CommonModule,
    BayRoutingModule,
    AllModule,
    NgxDaterangepickerMd.forRoot(),
  ],
  providers: [DatePipe]
})
export class BayModule { }
