import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { TrucklistModalComponent } from 'client/app/modals/trucklist-modal/trucklist-modal.component';
@Component({
  selector: 'app-totaltrucks',
  templateUrl: './totaltrucks.component.html',
  styleUrls: ['./totaltrucks.component.scss']
})
export class TotaltrucksComponent implements OnChanges, OnInit {
  @Input() TruckCount:any;
  slot_filled:number = 0;
  loading:boolean = true;
  slot_avable: number;
  menus: string;
  constructor(private router: ActivatedRoute, public dialog: MatDialog){}
ngOnInit(): void {
  this.router.paramMap.subscribe(params => {
    this.menus = '';
    if(params.get('id')=="Tarping"){
     this.menus = 'Tarping';
    }
    else if(params.get('id')=="Loading"){
     this.menus = 'Loading';
    }})
}
  ngOnChanges(changes: SimpleChanges) {
    if(changes.TruckCount.currentValue != undefined || null){
      this.slot_avable = changes.TruckCount.currentValue.remaining;
      this.slot_filled = changes.TruckCount.currentValue.truckCount;
      this.loading = false;
    }
  }
  truck_Modal(): void {
    const bayadd:any =  this.menus;
    this.dialog.open(TrucklistModalComponent, {
      width: '100%',
      maxWidth: '85vw',
      height:'auto',
      data: {bayadd},
      disableClose: false,
      autoFocus: false,
      position: {
        top:'20px'
      }
    });
  }
}
