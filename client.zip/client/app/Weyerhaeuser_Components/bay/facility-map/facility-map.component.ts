import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AlertAlarmModalComponent } from 'client/app/modals/alert-alarm-modal/alert-alarm-modal.component';

@Component({
  selector: 'app-facility-map',
  templateUrl: './facility-map.component.html',
  styleUrls: ['./facility-map.component.scss']
})
export class FacilityMapComponent{
  loading: boolean = true;
  @Input() alramCount: number = 0;
  @Input() menu: any="";
  constructor(public dialog: MatDialog){
    if(this.alramCount != undefined || null){
      this.loading = false;
    }
  }
  truck_Modal(): void {
    const bayadd:string = this.menu;
    this.dialog.open(AlertAlarmModalComponent, {
      width: '100%',
      height:'auto',
      data: {bayadd},
      disableClose: false,
      autoFocus: false,
      position: {
        top:'20px'
      }
    });
  }

}
