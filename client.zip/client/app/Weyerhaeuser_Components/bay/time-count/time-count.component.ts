import { Component } from '@angular/core';
@Component({
  selector: 'app-time-count',
  templateUrl: './time-count.component.html',
  styleUrls: ['./time-count.component.scss']
})
export class TimeCountComponent {
  public now = new Date();
  loading: boolean = true;
  constructor() {
    this.loading = false
}
}
