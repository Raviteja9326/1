import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ActivatedRoute } from '@angular/router';
import dayjs from 'dayjs/esm';
@Component({
  selector: 'app-time-evaluation',
  templateUrl: './time-evaluation.component.html',
  styleUrls: ['./time-evaluation.component.scss']
})
export class TimeEvaluationComponent implements OnInit {
  @Input() timeTable = '';
  @Output() dataTable = new EventEmitter<any>();
  dataSource: any;
  result: any;
  largeScreen: string = 'max-heght_table5';
  opt_screen: string;
  displayNoRecords: boolean = true;
  fullscreenIconClass = 'fa fa-expand-arrows-alt';
  isFullscreen = false;
  document: any;
  _value: any;
  pageIndex: number = 1;
  pageSize: number = 20;
  currentPage: number = 1;
  labels: any = {
    previousLabel: 'Prev',
    nextLabel: 'Next',
  };
  totalItems: number;
  ELEMENT_DATA: any;
  loading: boolean = false;
  fullscreen_bol: boolean = false;
  id: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild('fullScreen') divRef;
  displayedColumns: string[] = [
    "Sr.No.",
    "vehicleLicence",
    "incomingTime",
    "waitingTime",
    "outgoingTime"
  ];
  searchFilterFlags: any = {
    vehicleLicence: false,
    incomingTime: false,
    waitingTime: false,
    outgoingTime: false
  }
  searchParameters: any = {
    vehicleLicence: "",
    incomingTime: "",
    waitingTime: "",
    outgoingTime: ""
  }
  sortParameters: any = {
    vehicleLicence: "",
    incomingTime: "",
    waitingTime: "",
    outgoingTime: ""
  }
  sortOrder: any = "";
  sortColumn: any = "";
  constructor(private datepipe: DatePipe, private router: ActivatedRoute, private datePipe: DatePipe) {this.document = window.document}
  ngOnInit(): void {
    this.router.paramMap.subscribe(params => {
      this.id = params.get('id');
      let pageSize = 20;
      let pageIndex = 1;
      if (params.get('id') == "Tarping") {
        this.initializeSearch();
        this.initializePaginator();
        //this.getdynamicdata(pageIndex, pageSize);
        this.largeScreen = 'max-heght_table5';
      }
      else if (params.get('id') == "Loading") {
        this.initializeSearch();
        this.initializePaginator();
        //this.getdynamicdata(pageIndex, pageSize);
        this.largeScreen = 'max-heght_table5';
      }
      else if (params.get('id') == "Parking") {
        this.initializeSearch();
        this.initializePaginator();
        //this.getdynamicdata(pageIndex, pageSize);
        this.largeScreen = 'max-heght_table';
      }
      this.loading = true;
      this._value = "";
      this.ELEMENT_DATA = [];
      this.dataSource = this.ELEMENT_DATA;
      this.displayNoRecords = true;
    })
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.timeTable?.currentValue?.elements?.length != 0) {
      this.ELEMENT_DATA = changes?.timeTable?.currentValue;
      this.displayNoRecords = false;
      this.dataSource = this.ELEMENT_DATA?.elements;
      setTimeout(() => {
        this.totalItems = this.ELEMENT_DATA?.metadata?.total;
        this.pageIndex = this.ELEMENT_DATA?.metadata?.current_page - 1;
      });
      this.loading = false;
    }
    else {
      this.ELEMENT_DATA = [];
      this.dataSource = this.ELEMENT_DATA;
      this.displayNoRecords = true;
      this.loading = false;
    }

  }
  initializePaginator() {
    this.currentPage = 1;
    this.pageSize = 20;
  }
  initializeSearch() {
    this.searchFilterFlags = {
      vehicleLicence: false,
      incomingTime: false,
      waitingTime: false,
      outgoingTime: false
    }
    this.searchParameters = {
      vehicleLicence: "",
      incomingTime: "",
      waitingTime: "",
      outgoingTime: ""
    }
    this.sortParameters = {
      vehicleLicence: "",
      incomingTime: "",
      waitingTime: "",
      outgoingTime: ""
    }
    this.sortOrder = "";
    this.sortColumn = "";
  }

  pageChanged(pageSize, currentPage) {
    console.log("sssssssssssssssssss")
    this.getdynamicdata(currentPage, pageSize);
  }

  getdynamicdata(currentPage, pageSize, columnObj?) {
      const obj = {};
      obj['pageindex'] = currentPage;
      obj['pagesize'] = pageSize;
      obj['filter'] = columnObj ? columnObj : null;
      obj['search'] = this._value;
      obj['sortColumn'] = this.sortColumn;
      obj['sortOrder'] = this.sortParameters[this.sortColumn];
      this.dataTable.emit(obj);
      this.loading = true;
  }

  // getdynamicdata2(currentPage, pageSize, columnObj?) {
  //   console.log("sssssssssssdsdsdsdsds",columnObj)
  //   if(currentPage != undefined || null || '' ){
  //     const obj = {};
  //     obj['pageindex'] = currentPage;
  //     obj['pagesize'] = pageSize;
  //     obj['filter'] = columnObj ? columnObj : null;
  //     obj['search'] = this._value;
  //     obj['sortColumn'] = this.sortColumn;
  //     obj['sortOrder'] = this.sortParameters[this.sortColumn];
  //     this.dataTable.emit(obj);
  //     this.loading = true;
  //   }
  // }

  openFullscreen() {
    const body = document.getElementsByTagName('body')[0];
    if (this.fullscreen_bol == false) {
      this.largeScreen = 'large';
      this.opt_screen = 'fullscreen'
      this.fullscreen_bol = true;
      body.classList.add('open');
    }
    else if (this.fullscreen_bol == true) {
      if (this.id == "Tarping") {
        this.largeScreen = 'max-heght_table5';
      }
      else if (this.id == "Loading") {
        this.largeScreen = 'max-heght_table5';
      }
      else if (this.id == "Parking") {
        this.largeScreen = 'max-heght_table5';
      }
      this.opt_screen = ''
      this.fullscreen_bol = false;
      body.classList.remove('open');
    }
  }
  applyFilter() {
    console.log(this.searchParameters);
    this.initializePaginator();
    let columnWiseFilterPresent = this.checkColumnFiltersPresent();
    let columnObj = null;
    if (columnWiseFilterPresent) {
      columnObj = { ...this.searchParameters };
    }
    if (this.searchParameters.incomingTime) {
      columnObj.incomingTime = this.datePipe.transform(dayjs(columnObj.incomingTime).toString(), 'yyyy-MM-dd');
    }
    if (this.searchParameters.outgoingTime) {
      columnObj.outgoingTime = this.datePipe.transform(dayjs(columnObj.outgoingTime).toString(), 'yyyy-MM-dd');
    }
    this.getdynamicdata(this.currentPage, this.pageSize, columnObj);
  }
  onSortChanged(event) {
    this.sortColumn = event;
    let tempSortParameters = {
      vehicleLicence: "",
      incomingTime: "",
      waitingTime: "",
      outgoingTime: ""
    }
    this.sortParameters[this.sortColumn] = this.sortParameters[this.sortColumn] != 'asc'
      && this.sortParameters[this.sortColumn] != 'desc' ?
      'asc' : this.sortParameters[this.sortColumn] == 'asc' ? 'desc' : "";
    tempSortParameters[this.sortColumn] = this.sortParameters[this.sortColumn];
    this.sortParameters = { ...tempSortParameters };
    this.initializePaginator();
    this.getdynamicdata(this.currentPage, this.pageSize);
  }
  checkColumnFiltersPresent() {
    if (this.searchParameters.vehicleLicence || this.searchParameters.incomingTime || this.searchParameters.waitingTime || this.searchParameters.outgoingTime) {
      return true;
    }
    return false;
  }
  toggleFullscreen() {
    if (!this.isFullscreen) {
      this.enterFullscreen();
    } else {
      this.exitFullscreen();
    }
  }
  enterFullscreen() {
    this.isFullscreen = true;
    this.fullscreenIconClass = 'fa fa-compress-arrows-alt';
    this.document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.addEventListener('keydown', this.handleEscKey);
  }
  exitFullscreen() {
    this.isFullscreen = false;
    this.fullscreenIconClass = 'fa fa-expand-arrows-alt';
    this.document.removeEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.removeEventListener('keydown', this.handleEscKey);
  }

  handleFullscreenChange = () => {
    if (!this.document.fullscreenElement && !this.document.webkitFullscreenElement &&
        !this.document.mozFullScreenElement && !this.document.msFullscreenElement) {
      this.exitFullscreen();
    }
  }
  handleEscKey = (event: KeyboardEvent) => {
    if (event.key === 'Escape') this.exitFullscreen();
  }
}