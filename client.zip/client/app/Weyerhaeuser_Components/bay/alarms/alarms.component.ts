import { Component, Input } from '@angular/core';
@Component({
  selector: 'app-alarms',
  templateUrl: './alarms.component.html',
  styleUrls: ['./alarms.component.scss']
})
export class AlarmsComponent {
  loading: boolean = true;
  @Input() avgCount: number = 0;
  constructor(){
    if(this.avgCount != undefined || null){
      this.loading = false;
    }
  }
}
