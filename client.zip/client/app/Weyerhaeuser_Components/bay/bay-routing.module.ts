import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BayComponent } from './bay.component';

const routes: Routes = [
  {path:'',component:BayComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BayRoutingModule { }
