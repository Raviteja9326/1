import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TrucklistModalComponent } from 'client/app/modals/trucklist-modal/trucklist-modal.component';
@Component({
  selector: 'app-slots',
  templateUrl: './slots.component.html',
  styleUrls: ['./slots.component.scss']
})
export class SlotsComponent implements OnChanges {
  @Input() TruckCount:any;
  slot_filled:number = 0;
  loading:boolean = true;
  slot_avable: number = 0;
  ngOnChanges(changes: SimpleChanges) {
    if(changes.TruckCount.currentValue != undefined || null){
      this.slot_avable = changes.TruckCount.currentValue.remaining;
      this.slot_filled = changes.TruckCount.currentValue.truckCount;
      this.loading = false;
    }
  }
  constructor(public dialog: MatDialog){}
  truck_Modal(): void {
    const parkingadd:string = "Parking";
    this.dialog.open(TrucklistModalComponent, {
      width: '100%',
      maxWidth: '85vw',
      height:'auto',
      data: {parkingadd},
      disableClose: false,
      autoFocus: false,
      position: {
        top:'20px'
      }
    });
  }

}
