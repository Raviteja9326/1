import { DatePipe } from '@angular/common';
import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  ApexPlotOptions,
  ApexChart,
  ChartComponent,
  ApexLegend,
  ApexAxisChartSeries,
} from 'ng-apexcharts';

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  labels: string[];
  plotOptions: ApexPlotOptions;
  legend: ApexLegend;
};
@Component({
  selector: 'app-total-max-graph',
  templateUrl: './total-max-graph.component.html',
  styleUrls: ['./total-max-graph.component.scss'],
})
export class TotalMaxGraphComponent implements OnChanges, OnInit {
  @Input() graph2 = '';
  public colors = ['#488A99', '#7cbb87', '#fdcf65', '#f18585'];
  @ViewChild('chart') chart: ChartComponent;
  public chartOptions: Partial<any>;
  loading: boolean = true;
  dateLables: any = [];
  dateocupancy: any = [];
  dateocupancy2: any = [];
  dataname: any;
  constructor(private datepipe: DatePipe, private router: ActivatedRoute) {
    this.loading = false;
  }
  ngOnInit(): void {
    this.router.paramMap.subscribe((params) => {
      if (params.get('id') == 'Tarping') {
        this.dataname = 'Tarping';
      } else if (params.get('id') == 'Loading') {
        this.dataname = 'Loading';
      } else if (params.get('id') == 'Parking') {
        this.dataname = 'Parking';
      }
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.loading = true;
    this.dateLables = [];
    this.dateocupancy = [];
    this.dateocupancy2 = [];
    if (changes.graph2.currentValue != undefined || null) {
      this.dateocupancy = changes.graph2.currentValue;
      if (this.dateocupancy != 0) {
        this.dateocupancy.map((res) => {
          console.log(res);
          this.dateocupancy2.push(res.maxWaitingTime);
          this.dateLables.push(res.vehicleLicence);
        });
      }
      this.loading = false;
      this.graphsbydate();
    }
  }
  graphsbydate() {
    this.chartOptions = {
      chart: {
        height: 350,
        type: 'bar',
        toolbar: {
          show: false,
        },
      },
      plotOptions: {
        bar: {
          horizontal: false,
        },
      },
      series: [
        {
          name: 'Time (Mins)',
          data: this.dateocupancy2,
          style: {
            fontSize: '13px',
            fontFamily: "'Open Sans', sans-serif",
            fontWeight: 700,
          },
        },
      ],
      xaxis: {
        gridLineWidth: 0.5,
      lineWidth: 0,
      lineColor: 'transparent',
        categories: this.dateLables,
        fontSize: '30px',
        fontFamily: "Open Sans",
        title: {
          text: 'Truck Number',
          style: {
            fontSize: '13px',
            fontFamily: "'Open Sans', sans-serif",
            fontWeight: 700,
          },
        },
      },
      yaxis: {
        gridLineWidth: 0.5,
        title: {
            text: 'Mins',
            style:{
              color: '#000',
              fontWeight: '600',
              fontFamily: "'Open Sans', sans-serif",
            },
        },
        labels: {
          style: {
              color: '#000',
              fontWeight: '600',
              fontFamily: "'Open Sans', sans-serif",
          }
        }
    },
    };
  }
}
