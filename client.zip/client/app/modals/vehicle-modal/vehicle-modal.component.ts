import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { VehiclecustomerService } from 'client/app/services/vehiclecustomer.service';
@Component({
  selector: 'app-vehicle-modal',
  templateUrl: './vehicle-modal.component.html',
  styleUrls: ['./vehicle-modal.component.scss'],
})
export class VehicleModalComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  roleName: string;
  description: string;
  userdata:any;
  qrdta:any;
  elementType = "canvas"
  constructor(
    public dialogRef: MatDialogRef<VehicleModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private storage: StorageService,
    private cam_ser:VehiclecustomerService
  ) {}
  roleForm = this.formBuilder.group({
    VehicleLicence: [
      '',
      [Validators.required],
    ],
    Capacity: [
      '',
      [Validators.required],
    ],
    driverName: [
      ''],
    drivercontact: [
      ''],
    vendorCompany: [
      ''],
  });
  ngOnInit(): void {
    this.userdata = this.storage.getuser();
    if(this.data.vecupd == true){
    this.Update_roledata();
    }
    else if(this.data.qrupd==true){
    this.qrdta = JSON.stringify(this.data.qrData)
    }
  }
  onCancel() {
    this.dialogRef.close();
  }
  rolesubmit() {
    if (this.roleForm.valid) {
      this.visible = true;
      this.cam_ser
        .addVehicle(this.roleForm.value)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next: (res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
          this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  roleupdate() {
    if (this.roleForm.valid) {
      this.visible = true;
      let roleData = {};
      roleData['id'] = this.data.vecData.VechicleID
      this.cam_ser
        .updateVehicle(this.roleForm.value,roleData)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next:(res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  Update_roledata() {
    if (this.data.vecupd == true) {
      console.log(this.data.vecData)
      this.roleForm.setValue({
        VehicleLicence: this.data.vecData.VehicleLicence,
        Capacity: this.data.vecData.Capacity,
        driverName: this.data.vecData.driverName,
        drivercontact: this.data.vecData.drivercontact,
        vendorCompany: this.data.vecData.vendorCompany,
      });
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }

  saveAsImage(parent: any) {
    console.log(parent)
    let parentElement = null

    if (this.elementType === "canvas") {
      // fetches base 64 data from canvas
      parentElement = parent.qrcElement.nativeElement
        .querySelector("canvas")
        .toDataURL("image/png")
    }

    if (parentElement) {
      // converts base 64 encoded image to blobData
      let blobData = this.convertBase64ToBlob(parentElement)
      // saves as image
      const blob = new Blob([blobData], { type: "image/png" })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      // name of the file
      link.download = "Qrcode"
      link.click()
    }
  }

  private convertBase64ToBlob(Base64Image: string) {
    // split into two parts
    const parts = Base64Image.split(";base64,")
    // hold the content type
    const imageType = parts[0].split(":")[1]
    // decode base64 string
    const decodedData = window.atob(parts[1])
    // create unit8array of size same as row data length
    const uInt8Array = new Uint8Array(decodedData.length)
    // insert all character code into uint8array
    for (let i = 0; i < decodedData.length; ++i) {
      uInt8Array[i] = decodedData.charCodeAt(i)
    }
    // return blob image after conversion
    return new Blob([uInt8Array], { type: imageType })
  }
}
