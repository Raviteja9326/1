import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { CameraMasterService } from 'client/app/services/camera-master.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { SimulatorService } from 'client/app/services/simulator.service';
import { DatePipe } from '@angular/common';
import { notZero } from 'client/app/entity/onlyzero-notallowed.directive';
@Component({
  selector: 'app-simulator-modal',
  templateUrl: './simulator-modal.component.html',
  styleUrls: ['./simulator-modal.component.scss'],
  providers: [DatePipe]
})
export class SimulatorModalComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  roleName: string;
  description: string;
  userdata: any;
  sitedata: any = [];
  camera: any = [];
  vehicle: any = [];
  currentDate: Date = new Date();
  constructor(
    public dialogRef: MatDialogRef<SimulatorModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private storage: StorageService,
    private adminService: FacilitymasterService,
    private camerService: CameraMasterService,
    private simService: SimulatorService,
    private datePipe: DatePipe
  ) { }
  roleForm = this.formBuilder.group({
    vehicleLicence: ['',[Validators.required,Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/), notZero()]],
    Capacity: [''],
    facilityId: ['', [Validators.required]],
    cameraId: ['', [Validators.required]],
    recivedTime: ['', [Validators.required]],
    driverName: [''],
    driverContact: [''],
    vendorCompany: [''],
  });
  ngOnInit(): void {
    this.getsites();
    this.userdata = this.storage.getuser();
    if (this.data.parkingadd == true) {
      this.getUser_master("Parking In");
    }
    else if (this.data.bayboolen == true) {
      this.getUser_master("Parking In");
    }
    else if (this.data.trapadd == true) {
      this.getUser_master("Tarping In");
    }
    else if (this.data.trapexit == true) {
      this.getUser_master("Tarping In");
    }
  }
  onCancel() {
    this.dialogRef.close();
  }
  getsites() {
    this.adminService.getfacilitymaster().pipe(takeUntil(this._destroying$)).subscribe({
      next: (res: any) => {
        res.elements.map(res2 => {
        res2.map(res3 =>{
          console.log(res3)
          if(res3.isActive == '1'){
            this.sitedata.push(res3)
          }
        })
        })

      }, error: (error) => {
        this.toastr.error(error.error.message);
        if (error.status == 401) {
          this.dialogRef.close();}
      }
    })
  }
  async getcamer(id) {
    console.log(id)
    this.camera = [];
    await this.camerService.getcameramasterID(id).pipe(takeUntil(this._destroying$)).subscribe({
      next: (res: any) => {
        if (res.data.length != 0) {
          this.camera = res.data;
        }
      }, error: (error) => {
        this.toastr.error(error.error.message);
        if (error.status == 401) {
          this.dialogRef.close();}
      }
    })
  }
  getUser_master(data) {
    console.log(data)
    const timedate = {};
    timedate['pageindex'] = 1;
    timedate['pagesize'] = 200000;
    timedate['status'] = data,
      timedate['time'] = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd HH:mm:ss');
    timedate['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone,
      this.simService.getallsimulator2(timedate).pipe(takeUntil(this._destroying$)).subscribe({
        next: (res) => {
          if (res.data.length != 0) {
            this.vehicle = res.data;
          }
        }, error: (error) => {
          this.toastr.error(error.error.message);
        }
      })
  }

 
  rolesubmit() {
    if (this.roleForm.valid) {
      this.visible = true;
      const obj = {};
      obj['cameraId'] = parseInt(this.roleForm.value.cameraId);
      this.simService
        .addentry(this.roleForm.value, obj)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          }, error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
              this.dialogRef.close();}
            this.visible = false;
          }
        });
    }
  }
  vehcsubmit() {
    if (this.roleForm.valid) {
      this.visible = true;
      const obj = {};
      obj['cameraId'] = parseInt(this.roleForm.value.cameraId);
      this.simService
        .addparking(this.roleForm.value, obj)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          }, error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
              this.dialogRef.close();}
            this.visible = false;
          }
        });
    }
  }
  baysubmit(data) {
    console.log(data)
    if (this.roleForm.valid) {
      this.visible = true;
      const obj = {};
      obj['cameraId'] = parseInt(this.roleForm.value.cameraId);
      this.simService
        .addload1(this.roleForm.value, obj)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          }, error: (error) => {
            this.toastr.error(error.error.message)
            this.visible = false;
          }
        });

    }
  }
  trapsubmit(data) {
    console.log(data)
    if (this.roleForm.valid) {
      this.visible = true;
      const obj = {};
      obj['cameraId'] = parseInt(this.roleForm.value.cameraId);
      if (data == 'Tarping In') {
        this.simService
          .addtrapinin(this.roleForm.value, obj)
          .pipe(takeUntil(this._destroying$))
          .subscribe({
            next: (res) => {
              this.toastr.success(res.message, '', {
                progressBar: true,
                progressAnimation: 'decreasing',
              });
              this.visible = false;
              this.dialogRef.close();
            }, error: (error) => {
              this.toastr.error(error.error.message);
              if (error.status == 401) {
                this.dialogRef.close();}
              this.visible = false;
            }
          });
      }
      else if (data == 'Tarping Exit') {
        this.simService
          .addtrapinout(this.roleForm.value, obj)
          .pipe(takeUntil(this._destroying$))
          .subscribe({
            next: (res) => {
              this.toastr.success(res.message, '', {
                progressBar: true,
                progressAnimation: 'decreasing',
              });
              this.visible = false;
              this.dialogRef.close();
            }, error: (error) => {
              this.toastr.error(error.error.message);
              if (error.status == 401) {
                this.dialogRef.close();}
              this.visible = false;
            }
          });
      }
    }
  }
  exitsubmit() {
    console.log(this.roleForm.value)
    if (this.roleForm.valid) {
      this.visible = true;
      const obj = {};
      obj['cameraId'] = parseInt(this.roleForm.value.cameraId);
      this.simService
        .addtrapinout(this.roleForm.value, obj)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          }, error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
              this.dialogRef.close();}
            this.visible = false;
          }
        });
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
