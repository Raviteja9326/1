import { Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Totalexpand } from 'client/app/shared/search';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { rowsAnimation } from 'client/app/shared/animations';
import { ParkingyardService } from 'client/app/services/parkingyard.service';
import { DatePipe } from '@angular/common';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import dayjs from 'dayjs/esm';
@Component({
  selector: 'app-alert-alarm-modal',
  templateUrl: './alert-alarm-modal.component.html',
  styleUrls: ['./alert-alarm-modal.component.scss'],
  animations: [Totalexpand.search_animations, rowsAnimation],
})
export class AlertAlarmModalComponent implements OnInit, OnDestroy {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = 'timeAlert';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  userDetail: any;
  isLinear:boolean = false;
  pageIndex: number = 1;
  pageSize: number = 20;
  totalItems: number;
  currentDate = new Date();
  menus: string;
  menus2: string;
  displayedColumns: string[] = ['vehicleLicence','alertType', 'parameterValue', 'entryTime'];
  parking: any;
  loading: any;
  traping: any;
  searchFilterFlags:any={
    vehicleLicence:false,
    parameterValue:false,
    entryTime:false,
    alertType:false
  }
  searchParameters:any={
    vehicleLicence:"",
    parameterValue:0,
    entryTime:"",
    alertType:""
  }
  sortParameters:any={
    vehicleLicence:"",
    parameterValue:"",
    entryTime:"",
    alertType:""
  }
  sortOrder: any="";
  sortColumn: any="";
  constructor(
    public dialogRef: MatDialogRef<AlertAlarmModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private sim_cust: ParkingyardService,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private Bay_cust: BayMasterService,
    private userser: StorageService
  ) { }
  ngOnInit(): void {
    //this.getRoutes();
    this.getUserDetails();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  onStepClick(event) {
    this.initializeFilters();
    if(event.selectedIndex == 0){
      this._value = 'timeAlert';
      this.displayedColumns = ['vehicleLicence','alertType', 'parameterValue', 'entryTime'];
      this.getUser_master();
    }
    else if(event.selectedIndex == 1){
      this._value = 'occupancyAlert';
      this.displayedColumns = ['parameterValue','vehicleLicence','alertType','entryTime'];
      this.getUser_master();
    }
  }
  refreshTable(){
    this.pageIndex=1;
    this.pageSize=20;
    this.searchParameters = {
      vehicleLicence:"",
      parameterValue:0,
      entryTime:""
    };
    this.searchFilterFlags = {
      vehicleLicence:false,
      parameterValue:false,
      entryTime:false
    };
    this.sortParameters = {
      vehicleLicence:"",
      parameterValue:"",
      entryTime:""
    };
    this.sortColumn = "";
    this.sortOrder = "";
    this.getUser_master();
  }
  initializePaginator() {
    this.pageIndex = 1;
    this.pageSize = 20;
  }
  initializeFilters(){
    this.pageIndex=1;
    this.pageSize=20;
    this.searchParameters = {
      vehicleLicence:"",
      parameterValue:0,
      entryTime:""
    };
    this.searchFilterFlags = {
      vehicleLicence:false,
      parameterValue:false,
      entryTime:false
    };
    this.sortParameters = {
      vehicleLicence:"",
      parameterValue:"",
      entryTime:""
    };
    this.sortColumn = "";
    this.sortOrder = "";
  }
  applyFilter(){
    console.log(this.searchParameters);
    this.initializePaginator();
    let columnWiseFilterPresent = this.checkColumnFiltersPresent();
    let columnObj=null;
    if(columnWiseFilterPresent){
      columnObj = {...this.searchParameters};
    }
    let time = new Date();
    if(this.searchParameters.entryTime){
      columnObj.entryTime = this.datePipe.transform(dayjs(columnObj.entryTime).toString(), 'yyyy-MM-dd');
      columnObj.entryTime = columnObj.entryTime+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    this.getUser_master(columnObj);
  }
  onSortChanged(event){
    this.sortColumn = event;
    let tempSortParameters={
      vehicleLicence:"",
      parameterValue:"",
      entryTime:""
    }
    this.sortParameters[this.sortColumn] = this.sortParameters[this.sortColumn]!='asc'
     && this.sortParameters[this.sortColumn]!='desc' ?
     'asc': this.sortParameters[this.sortColumn]=='asc'?'desc':"";
    tempSortParameters[this.sortColumn] = this.sortParameters[this.sortColumn];
    this.sortParameters = {...tempSortParameters};
    this.applyFilter();
  }
  checkColumnFiltersPresent(){
    if(this.searchParameters.vehicleLicence || this.searchParameters.parameterValue || this.searchParameters.entryTime || this.searchParameters.alertType){
      return true;
    }
    return false;
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    let columnWiseFilterPresent = this.checkColumnFiltersPresent();
    let columnObj=null;
    if(columnWiseFilterPresent){
      columnObj = {...this.searchParameters};
    }
    let time = new Date();
    if(this.searchParameters.entryTime){
      columnObj.entryTime = this.datePipe.transform(dayjs(columnObj.entryTime).toString(), 'yyyy-MM-dd');
      columnObj.entryTime = columnObj.entryTime+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    this.getUser_master(columnObj);
  }
  onCancel() {
    this.dialogRef.close();
  }
  getUserDetails() {
    this.userDetail = this.userser.getvariable();
    this.getbay_Master();
  }
  async getbay_Master() {
    const timedate = {};
    timedate['time'] = this.datePipe.transform(
      this.currentDate,
      'yyyy-MM-dd HH:mm:ss'
    );
    (timedate['stamp'] = Intl.DateTimeFormat().resolvedOptions().timeZone),
      await this.Bay_cust.getbay(timedate)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            res.elements.map((data) => {
              data.map((data2) => {
                if (data2.facilityId == this.userDetail && data2.bayName == 'PARKING') {
                  this.parking = data2.bayId;
                }
                if (data2.facilityId == this.userDetail && data2.bayName == 'LOADING') {
                  this.loading = data2.bayId;
                }
                if (data2.facilityId == this.userDetail && data2.bayName == 'TARPING') {
                  this.traping = data2.bayId;
                }
              });
            });
            console.log(this.parking, this.loading, this.traping)
            this.getUser_master();
          },
          error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
            this.dialogRef.close();}
          },
        });
  }
  getUser_master(columnObj?) {
    this.ELEMENT_DATA = [];
    this.isLoading = true;
    const timedate = {};
    timedate['pageindex'] = this.pageIndex;
    timedate['pagesize'] = this.pageSize;
    timedate['filter'] = columnObj?columnObj:"";
    //timedate['search'] = this._value;
    timedate['sortColumn'] = this.sortColumn;
    timedate['alertType'] = this._value;
    timedate['sortOrder'] = this.sortParameters[this.sortColumn];
    timedate['timezone'] =  Intl.DateTimeFormat().resolvedOptions().timeZone;
    timedate['date'] = this.datePipe.transform(
      this.currentDate,
      'yyyy-MM-dd HH:mm:ss'
    );
    if (this.data.bayadd == 'PARKING') {
      timedate['facilityId'] = this.userDetail;
      timedate['bayId'] = this.parking;
    } else if (this.data.bayadd == 'LOADING') {
      timedate['facilityId'] = this.userDetail;
      timedate['bayId'] = this.loading;
    } else if (this.data.bayadd == 'TARPING') {
      timedate['facilityId'] = this.userDetail;
      timedate['bayId'] = this.traping;
    }
    this.sim_cust
      .getAlertAlarms(timedate)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          console.log(res.elements);
          this.ELEMENT_DATA = res;
          if (res['elements'].length != 0) {
            this.isLoading = false;
            this.displayNoRecords = false;
            this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA.elements);//uncomment later
            setTimeout(() => {
              this.dataSource.sort = this.sort;
              this.totalItems = res.metadata.total;
              this.pageIndex = res.metadata.current_page - 1;
            });
          } else if (res.elements.length == 0) {
            this.ELEMENT_DATA = [];
            this.dataSource = new MatTableDataSource<any>([]);
            this.isLoading = false;
            this.displayNoRecords = true;
            this.totalItems = 0;
            this.pageIndex = 1;
            this.pageSize = 20;
          }
        },
        error: (error) => {
          this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
        },
      });
  }
}
