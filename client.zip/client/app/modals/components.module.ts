import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AccessModalComponent } from './access-modal/access-modal.component';
import { AlertModalComponent } from './alert-modal/alert-modal.component';
import { RoleModalComponent } from './role-modal/role-modal.component';
import { UserModalComponent } from './user-modal/user-modal.component';
import { VehicleModalComponent } from './vehicle-modal/vehicle-modal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { SkeletonModule } from 'primeng/skeleton';
import { MaterialModule } from '../shared/material.module';
import { AlertMsgComponent } from './alert-msg/alert-msg.component';
import { FacilityModalComponent } from './facility-modal/facility-modal.component';
import { CameraModalComponent } from './camera-modal/camera-modal.component';
import { BayModalComponent } from './bay-modal/bay-modal.component';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { SimulatorModalComponent } from './simulator-modal/simulator-modal.component';
import { NgxMatDateFormats, NGX_MAT_DATE_FORMATS } from '@angular-material-components/datetime-picker';
import { TrucklistModalComponent } from './trucklist-modal/trucklist-modal.component';
import { PenaltyModalComponent } from './penalty-modal/penalty-modal.component';
import { WaitingTimeModalComponent } from './waitingtime-modal/waitingtime-modal.component';
import { LandModalComponent } from './land-modal/land-modal.component';
import { AlertAlarmModalComponent } from './alert-alarm-modal/alert-alarm-modal.component';
import { Sub_Add_PipeModule } from '../shared/sub_add_pipe_module';
const CUSTOM_DATE_FORMATS: NgxMatDateFormats = {
  parse: {
    dateInput: "LL"
  },
  display: {
    dateInput: 'DD-MM-YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  }
};

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot({
      maxOpened: 1,
      preventDuplicates: true
    }),
    SkeletonModule,
    MatOptionModule,
    MatSelectModule,
    Sub_Add_PipeModule
  ],
  declarations: [
    VehicleModalComponent,
    UserModalComponent,
    AlertModalComponent,
    RoleModalComponent,
    AccessModalComponent,
    AlertMsgComponent,
    FacilityModalComponent,
    CameraModalComponent,
    BayModalComponent,
    SimulatorModalComponent,
    TrucklistModalComponent,
    PenaltyModalComponent,
    WaitingTimeModalComponent,
    LandModalComponent,
    AlertAlarmModalComponent
  ],
  exports: [
    VehicleModalComponent,
    UserModalComponent,
    AlertModalComponent,
    RoleModalComponent,
    AccessModalComponent,
    AlertMsgComponent,
    FacilityModalComponent,
    CameraModalComponent,
    BayModalComponent,
    SimulatorModalComponent,
    TrucklistModalComponent,
    PenaltyModalComponent,
    WaitingTimeModalComponent,
    LandModalComponent,
    AlertAlarmModalComponent
  ]
})
export class ComponentsModule { }
