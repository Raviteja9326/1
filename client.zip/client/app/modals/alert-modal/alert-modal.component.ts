import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertmasterService } from 'client/app/services/alertmaster.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { RoleService } from 'client/app/services/role.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-alert-modal',
  templateUrl: './alert-modal.component.html',

})
export class AlertModalComponent implements OnInit, OnDestroy {
  _destroying$: Subject<boolean> = new Subject<boolean>();
  visible: boolean = false;
  Selected_Default_value: any;
  alarmsList: any = [];
  SitesData: any = [];
  roles: any = [];
  AlertsData: any[];
  AlertName: any;
  bayId: any;
  constructor(
    public dialogRef: MatDialogRef<AlertModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private cd: ChangeDetectorRef,
    private bay: BayMasterService,
    private alert: AlertmasterService,
    private route: Router,
    private adminService: FacilitymasterService,
    private roleService: RoleService
  ) { }
  ngOnInit(): void {
    this.getsites();
    this.getroles();
    this.onChange(1);
    if (this.data.alrtupd == true) {
      this.getbay(this.data.alrtData.facilityId);
      this.user_update_data();
    }
    else{
    this.userForm.get('alertDesc').setValue('Vehicle is waiting in area for more than set threshold value');
    }
    this.AlertsData = ['Parking occupancy alert','Loading occupancy alert','Tarping occupancy alert'];
  }
  userForm = this.formBuilder.group({
    alertName: ['', [Validators.required]],
    alertDesc: ['', [Validators.required]],
    minThreshold: ['',[Validators.required]],
    maxThreshold: ['', [Validators.required]],
    maxThresholdWarning: ['', [Validators.required]],
    bayId: ['', [Validators.required]],
    notifiedTo: ['', [Validators.required]],
    facilityId: ['', [Validators.required]],
  });
  onCancel() {
    this.dialogRef.close();
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  getsites() {
    this.SitesData = [];
    this.adminService
      .getfacilitymaster()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          res.elements[0].map((x) => {
            if (x.isActive == true) {
              this.SitesData.push(x);
            }
          });
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
  }
  async getbay(id) {
    await this.bay
      .getbaybyid1(id)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          this.alarmsList = res.elements;
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
  }

  getbay1(id)
  {
    let Bay = id;
    if(Bay == 2)
    {
      this.userForm.get('alertName').setValue('Parking occupancy alert');
    }
    if(Bay == 3)
    {
      this.userForm.get('alertName').setValue('Loading occupancy alert');
    }
    if(Bay == 14)
    {
      this.userForm.get('alertName').setValue('Tarping occupancy alert');
    }
  }

  async getroles() {
    await this.roleService
      .getRoles()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          this.roles = res.elements;
          console.log(this.roles)
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
  }

  getAlert(name){
    this.AlertName = name;

  }

  userMastersubmit() {
    console.log(this.userForm.value)
    if(this.AlertName == "Parking occupancy alert")
    {
      this.bayId = 2;
    }
    if(this.AlertName == "Loading occupancy alert")
    {
      this.bayId = 3;
    }
    if(this.AlertName == "Tarping occupancy alert")
    {
      this.bayId = 14;
    }
    if (!this.userForm.valid) {
      Object.keys(this.userForm.controls).forEach((field) => {
        const control = this.userForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    } else if (this.userForm.valid) {
      this.visible = true;
      const obj = {};
      obj['isActive'] = this.Selected_Default_value;
      obj["alertType"] = "occupancyAlert";
      obj["avgWaiting"] = 20;
      // obj["bayId"] = this.bayId;
      // obj['alertDesc'] = 'Vehicle is waiting in area for more than set threshold value';
      this.alert
        .addalertMaster(this.userForm.value, obj)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          },
          error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
              this.dialogRef.close();
            }
            this.visible = false;
          },
        });
    }
  }
  userMasterupdate() {
    if (!this.userForm.valid) {
      Object.keys(this.userForm.controls).forEach((field) => {
        const control = this.userForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    } else if (this.userForm.valid) {
      this.visible = true;
      const obj = {};
      obj['isActive'] = this.Selected_Default_value;
      obj["alertType"] = "occupancyAlert";
      // obj["bayId"] = this.data.alrtData.bayId;
      this.alert
        .updatealert(this.userForm.value, obj, this.data.alrtData.Id)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          },
          error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
              this.dialogRef.close();
            }
            this.visible = false;
          },
        });
    }
  }
  user_update_data() {
    console.log(this.data.alrtData);
    this.userForm.setValue({
      alertName: this.data.alrtData.alertName,
      alertDesc: this.data.alrtData.alertDesc,
      minThreshold: this.data.alrtData.minThreshold,
      maxThreshold: this.data.alrtData.maxThreshold,
      maxThresholdWarning: this.data.alrtData.maxThresholdWarning,
      notifiedTo: this.data.alrtData.roleId,
      facilityId: this.data.alrtData.facilityId,
      bayId: this.data.alrtData.bayId
    });
    if (this.data.alrtData.isActive == false) {
      this.Selected_Default_value = 0;
    } else if (this.data.alrtData.isActive == true) {
      this.Selected_Default_value = 1;
    }
  }
  ngAfterContentInit() {
    this.cd.detectChanges();
  }
  onChange($event) {
    if ($event == '1') {
      this.cd.detectChanges();
      this.Selected_Default_value = 1;
    } else if ($event == '0') {
      this.cd.detectChanges();
      this.Selected_Default_value = 0;
    }
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
