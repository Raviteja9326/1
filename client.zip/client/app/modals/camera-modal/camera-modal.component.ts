import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { CameraMasterService } from 'client/app/services/camera-master.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
@Component({
  selector: 'app-camera-modal',
  templateUrl: './camera-modal.component.html',
  styleUrls: ['./camera-modal.component.scss']
})
export class CameraModalComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  roleName: string;
  description: string;
  userdata:any;
  SitesData:any=[];
  constructor(
    public dialogRef: MatDialogRef<CameraModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private storage: StorageService,
    private cam_ser:CameraMasterService,
    private adminService: FacilitymasterService,
  ) {}
  roleForm = this.formBuilder.group({
    facilityId: [
      '',
      [Validators.required],
    ],
    locationDescription: [
      '',
      [Validators.required],
    ],
    cameraId: [
      '',
      [Validators.required],
    ],
    locationName:['',[Validators.required]]
  });
  ngOnInit(): void {
   this.getsites();
    this.userdata = this.storage.getuser();
    if(this.data.camupd == true){
    this.Update_roledata();
    }
  }
  onCancel() {
    this.dialogRef.close();
  }
  getsites() {
    this.adminService.getfacilitymaster().pipe(takeUntil(this._destroying$)).subscribe({next:(res:any)=>{
      res.elements.map(res => {
        this.SitesData = res;
      })
    },error: (error) => {
      this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
 }})
  }
  rolesubmit() {
    if (this.roleForm.valid) {
      this.visible = true;
      const roleData = {};
      roleData['createdBy'] = this.userdata.userId;
      this.cam_ser
        .addcameraMaster(this.roleForm.value,roleData)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next: (res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
          this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  roleupdate() {
    if (this.roleForm.valid) {
      this.visible = true;
      let roleData = {};
      roleData['id'] = this.data.camData.id
      roleData['updatedBy'] = this.userdata.userId;
      this.cam_ser
        .updatecameraMaster(this.roleForm.value,roleData)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next:(res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
          this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  Update_roledata() {
    if (this.data.camupd == true) {
      console.log(this.data.roleData)
      this.roleForm.setValue({
        facilityId: this.data.camData.facilityId,
        locationDescription: this.data.camData.locationDescription,
        cameraId: this.data.camData.cameraId,
        locationName: this.data.camData.cameraName
      });
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
