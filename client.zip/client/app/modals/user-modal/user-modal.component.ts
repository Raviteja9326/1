import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { UsermasterService } from 'client/app/services/usermaster.service';
import { MustMatch, spaceValidator } from 'client/app/shared/config';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-user-modal',
  templateUrl: './user-modal.component.html',
  styleUrls: ['./user-modal.component.scss'],
})
export class UserModalComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  SitesData = [];
  Roles = [];
  Selected_Default_value: any;
  roleID: number;
  userdata: any;
  hide: boolean = true;
  hideconf: boolean = true;
  roleID1: any;
  facilityID1: any;
  constructor(
    public dialogRef: MatDialogRef<UserModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private userService: UsermasterService,
    private toastr: ToastrService,
    private adminService: FacilitymasterService,
    private cd: ChangeDetectorRef,
    private storage: StorageService
  ) {}
  ngOnInit(): void {
    this.getroles();
    this.onChange(1);
    if (this.data.userupdate == true) {
      this.getsites();
      this.user_update_data();
    }
    this.userdata = this.storage.getuser();

  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  userForm = this.formBuilder.group(
    {
      fullName: ['', [Validators.required, spaceValidator]],
      email: [
        '',
        [
          spaceValidator,
          Validators.required,
          Validators.pattern(
            '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@' +
              '[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$'
          ),
        ],
      ],
      roleId: ['', [Validators.required]],
      facility: ['', [Validators.required]],
      password: [
        '',
        [
          Validators.required,
          spaceValidator,
          Validators.pattern(
            /^(?=.{8,16}$)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/
          ),
        ],
      ],
      ConfirmPassword: ['', [Validators.required]],
    },
    {
      validator: MustMatch('password', 'ConfirmPassword'),
    }
  );

  onCancel() {
    this.dialogRef.close();
  }
  getroles() {
    this.userService
      .getRoles()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          console.log(res);
          this.Roles = res.elements;
        },
        error: (error) => {
          this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
        },
      });
  }


  getsites() {
     this.SitesData =[];
      this.adminService
      .getfacilitymaster()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          res.elements.map(ele => {
            ele.map(res =>{
              if(res.isActive == '1'){
                this.SitesData.push(res);
              }
            })
        });
        },
        error: (error) => {
          this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
        },
      });
  }

  userMastersubmit() {
    if (!this.userForm.valid) {
      Object.keys(this.userForm.controls).forEach((field) => {
        const control = this.userForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.visible = false;
    } else if (this.userForm.valid) {
      this.user_submit();
    }
  }
  user_submit() {
    this.visible = true;
    const authorizationData = btoa(
      JSON.stringify(this.userForm.value.password)
    );
    const obj = {};
    obj['isActive'] = this.Selected_Default_value;
    obj['createdBy'] = this.userdata.userId;
    obj['password'] = authorizationData;
    obj['ConfirmPassword'] = authorizationData;
    this.userService
      .adduserMaster(this.userForm.value, obj)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          this.toastr.success(res.message, '', {
            progressBar: true,
            progressAnimation: 'decreasing',
          });
          this.visible = false;
          this.dialogRef.close();
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          this.visible = false;
        },
      });
  }
  user_update_data() {
    this.userForm.setValue({
      fullName: this.data.userData.fullName,
      email: this.data.userData.email,
      roleId: parseInt(this.data.userData.roleId),
      facility: this.convertStringToObjects(this.data.userData.facilityId),
      password: '',
      ConfirmPassword: '',
    });
    if (this.data.userData.isActive == false) {
      this.Selected_Default_value = false;
    } else if (this.data.userData.isActive == true) {
      this.Selected_Default_value = true;
    }
  }

  user_update() {
    this.visible = true;
    const obj = {};
    obj['isActive'] = this.Selected_Default_value;
    obj['updatedBy'] = this.data.userData.userid;
    obj['prevFacility'] = JSON.parse("[" + this.data.userData.facilityId + "]");
    this.visible = true;
    this.userService
      .updateuserMaster(this.userForm.value, obj, this.data.userData.userid)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          this.toastr.success(res.message, '', {
            progressBar: true,
            progressAnimation: 'decreasing',
          });
          this.visible = false;
          this.dialogRef.close();
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          this.visible = false;
        },
      });
  }
  ngAfterContentInit() {
    this.cd.detectChanges();
  }
  onChange($event) {
    if ($event == '1') {
      this.cd.detectChanges();
      this.Selected_Default_value = true;
    } else if ($event == '0') {
      this.cd.detectChanges();
      this.Selected_Default_value = false;
    }
  }
  convertStringToObjects(keysString) {
    var keys = keysString.split(',');
    var objects = [];
    // Assuming keys and values have the same length
    for (var i = 0; i < keys.length; i++) {
      objects.push(parseFloat(keys[i].trim()));
    }
    return objects;
  }
}
