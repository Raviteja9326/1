import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { CameraMasterService } from 'client/app/services/camera-master.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-bay-modal',
  templateUrl: './bay-modal.component.html',
  styleUrls: ['./bay-modal.component.scss']
})
export class BayModalComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  SitesData = [];
  Roles = [];
  Selected_Default_value: any;
  roleID: number;
  userdata:any;
  camera: any = [];
  facilitydata:any;
  constructor(
    public dialogRef: MatDialogRef<BayModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private userService: BayMasterService,
    private toastr: ToastrService,
    private adminService: FacilitymasterService,
    private camerService: CameraMasterService,
    private cd: ChangeDetectorRef,
    private storage: StorageService
  ) {
  }
  ngOnInit(): void {
    this.getsites();
    this.onChange(1);
    if (this.data.bayupdate == true) {
      this.facilitydata = parseInt(this.data.bayData.facilityId);
      this.getcamer(this.facilitydata);
      this.user_update_data();
    }
    this.userdata = this.storage.getuser();
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  userForm = this.formBuilder.group({
    bayName: ['', [Validators.required]],
    bayDesc: ['', [Validators.required]],
    cameraId: ['',[ Validators.required]],
    facilityId: ['', [Validators.required]],
  });

  onCancel() {
    this.dialogRef.close();
  }
  getsites() {
    this.adminService.getfacilitymaster().pipe(takeUntil(this._destroying$)).subscribe({next:(res:any)=>{
      res.elements.map(res => {
        this.SitesData = res;
      })
    },error: (error) => {
      this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
 }})
  }
 async getcamer(id) {
    this.camera = [];
    await this.camerService.getcameramasterID(id).pipe(takeUntil(this._destroying$)).subscribe({next:(res:any)=>{
    if(res.data.length !=0){
      console.log(res.data)
    this.camera = res.data;
    }
    },error: (error) => {
      this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
 }})
  }
 userMastersubmit() {
  if (!this.userForm.valid) {
    Object.keys(this.userForm.controls).forEach(field => {
      const control = this.userForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    this.visible = false
  }
    else if(this.userForm.valid){
      if (this.data.bayupdate == true) {
      this.user_update();
      }
      if (this.data.bayupdate != true) {
        this.user_submit();
        }
    }
  }
  user_submit() {
    this.visible = true;
    const obj = {};
    obj['isActive'] = this.Selected_Default_value;
    obj['createdBy'] = this.userdata.userId;
    this.userService
      .addBayMaster(this.userForm.value, obj).pipe(takeUntil(this._destroying$))
      .subscribe({next:(res) => {
        this.toastr.success(res.message , '', {
          progressBar: true,
          progressAnimation: 'decreasing',
        });
        this.visible = false;
        this.dialogRef.close();
      },error: (error) => {
        this.toastr.error(error.error.message);
        if (error.status == 401) {
        this.dialogRef.close();}
        this.visible = false;
    }});
  }
 user_update_data() {
  console.log(this.data.bayData);
   this.userForm.setValue({
      bayName: this.data.bayData.bayName,
      bayDesc: '',
      facilityId: this.facilitydata,
      cameraId: this.data.bayData.cameraId,
    });
    if (this.data.bayData.isActive == false) {
      this.Selected_Default_value = false;
    } else if (this.data.bayData.isActive == true) {
      this.Selected_Default_value = true;
    }
    console.log(this.data.bayData.cameraId, this.userForm.value)
  }
  user_update() {
    this.visible= true;
    const obj = {};
    obj['isActive'] = this.Selected_Default_value;
    obj['updatedBy'] = this.userdata.userId;
    this.userService
      .updatebayMaster(this.userForm.value, obj, this.data.bayData.bayId).pipe(takeUntil(this._destroying$))
      .subscribe({next:(res) => {
        this.toastr.success(res.message , '', {
          progressBar: true,
          progressAnimation: 'decreasing',
        });
        this.visible = false;
        this.dialogRef.close();
      },error: (error) => {
        this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
        this.visible = false;
    }});
  }
  ngAfterContentInit() {
    this.cd.detectChanges();
  }
  onChange($event) {
    if ($event == '1') {
      this.cd.detectChanges();
      this.Selected_Default_value = true;
    } else if ($event == '0') {
      this.cd.detectChanges();
      this.Selected_Default_value = false;
    }
  }
}
