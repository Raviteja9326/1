import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertmasterService } from 'client/app/services/alertmaster.service';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { RoleService } from 'client/app/services/role.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { WaitingTimemasterService } from 'client/app/services/waitingtime-master.service';
import { FacilityMasterComponent } from 'client/app/Weyerhaeuser_Components/administrator/facility-master/facility-master.component';
@Component({
  selector: 'app-waitingtime-modal',
  templateUrl: './waitingtime-modal.component.html',
  styleUrls: ['./waitingtime-modal.component.scss'],
})
export class WaitingTimeModalComponent implements OnInit, OnDestroy {
  _destroying$: Subject<boolean> = new Subject<boolean>();
  visible: boolean = false;
  Selected_Default_value: any;
  alarmsList: any = [];
  SitesData: any = [];
  roles: any = [];
  SitesData1: any=[];
  bayID: any;
  facilityID: any;
  AlertsData: any =[];
  constructor(
    public dialogRef: MatDialogRef<WaitingTimeModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private cd: ChangeDetectorRef,
    private bay: BayMasterService,
    private alert: AlertmasterService,
    private route: Router,
    private WaitingTimeAlert: WaitingTimemasterService,
    private roleService: RoleService,
    private adminService: FacilitymasterService
  ) { }
  ngOnInit(): void {
    // this.getWaitingTimeAlert();
    this.getsites();
    this.getroles();
    this.onChange(1);
    if (this.data.alrtupd == true) {
      this.getbay(this.data.alrtData.facilityId);
      this.user_update_data();
    }
    this.AlertsData = ['Parking Time Alert', 'Loading Time Alert', 'Tarping Time Alert',  'Turn Around Time Alert'];
  }

  userForm = this.formBuilder.group({
    maxThreshold: ['', [Validators.required]],
    maxThresholdWarning: ['', [Validators.required]],
    minThreshold: ['', [Validators.required]],
    avgWaiting: [''],
    alertName: ['', [Validators.required]],
    facilityId: ['', [Validators.required]],
    bayId: ['', [Validators.required]],
    notifiedTo: ['', [Validators.required]],
    alertDesc: ['', [Validators.required]]
  });
  onCancel() {
    this.dialogRef.close();
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  getWaitingTimeAlert() {
    // console.log(this.facilityID);
    const obj = {};
    let data = {};

    data['pageIndex'] = 1;
    data['pageSize'] = 20;
    obj['alertType'] = 'timeAlert';
    obj['facilityId'] = 1;
    this.alert
      .getAlertList(data, obj)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          this.SitesData = res.elements;
          // console.log(this.SitesData);
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
  }

  getWaitingTimeAlert1(event) {
    this.bayID = event;
    console.log(this.bayID);
  }

  getsites() {
    this.SitesData1=[];
    this.adminService
      .getfacilitymaster()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          res.elements[0].map((x) => {
            if (x.isActive == true) {
              this.SitesData1.push(x);
            }
          });
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
  }

  async getbay(id) {
    this.facilityID = id;
    await this.bay
      .getbay1()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          this.alarmsList = res.elements[0];
          // console.log(res.elements[0])
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
    this.getWaitingTimeAlert();
  }

  getbay1(id)
  {
    let Bay = id;
    if(Bay == 2)
    {
      this.userForm.get('alertName').setValue('Parking Time Alert');
      this.userForm.get('alertDesc').setValue('Vehicle is waiting in Parking area for more than set threshold value');
    }
    if(Bay == 3)
    {
      this.userForm.get('alertName').setValue('Loading Time Alert');
      this.userForm.get('alertDesc').setValue('Vehicle is waiting in Loading area for more than set threshold value');
    }
    if(Bay == 14)
    {
      this.userForm.get('alertName').setValue('Tarping Time Alert');
      this.userForm.get('alertDesc').setValue('Vehicle is waiting in Tarping area for more than set threshold value');
    }
    if(Bay == 4)
    {
      this.userForm.get('alertName').setValue('Turn Around Time Alert');
      this.userForm.get('alertDesc').setValue('Vehicle is waiting in facility for more than Set threshold value');
    }
  }

  async getroles() {
    await this.roleService
      .getRoles()
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res: any) => {
          this.roles = res.elements;
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
        },
      });
  }
  userMastersubmit() {
    if (!this.userForm.valid) {
      Object.keys(this.userForm.controls).forEach((field) => {
        const control = this.userForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    } else if (this.userForm.valid) {
      this.visible = true;
      const obj = {};
      obj['isActive'] = 1;
      obj['alertType'] = 'timeAlert';
      // obj['alertDesc'] = 'Vehicle is waiting in  area for more than set threshold value';
      // obj['notifiedTo'] = 5;
      // obj['bayId'] = 1;
      this.alert
        .addalertMaster(this.userForm.value, obj)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            this.toastr.success(res.message, '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
          },
          error: (error) => {
            this.toastr.error(error.error.message);
            if (error.status == 401) {
              this.dialogRef.close();
            }
            this.visible = false;
          },
        });
    }
  }

  user_update_data() {
    console.log(this.data.alrtData);
    this.userForm.setValue({
      alertName: this.data.alrtData.alertName,
      minThreshold: this.data.alrtData.minThreshold,
      maxThreshold: this.data.alrtData.maxThreshold,
      maxThresholdWarning: this.data.alrtData.maxThresholdWarning,
      avgWaiting: this.data.alrtData.avgWaiting,
      facilityId: this.data.alrtData.facilityId,
      notifiedTo: this.data.alrtData.roleId,
      bayId: this.data.alrtData.bayId,
      alertDesc: this.data.alrtData.alertDesc
    });
    console.log(this.userForm.value)
  }

  userMasterupdate() {
    console.log(this.userForm.value);
    this.visible = true;
    const obj = {};
    obj['isActive'] = 1;
    obj['alertType'] = 'timeAlert';
    // obj['alertDesc'] = 'entry full';
    // obj['notifiedTo'] = 5;
    // obj['bayId'] = 1;
    this.alert
      .updatealert(this.userForm.value, obj, this.data.alrtData.Id)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          this.toastr.success(res.message, '', {
            progressBar: true,
            progressAnimation: 'decreasing',
          });
          this.visible = false;
          this.dialogRef.close();
        },
        error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
            this.dialogRef.close();
          }
          this.visible = false;
        },
      });

  }

  ngAfterContentInit() {
    this.cd.detectChanges();
  }
  onChange($event) {
    if ($event == '1') {
      this.cd.detectChanges();
      this.Selected_Default_value = 1;
    } else if ($event == '0') {
      this.cd.detectChanges();
      this.Selected_Default_value = 0;
    }
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
