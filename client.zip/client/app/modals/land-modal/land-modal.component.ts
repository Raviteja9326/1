import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { rowsAnimation } from 'client/app/shared/animations';
import { Totalexpand } from 'client/app/shared/search';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-land-modal',
  templateUrl: './land-modal.component.html',
  styleUrls: ['./land-modal.component.scss'],
  animations: [Totalexpand.search_animations, rowsAnimation],
})
export class LandModalComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  isLinear: boolean = false;
  expanded: boolean = false;
  isLoading: boolean = true;
  isLoading2: boolean = false;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild('paginator2') paginator2: MatPaginator;
  @ViewChild('sort2') sort2: MatSort;
  displayedColumns = [];
  result: any = [];
  constructor(
    public dialogRef: MatDialogRef<LandModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private datepipe: DatePipe
  ) { }
  onStepClick(event) {
    if (event.selectedIndex == 0) {
      this.getData4();
    }
    else if (event.selectedIndex == 1) {
      this.getData5();
    }
  }
  ngOnInit(): void {
    if (this.data.TrucksData2 != null || undefined) {
      this.isLoading2 = true;
      this.getRoutes();
    }
    else if (this.data.TrucksData != null || undefined) {
      this.isLoading2 = false;
      this.getRoutes2();
    }
    else if (this.data.alertpopup == true) {
      this.isLoading2 = false;
      this.displayedColumns = [
        'vehicleLicence',
        'alertName',
        'entryTime',
        'delayTime',
      ];
      this.getData4();
    }
  }

  getRoutes() {
    if (this.data.TrucksData2?.total >= 0 || null) {
      this.displayedColumns = [
        'vehicleLicence',
        'alertName',
        'entryTime',
        'delayTime'
      ];
      this.getData();
    }
    else if (this.data.TrucksData2?.totalPenalty >= 0 || null) {
      this.displayedColumns = [
        'vehicleLicence',
        'waitingTime',
        'penalty',
        'minThreshold',
        'maxThreshold',
        // 'maxThresholdWarning'
      ];
      this.getData1();
    }
  }

  getRoutes2() {
    this.displayedColumns = [];
    if (this.data.TrucksData.bayName == 'Total Trucks Entered') {
      this.displayedColumns = ['vehicleLicence', 'EntryIn'];
    }
    else if (this.data.TrucksData.bayName == 'Turn Around') {
      this.displayedColumns = [
        'vehicleLicence',
        'parkingWaiting',
        'loadingWaiting',
        'tarpingWaiting',
        'turnAroundWaiting',
        'eMinThreshold',
        'eMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.bayName == "Parking") {
      this.displayedColumns = [
        'vehicleLicence',
        'parkingWaiting',
        'pMinThreshold',
        'pMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.bayName == "Loading") {
      this.displayedColumns = [
        'vehicleLicence',
        'loadingWaiting',
        'lMinThreshold',
        'lMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.bayName == "Tarping") {
      this.displayedColumns = [
        'vehicleLicence',
        'tarpingWaiting',
        'tMinThreshold',
        'tMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.bayName == 'Trucks in Parking Bay') {
      this.displayedColumns = ['vehicleLicence', 'EntryIn', 'ParkingIn', 'parkingWaiting'];
    }
    else if (this.data.TrucksData.bayName == 'Trucks in Loading Bay') {
      this.displayedColumns = [
        'vehicleLicence',
        'EntryIn',
        'ParkingIn',
        'parkingWaiting',
        'LoadingIn',
        'loadingWaiting'
      ];
    }
    else if (this.data.TrucksData.bayName == 'Trucks in Tarping Bay') {
      this.displayedColumns = [
        'vehicleLicence',
        'EntryIn',
        'ParkingIn',
        'parkingWaiting',
        'LoadingIn',
        'loadingWaiting',
        'TarpingIn',
        'tarpingWaiting'
      ];
    } else if (this.data.TrucksData.bayName == 'Total Trucks Exited') {
      this.displayedColumns = [
        'vehicleLicence',
        'EntryIn',
        'ParkingIn',
        'parkingWaiting',
        'LoadingIn',
        'loadingWaiting',
        'TarpingIn',
        'tarpingWaiting',
        'turnAroundWaiting',
        'Exit'
      ];
    }
    else if (this.data.TrucksData.status.toLowerCase().includes("exit")) {
      this.displayedColumns = [
        'vehicleLicence',
        'parkingWaiting',
        'loadingWaiting',
        'tarpingWaiting',
        'turnAroundWaiting',
        'eMinThreshold',
        'eMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.status.toLowerCase().includes("parking in")) {
      this.displayedColumns = [
        'vehicleLicence',
        'parkingWaiting',
        'pMinThreshold',
        'pMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.status.toLowerCase().includes("loading in")) {
      this.displayedColumns = [
        'vehicleLicence',
        'loadingWaiting',
        'lMinThreshold',
        'lMaxThreshold'
      ];
    }
    else if (this.data.TrucksData.status.toLowerCase().includes("tarping in")) {
      this.displayedColumns = [
        'vehicleLicence',
        'tarpingWaiting',
        'tMinThreshold',
        'tMaxThreshold'
      ];
    }
    this.getData2();
  }

  getData2() {
    console.log(this.data.TrucksData.bayName);
    this.ELEMENT_DATA = this.data.TrucksData9;
    console.log(this.ELEMENT_DATA);
    if (this.ELEMENT_DATA.length != 0) {
      this.isLoading = false;
      this.displayNoRecords = false;
      this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
      setTimeout(() => {
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    } else if (this.ELEMENT_DATA.length == 0) {
      this.ELEMENT_DATA = [];
      this.dataSource = null;
      this.isLoading = false;
      this.displayNoRecords = true;
    }
  }

  getData1() {
    this.ELEMENT_DATA = this.data.TrucksData2.vehicles;
    if (this.ELEMENT_DATA.length != 0) {
      this.isLoading = false;
      this.displayNoRecords = false;
      this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
      setTimeout(() => {
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        // this.dataSource.filterPredicate = (data: any, filter: string) =>
        //   data.vehicleLicence.indexOf(filter) != -1;
      });
    } else if (this.ELEMENT_DATA.length == 0) {
      this.ELEMENT_DATA = [];
      this.dataSource = null;
      this.isLoading = false;
      this.displayNoRecords = true;
    }
  }
  getData4() {
    this.ELEMENT_DATA = [];
    this.ELEMENT_DATA = this.data.alertdata;
    console.log(this.ELEMENT_DATA)
    if (this.ELEMENT_DATA.length != 0) {
      this.isLoading = false;
      this.displayNoRecords = false;
      this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
      setTimeout(() => {
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    } else if (this.ELEMENT_DATA.length == 0) {
      this.ELEMENT_DATA = [];
      this.dataSource = null;
      this.isLoading = false;
      this.displayNoRecords = true;
    }
  }
  getData5() {
    this.ELEMENT_DATA = [];
    this.ELEMENT_DATA = this.data.alertdata2;
    console.log(this.ELEMENT_DATA)
    if (this.ELEMENT_DATA.length != 0) {
      this.isLoading = false;
      this.displayNoRecords = false;
      this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
      setTimeout(() => {
        this.dataSource.sort = this.sort2;
        this.dataSource.paginator = this.paginator2;
      });
    } else if (this.ELEMENT_DATA.length == 0) {
      this.ELEMENT_DATA = [];
      this.dataSource = null;
      this.isLoading = false;
      this.displayNoRecords = true;
    }
  }
  getData() {
    this.ELEMENT_DATA = this.data.TrucksData2.data;
    if (this.ELEMENT_DATA.length != 0) {
      this.isLoading = false;
      this.displayNoRecords = false;
      this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
      setTimeout(() => {
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        // this.dataSource.filterPredicate = (data: any, filter: string) =>
        //   data.vehicleLicence.indexOf(filter) != -1;
        // this.dataSource.filterPredicate = (data: any, filter: string) =>
        //   data.vehicleLicence.indexOf(filter) != -1;
      });
    } else if (this.ELEMENT_DATA.length == 0) {
      this.ELEMENT_DATA = [];
      this.dataSource = null;
      this.isLoading = false;
      this.displayNoRecords = true;
    }
  }
  applyFilter(event: Event) {
    this.result = [];
    let filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    for (let el of this.ELEMENT_DATA) {
      let EvehicleLicence = el.vehicleLicence;
      let EntryTime = this.datepipe.transform(el.EntryIn, 'MM/dd/YYYY HH:mm');
      let PincomingTime = this.datepipe.transform(el.ParkingIn, 'MM/dd/YYYY HH:mm');
      let PwaitingTime = JSON.stringify(el.parkingWaiting);
      let LincomingTime = this.datepipe.transform(el.LoadingIn, 'MM/dd/YYYY HH:mm');
      let LwaitingTime = JSON.stringify(el.loadingWaiting);
      let TincomingTime = this.datepipe.transform(el.TarpingIn, 'MM/dd/YYYY HH:mm',);
      let TwaitingTime = JSON.stringify(el.tarpingWaiting);
      let TurnAroundTime = JSON.stringify(el.turnAroundWaiting);
      let ExitTime = this.datepipe.transform(el.Exit, 'MM/dd/YYYY HH:mm');
      let waitingTime = JSON.stringify(el.waitingTime);
      var penalty = el.penalty;
      let minThreshold = JSON.stringify(el.minThreshold);
      let maxThreshold = JSON.stringify(el.maxThreshold);
      let delayTime = JSON.stringify(el.delayTime);
      let alertName = el.alertName;
      let entryTime = this.datepipe.transform(el.entryTime, 'dd-MM-YYYY');
      let parameterValue = JSON.stringify(el.parameterValue);
      let eMinThreshold = JSON.stringify(el.eMinThreshold);
      let eMaxThreshold = JSON.stringify(el.eMaxThreshold);
      let tMinThreshold = JSON.stringify(el.tMinThreshold);
      let tMaxThreshold = JSON.stringify(el.tMaxThreshold);
      let lMinThreshold = JSON.stringify(el.lMinThreshold);
      let lMaxThreshold = JSON.stringify(el.lMaxThreshold);
      let pMinThreshold = JSON.stringify(el.pMinThreshold);
      let pMaxThreshold = JSON.stringify(el.pMaxThreshold);

      // filter for truck entered
      if (this.data.TrucksData?.bayName == 'Total Trucks Entered') {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = EntryTime?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b==true) {
          this.result.push(el)
        }
      }
      // filter for truck exited
      if (this.data.TrucksData?.bayName == 'Total Trucks Exited' || this.data.TrucksData?.bayName == 'Trucks in Parking Bay' || this.data.TrucksData?.bayName == 'Trucks in Loading Bay' || this.data.TrucksData?.bayName == 'Trucks in Tarping Bay') {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = EntryTime?.toLocaleLowerCase().includes(filterValue)
        const c = PincomingTime?.toLocaleLowerCase().includes(filterValue)
        const d = PwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const e = LincomingTime?.toLocaleLowerCase().includes(filterValue)
        const f = LwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const g = TincomingTime?.toLocaleLowerCase().includes(filterValue)
        const h = TwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const i = TurnAroundTime?.toLocaleLowerCase().includes(filterValue)
        const j = ExitTime?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b == true || c == true || d == true || e == true || f == true || g == true || h == true || i == true || j==true) {
          this.result.push(el)
        }
      }

      // filter for penalty
      if (this.data.TrucksData2?.totalPenalty >= 0) {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const panlty = JSON.stringify(penalty.toFixed(2));
        const b = panlty?.toLocaleLowerCase().includes(filterValue)
        const c = waitingTime?.toLocaleLowerCase().includes(filterValue)
        const d = minThreshold?.toLocaleLowerCase().includes(filterValue)
        const e = maxThreshold?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b == true || c == true || d == true || e == true) {
          this.result.push(el)
        }
      }
      // filter for time alerts
      if (this.data.alertpopup == true) {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = delayTime?.toLocaleLowerCase().includes(filterValue)
        const alert = alertName?.toLowerCase();
        const c = alert?.toLocaleLowerCase().includes(filterValue)
        const d = entryTime?.toLocaleLowerCase().includes(filterValue)
        const e = parameterValue?.toLocaleLowerCase().includes(filterValue) // for occupancy alert
        if (a == true || b == true || c == true || d == true || e==true) {
          this.result.push(el)
        }
      }
      // filter for turn-around or exit
      if (this.data.TrucksData?.status?.toLowerCase().includes("exit") || this.data.TrucksData?.bayName == 'Turn Around') {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = PwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const c = LwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const d = TwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const e = TurnAroundTime?.toLocaleLowerCase().includes(filterValue)
        const f = eMinThreshold?.toLocaleLowerCase().includes(filterValue)
        const g = eMaxThreshold?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b == true || c == true || d == true || e == true || f == true || g == true) {
          this.result.push(el)
        }
      }
      // filter for tarping
      if (this.data.TrucksData?.status?.toLowerCase().includes("tarping in") || this.data.TrucksData?.bayName == 'Tarping') {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = TwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const c = tMaxThreshold?.toLocaleLowerCase().includes(filterValue)
        const d = tMinThreshold?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b == true || c == true || d == true) {
          this.result.push(el)
        }
      }
      // filter for loading
      if (this.data.TrucksData?.status?.toLowerCase().includes("loading in") || this.data.TrucksData?.bayName == 'Loading') {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = LwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const c = lMinThreshold?.toLocaleLowerCase().includes(filterValue)
        const d = lMaxThreshold?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b == true || c == true || d == true) {
          this.result.push(el)
        }

      }
      // filter for parking
      if (this.data.TrucksData?.status?.toLowerCase().includes("parking in") || this.data.TrucksData?.bayName == 'Parking') {
        const a = EvehicleLicence?.toLocaleLowerCase().includes(filterValue)
        const b = PwaitingTime?.toLocaleLowerCase().includes(filterValue)
        const c = pMinThreshold?.toLocaleLowerCase().includes(filterValue)
        const d = pMaxThreshold?.toLocaleLowerCase().includes(filterValue)
        if (a == true || b == true || c == true || d == true) {
          this.result.push(el)
        }
      }
    }
    if (this.result.length == 0) {
      this.dataSource = new MatTableDataSource<any>([]);
      this.dataSource.paginator = this.paginator;
    } else if (this.result.length !== 0) {
      this.dataSource = new MatTableDataSource<any>(this.result);
      this.dataSource.paginator = this.paginator;
      this.dataSource['sort'] = this.sort;
    }
    if (this._value == '') {
      this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA)
    }
  }

  onCancel() {
    this.dialogRef.close();
  }
  close() {
    this._value = '';
    this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA)
    this.dataSource.paginator = this.paginator;
    this.dataSource['sort'] = this.sort;
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search');
    }
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
}
