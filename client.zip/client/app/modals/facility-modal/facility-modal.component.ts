import { AfterContentInit, ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { FacilitymasterService } from 'client/app/services/facilitymaster.service';
import { spaceValidator } from 'client/app/shared/config';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-facility-modal',
  templateUrl: './facility-modal.component.html',
  styleUrls: ['./facility-modal.component.scss']
})
export class FacilityModalComponent implements OnInit, OnDestroy, AfterContentInit {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  Selected_Default_value: any;
  roleID: number;
  userdata:any;
  constructor(
    public dialogRef: MatDialogRef<FacilityModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private userService: FacilitymasterService,
    private toastr: ToastrService,
    private cd: ChangeDetectorRef,
    private storage: StorageService
  ) {
  }
  ngOnInit(): void {
    this.onChange(1);
    if (this.data.facupd == true) {
      this.user_update_data();
    }
    this.userdata = this.storage.getuser();
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  userForm = this.formBuilder.group({
    facilityDescription: ['', [Validators.required, spaceValidator]],
    facilityName: ['', [spaceValidator,Validators.required]]
  });

  onCancel() {
    this.dialogRef.close();
  }

 userMastersubmit() {
  if (!this.userForm.valid) {
    Object.keys(this.userForm.controls).forEach(field => {
      const control = this.userForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    this.visible = false
  }
    else if(this.userForm.valid){
      this.user_submit();
    }
  }
  user_submit() {
    this.visible = true;
    const obj = {};
    obj['isActive'] = this.Selected_Default_value;
    obj['createdBy'] = this.userdata.userId;
    obj['updatedBy'] = this.userdata.userId;
    obj['roleId'] = this.userdata.roleId;
    this.userService
      .addfacilityMaster(this.userForm.value, obj).pipe(takeUntil(this._destroying$))
      .subscribe({next:(res) => {
        this.toastr.success(res.message , '', {
          progressBar: true,
          progressAnimation: 'decreasing',
        });
        this.visible = false;
        this.dialogRef.close();
      },error: (error) => {
        this.toastr.error(error.error.message);
        if (error.status == 401) {
        this.dialogRef.close();}
        this.visible = false;
    }});
  }
  user_update_data() {
    console.log(this.data.facData)
    this.userForm.setValue({
      facilityName: this.data.facData.facilityName,
      facilityDescription: this.data.facData.facilityDescription
    });
    if (this.data.facData.isActive == false) {
      this.Selected_Default_value = false;
    } else if (this.data.facData.isActive == true) {
      this.Selected_Default_value = true;
    }
    console.log(this.userForm.value)
  }
  user_update() {
    this.visible= true;
    const obj = {};
    obj['isActive'] = this.Selected_Default_value;
    obj['updatedBy'] = this.userdata.userId;
    obj['facilityId'] = this.data.facData.facilityId;
    obj['roleId'] = this.userdata.roleId;
    this.visible = true;
    this.userService
      .updatefacilityMaster(this.userForm.value, obj).pipe(takeUntil(this._destroying$))
      .subscribe({next:(res) => {
        this.toastr.success(res.message , '', {
          progressBar: true,
          progressAnimation: 'decreasing',
        });
        this.visible = false;
        this.dialogRef.close();
      },error: (error) => {
        this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
        this.visible = false;
    }});
  }
  ngAfterContentInit() {
    this.cd.detectChanges();
  }
  onChange($event) {
    if ($event == '1') {
      this.cd.detectChanges();
      this.Selected_Default_value = true;
    } else if ($event == '0') {
      this.cd.detectChanges();
      this.Selected_Default_value = false;
    }
  }
}
