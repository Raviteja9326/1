import { Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Totalexpand } from 'client/app/shared/search';
import { MatSort } from '@angular/material/sort';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { rowsAnimation } from 'client/app/shared/animations';
import { ParkingyardService } from 'client/app/services/parkingyard.service';
import { DatePipe } from '@angular/common';
import { BayMasterService } from 'client/app/services/bay-master.service';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { ConnectionPositionPair } from '@angular/cdk/overlay';
import dayjs from 'dayjs/esm';
@Component({
  selector: 'app-trucklist-modal',
  templateUrl: './trucklist-modal.component.html',
  styleUrls: ['./trucklist-modal.component.scss'],
  animations: [Totalexpand.search_animations, rowsAnimation],
})
export class TrucklistModalComponent implements OnInit, OnDestroy {
  public positions = [
    new ConnectionPositionPair({
        originX: 'end',
        originY: 'top'},{
        overlayX: 'end',
        overlayY: 'bottom'},
         0,
         50)
];
  dataSource: MatTableDataSource<any>;
  private readonly _destroying$ = new Subject<void>();
  _value = '';
  expanded: boolean = false;
  isLoading: boolean = true;
  displayNoRecords: boolean = false;
  ELEMENT_DATA: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  userDetail: any;
  totalItems: number;
  currentDate = new Date();
  menus: string;
  menus2: string;
  displayedColumns: string[] = [];
  parking: any;
  loading: any;
  traping: any;
  pageIndex: number = 1;
  pageSize: number = 20;
  searchFilterFlags: any = {
    vehicleLicence: false,
    entry: false,
    waitingTime: false,
    pEntry: false,
    pExit: false,
    pWaitingTime: false,
    lEntry: false,
    lExit: false,
    lWaitingTime: false
  }
  searchParameters: any = {
    vehicleLicence: "",
    entry: "",
    waitingTime: null,
    pEntry: "",
    pExit: "",
    pWaitingTime: null,
    lEntry: "",
    lExit: "",
    lWaitingTime: null
  }
  sortParameters: any = {
    vehicleLicence: "",
    entry: "",
    waitingTime: "",
    pEntry: "",
    pExit: "",
    pWaitingTime: "",
    lEntry: "",
    lExit: "",
    lWaitingTime: ""
  }
  sortOrder: any = "";
  sortColumn: any = "";
  constructor(
    public dialogRef: MatDialogRef<TrucklistModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private sim_cust: ParkingyardService,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private Bay_cust: BayMasterService,
    private userser: StorageService
  ) { }
  ngOnInit(): void {
    this.getRoutes();
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
  refreshTable(){
    this.pageIndex=1;
    this.pageSize=20;
    this.searchParameters = {
      vehicleLicence: "",
      entry: "",
      waitingTime: null,
      pEntry: "",
      pExit: "",
      pWaitingTime: null,
      lEntry: "",
      lExit: "",
      lWaitingTime: null
    };
    this.searchFilterFlags = {
      vehicleLicence: false,
      entry: false,
      waitingTime: false,
      pEntry: false,
      pExit: false,
      pWaitingTime: false,
      lEntry: false,
      lExit: false,
      lWaitingTime: false
    };
    this.sortParameters = {
      vehicleLicence: "",
      entry: "",
      waitingTime: "",
      pEntry: "",
      pExit: "",
      pWaitingTime: "",
      lEntry: "",
      lExit: "",
      lWaitingTime: ""
    };
    this.sortColumn = "";
    this.sortOrder = "";
    this.getUser_master();
  }
  /* applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  } */
  onCancel() {
    this.dialogRef.close();
  }
  getRoutes() {
    this.displayedColumns = [];
    if (this.data.parkingadd == 'Parking') {
      this.menus = 'PARKING';
      this.menus2 = 'Parking In';
      this.displayedColumns = ['vehicleLicence', 'entry', 'parkentry', 'waitingTime'];
    } else if (this.data.bayadd == 'Loading') {
      this.menus = 'LOADING';
      this.menus2 = 'Loading In';
      this.displayedColumns = ['vehicleLicence', 'entrys', 'pEntry', 'pExit', 'pWaitingTime', 'entrydata', 'waitingTime'];
      console.log("llll", this.displayedColumns)
    } else if (this.data.bayadd == 'Tarping') {
      console.log("TTT")
      this.menus = 'TARPING';
      this.menus2 = 'Tarping In';
      this.displayedColumns = ['vehicleLicence', 'entrys', 'pEntry', 'pExit', 'pWaitingTime', 'lEntry', 'lExit', 'lWaitingTime', 'entry', 'waitingTime'];
      console.log("llll", this.displayedColumns)
    }
    this.getUserDetails();
  }
  getUserDetails() {
    this.userDetail = this.userser.getvariable();
    this.getbay_Master();
  }
  async getbay_Master() {
    const timedate = {};
    timedate['time'] = this.datePipe.transform(
      this.currentDate,
      'yyyy-MM-dd HH:mm:ss'
    );
    (timedate['stamp'] = Intl.DateTimeFormat().resolvedOptions().timeZone),
      await this.Bay_cust.getbay(timedate)
        .pipe(takeUntil(this._destroying$))
        .subscribe({
          next: (res) => {
            res.elements.map((data) => {
              data.map((data2) => {
                if (data2.facilityId == this.userDetail && data2.bayName == 'PARKING') {
                  this.parking = data2.bayId;
                }
                if (data2.facilityId == this.userDetail && data2.bayName == 'LOADING') {
                  this.loading = data2.bayId;
                }
                if (data2.facilityId == this.userDetail && data2.bayName == 'TARPING') {
                  this.traping = data2.bayId;
                }
              });
            });
            console.log(this.parking, this.loading, this.traping)
            this.getUser_master();
          },
          error: (error) => {
            this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
          },
        });
  }
  getUser_master(columnObj?) {
    this.ELEMENT_DATA = [];
    this.isLoading = true;
    const timedate = {};
    timedate['pageindex'] = this.pageIndex;
    timedate['pagesize'] = this.pageSize;
    timedate['filter'] = columnObj?columnObj:{"vehicleLicence":"","entry":"","waitingTime":"","pEntry":"","pExit":"","pWaitingTime":"","lEntry":"","lExit":"","lWaitingTime":""};
    timedate['sortColumn'] = this.sortColumn;
    timedate['sortOrder'] = this.sortParameters[this.sortColumn];
    timedate['timezone'] =  Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (this.data.parkingadd == 'Parking') {
      timedate['facilityId'] = this.userDetail;
      timedate['currentBayId'] = this.parking;
      timedate['status'] = this.menus2;
    } else if (this.data.bayadd == 'Loading') {
      timedate['facilityId'] = this.userDetail;
      timedate['currentBayId'] = this.loading;
      timedate['parkingId'] = this.parking;
      timedate['status'] = this.menus2;
    } else if (this.data.bayadd == 'Tarping') {
      timedate['facilityId'] = this.userDetail;
      timedate['currentBayId'] = this.traping;
      timedate['parkingId'] = this.parking;
      timedate['loadingId'] = this.loading;
      timedate['status'] = this.menus2;
    }
    this.sim_cust
      .getdashboardtruck(timedate)
      .pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (res) => {
          console.log(res.elements);
          this.ELEMENT_DATA = res.elements;
          if (res['elements'].length != 0) {
            this.isLoading = false;
            this.displayNoRecords = false;
            this.dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
            this.totalItems = res.metadata.total;
            setTimeout(() => {
              this.dataSource.sort = this.sort;
             // this.dataSource.paginator = this.paginator;
              // this.dataSource.filterPredicate = (data: any, filter: string) =>
              //   data.vehicleLicence.indexOf(filter) != -1;
            });
          } else if (res.elements.length == 0) {
            this.ELEMENT_DATA = [];
            this.dataSource = null;
            this.isLoading = false;
            this.displayNoRecords = true;
          }
        },
        error: (error) => {
          this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
        },
      });
  }
  close() {
    this._value = '';
    this.pageIndex = 1;
    this.pageSize = 20
    this.getUser_master();
  }
  onSearchClicked() {
    if (!this.expanded) {
      this.expanded = true;
    } else {
      console.log('search');
    }
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }
  pageChanged(event) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    let columnWiseFilterPresent = this.checkColumnFiltersPresent();
    let columnObj=null;
    if(columnWiseFilterPresent){
      columnObj = {...this.searchParameters};
    }
    let time = new Date();
    if(this.searchParameters.entry){
      columnObj.entry = this.datePipe.transform(dayjs(columnObj.entry).toString(), 'yyyy-MM-dd');
      columnObj.entry = columnObj.entry+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    if(this.searchParameters.pEntry){
      columnObj.pEntry = this.datePipe.transform(dayjs(columnObj.pEntry).toString(), 'yyyy-MM-dd');
      columnObj.pEntry = columnObj.pEntry+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    if(this.searchParameters.pExit){
      columnObj.pExit = this.datePipe.transform(dayjs(columnObj.pExit).toString(), 'yyyy-MM-dd');
      columnObj.pExit = columnObj.pExit+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    this.getUser_master(columnObj);
  }
  initializePaginator(){
    this.pageIndex = 1;
    this.pageSize = 20;
  }
  applyFilter() {
    console.log(this.searchParameters);
    this.initializePaginator();
    let columnWiseFilterPresent = this.checkColumnFiltersPresent();
    let columnObj=null;
    if(columnWiseFilterPresent){
      columnObj = {...this.searchParameters};
    }
    let time = new Date();
    if(this.searchParameters.entry){
      columnObj.entry = this.datePipe.transform(dayjs(columnObj.entry).toString(), 'yyyy-MM-dd');
      columnObj.entry = columnObj.entry+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    if(this.searchParameters.pEntry){
      columnObj.pEntry = this.datePipe.transform(dayjs(columnObj.pEntry).toString(), 'yyyy-MM-dd');
      columnObj.pEntry = columnObj.pEntry+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    if(this.searchParameters.pExit){
      columnObj.pExit = this.datePipe.transform(dayjs(columnObj.pExit).toString(), 'yyyy-MM-dd ');
      columnObj.pExit = columnObj.pExit+" "+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
    }
    // if(this.searchParameters.waitingTime){
    //   columnObj.waitingTime =
    // }
    this.getUser_master(columnObj);
   }
  onSortChanged(event) {
    this.sortColumn = event;
    let tempSortParameters = {
      vehicleLicence: "",
      entry: "",
      waitingTime: "",
      pEntry: "",
      pExit: "",
      pWaitingTime: "",
      lEntry: "",
      lExit: "",
      lWaitingTime: ""
    };
    this.sortParameters[this.sortColumn] = this.sortParameters[this.sortColumn] != 'asc'
      && this.sortParameters[this.sortColumn] != 'desc' ?
      'asc' : this.sortParameters[this.sortColumn] == 'asc' ? 'desc' : "";
    tempSortParameters[this.sortColumn] = this.sortParameters[this.sortColumn];
    this.sortParameters = { ...tempSortParameters };
    this.applyFilter();
  }
refactorFilterObj(obj){
let templateFilterObj = {
  vehicleLicence: "",
  entry: "",
  waitingTime: "",
  pEntry: "",
  pExit: "",
  pWaitingTime: "",
  lEntry: "",
  lExit: "",
  lWaitingTime: ""
};
templateFilterObj.vehicleLicence = obj.vehicleLicence;
templateFilterObj.entry = obj.entry?obj.entry:obj.parkentry?obj.parkentry:obj.entrydata?obj.entrydata:"";
templateFilterObj.waitingTime = obj.waitingTime;
templateFilterObj.pEntry = obj.pEntry?obj.pEntry:obj.entrys?obj.entrys:"";
templateFilterObj.pExit = obj.pExit;
templateFilterObj.pWaitingTime = obj.pWaitingTime;
templateFilterObj.lEntry = obj.lEntry;
templateFilterObj.lExit = obj.lExit;
templateFilterObj.lWaitingTime = obj.lWaitingTime;

return templateFilterObj;
}
checkColumnFiltersPresent(){
  if(this.searchParameters.vehicleLicence || this.searchParameters.entry || this.searchParameters.parkentry
    || this.searchParameters.waitingTime || this.searchParameters.entrys || this.searchParameters.pEntry
    || this.searchParameters.pExit || this.searchParameters.pWaitingTime || this.searchParameters.lEntry
    || this.searchParameters.lWaitingTime
    ){
    return true;
  }
  return false;
}
}
