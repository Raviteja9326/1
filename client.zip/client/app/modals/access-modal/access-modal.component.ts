import {
  Component,
  OnInit,
  Inject,
} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { AccessMasterService } from 'client/app/services/access-master.service';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-access-modal',
  templateUrl: './access-modal.component.html',
  styleUrls: ['./access-modal.component.scss'],
})
export class AccessModalComponent implements OnInit {
  visible: boolean = false;
  private readonly _destroying$ = new Subject<void>();
  dataSource = MatTableDataSource<any>;
  moduleIDs: any = [];
  ReportIDs: any = [];
  AdminIDs: any = [];

  userdata:any;

  constructor(public dialogRef: MatDialogRef<AccessModalComponent>, @Inject(MAT_DIALOG_DATA) public data: any = [], private formBuilder: FormBuilder, private toastr: ToastrService, private accessService: AccessMasterService, private storage:StorageService) {
  }

  ngOnInit(): void {
    this.userdata = this.storage.getuser();
    if (this.data.dataupdate == true){
     this.getdatacomp();
    }
  }

  accessForm = this.formBuilder.group({
    role: ['', [Validators.required]],
    dashbaord: [[{}]],
    report: [[{}]],
    admin: [[{}]],
  });

  onCancel() {
    this.dialogRef.close();
  }

  getdatacomp(){
    console.log(this.data.accessData);
    this.moduleIDs = this.data.accessData.data.dashboard;
    this.ReportIDs = this.data.accessData.data.report;
    this.AdminIDs = this.data.accessData.data.admin;
    this.getcheckedvalue();
  }

  getcheckedvalue(){
    const initialSelectedValues1 = this.moduleIDs.filter(option => option.isAssigned === 1).map(option => option.moduleid);
    const initialSelectedValues2 = this.ReportIDs.filter(option => option.isAssigned === 1).map(option => option.moduleid);
    const initialSelectedValues3 = this.AdminIDs.filter(option => option.isAssigned === 1).map(option => option.moduleid);
    this.accessForm.setValue({
      'role': this.data.accessData.Role.roleName,
      'dashbaord' : initialSelectedValues1,
      'report' : initialSelectedValues2,
      'admin' : initialSelectedValues3
    })
  }

  getDataForUpdate() {
    // console.log(this.accessForm.value)
      const moduleIDs = this.accessForm.value.dashbaord.map(id1 => this.moduleIDs.find(obj1 => obj1.moduleid === id1));
      const ReportIDs = this.accessForm.value.report.map(id2 => this.ReportIDs.find(obj2 => obj2.moduleid === id2));
      const AdminIDs = this.accessForm.value.admin.map(id3 => this.AdminIDs.find(obj3 => obj3.moduleid === id3));
     this.getSubmit(moduleIDs, ReportIDs, AdminIDs);
  }

  getSubmit(mod,rep,adm){
    this.visible = true;
    const obj = {};
    obj['role'] = this.data.accessData.Role;
    obj['dashbaord'] = mod;
    obj['report'] = rep;
    obj['admin'] = adm;
    obj['updatedBy'] = this.userdata.userId;
    console.log(obj)
    this.accessService.saveAccessData(obj).pipe(takeUntil(this._destroying$)).subscribe({next:(res) => {
      this.toastr.success(res.message , '', {
        progressBar: true,
        progressAnimation: 'decreasing',
      });
      this.visible = false;
      this.dialogRef.close();
    },error: (error) => {
      this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
      this.visible = false;
  }})
  }
}
