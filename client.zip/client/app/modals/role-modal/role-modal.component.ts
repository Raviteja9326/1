import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { RoleService } from 'client/app/services/role.service';
import { Subject, takeUntil } from 'rxjs';
import { StorageService } from 'client/app/core/interceptor/storage.service';
@Component({
  selector: 'app-role-modal',
  templateUrl: './role-modal.component.html',
  styleUrls: ['./role-modal.component.scss'],
})
export class RoleModalComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  roleName: string;
  description: string;
  userdata:any;
  constructor(
    public dialogRef: MatDialogRef<RoleModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private roleService: RoleService,
    private toastr: ToastrService,
    private storage: StorageService
  ) {}
  roleForm = this.formBuilder.group({
    roleName: [
      '',
      [Validators.required, Validators.minLength(4), Validators.maxLength(20)],
    ],
    roleDescription: [
      '',
      [Validators.required, Validators.minLength(4), Validators.maxLength(100)],
    ],
  });
  ngOnInit(): void {
    this.userdata = this.storage.getuser();
    if(this.data.dataupdate == true){
    this.Update_roledata();
    }
  }
  onCancel() {
    this.dialogRef.close();
  }
  rolesubmit() {
    if (this.roleForm.valid) {
      this.visible = true;
      let roleData = {};
      roleData['roleName'] = this.roleForm.value.roleName;
      roleData['roleDescription'] = this.roleForm.value.roleDescription;
      roleData['createdBy'] = this.userdata.userId;
      roleData['crratetime'] = this.userdata.userId;
      this.roleService
        .addRole(roleData)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next: (res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
      if (error.status == 401) {
      this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  roleupdate() {
    if (this.roleForm.valid) {
      this.visible = true;
      let roleData = {};
      roleData['roleId'] = this.data.roleData.roleId;
      roleData['roleName'] = this.roleForm.value.roleName;
      roleData['roleDescription'] = this.roleForm.value.roleDescription;
      roleData['updatedBy'] = this.userdata.userId;
      this.roleService
        .updateRole(roleData)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next:(res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
          this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  Update_roledata() {
    if (this.data.dataupdate == true) {
      console.log(this.data.roleData)
      this.roleForm.setValue({
        roleName: this.data.roleData.roleName,
        roleDescription: this.data.roleData.roleDescription,
      });
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
