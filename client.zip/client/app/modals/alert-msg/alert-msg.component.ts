import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { RoleService } from 'client/app/services/role.service';
import { spaceValidator, MustMatch } from 'client/app/shared/config';
import { OwlOptions, SlidesOutputData } from 'ngx-owl-carousel-o';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { AllinoneService } from 'client/app/services/allinone.service';
@Component({
  selector: 'app-alert-msg',
  templateUrl: './alert-msg.component.html',
  styleUrls: ['./alert-msg.component.scss']
})
export class AlertMsgComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  visible: boolean = false;
  constructor(
    public dialogRef: MatDialogRef<AlertMsgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private cam_ser:RoleService,
    private store: StorageService,
    private allone: AllinoneService
  ) {}

  roleForm = this.formBuilder.group({
    password: ['',[Validators.required, spaceValidator,Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]  ],
    ConfirmPassword: ['', [Validators.required]],
  },{
    validator: MustMatch('password', 'ConfirmPassword')
  });
  siteForm = this.formBuilder.group({
    siteName: ['', [Validators.required]]
  });
  ngOnInit(): void {}
  onCancel() {
    this.dialogRef.close();
  }
  rolesubmit() {
    if (this.roleForm.valid) {
      this.visible = true;
      const authorizationData = btoa(JSON.stringify(this.roleForm.value.password));
      const roleData = {};
      roleData['password'] = authorizationData;
      roleData['notificationId'] = this.data.alertdata.notificationId;
      roleData['userId'] = this.data.alertdata.userId;
      this.cam_ser
        .changepwd(roleData)
        .pipe(takeUntil(this._destroying$))
        .subscribe({next: (res) => {
            this.toastr.success(res.message , '', {
              progressBar: true,
              progressAnimation: 'decreasing',
            });
            this.visible = false;
            this.dialogRef.close();
        },error: (error) => {
          this.toastr.error(error.error.message);
          if (error.status == 401) {
          this.dialogRef.close();}
          this.visible = false;
      }});
    }
  }
  closeDialog(): void {
    if (!this.siteForm.valid) {
      Object.keys(this.siteForm.controls).forEach(field => {
        const control = this.siteForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    }
    else if (this.siteForm.valid) {
      this.store.variable(this.siteForm.value.siteName);
      this.dialogRef.close({ result: this.siteForm.value.siteName});
    }
  }
  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
