import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorsComponent } from './errors/errors.component';
import { ngxUiLoaderConfig } from './shared/config'
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { NgxUiLoaderConfig, NgxUiLoaderModule, NgxUiLoaderRouterModule } from 'ngx-ui-loader';
import { RemoveWhiteSpacePipe } from './shared/remove_space';
import { ToastrModule } from 'ngx-toastr';
import { AuthInterceptor } from './core/interceptor/auth.interceptor';
const ngxUiLoaderConfigs: NgxUiLoaderConfig = ngxUiLoaderConfig
@NgModule({
  declarations: [
    AppComponent,
    ErrorsComponent,
    RemoveWhiteSpacePipe,
  ],
  imports: [
    ToastrModule.forRoot({
      maxOpened: 1,
      preventDuplicates: true
    }),
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    NgxUiLoaderRouterModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfigs)
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
