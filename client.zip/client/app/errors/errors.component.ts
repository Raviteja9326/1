import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-errors',
  templateUrl: './errors.component.html',
  styleUrls: ['./errors.component.sass']
})
export class ErrorsComponent implements OnInit {

  constructor(private dialog: MatDialog) { }

  ngOnInit(): void {
    if(this.dialog){
      this.dialog.closeAll();
    }
  }

}
