import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient) {}

    getRoles(){
      return this.http
      .get<any>(`${Creditianls.redirectUriendpoint}/getRoles`,{
        headers: this.requestHeader,
      }).pipe(timeout(60000),retry(1))
    }
    getnotifications(data){
      return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/notification/list`, data,{
        headers: this.requestHeader,
      }).pipe(timeout(60000),retry(1))
    }
    addRole(data){
      return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/createRole`,data,{
        headers: this.requestHeader,
      }).pipe(timeout(60000),retry(1))
    }
    changepwd(data){
      return this.http
      .put<any>(`${Creditianls.redirectUriendpoint}/password/${data.userId}`,data,{
        headers: this.requestHeader,
      }).pipe(timeout(60000),retry(1))
    }
    updateRole(data){
      return this.http
      .put<any>(`${Creditianls.redirectUriendpoint}/upadteRole`,data,{
        headers: this.requestHeader,
      }).pipe(timeout(60000),retry(1))
    }
    getUserRoles(){
      return this.http
      .get<any>(`${Creditianls.redirectUriendpoint}/userAccess`)
    }
  }




