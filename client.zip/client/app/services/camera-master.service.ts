import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class CameraMasterService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient) { }

  getcameramaster(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getCameraDetails`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getcameramasterID(id){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getCameraByFacilityId/${id}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  addcameraMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/createCamera`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  updatecameraMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/updateCameraRecord`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}
