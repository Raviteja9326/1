import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { retry, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class ParkingyardService {

  constructor(private http: HttpClient) { }
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  getdashboardDetails2(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/details`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  getdashboardtruck(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/truck/list?page=${obj.pageindex}&page_size=${obj.pagesize}`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  getdashboardList(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/list?page=${obj.page}&page_size=${obj.page_size}`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  getGraph(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/chart`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  getAlertAlarms(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/alert/list?page=${obj.pageindex}&page_size=${obj.pagesize}`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  getJobCard(page, page_size) {
    return this.http
      .get<any>(`${Creditianls.redirectUriendpoint}/parking/list?page=${page}&page_size=${page_size}`, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
}
