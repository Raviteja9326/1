import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { catchError, retry, throwError, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class AccessMasterService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient) {}

  saveAccessData(data){
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/updateRoleMapping`,data,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getAccessDetail(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getDashboardRoleAccess`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getAccessDetail2(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getAssignmentRecords`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

}
