import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, retry, timeout } from 'rxjs';
import { StorageService } from '../core/interceptor/storage.service';
import { Creditianls } from '../shared/config';
import { ReportsService } from './reports.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class LoginService {

constructor( private http: HttpClient, private router:Router ,private userAuthService:StorageService, private report:ReportsService) {}

  useremaillogin(data): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
    };
    return this.http.get<any>(`${Creditianls.redirectUriloginendpoint}/login?email=${data.email}&password=${data.cred}`,httpOptions)
  }

  useremail(data): Observable<any> {
    const headers = new HttpHeaders({ 'skipInterceptor': 'true' });
    return this.http.post<any>(`${Creditianls.redirectUriendpoint}/admin/contact`, data, {headers})
  }

  getlogoutiffailed() {
    this.report.logout(this.userAuthService.getuser().userId).subscribe(res=>{
      console.log(res)
    })
    this.router.navigate(['/login']);
  }

}