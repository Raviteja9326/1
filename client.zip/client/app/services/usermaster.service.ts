import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { retry, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class UsermasterService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient, private ngxLoader: NgxUiLoaderService, private router: Router) { }

  getUsermaster(data){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/users?dt=${data.time}&timezone=${data.stamp}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  adduserMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/user`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  updateuserMaster(data,data2,data3){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/user/${data3}`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getRoles(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getRoles`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}
