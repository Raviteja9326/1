import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class FacilitymasterService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient) { }

  getfacilitymaster(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/facility/list`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getFacilityByRole(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getFacilityByRole`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  addfacilityMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/facility`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  updatefacilityMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/facility/${data2.facilityId}`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}
