import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BehaviorSubject, catchError, retry, throwError, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class LoadingbayService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http: HttpClient, private ngxLoader: NgxUiLoaderService, private router: Router, private toastr: ToastrService) { 
    var currentdate = new Date();
    var date = currentdate.getFullYear() + "-"
      + String(currentdate.getMonth() + 1).padStart(2, '0') + "-"
      + currentdate.getDate() + "%"
      + currentdate.getHours() + ":"
      + currentdate.getMinutes() + ":"
      + currentdate.getSeconds();
    let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
// observable for getting dashboard details starts
  private subsSource = new BehaviorSubject<any>(undefined);
  subs$ = this.subsSource.asObservable();

  getSubsSource(): BehaviorSubject<any> {
      return this.subsSource;
  }
  
  setSubsSource(param: any) {
      this.subsSource.next(param);
  }
// observable for getting dashboard details ends

  getSlots(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/details`,obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getdashboardDetails(obj) {
      return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/details`,obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }


  getdashboardList(page, page_size,obj) {
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/list?page=${page}&page_size=${page_size}`,obj, {
      headers: this.requestHeader,
    }).pipe(timeout(60000), retry(1))
}

  getUpdate(plantID) {
    return this.http
      .get<any>(`${Creditianls.redirectUriendpoint}/dashboard/dataUpdate/${plantID}`)
  }

  getGraphbyweek(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/chart`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getGraphbyday(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/chart`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  // getJobEdit(data) {
  //   return this.http
  //     .put<any>(`${Creditianls.redirectUriendpoint}/JobCard/stopWaitTime`, data)
  // }
}
