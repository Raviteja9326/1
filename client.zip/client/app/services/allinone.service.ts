import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AllinoneService {
  public reportsData = new BehaviorSubject('0');
  public UpdatedData = new BehaviorSubject('0');
  public alertData = new BehaviorSubject('0');
  public customerData = new BehaviorSubject('0');
  public customerArrivalData = new BehaviorSubject('0');
  arrivalCustomerData = this.customerArrivalData.asObservable();
  public alertOccupancyData = new BehaviorSubject('0');
  public customerTileData = new BehaviorSubject('0');
  tilesCustomerData = this.customerTileData.asObservable();
  public customerOccupancyData = new BehaviorSubject('0');
  occupancyCustomerData = this.customerOccupancyData.asObservable();
  public vehicleCountData = new BehaviorSubject('0');
  countVehicleData = this.vehicleCountData.asObservable();
  public vehicleArrivalData = new BehaviorSubject('0');
  ArrivalVehicleData = this.vehicleArrivalData.asObservable();
  public parkingTrendData = new BehaviorSubject('0');
  parkingData = this.parkingTrendData.asObservable();
  public servicingTrendData = new BehaviorSubject('0');
  servicingData = this.servicingTrendData.asObservable();
  public pdf_bol =true;
  public excel_bol =true;
  constructor(private http: HttpClient) {}
  // observable for bayIds starts
  private subsSource = new BehaviorSubject<any>(undefined);
  subs$ = this.subsSource.asObservable();
  private siteStub = new BehaviorSubject<any>(undefined);
  siteSource$ = this.siteStub.asObservable();
  private alertGraphStub = new BehaviorSubject<any>(undefined);
  alertGraphStubSource$ = this.alertGraphStub.asObservable();
  clickSubject = new BehaviorSubject(null);
  clickSubjectMonth = new BehaviorSubject(null);
  clickSubjectAlert = new BehaviorSubject(null);
  private alertSource = new BehaviorSubject<any>(undefined);
  alertSource$ = this.alertSource.asObservable();
  getSubsSource(): BehaviorSubject<any> {
    return this.subsSource;
  }

  setSubsSource(param: any) {
     this.subsSource.next(param);
  }

  setSourceStub(data:any){
    this.siteStub.next(data);
  }
  getSourceStub(){
    return this.siteStub;
  }
  setAlertGraphStub(data:any){
    this.alertGraphStub.next(data);
  }
  getAlertGraphSourceStub(){
    return this.alertGraphStub;
  }
  getAlertSource(): any{
    return JSON.parse(sessionStorage.getItem("alert-reports-excel-data"));
  }

  setAlertSource(param: any) {
     sessionStorage.setItem("alert-reports-excel-data",JSON.stringify(param));
  }

  // observable for bayIds ends
  setUpdateddata(list: string) {
    this.UpdatedData.next(list);
  }

  getReportsdata(list) {
    this.reportsData.next(list);
  }

  getCustomerdata(list) {
    this.customerData.next(list);
  }

  getAlertdata(list) {
    this.alertData.next(list);
  }

  getCustomerArrivalData(list){
  this.customerArrivalData.next(list);
  }

  getCustomerTilesData(list){
    this.customerTileData.next(list);
    }

  getCustomerOccupancyData(list){
      this.customerOccupancyData.next(list);
    }

    getVehicleCountData(list){
      this.vehicleCountData.next(list)
    }

    getVehicleArrivalData(list){
      this.vehicleArrivalData.next(list)
    }

    getParkingData(list){
      this.parkingTrendData.next(list)
    }

    getServicingData(list){
      this.servicingTrendData.next(list)
    }

    getAlertOccupancydata(list) {
      this.alertOccupancyData.next(list);
    }
}
