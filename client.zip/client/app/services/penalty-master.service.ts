import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class PenaltymasterService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient) { }

  getfacilitymaster(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/penalty?facilityId=1`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  addfacilityMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/penalty`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  updatefacilityMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/facility/${data2.updatedBy}`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getpenaltytable(data){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/penaltyReport`,data,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getpenaltytablegrapgh(data){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/getPenaltyReportTable?page=${data.pageindex}&page_size=${data.pagesize}`,data,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}
