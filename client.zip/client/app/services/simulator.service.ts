import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class SimulatorService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http: HttpClient) { }


  getallsimulator2(data) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getVehicleByStatus?page=${data.pageindex}&page_size=${data.pagesize}`, data, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  addentry(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/entrySimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  addparking(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/parkingSimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  addload1(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/loadingSimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  addload2(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/loading2Simulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  addload3(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/loading3Simulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  addload4(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/loading4Simulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  adddock(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/dockSimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  addtrapinin(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/tarpingSimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  addtrapinout(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/tarpingExitSimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
  addexit(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/exitSimulation`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  simulatedata(data) {
    const obj2 = Object.assign({}, data);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getScenerio1Data`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  simulatedata2(data) {
    // const obj2 = Object.assign({}, data);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getScenerio2Data`, data, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  simulatedata3(data, data2) {
    const obj2 = Object.assign({}, data,data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getNewScenerio3Data`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
}
