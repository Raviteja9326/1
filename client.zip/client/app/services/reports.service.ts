import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { retry, catchError, throwError, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  datak:any = null
  constructor(private http:HttpClient, private ngxLoader: NgxUiLoaderService,private router: Router) { }



  reportsParking(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/parkingYardTrends/custom/${data}`,data2)
  }


  reportsTiles(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/customTiles/${data}`,data2)
  }

  customerTiles(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/customTiles/partsCounter/${data}`,data2)
  }

  reportsPie(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/customPieChart/${data}`,data2)
  }

  customerPie(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/customPieChart/partsCounter/${data}`,data2)
  }

  reportsService(data, data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/servicingBayTrends/custom/${data}`,data2)
  }

  customerService(data, data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/reportScreen/partsCounterCustomTrends/${data}`,data2)
  }

  reportsalerts(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/history/report/list?page=${data.pageIndex}&page_size=${data.pageSize}`,data2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
  weekwiseAlerts(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/waitingTimeWeekList`,data2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
  Dashboardreports(data, data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/dashboard/homePage/${data}`,data2)
  }
  logout(data){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/logout/${data}`,this.datak,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}


