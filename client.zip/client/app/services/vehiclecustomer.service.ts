import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { catchError, Observable, retry, throwError, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class VehiclecustomerService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private http:HttpClient) { }

  getVehicle(data): Observable<any>{
    return this.http
    .get(`${Creditianls.redirectUriendpoint}/vehicle/list?page=${data.pageIndex}&page_size=${data.pageSize}&search=${data._value}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  addVehicle(data){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/vehicle`,data,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  updateVehicle(data,data2){
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/vehicle/${data2.id}`,data,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
  getVehicleforReport(data){
    return this.http
    .get(`${Creditianls.redirectUriendpoint}/vehicle/list/${data.facilityId}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}
