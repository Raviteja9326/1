import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { retry, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class WaitingTimemasterService {

  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private http:HttpClient) { }

  addalertMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/waitingtimealerttype`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  // getAlertList(data){
  //   return this.http
  //   .get<any>(`${Creditianls.redirectUriendpoint}/alert/list?page=${data.pageIndex}&page_size=${data.pageSize}&search=${data._value}`,{
  //     headers: this.requestHeader,
  //   }).pipe(timeout(60000),retry(1))
  // }

  // updatealert(data,data2,data3){
  //   const obj2 = Object.assign({}, data,data2);
  //   return this.http
  //   .put<any>(`${Creditianls.redirectUriendpoint}/alert/${data3}`,obj2,{
  //     headers: this.requestHeader,
  //   }).pipe(timeout(60000),retry(1))
  // }

  getWaitingTimeAlert(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/waitingtimealerttype`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

}



