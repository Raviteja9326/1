import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class BayMasterService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private http:HttpClient) { }

  getbay(date){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/locationBay/list?dt=${date.time}&timezone=${date.stamp}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
  getbaybyid(data){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/activebay?facilityId=${data}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getbaybyid1(data){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getOccupancyBay?facilityId=${data}`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getbay1(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/bayReport`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  addBayMaster(data,data2){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/locationBay`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
  updatebayMaster(data,data2,data3){
    const obj2 = Object.assign({}, data,data2);
    return this.http
    .put<any>(`${Creditianls.redirectUriendpoint}/locationBay/${data3}`,obj2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }
}
