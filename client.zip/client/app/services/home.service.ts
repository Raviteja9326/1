import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timeout, retry } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: HttpClient) { }
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  getlandDetails(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/todayVehicleReport`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getminmax(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getVehiclesMinMaxThreshold`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getallroles(){
    return this.http
    .get<any>(`${Creditianls.redirectUriendpoint}/getUserAccessDetails`,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  gealerts(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/todayPenaltyAlerts`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getoverall(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/overWaitingVehicleReport`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getpenalty(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/landing/penalty/chart`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getchart(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/landing/chart`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getpenaltycharges(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getPenaltyForLandingPage`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }

  getind(obj) {
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/getVehicleDataByStatus`, obj, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1))
  }
}
