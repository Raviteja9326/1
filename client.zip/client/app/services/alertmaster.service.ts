import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, retry, timeout } from 'rxjs';
import { Creditianls } from '../shared/config';

@Injectable({
  providedIn: 'root',
})
export class AlertmasterService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private http: HttpClient) { }



  addalertMaster(data, data2) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .post<any>(`${Creditianls.redirectUriendpoint}/alert`, obj2, {
        headers: this.requestHeader,
      }).pipe(timeout(60000), retry(1));
  }

  getallAlert(data){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/getLatestAlert`,data, {
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getAcknowledge(data){
    console.log(data)
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/acknowledgeAlert`, data,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getAlertList(data,data2){
    return this.http
    .post<any>(`${Creditianls.redirectUriendpoint}/alert/list?page=${data.pageIndex}&page_size=${data.pageSize}`,data2,{
      headers: this.requestHeader,
    }).pipe(timeout(60000),retry(1))
  }

  getAlertReport(pageIndx, pageSize, data) {
      return this.http
        .post<any>(
          `${Creditianls.redirectUriendpoint}/alertReport?page=${pageIndx}&page_size=${pageSize}`, data,
          {
            headers: this.requestHeader,
          }
        )
        .pipe(timeout(60000), retry(1));
  }
  // &vehicleId=${data.vehicleLicence}
  //localhost:3000/api/v1/alert/list?page=1&facilityId=1&vehicleId=30&startDate=2023-03-01&endDate=2023-03-11&page_size=19

  updatealert(data, data2, data3) {
    const obj2 = Object.assign({}, data, data2);
    return this.http
      .put<any>(`${Creditianls.redirectUriendpoint}/alert/${data3}`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(timeout(60000), retry(1));
  }
}
