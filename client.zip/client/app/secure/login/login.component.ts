import { Component, OnDestroy, OnInit} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { StorageService } from 'client/app/core/interceptor/storage.service';
import { LoginService } from 'client/app/services/login.service';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnDestroy{
visible:boolean = false;
loading:boolean = false;
destroy$: Subject<boolean> = new Subject<boolean>();
skeletonloader: boolean = false;
names: any;
constructor( private login: LoginService, private router: Router, private userAuthService: StorageService, private toastr: ToastrService, private dialog: MatDialog){
  this.dialog.closeAll();
  this.userAuthService.clear();
  if(localStorage.getItem('data') != null){
    const obj = JSON.parse(localStorage.getItem('data'));
    this.loginform.setValue({
     emailId : obj['email'],
     cred: JSON.parse(atob(obj['cred'])),
     Remember : true
    })
   }
   else{
     this.loginform.reset();
   }
}
loginform = new FormGroup({
  emailId: new FormControl('', [
    Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),
    Validators.required,
  ]),
  cred: new FormControl('', [ Validators.required]),
  Remember : new FormControl (false)
});
get ware_login() {
  return this.loginform.controls;
}
loginform2 = new FormGroup({
  emailId: new FormControl('', [
    Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),
    Validators.required,
  ])
});
get ware_login2() {
  return this.loginform2.controls;
}
LoginUser() {
  this.visible = true;
  let userobj = [];
  const authorizationData = btoa(JSON.stringify(this.loginform.value.cred));
  const userobj2= {};
  userobj2['email'] = this.loginform.value.emailId;
  userobj2['cred'] = authorizationData;
  userobj2['remember'] = this.loginform.value.Remember;
  this.login.useremaillogin(userobj2).pipe(takeUntil(this.destroy$))
  .subscribe({next: (data: any )=> {
   if(data.message =="Authenticated Successfully...."){
    this.visible = false;
    data.userDetails.map((res=> {
      userobj = res
    }));
    if(this.loginform.value.Remember == true){
    localStorage.setItem('data', JSON.stringify(userobj2));
    }
    else if(this.loginform.value.Remember == false){
      localStorage.clear();
    }
    this.userAuthService.setToken(data.token);
    this.userAuthService.setusername(userobj);
    this.userAuthService.setRoles(userobj['roleId'])
    this.names = this.userAuthService.getuser();
    this.router.navigate(['/dashboard']);
   }
  },error: (error) => {
    this.toastr.error(error.error.message)
    this.visible = false;
}})
}
showadmin(data){
  this.loginform2.reset();
  if(data==true){
    this.loading = true;
  }
  else if(data==false){
    this.loading = false;
  }
}
LoginUser2() {
  this.visible = true;
  const userobj2= {};
  userobj2['email'] = this.loginform2.value.emailId;
  this.login.useremail(userobj2).pipe(takeUntil(this.destroy$))
  .subscribe({next: (data: any )=> {
    this.toastr.success(data.message)
    this.visible = false;
    this.showadmin(false)
  },error: (error) => {
    this.toastr.error(error.error.message)
    this.visible = false;
}})
}
ngOnDestroy(): void {
  this.destroy$.next(undefined);
  this.destroy$.complete();
}
}
