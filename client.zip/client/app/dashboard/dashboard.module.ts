import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { ToggleFullscreenDirective } from '../shared/maximize';
import { AllModule } from '../shared/all_modules';


@NgModule({
  declarations: [DashboardComponent,ToggleFullscreenDirective],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    AllModule
  ],
})
export class DashboardModule { }
