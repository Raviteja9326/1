import {Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { StorageService } from '../core/interceptor/storage.service';
import { RoleService } from '../services/role.service';
import { Subject, takeUntil } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { AlertMsgComponent } from '../modals/alert-msg/alert-msg.component';
import { HomeService } from '../services/home.service';
import { AlertmasterService } from '../services/alertmaster.service';
import { FormBuilder } from '@angular/forms';
import { AllinoneService } from '../services/allinone.service';
import { LoginService } from '../services/login.service';
declare let $: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit, OnDestroy {
  names: any;
  token: any;
  adminID: boolean = false;
  reportID: boolean = false;
  dashID: boolean = false;
  menuList_data: any = [];
  loading = 'diplyblock2';
  loading2 = 'diplyblock2';
  _destroying$: Subject<boolean> = new Subject<boolean>();
  notifdata: any;
  alertdata: any;
  menus: string;
  intervalId = null;
  menus2: string;
  alertdata2: any;
  siteDatamodify:any = '';
  showoff:string = 'diplyblock2';
  mainmenu:any;
  submenu:any;
  fullscreenIconClass = 'fa fa-expand-arrows-alt';
  isFullscreen = false;
  document: any;
  constructor(private router: Router, private userser: StorageService, private toastr: ToastrService, private notify: RoleService, public dialog: MatDialog, private home: HomeService, private alert: AlertmasterService,private formBuilder: FormBuilder, private allone:AllinoneService, private login:LoginService) {this.document = window.document;}
  siteForm = this.formBuilder.group({
    siteName: ['']
  });
  ngOnInit(): void {
    this.getUsername();
    this.jquremethod();
    this.callapifor1min();
  }
  callapifor1min(){
    this.intervalId = setInterval(()=>{
      this.notifications();
     },60000)
  }
  @HostListener('window:scroll', ['$event'])
  getScrollHeight(event: any) {
    if (window.pageYOffset > 1) {
      $('.top-navbar').addClass('is-sticky');
    } else {
      $('.top-navbar').removeClass('is-sticky');
    }
  }
  jquremethod() {
    $('.burger-menu').on('click', () => {
      $(this).toggleClass('active');
      $('.main-content').toggleClass('hide-sidemenu-area');
      $('.sidemenu-area').toggleClass('toggle-sidemenu-area');
      $('.top-navbar').toggleClass('toggle-navbar-area');
    });
    $('.responsive-burger-menu').on('click', function () {
      $('.responsive-burger-menu').toggleClass('active');
      $('.sidemenu-area').toggleClass('active-sidemenu-area');
    });
    $(function () {
      $('[data-toggle="tooltip"]').tooltip();
    });
    $(function () {
      $('[data-toggle="popover"]').popover();
    });
    $(function () {
      $('#sidemenu-nav').metisMenu();
    });
    $('.bx-fullscreen-btn').on('click', () => {
      $(this).toggleClass('active');
    });
    $(function () {
      $('.accordion')
        .find('.accordion-title')
        .on('click', function () {
          $(this).toggleClass('active');
          $(this).next().slideToggle('fast');
          $('.accordion-content').not($(this).next()).slideUp('fast');
          $('.accordion-title').not($(this)).removeClass('active');
        });
    });
    (function ($) {
      $('.tab ul.tabs')
        .addClass('active')
        .find('> li:eq(0)')
        .addClass('current');
      $('.tab ul.tabs li a').on('click', function (g) {
        var tab = $(this).closest('.tab'),
          index = $(this).closest('li').index();
        tab.find('ul.tabs > li').removeClass('current');
        $(this).closest('li').addClass('current');
        tab
          .find('.tab_content')
          .find('div.tabs_item')
          .not('div.tabs_item:eq(' + index + ')')
          .slideUp();
        tab
          .find('.tab_content')
          .find('div.tabs_item:eq(' + index + ')')
          .slideDown();
        g.preventDefault();
      });
    });
  }
  toggleFullscreen() {
    if (!this.isFullscreen) {
      this.enterFullscreen();
    } else {
      this.exitFullscreen();
    }
  }
  enterFullscreen() {
    this.isFullscreen = true;
    this.fullscreenIconClass = 'fa fa-compress-arrows-alt';
    this.document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.addEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.addEventListener('keydown', this.handleEscKey);
  }
  exitFullscreen() {
    this.isFullscreen = false;
    this.fullscreenIconClass = 'fa fa-expand-arrows-alt';
    this.document.removeEventListener('fullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('mozfullscreenchange', this.handleFullscreenChange);
    this.document.removeEventListener('MSFullscreenChange', this.handleFullscreenChange);
    this.document.removeEventListener('keydown', this.handleEscKey);
  }
  handleFullscreenChange = () => {
    if (!this.document.fullscreenElement && !this.document.webkitFullscreenElement &&
        !this.document.mozFullScreenElement && !this.document.msFullscreenElement) {
      this.exitFullscreen();
    }
  }
  handleEscKey = (event: KeyboardEvent) => {
    if (event.key === 'Escape') this.exitFullscreen();
  }
  checksite(data){
    if(data != null) {
      this.userser.variable(data)
      this.siteForm.controls.siteName.patchValue(data)
      this.showoff = 'diplyblock';
      this.notifications();
      this.getroles();
    }
    else if(data == null){
      this.showoff = 'diplyblock2'
      this.getalert5(this.names);
    }
  }
  getUsername() {
    this.names = this.userser.getuser();
    this.token = this.userser.getToken();
    this.siteDatamodify = this.userser.getvariable();
    if(this.names.facilities.length == 0){
      this.toastr.error("Sorry for the Inconvenience, You Don't Have Required Access");
      this.logout();
    }
   else if(this.names.facilities.length == 1){
      this.names.facilities.map(res=>{
        this.siteDatamodify = res.facilityId;
        this.userser.variable(res.facilityId);
        this.userser.setSiteName(res.facilityName);
        this.allone.setSourceStub({'facilityId':res.facilityId,'facilityName':res.facilityName});
        this.checksite(res.facilityId);
      })
    }
    else if(this.siteDatamodify == null){
      if(this.names.facilities.length >=2){
        this.getalert5(this.names);
      }
    }
    else {
      this.checksite(this.siteDatamodify.facilityId);
    }
  }
  notifications() {
    const obj = {};
    obj['facilityId'] = this.siteDatamodify
    this.notify.getnotifications(obj).pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (data: any) => {
          if (data != null) {
            this.notifdata = data?.elements
            this.alertdata = data?.timeAlert
            this.alertdata2 = data?.occupancyAlert
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
        }
      })
  }
  getAlerts() {
    const obj = {};
    obj['facilityId'] = this.siteDatamodify
    this.alert.getallAlert(obj).pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (data: any) => {
          if (data != null) {
            // this.getalert4(data.data)
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
        }
      })
  }
  getAknowlebutton() {
    const data = [];
    const data2 = [];
   this.alertdata.map(res=>{
    return data.push(res.alertId)
   })
   this.alertdata2.map(res=>{
    return data.push(res.alertId)
   })
   const obj = {};
   obj['alertId'] = [...data, ...data2]
    this.alert.getAcknowledge(obj).pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (data: any) => {
          if(data.message == "Alert message acknowledged successfully."){
            this.notifications();
          }
        }, error: (error) => {
          this.toastr.error(error.error.message)
        }
      })
  }
  logout() {
    this.login.getlogoutiffailed();
  }
  clear(){
    this.mainmenu = 'Dashboard';
    this.submenu = null;
  }
  gotomenu(menu,menu2) {
    console.log(menu,menu2)
    const parts = menu.split("/");
    if(parts[1] == 'allreports'){
      this.clear();
    }
    else if(parts[1] == 'dt-simulator'){
      this.mainmenu = menu2;
      this.submenu = null
    }
    else {
      this.mainmenu = parts[1];
      this.submenu = menu2
    }
    this.userser.menu(menu);
    this.userser.menunames(menu2)
    this.router.navigate([`/${menu}`]);
  }
  changepwd(alertdata): void {
    const alertmsg: boolean = true;
    this.dialog.open(AlertMsgComponent, {
      width: '500px',
      data: { alertmsg, alertdata },
      disableClose: false,
      autoFocus: false,
      position: {
        top: '30px'
      }
    });
  }
  getalert(popupdata): void {
    const popup: boolean = true;
    this.dialog.open(AlertMsgComponent, {
      width: '500px',
      data: { popup, popupdata },
      disableClose: false,
      autoFocus: false,
      position: {
        top: '30px'
      }
    });
  }
  getalert3(popupdata2): void {
    const popup2: boolean = true;
    this.dialog.open(AlertMsgComponent, {
      width: '500px',
      data: { popup2, popupdata2 },
      disableClose: false,
      autoFocus: false,
      position: {
        top: '30px'
      }
    });
  }
  getalert4(popup3): void {
    const alertpopup: boolean = true;
    this.dialog.open(AlertMsgComponent, {
      panelClass: 'custom-modal-class',
      width: 'auto',
      data: { alertpopup, popup3 },
      disableClose: false,
      autoFocus: false,
      position: {
        top: '5px'
      }
    });
  }
  getalert5(sites): void {
    const sitespopup: boolean = true;
    const dialogRef = this.dialog.open(AlertMsgComponent, {
      width: 'auto',
      data: { sitespopup, sites },
      disableClose: true,
      autoFocus: false,
      position: {
        top: '5%'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._destroying$)).subscribe((result: any) => {
      this.siteDatamodify = result.result.facilityId;
      this.checksite(this.siteDatamodify)
    });
  }
  getroles() {
    this.home.getallroles().pipe(takeUntil(this._destroying$))
      .subscribe({
        next: (data: any) => {
          data.map(res => {
          this.userser.setRoles(res['roleId'])
            this.menuList_data = res.data;
          })
          const hasAssigned2 = this.menuList_data.report.some((obj: any) => obj.isAssigned === 1);
          if (hasAssigned2 == true) {
            this.loading = 'diplyblock'
          }
          else if (hasAssigned2 == false) {
            this.loading = 'diplyblock2'
          }
          const hasAssigned3 = this.menuList_data.admin.some((obj: any) => obj.isAssigned === 1);
          if (hasAssigned3 == true) {
            this.loading2 = 'diplyblock'
          }
          else if (hasAssigned3 == false) {
            this.loading2 = 'diplyblock2'
          }
          const modules = [...this.menuList_data.dashboard, ...this.menuList_data.report, ...this.menuList_data.admin];
          const object = [];
          modules.map(res => {
            if(res.isAssigned == 1) {
            object.push(res);
          }});
             this.userser.menucheck(object);
          const assignedModule = modules.find(module => module.isAssigned === 1);
          if (assignedModule) {
            if(this.userser.getmenu() == null){
            this.gotomenu(assignedModule.routes,assignedModule.modulename);
           }
           else if(this.userser.getmenu() != null){
            this.gotomenu(this.userser.getmenu(), this.userser.getmenunames());
           }
          }
        }, error: (error) => {
          this.toastr.error(error.error.message);
        }
      })
    // this.getAlerts();
  }
  emitSiteChange(event){
    this.userser.variable(event.value);
    this.userser.setSiteName(event.source.triggerValue);
    this.allone.setSourceStub({'facilityId':event.value,'facilityName':event.source.triggerValue});
  }
  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    clearInterval(this.intervalId);
  }
  collapseExpanded(){
    var menu = document.getElementsByClassName("has-submenu");
    var secondLevel = document.getElementsByClassName("sidemenu-nav-second-level");
    const elements: Element[] = Array.from(menu);
    const subElements: Element[] = Array.from(secondLevel);
    elements.forEach((el: Element) => {
      el.classList.remove('mm-active');
  });
    subElements.forEach((el: Element) => {
    el.classList.remove('mm-show');
})
  }
}
