import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../core/auth.guard';
import { ErrorsComponent } from '../errors/errors.component';
import { DashboardComponent } from './dashboard.component';

const routes: Routes = [
  {
    path: '', component: DashboardComponent, children: [
      { path: "errors", component: ErrorsComponent },
      { path: 'administration', data: { preload: false }, loadChildren: () => import('../Weyerhaeuser_Components/administrator/administrator.module').then(m => m.AdministratorModule), canActivate: [AuthGuard] },
      { path: 'simulator', data: { preload: false }, loadChildren: () => import('../Weyerhaeuser_Components/simulator/simulator.module').then(m => m.SimulatorModule), canActivate: [AuthGuard] },
      { path: 'bay/:id', data: { preload: false }, loadChildren: () => import('../Weyerhaeuser_Components/bay/bay.module').then(m => m.BayModule), canActivate: [AuthGuard] },
      { path: 'report', data: { preload: false }, loadChildren: () => import('../Weyerhaeuser_Components/report/report.module').then(m => m.ReportModule), canActivate: [AuthGuard] },
      { path: 'allreports', data: { preload: false }, loadChildren: () => import('../Weyerhaeuser_Components/home/home.module').then(m => m.HomeModule), canActivate: [AuthGuard] },
      { path: 'dt-simulator', data: { preload: false }, loadChildren: () => import('../Weyerhaeuser_Components/dt-simulator/dt-simulator.module').then(m => m.DtSimulatorModule), canActivate: [AuthGuard] },


    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
