import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { StorageService } from './interceptor/storage.service';
import { ReportsService } from '../services/reports.service';
import { LoginService } from '../services/login.service';

interface Module {
  modulename: string;
  moduleid: number;
  isAssigned: number;
  routes: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private userAuthService: StorageService, private login:LoginService ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (
      this.userAuthService.getToken() !== null &&
      this.userAuthService.getToken() !== '' &&
      this.userAuthService.getToken() !== undefined &&
      this.userAuthService.getToken() !== '0'
    ) {
      const browserRoute = state.url;
      const matchedModule = (this.userAuthService.checkmenu() as unknown as Array<Module>).find(
        module => `/${module.routes}` === browserRoute
      );

      if (matchedModule) {
        return true;
      } else {
        this.login.getlogoutiffailed();
        return false;
      }
    } else {
      this.login.getlogoutiffailed();
      return false;
    }
  }
}