import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
const SecureStorage = require('secure-web-storage');
const SECRET_KEY: any = 'Y7J82,Lf^KwM@v?&X&q3bcF';
declare var require: any;

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  constructor() {}

  secureStorage = new SecureStorage(sessionStorage, {
    hash: function hash(key: any) {
      key = CryptoJS.SHA256(key, SECRET_KEY);
      return key.toString();
    },

    // Encrypt the localstorage data
    encrypt: function encrypt(data: any) {
      data = CryptoJS.AES.encrypt(data, SECRET_KEY);
      data = data.toString();
      return data;
    },

    // Decrypt the encrypted data
    decrypt: function decrypt(data: any) {
      data = CryptoJS.AES.decrypt(data, SECRET_KEY);
      data = data.toString(CryptoJS.enc.Utf8);
      return data;
    },
  });

  public setRoles(roles: any) {
    return this.secureStorage.setItem('roles', roles);
  }

  public getRoles() {
    return this.secureStorage.getItem('roles');
  }

  public setfacility(facility: any) {
    return this.secureStorage.setItem('sites', facility);
  }

  public getfacility() {
    return this.secureStorage.getItem('sites');
  }

  public setToken(jwtToken: any) {
    return this.secureStorage.setItem('jwtToken', jwtToken.accessToken);
  }

  public getToken(): string {
    return this.secureStorage.getItem('jwtToken');
  }

  public getuser(): any {
    return this.secureStorage.getItem('username');
  }

  public setusername(username: any) {
    return this.secureStorage.setItem('username', username);
  }

  public clear() {
    return this.secureStorage.clear();
  }

  public variable(data: any) {
    return this.secureStorage.setItem('alldata', data);
  }

  public getvariable(): string {
    return this.secureStorage.getItem('alldata');
  }
  public setSiteName(data: any) {
    return this.secureStorage.setItem('site-name', data);
  }

  public getSiteName(): string {
    return this.secureStorage.getItem('site-name');
  }

  public menu(data: any) {
    return this.secureStorage.setItem('menu', data);
  }

  public getmenu(): string {
    return this.secureStorage.getItem('menu');
  }

  public menunames(data: any) {
    return this.secureStorage.setItem('menus', data);
  }

  public getmenunames(): string {
    return this.secureStorage.getItem('menus');
  }

  public menucheck(data: any) {
    return this.secureStorage.setItem('checkmenu', data);
  }

  public checkmenu(): string {
    return this.secureStorage.getItem('checkmenu');
  }
}
