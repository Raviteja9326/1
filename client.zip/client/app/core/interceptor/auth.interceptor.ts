import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { StorageService } from './storage.service';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private userAuthService: StorageService,
    private router: Router,
    private toast: ToastrService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (
      !req.headers.get('No-auth') ||
      (req.headers.get('No-auth') === 'True' &&
        req.headers.get('TokenRefresh') === 'False')
    ) {
      return next.handle(req.clone());
    }
    else if (req.headers.get('skipInterceptor')) {
      return next.handle(req);
    }
    const token = this.userAuthService.getToken();
    req = this.addToken(req, token);

    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status == 401) {
          this.toast.error('Access Denied');
           this.router.navigate(['/login']);
           sessionStorage.clear();
          this.userAuthService.clear();
          return throwError(() => error);
        } else {
          return throwError(() => error);
        }
      })
    );
  }

  private addToken(request: HttpRequest<any>, token: string) {
    return request.clone({
      setHeaders: {
        'Cache-Control': 'no-cache',
        Pragma: 'no-cache',
        'Content-Type': 'application/json',
        Authorization: `${token}`,
      },
    });
  }
}
