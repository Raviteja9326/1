/** @type {import('jest').Config} */
const {defaults} = require('jest-config');
const config = {
    verbose: true,
    bail:1,
    globals: {
        "USER_ID": "rajat.agrawal@birlasoft.com",
        "ROLE_ID": 2
      },
    testRegex: [...defaults.testRegex, '(/__tests__/.*|(\\.|/)(test))\\.[j]s?$'],
    testEnvironment:  'node',
        coveragePathIgnorePatterns: [
            '/node_modules/'
        ],
        testResultsProcessor:  'jest-sonar-reporter'

  };
  
  module.exports = config;