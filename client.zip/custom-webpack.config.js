module.exports = {
    resolve: {
        fallback: {
            os: require.resolve('os-browserify'),
            path: require.resolve('path-browserify')
        }
    }
  };