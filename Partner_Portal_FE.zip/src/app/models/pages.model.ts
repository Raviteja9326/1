export interface PageData {
    attributes: AttributesData;
    id: string;
}
export interface AttributesData {
    body: Record<string, any>;
    changed: Date;
    created: Date;
    default_langcode: boolean;
    field_banner_description: string;
    field_display_order: number;
    field_domain_all_affiliates: boolean;
    langcode: string;
    moderation_state: string;
    promote: boolean;
    status: boolean;
    sticky: boolean;
    title: string;
}