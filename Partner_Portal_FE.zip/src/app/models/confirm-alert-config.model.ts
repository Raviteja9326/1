import { Observable } from "rxjs";

export interface ConfirmAlertConfig {
  question: string;
  showCancelButton?: boolean;
  confirmButtonText?: string;
  callback: any;
  callbackParams?: { scope: object, params?: any }
}
