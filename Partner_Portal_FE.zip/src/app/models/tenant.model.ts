export interface TenantData{
    tenant_id:string;
    tenant_name:string;
    status:string;
    last_updated:string
}

export const DummyChartData: any[] = [
    {
        name: 'Completed', // string
        value: 20, // number
        color: '#FF6600', // string,
      },
      {
        name: 'in Progress', // string
        value: 16, // number
        color: '#F9B200', // string,
      },
      {
        name: 'initiated', // string
        value: 14, // number
        color: '#7D7D7D', // string,
      },
];
