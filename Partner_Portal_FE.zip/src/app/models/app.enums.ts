export enum SortingDirection {
  Descending = "desc",
  Ascending = "asc"
}
export enum Events {
  Logout = "logout",
  SessionOut = "session-out",
  ClientChanged = "client-changed",
  tokenLife = "token-life",
  userEvent = "user-event",
  InvoiceDispute = "invoice-dispute",
  ShowModalPopup = "modal-popup-show",
  HideModelPopup = "modal-popup-hide",
  ShowChildPopup = "child-popup-show",
  HideChildPopup = "child-popup-hide",
  CatalogFilterUpdated = 'catalog-filter',
  RequestDemo = "request-demo",
  SelectedDeal = "selected-deal",
  LoginSuccess = "login-success",

  ForecastAdded = "forecast-add-success",
  ForecastUpdated = "forecast-update-success",
  DealRefresh= "deal-refresh",

  UpdateCatalogAttribute = "update-catalog-attr",
  CloseServiceCatalog = "service-catalog-close",
  ValidteCatalog = "catalog-validation",
  CloseSidePopup = "close-side-popup"
}

export enum Platform {
  Drupal = "drupal",
  Concierto = "concierto"
}

export enum FieldType {
  Textbox = "textbox",
  Textarea = "textarea",
  Radiolist = "radios",
  Checklist = "checks",
  Number = "number",
  Dropdown = "dropdown",
  Switch = "switch",
  Email = "email",
  Date = "date",
}

export enum FeatureList {
  NewsCarousel = "news-carousel",
  MyDealsCommon = "my-deals-common",
  MyDealsAWS = "my-deals-aws",
  OpportunitySnapshot = "opportunity-snapshot",
  SalesPipeline = "sales-pipeline"
};

