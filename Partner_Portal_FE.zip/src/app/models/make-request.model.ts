export interface MakeRequest {
  type: string;
  title: string;
  body: string;
  // date: any;
}

export enum MakeRequestType {
  PROPOSAL = 'Request for Proposal',
  DEMO = 'Request for Demo',
  QUERY = "Submit a Query"
  // POC_ACCESS = 'Support for POC Access'
}
