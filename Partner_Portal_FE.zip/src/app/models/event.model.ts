export interface EventData {
  name: string,
  value?: any,
  alignment?: string
}