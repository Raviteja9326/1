export interface NewsListing {
  news: Array<NewsList>;
}

export interface NewsList {
  banner: string;
  body: string;
  category: string;
  date: any;
  id: string;
  published: string;
  status: string;
  tags: string;
  title: string;
  trending: string;
  user: string;
}
