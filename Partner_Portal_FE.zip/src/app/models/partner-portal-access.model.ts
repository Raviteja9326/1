export interface PartnerDetails  {
    name:string,
    mail:string,
    duns:string,
    website:string,
    address:string,
    fname:string,
    lname:string,
    title:string,
    phone:string,
    secondary_phone:string,
    type:string,
    country:string, 
    state:string, 
    city:string,
    zip:string,
    hear_from:string

  }
  