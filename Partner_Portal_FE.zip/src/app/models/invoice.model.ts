export interface InvoiceData {
    title: string,
    field_invoice_partner: string,
    field_invoice_date: Date,
    field_invoice_doc: string,
    field_invoice_id: string,
    field_invoice_title: string
}
