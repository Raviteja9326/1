export interface Authentication {
  userName: string;
  password: string;
  realm?: string;
}
