export interface KeyContacts {
  name: string;
  title: string;
  email: string;
  mobile: string;
  region: string;
  photo: any;
}

export interface updateContacts {
  id: string;
  name: string;
  title: string;
  email: string;
  mobile: string;
  region: string;
  photo: any;
  log: string;
}
