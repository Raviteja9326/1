export interface SalesAsset {
    title: string;
    field_assets_type: string;
    field_asserts_title: string;
    field_asserts_banner: string;
    field_asserts_file: string;
    field_assets_file_type: string;
    field_asserts_link: string;
    category: string;
}

export enum SalesAssetsType {
    PROD_DATA_SHEETS = 'Product Data Sheets',
    CUSTOMER_PRESENTATIONS = 'Customer Presentations',
    CUSTOMER_ONBOARDING_SOPS = 'Customer Onboarding Sops',
    PRODUCT_VIDEOS = 'Product Videos'
}

export const SalesAssetsCategories: Record<string, string> = {
    'Product Data Sheets': 'datasheet',
    'Customer Presentations': 'presentation',
    'Customer Onboarding Sops': 'sop',
    'Product Videos': 'video'
}

export interface SalesAssetsGroup {
    data: SalesAsset[];
    category: string;
}
