
export interface DealColumn {
    name: string,
    dataField: string,
    isFilterable: boolean,
    filterValues: any[],
    filterOpened: boolean,
    isSorted: boolean,
    sortingDirection: string,
    // selected: true,
    class?: string
  }
