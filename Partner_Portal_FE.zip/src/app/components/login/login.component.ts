import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { OwlOptions } from "ngx-owl-carousel-o";
import { Subscription } from "rxjs";
import { Authentication } from "src/app/models/authentication.model";
import { AuthenticationService } from "src/app/modules/authentication/authentication.service";
import { appConfig } from "src/app/app.config";
import { Events, Platform } from 'src/app/models/app.enums';
import { ApiService } from "src/app/modules/shared/api.service";
import { EventBusService } from 'src/app/modules/shared/event-bus.service';
import { AppComponent } from "src/app/app.component";
import { CommonUtilService } from "src/app/modules/utils/common-util.service";
import { AlertUtility } from "src/app/modules/utils/alert.util";
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent implements OnInit {
  showPartnerPortalAccessModal: boolean = false;
  recognitionCarousel: OwlOptions = {
    loop: false,
    autoplay: false,
    nav: true,
    items: 4,
    margin: 20,
    dots: false,
    navText: [
      "<div class='carouselNav'><img class='black-arrow' src='../../../../assets/images/black-left-arrow.png'><img class='white-arrow' src='../../../../assets/images/left-arrow.png'></div>",
      "<div class='carouselNav'><img class='inverted-arrow black-arrow' src='../../../../assets/images/black-left-arrow.png'><img class='inverted-arrow white-arrow' src='../../../../assets/images/left-arrow.png'></div>",
    ],
    responsive: {
      0: {
        items: 1,
        center: true,
        stagePadding: 50,
        nav: false,
      },
      576: {
        items: 2,
        margin: 10,
        nav: false,
      },
      756: {
        items: 3,
        margin: 20,
        nav: true,
        slideBy: 1,
      },
      992: {
        items: 4,
        nav: true,
        slideBy: 1,
      },
    },
  };
  ssCarousel: OwlOptions = {
    loop: false,
    autoplay: false,
    nav: true,
    items: 4,
    margin: 30,
    dots: false,
    navText: [
      "<div class='carouselNav'><img class='black-arrow' src='../../../../assets/images/black-left-arrow.png'><img class='white-arrow' src='../../../../assets/images/left-arrow.png'></div>",
      "<div class='carouselNav'><img class='inverted-arrow black-arrow' src='../../../../assets/images/black-left-arrow.png'><img class='inverted-arrow white-arrow' src='../../../../assets/images/left-arrow.png'></div>",
    ],
    responsive: {
      0: {
        items: 1,
        center: true,
        stagePadding: 50,
        nav: false,
      },
      576: {
        items: 2,
        margin: 20,
        nav: false,
      },
      756: {
        items: 3,
        margin: 30,
        nav: true,
        slideBy: 1,
      },
    },
  };
  isLoading: boolean = false;
  returnUrl!: string;
  frmLogin!: FormGroup;
  loginSubscription$!: Subscription;
  drupalUserProfileSubscription$!: Subscription;
  resetToggle: boolean = false
  forgotPasswordSubscription$!: Subscription;
  username: string = "";
  frmForgotPassword!: FormGroup;
  // alertService: any;
  constructor(
    private apiService: ApiService,
    private router: Router,
    private authService: AuthenticationService,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private eventBusService: EventBusService,
    private util:CommonUtilService,
    private alertUtil:AlertUtility
  ) { }

  createForgotPasswordForm() {
    this.frmForgotPassword = this.fb.group({
      username: ["", Validators.required]
    });

  }
  createLoginForm() {
    this.frmLogin = this.fb.group({
      username: [
        "",
        Validators.required
      ],
      password: ["", Validators.required],
    });
  }

  ngOnInit(): void {
    this.apiService.logoutDrupal();
    this.createLoginForm();
    this.createForgotPasswordForm()

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams["returnUrl"] || "/home";
  }
  getPartnerPortalAccess() {
    this.showPartnerPortalAccessModal = true;
  }
  login() {
    this.isLoading = true;
    const auth: Authentication = {
      userName: this.frmLogin.controls["username"].value,
      password: this.frmLogin.controls["password"].value,
      realm: this.authService.getRealm()
    };
    this.loginSubscription$ = this.authService.login(auth).subscribe(
      (resp: any) => {
        if (resp.status === 200) {
          resp.current_user.drupalData.pw = btoa(auth.password)
          this.util.setLocalStorage(appConfig.drupal.storageKeys.loginInfo, resp.current_user.drupalData)
          this.util.setLocalStorage(appConfig.concierto.storageKeys.loginInfo, resp.current_user.conciertoData)
          this.loadDrupalUserProfile(resp);
          this.eventBusService.emit({ name: Events.tokenLife, value: { platform: Platform.Drupal, accessToken: resp.current_user.drupalData.access_token } })
          this.eventBusService.emit({ name: Events.tokenLife, value: { platform: Platform.Concierto, accessToken: resp.current_user.conciertoData.access_token } })
        }
        else {
          this.isLoading = false;
          this.alertUtil.showAlert("error", resp.data.message);
        }
      },
      (error: any) => {
        this.alertUtil.showAlert("error", error.error.message);
        this.isLoading = false;
      }
    );
  }

  private loadDrupalUserProfile(response: any) {
    this.drupalUserProfileSubscription$ = this.apiService.getDrupalUserProfile(response.current_user.drupalData.uid).subscribe((resp: any) => {
      if (resp) {
        this.util.setLocalStorage("loginType", "nonad");

        const drupalLoginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo);
        drupalLoginInfo.profile = resp;
        const fullname = `${resp.fname} ${resp.lname}`
        drupalLoginInfo.profile.initials = this.util.getInitials(fullname)
        drupalLoginInfo.profile.bgcolor = this.util.stringToColour(fullname)
        this.util.setLocalStorage(appConfig.drupal.storageKeys.loginInfo, drupalLoginInfo);

        const conciertoLoginInfo = this.util.getLocalStorage(appConfig.concierto.storageKeys.loginInfo);
        conciertoLoginInfo.realmid = resp.realmid;
        this.util.setLocalStorage(appConfig.concierto.storageKeys.loginInfo, conciertoLoginInfo);

        this.isLoading = false;
        this.router.navigateByUrl(this.returnUrl);
        // this.authService.isLoggedIn = true;
        // this.app.toggleLoginFlag(true);
      }
      else {
        this.alertUtil.showAlert("error", resp.data.message);
        this.isLoading = false;
      }
    },
      (error: any) => {
        this.alertUtil.showAlert("error", error.error.message);
        this.isLoading = false;
      });
  }

  ngOnDestroy() {
    this.loginSubscription$?.unsubscribe();
    this.drupalUserProfileSubscription$?.unsubscribe();
    this.forgotPasswordSubscription$?.unsubscribe();
  }

  closePartnerPortalAccessModal() {
    this.showPartnerPortalAccessModal = false;
  }

  forgotPassword() {
    this.isLoading = true;
    const payload = { userName: this.frmForgotPassword.controls["username"].value.trim() }
    this.forgotPasswordSubscription$ = this.apiService.forgotPassword(payload).subscribe((resp: any) => {
      if (resp.data.status === 200)
        this.alertUtil.showAlert("success", "Password reset link is sent to your email.");
      else
        this.alertUtil.showAlert("error", resp.data.message || "Something went wrong! Sorry for the inconvenience.");
      this.isLoading = false;
    }, (error: any) => {
      this.alertUtil.showAlert("error", error);
      this.isLoading = false;
    })
  }

}
