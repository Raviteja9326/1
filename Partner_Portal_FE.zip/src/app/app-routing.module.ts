import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { TestComponent } from './components/test/test.component';
import { accountRoutes } from './modules/account-management/account-management-routing.module';
import { AuthGuard } from './modules/authentication/auth.guard';
import { AuthenticationGuard } from './modules/authentication/authentication.guard';
import { CollateralComponent } from './modules/dashboard/collateral/collateral.component';
import { dashboardRoutes } from './modules/dashboard/dashboard-routing.module';
import { HomeComponent } from './modules/dashboard/home/home.component';
import { LearningComponent } from './modules/dashboard/learning/learning.component';
import { NewsDetailsComponent } from './modules/dashboard/news-details/news-details.component';
import { NewsComponent } from './modules/dashboard/news/news.component';
import { OpportunityManagementDetailsComponent } from './modules/dashboard/opportunity-management-details/opportunity-management-details.component';
import { OpportunityManagementComponent } from './modules/dashboard/opportunity-management/opportunity-management.component';
import { PartnershipComponent } from './modules/dashboard/partnership/partnership.component';
import { PlatformComponent } from './modules/dashboard/platform/platform.component';
import { SalesAssetDetailsComponent } from './modules/dashboard/sales-asset-details/sales-asset-details.component';
import { productUpdatesRoutes } from './modules/product-updates/product-updates-routing.module';
import { publishRoutes } from './modules/publish/publish-routing.module';
import { CatalogSectionsComponent } from './modules/service-catalog/components/catalog-sections/catalog-sections.component';
import { Awsec2MultiComponent } from './modules/service-catalog/components/popup/awsec2-multi/awsec2-multi.component';
import { serviceCatalogRoutes } from './modules/service-catalog/service-catalog-routing.module';
import { RolesGuard } from './modules/shared/roles.guard';
import { sharedRoutes } from './modules/shared/shared-routing.module';
import { SupportComponent } from './modules/dashboard/support/support.component';
import { LearingAllComponent } from './modules/dashboard/learing-all/learing-all.component';
import { CollateralListComponent } from './modules/dashboard/collateral-list/collateral-list.component';


const routes: Routes = [
  {
    path: 'landing',
    loadChildren: () => import('./modules/pre-login/pre-login.module').then(m => m.PreLoginModule)
  }, {
    path: '',
    redirectTo: "landing",
    pathMatch: "full"
  }, {
    path: "login",
    redirectTo: "home",
    pathMatch: "full"
  }, {
    path: "home",
    component: HomeComponent,
    // loadChildren: () => import('./modules/dashboard/dashboard.module').then(m => m.DashboardModule),
    // children: [...dashboardRoutes],
    canActivate: [AuthGuard]
  },
  { path: "collateral", component: CollateralComponent, canActivate: [AuthGuard] },
  // { path: "collateral", component: CollateralListComponent, canActivate: [AuthGuard] },
  { path: "learning", component: LearingAllComponent, canActivate: [AuthGuard] },
  { path: "news", component: NewsComponent, canActivate: [AuthGuard] },
  { path: "news-details", component: NewsDetailsComponent, canActivate: [AuthGuard] },
  { path: "platform/:platformSubMenu/:id", component: PlatformComponent, canActivate: [AuthGuard] },
  { path: "opportunity", component: OpportunityManagementComponent, canActivate: [AuthGuard] },
  { path: "collateral/:id", component: SalesAssetDetailsComponent, canActivate: [AuthGuard] },
  { path: "partnership/:partnershipSubMenu/:id", component: PartnershipComponent, canActivate: [AuthGuard] },
  { path: "opportunity-details", component: OpportunityManagementDetailsComponent, canActivate: [AuthGuard] },
  { path: "support", component: SupportComponent },
  
  {
    path: "account",
    children: [...accountRoutes],
    canActivate: [AuthGuard]
  },
  {
    path: "publish",
    children: [...publishRoutes],
    canActivate: [AuthGuard],
  },
  {
    path: "shared",
    children: [...sharedRoutes],
    canActivate: [AuthGuard]
  },
  {
    path: "service-catalog",
    children: [...serviceCatalogRoutes],
    canActivate: [RolesGuard],
    data: {
      requiredRoles: ['site_admin']
    }
  }, {
    path: 'forecast',
    loadChildren: () => import('./modules/forecasting/forecasting.module').then(m => m.ForecastingModule),
    canActivate: [AuthGuard],
  }, {
    path: 'award',
    loadChildren: () => import('./modules/partner-awards/partner-awards.module').then(m => m.PartnerAwardsModule),
    canActivate: [AuthGuard],
  }, {
    path: 'deal-details/:dealId',
    loadChildren: () => import('./modules/opportunity-management/opportunity-management.module').then(m => m.OpportunityManagementModule),
    canActivate: [AuthGuard],
  }, {
    path: "updates/:category/:id",
    children: [...productUpdatesRoutes],
    // canActivate: [AuthGuard],
  },
  {
    path: "ec2",
    component: Awsec2MultiComponent
  },
  {
    path: "test",
    component: TestComponent
  },
  {
    path: "**",
    redirectTo: "dashboard"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
