import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppInterceptor } from './app.interceptor';
import { LoginComponent } from './components/login/login.component';
// import { AccountModule } from './modules/account/account.module';
import { PartnerPortalAccessComponent } from './modules/account/partner-portal-access/partner-portal-access.component';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { DirectivesModule } from './modules/directives/directives.module';
import { SharedModule } from './modules/shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { PublishModule } from './modules/publish/publish.module';
import { AccountManagementModule } from './modules/account-management/account-management.module';
import { ServiceCatalogModule } from './modules/service-catalog/service-catalog.module';
import { TestComponent } from './components/test/test.component';
import { MaterialModule } from './modules/shared/material/material.module';
import { TINYMCE_SCRIPT_SRC } from '@tinymce/tinymce-angular';
import { OpportunityManagementModule } from './modules/opportunity-management/opportunity-management.module';
import { initializeKeycloak } from './init/keycloak-init.factory';
import { KeycloakAngularModule, KeycloakService } from 'keycloak-angular';
import { AuthenticationService } from './modules/authentication/authentication.service';
import { ForecastingModule } from './modules/forecasting/forecasting.module';
import { ValidationModule } from './modules/validation/validation.module';
import { PreLoginModule } from './modules/pre-login/pre-login.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    PartnerPortalAccessComponent,
    TestComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    PreLoginModule,
    CarouselModule,
    // AccountModule,
    AccountManagementModule,
    DashboardModule,
    SharedModule,
    DirectivesModule,
    ReactiveFormsModule,
    HttpClientModule,
    PublishModule,
    ServiceCatalogModule,
    MaterialModule,
    OpportunityManagementModule,
    KeycloakAngularModule,
    ValidationModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AppInterceptor, multi: true },
    { provide: TINYMCE_SCRIPT_SRC, useValue: 'tinymce/tinymce.min.js' },
    {
      provide: APP_INITIALIZER,
      useFactory: initializeKeycloak,
      multi: true,
      deps: [KeycloakService, AuthenticationService],
    }
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
