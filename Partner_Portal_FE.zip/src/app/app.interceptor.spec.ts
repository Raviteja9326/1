import { TestBed } from '@angular/core/testing';

import { AppInterceptor } from './app.interceptor';
import { HttpClientModule } from '@angular/common/http';
import { KeycloakAngularModule } from 'keycloak-angular';

describe('AppInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports:[
      HttpClientModule, KeycloakAngularModule
    ],
    providers: [
      AppInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: AppInterceptor = TestBed.inject(AppInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
