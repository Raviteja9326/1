import { Component, HostListener } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { appConfig } from './app.config';
import { forkJoin, Subscription } from 'rxjs';
import { Events, Platform } from './models/app.enums';
import { EventData } from './models/event.model';
import { AuthenticationService } from './modules/authentication/authentication.service';
import { EventBusService } from './modules/shared/event-bus.service';
import { CommonUtilService } from './modules/utils/common-util.service';
import { KeycloakService } from 'keycloak-angular';
import { environment } from 'src/environments/environment';
import { initializeKeycloak } from './init/keycloak-init.factory';
import { UserManagementService } from './modules/shared/services/user-management.service';
import { AlertUtility } from './modules/utils/alert.util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'concierto-partner-spa';
  isLoggedIn: boolean = false;
  platform = Platform;
  drupalLogoutSubscription$: any;
  eventSubscription$!: Subscription;
  authServerSub$!: Subscription;
  isLoading: boolean = false;
  userDetailSub$!: Subscription;
  drupalUserProfileSubscription$!: Subscription;
  showHeader: boolean = false;

  
  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private alertUtil: AlertUtility,
    private keyCloak: KeycloakService,
    private userService: UserManagementService) {
    this.loadAllSubscription();
    // this.loadUserInfo();

  }



  loadAllSubscription() {
    this.eventSubscription$ = this.eventBusService.on(Events.Logout, () => {
      this.logout();
    });
    this.eventSubscription$ = this.eventBusService.on(Events.SessionOut, () => {
      // this.showSessionModal();
      this.triggerLogout({
        scope: this,
        params: { value: true }
      })
    });

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.util.setBodyBackground();
        // this.toggleLoginFlag(true);
        if (!this.authService.checkPortalLoggedin() && event.urlAfterRedirects.includes("/home")) {
          const kc: any = Object.assign({}, this.keyCloak);
          this.loadUserDetails(kc._instance);
        }
      }
    });
  }

  ngOnInit(): void {
    // this.setActiveApp("concierto");
    let loginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo)
    let token = loginInfo.access_token
    this.toggleLoginFlag(token ? true : false)
  }

  loadUserDetails(keyCloak: any) {
    this.isLoading = true
    const previousSessionInvalidator = this.authService.invalidateOthersSession();
    const userDetailAccessor = this.userService.getUserDetails(keyCloak.token);
    this.isLoading = true;
    this.userDetailSub$ = forkJoin([previousSessionInvalidator, userDetailAccessor]).subscribe({
      next: (values: any[]) => {
        console.log(values[0].body?.message)
        const resp = values[1]
        if (+resp.body.data.isUserBlocked) {
          this.blockAccess(resp);
        }
        else {
          this.util.setLocalStorage(appConfig.drupal.storageKeys.loginInfo, resp.body.current_user.drupalData)

          resp.body.current_user.conciertoData.realmid = this.authService.getRealm();
          resp.body.current_user.conciertoData.access_token = keyCloak.token;
          resp.body.current_user.conciertoData.refresh_token = keyCloak.refreshToken;
          this.util.setLocalStorage(appConfig.concierto.storageKeys.loginInfo, resp.body.current_user.conciertoData)
          this.loadDrupalProfile(resp.body);
          this.eventBusService.emit({ name: Events.tokenLife, value: { platform: Platform.Drupal, accessToken: resp.body.current_user.drupalData.access_token } })
          this.eventBusService.emit({ name: Events.tokenLife, value: { platform: Platform.Concierto, accessToken: resp.body.current_user.conciertoData.access_token } })
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.alertUtil.showAlert('error', error)
      },
      complete: () => { }
    })
  }

  private blockAccess(resp: any) {
    const config = {
      icon: "error",
      title: "Sorry for any inconvenience",
      message: `${resp.body.data.login}`,
      confirmButtonText: "Ok",
      cancelButtonText: "Login",
      confirmButtonCallback: this.triggerLogout,
      // cancelButtonCallback: this.triggerLogout,
      showConfirmButton: true,
      callbackParams: {
        scope: this,
        params: { value: true }
      }
    };

    this.alertUtil.showCallbackAlert(config);
  }

  private loadDrupalProfile(resp: any) {
    this.drupalUserProfileSubscription$ = this.userService.getDrupalUserProfile(resp.current_user.drupalData.uid).subscribe((resp: any) => {
      if (resp.status === 200) {
        this.util.setLocalStorage(appConfig.storageKeys.loginType, "nonad")
        const drupalLoginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo);
        drupalLoginInfo.profile = resp.body;
        const fullname = `${resp.body.fname} ${resp.body.lname}`
        drupalLoginInfo.profile.initials = this.util.getInitials(fullname)
        drupalLoginInfo.profile.bgcolor = this.util.stringToColour(fullname)
        this.util.setLocalStorage(appConfig.drupal.storageKeys.loginInfo, drupalLoginInfo);

        const conciertoLoginInfo = this.util.getLocalStorage(appConfig.concierto.storageKeys.loginInfo);
        conciertoLoginInfo.realmid = resp.body.realmid;
        this.util.setLocalStorage(appConfig.concierto.storageKeys.loginInfo, conciertoLoginInfo);

        // this.util.notifyToast("Login successfull");
        // this.isLoading = false;
        // this.router.navigate(['/home']);
        this.toggleLoginFlag(true);
        this.eventBusService.emit({ name: Events.LoginSuccess, value: true })
        // console.log(resp)
        this.isLoading = false
      }
      else {
        this.alertUtil.notifyToast(resp, "error");
      }
    }, (error) => {
      this.alertUtil.notifyToast(error.message, "error")
    });
  }

  toggleLoginFlag(isLoggedIn: boolean) {
    this.showHeader = true
    this.isLoggedIn = isLoggedIn;
    this.authService.isLoggedIn = isLoggedIn
  }

  showSessionModal() {
    if (this.authService.isQuestionAlertShown) return;
    const realoadingCount = this.util.getLocalStorage(appConfig.storageKeys.reloading, "number")
    const config = {
      icon: "info",
      title: "Sorry for any inconvenience",
      message: `Your session ${realoadingCount >= appConfig.maxReloadingCount ? 'is' : 'might be'} expired.`,
      confirmButtonText: "Reload",
      cancelButtonText: "Login",
      confirmButtonCallback: this.triggerReload,
      cancelButtonCallback: this.triggerLogout,
      showConfirmButton: realoadingCount < appConfig.maxReloadingCount,
      callbackParams: {
        scope: this,
        params: { value: true }
      }
    }
    this.authService.isQuestionAlertShown = true;
    setTimeout(() => {
      this.alertUtil.showQuestionAlert(config)
    }, 1000);
  }

  triggerReload(params: any) {
    params.scope.util.setLocalStorage(appConfig.storageKeys.reloading,
      params.scope.util.getLocalStorage(appConfig.storageKeys.reloading, "number") + 1
    )
    location.reload();
  }
  triggerLogout(params: any) {
    // params.scope.util.triggerLogout(params.params.value)
    const event: EventData = {
      name: Events.Logout,
      value: params.params.value
    }
    params.scope.eventBusService.emit(event)
  }

  logout() {
    this.isLoading = true;
    setTimeout(() => {
      this.logoutDrupal();
    }, 100);
  }

  private logoutDrupal() {
    const userProfile = this.authService.getLoggedinUserDetails()
    this.drupalLogoutSubscription$ = this.userService.logoutDrupal(userProfile?.id).subscribe({
      complete: () => { this.logoutKeycloak(); }, // completeHandler
      error: () => { this.logoutKeycloak(); },    // errorHandler
      next: () => { this.logoutKeycloak(); },     // nextHandler
    });
  }

  private logoutKeycloak() {
    const idTokenHint = this.keyCloak.getKeycloakInstance().idToken;
    const realmRedirectUrl = `${environment.endpoints.keyCloak.redirectUri}`;
    const redirectUrl = `${realmRedirectUrl}&id_token_hint=${idTokenHint}`;

    localStorage.clear();
    this.toggleLoginFlag(false);
    localStorage.setItem("loggedin", "0");
    this.isLoading = false;
    if (!idTokenHint) {
      window.location.href = realmRedirectUrl
    } else {
      this.keyCloak.logout(redirectUrl).then(resp => {
        this.isLoading = false;
        console.log("Concierto Logout successful");
      }).catch(error => {
        window.location.href = realmRedirectUrl
      });
    }
  }

  ngOnDestroy() {
    this.drupalLogoutSubscription$?.unsubscribe();
    this.eventSubscription$?.unsubscribe();
    this.authServerSub$?.unsubscribe();
    this.userDetailSub$?.unsubscribe();
    this.drupalUserProfileSubscription$?.unsubscribe();
  }
}
