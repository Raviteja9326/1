import { KmbPipe } from './kmb.pipe';

describe('KmbPipe', () => {
  it('create an instance', () => {
    const pipe = new KmbPipe();
    expect(pipe).toBeTruthy();
  });
});
