import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpsPipe } from './https.pipe';
import { DateMomentPipe } from './date-moment.pipe';
import { KmbPipe } from './kmb.pipe';
import { IsAuthorizedPipe } from './is-authorized.pipe';



@NgModule({
  declarations: [
    HttpsPipe,
    DateMomentPipe,
    KmbPipe,
    IsAuthorizedPipe
  ],
  imports: [
    CommonModule
  ],
  exports: [
    HttpsPipe,
    DateMomentPipe,
    KmbPipe,
    IsAuthorizedPipe
  ]

})
export class PipesModule { }
