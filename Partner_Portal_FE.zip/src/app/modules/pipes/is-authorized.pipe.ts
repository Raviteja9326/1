import { Pipe, PipeTransform } from '@angular/core';
import { AuthorizationService } from '../authentication/authorization.service';

@Pipe({
  name: 'isAuthorized'
})
export class IsAuthorizedPipe implements PipeTransform {
constructor(private authorizer:AuthorizationService){

}
  transform(value: string, ...args: unknown[]): unknown {
    return this.authorizer.isAuthorizedFeature(value);
  }

}
