import { Pipe, PipeTransform } from "@angular/core";
import moment from "moment";

@Pipe({
  name: "DateMoment",
})
export class DateMomentPipe implements PipeTransform {
  transform(value: any): any {
    return moment(value).fromNow();
    // value = value * 1000;
    // const newDate: any = new Date();
    // var seconds = Math.floor((newDate - value) / 1000);

    // var interval = seconds / 31536000;
    // // console.log(interval);

    // if (interval > 1) {
    //   return Math.floor(interval) + " years ago";
    // }
    // interval = seconds / 2592000;
    // if (interval > 1) {
    //   return Math.floor(interval) + " months ago";
    // }
    // interval = seconds / 86400;
    // if (interval > 1) {
    //   return Math.floor(interval) + " days ago";
    // }
    // interval = seconds / 3600;
    // if (interval > 1) {
    //   return Math.floor(interval) + " hours ago";
    // }
    // interval = seconds / 60;
    // if (interval > 1) {
    //   return Math.floor(interval) + " minutes ago";
    // }
    // return Math.floor(seconds) + " seconds ago";
  }
}
