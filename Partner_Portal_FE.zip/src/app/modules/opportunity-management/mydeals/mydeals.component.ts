import { Component, HostListener, Input, OnInit } from "@angular/core";
@Component({
  selector: "app-mydeals",
  templateUrl: "./mydeals.component.html",
  styleUrls: ["./mydeals.component.scss"],
})
export class MydealsComponent implements OnInit {

  constructor(){

  }
  ngOnInit(): void {

  }
    
}


