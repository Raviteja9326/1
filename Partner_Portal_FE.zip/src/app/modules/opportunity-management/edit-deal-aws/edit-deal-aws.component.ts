import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-deal-aws',
  templateUrl: './edit-deal-aws.component.html',
  styleUrls: ['./edit-deal-aws.component.scss']
})
export class EditDealAwsComponent implements OnInit {
  // tabs = [{ name: "DEAL DETAILS", value: "deal-details" }, { name: "REVENUE FORECAST", value: "revenue-forecast" }]
  @Input() dealInfo!: any;
  @Input() tabIndex: number = 0;
  editMode: boolean = true


  constructor() { }

  ngOnInit(): void {
    // const elm: HTMLElement | null = document.querySelector('.mat-tab-label-active')
    // if (elm)
    //   elm.click()
    //  elm.click()
    //   this.onTabClick(this.activeTab)
    // document.querySelector('.mat-tab-label-active')
  }

  onTabClick(event: any) {
    // const selected = this.tabs.filter(
    //   ((item: any) => item?.label === event?.tab?.textLabel)
    // )
  }
}
