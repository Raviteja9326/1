import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDealAwsComponent } from './edit-deal-aws.component';

describe('EditDealAwsComponent', () => {
  let component: EditDealAwsComponent;
  let fixture: ComponentFixture<EditDealAwsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditDealAwsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDealAwsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
