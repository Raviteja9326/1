import { Component, Input, OnInit } from '@angular/core';
import { AuthenticationService } from '../../authentication/authentication.service';
import { Subscription, forkJoin } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';
import { OpportunityService } from '../opportunity.service';
import { Events } from 'src/app/models/app.enums';

@Component({
  selector: 'app-deal-details',
  templateUrl: './deal-details.component.html',
  styleUrls: ['./deal-details.component.scss']
})
export class DealDetailsComponent implements OnInit {
  currentrealm!: string;

  clientChangeSub$: Subscription;
  isLoading: boolean = false;
  snapshot$!: Subscription;
  dealDetails: any;
  stageList!: any[];

  constructor(
    private router: Router, private currentRoute: ActivatedRoute,
    private authService: AuthenticationService,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private opportunity: OpportunityService,
    private alertUtil: AlertUtility) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.loadDealDetails()
    })
  }

  ngOnInit(): void {
    this.currentrealm = this.authService.getRealm()
    this.loadDealDetails()
    this.util.setBodyBackground("white");
  }
  loadDealDetails() {
    if (this.util.getClientId()) {
      const dealId = this.currentRoute.snapshot.paramMap.get('dealId')?.toString()
      if (!dealId) {
        this.alertUtil.showAlert('error', "No DealId found.")
        return
      }

      this.isLoading = true;
      const pOpportunity = this.opportunity.getOpportunityDetails(dealId);
      const pStages = this.opportunity.getOpportunityStages();
      this.snapshot$ = forkJoin([pOpportunity, pStages]).subscribe({
        next: (resp: any) => {
          this.dealDetails = resp[0]
          this.checkDealDetails(this.dealDetails)
          this.stageList = resp[1]
          this.isLoading = false
        },
        error: (err: any) => {
          this.alertUtil.showAlert('error', err)
          this.isLoading = false
        },
      })
    }
  }
  checkDealDetails(dealDetails: any) {
    if (!dealDetails?.dealInfo)
      this.alertUtil.showAlert('error', "Deal Details not found")
    else if (!dealDetails?.stages)
      this.alertUtil.showAlert('error', "Deal Stages not found")
    else if (!dealDetails?.customerDetails)
      this.alertUtil.showAlert('error', "Customer Details not found")
    else if (!dealDetails?.detailInfo)
      this.alertUtil.showAlert('error', "Deal Detail Info not found")
  }

  ngOnDestroy() {
    this.snapshot$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }
  onMenuClick(url: string) {
    this.router.navigate(
      [`/${url}`],
      { queryParams: { realm: this.authService.getRealm() } }
    );
  }
}

