import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-deal-header',
  templateUrl: './deal-header.component.html',
  styleUrls: ['./deal-header.component.scss']
})
export class DealHeaderComponent implements OnInit {
  @Input() dealInfo: any
  @Input() detailInfo: any
  constructor() { }

  ngOnInit(): void {
  }

}
