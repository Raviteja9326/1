export interface DetailInfoType {
    id: number, key: string, name: string
  }
  