import { DetailInfoType } from "./deatil-info.model";

export const detailInfoType: DetailInfoType[] = [
  {
    id: 1,
    key: "activities",
    name: "ACTIVITY"
  },
  {
    id: 2,
    key: "detail",
    name: "DETAILS"
  },
  {
    id: 3,
    key: "request",
    name: "RAISE A REQUEST"
  }
]