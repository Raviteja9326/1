import { Component, Input, OnInit } from '@angular/core';
import _ from 'lodash';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss']
})
export class StepperComponent implements OnInit {
  @Input() stageList!: any[]
  @Input() currentStage!: string
  stages!: any[];

  constructor() { }

  ngOnInit(): void {
    this.stages = _.cloneDeep(this.stageList)
    const currentStageIndex = this.stages.findIndex(s => s.stageId === this.currentStage)
    for (let i = 0; i < currentStageIndex; i++) {
      this.stages[i].class = "completed"
    }
    this.stages[currentStageIndex].class = "active"
    // console.log(this.stageList)
  }

}
