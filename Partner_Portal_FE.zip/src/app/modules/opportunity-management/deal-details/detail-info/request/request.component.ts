import { Component, Input, OnInit } from '@angular/core';
import { CommonUtilService } from 'src/app/modules/utils/common-util.service';
import { appConfig } from "src/app/app.config";
import { OpportunityService } from '../../../opportunity.service';
import { concat, Observable, Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { debounceTime, shareReplay } from 'rxjs/operators';
import { AlertUtility } from 'src/app/modules/utils/alert.util';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss']
})
export class RequestComponent implements OnInit {
  @Input() requests!: any;
  detailRequest: any;
  loginInfo: any;
  commentPost$!: Subscription;
  commentRequests: any = "";
  isLoading: boolean = false;
  loggedUser: any;
  maxChars = 200;
  constructor(private util: CommonUtilService, private opportunityService: OpportunityService,
    private currentRoute: ActivatedRoute, private alertUtil: AlertUtility,) { }

  ngOnInit(): void {
    this.loginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo);
    this.requests.map((comentsby: any) => {
      var matches = comentsby.commentedBy.match(/\b(\w)/g)
      const initials = matches.join('').toUpperCase()
      for (let i = 0; i < this.requests.length; i++) {
        if (comentsby.commentedBy == this.requests[i].commentedBy) {
          this.requests[i]['photo'] = initials
        }
      }
    });
  }

  onPostClick() {
    this.isLoading = true;
    const dealId = this.currentRoute.snapshot.paramMap.get('dealId')?.toString()
    const payLoad = { "nid": dealId, "fieldComment": this.commentRequests }
    this.opportunityService.OppurtunityAddComment(payLoad).subscribe((resp) => {
      if (resp) {
        setTimeout(() => {
          this.commentPost$ = this.opportunityService.getOpportunityDetails(dealId).subscribe((resp) => {
            this.requests = resp.detailInfo.requests;
            this.requests.map((comentsby: any) => {
              var matches = comentsby.commentedBy.match(/\b(\w)/g)
              const initials = matches.join('').toUpperCase()
              for (let i = 0; i < this.requests.length; i++) {
                if (comentsby.commentedBy == this.requests[i].commentedBy) {
                  this.requests[i]['photo'] = initials
                }
              }
            });
          })
        }, 100);
      }
      (error: any) => {
        this.alertUtil.showAlert("error", error.error.message);
        this.isLoading = false;
      }
      this.commentRequests = "";
    })
  }

  onChange(data: any) {
    console.log(data)
  }

  ngOnDestroy() {
    this.commentPost$?.unsubscribe();
  }
}
