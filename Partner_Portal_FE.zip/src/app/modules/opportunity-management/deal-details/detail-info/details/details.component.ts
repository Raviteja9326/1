import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { AlertUtility } from 'src/app/modules/utils/alert.util';
import { OpportunityService } from '../../../opportunity.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  @Input() details: any;
  isLoading: boolean = false;
  forecastGet$!: Subscription;
  opportunityGet$!: Subscription;
  tableConfig: any = {}
  revenueData: any;
  constructor(private opportunity: OpportunityService, private alertUtil: AlertUtility, private currentRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getOpportunity()
    this.tableConfig = {
      hideOnClickOutside: true,
      showFooter: false,
      headerStyle: {
        "height": "80px"
      },
      pagination: {
        pageSize: 2
      },
      columns: [
        {
          columnTitle: "Year",
          dataField: "year",
          classes: ["ellipsis"],
          headerStyle: {
            "width": "80px"
          },
        }, {
          columnTitle: "Quarter1",
          dataField: "quarter1",
          isFilterable: false,
          dataType: "currency",
          headerStyle: {
            "width": "80px"
          },
        },
        {
          columnTitle: "Quarter2",
          dataField: "quarter2",
          dataType: "currency",
          isFilterable: false,
          headerStyle: {
            "width": "80px"
          },
        },
        {
          columnTitle: "Quarter3",
          dataType: "currency",
          dataField: "quarter3",
          isFilterable: false,
          headerStyle: {
            "width": "80px"
          },
        },
        {
          columnTitle: "Quarter4",
          dataType: "currency",
          dataField: "quarter4",
          isFilterable: false,
          headerStyle: {
            "width": "80px"
          },
        },
        {
          columnTitle: "Total Revenue",
          dataType: "currency",
          isFilterable: false,
          dataField: "totalForecast",
          headerStyle: {
            "width": "80px"
          },
        },
      ]
    }
  }

  getOpportunity() {
    this.isLoading = true;
    const dealId = this.currentRoute.snapshot.paramMap.get('dealId')?.toString()
    this.opportunityGet$ = this.opportunity.getOpportunityDetails(dealId).subscribe({
      next: (resp: any) => {
        this.isLoading = false
        console.log(resp.dealInfo.organizationName)
        this.getRevenueForecastData(resp.dealInfo.organizationName, dealId)
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error)
        this.isLoading = false
      }
    })
  }

  getRevenueForecastData(opportunityName: any, dealId: any) {
    this.forecastGet$ = this.opportunity.getRevenueForecast(opportunityName, dealId).subscribe({
      next: (resp: any) => {
        this.isLoading = false
        this.revenueData = resp.forecasts
        console.log(this.revenueData)
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error)
        this.isLoading = false
      }
    })
  }

}
