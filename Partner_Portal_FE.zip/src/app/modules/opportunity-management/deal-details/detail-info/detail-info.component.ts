import { Component, Input, OnInit } from '@angular/core';
import { detailInfoType } from '../detail-info.config';
import { MatTabsModule } from '@angular/material/tabs';
import { OpportunityService } from '../../opportunity.service';
import { AlertUtility } from 'src/app/modules/utils/alert.util';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-detail-info',
  templateUrl: './detail-info.component.html',
  styleUrls: ['./detail-info.component.scss'],
})
export class DetailInfoComponent implements OnInit {
  @Input() detailInfo: any;
  detailInfoTypes: any;
  dealdetails$: any;
  dealInfo: any;
  selectTab: any;
  isTabActivity: boolean = true;
  isTabDetails: boolean = false;
  isTabRequest: boolean = false;
  active=0;

  constructor(
    private opportunity: OpportunityService,
    private alertUtil: AlertUtility,
    private currentRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.detailInfoTypes = detailInfoType;
    console.log(this.detailInfo)
  }

  tabSelected(event:any) {
    this.selectTab=""
    this.selectTab = event.tab.textLabel;
    if(this.selectTab == "ACTIVITY"){
      this.isTabActivity = true
      this.isTabDetails = false;
      this.isTabRequest = false;
    }
    if(this.selectTab == "DETAILS"){
      this.isTabDetails = true
      this.isTabActivity = false
      this.isTabRequest = false;
    }
    if(this.selectTab == "RAISE A REQUEST"){
      this.isTabRequest = true
      this.isTabDetails = false
      this.isTabActivity = false

    }
  }
}
