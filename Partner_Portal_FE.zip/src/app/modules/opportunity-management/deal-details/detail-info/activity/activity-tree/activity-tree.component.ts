import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-tree',
  templateUrl: './activity-tree.component.html',
  styleUrls: ['./activity-tree.component.scss']
})
export class ActivityTreeComponent implements OnInit {
  @Input() acivityTree: any;
  constructor() { }

  ngOnInit(): void {
   
  }

}