import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-group',
  templateUrl: './activity-group.component.html',
  styleUrls: ['./activity-group.component.scss']
})
export class ActivityGroupComponent implements OnInit {
  @Input() acivityGroup: any;
  constructor() { }

  ngOnInit(): void {
  }

}