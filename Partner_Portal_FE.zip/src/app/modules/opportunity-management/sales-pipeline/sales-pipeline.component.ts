import { Component, Input, OnInit } from '@angular/core';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';
import { EventBusService } from '../../shared/event-bus.service';
import { Events } from 'src/app/models/app.enums';
import { OpportunityService } from '../opportunity.service';

@Component({
  selector: 'app-sales-pipeline',
  templateUrl: './sales-pipeline.component.html',
  styleUrls: ['./sales-pipeline.component.scss']
})
export class SalesPipelineComponent implements OnInit {

  gaugeGraphData: { id: string; consumption: number; data: []; rules: [] } = { id: "guageChart", consumption: 0, data: [], rules: [] };
  funnelGraph$: any;
  salesGraph$: any;
  salesChartData!: { id: string; consumption: number; data: []; rules: [] };
  salesGraphData: { label: string, value: number, color: string }[] = [];
  rules!: { rule: string; "background-color": string; }[];
  isLoading: boolean = false;
  clientChangeSub$: any;
  dealRegistrationSub$: any;
  @Input("origin") origin = "";

  constructor(
    private alertUtil: AlertUtility,
    private util: CommonUtilService,
    private eventBusService: EventBusService,
    private opportunity: OpportunityService) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.loadGraphData()
    })
    this.dealRegistrationSub$ = this.eventBusService.on(Events.DealRefresh, (params: any) => {
      this.loadGraphData()
    })
  }

  ngOnInit(): void {
    this.loadGraphData()
  }
  loadGraphData() {
    if (this.util.getClientId()) {
      this.isLoading = true;
      this.funnelGraph$ = this.opportunity.getFunnelChartData().subscribe({
        next: (resp: any) => {
          this.salesGraphData = resp
          this.isLoading = false
        },
        error: (err) => {
          this.alertUtil.showAlert('error', err)
          this.isLoading = false

        },
      })
    }
  }
  ngOnDestroy() {
    this.funnelGraph$?.unsubscribe();
    this.salesGraph$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
    this.dealRegistrationSub$?.unsubscribe();
  }
}
