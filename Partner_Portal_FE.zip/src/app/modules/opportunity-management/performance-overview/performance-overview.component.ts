import { Component, OnInit } from '@angular/core';
import { FeatureList } from 'src/app/models/app.enums';

@Component({
  selector: 'app-performance-overview',
  templateUrl: './performance-overview.component.html',
  styleUrls: ['./performance-overview.component.scss']
})
export class PerformanceOverviewComponent implements OnInit {
  feature!: typeof FeatureList;

  constructor() { }

  ngOnInit(): void {
    this.feature = FeatureList

  }

}
