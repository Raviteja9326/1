import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: '[summary-card]',
  templateUrl: './summary-card.component.html',
  styleUrls: ['./summary-card.component.scss']
})
export class SummaryCardComponent implements OnInit {
  @Input() card: any
  constructor() { }

  ngOnInit(): void {
    this.card.summary.forEach((item:any) => {
      item.icon = `assets/icons/forecasting/${this.card.title?.split(" ")[0]?.toLowerCase().trim()}-${item.name?.split(" ")[0]?.toLowerCase().trim()}.png`
    });
  }

}
