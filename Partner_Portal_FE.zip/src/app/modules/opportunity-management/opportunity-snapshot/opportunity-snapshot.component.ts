import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';
import { Subscription } from 'rxjs';
import { EventBusService } from '../../shared/event-bus.service';
import { Events } from 'src/app/models/app.enums';
import { CommonUtilService } from '../../utils/common-util.service';
import { OpportunityService } from '../opportunity.service';
import { AlertUtility } from '../../utils/alert.util';

@Component({
  selector: 'app-opportunity-snapshot',
  templateUrl: './opportunity-snapshot.component.html',
  styleUrls: ['./opportunity-snapshot.component.scss']
})
export class OpportunitySnapshotComponent implements OnInit {
  clientChangeSub$: Subscription;
  isLoading: boolean = false;
  snapshot$!: Subscription;
  opportunitySnapshotData: any;
  dealRegistrationSub$: Subscription;
  @Input("origin") origin = "";


  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private opportunity: OpportunityService,
    private alertUtil: AlertUtility) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.loadSnapshotData()
    })
    this.dealRegistrationSub$ = this.eventBusService.on(Events.DealRefresh, (params: any) => {
      this.loadSnapshotData()
    })
  }

  ngOnInit(): void {

    this.loadSnapshotData()
  }
  loadSnapshotData() {
    if (this.util.getClientId()) {
      this.isLoading = true;
      this.snapshot$ = this.opportunity.getOpportunitySnapshotData().subscribe({
        next: (resp: any) => {
          this.opportunitySnapshotData = resp
          this.isLoading = false
        },
        error: (err: any) => {
          this.alertUtil.showAlert('error', err)
          this.isLoading = false

        },
      })
    }
  }

  ngOnDestroy() {
    this.snapshot$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
    this.dealRegistrationSub$?.unsubscribe()
  }
  onMenuClick(url: string) {
    this.router.navigate(
      [`/${url}`],
      { queryParams: { realm: this.authService.getRealm() } }
    );
  }
}


