import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunitySnapshotComponent } from './opportunity-snapshot.component';

describe('OpportunitySnapshotComponent', () => {
  let component: OpportunitySnapshotComponent;
  let fixture: ComponentFixture<OpportunitySnapshotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpportunitySnapshotComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunitySnapshotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
