import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OpportunityManagementRoutingModule } from './opportunity-management-routing.module';
import { RegisterDealComponent } from './register-deal/register-deal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SwitchComponent } from './switch/switch.component';
import { MatIconModule } from '@angular/material/icon';
import { DirectivesModule } from '../directives/directives.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { OpportunitySnapshotComponent } from './opportunity-snapshot/opportunity-snapshot.component';
import { SalesPipelineComponent } from './sales-pipeline/sales-pipeline.component';
import { DealListComponent } from './deal-list/deal-list.component';
import { DealDetailsComponent } from './deal-details/deal-details.component';
import { ChartingModule } from '../charting/charting.module';
import { SummaryCardComponent } from './opportunity-snapshot/summary-card/summary-card.component';
import { SummaryComponent } from './opportunity-snapshot/summary-card/summary/summary.component';
import { PipesModule } from '../pipes/pipes.module';
import { DealHeaderComponent } from './deal-details/deal-header/deal-header.component';
import { DetailInfoComponent } from './deal-details/detail-info/detail-info.component';
import { CustomerDetailComponent } from './deal-details/customer-detail/customer-detail.component';
import { StepperComponent } from './deal-details/stepper/stepper.component';
import { MatTabsModule } from '@angular/material/tabs';
import { ActivityComponent } from './deal-details/detail-info/activity/activity.component';
import { ActivityTreeComponent } from './deal-details/detail-info/activity/activity-tree/activity-tree.component';
import { ActivityGroupComponent } from './deal-details/detail-info/activity/activity-tree/activity-group/acivity-group.component';
import { RegisterDealAwsComponent } from './register-deal-aws/register-deal-aws.component';
import { FormGeneratorModule } from '../form-generator/form-generator.module';
import { MaterialModule } from '../shared/material/material.module';
import { DetailsComponent } from './deal-details/detail-info/details/details.component'
import { RequestComponent } from './deal-details/detail-info/request/request.component';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { RevenueForecastComponent } from './revenue-forecast/revenue-forecast.component';
import { ForecastComponent } from './revenue-forecast/forecast/forecast.component';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { EditDealAwsComponent } from './edit-deal-aws/edit-deal-aws.component';
import { SalesPerformanceComponent } from './sales-performance/sales-performance.component';
import { PerformanceOverviewComponent } from './performance-overview/performance-overview.component';
import { ConversionMetricsComponent } from './conversion-metrics/conversion-metrics.component';
import { MydealsComponent } from './mydeals/mydeals.component';
import { LeadsComponent } from './leads/leads.component';


@NgModule({
  declarations: [
    RegisterDealComponent,
    SwitchComponent,
    OpportunitySnapshotComponent,
    SalesPipelineComponent,
    DealListComponent,
    DealDetailsComponent,
    SummaryCardComponent,
    SummaryComponent,
    DealHeaderComponent,
    DetailInfoComponent,
    CustomerDetailComponent,
    StepperComponent,
    ActivityComponent,
    ActivityTreeComponent,
    ActivityGroupComponent,
    RegisterDealAwsComponent,
    DetailsComponent,
    RequestComponent,
    RevenueForecastComponent,
    ForecastComponent,
    EditDealAwsComponent,
    SalesPerformanceComponent,
    PerformanceOverviewComponent,
    ConversionMetricsComponent,
    MydealsComponent,
    LeadsComponent
  ],
  imports: [
    CommonModule,
    OpportunityManagementRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    MatIconModule,
    DirectivesModule,
    ChartingModule,
    PipesModule,
    MatTabsModule,
    FormGeneratorModule,
    MaterialModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    CdkAccordionModule,
  ],
  exports: [
    // OpportunitySnapshotComponent,
    // SalesPipelineComponent,
    DealListComponent,
    DealDetailsComponent,
    SalesPerformanceComponent

  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class OpportunityManagementModule { }
