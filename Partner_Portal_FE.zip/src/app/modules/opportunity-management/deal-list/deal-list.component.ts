import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';
import { OpportunityService } from '../opportunity.service';
import { Events } from 'src/app/models/app.enums';
import { Deal } from './deal-list.model';
import { Popups } from '../../shared/popup/popup-mapper';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-deal-list',
  templateUrl: './deal-list.component.html',
  styleUrls: ['./deal-list.component.scss']
})
export class DealListComponent implements OnInit {
  isLoading: boolean = false;
  myDeal$: any;
  clientChangeSub$: any;
  myDeals: any;
  dealRegistrationSub$: any;
  selectedUpdate!: Deal;
  updateDeal$!: Subscription;

  constructor(
    private router: Router,
    private currentRoute: ActivatedRoute,
    private authService: AuthenticationService,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private opportunity: OpportunityService,
    private alertUtil: AlertUtility) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.loadMyDeals()
    })
    this.dealRegistrationSub$ = this.eventBusService.on(Events.DealRefresh, (params: any) => {
      this.loadMyDeals()
    })
  }

  ngOnInit(): void {
    this.loadMyDeals()

  }
  loadMyDeals() {
    if (this.util.getClientId()) {
      this.isLoading = true;
      this.myDeal$ = this.opportunity.getMyDeals().subscribe({
        next: (resp: any) => {
          this.myDeals = resp
          this.isLoading = false
        },
        error: (err: any) => {
          this.alertUtil.showAlert('error', err)
          this.isLoading = false

        },
      })
    }
  }

  ngOnDestroy() {
    this.myDeal$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
    this.dealRegistrationSub$?.unsubscribe();
  }

  showDetails(event: any, scope: any, args: any = {}) {
    event.stopPropagation();
    console.log(`Scope: ${scope} values: ${JSON.stringify(args)}`);
    scope.router.navigate([`deal-details/${args.nid}`], {
      queryParams: { realm: scope.authService.getRealm() },
    });
  }

  edit(event: any, scope: any, dealInfo: Deal,) {
    event.stopPropagation();
    scope.eventBusService.emit({
      name: Events.ShowModalPopup, value: {
        modalId: Popups.EditDealAws, title: "Edit Deal",
        params: [
          { key: "dealInfo", value: dealInfo },
          { key: "tabIndex", value: 0 },
        ]
      },

    })
  }
  addForecast(event: any, scope: any, dealInfo: Deal,) {
    event.stopPropagation();
    scope.eventBusService.emit({
      name: Events.ShowModalPopup, value: {
        modalId: Popups.EditDealAws, title: "Edit Deal",
        params: [
          { key: "dealInfo", value: dealInfo },
          { key: "tabIndex", value: 1 },
        ]
      },

    })
  }

  tableConfig = {
    hideOnClickOutside: true,
    showFooter: false,
    classes: [
      "border",
    ],
    pagination: {
      pageSize: 2
    },
    row: { //configuration for row
      isClickable: true,
      events: [{
        name: "click",
        scope: this,
        callback: this.showDetails
      }],
    },
    columns: [
      {
        columnTitle: "Deal Name",
        dataField: "dealName",
        classes: ["ellipsis"],
        headerStyle: {
          "width": "10%"
        },
      }, {
        columnTitle: "Customer Name",
        dataField: "customerName",
        classes: ["ellipsis"],
        headerStyle: {
          "width": "14%"
        },
      }, {
        columnTitle: "TCV",
        dataField: "amount",
        classes: ["ellipsis"],
        isFilterable: false,
        headerStyle: {
          "width": "8%",
        },
        dataType: "currency",
        format: {
          unit: "USD",
          symbol: '1.0-0'
        },
        style: {
          "justify-content": "right",
          "text-align": "right",
          "padding-right": "5px"
        },
      }, {
        columnTitle: "Industry",
        dataField: "industry",
        classes: ["ellipsis"],
        headerStyle: {
          "width": "10%"
        },
      }, {
        columnTitle: "Stage",
        dataField: "stage",
        classes: ["ellipsis"],
        headerStyle: {
          "width": "8%"
        },
      }, {
        columnTitle: "Created Date",
        dataField: "createdOn",
        classes: ["ellipsis"],
        headerStyle: {
          "width": "10%"
        },
        isFilterable: false,
        dataType: "dateTime",
        format: "YYYY-MM-dd",
      }, {
        columnTitle: "Close Date",
        dataField: "closedOn",
        classes: ["ellipsis"],
        headerStyle: {
          "width": "10%"
        },
        dataType: "dateTime",
        format: "YYYY-MM-dd",
        isFilterable: false
      }, {
        columnTitle: "Revenue Forecast",
        dataField: "revenueForecast",
        isFilterable: false,
        headerStyle: { "width": "12%" },
        dataType: "currency",
        format: {
          unit: "USD",
          symbol: '1.0-0'
        },
        style: {
          "justify-content": "right",
          "text-align": "right",
          "padding-right": "15px"
        },
      },
      {
        tag: "actions",
        isFilterable: false,
        isSortable: false,
        headerStyle: { "width": "12%" },
        actions: [
          {
            title: "Edit",
            icon: "edit",
            callback: this.edit,
            scope: this,
          },
          {
            title: "Add Forecast",
            // icon: "edit",
            callback: this.addForecast,
            scope: this,
            conditions: [
              {
                dataField: "revenueForecast",
                value: "",
              }
            ]
          },
        ]
      }
    ]
  }
}
