export interface Deal {
  dealName?: string,
  customerName?: string,
  amount?: string,
  industry?: string,
  stage?: Date,
  createdOn?: string,
  closedOn?: string,
  nid?: string
  action?: string,
  readonly?: boolean,
  opportunityName: string

}