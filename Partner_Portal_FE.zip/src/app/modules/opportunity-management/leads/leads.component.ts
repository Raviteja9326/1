import { Component, OnInit } from '@angular/core';
import { Events } from 'src/app/models/app.enums';
import { AuthenticationService } from '../../authentication/authentication.service';
import { EventBusService } from '../../shared/event-bus.service';
import { Popups } from '../../shared/popup/popup-mapper';

@Component({
  selector: 'app-leads',
  templateUrl: './leads.component.html',
  styleUrls: ['./leads.component.scss']
})
export class LeadsComponent implements OnInit {

  constructor(private authService: AuthenticationService, private eventBusService: EventBusService) { }

  ngOnInit(): void {
  }

  registerDeal(){
    if (this.authService.getRealm().toLowerCase() === "aws")
      this.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.RegisterDealAws, title: "Register a Deal" } })
    else
      this.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.RegisterDeal, title: "Register a Deal" } })

  }
}
