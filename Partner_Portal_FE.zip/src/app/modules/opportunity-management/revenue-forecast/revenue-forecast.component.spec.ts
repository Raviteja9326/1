import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RevenueForecastComponent } from './revenue-forecast.component';

describe('RevenueForecastComponent', () => {
  let component: RevenueForecastComponent;
  let fixture: ComponentFixture<RevenueForecastComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RevenueForecastComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RevenueForecastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
