import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import _ from 'lodash';
import { Subscription } from 'rxjs';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { OpportunityService } from '../opportunity.service';
import { Events } from 'src/app/models/app.enums';
import { data } from 'jquery';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-revenue-forecast',
  templateUrl: './revenue-forecast.component.html',
  styleUrls: ['./revenue-forecast.component.scss']
})
export class RevenueForecastComponent implements OnInit {
  @Input() dealInfo!: any;
  forecastCreate$!: Subscription;
  isLoading: boolean = false
  frmRevenueForecast!: FormGroup;
  years!: number[];
  dealYearCount: number = 6
  forecastGet$!: Subscription;
  defaultFormValue: any = { forecasts: [] }
  constructor(private opportunity: OpportunityService, private fb: FormBuilder, private alertUtil: AlertUtility, private eventBusService: EventBusService, private util: CommonUtilService) { }

  ngOnInit(): void {
    this.years = Array.from({ length: this.dealYearCount }, (value, index) => index + (new Date()).getFullYear())
    this.loadForecasts();
    // this.appendForecast()
  }

  onQuarterUpdate(forecast: any) {
    const sum =
      this.util.toNumber(forecast.get('quarter1').value) +
      this.util.toNumber(forecast.get('quarter2').value) +
      this.util.toNumber(forecast.get('quarter3').value) +
      this.util.toNumber(forecast.get('quarter4').value)

    forecast.get('totalForecast').setValue(sum)
  }

  expandForecast(index: number) {
    this.forecasts.controls.forEach((forecast, i) => {
      forecast.get('expanded')?.setValue(false)
    });
    this.forecasts.controls[index].get('expanded')?.setValue(true)
  }

  loadForecasts() {
    this.isLoading = true;
    this.forecastGet$ = this.opportunity.getRevenueForecast(this.dealInfo.opportunityName, this.dealInfo.nid).subscribe({
      next: (resp: any) => {
        this.isLoading = false
        resp.forecasts.forEach((forecast: any, index: number) => {
          forecast.quarter1 = this.util.numberToCurrency(forecast.quarter1)
          forecast.quarter2 = this.util.numberToCurrency(forecast.quarter2)
          forecast.quarter3 = this.util.numberToCurrency(forecast.quarter3)
          forecast.quarter4 = this.util.numberToCurrency(forecast.quarter4)
          forecast.expanded = index === 0 ? true : false;
        })
        this.defaultFormValue = resp;
        this.reset()
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error)
        this.isLoading = false
      }
    })
  }

  get forecasts(): FormArray {
    return this.frmRevenueForecast.get('forecasts') as FormArray;
  }

  appendForecast() {
    if (this.forecasts.length >= this.dealYearCount) return;
    this.forecasts.push(
      new FormGroup({
        forecastNid: new FormControl(''),
        year: new FormControl('', Validators.required),
        quarter1: new FormControl(''),
        quarter2: new FormControl(''),
        quarter3: new FormControl(''),
        quarter4: new FormControl(''),
        totalForecast: new FormControl('', Validators.required),
        expanded: new FormControl(false)
      })
    )
    this.expandForecast(this.forecasts.length - 1)
  }

  submitRevenue() {
    const payload = {
      dealNid: this.dealInfo.nid,
      opportunityName: this.dealInfo.opportunityName
    }
    const fullPayload = _.merge(payload, this.getPayload())
    if (this.validateYears(fullPayload)) {
      this.isLoading = true;
      this.forecastCreate$ = this.opportunity.updateRevenueForecast(fullPayload).subscribe({
        next: (resp: any) => {
          this.isLoading = false
          this.alertUtil.showAlert("success", resp.response.message)
          this.eventBusService.emit({ name: Events.HideModelPopup })
          this.eventBusService.emit({ name: Events.DealRefresh })
        },
        error: (error: any) => {
          this.alertUtil.showAlert('error', error)
          this.isLoading = false
        }
      })
    } else {
      this.alertUtil.showAlert("error", "Year must be unique!")
    }
    // console.log(fullPayload)

    // const payload = this.getPayload()
  }
  validateYears(payload: any) {
    const years = payload.forecasts.map((forecast: any) => forecast.year);
    const arrOfNum = years.map((str: any) => {
      return parseInt(str, 10);
    });
    return _.uniq(arrOfNum).length === arrOfNum.length
  }

  getPayload() {
    const formValue: any = _.cloneDeep(this.frmRevenueForecast.value)
    formValue.forecasts.forEach((forecast: any) => {
      forecast.quarter1 = this.util.toNumber(forecast.quarter1)
      forecast.quarter2 = this.util.toNumber(forecast.quarter2)
      forecast.quarter3 = this.util.toNumber(forecast.quarter3)
      forecast.quarter4 = this.util.toNumber(forecast.quarter4)
    })
    return formValue
  }

  ngOnDestroy() {
    this.forecastCreate$?.unsubscribe();
    this.forecastGet$?.unsubscribe();
  }

  reset() {
    let forecasts = new FormArray([]);
    this.frmRevenueForecast = new FormGroup({
      'forecasts': forecasts
    })
    this.defaultFormValue.forecasts.forEach((forecast: any) => {
      this.appendForecast()
    })
    this.frmRevenueForecast.reset(this.defaultFormValue)
  }
}
