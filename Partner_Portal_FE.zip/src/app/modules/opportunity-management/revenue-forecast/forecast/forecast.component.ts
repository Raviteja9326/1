import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.scss']
})
export class ForecastComponent implements OnInit {
  @Input() revenueForecastData: any;
  @Input() form!: FormGroup;
  @Output() updateFormEmitter = new EventEmitter<any>();
  @Input() updateFormData!: any;
  defaultYears!: boolean;
  items = ['Forecast year'];
  expandedIndex = 0;
  frmRevenueForecast!: FormGroup;
  totalRevenue!: any;
  sum: any;
  constructor(private fb: FormBuilder,) { }

  ngOnInit(): void {
    console.log(this.revenueForecastData)
    if (this.revenueForecastData == undefined) {
      this.defaultYears = true
    }
    else this.defaultYears = false
    this.revenueForm()
    setTimeout(() =>
      this.frmRevenueForecast?.patchValue({
        Q1: this.revenueForecastData?.forcastQuarter1,
        Q2: this.revenueForecastData?.forcastQuarter2,
        Q3: this.revenueForecastData?.forcastQuarter3,
        Q4: this.revenueForecastData?.forcastQuarter4,
        year: this.revenueForecastData?.forcastYear,
        total: this.revenueForecastData?.totalForcast
      })
    );
  }

  revenueForm() {
    this.frmRevenueForecast = this.fb.group({
      Q1: ["", Validators.required],
      Q2: ["", Validators.required],
      Q3: ["", Validators.required],
      Q4: ["", Validators.required],
      year: ["", Validators.required],
      total: ["", Validators.required],

    })
  }

  updateForecast(event: any) {
    console.log(event)
  }

  ngOnChanges() {
    console.log('this.frmRevenueForecast.value')
  }

  onNameBlur() {
    this.sum = ''
    this.sum = this.frmRevenueForecast.controls["Q1"].value + this.frmRevenueForecast?.controls["Q2"].value + this.frmRevenueForecast.controls["Q3"].value + this.frmRevenueForecast.controls["Q4"].value
    const total = Object.keys(this.frmRevenueForecast.value).reduce((prev, curr) => {
      return prev + this.frmRevenueForecast.value[curr]
    }, 0);

    this.frmRevenueForecast.controls["total"].setValue(this.sum)
    console.log(this.frmRevenueForecast.value)

    this.updateFormEmitter.emit(this.frmRevenueForecast.value)
  }

  onSave() {
    this.updateFormEmitter.emit("test")
  }

  getSelectedValue(event: any) {
    console.log(event)
  }
}
