import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conversion-metrics',
  templateUrl: './conversion-metrics.component.html',
  styleUrls: ['./conversion-metrics.component.scss']
})
export class ConversionMetricsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
