import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversionMetricsComponent } from './conversion-metrics.component';

describe('ConversionMetricsComponent', () => {
  let component: ConversionMetricsComponent;
  let fixture: ComponentFixture<ConversionMetricsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConversionMetricsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversionMetricsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
