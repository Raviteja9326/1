import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { CommonUtilService } from '../../utils/common-util.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';

@Component({
  selector: 'app-sales-performance',
  templateUrl: './sales-performance.component.html',
  styleUrls: ['./sales-performance.component.scss']
})
export class SalesPerformanceComponent implements OnInit {
  @ViewChild('tabContent', { read: ViewContainerRef, static: true }) tabContent!: ViewContainerRef;

  tabs: { title: string, url: string }[] = [
    {
      title: "Overview", url: "performance-overview"
    },
    {
      title: "My Deals", url: "my-deals"
    },
    // {
    //   title: "Conversion Metrics", url: "conversion-metrics"
    // },
    // {
    //   title: "Target Comparision", url: "target-comparison"
    // }
  ]
  constructor(private util: CommonUtilService, private router:Router, private authService:AuthenticationService) { }

  ngOnInit(): void {
    this.onTabClick()
  }
  onMoreClick(){
    this.router.navigate(['leads'], {
      queryParams: { realm: this.authService.getRealm() }
    });
  }

  selectedIndex: number = 0;
  onTabClick(event: any = { index: 0 }) {
    this.selectedIndex = event.index;
    this.util.showTabContent(this.tabs[this.selectedIndex], this.tabContent)
  }
}
