import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OpportunityService {
  registerDeal(payload: any) {
    const url = `${environment.endpoints.drupal}api/csSalesforceOpportunityCreate`
    return this.http.post(url, payload).pipe(
      map((response: any) => response));
  }
  getOpportunityStages() {
    const url = `${environment.endpoints.drupal}api/csShowSalesforceStages`
    // const url = "assets/data/opportunity/stages.json";
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  getOpportunityDetails(dealId: string | undefined) {
    const url = `${environment.endpoints.drupal}api/csShowDealDetailsData/${dealId}`
    //const url = "assets/data/opportunity/deal-details.json";
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  getMyDeals() {
    const url = `${environment.endpoints.drupal}api/csShowSalesforceOpportunities`
    // const url = "assets/data/opportunity/my-deals.json";
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  getOpportunitySnapshotData() {
    const url = `${environment.endpoints.drupal}api/csShowSalesStageGroupRevenue`
    // const url = "assets/data/opportunity/opportunity-snapshot.json";
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  getFunnelChartData() {
    const url = `${environment.endpoints.drupal}api/csShowSalesStageRevenue`
    // const url = "assets/data/opportunity/funnel-chart.json";
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  OppurtunityAddComment(payload: any) {
    const url = `${environment.endpoints.drupal}api/csSfOpportunityAddComments`
    return this.http.post(url, payload).pipe(
      map((response: any) => response));
  }
  getUpdateForm(id: any) {
    const url = `${environment.endpoints.drupal}api/csShowSalesforceOpportunityUpdateForm/${id}`
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  UpdateDeal(payload: any, id: any) {
    const url = `${environment.endpoints.drupal}api/csSalesforceOpportunityUpdate/${id}`
    return this.http.put(url, payload).pipe(
      map((response: any) => response));
  }
  getRevenueForecast(opportunitynId: string, nid: string) {
    let url: string = ""
    if (opportunitynId)
      url = `${environment.endpoints.drupal}api/csShowSalesforceRevenueForecast?opportunityname=${opportunitynId}`;
    else
      url = `${environment.endpoints.drupal}api/csShowSalesforceRevenueForecast?opportunitynid=${nid}`;

    //const url = "assets/data/opportunity/revenue.json";
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  updateRevenueForecast(payload: any) {
    const url = `${environment.endpoints.drupal}api/csSalesforceOpportunityForecastUpdate`
    return this.http.post(url, payload).pipe(
      map((response: any) => response));
  }
  createRevenueForecast(payload: any) {
    const url = `${environment.endpoints.drupal}api/csSalesforceOpportunityForecast`
    return this.http.post(url, payload).pipe(
      map((response: any) => response));
  }

  constructor(private http: HttpClient) { }
}
