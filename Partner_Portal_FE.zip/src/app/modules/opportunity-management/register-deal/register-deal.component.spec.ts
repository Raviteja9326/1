import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterDealComponent } from './register-deal.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

describe('RegisterDealComponent', () => {
  let component: RegisterDealComponent;
  let fixture: ComponentFixture<RegisterDealComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterDealComponent ],
      imports:[
        HttpClientModule, ReactiveFormsModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterDealComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
