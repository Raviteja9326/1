import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { appConfig, maxLengthValidator } from 'src/app/app.config';
import { Events } from 'src/app/models/app.enums';
import { ServiceCatalogService } from '../../service-catalog/service-catalog.service';
import { ApiService } from '../../shared/api.service';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { Popups } from 'src/app/modules/shared/popup/popup-mapper';
import { InvalidCharactersValidator } from '../../validation/validators/invalid-characters-validator';
import { NoWhitespaceValidator } from '../../validation/validators/no-whitespace-validator';
@Component({
  selector: 'app-register-deal',
  templateUrl: './register-deal.component.html',
  styleUrls: ['./register-deal.component.scss']
})
export class RegisterDealComponent implements OnInit {
  @Input() dealId:any = ""
  isLoading: boolean = false
  cloudList: any = []
  layersList: any = []
  serviceList: any = []
  stateList: any = [];
  countryList: any
  pilotRequired = false
  directOnboarding = false
  registerDealForm!: FormGroup
  allStateList: any;
  makeRegisterSubscription$!: Subscription;
  serverDetailsExpanded: boolean = false
  lcsSub$!: Subscription;
  lifeCycleStages: any = []
  selectedCloud!: any[]
  selectedDeal: any;
  dealSub$!: Subscription;
  totalData: any = [];
  minDate: any = new Date().toISOString().split('T')[0]
  constructor(
    private apiService: ApiService,
    private fb: FormBuilder,
    private catalogService: ServiceCatalogService,
    private eventBusService: EventBusService,
    private alertUtil:AlertUtility) { }
  ngOnInit(): void {
    this.loadDealDropDowns()
    this.isLoading = true
    if (this.dealId == "") {
      setTimeout(() => {
        this.registerForm()
        this.isLoading = false;
      }, 750)
    }
    else {
      this.dealSub$ = this.apiService.getDealById(this.dealId).subscribe((resp: any) => {
        this.selectedDeal = resp[0]
        this.createEditDealForm(this.selectedDeal)
      });
    }
    this.getCountryList()
  }
  onChangeStatus(event: boolean, key: string) {
    (this as Record<string, any>)[key] = event;
    this.pilotRequired ? this.registerDealForm.controls["pilot_start_date"].setValidators(Validators.required) : this.registerDealForm.controls["pilot_start_date"].clearValidators()
    this.pilotRequired ? this.registerDealForm.controls["pilot_start_date"].setValue(this.minDate) : this.registerDealForm.controls["pilot_start_date"].setValue("")
  }
  getCountryList() {
    this.apiService.getCountryList().subscribe((list) => {
      this.countryList = list;
    });
  }
  private loadDealDropDowns() {
    this.lcsSub$ = this.apiService.getDealList().subscribe((resp: any) => {
      this.lifeCycleStages = this.catalogService.jsonToArray(resp.stage)
      this.cloudList = this.catalogService.jsonToArray(resp.customer_infra)
      this.layersList = this.catalogService.jsonToArray(resp.layers_being_onboarded)
      this.serviceList = this.catalogService.jsonToArray(resp.services_being_onboarded)
    })
  }

  onResetForm() {
    this.registerDealForm.reset()
    if (this.selectedDeal)
      this.createEditDealForm(this.selectedDeal)
  }
  submitForm(controls: any) {
    this.isLoading = true;
    const registerDeal = {
      customer_name: controls["customer_name"].value?.trim(),
      customer_domain: controls["customer_domain"].value?.trim(),
      customer_revenue: controls["customer_revenue"].value,
      stage: controls["stage"].value,
      customer_hq_country: controls["customer_hq_country"].value,
      customer_hq: controls["customer_hq"].value,
      customer_infra: controls["customer_infra"].value,
      special_requirements: controls["special_requirements"].value,
      pilot_required: this.pilotRequired,
      layers_being_onboarded: controls["layers_being_onboarded"].value,
      services_being_onboarded: controls["services_being_onboarded"].value,
      pilot_start_date: controls["pilot_start_date"].value,
      startdate: controls["startdate"].value,
      annual_concierto_fee: controls["annual_concierto_fee"].value,
      total_vm: controls["total_vm"].value
    }
    if (this.selectedDeal?.id)
      this.makeRegisterSubscription$ = this.apiService.editRegisterDeal(registerDeal, this.selectedDeal?.id).subscribe(
        (resp: any) => {
          if (resp.response.status === 'success') {
            this.alertUtil.showAlert("success", resp.response.message)
            this.eventBusService.emit({ name: Events.HideModelPopup, value: { modalId: Popups.RegisterDeal, title: "Register a Deal" } });
            this.isLoading = false;
          }
          else
            this.alertUtil.showAlert("error", resp.response.message)
        }, (error: any) => {
          this.alertUtil.showAlert("error", error)
          this.isLoading = false;
        });
    else
      this.makeRegisterSubscription$ = this.apiService.submitRegisterDeal(registerDeal).subscribe(
        (resp: any) => {
          if (resp.response.status === 'success') {
            this.alertUtil.showAlert("success", resp.response.message)
            this.eventBusService.emit({ name: Events.HideModelPopup });
            this.isLoading = false;
          }
          else
            this.alertUtil.showAlert("error", resp.response.message)
        }, (error: any) => {
          this.alertUtil.showAlert("error", error)
          this.isLoading = false;
        });
  }
  registerForm() {
    this.registerDealForm = this.fb.group({
      customer_name: ["", [
        Validators.required,
        NoWhitespaceValidator.isValid(),
        Validators.maxLength(appConfig.textMaxLength.xs),
        InvalidCharactersValidator.isValid()
      ]],
      customer_domain: ["", Validators.maxLength(100)],
      customer_revenue: [""],
      stage: this.lifeCycleStages[0]?.id ?? "",
      customer_hq_country: [""],
      customer_hq: ["", Validators.maxLength(100)],
      customer_infra: ["", Validators.required],
      total_vm: ["", Validators.required],
      special_requirements: [""],
      pilot_start_date: [""],
      layers_being_onboarded: ["", Validators.required],
      services_being_onboarded: ["", Validators.required],
      startdate: ["", Validators.required],
      annual_concierto_fee: ["", Validators.required],
    })
  }
  createEditDealForm(selectedDeal: any) {
    if (selectedDeal) {
      this.pilotRequired = selectedDeal.pilot_required == "Yes" ? true : false
      this.registerDealForm = this.fb.group({
        customer_name: [selectedDeal.customer_name ?? "", [
          Validators.required,
          NoWhitespaceValidator.isValid(),
          Validators.maxLength(appConfig.textMaxLength.xs),
          InvalidCharactersValidator.isValid()
        ]],
        customer_domain: [selectedDeal.customer_domain ?? "", Validators.maxLength(100)],
        customer_revenue: [selectedDeal.customer_revenue ?? ""],
        stage: [selectedDeal.stage ?? ""],
        customer_hq_country: [selectedDeal.customer_hq_country ?? ""],
        customer_hq: [selectedDeal.customer_hq ?? "", Validators.maxLength(100)],
        customer_infra: [selectedDeal.customer_infra?.split(",") ?? "", Validators.required],
        total_vm: [selectedDeal.total_vm ?? "", Validators.required],
        special_requirements: [selectedDeal.special_requirements ?? ""],
        pilot_start_date: [selectedDeal.pilot_start_date ?? ""],
        layers_being_onboarded: [selectedDeal.layers_being_onboarded?.split(",") ?? "", Validators.required],
        services_being_onboarded: [selectedDeal.services_being_onboarded?.split(",") ?? "", Validators.required],
        startdate: [selectedDeal.estimated_start_date ?? "", Validators.required],
        annual_concierto_fee: [selectedDeal.annual_concierto_fee ?? "", Validators.required],
        pilot_required: this.pilotRequired
      });
      this.isLoading = false
    }
  }
  ngOnDestroy() {
    this.makeRegisterSubscription$?.unsubscribe();
  }
}
