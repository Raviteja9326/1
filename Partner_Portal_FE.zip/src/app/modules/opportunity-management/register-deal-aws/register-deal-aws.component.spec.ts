import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterDealAwsComponent } from './register-deal-aws.component';

describe('RegisterDealAwsComponent', () => {
  let component: RegisterDealAwsComponent;
  let fixture: ComponentFixture<RegisterDealAwsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterDealAwsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterDealAwsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
