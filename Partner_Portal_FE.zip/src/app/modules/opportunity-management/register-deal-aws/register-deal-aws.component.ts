import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { OpportunityService } from '../opportunity.service';
import { AlertUtility } from '../../utils/alert.util';
import { Events } from 'src/app/models/app.enums';
import _ from 'lodash';
import { Subscription } from 'rxjs';
import { EventBusService } from '../../shared/event-bus.service';
import { FormGeneratorService } from '../../form-generator/form-generator.service';

@Component({
  selector: 'app-register-deal-aws',
  templateUrl: './register-deal-aws.component.html',
  styleUrls: ['./register-deal-aws.component.scss']
})
export class RegisterDealAwsComponent implements OnInit {
  @Input() dealId!: string;
  @Input() editMode: boolean = false

  isLoading: boolean = false
  frmRegisterDeal!: FormGroup
  jsonFormGroups!: any[];

  formDataSub$!: Subscription;
  registerDealSub$!: Subscription;
  editFormDataSub$!: Subscription;
  editDealSub$!: Subscription;


  constructor(
    private opportunity: OpportunityService,
    private alertUtil: AlertUtility,
    private fb: FormBuilder,
    private formGeneratorService: FormGeneratorService,
    private eventBusService: EventBusService) { }

  ngOnInit(): void {
    this.frmRegisterDeal = this.fb.group({});
    if (this.dealId) {
      this.loadEditFormData(this.dealId)
    }
    else
      this.loadFormGeneratingData()
  }

  loadEditFormData(dealId: string) {
    this.isLoading = true
    //const url = "api/csShowSalesforceOpportunityForm";
    this.editFormDataSub$ = this.opportunity.getUpdateForm(dealId).subscribe({
      next: (resp: any[]) => {
        this.jsonFormGroups = resp;
        console.log(this.jsonFormGroups)
        this.isLoading = false
      },
      error: (error) => {
        this.alertUtil.showAlert('error', error)
        this.isLoading = false
      }
    });
  }

  loadFormGeneratingData() {
    this.isLoading = true
    const url = "api/csShowSalesforceOpportunityForm";
    this.formDataSub$ = this.formGeneratorService.getDynamicFormGeneratorData(url).subscribe({
      next: (resp: any[]) => {
        this.jsonFormGroups = resp;
        this.isLoading = false
      },
      error: (error) => {
        this.alertUtil.showAlert('error', error)
        this.isLoading = false
      }
    });
  }

  registerDeal() {
    const payload: any = this.getPayload(this.frmRegisterDeal.value)
    if (this.frmRegisterDeal.valid && this.formGeneratorService.validateData(payload, this.jsonFormGroups)) {
      this.isLoading = true
      this.registerDealSub$ = this.opportunity.registerDeal(payload).subscribe({
        next: (resp: any) => {
          this.isLoading = false;
          this.alertUtil.showAlert("success", resp.response.message)
          this.eventBusService.emit({ name: Events.HideModelPopup })
          this.eventBusService.emit({ name: Events.DealRefresh })
        },
        error: (error: any) => {
          this.alertUtil.showAlert('error', error)
          this.isLoading = false
        }
      })
    } else {
      this.focusInvalidField();
    }
  }

  editDeal() {
    const payload: any = this.getPayload(this.frmRegisterDeal.value)
    if (this.frmRegisterDeal.valid && this.formGeneratorService.validateData(payload, this.jsonFormGroups)) {
      this.isLoading = true
      this.editDealSub$ = this.opportunity.UpdateDeal(payload, this.dealId).subscribe({
        next: (resp: any) => {
          this.isLoading = false;
          this.alertUtil.showAlert("success", resp.response.message)
          this.eventBusService.emit({ name: Events.HideModelPopup })
          this.eventBusService.emit({ name: Events.DealRefresh })
        },
        error: (error: any) => {
          this.alertUtil.showAlert('error', error)
          this.isLoading = false
        }
      })
    } else {
      this.focusInvalidField();
    }
  }

  private focusInvalidField() {
    this.frmRegisterDeal.markAllAsTouched();
    const invalidField: HTMLElement = document.querySelector('.form-control.ng-invalid') as HTMLElement;
    invalidField?.focus();
  }

  getPayload(value: any): any {
    return Object.keys(value)
      .map(key => value[key])
      .reduce((c, key) => _.merge(c, key), {})
  }
  reset() {
    this.frmRegisterDeal.reset()
  }

  resetDefault() {
    this.isLoading = true
    this.editFormDataSub$ = this.opportunity.getUpdateForm(this.dealId).subscribe({
      next: (resp: any[]) => {
        this.jsonFormGroups = resp;
        console.log(this.jsonFormGroups)
        this.isLoading = false
      },
      error: (error) => {
        this.alertUtil.showAlert('error', error)
        this.isLoading = false
      }
    });
  }
  ngOnDestroy() {
    this.formDataSub$?.unsubscribe();
    this.registerDealSub$?.unsubscribe();
    this.editFormDataSub$?.unsubscribe();
    this.editDealSub$?.unsubscribe()
  }
}
