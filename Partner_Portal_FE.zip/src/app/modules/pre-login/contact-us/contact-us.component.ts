import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { NameValidator } from "../../validation/validators/name-validator";
import { EmailValidator } from "../../validation/validators/email-validator";
import { MobileNumberValidator } from "../../validation/validators/mobile-number-validator";
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../../shared/api.service';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent implements OnInit {
  SubmissionSubscription$!: Subscription;
  constructor(private fb: FormBuilder, private eventBusService: EventBusService, private apiService: ApiService,private cdr:ChangeDetectorRef,private alertUtil:AlertUtility) { }
  contactUsForm!: FormGroup;
  isLoading: boolean = false;
  ngOnInit(): void {
    this.createForm();
    this.contactUsForm.valueChanges.subscribe(() => {
      this.cdr.detectChanges();
    });
  }
 
  createForm() {
    this.contactUsForm = this.fb.group({
      name: ["", [Validators.required, NameValidator.isValid()]],
      email: ["", [Validators.required, EmailValidator.isValid()]],
      companyName: ["", [Validators.required]],
      message: ["",[Validators.required]]
    });
  }
  public submitRequest() {
    const partnerDetails: any = {
      name: this.contactUsForm.controls["name"].value,
      email: this.contactUsForm.controls["email"].value,
      companyName: this.contactUsForm.controls["companyName"].value,
      message: this.contactUsForm.controls["message"].value,
    };
    this.postPartnerDetails(partnerDetails);
  }

  public postPartnerDetails(eventDetails: any) {
    this.isLoading = true;
    this.SubmissionSubscription$ = this.apiService
      .submitContactRequest(eventDetails)
      .subscribe(
        (resp: any) => {
          this.contactUsForm.reset();
          this.alertUtil.showAlert("success", resp.response.message);
          this.isLoading = false;
          
        },
        (error: any) => {
          this.isLoading = false;
        }
      );
  }
  ngOnDestory() {
    this.SubmissionSubscription$?.unsubscribe();
  }
}
