import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpToDateEventsComponent } from './up-to-date-events.component';

describe('UpToDateEventsComponent', () => {
  let component: UpToDateEventsComponent;
  let fixture: ComponentFixture<UpToDateEventsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpToDateEventsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpToDateEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
