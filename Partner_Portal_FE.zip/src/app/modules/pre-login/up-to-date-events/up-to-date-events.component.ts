import { Component, OnInit } from '@angular/core';
import { PreLoginService } from '../pre-login.service';
import { ApiService } from '../../shared/api.service';
import { AlertUtility } from '../../utils/alert.util';
import { ngDebounce } from '../../shared/debounce.decorator';
import { environment } from 'src/environments/environment';
import { AuthenticationService } from '../../authentication/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-up-to-date-events',
  templateUrl: './up-to-date-events.component.html',
  styleUrls: ['./up-to-date-events.component.scss']
})
export class UpToDateEventsComponent implements OnInit {
  eventSub$: any;
  isLoading: boolean = false;
  events: any[] = [];
  selectedWeekday: string = "";
  selectedEventType: string = "";
  tabs: { name: string, value: string }[] = [];
  totalEvents: any = null;

  pageIndex: number = 1;
  pageSize: number = 6;
  eventType!: string;

  // showNextPage: any;

  constructor(
    private preLogin: PreLoginService,
    private apiService: ApiService,
    private alertUtil: AlertUtility,
  private router:Router,
private authService:AuthenticationService) { }

  // @HostListener('scroll', ['$event'])
  @ngDebounce(500)
  // @HostListener('window:scroll', ['$event'])
  onScroll(event: any) {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
    const documentHeight = Math.max(
      document.body.scrollHeight,
      document.documentElement.scrollHeight,
      document.body.offsetHeight,
      document.documentElement.offsetHeight,
      document.body.clientHeight,
      document.documentElement.clientHeight
    );

    const footer: any = document.querySelector('.doc-footer')
    const footerHeight = footer?.clientHeight || 0
    if (scrollTop + window.innerHeight >= (documentHeight - footerHeight)) {
      this.loadEvents(this.eventType)
      // console.log('Scrollbar has reached the bottom of the page');
    }

    // if (Math.ceil(scrollTop + clientHeight) + 2 >= scrollHeight) {
    //   const event = new CustomEvent(Events.TablePagerMessage, {
    //     detail: {
    //       tableId: this.config.tableId,
    //       displayed: this.config.recordsDisplayed.length,
    //       total: this.config.pagination.totalRecords || this.allRecords.length
    //     }
    //   })
    //   // console.log("Pager message", event)
    //   dispatchEvent(event)
    // }
  }
  ngOnInit(): void {
    // window.addEventListener('scroll', this.onScroll.call(this.showNextPage));
    this.loadTabs()
  }


  // showNextPage() {
  //   if (this.totalEvents > this.events.length) return;
  //   this.pageIndex++;
  //   this.loadEvents(this.eventType, this.pageIndex, this.pageSize);
  // }

  loadTabs() {
    this.isLoading = true;
    this.eventSub$ = this.apiService.getMenu('stay_informed').subscribe({
      next: (resp: any) => {
        const data = resp || [];
        // console.log(data,'stayInformed')
        this.tabs = data.map((tab: { title: any; url: any; }) => ({ name: tab.title, value: tab.url }))
        // if (this.tabs.length)
        //   this.loadEvents(this.tabs[0].value);
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  private loadEvents(type: string) {
    if ((this.totalEvents && this.totalEvents) > this.events.length) return;
    this.pageIndex++;

    this.isLoading = true;
    this.eventSub$ = this.preLogin.getEvents(type, this.pageIndex, this.pageSize).subscribe({
      next: (resp: any) => {
        const data: any[] = resp?.data || []
        this.events = this.processData(data)
        // this.totalEvents = resp.totalCount
        // data.forEach(event => {
        //   event.image = `${environment.endpoints.drupal}${event.image}`
        // })
        // this.events = [...this.events, ...data];
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
  processData(resp: any): any {
    resp.map((item: any) => {
      item.callback = () => this.onEventClick(item.nid)
      item.image = this.apiService.getImageUrl(item.image).replaceAll("//", "/").replace("/", "//");
    });
    return resp
  }

  selectedIndex: number = 0
  onTabChange(event: any) {
    this.events = [];
    this.selectedIndex = event.index;
    const selectedTab: { name: string; value: string; } | undefined = this.tabs.find(
      ((item: any) => item?.name === event?.tab?.textLabel)
    )
    this.eventType = selectedTab?.value || "all-events"
    this.pageIndex = 0
    this.totalEvents = null
    this.loadEvents(this.eventType)
  }

  onEventClick(nid:any) {
    this.router.navigate(
      [`case-studies-detail`],
      { queryParams: { realm: this.authService.getRealm() ,nid:nid} }
    );
  }
  ngOnDestroy() {
    this.eventSub$?.unsubscribe();

  }
}
