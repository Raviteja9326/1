import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from './landing/landing.component';
import { PartnerEcosystemComponent } from './partner-ecosystem/partner-ecosystem.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { EventsComponent } from './events/events.component';
import { ProductUpdatesComponent } from './product-updates/product-updates.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { CaseStudiesDetailComponent } from './case-studies-detail/case-studies-detail.component';
import { ResourcesComponent } from './resources/resources.component';

const routes: Routes = [
  {
    path: "",
    component: LandingComponent,
  },
  {
    path: "partner-ecosystem",
    component: PartnerEcosystemComponent,
  },
  {
    path: "product-updates",
    component: ProductUpdatesComponent,
  },
  {
    path: "events",
    component: EventsComponent,
  },
  {
    path: "resources",
    component: ResourcesComponent,
  },
  {
    path: "contact-us",
    component: ContactUsComponent,
  },
  {
    path: "event-detail",
    component: EventDetailsComponent
  },
  {path:"case-studies-detail",
    component:CaseStudiesDetailComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PreLoginRoutingModule { }
