import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs';
import { ApiService } from '../../shared/api.service';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';
import { PreLoginService } from '../pre-login.service';
import { Events } from 'src/app/models/app.enums';
import { Popups } from '../../shared/popup/popup-mapper';
import { EventBusService } from '../../shared/event-bus.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LandingComponent implements OnInit {
  whyPartnerTabData!: any
  eventData: any;
  stayInformedData: any;
  joinConciertoData: any;
  gettingStartedData: any;

  constructor(private preLoginService: PreLoginService, private alertUtil: AlertUtility, private util: CommonUtilService, private router: Router, private auth: AuthenticationService, private eventBusService: EventBusService, private authService: AuthenticationService, private apiService: ApiService, private sanitizer:DomSanitizer) { }
  isLoading: boolean = false
  loadDataSub$!: Subscription
  bannerData!: any;
  whyPartnerData!: any;
  ngOnInit(): void {
    // if (this.util.getClientId())
    //   this.router.navigate(["/home"], {
    //     queryParams: { realm: this.auth.getRealm() }
    //   });
    // else
    // if(this.util.getClientId()){
    //   this.login();
    // }
    this.loadData();
  }
  loadData() {
    this.isLoading = true
    this.loadDataSub$ = this.preLoginService.getLandingPageData().subscribe({
      next: (resp: any) => {
        this.bannerData = resp.data.banner
        this.bannerData.title = this.sanitizer.bypassSecurityTrustHtml(this.bannerData.title);
        this.bannerData.imageUrl = this.apiService.getImageUrl(this.bannerData.imageUrl).replaceAll("//", "/").replace("/", "//")
        this.whyPartnerData = resp.data.section.whyPartner
        this.eventData = resp.data.section.events
        this.stayInformedData = resp.data.section.stayInformed
        this.whyPartnerTabData = this.whyPartnerData.menu[0]
        this.joinConciertoData = resp.data.section.joinTheConcierto
        this.gettingStartedData = resp.data.section["Getting Started"]
        this.isLoading = false
        // console.log(resp.data)
      },
      error: (error: any) => {
        this.alertUtil.notifyToast(error.message, "error")
        this.isLoading = false
      }
    })
  }
  onTabChange(event: any) {
    const selectedTab: { name: string; value: string; } | undefined = this.whyPartnerData.menu.find(
      ((item: any) => item?.name === event?.tab?.textLabel)
    )
    this.preLoginService.getLandingPageSectionData(selectedTab?.value).subscribe({
      next: (resp: any) => {
        this.whyPartnerTabData = resp.data
        this.whyPartnerData.homePageDesciption = this.whyPartnerData.homePageDesciption
        // console.log('data tab',this.whyPartnerData)
      }
    })
  }
  login() {
    this.router.navigate(['/home']);
  }
  onEventClick(routeUrl: any, optionalParameter?: any) {

    if (optionalParameter) console.log(optionalParameter)
    this.router.navigate(
      [routeUrl],
      { queryParams: { realm: this.authService.getRealm(), optionalParameter: optionalParameter } }
    );
  }
  getPartnerPortalAccess() {
    this.eventBusService.emit({
      name: Events.ShowModalPopup,
      value: {
        modalId: Popups.RegisterPartner,
        alignment: 'center',
        title: "PARTNER PORTAL ACCESS APPLICATON",
        subTitle: "Help us get to know you and your business"
      }
    })
    // this.showPartnerPortalAccessModal = true;
  }
  getImage(img: any) {
    return this.apiService.getImageUrl(img)
  }

}
