import { Component, OnInit } from '@angular/core';
import { PreLoginService } from '../pre-login.service';
import { AlertUtility } from '../../utils/alert.util';
import { environment } from 'src/environments/environment';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventsComponent implements OnInit {
  selectedWeekday: string = "";
  selectedEventType: string = "";

  constructor(private preLogin: PreLoginService, private alertUtil: AlertUtility,private util:CommonUtilService) { }

  ngOnInit(): void {
    this.util.gotoTop();
  }

  onWeekdayChange(event: any) {

  }
  onEventTypesChange(event: any) {

  }
  ngOnDestroy() {

  }
}
