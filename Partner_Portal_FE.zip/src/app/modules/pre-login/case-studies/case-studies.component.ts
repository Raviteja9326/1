import { Component, HostListener, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { PreLoginService } from '../pre-login.service';
import { AlertUtility } from '../../utils/alert.util';
import { ApiService } from '../../shared/api.service';
import { ngDebounce } from '../../shared/debounce.decorator';
import { AuthenticationService } from '../../authentication/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-case-studies',
  templateUrl: './case-studies.component.html',
  styleUrls: ['./case-studies.component.scss']
})
export class CaseStudiesComponent implements OnInit {
  caseSub$: any;
  isLoading: boolean = false;
  cases: any[] = [];
  selectedWeekday: string = "";
  selectedEventType: string = "";
  tabs: { name: string, value: string }[] = [];
  totalCases: any = null;

  pageIndex: number = 1;
  pageSize: number = 6;
  caseType!: string;

  // showNextPage: any;

  constructor(
    private preLogin: PreLoginService,
    private apiServices: ApiService,
    private alertUtil: AlertUtility, private router: Router, private authService: AuthenticationService) { }

  // @HostListener('scroll', ['$event'])
  @ngDebounce(500)
  // @HostListener('window:scroll', ['$event'])
  onScroll(event: any) {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
    const documentHeight = Math.max(
      document.body.scrollHeight,
      document.documentElement.scrollHeight,
      document.body.offsetHeight,
      document.documentElement.offsetHeight,
      document.body.clientHeight,
      document.documentElement.clientHeight
    );

    const footer: any = document.querySelector('.doc-footer')
    const footerHeight = footer?.clientHeight || 0
    if (scrollTop + window.innerHeight >= (documentHeight - footerHeight)) {
      this.loadCases(this.caseType)
      // console.log('Scrollbar has reached the bottom of the page');
    }

    // if (Math.ceil(scrollTop + clientHeight) + 2 >= scrollHeight) {
    //   const event = new CustomEvent(Cases.TablePagerMessage, {
    //     detail: {
    //       tableId: this.config.tableId,
    //       displayed: this.config.recordsDisplayed.length,
    //       total: this.config.pagination.totalRecords || this.allRecords.length
    //     }
    //   })
    //   // console.log("Pager message", event)
    //   dispatchEvent(event)
    // }
  }
  ngOnInit(): void {
    // window.addEventListener('scroll', this.onScroll.call(this.showNextPage));
    this.loadTabs()
  }


  // showNextPage() {
  //   if (this.totalCases > this.cases.length) return;
  //   this.pageIndex++;
  //   this.loadCases(this.eventType, this.pageIndex, this.pageSize);
  // }

  loadTabs() {
    this.isLoading = true;
    this.caseSub$ = this.apiServices.getMenu('case_study').subscribe({
      next: (resp: any) => {
        const data = resp || [];
        this.tabs = data.map((tab: { title: any; url: any; }) => ({ name: tab.title, value: tab.url }))
        // if (this.tabs.length)
        //   this.loadCases(this.tabs[0].value);
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  private loadCases(caseType: string) {
    if ((this.totalCases && this.totalCases) > this.cases.length) return;
    this.pageIndex++;

    this.isLoading = true;
    this.caseSub$ = this.preLogin.getCases(caseType, this.pageIndex, this.pageSize).subscribe({
      next: (resp: any) => {
        const data: any[] = resp?.data || []
        this.totalCases = resp.totalCount
        data.forEach(caseStudy => {
          caseStudy.callback = () => this.onEventClick(caseStudy.nid)
          caseStudy.image = this.apiServices.getImageUrl(caseStudy.image) //`${environment.endpoints.drupal}${caseStudy.image}`
        })
        this.cases = [...this.cases, ...data];
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  selectedIndex: number = 0
  onTabChange(event: any) {
    this.cases = [];
    this.selectedIndex = event.index;
    const selectedTab: { name: string; value: string; } | undefined = this.tabs.find(
      ((item: any) => item?.name === event?.tab?.textLabel)
    )
    this.caseType = selectedTab?.value || "all-cases"
    this.pageIndex = 0
    this.totalCases = null
    this.loadCases(this.caseType)
  }

  onEventClick(nid: any) {
    this.router.navigate(
      [`case-studies-detail`],
      { queryParams: { realm: this.authService.getRealm(), nid: nid } }
    );
  }

  ngOnDestroy() {
    this.caseSub$?.unsubscribe();

  }
}
