import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { AuthenticationService } from '../../authentication/authentication.service';
import { ApiService } from '../../shared/api.service';
import { ngDebounce } from '../../shared/debounce.decorator';
import { AlertUtility } from '../../utils/alert.util';
import { PreLoginService } from '../pre-login.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-product-insights',
  templateUrl: './product-insights.component.html',
  styleUrls: ['./product-insights.component.scss']
})
export class ProductInsightsComponent implements OnInit {
  data: any;
  isLoading: boolean = false;

  dataSub$!: Subscription
  // showNextPage: any;

  constructor(
    private preLogin: PreLoginService,
    private apiService: ApiService,
    private alertUtil: AlertUtility, private router: Router, private authService: AuthenticationService) { }

  // @HostListener('scroll', ['$event'])
  @ngDebounce(500)
  ngOnInit(): void {
    // window.addEventListener('scroll', this.onScroll.call(this.showNextPage));
    this.loadData()
  }
  loadData() {
    this.isLoading = true;
    this.dataSub$ = this.apiService.getProductInsightsData().subscribe({
      next: (resp: any) => {
        console.log(resp)
        this.data = this.processData( resp.data)
        this.isLoading = false;
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });

  }
  processData(resp: any): any {
    resp.map((item: any) => {
      item.image = this.apiService.getImageUrl(item.image).replaceAll("//", "/").replace("/", "//");
    });
    return resp
  }
 
  onProductClick(url:any){
    window.open(url,'_blank')
  }
  ngOnDestroy() {
    this.dataSub$?.unsubscribe();

  }

}
