import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-updates',
  templateUrl: './product-updates.component.html',
  styleUrls: ['./product-updates.component.scss']
})
export class ProductUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
