import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PreLoginService {
  getCases(type: string, pageIndex: number, pageSize: number) {
    // const url = `${environment.endpoints.drupal}api/csCaseStudy?category=${type}&page=${pageIndex}&limit=${pageSize}`;
    const url = `assets/data/case-studies.json`;
    return this.http.get(url).pipe(map((response: any) => response));
  }
  getEvents(type: string = "all", pageIndex: number = 1, pageSize: number = 6) {
    let url: string = "";
    if (type === "case-studies-showcase")
      url = 'assets/data/case-studies-showcase.json'
    else if (type === "product-evaluation-centre")
      url = 'assets/data/product-evaluation-centre.json'
    else if (type === "concierto-updates-hub")
      url = 'assets/data/concierto-updates-hub.json'
    else if (type === "future-innovation-preview")
      url = 'assets/data/future-innovation-preview.json'
    else
      url = `assets/data/events.json`;
      // url = `${environment.endpoints.drupal}api/csDashboardData?content=${type}&page=${pageIndex}&limit=${pageSize}`;
    return this.http.get(url).pipe(map((response: any) => response));
  }
  getLandingPageData() {
    // const url = `${environment.endpoints.drupal}api/csDashboard`;
    const url = `assets/data/landing.json`;
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  getLandingPageSectionData(event: any) {
    const url = `${environment.endpoints.drupal}api/csDashboardData?content=${event}`;
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  getPartnerEcosystemData() {
    const url = `${environment.endpoints.drupal}api/csPartnerEcosystem`
    return this.http.get(url).pipe(
      map((response: any) => response));
  }

  constructor(private http: HttpClient) { }
}
