import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { NameValidator } from "../../validation/validators/name-validator";
import { EmailValidator } from "../../validation/validators/email-validator";
import { MobileNumberValidator } from "../../validation/validators/mobile-number-validator";
import { EventBusService } from '../../shared/event-bus.service';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ApiService } from '../../shared/api.service';
import { Subscription } from 'rxjs';
import { AlertUtility } from '../../utils/alert.util';
import { ActivatedRoute } from '@angular/router';
import { CommonUtilService } from '../../utils/common-util.service';
@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.scss']
})
export class EventDetailsComponent implements OnInit {
  eventdate = ["Feb 20: San Franciso , CA", "Feb 21: San Jose , CA", "Feb 22: Portland , OR", "Feb 20: Seattle , CA"]
  SubmissionSubscription$!: Subscription;
  dataSub$!: Subscription
  nid: any;
  constructor(private fb: FormBuilder, private eventBusService: EventBusService, private apiService: ApiService, private cdr: ChangeDetectorRef, private alertUtil: AlertUtility, private route: ActivatedRoute,private util:CommonUtilService) { }
  eventRegisterForm!: FormGroup;
  eventData!: any
  isLoading: boolean = false;
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.nid = params['nid'] || null;
    });
    this.loadData();
    this.createForm();
    this.eventRegisterForm.valueChanges.subscribe(() => {
      this.cdr.detectChanges();
    });
  }
  loadData() {
    this.dataSub$ = this.apiService.getEventDetailsData(this.nid).subscribe({
      next: (resp: any) => {
        this.eventData = resp.data[0]
        this.util.gotoTop();


      },
      error: (error) => {
        this.isLoading = false;
        this.alertUtil.showAlert('error', error)
      },
      complete: () => { }
    })
  }


  createForm() {
    this.eventRegisterForm = this.fb.group({
      name: ["", [Validators.required, NameValidator.isValid()]],
      title: ["", [Validators.required]],
      organizationName: ["", [Validators.required]],
      email: ["", [Validators.required, EmailValidator.isValid()]],
      phone: ["", [Validators.required, MobileNumberValidator.isValid()]],
      date: ["",],
      message: [""]
    });
  }
  public submitRequest() {
    const partnerDetails: any = {
      name: this.eventRegisterForm.controls["name"].value,
      title: this.eventRegisterForm.controls["title"].value,
      organizationName: this.eventRegisterForm.controls["organizationName"].value,
      email: this.eventRegisterForm.controls["email"].value,
      phone: this.eventRegisterForm.controls["phone"].value,
      message: this.eventRegisterForm.controls["message"].value,
      date: this.eventRegisterForm.controls["date"].value,
    };
    this.postPartnerDetails(partnerDetails);
  }

  public postPartnerDetails(eventDetails: any) {
    this.isLoading = true;
    this.SubmissionSubscription$ = this.apiService
      .submitEventRequest(eventDetails)
      .subscribe(
        (resp: any) => {
          this.alertUtil.showAlert("success", resp.response.message);
          this.eventRegisterForm.reset();
          this.isLoading = false;

        },
        (error: any) => {
          this.isLoading = false;
        },
      );
  }
  ngOnDestory() {
    this.SubmissionSubscription$?.unsubscribe();
    this.dataSub$?.unsubscribe()
  }

}
