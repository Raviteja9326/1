import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PreLoginRoutingModule } from './pre-login-routing.module';
import { LandingComponent } from './landing/landing.component';
import { PartnerEcosystemComponent } from './partner-ecosystem/partner-ecosystem.component';
import { ProductUpdatesComponent } from './product-updates/product-updates.component';
import { EventsComponent } from './events/events.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { MaterialModule } from '../shared/material/material.module';
import { SharedModule } from '../shared/shared.module';
import { DirectivesModule } from '../directives/directives.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EventListComponent } from './event-list/event-list.component';
import { CaseStudiesComponent } from './case-studies/case-studies.component';
import { UpToDateEventsComponent } from './up-to-date-events/up-to-date-events.component';
import { ProductUpdatesModule } from '../product-updates/product-updates.module';
import { EventDetailsComponent } from './event-details/event-details.component';
import { CaseStudiesDetailComponent } from './case-studies-detail/case-studies-detail.component';
import { SuccessMessageComponent } from './success-message/success-message.component';
import { ResourcesComponent } from './resources/resources.component';
import { ProductInsightsComponent } from './product-insights/product-insights.component';
import { GettingStartedSectionComponent } from './getting-started-section/getting-started-section.component';
import { JoinConciertoSectionComponent } from './join-concierto-section/join-concierto-section.component';


@NgModule({
  declarations: [
    LandingComponent,
    PartnerEcosystemComponent,
    ProductUpdatesComponent,
    EventsComponent,
    ContactUsComponent,
    EventListComponent,
    CaseStudiesComponent,
    UpToDateEventsComponent,
    EventDetailsComponent,
    CaseStudiesDetailComponent,
    SuccessMessageComponent,
    ResourcesComponent,
    ProductInsightsComponent,
    GettingStartedSectionComponent,
    JoinConciertoSectionComponent
  ],
  imports: [
    PreLoginRoutingModule,
    MaterialModule,
    SharedModule,
    DirectivesModule,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    ProductUpdatesModule
  ]
})
export class PreLoginModule { }
