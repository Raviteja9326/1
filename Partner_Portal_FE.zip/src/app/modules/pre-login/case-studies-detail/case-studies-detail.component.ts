import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../shared/api.service';
import { Subscription } from 'rxjs';
import { AlertUtility } from '../../utils/alert.util';
import { ActivatedRoute } from '@angular/router';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-case-studies-detail',
  templateUrl: './case-studies-detail.component.html',
  styleUrls: ['./case-studies-detail.component.scss']
})
export class CaseStudiesDetailComponent implements OnInit {

  constructor(private apiService:ApiService,private alertUtil:AlertUtility,private route:ActivatedRoute,private util:CommonUtilService) { }
   dataSub$!:Subscription
   description!:any[];
   nid:any;
   caseStudyData:any;
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.nid = params['nid'] || null;
      
    });
    this.dataSub$=this.apiService.getCaseStudiesDetail(this.nid).subscribe({
      next: (resp: any) => {
      this.caseStudyData=resp.data[0]
      this.description=resp.data[0].description
      this.util.gotoTop();
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error)
        
      }
    })
  }
  getImage(img:any){
    return this.apiService.getImageUrl(img)
  }
  ngOnDestroy(){
    this.dataSub$?.unsubscribe();
  }

}
