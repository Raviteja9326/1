import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseStudiesDetailComponent } from './case-studies-detail.component';

describe('CaseStudiesDetailComponent', () => {
  let component: CaseStudiesDetailComponent;
  let fixture: ComponentFixture<CaseStudiesDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseStudiesDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseStudiesDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
