import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.scss']
})
export class ResourcesComponent implements OnInit {

  constructor(private router:Router,private authService:AuthenticationService,private util:CommonUtilService) { }
  onEventClick(routeUrl:any) {
   
    
    this.router.navigate(
      [routeUrl],
      { queryParams: { realm: this.authService.getRealm() } }
    );
  }
  ngOnInit(): void {
    this.util.gotoTop();
  }

}
