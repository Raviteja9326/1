import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JoinConciertoSectionComponent } from './join-concierto-section.component';

describe('JoinConciertoSectionComponent', () => {
  let component: JoinConciertoSectionComponent;
  let fixture: ComponentFixture<JoinConciertoSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JoinConciertoSectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JoinConciertoSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
