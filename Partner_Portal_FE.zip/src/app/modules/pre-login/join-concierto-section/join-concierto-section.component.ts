import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-concierto-section',
  templateUrl: './join-concierto-section.component.html',
  styleUrls: ['./join-concierto-section.component.scss']
})
export class JoinConciertoSectionComponent implements OnInit {
  @Input() joinConciertoData:any;
  constructor() { }

  ngOnInit(): void {
  }

}
