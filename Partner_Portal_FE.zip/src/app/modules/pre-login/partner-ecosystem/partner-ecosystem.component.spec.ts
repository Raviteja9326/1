import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerEcosystemComponent } from './partner-ecosystem.component';

describe('PartnerEcosystemComponent', () => {
  let component: PartnerEcosystemComponent;
  let fixture: ComponentFixture<PartnerEcosystemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PartnerEcosystemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerEcosystemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
