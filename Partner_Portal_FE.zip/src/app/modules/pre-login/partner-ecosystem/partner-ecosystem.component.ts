import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { PreLoginService } from '../pre-login.service';
import { ApiService } from '../../shared/api.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-partner-ecosystem',
  templateUrl: './partner-ecosystem.component.html',
  styleUrls: ['./partner-ecosystem.component.scss']
})
export class PartnerEcosystemComponent implements OnInit {
  title: string | null = null;
  constructor(private preLoginService:PreLoginService,private apiService:ApiService,private route:ActivatedRoute) { }
  dataSub$!:Subscription
  targetSection=0;
  istargetSection:boolean=false;
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.title = params['optionalParameter'] || null;
      
    });
    this.loadData();
  }
  loadData(){
    this.dataSub$=this.apiService.getMenu('partner-program').subscribe({
      next:(resp:any)=>{
       
       const targetSectionIndex = resp.findIndex((item: any) => item.name === this.title);

       if (targetSectionIndex !== -1) {
         this.targetSection = targetSectionIndex;
        this.istargetSection=true}

      }
    })
  }

}
