import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-getting-started-section',
  templateUrl: './getting-started-section.component.html',
  styleUrls: ['./getting-started-section.component.scss']
})
export class GettingStartedSectionComponent implements OnInit {
  @Input() gettingStartedData:any;
  constructor() { }

  ngOnInit(): void {
  }

}
