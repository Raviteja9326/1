import { Component, Input, OnInit } from '@angular/core';
import { Award } from '../models/award.model';

@Component({
  selector: 'app-partner-award',
  templateUrl: './partner-award.component.html',
  styleUrls: ['./partner-award.component.scss']
})
export class PartnerAwardComponent implements OnInit {
  @Input() award: Award | undefined
  constructor() { }

  ngOnInit(): void {
  }

}
