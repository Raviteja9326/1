import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PartnerAwardComponent } from './partner-award/partner-award.component';
import { AwardProgressComponent } from './award-progress/award-progress.component';
import { AwardComponent } from './award/award.component';
import { PartnerAwardsComponent } from './partner-awards.component';
import { AwardListComponent } from './award-list/award-list.component';
import { MaterialModule } from '../shared/material/material.module';
import { ProgressStatusComponent } from './progress-status/progress-status.component';
import { DirectivesModule } from '../directives/directives.module';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path: '', component: PartnerAwardsComponent
},]

@NgModule({
  declarations: [
    PartnerAwardsComponent,
    PartnerAwardComponent,
    AwardProgressComponent,
    AwardComponent,
    AwardListComponent,
    ProgressStatusComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    DirectivesModule,
    RouterModule.forChild(routes),
  ]
})
export class PartnerAwardsModule { }
