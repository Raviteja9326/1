export interface Award {
  name: string;
  qualifications: string[],
  benefits: string[],
  completed?:boolean,
  suggestion:string
}
