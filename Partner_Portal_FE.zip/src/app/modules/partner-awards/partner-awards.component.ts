import { Component, OnInit } from '@angular/core';
import { AwardService } from './award.service';
import { Subscription } from 'rxjs';
import { Award } from './models/award.model';
import { EventBusService } from '../shared/event-bus.service';
import { Events } from 'src/app/models/app.enums';
import { AlertUtility } from '../utils/alert.util';

@Component({
  selector: 'app-partner-awards',
  templateUrl: './partner-awards.component.html',
  styleUrls: ['./partner-awards.component.scss']
})
export class PartnerAwardsComponent implements OnInit {
  awardName: string = "";
  awardSubs$!: Subscription;
  awardList!: Award[];
  award: Award | undefined;
  certificatesCount: number = 0;
  isLoading: boolean = false;
  clientChangeSub$!: Subscription;

  constructor(
    private eventBusService: EventBusService,
    private awardService: AwardService,
    private alertUtil: AlertUtility) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.loadAwards()
    })

  }

  ngOnInit(): void {
    this.loadAwards()
  }
  loadAwards() {
    this.isLoading = true;
    this.awardSubs$ = this.awardService.getAwardList().subscribe((resp: any) => {
      this.awardList = resp
      this.certificatesCount = this.awardService.getCertificateCount()
      this.awardName = this.awardService.getAwardName(this.certificatesCount)
      this.award = this.awardList?.find((award: Award) => award.name === this.awardName);
      this.awardService.setStatus(this.awardList, this.certificatesCount)
      this.awardList = this.awardList.slice(1);
      this.isLoading = false;
    },(error)=>{
      this.alertUtil.notifyToast(error.message, "error")
      this.isLoading = false
    })
  }
  ngOnDestroy() {
    this.awardSubs$?.unsubscribe()
    this.clientChangeSub$?.unsubscribe()
  }
}
