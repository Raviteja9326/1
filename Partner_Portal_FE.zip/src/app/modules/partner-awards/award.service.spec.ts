import { TestBed } from '@angular/core/testing';

import { AwardService } from './award.service';
import { HttpClientModule } from '@angular/common/http';

describe('AwardService', () => {
  let service: AwardService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientModule
      ]
    });
    service = TestBed.inject(AwardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
