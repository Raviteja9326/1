import { Component, Input, OnInit } from '@angular/core';
import { AwardService } from '../award.service';
import { Award } from '../models/award.model';

@Component({
  selector: 'app-progress-status',
  templateUrl: './progress-status.component.html',
  styleUrls: ['./progress-status.component.scss']
})
export class ProgressStatusComponent implements OnInit {
  @Input() awards!: Award[];
  @Input() certificatesCount!: number;
  progress!: { width: string; };
  constructor(private awardService:AwardService) { }

  ngOnInit(): void {
    this.progress = { width: `${this.awardService.getProgressValue(this.certificatesCount)}%` }
  }

}
