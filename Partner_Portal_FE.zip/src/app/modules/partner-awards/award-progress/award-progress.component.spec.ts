import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AwardProgressComponent } from './award-progress.component';
import { HttpClientModule } from '@angular/common/http';

describe('AwardProgressComponent', () => {
  let component: AwardProgressComponent;
  let fixture: ComponentFixture<AwardProgressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AwardProgressComponent ],
      imports:[
        HttpClientModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AwardProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
