import { Component, Input, OnInit } from '@angular/core';
import { AwardService } from '../award.service';
import { Award } from '../models/award.model';

@Component({
  selector: 'app-award-progress',
  templateUrl: './award-progress.component.html',
  styleUrls: ['./award-progress.component.scss']
})
export class AwardProgressComponent implements OnInit {
  @Input() awards: Award[] = []
  @Input() certificatesCount!: number;
  suggestion: string = "";
  constructor(private awardService: AwardService) { }
  ngOnInit(): void {
    const currentAward = this.awardService.getAwardName(this.certificatesCount)
    const award: Award | undefined = this.awards?.find(award => award.name === currentAward)
    this.suggestion = award?.suggestion || ""
  }
}
