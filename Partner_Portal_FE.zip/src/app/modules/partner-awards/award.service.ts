import { Injectable } from '@angular/core';
import { ApiService } from '../shared/api.service';
import { Award } from './models/award.model';

@Injectable({
  providedIn: 'root'
})
export class AwardService {
  getCertificateCount() {
    return 65;
  }
  setStatus(awards: Award[], certificationCompleted: number) {
    awards.forEach((award: Award) => {
      if (certificationCompleted >= this.getNumber(award.qualifications[1]))
        award.completed = true
      else
        award.completed = false
    })
  }
  getNumber(text: string): number {
    const r = /\d+/;
    return parseInt(text.match(r)?.toString() || "0");
  }
  getProgressValue(certificationCompleted: number) {
    const minValue = 25
    if (certificationCompleted <= minValue)
      return 0
    else {
      const extra = certificationCompleted - minValue
      return extra / (100 - minValue) * 100
    }
  }
  getAwardList() {
    return this.apiService.getAwardList()
  }
  getAwardName(certificationCompleted: any): any {
    if (certificationCompleted < 25)
      return "beginner"
    else if (certificationCompleted < 50)
      return "bronze"
    else if (certificationCompleted < 75)
      return "silver"
    else if (certificationCompleted < 100)
      return "gold"
    else return "diamond"
  }


  constructor(private apiService: ApiService) { }
}
