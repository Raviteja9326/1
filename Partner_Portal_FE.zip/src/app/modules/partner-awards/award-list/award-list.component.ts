import { Component, Input, OnInit } from '@angular/core';
import { Award } from '../models/award.model';

@Component({
  selector: 'app-award-list',
  templateUrl: './award-list.component.html',
  styleUrls: ['./award-list.component.scss']
})
export class AwardListComponent implements OnInit {
  @Input() awardList!: Award[]
  constructor() { }

  ngOnInit(): void {
  }

}
