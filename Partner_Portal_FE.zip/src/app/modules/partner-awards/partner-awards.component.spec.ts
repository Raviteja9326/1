import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerAwardsComponent } from './partner-awards.component';
import { HttpClientModule } from '@angular/common/http';

describe('PartnerAwardsComponent', () => {
  let component: PartnerAwardsComponent;
  let fixture: ComponentFixture<PartnerAwardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PartnerAwardsComponent ],
      imports:[
        HttpClientModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerAwardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
