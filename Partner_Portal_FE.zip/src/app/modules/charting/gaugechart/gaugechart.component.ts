import { Component, Input, OnInit } from '@angular/core';
import zingchart from 'zingchart/es6';
@Component({
  selector: 'app-gaugechart',
  templateUrl: './gaugechart.component.html',
  styleUrls: ['./gaugechart.component.scss']
})
export class GaugechartComponent implements OnInit {
  @Input() chartData!: { id: string; consumption: number; data: [];rules:[] };
  // @Input() salesChartData!: { id: string; consumption: number; data: [];rules:[] };
  chartId!: string;
  constructor() {
  }

  ngOnInit(): void {
    this.drawChart(this.chartData)
    // if(this.salesChartData?.id === 'salesChart')
    // this.drawChart(this.salesChartData)
  }
  drawChart(chartData: any) {
    var maxLength = 0;
    chartData.data.forEach((element: any) => {
      if (maxLength < element.value)
        maxLength = element.value;
    });
    var chartConfig = {
      "type": "gauge",
      "scale-r": {
        "aperture": 275,
        "minValue": 0,
        "maxValue": maxLength,
        "center": {
          'background-color': 'orange',
          'border-color': "none",
          'size': 15,
        },
        'tick': {
          'visible': false
        },
        "item": {
          'offset-r': -2,
        },
        "ring": {
          "size": 12,
          "rules": chartData.rules
        }
      },
      "series": [
        {
          "values": [chartData.currentValue],
          'background-color': "#808080",
          "animation": {
            'effect': 'ANIMATION_EXPAND_VERTICAL',
            'method': 'ANIMATION_REGULAR_EASE_OUT',
            'speed': 2500
          }
        }
      ],
      plot: {
        size: '100%',
        valueBox: {
          text: '%v',
          x: 108,
          y: 150,
          fontSize: 18,
        }
      },
    };
    zingchart.render({
      id: chartData.id,
      data: chartConfig,
      width: '240px',
      height: '220px',
    });
  }
}


