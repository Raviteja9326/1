import { Component, ElementRef, Input, OnInit, SimpleChanges, ViewEncapsulation } from '@angular/core';
import * as d3 from "d3";


@Component({
  selector: 'app-multi-line-forecasting-chart',
  encapsulation: ViewEncapsulation.None, //helps to use the css class for SVG
  templateUrl: './multi-line-forecasting-chart.component.html',
  styleUrls: ['./multi-line-forecasting-chart.component.scss']
})
export class MultiLineForecastingChartComponent implements OnInit {
  private width = 400;
  private height = 300;
  private margin = 30;
  private marginLeft = this.margin + 10
  public svgInner: any;
  public yScale: any;
  public xScale: any;
  public lineGroup: any;

  @Input() forecastData!: { title: string, xAxisTitle: string, yAxisTitle: string, dataset: { config: any, actualData: any[], forecastData: any[] }[] }
  public constructor(public chartElem: ElementRef) { }

  ngOnInit(): void { }

  private refreshChart() {
    this.syncChartData(this.forecastData.dataset);
    this.initializeChart();
    this.forecastData.dataset.forEach((data, i) => {
      this.defineScale(this.svgInner, data.actualData);
      this.drawChart(data.actualData, this.xScale, this.yScale, "actual" + i, data.config);
    });
    this.forecastData.dataset.forEach((data, i) => {
      this.defineScale(this.svgInner, data.forecastData);
      this.drawChart(data.forecastData, this.xScale, this.yScale, "forecast" + i, data.config);
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    this.forecastData = changes.forecastData.currentValue
    if (this.forecastData?.dataset)
    this.refreshChart()
  }

  syncChartData(dataset: { config: any; actualData: any[]; forecastData: any[]; }[]) {
    dataset.forEach(data => {
      if (data.actualData?.length) {
        const lastActualData = data.actualData[data.actualData?.length - 1]
        data.forecastData.unshift(lastActualData)
      }
    })
  }

  private initializeChart(): void {
    const svg = d3
      .select(this.chartElem.nativeElement)
      .select('.linechart')
      .html("")
      .append('svg')
      .attr('height', this.height - this.margin);
    this.svgInner = svg
      .append('g')
      .style('transform', `translate(${this.margin / 2 + 10}px, 5px)`);
    // .style('transform', 'translate(' + this.margin / 2 + 'px, ' + this.margin + 'px)');
    this.width = this.chartElem.nativeElement.getBoundingClientRect().width;
    svg.attr('width', this.width - 10);

    this.addTitle()
  }
  addTitle() {
    // this.svgInner.append("text")
    //   .attr("class", 'title')
    //   // .attr("x", (this.width / 2))
    //   // .attr("text-align", 'center')
    //   // .attr('text-anchor', 'middle')
    //   .text(this.forecastData.title)
    // debugger
    this.svgInner.append("text")
      .attr("class", "y-label")
      .attr("text-anchor", "end")
      .attr("y", -5)
      .attr("dy", "0")
      .attr("x", -this.height / 2 + 50)
      .attr("transform", "rotate(-90)")
      .text(this.forecastData.yAxisTitle);
  }
  private defineScale(svgInner: any, data: any) {
    this.defineXAxis(svgInner, data);
    this.defineYAxis(svgInner, data);
  }

  private defineXAxis(svgInner: any, data: any) {
    this.xScale = d3.scalePoint()
      .domain(this.getAllXAxisValue())
      .range([this.marginLeft, this.width - 2 * this.margin]);

    const xAxisBar = svgInner
      .append('g')
      .attr('id', 'x-axis')
      .style('transform', `translate(0, ${this.height - 2 * this.margin}px)`);
    // .style('transform', 'translate(0, ' + (this.height - 2 * this.margin) + 'px)');
    const xAxis = d3
      .axisBottom(this.xScale)
      .ticks(10)
    // .tickFormat(d3.timeFormat('%m / %Y'));

    xAxisBar.call(xAxis);
  }

  private defineYAxis(svgInner: any, data: { key: string, value: number }[]) {
    const maxValue = this.getYMax()
    const minValue = this.getYMin()
    const clearance = (maxValue - minValue) / 10
    this.yScale = d3
      .scaleLinear()
      // .domain([maxValue, minValue])
      .domain([maxValue + clearance, minValue - clearance])
      // .domain([(d3.max(data, d => d.value)) as number + 1, (d3.min(data, d => d.value)) as number - 1])
      .range([0, this.height - 2 * this.margin]);

    const yAxisBar = svgInner
      .append('g')
      .attr('id', 'y-axis')
      .style('transform', 'translate(' + this.marginLeft + 'px,  0)');
    const yAxis = d3.axisLeft(this.yScale);
    yAxisBar.call(yAxis);
  }

  private drawChart(data: any, xScale: any, yScale: any, lineId: string, config: any) {
    const line = d3
      .line()
      .x(d => d[0])
      .y(d => d[1])
    // .curve(d3.curveMonotoneX);

    const points: [number, number][] = data.map((d: any) => [
      xScale(d.key),
      yScale(d.value),
    ]);
    this.lineGroup = this.svgInner
      .append('g')
      .append('path')
      .attr('id', 'line' + lineId)
      .style('fill', 'none')
      .style('stroke', config.color)
      .style('stroke-width', `${config.thickness}px`)
      .attr('d', line(points));
    if (lineId.includes("forecast")) {
      this.lineGroup
        .style("stroke-dasharray", (`${config.thickness},${config.thickness * 2}`))  // <== This line here!!
    }
  }

  private getAllXAxisValue(): Iterable<string> {
    let keys: string[] = []
    this.forecastData.dataset.forEach(ds => {
      keys = keys.concat(ds.actualData.map((d: any) => d.key))
    })
    this.forecastData.dataset.forEach(ds => {
      keys = keys.concat(ds.forecastData.map((d: any) => d.key))
    })
    return [...new Set(keys)]
  }
  private getYMin(): number {
    let min: number = Number.MAX_VALUE
    this.forecastData.dataset.forEach(ds => {
      let temp = d3.min([...ds.actualData, ...ds.forecastData], (d: { value: number; }) => d.value)
      temp = temp === undefined ? min : temp
      min = min < temp ? min : temp
    })
    return min
  }
  private getYMax(): number {
    let max: number = 0
    this.forecastData.dataset.forEach(ds => {
      let temp = d3.max([...ds.actualData, ...ds.forecastData], (d: { value: number; }) => d.value)
      temp = temp === undefined ? max : temp
      max = max > temp ? max : temp
    })
    return max
  }
}
