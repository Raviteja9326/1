import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiLineForecastingChartComponent } from './multi-line-forecasting-chart.component';

describe('MultiLineForecastingChartComponent', () => {
  let component: MultiLineForecastingChartComponent;
  let fixture: ComponentFixture<MultiLineForecastingChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiLineForecastingChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiLineForecastingChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
