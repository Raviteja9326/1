import { Component, Input, OnInit, SimpleChanges, ViewEncapsulation } from '@angular/core';
import D3Funnel from 'd3-funnel';

@Component({
  selector: 'app-funnelchart',
  templateUrl: './funnelchart.component.html',
  styleUrls: ['./funnelchart.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FunnelchartComponent implements OnInit {
  @Input() chartData: { label: string, value: number, color:string }[] = [];
//https://codesandbox.io/s/d3-funnel-with-custom-color-scale-forked-j2ejtw?file=/src/index.js:1199-1208
  constructor() {
  }
  ngOnInit(): void {

  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.chartData.length)
      this.drawChart(this.chartData)
  }
  drawChart(data: { label: string, value: number, color:string }[]) {
    const options = {
      block: {
        dynamicHeight: false,
        // minHeight: 15,
      },
      chart: {
        curve: {
          enabled: false
        },
        bottomPinch: 3,
        bottomWidth: 1/2,
        fillType : "gradient",
        hoverEffects : true,
        // height: 300,
        // width: 300
      },
      tooltip: {
        enabled: true,
        format: (l: any, f: any, color: any) => {
          // const percentage = ((f / totalData) * 100).toFixed(1);
          // return `${l}: ${f} (${percentage}%)`;
          return `${f}`;
        }
      },
      label: {
        fill: "#000",
        // format: `{l}\n{f}`,
        format: `{f}`,
      }
    };
    // const options = {
    //   block: {
    //     dynamicHeight: true,
    //     minHeight: 30,
    //     marginLeft: 40
    //   },
    //   chart: {
    //     curve: {
    //       enabled: false
    //     },
    //     bottomPinch: 2,
    //     height: 300,
    //     width: 200
    //   },
    //   tooltip: {
    //     enabled: true,
    //     format: (l:any, f:any, color:any) => {
    //       // const percentage = ((f / totalData) * 100).toFixed(1);
    //       // return `${l}: ${f} (${percentage}%)`;
    //       return `{f}`;
    //     }
    //   },
    //   label: {
    //     fill: "#000",
    //     fontFamily: "Open Sans",
    //     fontSize: 13,
    //     format: `{f}`
    //   }
    // };
    D3Funnel.defaults.block.fill.scale = data.map(d=>d.color);
    D3Funnel.defaults.block.margin = 10;
    const chart = new D3Funnel('#funnel');
    chart.draw(data, options);
  }
}
