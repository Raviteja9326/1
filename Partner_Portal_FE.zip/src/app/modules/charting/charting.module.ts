import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChartingRoutingModule } from './charting-routing.module';
import { FunnelchartComponent } from './funnelchart/funnelchart.component';
import { GaugechartComponent } from './gaugechart/gaugechart.component';
import { DonutchartComponent } from './donutchart/donutchart.component';
import { MultiLineForecastingChartComponent } from './multi-line-forecasting-chart/multi-line-forecasting-chart.component';


@NgModule({
  declarations: [
    FunnelchartComponent,
    GaugechartComponent,
    DonutchartComponent,
    MultiLineForecastingChartComponent
  ],
  imports: [
    CommonModule,
    ChartingRoutingModule
  ],
  exports:[
    FunnelchartComponent,
    GaugechartComponent,
    DonutchartComponent,
    MultiLineForecastingChartComponent
  ]
})
export class ChartingModule { }
