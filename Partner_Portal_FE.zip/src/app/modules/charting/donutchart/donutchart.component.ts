import { Component, Input, OnInit } from '@angular/core';
import * as d3 from 'd3-selection';
import * as d3Scale from 'd3-scale';
import * as d3Shape from 'd3-shape';
@Component({
  selector: 'app-donutchart',
  templateUrl: './donutchart.component.html',
  styleUrls: ['./donutchart.component.scss']
})
export class DonutchartComponent implements OnInit {
  @Input() label: string = '';
  @Input() donutChartData: any = [];
  private width!: number;
  private height!: number;
  private svg: any;
  private radius!: number;
  private arc!: d3Shape.Arc<this, any>;
  private pie!: d3Shape.Pie<any, number | { valueOf(): number }>;
  private color!: d3Scale.ScaleOrdinal<string, unknown, never>;
  private total!: number
  constructor() { }

  ngOnInit() {
    this.initSvg();
    this.total = this.donutChartData.reduce((acc: any, item: any) => {
      return acc + item.value
    }, 0);
    this.drawChart(this.donutChartData);

  }
  private initSvg() {
    this.svg = d3.select('svg#donut');
    this.width = +this.svg.attr('width');
    this.height = +this.svg.attr('height');
    this.radius = Math.min(this.width, this.height) / 2;
    this.color = d3Scale.scaleOrdinal().range(['#FF6600', '#F9B200', '#7D7D7D']);
    this.arc = d3Shape.arc()
      .outerRadius(this.radius)
      .innerRadius(this.radius - this.radius * .25);
    this.pie = d3Shape.pie()
      .sort(null)
      .value((d: any) => d.value);

    this.svg = d3.select('svg#donut')
      .append('g')
      .attr('transform', 'translate(' + this.width / 2 + ',' + this.height / 2 + ')');
  }
  private drawChart(data: any[]) {
    let g = this.svg.selectAll('.arc')
      .data(this.pie(data))
      .enter().append('g')
      .attr('class', 'arc');
    g.append('path')
      .attr('d', this.arc)
      .style('fill', (d: any) => this.color(d.data));
    g.append('svg:text')
      .attr("text-anchor", "middle")
      .append('svg:tspan')
      .text('TOTAL')
      .append('svg:tspan')
      .attr('x', 0)
      .attr('dy', 20)
      .text(this.total)
  }
}
