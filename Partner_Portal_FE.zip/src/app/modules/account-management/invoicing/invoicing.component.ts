import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { ApiService } from '../../shared/api.service';
import { DocumentPreviewComponent } from '../../shared/components/document-preview/document-preview.component';
import { EventBusService } from '../../shared/event-bus.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-invoicing',
  templateUrl: './invoicing.component.html',
  styleUrls: ['./invoicing.component.scss']
})
export class InvoicingComponent implements OnInit {
  invoiceSubscription$!: Subscription;
  clientChangeSub$: Subscription;
  constructor(
    private apiService: ApiService,
    private dialog: MatDialog,
    private util: CommonUtilService,
    private eventBusService: EventBusService) {
    if (this.util.getClientId())
      this.getInvoiceList();
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.getInvoiceList();
    })
  }
  isLoading: boolean = false;
  innerWidth: any;
  invoiceData: Record<string, any>[] = []

  // invoiceColumns: { columnConfig: TableColumn[] } = {
  //   columnConfig: [
  //     {
  //       name: "Invoice No",
  //       dataField: 'field_invoice_id',
  //       isFilterable: true,
  //       filterValues: [],
  //       filterOpened: false,
  //       isSorted: false,
  //       sortingDirection: SortingDirection.Descending,
  //     }, {
  //       name: "Date",
  //       dataField: 'field_invoice_date',
  //       isFilterable: false,
  //       filterValues: [],
  //       filterOpened: false,
  //       isSorted: false,
  //       sortingDirection: SortingDirection.Descending,
  //     }, {
  //       name: "Invoice Title",
  //       dataField: 'field_invoice_title',
  //       isFilterable: true,
  //       filterValues: [],
  //       filterOpened: false,
  //       isSorted: false,
  //       sortingDirection: SortingDirection.Descending,
  //     },
  //   ]
  // }

  tableConfig: any = {
    hideOnClickOutside: true,
    showFooter: false,
    pagination: {
      pageSize: 2
    },
    columns: [
      {
        columnTitle: "Invoice No",
        dataField: "field_invoice_id"
      }, {
        columnTitle: "Date",
        dataField: "field_invoice_date",
        dataType: "dateTime",
        isFilterable: false,
        style: {
          'width': '155px'
        }
      }, {
        columnTitle: "Invoice Title",
        dataField: "field_invoice_title",
        style: {
          'width': '140px'
        }
      }, {
        columnTitle: "Amount",
        dataField: "field_invoice_amount",
        dataType: "currency"
      }, {
        columnTitle: "Status",
        dataField: "field_invoice_status",
        tag: "styled",
        styles: {
          Paid: { color: "green" },
          else: { color: "orange" }
        }
      }, {
        tag: "actions",
        isFilterable: false,
        isSortable: false,
        actions: [
          {
            title: "Preview",
            icon: "preview",
            callback: this.onPreview,
            scope: this,
            dataFields: ["field_invoice_doc"]
          },
          {
            title: "Dowload",
            icon: "download",
            // linkType: "download",
            callback: this.onDownload,
            scope: this,
            dataFields: ["field_invoice_doc"]
          }
        ]
      }
    ]
  }

  raiseInvoiceDispute() {
    this.eventBusService.emit({ name: Events.InvoiceDispute })
  }
  onDownload(event: any, scope: any, args: any) {
    scope.util.downloadURI(args["field_invoice_doc"], "")
  }

  ngOnInit(): void {
    this.innerWidth = window.innerWidth;
  }

  onPreview(event: any, scope: any, args: any) {
    scope.dialog.open(DocumentPreviewComponent, {
      height: '80%',
      width: '80%',
      panelClass: 'modal-class',
      data: { link: args["field_invoice_doc"] },
      disableClose: true
    })
  }
  getInvoiceList() {
    this.invoiceData=[]
    this.isLoading = true;
    this.invoiceSubscription$ = this.apiService.getInvoice().subscribe((res) => {
      this.invoiceData = res
      this.isLoading = false
    })
  }

  @HostListener('window:resize', ['$event'])
  onResize() {
    this.innerWidth = window.innerWidth;
  }
  ngOnDestroy() {
    this.invoiceSubscription$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }
}
