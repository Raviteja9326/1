import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { appConfig } from 'src/app/app.config';
import { AuthenticationService } from '../../authentication/authentication.service';
import { ConfirmedValidator } from '../../shared/confirm-validator';
import { UserManagementService } from '../../shared/services/user-management.service';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-chanage-password',
  templateUrl: './chanage-password.component.html',
  styleUrls: ['./chanage-password.component.scss']
})
export class ChanagePasswordComponent implements OnInit {
  frmChangePassword!: FormGroup
  updatePasswordSubscription$!: Subscription;

  constructor(private fb: FormBuilder,
    private userService: UserManagementService,
    private auth: AuthenticationService,
    private util: CommonUtilService,
    private alertUtil: AlertUtility) { }

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.frmChangePassword = this.fb.group({
      // mail: ["", Validators.required],
      old_pass: ["", Validators.required],
      new_pass: ["", Validators.required],
      confirm_pass: ["", Validators.required]
    }, {
      validator: ConfirmedValidator('new_pass', 'confirm_pass')
    });
  }


  updatePassword(controls: any) {
    const loginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo)
    const profile = loginInfo.profile;
    const old_pass = controls['old_pass'].value.trim()
    const new_pass = controls['new_pass'].value.trim()
    if (atob(loginInfo.pw) !== old_pass) {
      this.alertUtil.showAlert("error", "Current Password doesn't match.")
      return
    }
    else if (old_pass === new_pass) {
      this.alertUtil.showAlert("error", "Password exists already!")
      return
    }
    const payload = {
      password: new_pass,
      userId: profile?.keyclockuserid,
      realm: profile?.realmid
    }
    this.updatePasswordSubscription$ = this.userService.updatePassword(payload).subscribe((resp: any) => {
      this.alertUtil.showAlert("success", "Password updated successfully.")
      console.log(resp)
      //TODO: need to show the success message to UI
    });

  }

  ngOnDestroy() {
    this.updatePasswordSubscription$?.unsubscribe();
  }
}
