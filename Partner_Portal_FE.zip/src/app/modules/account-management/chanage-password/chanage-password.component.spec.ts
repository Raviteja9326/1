import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChanagePasswordComponent } from './chanage-password.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { KeycloakAngularModule } from 'keycloak-angular';

describe('ChanagePasswordComponent', () => {
  let component: ChanagePasswordComponent;
  let fixture: ComponentFixture<ChanagePasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChanagePasswordComponent ],
      imports: [ReactiveFormsModule, HttpClientModule, KeycloakAngularModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChanagePasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
