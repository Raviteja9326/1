import { Component, OnInit } from '@angular/core';
import { appConfig } from 'src/app/app.config';
import { Events } from 'src/app/models/app.enums';
import { AuthenticationService } from '../../authentication/authentication.service';
import { EventBusService } from '../../shared/event-bus.service';
import { UserManagementService } from '../../shared/services/user-management.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  profileInfo: any;
  appConfig:any = appConfig
  clientChangeSub$: any;

  constructor(private userService: UserManagementService, private authService:AuthenticationService, private eventBusService:EventBusService, private util:CommonUtilService) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (arg: any) => {
      this.bindProfileInfo();
    });

  }

  ngOnInit(): void {
    if(this.util.getClientId())
    this.bindProfileInfo()
  }
  bindProfileInfo(): any {
    const userInfo = this.userService.getLoggedinUserDetails()
    if (userInfo)
      this.profileInfo = this.userService.appendRoles(userInfo);
  }
  objectkeys(obj: any) {
    return Object.keys(obj)
  }
  // checkPermission(permittedRoles: string[]) {
  //   return this.authService.isPermitted(permittedRoles)
  // }
  ngOnDestroy() {
    this.clientChangeSub$?.unsubscribe();
  }

}
