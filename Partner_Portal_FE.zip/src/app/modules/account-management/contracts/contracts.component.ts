import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { ApiService } from "../../shared/api.service";
import { DocumentPreviewComponent } from '../../shared/components/document-preview/document-preview.component';
import { EventBusService } from '../../shared/event-bus.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-contracts',
  templateUrl: './contracts.component.html',
  styleUrls: ['./contracts.component.scss']
})
export class ContractsComponent implements OnInit {
  innerWidth: any;
  isLoading: boolean = false;
  allContracts: any = [];
  clientChangeSub$: Subscription;
  constructor(private apiService: ApiService, private dialog: MatDialog, private eventBusService: EventBusService, private util: CommonUtilService) {
    if (this.util.getClientId())
      this.contractsList();
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.contractsList();
    })
  }

  ngOnInit(): void {
    this.innerWidth = window.innerWidth;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }

  public contractsList() {
    this.isLoading = true;
    this.apiService.getShowContracts().subscribe((contracts: any) => {
      this.allContracts = contracts;
      this.isLoading = false;
    }, (error: any) => {
      this.isLoading = false;
    });
  }
  onPreview(url: string) {
    this.dialog.open(DocumentPreviewComponent, {
      height: '80%',
      width: '80%',
      panelClass: 'modal-class',
      data: { link: url },
      disableClose: true
    })
  }
  ngOnDestroy() {
    this.clientChangeSub$?.unsubscribe();
  }
}
