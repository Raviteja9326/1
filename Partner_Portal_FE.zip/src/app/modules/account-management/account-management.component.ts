import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { AuthenticationService } from '../authentication/authentication.service';
import { EventBusService } from '../shared/event-bus.service';
import { CommonUtilService } from '../utils/common-util.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-account-management',
  templateUrl: './account-management.component.html',
  styleUrls: ['./account-management.component.scss']
})
export class AccountManagementComponent implements OnInit {
  innerWidth: number;
  currentrealm: any;
  menuItems: any = [
    { link: "profile", active: false, name: "Profile Information" },
    // { link: "edit", active: false, name: "Edit Profile" },
    // { link: "change-password", active: false, name: "Change Password" },
    { link: "invoicing", active: false, name: "Invoicing" },
    { link: "contracts", active: false, name: "Contracts & Key documents" },
  ]
  eventSubscription$!: Subscription;

  constructor(private util: CommonUtilService, private router: Router, private eventBusService: EventBusService, private authService: AuthenticationService) {
    this.innerWidth = window.innerWidth;
    this.currentrealm = this.authService.getRealm()
    this.eventSubscription$ = this.eventBusService.on(Events.userEvent, () => {
      setTimeout(() => {
        this.selectMenu(this.router.url);
      }, 200);
    });
  }
  onClick(item: any) {
    this.selectMenu(item.link)
  }

  private initMenu() {
    this.menuItems.forEach((item: any) => {
      item.active = false;
    });
  }

  ngOnInit(): void {
    this.selectMenu(this.router.url);
  }
  private selectMenu(url: string) {
    if (!url.includes('account')) {
      this.router.navigate([`/account/${url}`], {
        queryParams: { realm: this.authService.getRealm() },
      });
    }
    else if (!url.includes('realm') && url.includes('account')) {
      this.router.navigate([`${url}`], {
        queryParams: { realm: this.authService.getRealm() }
      });
    }
    this.initMenu();
    this.menuItems.forEach((item: any) => {
      item.active = url.includes(item.link);
    });
  }

  ngOnDestroy() {
    this.eventSubscription$?.unsubscribe()
  }

}
