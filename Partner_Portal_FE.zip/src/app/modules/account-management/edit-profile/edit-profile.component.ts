import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from '../../authentication/authentication.service';
import { UserManagementService } from '../../shared/services/user-management.service';
import { AlertUtility } from '../../utils/alert.util';
// import { Subscription } from 'rxjs';
// import { UserManagementService } from 'src/app/services/user-management.service';
// import { UtilityService } from 'src/app/services/utility.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {
  frmEditProfile!: FormGroup
  userInfo: any;
  isLoading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthenticationService,
    private userService:UserManagementService,
    private alertUtil:AlertUtility) {
  }

  createForm(userInfo: any) {
    this.frmEditProfile = this.fb.group({
      fname: [userInfo.fname, Validators.required],
      lname: [userInfo.lname, Validators.required],
      // email: [userInfo.email, [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]]
    });
  }

  ngOnInit(): void {
    this.bindProfileInfo()
  }
  bindProfileInfo(): any {
    const userInfo = this.authService.getLoggedinUserDetails()
    if (userInfo) {
      this.userInfo = userInfo;
      this.createForm(userInfo);
    }
  }

  updateProfile(controls: any) {
    this.isLoading = true;
    const payload = {
      id: this.userInfo.id,
      fname: controls['fname'].value,
      lname: controls['lname'].value
    }
    this.userService.updateUser(payload).subscribe((resp: any) => {
      this.userInfo.fname = payload.fname;
      this.userInfo.lname = payload.lname;
      this.userService.setProfileInfo(this.userInfo)
      this.alertUtil.showAlert("success", "Profile updated successfully.")
      this.isLoading = false;
    });

  }

  ngOnDestroy() {
  }
}
