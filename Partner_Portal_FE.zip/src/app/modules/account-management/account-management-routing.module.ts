import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PartnerAwardsComponent } from '../partner-awards/partner-awards.component';
import { AccountManagementComponent } from './account-management.component';
import { ChanagePasswordComponent } from './chanage-password/chanage-password.component';
import { ContractsComponent } from './contracts/contracts.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { InvoicingComponent } from './invoicing/invoicing.component';
import { MyProfileComponent } from './my-profile/my-profile.component';

export const accountRoutes: Routes = [
  {
    path: "",
    component: AccountManagementComponent,
    children: [
      { path: "profile", component: MyProfileComponent },
      { path: "edit", component: EditProfileComponent },
      { path: "change-password", component: ChanagePasswordComponent },
      { path: 'contracts', component: ContractsComponent },
      { path: 'invoicing', component: InvoicingComponent },
    ]
  },
  {
    path: "award",
    component: PartnerAwardsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(accountRoutes)],
  exports: [RouterModule]
})
export class AccountManagementRoutingModule { }
