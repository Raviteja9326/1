import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountManagementRoutingModule } from './account-management-routing.module';
import { ChanagePasswordComponent } from './chanage-password/chanage-password.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { AccountManagementComponent } from './account-management.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DirectivesModule } from '../directives/directives.module';
import { ContractsComponent } from './contracts/contracts.component';
import { InvoicingComponent } from './invoicing/invoicing.component';
import { MaterialModule } from '../shared/material/material.module';
import { PartnerAwardsModule } from '../partner-awards/partner-awards.module';


@NgModule({
  declarations: [ChanagePasswordComponent, MyProfileComponent, AccountManagementComponent, EditProfileComponent, ContractsComponent, InvoicingComponent],
  imports: [
    CommonModule,
    AccountManagementRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DirectivesModule,
    MaterialModule,
    PartnerAwardsModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AccountManagementModule { }
