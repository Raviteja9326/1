import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Field } from '../../forecasting/models/field.model';
import { FormGeneratorService } from '../form-generator.service';
import { AlertUtility } from '../../utils/alert.util';
import { Options } from 'select2';
import { Select2OptionData } from 'ng-select2';
import { appConfig } from 'src/app/app.config';
import { debounceTime } from 'rxjs/operators';
import { Subject } from 'rxjs';
declare var $: any

@Component({
  selector: 'app-section-generator',
  templateUrl: './section-generator.component.html',
  styleUrls: ['./section-generator.component.scss']
})
export class SectionGeneratorComponent implements OnInit {
  @Input() group: any;
  @Input() form!: FormGroup
  fieldDataSub$: any;
  statusSub$: any;
  @Output() autocompleteEmitter = new EventEmitter<any>();
  options!: Options;
  exampleData!: Array<Select2OptionData>;

  constructor(
    private formGeneratorService: FormGeneratorService,
    private alertUtil: AlertUtility,
    private fb: FormBuilder) { }

  ngOnInit(): void {
    this.form = this.form || this.fb.group({});
    this.generateFormGroup(this.form, this.group?.fields, {})


    // $('select').select2()
    //   .on("change", (e: any) => {
    //     // mostly used event, fired to the original element when the value changes
    //     // console.log("change val=" + e);
    //     this.onDatalistValueChange(e)
    //   })
  }

  // onDatalistValueChange(event: any) {
  //   const dataSource: any = this.group.fields.find((f: any) => f.id === event.target.id)?.dataSource
  //   // const values: any[] = dataSource?.values
  //   const flag = Array.from(event.target.options).some((option: any) => option.value.toLowerCase() === event.target.value.toLowerCase())
  //   // const json = JSON.parse(`{${this.group.id}:{${event.target.id}Found:${!flag}}}`)
  //   const json = JSON.parse(`{"${this.group.id}":{"${event.target.id}Found":${flag}}}`)
  //   this.autocompleteEmitter.emit(json)
  // }
  onDatalistValueChange(event: any, fc: FormControl) {
    const dataSource: any = this.group.fields.find((f: any) => f.id === event.target.id)?.dataSource
    const values: any[] = dataSource?.values
    const flag = true
    fc.setValue(event.target.value)
    // const json = JSON.parse(`{${this.group.id}:{${event.target.id}Found:${!flag}}}`)
    const json = JSON.parse(`{"${this.group.id}":{"${event.target.id}Found":${flag}}}`)
    //console.log(`{"${this.group.id}":{"${event.target.id}Found":${flag}}}`)
    this.autocompleteEmitter.emit(json)
  }

  loadData(field: Field, fc: FormControl) {
    // this.disabledValue(field, fc);
    if (field.dataSource?.apiUrl)
      this.fieldDataSub$ = this.formGeneratorService.getDynamicListData(field.dataSource.apiUrl).subscribe({
        next: (resp: any[]) => {
          if (field.dataSource)
            field.dataSource.values = resp
          //console.log(resp)
          if (field.type.toLowerCase() === "autocomplete")
            this.initializeSelect2field(field, fc);

          // field.dataSource.values = resp.map(item => ({ id: item[field.dataSource?.valueField || "name"], text: item[field.dataSource?.nameField || "name"] }))
        },
        error: (error: any) => {
          this.alertUtil.showAlert('error', error)
        }
      })
  }
  initializeSelect2field(field: any, fc: FormControl) {
    $(`#${field.id}`).select2();
    // $(`#${field.id}`).select2({
    //   tags: true,
    //   minimumInputLength: appConfig.minSearchTermlength,
    //   allowClear: true
    // });
    $(`#${field.id}`).on('select2:select', (e: any) => {
      const selectedValue = $(`#${field.id}`).val();
      this.onDatalistValueChange({ target: { id: field.id, value: selectedValue } }, fc);
    });

    $(document).on('input', '.select2-search__field', function (e: any) {
      searchTermSubject.next(e.target.value);
    });

    const searchTermSubject = new Subject<string>();

    searchTermSubject.pipe(debounceTime(250)).subscribe((searchTerm: string) => {

      this.formGeneratorService.getDynamicListData(`${field.dataSource?.apiUrl}?key_word=${searchTerm}`).subscribe({
        next: (data: any[]) => {
          // console.log(field.dataSource)
          // if(!data.length){ data=[{id:`${searchTerm}newData`,text:searchTerm}]}
          // console.log(data)
         const results = data.map((item: any) => (
            {
              id: item[field.dataSource.valueField || 'id'],
              text: item[field.dataSource.nameField || 'name'],

            }));
          // console.log(results)
          // Update select2 results
          $(`#${field.id}`).select2('trigger', 'results:all', { results: results });
        },
        error: (error: any) => {
          console.error('Error fetching data:', error);
        },
      });
    });
  }

  loadLovData(field: any, fc: FormControl) {
    const listFields: string[] = ["dropdown", "checks", "radios", "autocomplete"]
    if (listFields.includes(field.type)) {
      this.loadData(field, fc)
    }
  }
  generateFormGroup(form: FormGroup, fields: any[], defaultValues: any) {
    fields.forEach((field: Field, i: any) => {
      this.addFormField(form, field, defaultValues?.[field.id]);

    });
    // return formGroup
  }

  private addFormField(formGroup: FormGroup, field: Field, defaultValue: any) {

    field.errorMessage = `${field.title} is required`;
    const fc: FormControl = new FormControl(defaultValue || field?.defaultValue || "");
    fc.setValidators(this.formGeneratorService.getValidators(field));
    formGroup.addControl(field.id, fc);
    this.loadLovData(field, fc); //LOV => List of Value
    //this.disabledValue(field, fc);
    this.statusSub$ = fc.statusChanges.subscribe(v => {
      // fc.setValue(fc.value?.trim())
      if (v === "INVALID") {
        field.errorMessage = this.formGeneratorService.getErrorMessage(field, fc.errors);
      }
    });
  }

  // disabledValue(field: any, fc:FormControl) {
  //   if(field.readOnly===true) {
  //     fc.disable({ onlySelf: true });
  //   }
  // }

  ngOnDestroy() {
    this.fieldDataSub$?.unsubscribe();
    this.statusSub$?.unsubscribe();

  }
}
