import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SectionGeneratorComponent } from './section-generator.component';

describe('SectionGeneratorComponent', () => {
  let component: SectionGeneratorComponent;
  let fixture: ComponentFixture<SectionGeneratorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SectionGeneratorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SectionGeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
