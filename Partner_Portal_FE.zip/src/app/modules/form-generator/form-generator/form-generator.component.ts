import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import _ from 'lodash';
import { CommonUtilService } from '../../utils/common-util.service';
import { SortingDirection } from 'src/app/models/app.enums';
import { FormGeneratorService } from '../form-generator.service';

@Component({
  selector: 'app-form-generator',
  templateUrl: './form-generator.component.html',
  styleUrls: ['./form-generator.component.scss']
})
export class FormGeneratorComponent implements OnInit {
  autocompleteStatus: any = {};
  @Input() form!: FormGroup
  @Input() jsonFormGroups!: any[]


  /**
   *
   * @param util
   * "dataSource": {
          "apiUrl": "api/csSearchOrganizationID",
          "valueField": "organizationName",
          "nameField": "organizationName"
        }

        "dataSource": {
          "apiUrl": "https://jsonplaceholder.typicode.com/users",
          "valueField": "username",
          "nameField": "username"
        }


   * @param fb
   */
  constructor(private util: CommonUtilService, private fb: FormBuilder, private formGeneratorService:FormGeneratorService) { }

  ngOnInit(): void {
    // debugger
    this.form = this.form || this.fb.group({})
    this.sortBySerial(this.jsonFormGroups);

  }

  private sortBySerial(resp: any[]) {
    // const groups = resp;
    this.util.sort(this.jsonFormGroups, "serial", SortingDirection.Ascending);
    this.jsonFormGroups.forEach((group: any) => {
      this.util.sort(group.fields, 'serial', SortingDirection.Ascending);
      this.createFromGroup(group);
      this.setRequiredField(group.fields)
    });
  }
  private createFromGroup(group: any) {
    group.formGroup = this.fb.group({});
    this.form.addControl(group.id, group.formGroup);
  }

  setRequiredField(fields: any) {
    fields.forEach((field: any) => {
      field.required = field.validators?.some((v: any) => v.name.toLowerCase() === "required")
    })
  }

  updateAutoCompleteInfo(event: any) {
    this.autocompleteStatus = _.merge(this.autocompleteStatus, event)
    this.formGeneratorService.payload = _.merge(this.form.value, this.autocompleteStatus)

    // console.log(payload)
  }


}
