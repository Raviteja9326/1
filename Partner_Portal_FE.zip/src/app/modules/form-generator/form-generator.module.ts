import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SectionGeneratorComponent } from './section-generator/section-generator.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../shared/material/material.module';
import { FormGeneratorComponent } from './form-generator/form-generator.component';
import { NgSelect2Module } from 'ng-select2';



@NgModule({
  declarations: [
    SectionGeneratorComponent,
    FormGeneratorComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MaterialModule,
    NgSelect2Module
  ],
  exports:[
    FormGeneratorComponent
    // SectionGeneratorComponent
  ]
})
export class FormGeneratorModule { }
