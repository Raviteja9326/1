import { Injectable } from '@angular/core';
import { ValidatorFn, Validators } from '@angular/forms';
import { NoWhitespaceValidator } from '../validation/validators/no-whitespace-validator';
import { InvalidCharactersValidator } from '../validation/validators/invalid-characters-validator';
import { EmailValidator } from '../validation/validators/email-validator';
import { UrlValidator } from '../validation/validators/url-validator';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { MobileNumberValidator } from '../validation/validators/mobile-number-validator';
import _ from 'lodash';
import { TagValidator } from '../validation/validators/tag-validator';
import { AlertUtility } from '../utils/alert.util';

@Injectable({
  providedIn: 'root'
})
export class FormGeneratorService {
  updateMode(readOnly: boolean = false, resp: any[]): any[] {
    if (!readOnly) return resp
    resp.forEach(section => { section.fields.forEach((field: { readonly: boolean; }) => { field.readonly = true }) })
    return resp
  }
  getFieldType(type: string, multiple: boolean): string {
    switch (type.toLowerCase()) {
      case "textfield": return "textbox"
      case 'radio': return "radios"
      case 'select': return multiple ? "multiselect" : "dropdown"
      // case 'select': return multiple ? "multiselect" : "singleselect"
      case 'checkbox': return 'checks'
      default: return type
    }
  }

  defautValues: any;
  getFormData(fromValue: any) {
    const formData = _.cloneDeep(fromValue);
    delete formData?.Open;
    _.merge(formData, fromValue?.Open);
    return formData;
  }
  validateData(payload: any, jsonFormGroups: any[]) {
    const allFields = jsonFormGroups.reduce((c, item) => _.merge(c, item.fields), [])
    const conditionalFields: any[] = allFields.filter((f: any) => f.conditions)
    let errorFound: boolean = false
    for (let i = 0; i < conditionalFields.length; i++) {
      if (errorFound) break
      const field = conditionalFields[i]
      const value = payload[field.id]
      if (value === "") continue
      let expression = ""
      let errorMessage = `${field.title} should be `
      for (let j = 0; j < field.conditions.length; j++) {
        const condition = field.conditions[j]
        if (!this.isConditionProperlyDefined(condition)) {
          this.alertUtil.showAlert("error", `The conditions for the field ${field.title} is not defined properly!.`)
          errorFound = true
          break
        } else {
          if (condition.id) {
            const comparator = allFields.find((field: any) => field.id === condition.id)
            if (comparator) {
              const comparatorValue = payload[comparator.id]
              if (comparatorValue === "") {
                errorFound = true
                this.alertUtil.showAlert("error", `${comparator.title} should have some value.`)
                break
              } else {
                expression += `("${value}"${condition.relation}"${comparatorValue}") ||`
                errorMessage += `${condition.message} ${comparator.title} or`
              }
            } else {
              errorFound = true
              this.alertUtil.showAlert("error", `No field found with id=${condition.id}`)
              break
            }
          }
          else {
            expression += `(${value}${condition.relation}${condition.value}) ||`
            errorMessage += `${condition.message} ${condition.value} or `
          }
        }
      }
      errorFound = this.evaluateExpression(expression, errorMessage);

    }
    return !errorFound
  }
  private isConditionProperlyDefined(condition: any) {
    return condition.message && condition.relation && (condition.value != undefined || condition.id);
  }

  private evaluateExpression(expression: string, errorMessage: string) {
    let error = false
    expression = _.trim(expression.trim(), '|');
    errorMessage = _.trim(errorMessage.trim(), " or");
    if (!eval(expression)) {
      error = true
      this.alertUtil.showAlert("error", errorMessage);
    }
    return error;
  }
  getDynamicFormGeneratorData(apiUrl: string = "assets/data/opportunity/sf-form.json") {
    const url = (apiUrl.includes("http") || apiUrl.includes("assets/data")) ? apiUrl : `${environment.endpoints.drupal}${apiUrl}`
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  payload: any;
  getDynamicListData(apiUrl: string) {
    const url = (apiUrl.includes("http") || apiUrl.includes("assets/data")) ? apiUrl : `${environment.endpoints.drupal}${apiUrl}`
    return this.http.get(url).pipe(map((response: any) => response));
  }
  getErrorMessage(field: any, error: any) {
    const err = Object.keys(error)[0]
    switch (err.toLowerCase()) {
      case "required":
        return `${field.title} is required`
      case "min":
        return `Minimum allowed value is ${field.validators?.find((v: FieldValidator) => v.name.toLowerCase() === err.toLowerCase())?.value}.`
      case "max":
        return `Maximum allowed value is ${field.validators?.find((v: FieldValidator) => v.name.toLowerCase() === err.toLowerCase())?.value}.`
      case "minlength":
        return `Number of characters are ${error[err].actualLength} (Min limit ${error[err].requiredLength})`
      // return `Please add at least ${error[err].requiredLength - error[err].actualLength} more character(s).`
      case "maxlength":
        // return `Please remove ${error[err].actualLength - error[err].requiredLength} character(s).`
        return `Number of characters are ${error[err].actualLength} (Max limit ${error[err].requiredLength})`
      case "email":
        return `The ${field.title} is not valid.`
      // case "pattern":
      //   return `The ${field.title} is not valid.`
      case "invalidurl":
        return `The ${field.title} is not valid.`
      case "invalidmobile":
        return `The ${field.title} is not valid.`
      case "invalidcharacters":
        return `Invalid Characters (${error[err].characters})`
      case "tag":
        return `HTML tag is not allowed`
      default:
        return ""
    }
  }

  constructor(private http: HttpClient, private alertUtil: AlertUtility) { }

  supportedValidator(validatorName: string) {
    const supportedValidators = ["required", "minlength", 'maxlength', "min", "max", "email",
      "emailvalidator", "nowhitespacevalidator", "invalidcharactersvalidator", "mobilenumbervalidator", "urlvalidator"]
    return supportedValidators.some(v => v === validatorName.toLowerCase())
  }
  getValidators(field: any) {
    const vals: ValidatorFn[] = []
    const validators = field?.validators || []
    validators.forEach((v: FieldValidator) => {
      switch (v.name.toLowerCase()) {
        case "required":
          if (v.value !== false)
            vals.push(Validators.required)
          break;
        case "minlength":
          if (v.value)
            vals.push(Validators.minLength(v.value))
          break;
        case "maxlength":
          if (v.value)
            vals.push(Validators.maxLength(v.value))
          break;
        case "min":
          if (v.value)
            vals.push(Validators.min(v.value))
          break;
        case "max":
          if (v.value)
            vals.push(Validators.max(v.value))
          break;
        case "email":
          vals.push(Validators.email)
          break;
        case "emailvalidator":
          vals.push(EmailValidator.isValid())
          break;
        // case "pattern":
        //   if (v.value)
        //     vals.push(validators.pattern(v.value))
        //   break;
        case "nowhitespacevalidator":
          vals.push(NoWhitespaceValidator.isValid())
          break;
        case "invalidcharactersvalidator":
          vals.push(InvalidCharactersValidator.isValid(v.value))
          break;
        case "mobilenumbervalidator":
          vals.push(MobileNumberValidator.isValid())
          break;
        case "urlvalidator":
          vals.push(UrlValidator.isValid())
          break;
        case "tagvalidator":
          vals.push(TagValidator.isValid())
          break;
        default:
          console.log(`The Validator ${v.name} not found`)
          break;
      }
    })
    return vals.length ? vals : []
  }

  getDateTimeFormValue(datetime: any) {
    return datetime?.substring(0, 16)
  }


}
export interface FieldValidator {
  name: string, //required:, minLength:number, maxLength:number, email:
  value?: any,
}
