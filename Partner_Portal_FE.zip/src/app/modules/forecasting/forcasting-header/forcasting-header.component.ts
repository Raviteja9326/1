import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forcasting-header',
  templateUrl: './forcasting-header.component.html',
  styleUrls: ['./forcasting-header.component.scss']
})
export class ForcastingHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
