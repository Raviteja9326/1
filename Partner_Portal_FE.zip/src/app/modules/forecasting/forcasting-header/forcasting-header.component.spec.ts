import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForcastingHeaderComponent } from './forcasting-header.component';

describe('ForcastingHeaderComponent', () => {
  let component: ForcastingHeaderComponent;
  let fixture: ComponentFixture<ForcastingHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForcastingHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForcastingHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
