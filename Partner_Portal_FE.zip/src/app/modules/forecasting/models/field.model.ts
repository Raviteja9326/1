import { FieldValidator } from "./field-validator.model"

export interface Field {
  id: string,
  serial: number,
  title: string,
  readOnly:boolean,
  type: string, //textbox, textarea, radios, checks, number, dropdown, switch, email, date etc
  required: boolean, //computed field from validators
  errorMessage: string, //compute field
  validators?: FieldValidator[],
  defaultValue?: any,
  dataSource?: {
    apiUrl?: string,
    nameField: string,
    valueField: string,
    values?: any[]
  }
  values?:
  {
    name: string,
    value: any
  }[]
}
