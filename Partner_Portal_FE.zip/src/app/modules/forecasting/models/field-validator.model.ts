import { Validators } from "@angular/forms";

export interface FieldValidator {
  name: string, //required:, minLength:number, maxLength:number, email:
  value?: any,
}

