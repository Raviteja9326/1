import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddForecastDynamicComponent } from './add-forecast-dynamic.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

describe('AddForecastDynamicComponent', () => {
  let component: AddForecastDynamicComponent;
  let fixture: ComponentFixture<AddForecastDynamicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddForecastDynamicComponent ],
      imports:[HttpClientModule, ReactiveFormsModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddForecastDynamicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
