import { Component, Input, OnInit } from '@angular/core';
import { ForcastingService as ForecastingService } from '../forcasting.service';
import { Subscription, forkJoin } from 'rxjs';
import { Field } from '../models/field.model';
import { MatListOption } from '@angular/material/list';
import { FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { AlertUtility } from '../../utils/alert.util';
import { EventBusService } from '../../shared/event-bus.service';
import { Events, SortingDirection } from 'src/app/models/app.enums';
import { FieldValidator } from '../models/field-validator.model';
import { CommonUtilService } from '../../utils/common-util.service';
import { EmailValidator } from '../../validation/validators/email-validator';
import { NoWhitespaceValidator } from '../../validation/validators/no-whitespace-validator';
import { InvalidCharactersValidator } from '../../validation/validators/invalid-characters-validator';
import { UrlValidator } from '../../validation/validators/url-validator';

@Component({
  selector: 'app-add-forecast-dynamic',
  templateUrl: './add-forecast-dynamic.component.html',
  styleUrls: ['./add-forecast-dynamic.component.scss']
})
export class AddForecastDynamicComponent implements OnInit {
  forDataSub$!: Subscription;
  isLoading: boolean = false;
  fields: Field[] = [];
  forecastForm!: FormGroup;
  addForcastSub$!: Subscription;
  statusSub$!: Subscription;
  @Input() forecastId: string = ""
  updateForcastSub$!: Subscription;

  constructor(
    private forecastService: ForecastingService,
    private fb: FormBuilder,
    private alertUtil: AlertUtility,
    private eventBusService: EventBusService,
    private util: CommonUtilService) { }

  ngOnInit(): void {
    this.showForecastForm(this.forecastId)
  }
  selectionChange(option: MatListOption) {
    console.log(option.selectionList._value);
  }
  showForecastForm(forecastId: string) {
    this.isLoading = true
    const pForecastFields = this.forecastService.getForecastingFormFields();
    const pForecastDetails = this.forecastService.getDynamicForecastDetails(forecastId);
    this.forDataSub$ = forkJoin([pForecastFields, pForecastDetails]).subscribe({
      next: (resp: any[]) => {
        const fields = resp[0]
        this.util.sort(fields, "serial", SortingDirection.Ascending)
        this.fields = fields
        this.generateForm(fields, resp[1])
      },
      error: (error) => {
        this.alertUtil.notifyToast(error.message, 'error')
        this.isLoading = false
      },
      complete: () => { this.isLoading = false }
    })
  }
  generateForm(fields: any, forecastDetails: any) {
    this.forecastForm = this.fb.group({});

    fields.forEach((field: Field, i: any) => {
      field.errorMessage = `${field.title} is required`
      const fc: FormControl = new FormControl(forecastDetails?.[field.id] || field?.defaultValue || "")
      fc.setValidators(this.getValidators(field))
      this.forecastForm.addControl(field.id, fc)
      this.statusSub$ = fc.statusChanges.subscribe(v => {
        // fc.setValue(fc.value?.trim())
        if (v === "INVALID") {
          field.errorMessage = this.getErrorMessage(field, fc.errors)
        }
      })
    });
  }

  getErrorMessage(field: Field, error: any) {
    const err = Object.keys(error)[0]
    switch (err.toLowerCase()) {
      case "required":
        return `${field.title} is required`
      case "minlength":
        return `Please add at least ${error[err].requiredLength - error[err].actualLength} more characters.`
      case "maxlength":
        return `Please remove ${error[err].actualLength - error[err].requiredLength} characters.`
      case "email":
        return `The email is not valid.`
      case "invalidurl":
        return `The url is not valid.`
      case "invalidcharacters":
        return `Invalid Characters (${field.validators?.find(v => v.name.toLowerCase() === 'invalidcharactersvalidator')?.value})`
      default:
        return ""
    }
  }
  getValidators(field: Field) {
    const vals: ValidatorFn[] = []
    const validators = field?.validators || []
    validators.forEach((v: FieldValidator) => {
      switch (v.name.toLowerCase()) {
        case "required":
          field.required = true
          vals.push(Validators.required)
          break;
        case "minlength":
          vals.push(Validators.minLength(v.value))
          break;
        case "maxlength":
          vals.push(Validators.maxLength(v.value))
          break;
        case "email":
          vals.push(Validators.email)
          break;
        case "nowhitespacevalidator":
          vals.push(NoWhitespaceValidator.isValid())
          break;
        case "invalidcharactersvalidator":
          vals.push(InvalidCharactersValidator.isValid())
          break;
        case "emailvalidator":
          vals.push(EmailValidator.isValid())
          break;
        case "urlvalidator":
          vals.push(UrlValidator.isValid())
          break;
        default:
          console.error(`The Validator ${v.name} not found`)
          break;
      }
    })
    return vals.length ? vals : []
  }

  onForecastSubmit() {
    this.isLoading = true
    if (this.forecastId)
      this.UpdateForecast()
    else
      this.createForecast();
  }

  private createForecast() {
    this.addForcastSub$ = this.forecastService.createDynamicForecast(this.forecastForm.value).subscribe({
      next: (resp: any) => {
        this.alertUtil.showAlert("success", `${resp.message}!`);
        this.eventBusService.emit({ name: Events.HideModelPopup });
        this.eventBusService.emit({ name: Events.ForecastAdded, value: { ...this.forecastForm.value, id: resp.forecastId } })
      },
      error: (error: any) => {
        this.alertUtil.showAlert("error", error.error.message || `Sorry for the inconvenience!<br> Please re-check the inputs before submission.`);
        this.isLoading = false;
      },
      complete: () => { this.isLoading = false; }
    });
  }

  private UpdateForecast() {
    this.updateForcastSub$ = this.forecastService.updateDynamicForecast(this.forecastForm.value, this.forecastId).subscribe({
      next: (resp: any) => {
        this.alertUtil.showAlert("success", `${resp.message}!`);
        this.eventBusService.emit({ name: Events.HideModelPopup });
        this.eventBusService.emit({ name: Events.ForecastUpdated, value: { ...this.forecastForm.value, id: this.forecastId } })
      },
      error: (error: any) => {
        this.alertUtil.showAlert("error", error.error.message || `Sorry for the inconvenience!<br> Please re-check the inputs before submission.`);
        this.isLoading = false;
      },
      complete: () => { this.isLoading = false; }
    });
  }
  reset() {
    if (this.forecastId){
      this.ngOnInit()
    }
    else{
      this.forecastForm.reset()
      this.setDefaultValues(this.fields)
    }
  }

  setDefaultValues(fields: Field[]) {
    fields.forEach((field: Field) => {
      this.forecastForm.get(field.id)?.setValue(field?.defaultValue || "")
    })
  }

  ngOnDestroy() {
    this.addForcastSub$?.unsubscribe();
    this.forDataSub$?.unsubscribe();
    this.statusSub$?.unsubscribe();
    this.updateForcastSub$?.unsubscribe();
  }

}
