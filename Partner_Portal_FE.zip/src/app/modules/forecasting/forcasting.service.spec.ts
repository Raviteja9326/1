import { TestBed } from '@angular/core/testing';

import { ForcastingService } from './forcasting.service';
import { HttpClientModule } from '@angular/common/http';

describe('ForcastingService', () => {
  let service: ForcastingService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientModule
      ]
    });
    service = TestBed.inject(ForcastingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
