import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { SummaryListComponent } from './summary-list/summary-list.component';
import { ForcastingHeaderComponent } from './forcasting-header/forcasting-header.component';
import { SummaryComponent } from './summary/summary.component';
import { MaterialModule } from '../shared/material/material.module';
import { AddForecastComponent } from './add-forecast/add-forecast.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ChartingModule } from '../charting/charting.module';
import { DirectivesModule } from '../directives/directives.module';
import { AddForecastDynamicComponent } from './add-forecast-dynamic/add-forecast-dynamic.component';
import { ValidationModule } from '../validation/validation.module';
import { ForecastingListComponent } from './forecasting-list/forecasting-list.component';


const routes: Routes = [{
  path: '', component: DashboardComponent
},]
@NgModule({
  declarations: [
    HeaderComponent,
    DashboardComponent,
    SummaryListComponent,
    SummaryComponent,
    ForcastingHeaderComponent,
    AddForecastComponent,
    AddForecastDynamicComponent,
    ForecastingListComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    ChartingModule,
    DirectivesModule,
    ValidationModule,
    RouterModule.forChild(routes),
  ],
  exports: [
    ForecastingListComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ForecastingModule {
}
