import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import * as XLSX from 'xlsx';
import _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class ForcastingService {
  updateDynamicForecast(payload: any, forecastId: string) {
    const apiUrl = `${environment.endpoints.drupal}api/csUpdateForecastData/${forecastId}`;
    return this.http.put(apiUrl, payload).pipe(map((response) => response));
  }
  getDynamicForecastDetails(forecastId: string) {
    if (!forecastId) return of({})
    const apiUrl = `${environment.endpoints.drupal}api/csShowForecastData/${forecastId}`;
    return this.http.get(apiUrl).pipe(map((response) => response));
  }
  getDynamicForecastingList() {
    // const apiUrl = `assets/data/forecast/aws-forecast-list.json`;
    const apiUrl = `${environment.endpoints.drupal}api/csShowForecastData/all`;
    return this.http.get(apiUrl).pipe(map((response) => response));
  }
  createDynamicForecast(payload: any) {
    // console.log("AWS forecast", JSON.stringify(payload))
    const apiUrl = `${environment.endpoints.drupal}api/csCreateForecastData`;
    return this.http.post(apiUrl, payload).pipe(map((response) => response));
  }
  getForecastingFormFields() {
    // const apiUrl = `assets/data/forecast/aws-forecast.json`;
    const apiUrl = `${environment.endpoints.drupal}api/csShowForecastForm`;
    return this.http.get(apiUrl).pipe(map((response) => response));
  }
  getForecastCategory(key: string) {
    // const apiUrl = `assets/data/forecast/categories.json`;
    const apiUrl = `${environment.endpoints.drupal}api/csForecastCategory/${key}`;
    return this.http.get(apiUrl).pipe(map((response) => response));
  }
  createForecast(payload: any) {
    const apiUrl = `${environment.endpoints.drupal}api/csCreateForecast`;
    return this.http.post(apiUrl, payload).pipe(map((response) => response));
  }
  getListOfValues(key: string) {
    const apiUrl = `${environment.endpoints.drupal}api/csForecastData/${key}`;
    return this.http.get(apiUrl).pipe(map((response) => response));
  }
  getAllForecasts() {
    const apiUrl = `${environment.endpoints.drupal}api/csShowForecast/all`;
    return this.http.get(apiUrl).pipe(map((response) => response));
  }
  getForcastSummary() {
    // const url = `assets/data/forecast/forecast-summary.json`;
    const apiUrl = `${environment.endpoints.drupal}api/csShowForecast/projection`;
    return this.http.get(apiUrl).pipe(map((response: any) => response));
  }

  getCustomerForcastingData() {
    const url = `${environment.endpoints.drupal}api/csForecastGraphData/revenueGraphData`;
    // const url = `assets/data/forecast/customer-forecast.json`;
    return this.http.get(url).pipe(map((response: any) => response));
  }
  getServerForcastingData() {
    const url = `${environment.endpoints.drupal}api/csForecastGraphData/vmsGraphData`;
    // const url = `assets/data/forecast/server-forecast.json`;
    return this.http.get(url).pipe(map((response: any) => response));
  }

  exportAsExcelFile(data: any[], mergeExpression: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    worksheet['!cols'] = this.fitToColumn(data);
    // worksheet["!merges"] = mergeExpression;
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    XLSX.writeFile(workbook, this.toExportFileName(excelFileName));
  }

  private fitToColumn(data: any[]) {
    const wscols: any[] = []
    for (let key in data[0]) {
      const maxItem = _.maxBy(data, function (o) {
        return o[key]?.length || 0
      })
      const maxLength = maxItem[key].length
      wscols.push({ wch: maxLength > key.length ? maxLength : key.length })
    }
    return wscols
    // get maximum character of each column
    // return data[0].map((d: any, i: number) => ({ wch: Math.max(...data.map(a2 => a2[i] ? a2[i].toString().length : 0)) }));
  }

  private toExportFileName(excelFileName: string): string {
    return `${excelFileName}_export_${new Date().getTime()}.xlsx`;
  }


  constructor(private http: HttpClient) { }
}
