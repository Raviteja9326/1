import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { EventBusService } from '../../shared/event-bus.service';
import { CommonUtilService } from '../../utils/common-util.service';
import { ForcastingService } from '../forcasting.service';
import { AuthenticationService } from '../../authentication/authentication.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  forcastSummary: any;
  forecastSummarySub$!: Subscription;
  allForecastSub$!: Subscription;
  allForecasts: any;
  customerForecastingData: any;
  lineChartSub$!: Subscription;
  isLoading: boolean = false
  forecastAdd$: Subscription;
  clientChangeSub$: Subscription;
  serverForecastingData: any;
  realm: string = "";

  constructor(private forcastService: ForcastingService, private eventBusService: EventBusService, private util: CommonUtilService, private authService:AuthenticationService) {
    this.forecastAdd$ = this.eventBusService.on(Events.ForecastAdded, () => {
      this.loadData()
    })
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (arg: any) => {
      this.loadData()
    });
  }

  ngOnInit(): void {
    this.realm = this.authService.getRealm().toLowerCase();
    if (this.util.getClientId())
      this.loadData();
  }
  private loadData() {
    this.loadForecastSummary();
    // this.loadAllForecasts();
    this.loadCustomerForecastingData();
    this.loadServerForecastingData();
  }
  loadServerForecastingData() {
    this.isLoading = true
    this.lineChartSub$ = this.forcastService.getServerForcastingData().subscribe((resp: any) => {
      this.isLoading = false
      this.serverForecastingData = resp;
    }, (error: any) => {
      this.isLoading = false
      console.log(error);
    });
  }

  loadCustomerForecastingData() {
    this.isLoading = true
    this.lineChartSub$ = this.forcastService.getCustomerForcastingData().subscribe((resp: any) => {
      this.isLoading = false
      this.customerForecastingData = resp;
    }, (error: any) => {
      this.isLoading = false
      console.log(error);
    });
  }
  loadAllForecasts() {
    this.isLoading = true
    this.allForecastSub$ = this.forcastService.getAllForecasts().subscribe((resp: any) => {
      this.isLoading = false
      this.allForecasts = resp;
      console.log(resp)
    }, (error: any) => {
      this.isLoading = false
      console.log(error);
    });
  }

  private loadForecastSummary() {
    this.isLoading = true
    this.forecastSummarySub$ = this.forcastService.getForcastSummary().subscribe((resp: any) => {
      this.isLoading = false
      this.forcastSummary = resp;
    }, (error: any) => {
      this.isLoading = false
      console.log(error);
    });
  }

  ngOnDestroy() {
    this.forecastSummarySub$?.unsubscribe();
    this.allForecastSub$?.unsubscribe();
    this.lineChartSub$?.unsubscribe();
    this.forecastAdd$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }

}
