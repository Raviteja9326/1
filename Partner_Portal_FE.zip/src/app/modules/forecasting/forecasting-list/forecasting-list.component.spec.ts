import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForecastingListComponent } from './forecasting-list.component';

describe('ForecastingListComponent', () => {
  let component: ForecastingListComponent;
  let fixture: ComponentFixture<ForecastingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForecastingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForecastingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
