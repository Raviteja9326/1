import { Component, OnInit } from '@angular/core';
import { ForcastingService } from '../forcasting.service';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { Popups } from '../../shared/popup/popup-mapper';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-forecasting-list',
  templateUrl: './forecasting-list.component.html',
  styleUrls: ['./forecasting-list.component.scss']
})
export class ForecastingListComponent implements OnInit {
  forecastingListSub$!: Subscription;
  isLoading: boolean = false;
  forecastingList: any[] = [];
  forecastChangedSub$: Subscription;
  clientChangeSub$: Subscription;
  tableConfig: any = {}
  constructor(
    private forecastService: ForcastingService,
    private eventBusService: EventBusService,
    private util:CommonUtilService,
    private alertUtil: AlertUtility
  ) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.loadForecastingList()
    })
    this.forecastChangedSub$ = this.eventBusService.on(Events.ForecastAdded, (forecast: any) => {
      this.loadForecastingList()
    })
    this.forecastChangedSub$ = this.eventBusService.on(Events.ForecastUpdated, (forecast: any) => {
      this.loadForecastingList()
    })
  }

  ngOnInit(): void {
    this.tableConfig = {
      hideOnClickOutside: true,
      showFooter: false,
      classes: [
        "customTable",
        "table",
        "table-striped",
        "border",
        "mb-0"
      ],
      pagination: {
        pageSize: 2
      },
      columns: [
        {
          columnTitle: "Prospect Name",
          dataField: "prospectName",
          classes: ["ellipsis"],
          headerStyle: {
            'width': '150px'
          },
        }, {
          columnTitle: "Prospect size",
          dataField: "prospectSize",
          isSortable: false,
          headerStyle: {
            'width': '120px'
          },
        }, {
          columnTitle: "Expected Revenue",
          dataField: "expectedRevenue",
          isFilterable: false,
          dataType: "currency",
          headerStyle: {
            'width': '155px'
          },
        },
        // {
        //   columnTitle: "Rep Email",
        //   dataField: "awsRepEmail",
        //   classes: ["ellipsis"],
        //   headerStyle: {
        //     'width': '130px'
        //   },
        // },
        // {
        //   columnTitle: "Prospect Location",
        //   dataField: "prospectLocation",
        //   // isFilterable: false,
        //   headerStyle: {
        //     'width': '140px'
        //   },
        // },
        {
          columnTitle: "Status",
          dataField: "status",
          isFilterable: false,
          headerStyle: {
            'width': '140px'
          },
        },
        {
          tag: "actions",
          isFilterable: false,
          isSortable: false,
          headerStyle: { "width": "45px" },
          actions: [
            {
              title: "Edit",
              icon: "edit",
              callback: this.editForecast,
              scope: this,
            },
          ],
        }
      ]
    }
    if (this.util.getClientId()) {
      this.isLoading = true
      this.loadForecastingList();
    }
  }

  loadForecastingList() {
    this.isLoading = true;
    this.forecastingListSub$ = this.forecastService.getDynamicForecastingList().subscribe((resp: any) => {
      this.forecastingList = resp;
      this.isLoading = false;
    }, (error) => {
        this.alertUtil.notifyToast(error.message, 'error')
        this.isLoading = false
    });
  }

  downloadReport() {
    if(this.forecastingList && this.forecastingList.length > 0){
      this.generateExcelReport(this.forecastingList);
    }
  }

  generateExcelReport(reportData: any) {
    const processedData = this.processReportData(reportData)
    this.forecastService.exportAsExcelFile(processedData.data, processedData.mergeExpression, "forecast_report")
  }

  processReportData(reportData: any[]) {
    const data: any[] = []
    const mergeExpression: { s: { r: number, c: number }, e: { r: number, c: number } }[] = []
    reportData.forEach((forecast, i) => {
      const obj: any = {}
      obj["Prospect Name"] = forecast.prospectName
      obj["Prospect Size"] = forecast.prospectSize
      obj["Prospect Location"] = forecast.prospectLocation
      obj["URL"] = forecast.url
      obj["Prospect Business Summary"] = forecast.businessSummary
      obj["Expected Rev"] = forecast.expectedRevenue
      obj["Request Summary"] = forecast.requestSummary
      obj["AWS Sales Rep"] = forecast.awsRepName
      obj["Next Steps"] = forecast.nextSteps
      data.push(obj)
      // this.generateMergeExpression(i, survey, mergeExpression);
    })
    return { data, mergeExpression }
  }

  editForecast(event: any, scope: any, forecast: any) {
    event.stopPropagation();
    scope.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.AddDynamicForecast, title: "Update Forecast", params: [{ key: "forecastId", value: forecast.id }] } })
  }

  ngOnDestroy() {
    this.forecastingListSub$?.unsubscribe();
    this.forecastChangedSub$.unsubscribe();
  }

}


