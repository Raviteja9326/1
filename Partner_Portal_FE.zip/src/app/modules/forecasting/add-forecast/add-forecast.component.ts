import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { forkJoin, Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { EventBusService } from '../../shared/event-bus.service';
import { ForcastingService } from '../forcasting.service';
import { AlertUtility } from '../../utils/alert.util';
import { InvalidCharactersValidator } from '../../validation/validators/invalid-characters-validator';
import { NoWhitespaceValidator } from '../../validation/validators/no-whitespace-validator';
import { EmailValidator } from '../../validation/validators/email-validator';
import { MobileNumberValidator } from '../../validation/validators/mobile-number-validator';

@Component({
  selector: 'app-add-forecast',
  templateUrl: './add-forecast.component.html',
  styleUrls: ['./add-forecast.component.scss']
})
export class AddForecastComponent implements OnInit {
  frmAddForecast!: FormGroup;
  industries!: { tid: string, name: string }[]
  headQuarters!: { tid: string, name: string }[]
  infraLocations!: { tid: string, name: string }[]
  serviceTypes!: { id: string, name: string }[]
  cloudList!: { id: string, name: string }[];
  // subCategories:

  categoryies: { name: string, subCategories: { name: string, key: string }[] }[] = []
  subCategories: { name: string, key: string }[] = []
  statusList!: { id: string, name: string }[]// = ["New Request", "Approved", "Concierto Scheduled", "Provisioned"]

  service!: { type: string, name: string }
  isLoading: boolean = false;
  loadDataSub$!: Subscription;
  addForcastSub$!: Subscription;
  constructor(private forecastService: ForcastingService, private eventBusService: EventBusService, private alertUtil:AlertUtility) { }

  ngOnInit(): void {
    this.loadListOfValues();
    this.createForm(this.getDefaultForecastData())
  }
  loadListOfValues() {
    const pIndustries = this.forecastService.getListOfValues("industry");
    const pHeadquarters = this.forecastService.getListOfValues("customerHq");
    const pInfraLocations = this.forecastService.getListOfValues("infraLocation");
    const pServiceTypes = this.forecastService.getListOfValues("requiredServices");
    const pCloudList = this.forecastService.getListOfValues("cloudProvider");
    const pStatus = this.forecastService.getListOfValues("status");
    const pCategories = this.forecastService.getForecastCategory("all");
    this.isLoading = true;
    this.loadDataSub$ = forkJoin([pIndustries, pHeadquarters, pInfraLocations, pServiceTypes, pCloudList, pStatus, pCategories]).subscribe(values => {
      this.industries = values[0] as { tid: string, name: string }[]
      this.headQuarters = values[1] as { tid: string, name: string }[]
      this.infraLocations = values[2] as { tid: string, name: string }[]
      this.serviceTypes = values[3] as { id: string, name: string }[]
      this.cloudList = values[4] as { id: string, name: string }[]
      this.statusList = values[5] as { id: string, name: string }[]
      this.categoryies = values[6] as { name: string, subCategories: { name: string, key: string }[] }[]
      this.isLoading = false;
      // this.createForm(this.getDefaultForecastData())
    }, (error) => {
      this.alertUtil.notifyToast(error.message, "error")
      this.isLoading = false
      // console.log(error)
      // this.isLoading = false;
    });
  }
  setSubCategories(event: any) {
    const cat = this.categoryies.find(c => c.name === event.target.value)
    this.subCategories = cat?.subCategories || []

    // const subCategories = new FormGroup({})
    this.subCategories.forEach(sg => {
      const fg: FormGroup = this.frmAddForecast.get('subCategories') as FormGroup;
      fg.addControl(sg.key, new FormControl(0, [Validators.required]))
    })
  }
  getDefaultForecastData(): any {
    return { category: "", "clientName": "", "revenue": "", "industry": "", "customerHeadquarter": "", "infraLocation": "", "cloudProviders": "", "requiredServices": "", "o365": false, "expectedNoOfTickets": "", "requiredOnboardingDate": "", "contactInfo": { "tenantAdminName": "", "email": "", "mobile": "", "mspAccountOwnerName": "", "trianzRelationshipManager": "" }, "status": "New Request", "expectedAvailabilityDate": "", "approverContact": "" }
  }
  createForm(forecast: any) {
    this.frmAddForecast = new FormGroup({
      category: new FormControl(forecast.infraLocation, [Validators.required]),
      subCategories: new FormGroup({}),
      clientName: new FormControl(forecast.category, [Validators.required, NoWhitespaceValidator.isValid(), Validators.maxLength(100), InvalidCharactersValidator.isValid()]),
      revenue: new FormControl(forecast.revenue, [Validators.required]),
      industry: new FormControl(forecast.industry, [Validators.required]),
      customerHeadquarter: new FormControl(forecast.customerHeadquarter, [Validators.required]),
      infraLocation: new FormControl(forecast.infraLocation, [Validators.required]),
      cloudProviders: new FormControl(forecast.cloudProviders, [Validators.required]),
      requiredServices: new FormControl(forecast.requiredServices, [Validators.required]),
      o365: new FormControl(forecast.o365, [Validators.required]),
      expectedNoOfTickets: new FormControl(forecast.expectedNoOfTickets, [Validators.required]),
      // noOfVMs: new FormControl(forecast.noOfVMs, [Validators.required]),
      requiredOnboardingDate: new FormControl(forecast.requiredOnboardingDate, [Validators.required, NoWhitespaceValidator.isValid(), Validators.maxLength(100)]),
      contactInfo: new FormGroup({
        tenantAdminName: new FormControl(forecast.contactInfo.tenantAdminName, [Validators.required, NoWhitespaceValidator.isValid(), Validators.maxLength(100), InvalidCharactersValidator.isValid()]),
        email: new FormControl(forecast.contactInfo.email, [Validators.required, EmailValidator.isValid()]),
        mobile: new FormControl(forecast.contactInfo.mobile, [Validators.required, MobileNumberValidator.isValid()]),
        mspAccountOwnerName: new FormControl(forecast.contactInfo.mspAccountOwnerName, [Validators.required, NoWhitespaceValidator.isValid(), Validators.maxLength(100), InvalidCharactersValidator.isValid()]),
        trianzRelationshipManager: new FormControl(forecast.contactInfo.trianzRelationshipManager, [Validators.required, NoWhitespaceValidator.isValid(), Validators.maxLength(100), InvalidCharactersValidator.isValid()]),
      }),
      status: new FormControl(forecast.status, [Validators.required]),
      expectedAvailabilityDate: new FormControl(forecast.expectedAvailabilityDate, [Validators.required]),
      approverContact: new FormControl(forecast.approverContact, [Validators.required, NoWhitespaceValidator.isValid(), Validators.maxLength(100)]),
    })

  }
  selectionChange(option: any) { }

  onForecastSubmit() {
    this.isLoading = true
    this.addForcastSub$ = this.forecastService.createForecast(this.frmAddForecast.value).subscribe((resp: any) => {
      this.isLoading = false;
      this.alertUtil.showAlert("success", `${resp.response.message}!`)
      this.eventBusService.emit({ name: Events.ForecastAdded })
      this.eventBusService.emit({ name: Events.HideModelPopup })
    }, (error: any) => {
      this.isLoading = false
      this.alertUtil.showAlert("error", error.error.message || `Sorry for the inconvenience!<br> Please re-check the inputs before submission.`)
      console.log(error);
    });
  }

  reset() {
    this.frmAddForecast.reset()
    this.createForm(this.getDefaultForecastData())
  }

  ngOnDestroy() {
    this.addForcastSub$?.unsubscribe();
    this.loadDataSub$?.unsubscribe()
  }
}
