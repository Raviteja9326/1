import { Component, OnInit } from '@angular/core';
import { Events } from 'src/app/models/app.enums';
import { EventBusService } from '../../shared/event-bus.service';
import { Popups } from 'src/app/modules/shared/popup/popup-mapper';
import { AuthenticationService } from '../../authentication/authentication.service';
import { CommonUtilService } from '../../utils/common-util.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentrealm :any
  constructor(private eventBusService: EventBusService, private authService: AuthenticationService, private util: CommonUtilService) {
    this.currentrealm = this.util.extractUrlValue("realm", decodeURIComponent(location.href)) || environment.endpoints.keyCloak.defaultRealm
  }

  ngOnInit(): void {
  }
  addForecast() {
    const realm: string = this.authService.getRealm()
    // const realm: string = "aws"
    if (realm.toLowerCase() === "aws")
      this.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.AddDynamicForecast, title: "Add Forecast", value: "3" } })
    else
      this.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.AddForecast, title: "Add Forecast", value: "3" } })
  }

}
