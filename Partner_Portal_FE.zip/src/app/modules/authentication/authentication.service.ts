import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Authentication } from 'src/app/models/authentication.model';
import { KeyContacts, updateContacts } from 'src/app/models/key-contacts.model';
import { MakeRequest } from 'src/app/models/make-request.model';
import { ApiService } from '../shared/api.service';
import jwt_decode from 'jwt-decode';
import { SweetAlertIcon } from 'sweetalert2';
import { appConfig } from 'src/app/app.config';
import { Events, Platform } from 'src/app/models/app.enums';
import { EventBusService } from '../shared/event-bus.service';
import { environment } from 'src/environments/environment';
import axios from 'axios';
import { CommonUtilService } from '../utils/common-util.service';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { KeycloakService } from 'keycloak-angular';
import { AlertUtility } from '../utils/alert.util';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  invalidateOthersSession() {
    const realm = this.getRealm()
    const url = `${environment.endpoints.concierto}iam/idp-User/invalidateOtherSessions`;
    return this.http.post(url, { realm }, { observe: 'response' }).pipe(
      map((response: any) => response));
  }
  checkPortalLoggedin() {
    const userInfo = this.getLoggedinUserDetails();
    return userInfo.id ? true : false
  }
  checkKeycloakLoggedin() {
    return parseInt(localStorage.getItem("loggedin") || "0") ? true : false
  }

  private _keycloakConfig: any;
  isLoggedin: boolean = false;
  async getKeycloakConfig() {
    if (this._keycloakConfig) return this._keycloakConfig
    return await this.getAuthServer(this.getRealm())
      .then((resp: any) => {
        if (!resp) {
          this.alertUtil.showAlert("error", "IAM server is down.<br> Please try after sometime.");
          return
        }
        const config = {
          url: resp.url,
          realm: this.getRealm(),
          clientId: environment.endpoints.keyCloak.clientId,
          redirectUri: environment.endpoints.keyCloak.redirectUri + this.getRealm()
        }
        this.setKeyclockConfig(config)
        return config
      })
      .catch(error => {
        this.alertUtil.showAlert("error", "IAM server is down.<br> Please try after sometime.")
      })
  }
  setKeyclockConfig(config: any) {
    this._keycloakConfig = config
  }
  getAuthServer(realm: string) {
    const url = `${environment.endpoints.concierto}iam/realm-manager/findOneByName/${realm}`;
    return axios.get(url).then((res: any) => {
      return {
        url: res.data.configData['auth-server-url'],
      }
    }).catch((err) => {
      console.log(err);
    });
  }
  getRealm() {
    return this.util.extractUrlValue("realm", decodeURIComponent(location.href)) || environment.endpoints.keyCloak.defaultRealm
  }
  authToken: string;
  // refreshTime = 1000;
  auth: Authentication = { userName: "", password: "", realm: "" };
  mr: MakeRequest = { type: "", title: "", body: "" };
  cc: KeyContacts = { name: "", title: "", email: "", mobile: "", region: "", photo: "" };
  uc: updateContacts = { id: "", name: "", title: "", email: "", mobile: "", region: "", photo: "", log: "" };
  isLoggedIn: boolean = false;

  constructor(
    private apiService: ApiService,
    private eventService: EventBusService,
    private util: CommonUtilService,
    private alertUtil: AlertUtility,
    private http: HttpClient,
    private keycloak: KeycloakService) {
    this.authToken = localStorage.getItem("drupal-login-info") || "";
  }
  isQuestionAlertShown: boolean = false;
  // logout() {
  //   localStorage.clear();
  // }

  login(auth: Authentication): Observable<any> {
    this.auth = auth;
    return this.apiService.login(this.auth)
  }

  storeUserInfo(userData: any) {
    this.authToken = JSON.stringify(userData);
    localStorage.setItem("authToken", this.authToken)
  }

  getTokenInfo(access_token: any) {
    if (!access_token) return
    this.authToken = access_token;
    const token = JSON.parse(atob(access_token.split('.')[1]));
    return {
      duration: token.exp - token.iat,
      timePassed: Date.now() / 1000 - token.iat
    }
  }

  isRefreshing: any = { drupal: false, concierto: false }
  generateRefreshToken(platform: string) {
    if (this.isRefreshing[platform]) return
    this.isRefreshing[platform] = true
    const loginInfo: any = this.util.getLocalStorage(appConfig[platform].storageKeys.loginInfo)
    // this.generateDrupalRefreshToken(loginInfo, platform);
    if (platform === Platform.Drupal) {
      this.generateDrupalRefreshToken(loginInfo, platform);
    }
    else {
      this.generateConciertoRefreshToken(loginInfo, platform);
    }
  }

  private generateDrupalRefreshToken(loginInfo: any, platform: string) {
    const header: any = {
      Authorization: `Bearer ${loginInfo[appConfig[platform].storageKeys.accessToken]}`,
      csrf_token: loginInfo[appConfig[platform].storageKeys.csrfToken]
    }
    const startAt = new Date().getTime();
    console.log(`At ${new Date().toLocaleTimeString()}: ${platform.toUpperCase()} token updating`)
    this.usergenerateDrupalRefreshToken(header).then((resp: any) => {
      if (resp?.status === 200) {
        loginInfo[appConfig[platform].storageKeys.accessToken] = resp?.data?.token;
        this.handleSuccess(platform, loginInfo, startAt);
      }
      else {
        this.handleFailure(platform);
      }
    }).catch((err: any) => {
      this.handleFailure(platform);
    });
  }
  private generateConciertoRefreshToken(loginInfo: any, platform: string) {
    this.keycloak.updateToken(3600).then(refreshed => {
      const startAt = new Date().getTime();
      if (refreshed) {
        const kc: any = Object.assign({}, this.keycloak)
        // console.log(kc._instance.token)
        loginInfo[appConfig.concierto.storageKeys.accessToken] = kc._instance.token;
        this.handleSuccess(platform, loginInfo, startAt);
      }
    })
  }

  usergenerateDrupalRefreshToken(headers: any) {
    // const url = `${environment.middlewareApi}token`
    const url = `${environment.endpoints.drupal}jwt/token`

    const options = {
      headers: headers
    }
    return axios.get(url, options).then((res) => {
      return res;
    }).catch((err) => {
      console.log(err);
    });
  }

  private handleSuccess(platform: string, loginInfo: any, startAt: number) {
    this.util.setLocalStorage(appConfig[platform].storageKeys.loginInfo, loginInfo);
    this.isRefreshing[platform] = false;
    // console.log(`Updating ${platform.toUpperCase()} token took ${(new Date().getTime() - startAt) / 1000} Sec`);
    this.eventService.emit({ name: Events.tokenLife, value: { platform: platform, accessToken: loginInfo[appConfig[platform].storageKeys.accessToken] } });
  }

  private handleFailure(platform: string) {
    // if (this.util.getLocalStorage(appConfig.storageKeys.reloading) > appConfig.maxReloadingCount)
    //   this.util.setLocalStorage(appConfig.storageKeys.reloading, 0)
    this.showSessionExpiryPopup();
    this.isRefreshing[platform] = false;
    console.log(`At ${new Date().toLocaleTimeString()}: ${platform.toUpperCase()} token error`);
  }

  showSessionExpiryPopup() {
    this.eventService.emit({ name: "session-out" })
  }

  getLoggedinUserDetails() {
    const drupalLoginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo)
    // const profileInfo = localStorage.getItem("profileInfo") || "{}"
    // return JSON.parse(profileInfo)
    return drupalLoginInfo.profile || {}
  }
  notifyToast(messenger: any, icon: SweetAlertIcon = "info") {
    messenger = messenger.message || messenger;
    // this.Toast.fire({
    //   icon: icon,
    //   title: messenger
    // })
    switch (icon) {
      case "error": {
        if (messenger?.toLowerCase().includes('expired'))
          this.eventService.emit({ name: Events.SessionOut })
        console.error(`At ${new Date().toLocaleTimeString()}: ${messenger}`);
        break
      }
      default: { console.info(`At ${new Date().toLocaleTimeString()}: ${messenger}`); break }
    }

  }

  isTokenValid() {
    return this.authToken ? true : false;
    // try {
    //   return JSON.parse(atob(token.split('.')[1]));
    // } catch (e) {
    //   return null;
    // }
  }

  makeRequest(mr: MakeRequest): Observable<any> {
    this.mr = mr;
    return this.apiService.makeRequest(this.mr);
  }

  getKeyContacts(): Observable<any> {
    return this.apiService.getKeyContacts();
  }

  createContacts(cc: KeyContacts): Observable<any> {
    this.cc = cc;
    return this.apiService.createContacts(this.cc);
  }

  updateContacts(uc: updateContacts): Observable<any> {
    this.uc = uc;
    return this.apiService.updateContacts(this.uc);
  }

  getMyRequest(): Observable<any> {
    return this.apiService.getMyRequest();
  }
  getToken() {
    if (this.authToken) {
      let auth = JSON.parse(this.authToken)
      return auth.access_token
    }
  }
  getTokenExpirationDate(token: string): any {
    token = this.getToken()
    const decoded: any = jwt_decode(token);
    if (decoded.exp === undefined) return null;
    const date = new Date(0);
    date.setUTCSeconds(decoded.exp);
    return date;
  }

  isTokenExpired(token?: string): boolean {
    if (!token) token = this.getToken();
    if (!token) return true;
    const date = this.getTokenExpirationDate(token);
    if (date === undefined) return false;
    return !(date.valueOf() > new Date().valueOf());
  }

  isEmptyObject(obj: any) {
    if (!obj) return;
    return !Object.keys(obj)?.length;
  }

  // isPermitted(permittedRoles: string[]) {
  //   const roles = this.util.intersectArray(permittedRoles, this.getLoggedinUserDetails().role || []);
  //   return roles.length;
  // }


}
