import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { appConfig } from 'src/app/app.config';
import { CommonUtilService } from '../utils/common-util.service';
import { map } from 'rxjs/operators';
import { of } from 'rxjs';
import { FeatureList } from 'src/app/models/app.enums';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {
  checkIfAdmin(adminActions: any, _access: any): boolean {
    let isAdmin: boolean = false
    if (!_access || !adminActions) return isAdmin;
    Object.keys(adminActions).forEach(key => {
      adminActions[key].forEach((action: string) => {
        if (_access[key]?.[action] && !isAdmin) {
          isAdmin = true;
        }
      });
    });
    return isAdmin
  }

  getPermittedFeatures() {
    // const aws = [FeatureList.MyDealsAWS, FeatureList.OpportunitySnapshot, FeatureList.SalesPipeline]
    // const others = [FeatureList.NewsCarousel, FeatureList.MyDealsCommon]
    // return of(aws)
    const url = `${environment.endpoints.drupal}api/csContentPermission`;
    return this.http.get(url).pipe(
      map((response: any) => response));
  }

  isAuthorizedFeature(featureName: string) {
    const permittedFeatures: string[] = this.util.getLocalStorage(appConfig.storageKeys.permittedFeatures, "array")
    return permittedFeatures.some(feature => feature.toLowerCase().includes(featureName.toLowerCase()))
  }

  constructor(private authenticator: AuthenticationService, private http: HttpClient, private util: CommonUtilService) { }
  isAuthorized(featureName: string, permission: string) {
    // console.log(`feature ${featureName}, Permission: ${permission}`)
    const userInfo: any = this.authenticator.getLoggedinUserDetails();
    return userInfo?._access?.[featureName]?.[permission] === 1 || false;
  }
}
