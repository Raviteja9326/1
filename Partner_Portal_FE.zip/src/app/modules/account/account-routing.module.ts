import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AccountInfoComponent } from './account-info/account-info.component';
// import { ContractsComponent } from './contracts/contracts.component';
// import { InvoicingComponent } from './invoicing/invoicing.component';

export const accountRoutes: Routes = [
  {path : 'forgot-password', component : ForgotPasswordComponent},
  {path : 'account-info', component : AccountInfoComponent},
]

@NgModule({
  imports: [RouterModule.forChild(accountRoutes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
