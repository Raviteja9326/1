import { Component, EventEmitter, OnInit, Output } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Subscription } from "rxjs/internal/Subscription";
import { HOW_HEARD_ABOUT_US_LISTING, INFRA_ENVIRONMENT_DETAILS, PARTNER_TYPE, PRODUCT_INTERESTED_IN } from "src/app/app.config";

import { PartnerDetails } from "src/app/models/partner-portal-access.model";
import { ApiService } from "../../shared/api.service";
import { NameValidator } from "../../validation/validators/name-validator";
import { EmailValidator } from "../../validation/validators/email-validator";
import { UrlValidator } from "../../validation/validators/url-validator";
import { MobileNumberValidator } from "../../validation/validators/mobile-number-validator";
import { ZipcodeValidator } from "../../validation/validators/zipcode-validator";
import { Events } from "src/app/models/app.enums";
import { EventBusService } from "../../shared/event-bus.service";
import { Popups } from "../../shared/popup/popup-mapper";
declare var $: any;
@Component({
  selector: "app-partner-portal-access",
  templateUrl: "./partner-portal-access.component.html",
  styleUrls: ["./partner-portal-access.component.scss"],
})
export class PartnerPortalAccessComponent implements OnInit {
  @Output() closePartnerReqModal = new EventEmitter<any>();
  $: any;
  // isOtherSelected:boolean=false;
  countryList: any;
  stateList: any = [];
  cityList: any = [];
  selectedCountry!: string;
  selectedState!: string;
  selectedCity!: string;
  infraEnvironmentDetail = INFRA_ENVIRONMENT_DETAILS
  infraSelected!: any
  howHeardAboutListing: any = HOW_HEARD_ABOUT_US_LISTING;
  productInterestedIn: any = PRODUCT_INTERESTED_IN
  productSelected!: any
  partnerType: any = PARTNER_TYPE
  partnerSelected!: any
  partnerPortalSubmissionForm!: FormGroup;
  isLoading: boolean = false;
  isOtherPartnerType:boolean=false;
  isOtherInfraType:boolean=false;
  public countryListSubscription$!: Subscription;
  public stateListSubscription$!: Subscription;
  public cityListSubscription$!: Subscription;
  public requestSubmissionSubscription$!: Subscription;
  constructor(private fb: FormBuilder, private apiService: ApiService, private eventBusService: EventBusService) { }

  ngOnInit(): void {
    // $("#partnerAccess").modal("show");
    this.countryListSubscription$ = this.apiService
      .getCountryList()
      .subscribe((list) => {
        this.countryList = list;
      });
    this.createForm();
  }

  public createForm() {
    this.partnerPortalSubmissionForm = this.fb.group({
      companyName: ["", [Validators.required,NameValidator.isValid()]],
      businessEmail: ["", [Validators.required, EmailValidator.isValid()]],
      website: ["", [UrlValidator.isValid(),Validators.required]],
      firstName: ["", [Validators.required, NameValidator.isValid()]],
      lastName: ["", [Validators.required, NameValidator.isValid()]],
      jobTitle: ["", [Validators.required]],
      phoneNo: ["", [Validators.required, MobileNumberValidator.isValid()]],
      partnerType: ["", [Validators.required]],
      partnerTypeOther:[""],
      productInterestedIn: [""],
      country: ["", [Validators.required]],
      state: [{ value: "", disabled: true }, [Validators.required]],
      city: [{ value: "", disabled: true }, [Validators.required]],
      zipcode: ["", [Validators.required, ZipcodeValidator.isValid()],],
      hear_from: [""],
      aceIP: [""],
      annualRevenu: ["",[Validators.required]],
      addtionalComment: [""],
      // addtionalDetail: [""],
      noOfEmp: ["",[Validators.required]],
      infraEnvironmentDetail: ["",[Validators.required]],
      infraEnvironmentDetailOther:[""]
    });
    this.partnerPortalSubmissionForm.get('infraEnvironmentDetail')?.valueChanges.subscribe(value => {
      this.isOtherInfraType= value == 'Other(Please Provide Details)';
      
    });
    this.partnerPortalSubmissionForm.get('partnerType')?.valueChanges.subscribe(value => {
      this.isOtherPartnerType= value == 'Other(Please Provide Details)';
      
    });
  }

  public submitRequest() {
    const partnerDetails: any = {
      companyName: this.partnerPortalSubmissionForm.controls["companyName"].value,
      mail: this.partnerPortalSubmissionForm.controls["businessEmail"].value,
      website: this.partnerPortalSubmissionForm.controls["website"].value,
      fname: this.partnerPortalSubmissionForm.controls["firstName"].value,
      lname: this.partnerPortalSubmissionForm.controls["lastName"].value,
      jobTitle: this.partnerPortalSubmissionForm.controls["jobTitle"].value,
      phone: this.partnerPortalSubmissionForm.controls["phoneNo"].value,
      partnerType: this.partnerSelected,
      partnerTypeOther:this.partnerPortalSubmissionForm.controls["partnerTypeOther"].value,
      productInterestedIn: this.productSelected,
      country: this.selectedCountry,
      state: this.selectedState,
      city: this.partnerPortalSubmissionForm.controls["city"].value,
      zip: this.partnerPortalSubmissionForm.controls["zipcode"].value,
      hear_from: this.partnerPortalSubmissionForm.controls["hear_from"].value,
      aceIP: this.partnerPortalSubmissionForm.controls["aceIP"].value,
      annualRevenu: this.partnerPortalSubmissionForm.controls["annualRevenu"].value,
      addtionalComment: this.partnerPortalSubmissionForm.controls["addtionalComment"].value,
      // addtionalDetail: this.partnerPortalSubmissionForm.controls["addtionalDetail"].value,
      noOfEmp: this.partnerPortalSubmissionForm.controls["noOfEmp"].value,
      infraEnvironmentDetail: this.infraSelected,
      infraEnvironmentDetailOther:this.partnerPortalSubmissionForm.controls["infraEnvironmentDetailOther"].value
    };
    this.postPartnerDetails(partnerDetails);
  }

  public postPartnerDetails(partnerDetails: any) {
    this.isLoading = true;
    this.requestSubmissionSubscription$ = this.apiService
      .submitPartnerRequest(partnerDetails)
      .subscribe(
        (resp: any) => {
          // login successful so redirect to return url
          this.isLoading = false;

          // $("#partnerAccess").modal("hide");

          // this.closePartnerReqModal.emit();
          // this.eventBusService.emit({ name: Events.HideModelPopup });
          this.showSuccessMessage()
          // $("#successAlertBox").modal("show");
        },
        (error: any) => {
          this.isLoading = false;
        }
      );
  }
  showSuccessMessage() {


    this.eventBusService.emit({ name: Events.HideModelPopup })
    setTimeout(() => {
      this.eventBusService.emit({
        name: Events.ShowModalPopup,
        value: {
          modalId: Popups.SuccessMessage,
          alignment: 'center',
          title: "Success",
        }
      })
    }, 100);
    // this.showPartnerPortalAccessModal = true;

    //  $("#partnerAccess").modal("hide");
  }
  public closeRequestSubmissionModal() {
    // $("#partnerAccess").modal("hide");
    // $("#successAlertBox").modal("hide");
    // this.showsuccessAlertBox=false;
    this.closePartnerReqModal.emit();
  }

  public countrySelection(selectedCountry: any) {
    this.selectedCountry = selectedCountry.name;
    this.getStateList(selectedCountry.iso2);
  }
  public partnerTypeSelection(partnerType: any) {
    this.partnerSelected = partnerType
    
   
  }
  public productInterestedInSelection(productInterestedIn: any) {
    this.productSelected = productInterestedIn
  }
  public infraEnvironmentDetailSelection(infraEnvironmentDetail: any) {
    this.infraSelected = infraEnvironmentDetail
  }

  public getStateList(countryCode: string) {
    let allStateList: any;
    this.stateListSubscription$ = this.apiService
      .getStateList()
      .subscribe((list) => {
        allStateList = list;
        this.stateList = allStateList.filter(
          (list: any) => list.country_code === countryCode
        );
        if (this.stateList.length === 0) {
          this.stateList.push({ name: this.selectedCountry });
        }

      });
    this.partnerPortalSubmissionForm.controls["state"].enable();
  }

  public stateSelection(selectedState: any) {
    this.getCityList(selectedState.state_code, selectedState.country_code);
    this.selectedState = selectedState.name;
  }

  public getCityList(stateCode: string, countryCode: string) {
    let allCityList: any;
    this.stateListSubscription$ = this.apiService
      .getCityList()
      .subscribe((list) => {
        allCityList = list;
        this.cityList = allCityList.filter(
          (list: any) =>
            list.state_code === stateCode && list.country_code === countryCode
        );
      });
    this.partnerPortalSubmissionForm.controls["city"].enable();
  }

  public citySelection(selectedCity: any) {
    this.selectedCity = selectedCity.name;
  }
  // onRadioChange(value: string) {
  //   this.isOtherSelected = value === 'Other';
  // }
  ngOnDestroy() {
    this.countryListSubscription$?.unsubscribe();
    this.stateListSubscription$?.unsubscribe();
    this.cityListSubscription$?.unsubscribe();
    this.requestSubmissionSubscription$?.unsubscribe();
  }
}
