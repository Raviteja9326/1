import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerPortalAccessComponent } from './partner-portal-access.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

describe('PartnerPortalAccessComponent', () => {
  let component: PartnerPortalAccessComponent;
  let fixture: ComponentFixture<PartnerPortalAccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PartnerPortalAccessComponent ],
      imports:[ReactiveFormsModule, HttpClientModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerPortalAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
