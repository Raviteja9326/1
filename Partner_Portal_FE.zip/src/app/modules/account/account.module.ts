import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { AccountRoutingModule } from './account-routing.module';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AccountInfoComponent } from './account-info/account-info.component';
// import { ContractsComponent } from './contracts/contracts.component';
// import { InvoicingComponent } from './invoicing/invoicing.component';
import { DirectivesModule } from '../directives/directives.module';
import { MaterialModule } from '../shared/material/material.module';

@NgModule({
  declarations: [
    ForgotPasswordComponent,
    AccountInfoComponent,
    // ContractsComponent,
    // InvoicingComponent,
  ],
  imports: [
    CommonModule,
    AccountRoutingModule,
    SharedModule,
    DirectivesModule,
    MaterialModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class AccountModule { }
