import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UpdatesTreeComponent } from './updates-tree/updates-tree.component';

export const productUpdatesRoutes: Routes = [
  {
    path: "",
    component: UpdatesTreeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(productUpdatesRoutes)],
  exports: [RouterModule]
})
export class ProductUpdatesRoutingModule { }
