export enum ProductUpdateEvent {
  View = "view",
  Add = "add",
  Edit = "edit",
  Delete = "delete",
  Nothing = "nothing"
}
