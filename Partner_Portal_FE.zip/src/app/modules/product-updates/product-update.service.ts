import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import moment from 'moment';
import { map } from 'rxjs/operators';
import { SortingDirection } from 'src/app/models/app.enums';
import { environment } from 'src/environments/environment';
import { CommonUtilService } from '../utils/common-util.service';
import { ProductUpdate } from './models/product-update.model';
import { UpdateGroup } from './models/update-group.model';

@Injectable({
  providedIn: 'root'
})
export class ProductUpdateService {

  constructor(private http: HttpClient, private util: CommonUtilService) { }

  doProductUpdate(payload: { id: string | undefined; title: any; description: any; category: any; }) {
    const url = `${environment.endpoints.drupal}api/csUpdateProductUpdates/${payload.id}`
    return this.http.put(url, payload).pipe(
      map((response: any) => response));
  }
  getProductUpdateCategories() {
    const url = `${environment.endpoints.drupal}api/csShowProductCat`;
    return this.http.get(url).pipe(
      map((response: any) => response));
  }
  deleteProductUpdates(id: any) {
    const url = `${environment.endpoints.drupal}api/csDeleteProductUpdates/${id}`
    return this.http.delete(url).pipe(
      map((response: any) => response));
  }
  addProductUpdate(payload: { title: any; description: any; category: any; }) {
    const url = `${environment.endpoints.drupal}api/csCreateProductUpdates`
    return this.http.post(url, payload).pipe(
      map((response: any) => response));
  }
  // getStaticProductUpdate(category: string) {
  //   return this.http.get(`assets/data/product-${category}.json`);
  // }
  getProductUpdates(id: number) {
    const url = `${environment.endpoints.drupal}api/csShowProductUpdatesn/${id}`;
    return this.http.get(url).pipe(
      map((response: any) => response));
    // else return this.getStaticProductUpdate(id)
  }
  getProductUpdateGroup(id: number) {
    return this.getProductUpdates(id).pipe(
      map((response: any) => this.getProductGroups(response))
    );
  }
  getProductGroups(productUpdates: ProductUpdate[]): UpdateGroup[] {
    if (!productUpdates) return [];
    productUpdates.forEach((update: ProductUpdate) => {
      update.customDate = moment(update.date).format("YYYY-MM-DD")
    })
    const result = productUpdates.reduce(function (r, a) {
      if (a.customDate) {
        r[a.customDate] = r[a.customDate] || [];
        r[a.customDate].push(a);
      }
      return r;
    }, Object.create(null));

    const groups: UpdateGroup[] = []
    Object.keys(result).forEach((key: string) => {
      groups.push({
        date: key,
        updates: result[key]
      })
    })
    const updateGroups: UpdateGroup[] = this.util.sort(groups, "date", SortingDirection.Descending) as UpdateGroup[]
    return updateGroups;
  }
}
