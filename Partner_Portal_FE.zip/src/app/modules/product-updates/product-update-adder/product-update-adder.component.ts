import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { appConfig, maxLengthValidator } from 'src/app/app.config';
import { AlertUtility } from '../../utils/alert.util';
import { ProductUpdate } from '../models/product-update.model';
import { ProductUpdateService } from '../product-update.service';
import { Events } from 'src/app/models/app.enums';
import { EventBusService } from '../../shared/event-bus.service';
import { InvalidCharactersValidator } from '../../validation/validators/invalid-characters-validator';
import { NoWhitespaceValidator } from '../../validation/validators/no-whitespace-validator';

@Component({
  selector: 'app-product-update-adder',
  templateUrl: './product-update-adder.component.html',
  styleUrls: ['./product-update-adder.component.scss']
})
export class ProductUpdateAdderComponent implements OnInit {
  @Input() productUpdateTypeId!: number;
  @Input() parentScope: any
  isLoading: boolean = false
  appConfig = appConfig
  frmProductUpdateAdder!: FormGroup
  addProductUpdateSubscription$!: Subscription;
  categoriesSubscription$!: Subscription;
  productUpdateCategories!: { category: string, name: string }[];

  constructor(
    private fb: FormBuilder,
    private productUpdateService: ProductUpdateService,
    private alertUtil: AlertUtility,
    private eventBusService: EventBusService) { }

  ngOnInit(): void {
    this.getCategories();
    this.createForm()
  }
  getCategories() {
    this.isLoading = true
    this.categoriesSubscription$ = this.productUpdateService.getProductUpdateCategories().subscribe((resp: any) => {
      this.productUpdateCategories = resp;
      this.isLoading = false;
    }, (error: any) => {
      this.isLoading = false;
      console.log(error)
    });
  }
  createForm() {
    this.frmProductUpdateAdder = this.fb.group({
      title: ['', [
        Validators.required,
        NoWhitespaceValidator.isValid(),
        Validators.maxLength(appConfig.textMaxLength.sm),
        InvalidCharactersValidator.isValid()
      ]],
      description: ['', maxLengthValidator.multiLine],
      category: ['']
    })
  }
  addProductUpdate(controls: any) {
    this.isLoading = true;
    const payload = {
      type: this.productUpdateTypeId,
      title: controls['title'].value.trim(),
      description: controls['description'].value.trim(),
      category: controls['category'].value || null
    }
    this.addProductUpdateSubscription$ = this.productUpdateService.addProductUpdate(payload).subscribe((resp: any) => {
      this.alertUtil.showAlert("success", resp?.message);
      const productUpdate: ProductUpdate = resp.data;
      const productUpdateCategory: any = this.productUpdateCategories.filter(cat => cat.category === productUpdate.category)
      productUpdate.category = productUpdateCategory.length ? productUpdateCategory[0].name : ""
      this.eventBusService.emit({ name: Events.HideModelPopup })
      this.parentScope.AddProductUpdate(this.parentScope, productUpdate)
      this.isLoading = false;
    }, (error: any) => {
      this.isLoading = false;
      this.alertUtil.showAlert("error", error.error.message || `Sorry for the inconvenience!<br> Please re-check the inputs before submission.`)
    });
  }

  ngOnDestroy() {
    this.categoriesSubscription$?.unsubscribe();
    this.addProductUpdateSubscription$?.unsubscribe();
  }

}
