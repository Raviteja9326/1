import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductUpdateAdderComponent } from './product-update-adder.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

describe('ProductUpdateAdderComponent', () => {
  let component: ProductUpdateAdderComponent;
  let fixture: ComponentFixture<ProductUpdateAdderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductUpdateAdderComponent ],
      imports:[ReactiveFormsModule, HttpClientModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductUpdateAdderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
