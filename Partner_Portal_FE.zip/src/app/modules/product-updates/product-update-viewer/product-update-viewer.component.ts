import { Component, Input, OnInit } from '@angular/core';
import { ProductUpdate } from '../models/product-update.model';

@Component({
  selector: 'app-product-update-viewer',
  templateUrl: './product-update-viewer.component.html',
  styleUrls: ['./product-update-viewer.component.scss']
})
export class ProductUpdateViewerComponent implements OnInit {
  @Input() selectedUpdate!: ProductUpdate;
  constructor() { }

  ngOnInit(): void {
  }

}
