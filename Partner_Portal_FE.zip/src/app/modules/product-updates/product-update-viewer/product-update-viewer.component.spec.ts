import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductUpdateViewerComponent } from './product-update-viewer.component';

describe('ProductUpdateViewerComponent', () => {
  let component: ProductUpdateViewerComponent;
  let fixture: ComponentFixture<ProductUpdateViewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductUpdateViewerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductUpdateViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
