import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AllUpdatesComponent } from './all-updates/all-updates.component';
import { ProductUpdatesRoutingModule } from './product-updates-routing.module';
import { UpdatesTreeComponent } from './updates-tree/updates-tree.component';
import { UpdateGroupComponent } from './updates-tree/update-group/update-group.component';
import { ProductUpdateComponent } from './updates-tree/update-group/product-update/product-update.component';
import { DirectivesModule } from '../directives/directives.module';
import { UpdateListingComponent } from './update-listing/update-listing.component';
import { MaterialModule } from '../shared/material/material.module';
import { ProductUpdateViewerComponent } from './product-update-viewer/product-update-viewer.component';
import { ProductUpdateAdderComponent } from './product-update-adder/product-update-adder.component';
import { ProductUpdateUpdaterComponent } from './product-update-updater/product-update-updater.component';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AllUpdatesComponent,
    UpdatesTreeComponent,
    UpdateGroupComponent,
    ProductUpdateComponent,
    UpdateListingComponent,
    ProductUpdateViewerComponent,
    ProductUpdateAdderComponent,
    ProductUpdateUpdaterComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    ProductUpdatesRoutingModule,
    DirectivesModule,
    MaterialModule,
    ReactiveFormsModule
  ],
  exports:[
    AllUpdatesComponent,
    UpdateListingComponent,
    ProductUpdateViewerComponent,
    ProductUpdateAdderComponent,
    ProductUpdateUpdaterComponent
  ]
  ,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class ProductUpdatesModule { }
