import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductUpdate } from '../../../models/product-update.model';

@Component({
  selector: 'app-product-update',
  templateUrl: './product-update.component.html',
  styleUrls: ['./product-update.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductUpdateComponent implements OnInit {

  @Input() productUpdate!: ProductUpdate;
  // isViewable: boolean = false;
  constructor(private route: ActivatedRoute, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
  }
  ngAfterViewInit() {
    this.cdr.markForCheck();
    const id = this.route.snapshot.paramMap.get('id') ?? -1;
    if (id != -1)
      setTimeout(() => {
        const elem: HTMLElement | null = document.querySelector(`#update${id}`) || null;
        if (elem) {
          const productUpdate: HTMLElement | null = elem.closest('.product-updates');
          productUpdate?.classList.add('highlight');
          productUpdate?.setAttribute("tabindex", "0");
          productUpdate?.focus();
        }
      }, 100);
  }
}

