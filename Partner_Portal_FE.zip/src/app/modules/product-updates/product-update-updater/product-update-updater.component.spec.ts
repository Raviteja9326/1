import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductUpdateUpdaterComponent } from './product-update-updater.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

describe('ProductUpdateUpdaterComponent', () => {
  let component: ProductUpdateUpdaterComponent;
  let fixture: ComponentFixture<ProductUpdateUpdaterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductUpdateUpdaterComponent ],
      imports:[ReactiveFormsModule, HttpClientModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductUpdateUpdaterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
