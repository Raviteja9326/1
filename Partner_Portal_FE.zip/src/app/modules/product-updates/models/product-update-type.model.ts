export interface ProductUpdateType {
  id: number, key: string, name: string
}

