import { ProductUpdate } from "./product-update.model";

export interface UpdateGroup {
  date: string,
  updates: ProductUpdate[]
}
