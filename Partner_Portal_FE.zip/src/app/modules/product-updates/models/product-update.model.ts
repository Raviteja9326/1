export interface ProductUpdate {
  id?: string,
  title: string,
  description: string,
  color?: string,
  date?: Date,
  category?: string,
  customDate?: string,

  action?: string,
  header?: string
}
