import { TestBed } from '@angular/core/testing';

import { ProductUpdateService } from './product-update.service';
import { HttpClientModule } from '@angular/common/http';

describe('ProductUpdateService', () => {
  let service: ProductUpdateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientModule
      ]
    });
    service = TestBed.inject(ProductUpdateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
