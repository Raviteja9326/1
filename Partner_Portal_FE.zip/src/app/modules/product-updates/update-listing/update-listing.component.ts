import { Component, HostListener, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { appConfig } from 'src/app/app.config';
import { Events } from 'src/app/models/app.enums';
import { ConfirmAlertConfig } from 'src/app/models/confirm-alert-config.model';
import { ProductUpdateType } from 'src/app/modules/product-updates/models/product-update-type.model';
import { AuthenticationService } from '../../authentication/authentication.service';
import { AuthorizationService } from '../../authentication/authorization.service';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';
import { ProductUpdate } from '../models/product-update.model';
import { ProductUpdateEvent } from '../product-update.enums';
import { ProductUpdateService } from '../product-update.service';
import { productUpdateTypes } from '../product-updates.config';
import { Popups } from '../../shared/popup/popup-mapper';
declare var $: any;

@Component({
  selector: 'app-update-listing',
  templateUrl: './update-listing.component.html',
  styleUrls: ['./update-listing.component.scss']
})
export class UpdateListingComponent implements OnInit {

  @Input() isHome: boolean = false;
  isLoading: boolean = false;
  selectedUpdate!: ProductUpdate
  productUpdatesSubscription$!: Subscription;
  deleteSubscription$: any;
  clientChangeSub$: Subscription;
  isPermitted: boolean = false;

  constructor(
    private productUpdateService: ProductUpdateService,
    private router: Router,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private authService: AuthenticationService,
    private authorizer: AuthorizationService,
    private alertUtil: AlertUtility) {
    this.isLoading = true
    if (this.util.getClientId())
      this.loadProductUpdates();
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (arg: any) => {
      this.loadProductUpdates();
    });
  }

  private loadProductUpdates() {
    const feature: string = "product updates";
    const profile = this.authService.getLoggedinUserDetails();
    this.productUpdateTypes = productUpdateTypes
    this.selectedProductUpdateType = productUpdateTypes[0]

    this.isPermitted = this.authorizer.checkIfAdmin(
      { [feature]: appConfig.adminActions[feature] },
      { [feature]: profile._access[feature] }
    );
    if (!this.isPermitted)
      this.blockAccess("You dont have access to this page.");
    else
      this.getProductUpdates(this.selectedProductUpdateType);
    
  }

  private blockAccess(message: string) {
    const config = {
      icon: "error",
      title: "Sorry for any inconvenience",
      message: message,
      confirmButtonText: "Ok",
      // cancelButtonText: "Login",
      confirmButtonCallback: this.gotoHome,
      showConfirmButton: true,
      callbackParams: {
        scope: this,
        params: { value: true }
      }
    };

    this.alertUtil.showCallbackAlert(config);
  }
  gotoHome(params: any) {
    params.scope.router.navigate([`/home`], {
      queryParams: { realm: params.scope.authService.getRealm() },
    });
  }

  errortxt: string = "";
  innerWidth: any;
  productUpdates!: ProductUpdate[];
  selectedProductUpdateType!: ProductUpdateType;
  productUpdateTypes!: ProductUpdateType[]

  ngOnInit(): void {
    this.innerWidth = window.innerWidth;

  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }
  getProductUpdates(productUpdateType: ProductUpdateType) {
    this.isLoading = true;
    this.selectedProductUpdateType = productUpdateType;
    if (this.productUpdates) {
      // Reset productUpdates if it already exists
      this.productUpdates = []; // Or assign an empty array/object depending on your data structure
  }
    this.productUpdatesSubscription$ = this.productUpdateService
      .getProductUpdates(productUpdateType.id)
      .subscribe({
        next: (data: any) => {
          if (this.productUpdates) {
            // Reset productUpdates if it already exists
            this.productUpdates = []; // Or assign an empty array/object depending on your data structure
        }
          this.productUpdates = data;
        },
        error: (error: any) => {
          this.isLoading=false
          this.alertUtil.notifyToast(error.message, "error");
        },
        complete: () => {
          this.isLoading = false;
        }
      });
  }
  
  view(event: any, scope: any, productUpdate: ProductUpdate) {
    event.stopPropagation();
    scope.eventBusService.emit({
      name: Events.ShowModalPopup, value: {
        modalId: Popups.ViewProductUpdate, title: "View Product Update", alignment: 'center',
        params: [
          { key: "selectedUpdate", value: productUpdate }
        ]
      }
    })
  }
  add(event: any, scope: any = this) {
    event.stopPropagation();
    scope.eventBusService.emit({
      name: Events.ShowModalPopup, value: {
        modalId: Popups.AddProductUpdate, title: "Add new update", alignment: 'center',
        params: [
          { key: "parentScope", value: scope },
          { key: "productUpdateTypeId", value: scope.selectedProductUpdateType.id },
        ]
      }
    })
  }
  edit(event: any, scope: any, productUpdate: ProductUpdate) {
    event.stopPropagation();
    scope.eventBusService.emit({
      name: Events.ShowModalPopup, value: {
        modalId: Popups.EditProductUpdate, title: "Edit Product Update", alignment: 'center',
        params: [
          { key: "selectedUpdate", value: productUpdate },
          { key: "parentScope", value: scope }
        ]
      }
    })
  }

  delete(event: any, scope: any, productUpdate: ProductUpdate) {
    event.stopPropagation();
    const config: ConfirmAlertConfig = {
      question: "Are you sure you want to delete this update?",
      confirmButtonText: "Delete",
      callback: scope.deleteProductUpdate.bind(scope),
      callbackParams: {
        scope: scope,
        params: { id: productUpdate.id }
      }
    }
    scope.alertUtil.showConfirmAlert(config)
  }
  deleteProductUpdate(params: any) {
    params.scope.isLoading = true;
    this.deleteSubscription$ = params.scope.productUpdateService.deleteProductUpdates(params.params.id).subscribe((resp: any) => {
      params.scope.isLoading = false;
      this.alertUtil.showAlert("success", resp?.response?.message || "Deleted successfully.");
      params.scope.productUpdates = params.scope.productUpdates.filter((pu: any) => pu.id !== params.params.id)
    }, (err: any) => {
      console.error(err);
    })
  }
  AddProductUpdate(scope: any, productUpdate: ProductUpdate) {
    scope.productUpdates.unshift(productUpdate)
    scope.productUpdates = Object.assign([], scope.productUpdates);
  }
  updateProductUpdates(scope: any, productUpdate: ProductUpdate) {
    let index: number | undefined = scope.productUpdates.findIndex((update: ProductUpdate) => update.id === productUpdate.id)
    if (index !== undefined && index !== -1)
      scope.productUpdates[index] = productUpdate;
    scope.productUpdates = Object.assign([], scope.productUpdates);
    // this.selectedUpdate.action = ProductUpdateEvent.Nothing;
  }

  ngOnDestroy() {
    this.productUpdatesSubscription$?.unsubscribe();
    this.deleteSubscription$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }

  tableConfig: any = {
    hideOnClickOutside: true,
    showFooter: false,
    pagination: {
      pageSize: 2
    },
    classes: ['product-updates', 'border'],
    row: { //configuration for row
      isClickable: true,
      events: [{
        name: "click",
        scope: this,
        callback: this.view
      }]
    },
    columns: [
      {
        columnTitle: "Date",
        dataField: "date",
        dataType: "string",

        // isFilterable: false,
        headerStyle: {
          'width': '100px'
        }
      }, {
        columnTitle: "Title",
        dataField: "title",
        headerStyle: {
          'width': '250px'
        }
      }, {
        columnTitle: "Category",
        dataField: "category",
        headerStyle: {
          'width': '110px'
        }
      }, {
        columnTitle: "Description",
        dataField: "description",
        // classes: "clickable",
        isFilterable: false,
        headerStyle: { "width": "235px" },
        // style: {
        //   'width': "auto",
        //   "display": "-webkit-box",
        //   "-webkit-line-clamp": 2,
        //   "line-clamp": 2,
        //   "-webkit-box-orient": "vertical",
        //   "box-orient": "vertical",
        //   "overflow": "hidden"
        // },
        classes: ["ellipsis"],
      }, {
        tag: "actions",
        isFilterable: false,
        isSortable: false,
        headerStyle: { "width": "55px" },
        actions: [
          {
            title: "Edit",
            icon: "edit",
            callback: this.edit,
            scope: this
            // dataField: "field_invoice_doc"
          },
          {
            title: "delete",
            icon: "delete",
            // linkType: "download",
            callback: this.delete,
            scope: this,
            dataField: "id"
          }
        ],
        headerActions: [
          {
            title: "Add",
            icon: "add",
            callback: this.add,
            tooltip: "Add",
            scope: this,
            // dataField: "field_invoice_doc"
          }
        ]
      }
    ]
  }
  productTabClick(event: any) {
    if (this.productUpdates) {
      // Reset productUpdates if it already exists
      this.productUpdates = []; // Or assign an empty array/object depending on your data structure
  }
    const productUpdateType: any = this.productUpdateTypes.find((item: any) => item.name === event?.tab?.textLabel)
    this.getProductUpdates(productUpdateType)
  }

}
