import { Component, HostListener, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { ProductUpdateType } from 'src/app/modules/product-updates/models/product-update-type.model';
import { EventBusService } from '../../shared/event-bus.service';
import { AlertUtility } from '../../utils/alert.util';
import { ProductUpdate } from '../models/product-update.model';
import { ProductUpdateService } from '../product-update.service';
import { productUpdateTypes } from '../product-updates.config';
import { AuthenticationService } from '../../authentication/authentication.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-all-updates',
  templateUrl: './all-updates.component.html',
  styleUrls: ['./all-updates.component.scss']
})
export class AllUpdatesComponent implements OnInit {
  @Input() isHome: boolean = false;
  isLoading: boolean = false;
  productUpdatesSubscription$!: Subscription;
  clientChangeSub$: Subscription;

  constructor(
    private productUpdateService: ProductUpdateService,
    private router: Router,
    private eventBusService: EventBusService,
    private authService: AuthenticationService,
    private alertUtil: AlertUtility,
    private util: CommonUtilService) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.getProductUpdates(this.selectedProductUpdateType);
    })

  }
  errortxt: string = "";
  innerWidth: any;
  productUpdates!: ProductUpdate[];
  lmslink = 'https://lms.trianz.com';
  selectedProductUpdateType!: ProductUpdateType;
  productUpdateTypes!: any[]
  ngOnInit(): void {
    this.productUpdateTypes = productUpdateTypes
    this.selectedProductUpdateType = productUpdateTypes[0]
    this.innerWidth = window.innerWidth;
    // if (this.util.getClientId())
      this.getProductUpdates(this.selectedProductUpdateType);
  }
  onMoreClick(){
    const id = -1
    this.router.navigateByUrl('/updates/' + this.selectedProductUpdateType.key + '/' + id + "?realm=" + this.authService.getRealm(), { state: Object.assign([], this.productUpdates) });

    // this.router.navigate([`/updates/changelog/${id}`], {
    //   queryParams: { realm: this.authService.getRealm() }
    // });
  }
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }
  getProductUpdates(productUpdateType: ProductUpdateType) {
    this.isLoading = true;
    this.selectedProductUpdateType = productUpdateType;
    this.productUpdates = [];
    this.productUpdatesSubscription$ = this.productUpdateService.getProductUpdates(productUpdateType.id).subscribe((data: any) => {
      this.productUpdates = data;
      // this.productTabClick("")
      this.isLoading = false;
    }, (error: any) => {
      this.alertUtil.notifyToast(error.message, "error")
      this.isLoading = false
      // console.log(error)
    })
  }

  onUpdateClick(update: ProductUpdate) {
    this.router.navigateByUrl('/updates/' + this.selectedProductUpdateType.key + '/' + update.id + "?realm=" + this.authService.getRealm(), { state: Object.assign([], this.productUpdates) });
  }
  ngOnDestroy() {
    this.productUpdatesSubscription$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }
  productTabClick(event: any) {
    const productUpdateType: any = this.productUpdateTypes.find((item: any) => item.name === event?.tab?.textLabel) || this.productUpdateTypes[0]
    this.getProductUpdates(productUpdateType)
  }
}
