import { ProductUpdateType } from "src/app/modules/product-updates/models/product-update-type.model";

export const productUpdateTypes: ProductUpdateType[] = [
  {
    id: 1,
    key: "changelog",
    name: "Product Changelog"
  },
  {
    id: 2,
    key: "procedures",
    name: "New Procedures"
  },
  {
    id: 3,
    key: "roadmap",
    name: "Roadmap"
  }
]
