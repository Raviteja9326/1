import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import { Events } from "src/app/models/app.enums";
import { NewsList } from "src/app/models/news.model";
import { environment } from "src/environments/environment";
import { AuthenticationService } from "../../authentication/authentication.service";
import { ApiService } from "../../shared/api.service";
import { EventBusService } from "../../shared/event-bus.service";

@Component({
  selector: "app-news-details",
  templateUrl: "./news-details.component.html",
  styleUrls: ["./news-details.component.scss"],
})
export class NewsDetailsComponent implements OnInit {
  public newsListSubscription$!: Subscription;
  newsId!: any;
  newsDetails!: NewsList;
  publishdate: any;
  showNewsDetails: boolean = false;
  clientChangeSub$: Subscription;
  blobStorage!: { account: string; container: string; sas: string; };

  constructor(
    private activatedRoute: ActivatedRoute,
    private apiService: ApiService,
    private router: Router,
    private eventBusService:EventBusService,
    private authService:AuthenticationService
  ) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.getNewsList();
    })

  }

  ngOnInit(): void {
    this.blobStorage = environment.blobStorageConfig
    this.activatedRoute.queryParams.subscribe((params) => {
      this.newsId = params.newsId;
    });

    this.getNewsList();
  }

  public goBackToNewsListing() {
    this.router.navigate(["/news"], {
      queryParams: { category: this.newsDetails.category, realm:this.authService.getRealm() },
    });
  }

  public getNewsList() {
    this.newsListSubscription$ = this.apiService
      .getNews()
      .subscribe((news: any) => {
        this.newsDetails = news.data.find((n: { id: any; })=>n.id===this.newsId)
        this.newsDetails.date = (parseInt(this.newsDetails.date)*1000).toString()
        this.showNewsDetails = true;
      });
  }

  ngOnDestroy(){
    this.clientChangeSub$?.unsubscribe();
    this.newsListSubscription$?.unsubscribe();
  }
}
