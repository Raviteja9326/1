import {
  Component,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { Subscription } from "rxjs";
import { AuthenticationService } from "src/app/modules/authentication/authentication.service";
import { ApiService } from "../../shared/api.service";
import { EventBusService } from "../../shared/event-bus.service";
import { AlertUtility } from "../../utils/alert.util";
import { CommonUtilService } from "../../utils/common-util.service";
import { CardListingComponent } from "../../shared/components/card-listing/card-listing.component";
import { ngDebounce } from "../../shared/debounce.decorator";

@Component({
  selector: "app-learning",
  templateUrl: "./learning.component.html",
  styleUrls: ["./learning.component.scss"],
})
export class LearningComponent implements OnInit, OnDestroy {


  public itemList: any;
  public isLoading = false;
  public itemListSub$!: Subscription;
  public lmsLink = "https://lms.trianz.com";
  tabs: { name: string; value: string; }[] = [];
  tabsSub$!: Subscription;

  constructor(
    private apiService: ApiService,
    private util: CommonUtilService,
    private alertUtil: AlertUtility,
    private apiServices: ApiService
  ) {
    // super()
  }
  @Input("origin") origin = "";
  maxItems: number = Number.MAX_SAFE_INTEGER;
  @HostListener('window:resize', ['$event'])
  @ngDebounce(500)
  onResize(event: Event) {
    this.setMaxItemsCount();
  }
  private setMaxItemsCount() {
    if (this.origin.toLowerCase() === "details")
      this.maxItems = Number.MAX_SAFE_INTEGER
    else
      if (window.innerWidth >= 1400) {
        this.maxItems = 8;
      } else {
        this.maxItems = 6;
      }
  }

  ngOnInit(): void {
    this.loadTabs()
    this.setMaxItemsCount();
  }
  loadTabs() {
    this.isLoading = true;
    this.tabsSub$ = this.apiServices.getMenu('tutorials').subscribe({
      next: (resp: any) => {
        if (resp.length) {
          this.tabs = resp.map((tab: { title: any; url: any; }) => ({ name: tab.title, value: tab.url }))
        } else {
          this.tabs = this.getTabs();
        }
        this.isLoading = false;
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
  getTabs() {

    return [
      {
        name: "Trending",
        value: "trending"
      },
      {
        name: "Certification Status",
        value: "certification-status"
      },
      {
        name: "Upcoming Deadlines",
        value: "upcoming-deadlines"
      },
      {
        name: "Certification Paths",
        value: "certification-paths"
      },
      {
        name: "Certification Support",
        value: "certification-support"
      },
    ]
  }


  loadTutorials(type: string) {
    this.isLoading = true
    this.itemListSub$ = this.apiService.getTutorials(type).subscribe((resp: any) => {
      this.itemList = resp;
      this.itemList.forEach((item: any) => {
        item.callback = () => this.onEventClick(item)
      })
      this.isLoading = false;

    },
      (error) => {
        this.alertUtil.showAlert(error.message, "error")
        this.isLoading = false;
      }
    );
  }

  selectedIndex: number = 0
  onTabChange(event: any) {
    this.selectedIndex = event.index || 0;
    const selectedTab: { name: string; value: string; } | undefined = this.tabs.find(
      ((item: any) => item?.name === event?.tab?.textLabel)
    )
    const type = selectedTab?.value || "trending"
    this.loadTutorials(type)
  }
  onEventClick(course: any) {
    window.open(course.link || this.lmsLink, '_blank');
  }
  ngOnDestroy() {
    this.itemListSub$?.unsubscribe();
    this.tabsSub$?.unsubscribe();
  }
}
