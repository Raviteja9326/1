import { Component, OnInit, HostListener } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs/internal/Subscription";
import { NEWS_CATEGORY_LISTING } from "src/app/app.config";
import { Events } from "src/app/models/app.enums";
import { NewsList, NewsListing } from "src/app/models/news.model";
import { environment } from "src/environments/environment";
import { AuthenticationService } from "../../authentication/authentication.service";
import { ApiService } from "../../shared/api.service";
import { NETWORK_ERROR } from "../../shared/constant";
import { EventBusService } from "../../shared/event-bus.service";
import { CommonUtilService } from "../../utils/common-util.service";

@Component({
  selector: "app-news",
  templateUrl: "./news.component.html",
  styleUrls: ["./news.component.scss"],
})
export class NewsComponent implements OnInit {
  newsList: Array<NewsList> = [];
  newsListByCategory: Array<NewsList> = [];
  category!: any;
  newsCategory!: string;
  innerWidth: any;
  newsCategoryListing: any = [];
  isLoading: boolean = true;
  public newsListSubscription$!: Subscription;
  public error: boolean = false;
  public errorMsg!: string;
  clientChangeSub$!: Subscription;
  selectedIndex!: number;
  blobStorage!: { account: string; container: string; sas: string; };
  currentrealm: any;

  constructor(
    private apiService: ApiService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private authService: AuthenticationService
  ) {
    this.currentrealm = this.util.extractUrlValue("realm", decodeURIComponent(location.href)) || environment.endpoints.keyCloak.defaultRealm
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.getNewsCategory();
    })
  }

  ngOnInit(): void {
    if (this.util.getClientId())
      this.getNewsCategory();
    this.innerWidth = window.innerWidth;
    this.blobStorage = environment.blobStorageConfig
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }

  public getNewsCategory() {
    this.isLoading = true;
    this.newsCategoryListing = [];
    this.newsListSubscription$ = this.apiService.getNewsCat().subscribe((resp: any) => {
      const fixedcontent = {
        categoryName: "ALL",
        href: "#all",
        id: "All",
        active: true,
        publishContent: "All",
      }
      this.newsCategoryListing.unshift(fixedcontent);
      if(resp && resp.length > 0){
        resp.forEach((element: any) => {
          element['categoryName'] = element.value.trim().toUpperCase();
          element['href'] = '#'+element.value.replace(/\s/g,'')
          element['id'] = element.value.trim();
          element['active'] = false;
          element['publishContent']= element.value.trim();
          this.newsCategoryListing.push(element);
        });
        this.getNewsList();
      }else{
        this.isLoading = false;
      }
    }, (error: any) => {
      this.isLoading = false;
    })
  }

  public getNewsList() {
    this.isLoading = true;
    this.newsListSubscription$ = this.apiService
      .getNews()
      .subscribe((news: any) => {
        this.newsList = news?.data || [];
        this.activatedRoute.queryParams.subscribe((params) => {
          this.category = params && params.category ? params.category : "All";
          this.selectedCategory(this.category)
          // this.setActiveCategory(this.category);
          this.isLoading = false;
        });
      }, (error: any) => {
        this.error = true;
        this.errorMsg = NETWORK_ERROR
        this.isLoading = false;
      });
  }
  getSelectedCategory() {
    return this.newsCategoryListing.find((c: { active: boolean; }) => c.active === true)?.id || this.newsCategoryListing[0].id
  }

  public setActiveCategory(category: string) {
    this.newsCategoryListing.forEach((list : any) => {
      list.active = list.id.toLowerCase() === category.toLowerCase();
    });
    this.selectedIndex = this.newsCategoryListing.findIndex((list: { id: string; }) => list.id.toLowerCase() === category.toLowerCase())
  }

  public selectedCategory(selectedCategory: any) {
    const category = selectedCategory?.tab ? selectedCategory?.tab?.textLabel : selectedCategory
    if (category.toLowerCase() !== "all") {
      this.newsListByCategory = this.newsList.filter(
        (item) => item.category?.toLowerCase() === category?.toLowerCase()
      );
    } else this.newsListByCategory = this.newsList;
    this.setActiveCategory(category)
  }

  public getNewsDetailsPage(news: any) {
    this.router.navigate(["/news-details"], {
      queryParams: { newsId: news.id, realm: this.authService.getRealm() },
    });
  }

  getDefaultImage(news: any) {
    return "assets/images/ss-2.png"
  }

  ngOnDestroy() {
    this.newsListSubscription$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }
}
