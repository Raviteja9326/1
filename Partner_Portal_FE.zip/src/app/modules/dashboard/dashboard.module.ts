import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DashboardRoutingModule } from "./dashboard-routing.module";
import { SharedModule } from "../shared/shared.module";
import { HomeComponent } from "./home/home.component";
import { LearningComponent } from "./learning/learning.component";
import { UserComponent } from "./user/user.component";
import { AnnouncementsComponent } from "./announcements/announcements.component";
import { DirectivesModule } from "../directives/directives.module";
import { ApplicationStatusComponent } from "./application-status/application-status.component";
import { SalesAssetsComponent } from "./sales-assets/sales-assets.component";
import { TrainingCertificatesComponent } from "./training-certificates/training-certificates.component";
import { MyRequestsComponent } from "./my-requests/my-requests.component";
import { NewsComponent } from "./news/news.component";
import { MaterialModule } from "../shared/material/material.module";
import { PlatformComponent } from "./platform/platform.component";
import { CollateralComponent } from "./collateral/collateral.component";
import { PartnershipComponent } from "./partnership/partnership.component";
import { SalesAssetDetailsComponent } from "./sales-asset-details/sales-asset-details.component";
import { OpportunityManagementComponent } from "./opportunity-management/opportunity-management.component";
import { OpportunityManagementDetailsComponent } from "./opportunity-management-details/opportunity-management-details.component";
import { MyForeCastComponent } from "./my-forecast/my-forecast.component";
import { TenantTableComponent } from "./tenant-table/tenant-table.component";
import { NewsDetailsComponent } from "./news-details/news-details.component";
import { PipesModule } from "../pipes/pipes.module";
import { ProductUpdatesModule } from "../product-updates/product-updates.module";
import { NewsCarouselComponent } from "./news-carousel/news-carousel.component";
import { ChartingModule } from "../charting/charting.module";
import { ForecastingModule } from "../forecasting/forecasting.module";
import { OpportunityManagementModule } from "../opportunity-management/opportunity-management.module";
import { CollateralListComponent } from './collateral-list/collateral-list.component';
import { SupportOverviewComponent } from './support-overview/support-overview.component';
import { SupportComponent } from './support/support.component';
import { SupportOptionsOverviewComponent } from './support-options-overview/support-options-overview.component';
import { LearingAllComponent } from "./learing-all/learing-all.component";

@NgModule({
  declarations: [
    HomeComponent,
    LearningComponent,
    LearingAllComponent,
    UserComponent,
    AnnouncementsComponent,
    ApplicationStatusComponent,
    SalesAssetsComponent,
    TrainingCertificatesComponent,
    MyRequestsComponent,
    NewsComponent,
    PlatformComponent,
    CollateralComponent,
    PartnershipComponent,
    SalesAssetDetailsComponent,
    OpportunityManagementComponent,
    OpportunityManagementDetailsComponent,
    NewsDetailsComponent,
    MyForeCastComponent,
    TenantTableComponent,
    NewsCarouselComponent,
    CollateralListComponent,
    SupportOverviewComponent,
    SupportComponent,
    SupportOptionsOverviewComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ForecastingModule,
    DashboardRoutingModule,
    DirectivesModule,
    MaterialModule,
    PipesModule,
    ProductUpdatesModule,
    ChartingModule,
    OpportunityManagementModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class DashboardModule {}
