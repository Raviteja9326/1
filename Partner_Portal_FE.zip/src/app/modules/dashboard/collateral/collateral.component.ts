import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { SalesAsset, SalesAssetsCategories, SalesAssetsGroup, SalesAssetsType } from 'src/app/models/sales-assets.model';
import { DocumentPreviewComponent } from '../../shared/components/document-preview/document-preview.component';
import { NETWORK_ERROR } from '../../shared/constant';
import { EventBusService } from '../../shared/event-bus.service';
import { SalesAssetsService } from '../../shared/services/sales-assets.service';
import { CommonUtilService } from '../../utils/common-util.service';
import { environment } from 'src/environments/environment';
import { AuthenticationService } from '../../authentication/authentication.service';
import { VideoPlayerComponent } from '../../shared/video-player/video-player.component';

@Component({
  selector: 'app-collateral',
  templateUrl: './collateral.component.html',
  styleUrls: ['./collateral.component.scss']
})
export class CollateralComponent implements OnInit {
  // salesAssetsTypes = SalesAssetsType as any;
  // salesAssetsGroup: SalesAssetsGroup[] = [];
  // tabs = Object.keys(SalesAssetsCategories).map(key => ({ label: key, category: SalesAssetsCategories[key] }));
  // isLoading = true;
  // innerWidth: any;
  // error: boolean = false;
  // errorMsg!: string;
  // categoryName: any;
  // filterSalesAssetsData!: SalesAssetsGroup[];
  // mediaIcons: Record<string, MediaIcon> = {
  //   datasheet: { src: 'assets/icons/pdf.png', pos: 'corner' },
  //   presentation: { src: 'assets/icons/ppt.png', pos: 'corner' },
  //   sop: { src: 'assets/icons/pdf.png', pos: 'corner' },
  //   video: { src: 'assets/icons/play-solid.svg', pos: 'center' }
  // }
  // clientChangeSub$!: Subscription;
  // salesAssestSub$!: Subscription;
  // currentrealm: any;

  constructor(
    private salesAssetsService: SalesAssetsService,
    private router: Router,
    private dialog: MatDialog,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private authService: AuthenticationService
  ) {
    // this.currentrealm = this.authService.getRealm()
    // if (this.util.getClientId())
    //   this.getSalesAssetsList();
    // this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
    //   this.getSalesAssetsList();
    // })
  }

  ngOnInit(): void {
    // this.tabs.unshift({ label: 'All', category: 'all' });
    // this.innerWidth = window.innerWidth;
  }

  // @HostListener('window:resize', ['$event'])
  // onResize(event: any) {
  //   this.innerWidth = window.innerWidth;
  // }

  // getSalesAssetsList() {
  //   this.isLoading = true
  //   this.salesAssestSub$ = this.salesAssetsService.getSalesAssetsByGroup().subscribe(({ all, group }) => {
  //     this.salesAssetsGroup = [{
  //       category: 'all',
  //       data: all
  //     }, ...group];
  //     this.isLoading = false;
  //     this.marketingTabClick("")
  //   }, err => {
  //     this.error = true;
  //     this.errorMsg = NETWORK_ERROR;
  //     this.isLoading = false;
  //   }
  //   )
  // }

  // onClick(asset: SalesAsset) {
  //   if (asset.field_assets_type === SalesAssetsType.PRODUCT_VIDEOS) {
  //     this.router.navigate(['/home/collateral', asset.field_asserts_title]);
  //     return;
  //   }
  //   const target = asset.field_assets_file_type === 'pdf' ? '_blank' : '_self';
  //   window.open(asset.field_asserts_file, target);

  //   // const filename = "file." + asset.field_assets_file_type;
  //   // this.downloadFile(asset.field_asserts_file, filename);
  // }

  // onPreview(asset: SalesAsset) {
  //   if (asset.field_assets_type === SalesAssetsType.PRODUCT_VIDEOS) {
  //     this.dialog.open(VideoPlayerComponent, {
  //       height: '80%',
  //       width: '80%',
  //       data: { playbackUrl: "https://" + asset.field_asserts_link}
  //     })
  //   }
  //   else
  //   this.dialog.open(DocumentPreviewComponent, {
  //     height: '80%',
  //     width: '80%',
  //     panelClass: 'modal-class',
  //     data: { link: asset.field_asserts_file },
  //     disableClose: true
  //   })
  // }

  // private downloadFile(url: string, filename: string) {
  //   const req = new XMLHttpRequest();
  //   req.open('GET', url, true);
  //   req.responseType = 'blob';
  //   req.onload = function () {
  //     const blob = new Blob([req.response]);
  //     const windowUrl = window.URL || window.webkitURL;
  //     const href = windowUrl.createObjectURL(blob);
  //     const a = document.createElement('a');
  //     a.setAttribute('download', filename);
  //     a.setAttribute('href', href);
  //     document.body.appendChild(a);
  //     a.click();
  //     document.body.removeChild(a);
  //   };
  //   req.send();
  // }

  // ngOnDestroy() {
  //   this.salesAssestSub$?.unsubscribe();
  //   this.clientChangeSub$?.unsubscribe();
  // }
  // marketingTabClick(event: any) {
  //   const selected = this.tabs.filter(
  //     ((item: any) => item?.label === event?.tab?.textLabel)
  //   )
  //   this.categoryName = event?.tab?.textLabel
  //     ? selected[0].category
  //     : "All";
  //   if (this.categoryName === "All") {
  //     this.filterSalesAssetsData = this.salesAssetsGroup
  //       .filter(
  //         (item: any) => item?.category === "all"
  //       )
  //   } else {
  //     this.filterSalesAssetsData = this.salesAssetsGroup
  //       .filter(
  //         (item: any) =>
  //           item?.category === this.categoryName
  //       )
  //   }
  // }

}

// interface MediaIcon {
//   src: string, pos: string
// }
