import { Component, HostListener, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../shared/api.service';
import { Subscription } from 'rxjs';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-support-overview',
  templateUrl: './support-overview.component.html',
  styleUrls: ['./support-overview.component.scss']
})
export class SupportOverviewComponent implements OnInit {
  selectTab: string="Overview";
  innerWidth!: any;
  selectedIndex: any;

  constructor(private apiService:ApiService,private alertUtil:AlertUtility,private util: CommonUtilService) { }
 
  loadMenuSub$!:Subscription
  
  menu:any
  isLoading:boolean=false
  tabs!: { title: string, url: string }[]
  @ViewChild('tabContent', { read: ViewContainerRef, static: true }) tabContent!: ViewContainerRef;
  ngOnInit(): void {
    this.loadMenuData();
   
  }
  loadMenuData(){
    this.isLoading=true
    this.loadMenuSub$=this.apiService.getMenu('support').subscribe({
      next: (resp: any) => {
        // this.menu=resp.data
        this.tabs=resp
        console.log(this.tabs,'this is menu')
        this.isLoading = false
      },
      error: (err: any) => {
        this.alertUtil.showAlert('error', err)
        this.isLoading = false
      },
      complete:()=>{this.isLoading=false}
    })
  }
  
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }
  tabSelected(event:any) {
    this.selectedIndex = event.index;
    this.util.showTabContent(this.tabs[this.selectedIndex], this.tabContent)
  }
 
  ngOnDestroy(){
    this.loadMenuSub$?.unsubscribe();
  }

}
