import { Component, OnInit } from "@angular/core";
import { Subscription } from "rxjs/internal/Subscription";
import { appConfig } from "src/app/app.config";
import { NewsList } from "src/app/models/news.model";
import { CommonUtilService } from "../../utils/common-util.service";
import _ from 'lodash';
import { AuthenticationService } from "../../authentication/authentication.service";
import { EventBusService } from "../../shared/event-bus.service";
import { Events } from "src/app/models/app.enums";
import { Popups } from "../../shared/popup/popup-mapper";
import { MakeRequestType } from "src/app/models/make-request.model";
import { param } from "jquery";
@Component({
  selector: "app-user",
  templateUrl: "./user.component.html",
  styleUrls: ["./user.component.scss"],
})
export class UserComponent implements OnInit {
  trendingNewsList: Array<NewsList> = [];
  public isLoading = false;
  allNews: any[] = [];
  public newsListSubscription$!: Subscription;
  date = new Date()
  userProfile: any;
  // requestType = MakeRequestType.DEMO

  get greetings() {
    const hour = this.date.getHours();
    return hour >= 1 && hour < 12 ? "Morning" : hour >= 12 && hour < 16 ? "Afternoon" : "Evening";
  }

  constructor(private util: CommonUtilService, private authService: AuthenticationService, private eventBusService: EventBusService) {
  }

  ngOnInit(): void {
    this.userProfile = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo)?.profile;
    setInterval(() => {
      this.date = new Date()
    }, 2000);
  }

  registerDeal() {
    if (this.authService.getRealm().toLowerCase() === "aws")
      this.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.RegisterDealAws, title: "Register a Deal" } })
    else
      this.eventBusService.emit({ name: Events.ShowModalPopup, value: { modalId: Popups.RegisterDeal, title: "Register a Deal" } })

  }
  scheduleDemo() {
    this.eventBusService.emit({
      name: Events.ShowModalPopup,
      value: {
        modalId: Popups.RequestDemo,
        title: "Make a Request",
        params: [
          { key: "requestType", value: MakeRequestType.DEMO }
        ]
      }
    })

    // this.eventBusService.emit({
    //   name: Events.RequestDemo,
    //   value: {
    //     modalId: Popups.RequestDemo, title: "Create Request",
        // params: [
        //   { key: "requestType", value: MakeRequestType.DEMO }
        // ]
    //   }
    // })
  }
}
