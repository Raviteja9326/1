import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../authentication/authentication.service';
import * as moment from 'moment';

@Component({
  selector: 'app-my-requests',
  templateUrl: './my-requests.component.html',
  styleUrls: ['./my-requests.component.scss']
})
export class MyRequestsComponent implements OnInit {
  isLoading: boolean = false;
  requestArr: any;
  startDate:any;
  endDate:any;
  constructor(private authService: AuthenticationService) { }

  ngOnInit(): void {
    this.getMyRequest();
  }
  
  getMyRequest(){
    let data= this.authService.getMyRequest().subscribe(
      (data:any) => {
        this.requestArr = data.data;
        console.log(this.requestArr);
        for (let i = 0; i < this.requestArr.length; i++) {
          let obj = {...this.requestArr[i]};
          this.requestArr.startDate  = moment(obj.start_date).format("dd/mm hh:mm a")
        }
        this.isLoading = false;
      },
      error => {
        this.isLoading = false;
        console.log(error)
      }
    );
  }
}
