import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learing-all',
  templateUrl: './learing-all.component.html',
  styleUrls: ['./learing-all.component.scss']
})
export class LearingAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
