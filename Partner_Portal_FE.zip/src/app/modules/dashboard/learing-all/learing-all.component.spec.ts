import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearingAllComponent } from './learing-all.component';

describe('LearingAllComponent', () => {
  let component: LearingAllComponent;
  let fixture: ComponentFixture<LearingAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearingAllComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearingAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
