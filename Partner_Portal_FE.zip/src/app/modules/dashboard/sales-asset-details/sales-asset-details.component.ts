import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, UrlSegment } from '@angular/router';
import { SalesAsset, SalesAssetsGroup } from 'src/app/models/sales-assets.model';
import { SalesAssetsService } from '../../shared/services/sales-assets.service';
import { AlertUtility } from '../../utils/alert.util';

@Component({
  selector: 'app-sales-asset-details',
  templateUrl: './sales-asset-details.component.html',
  styleUrls: ['./sales-asset-details.component.scss']
})
export class SalesAssetDetailsComponent implements OnInit {
  salesAssetsGroup: SalesAssetsGroup[] = [];
  videoArray?: SalesAsset
  title!: string;
  isLoading: boolean = false;
  constructor(
    private salesAssetsService: SalesAssetsService,
    private route: ActivatedRoute,
    private alertUtil: AlertUtility) { }

  ngOnInit(): void {
    this.route.url.subscribe((res: UrlSegment[]) => {
      this.title = res[1].path
    })
    // this.getSalesAssetsList();
  }
  // getSalesAssetsList() {
  //   this.isLoading = true;
  //   this.salesAssetsService.getSalesAssets().subscribe((res: SalesAsset[]) => {
  //     this.videoArray = res.find(asset => {
  //       return asset.field_asserts_title == this.title
  //     })
  //     this.isLoading = false;
  //   }, (error) => {
  //     this.alertUtil.notifyToast(error.message, "error")
  //     this.isLoading = false
  //   })
  // }
}
