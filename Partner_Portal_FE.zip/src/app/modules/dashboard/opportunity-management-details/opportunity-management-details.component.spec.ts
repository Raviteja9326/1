import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunityManagementDetailsComponent } from './opportunity-management-details.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { KeycloakAngularModule } from 'keycloak-angular';

describe('OpportunityManagementDetailsComponent', () => {
  let component: OpportunityManagementDetailsComponent;
  let fixture: ComponentFixture<OpportunityManagementDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpportunityManagementDetailsComponent ],
      imports: [
        RouterTestingModule, HttpClientModule, KeycloakAngularModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunityManagementDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
