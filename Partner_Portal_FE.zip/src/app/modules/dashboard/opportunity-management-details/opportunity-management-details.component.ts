import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';

@Component({
  selector: 'app-opportunity-management-details',
  templateUrl: './opportunity-management-details.component.html',
  styleUrls: ['./opportunity-management-details.component.scss']
})
export class OpportunityManagementDetailsComponent implements OnInit {

  largeValue: boolean=true;
  constructor(private router:Router, private authService:AuthenticationService) { }

  ngOnInit(): void {
  }
  onBackClick(url:string){
    this.router.navigate(
      [`/${url}`],
      { queryParams: { realm: this.authService.getRealm() } }
    );
  }
}
