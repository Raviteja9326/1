import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { appConfig, ticketType } from 'src/app/app.config';
import { Events, SortingDirection } from 'src/app/models/app.enums';
import { TableColumn } from 'src/app/models/table.model';
import { TenantData } from 'src/app/models/tenant.model';
import { EventBusService } from '../../shared/event-bus.service';
import { MyForecastService } from '../../shared/services/my-forecast.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-tenant-table',
  templateUrl: './tenant-table.component.html',
  styleUrls: ['./tenant-table.component.scss']
})
export class TenantTableComponent implements OnInit {
  @Input() isMinimal = false;
  tenantColumns: { columnConfig: TableColumn[] } = {
    columnConfig: [
      {
        name: "TENANT ID",
        dataField: 'tenant_id',
        isFilterable: true,
        filterValues: [],
        filterOpened: false,
        isSorted: false,
        sortingDirection: SortingDirection.Descending,
      }, {
        name: "TENANT NAME",
        dataField: 'tenant_name',
        isFilterable: false,
        filterValues: [],
        filterOpened: false,
        isSorted: false,
        sortingDirection: SortingDirection.Descending,
      }, {
        name: "STATUS",
        dataField: 'status',
        isFilterable: true,
        filterValues: [],
        filterOpened: false,
        isSorted: false,
        sortingDirection: SortingDirection.Descending,
      }, {
        name: "LAST UPDATED",
        dataField: 'last_updated',
        isFilterable: true,
        filterValues: [],
        filterOpened: false,
        isSorted: false,
        sortingDirection: SortingDirection.Descending,
      }
    ]
  }
  @Input() tenantData: any
  tenantSubscription$!: Subscription;
  reloadIncidentsSub$!: Subscription;
  constructor() { }

  ngOnInit(): void {
  }


  ngOnDestroy() {
    this.tenantSubscription$?.unsubscribe();
  }
}
