import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';

@Component({
  selector: 'app-training-certificates',
  templateUrl: './training-certificates.component.html',
  styleUrls: ['./training-certificates.component.scss'],
})
export class TrainingCertificatesComponent implements OnInit {
  public trainingCertificate: string = 'start';
  constructor(private router:Router, private authService:AuthenticationService) {}

  ngOnInit(): void {}
  onMoreClick(){
    this.router.navigate(['learning'], {
      queryParams: { realm: this.authService.getRealm() }
    });
  }
  onMenuClick(url:string){
    this.router.navigate(
      [`/${url}`],
      { queryParams: { realm: this.authService.getRealm() } }
    );
  }

}
