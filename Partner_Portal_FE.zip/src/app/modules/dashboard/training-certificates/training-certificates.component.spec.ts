import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingCertificatesComponent } from './training-certificates.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { KeycloakAngularModule } from 'keycloak-angular';

describe('TrainingCertificatesComponent', () => {
  let component: TrainingCertificatesComponent;
  let fixture: ComponentFixture<TrainingCertificatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainingCertificatesComponent ],
      imports:[
        RouterTestingModule, HttpClientModule, KeycloakAngularModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingCertificatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
