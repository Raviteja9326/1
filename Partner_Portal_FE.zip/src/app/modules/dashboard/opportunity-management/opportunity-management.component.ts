import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication/authentication.service';


@Component({
  selector: 'app-opportunity-management',
  templateUrl: './opportunity-management.component.html',
  styleUrls: ['./opportunity-management.component.scss']
})
export class OpportunityManagementComponent implements OnInit {
  currentRealm:any;  
  dealsData: any;
  constructor( private router: Router,
    private authService:AuthenticationService) { }

  ngOnInit(): void {
    this.dealsData=[];
    this.currentRealm = this.authService.getRealm().toLowerCase();
  }
  onMenuClick(url:string){
    this.router.navigate(
      [`/${url}`],
      { queryParams: { realm: this.authService.getRealm() } }
    );
  }

}
