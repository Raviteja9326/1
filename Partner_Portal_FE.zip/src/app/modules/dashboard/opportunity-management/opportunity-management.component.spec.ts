import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunityManagementComponent } from './opportunity-management.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { KeycloakAngularModule } from 'keycloak-angular';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

describe('OpportunityManagementComponent', () => {
  let component: OpportunityManagementComponent;
  let fixture: ComponentFixture<OpportunityManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OpportunityManagementComponent],
      imports: [
        RouterTestingModule, HttpClientModule, KeycloakAngularModule],
      providers: [{ provide: MatDialogRef, useValue: {} },{ provide: MatDialog, useValue: {} }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunityManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
