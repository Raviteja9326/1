import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { PlatformComponent } from "src/app/modules/dashboard/platform/platform.component";
// import { CollateralComponent } from "./collateral/collateral.component";
import { HomeComponent } from "./home/home.component";
import { LearningComponent } from "./learning/learning.component";
import { NewsDetailsComponent } from "./news-details/news-details.component";
import { NewsComponent } from "./news/news.component";
import { OpportunityManagementDetailsComponent } from "./opportunity-management-details/opportunity-management-details.component";
import { OpportunityManagementComponent } from "./opportunity-management/opportunity-management.component";
import { PartnershipComponent } from "./partnership/partnership.component";
import { SalesAssetDetailsComponent } from "./sales-asset-details/sales-asset-details.component";

export const dashboardRoutes: Routes = []
// export const dashboardRoutes: Routes = [
//   { path: "", component: HomeComponent },
//   { path: "learning", component: LearningComponent },
//   { path: "news", component: NewsComponent },
//   { path: "news-details", component: NewsDetailsComponent, },
//   { path: "platform/:platformSubMenu/:id", component: PlatformComponent, },
//   { path: "opportunity", component: OpportunityManagementComponent },
//   { path: "collateral/:id", component: SalesAssetDetailsComponent },
//   { path: "partnership/:partnershipSubMenu/:id", component: PartnershipComponent, },
//   { path: "opportunity-details", component: OpportunityManagementDetailsComponent },
// ];

@NgModule({
  imports: [RouterModule.forChild(dashboardRoutes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule { }
