import { Component, HostListener, OnInit } from "@angular/core";
import { Subscription } from "rxjs/internal/Subscription";
import { Events, FeatureList } from "src/app/models/app.enums";
import { NewsList } from "src/app/models/news.model";
import { AuthorizationService } from "../../authentication/authorization.service";
import { ApiService } from "../../shared/api.service";
import { EventBusService } from "../../shared/event-bus.service";
import { AlertUtility } from "../../utils/alert.util";
import { CommonUtilService } from "../../utils/common-util.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
  // changeDetection:ChangeDetectionStrategy.OnPush
})
export class HomeComponent implements OnInit {
  isLoading: boolean = false;
  innerWidth: any;
  public newsListSubscription$!: Subscription;
  newsList: Array<NewsList> = [];
  clientChangeSub$: Subscription;
  isLoggedIn: boolean = false;
  feature!: typeof FeatureList;
  constructor(
    private apiService: ApiService,
    private eventBusService: EventBusService,
    public authorizer: AuthorizationService,
    private util:CommonUtilService,
    private alertUtil: AlertUtility) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (params: any) => {
      this.isLoggedIn = true
      this.getNewsList();
    })
    this.clientChangeSub$ = this.eventBusService.on(Events.LoginSuccess, (params: any) => {
      this.getNewsList();
    })

  }

  ngOnInit(): void {
    this.innerWidth = window.innerWidth;
    this.getNewsList();
    this.feature = FeatureList

    if (this.util.getClientId()) {
      this.isLoggedIn = true
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }

  public getNewsList() {
    if (!this.util.getClientId()) return
    if (this.newsList.length) return
    this.isLoading = true;
    this.newsListSubscription$ = this.apiService
      .getNews()
      .subscribe({
        next: (news: any) => {
          this.newsList = news?.data || [];
          this.isLoading = false;
        }, error: err => {
          this.alertUtil.notifyToast(err.message, "error")
          this.isLoading = false;
        }, complete: () => {
          this.isLoading = false;
        }
      });
  }
  ngOnDestroy() {
    this.newsListSubscription$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }
}
