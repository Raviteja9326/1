import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { AttributesData } from 'src/app/models/pages.model';
import { ApiService } from '../../shared/api.service';
import { NETWORK_ERROR } from '../../shared/constant';
import { EventBusService } from '../../shared/event-bus.service';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-platform',
  templateUrl: './platform.component.html',
  styleUrls: ['./platform.component.scss']
})
export class PlatformComponent implements OnInit {

  pageInfo?: AttributesData;
  isLoading: boolean = false;
  error: boolean = false;
  errorMsg!: string;
  pageSub$!: Subscription;
  clientChangeSub$: any;
  constructor(private route: ActivatedRoute, private apiService: ApiService, private eventBusService: EventBusService, private util: CommonUtilService) {
    this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (arg: any) => {
      this.loadPlaformData();
    });
  }

  ngOnInit(): void {
    if (this.util.getClientId())
      this.loadPlaformData();
  }

  private loadPlaformData() {
    this.route.paramMap.subscribe((params: any) => {
      this.getOnePlatform(params.get('id'));
    });
  }

  getOnePlatform(id: string) {
    this.isLoading = true;
    this.pageInfo = undefined;
    this.pageSub$ = this.apiService.getPagesById(id).subscribe(({ data }) => {
      this.pageInfo = data.attributes;
      this.isLoading = false;
    }, err => {
      this.isLoading = false;
      this.pageInfo = undefined;
      this.error = true;
      this.errorMsg = NETWORK_ERROR;
    })
  }

  ngOnDestroy() {
    this.pageSub$?.unsubscribe();
    this.clientChangeSub$?.unsubscribe();
  }

}
