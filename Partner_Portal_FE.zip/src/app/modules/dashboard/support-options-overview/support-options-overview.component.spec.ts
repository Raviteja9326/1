import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportOptionsOverviewComponent } from './support-options-overview.component';

describe('SupportOptionsOverviewComponent', () => {
  let component: SupportOptionsOverviewComponent;
  let fixture: ComponentFixture<SupportOptionsOverviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupportOptionsOverviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportOptionsOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
