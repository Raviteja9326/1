import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../shared/api.service';
import { CommonUtilService } from '../../utils/common-util.service';
import { AlertUtility } from '../../utils/alert.util';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-support-options-overview',
  templateUrl: './support-options-overview.component.html',
  styleUrls: ['./support-options-overview.component.scss']
})
export class SupportOptionsOverviewComponent implements OnInit {
  data:any
  loadDataSub$!:Subscription
  constructor(private apiService:ApiService,private alertUtil:AlertUtility,private util: CommonUtilService) { }
  isLoading:boolean=false
  ngOnInit(): void {
    this.loadData();
  }
  loadData(){
    this.isLoading=true
    this.loadDataSub$=this.apiService.getCategoryData("overview").subscribe({
      next: (resp: any) => {
        this.data=resp.data
        console.log(this.data,'suport data')
        this.isLoading = false
      },
      error: (err: any) => {
        this.alertUtil.showAlert('error', err)
        this.isLoading = false
      },
      complete:()=>{this.isLoading=false}
    })
  }
  getKeys(obj:Object){
    return Object.keys(obj)

  }
  getImage(img:any){
    return this.apiService.getImageUrl(img)
  }
  
  ngOnDestroy(){
    this.loadDataSub$?.unsubscribe();
  
  }
}
