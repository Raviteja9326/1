import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsCarouselComponent } from './news-carousel.component';
import { HttpClientModule } from '@angular/common/http';
import { KeycloakAngularModule } from 'keycloak-angular';
import { RouterTestingModule } from '@angular/router/testing';

describe('NewsCarouselComponent', () => {
  let component: NewsCarouselComponent;
  let fixture: ComponentFixture<NewsCarouselComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewsCarouselComponent ],
      imports:[
        HttpClientModule, KeycloakAngularModule, RouterTestingModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsCarouselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
