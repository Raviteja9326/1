import { Component, Input, OnInit, SimpleChanges } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { NewsList } from "src/app/models/news.model";
import { AuthenticationService } from "../../authentication/authentication.service";

declare var $: any;
import _ from 'lodash';
import { environment } from "src/environments/environment";

@Component({
  selector: 'app-news-carousel',
  templateUrl: './news-carousel.component.html',
  styleUrls: ['./news-carousel.component.scss']
})
export class NewsCarouselComponent implements OnInit {
  @Input() newsList: Array<NewsList> = [];
  isLoading: boolean = false;
  allNews: any[] = [];
  newsSubscription$!: Subscription;
  private newsCount: number = 4;
  private rotationInterval: number = 4; //in sec
  eventsSubscription$!: Subscription;
  blobStorage!: { account: string; container: string; sas: string; };

  constructor(
    private authService: AuthenticationService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.blobStorage = environment.blobStorageConfig
    setTimeout(() => {
      $('.carousel').carousel({
        interval: this.rotationInterval * 1000
      })
    }, 3000);
  }
  ngOnChanges(changes: SimpleChanges) {
    this.filterTrendingNewsList(changes.newsList.currentValue);
  }

  public filterTrendingNewsList(newsList: NewsList[]) {
    const allnews: any[] = _.cloneDeep(newsList)
    this.allNews = allnews.filter((news: any) => news.trending === "1")
      .sort((a: { id: number; }, b: { id: number; }) => b.id - a.id)
      .slice(0, this.newsCount)
  }

  onNewsClick(news: any) {
    this.router.navigate(["/news-details"], {
      queryParams: { newsId: news.id, realm: this.authService.getRealm() },
    });
  }

  ngOnDestroy() {
    this.newsSubscription$?.unsubscribe();
    this.eventsSubscription$?.unsubscribe();
  }
}
