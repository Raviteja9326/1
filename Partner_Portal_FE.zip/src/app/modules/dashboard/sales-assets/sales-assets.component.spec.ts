import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesAssetsComponent } from './sales-assets.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { KeycloakAngularModule } from 'keycloak-angular';

describe('SalesAssetsComponent', () => {
  let component: SalesAssetsComponent;
  let fixture: ComponentFixture<SalesAssetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalesAssetsComponent ],
      imports:[
        HttpClientModule,
        RouterTestingModule,
        KeycloakAngularModule
      ],
      providers: [{ provide: MatDialogRef, useValue: {} }, { provide: MatDialog, useValue: {} }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
