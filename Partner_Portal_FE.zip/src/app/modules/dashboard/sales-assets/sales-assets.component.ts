import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
import { SalesAsset, SalesAssetsCategories, SalesAssetsGroup, SalesAssetsType } from 'src/app/models/sales-assets.model';
import { AuthenticationService } from '../../authentication/authentication.service';
import { DocumentPreviewComponent } from '../../shared/components/document-preview/document-preview.component';
import { EventBusService } from '../../shared/event-bus.service';
import { SalesAssetsService } from '../../shared/services/sales-assets.service';
import { VideoPlayerComponent } from '../../shared/video-player/video-player.component';
import { AlertUtility } from '../../utils/alert.util';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-sales-assets',
  templateUrl: './sales-assets.component.html',
  styleUrls: ['./sales-assets.component.scss']
})
export class SalesAssetsComponent implements OnInit {
  // innerWidth: any;
  // tabs = Object.keys(SalesAssetsCategories).map(key => ({ label: key, category: SalesAssetsCategories[key] }));
  // salesAssetsGroup: SalesAssetsGroup[] = [];
  // mediaIcons: Record<string, MediaIcon> = {
  //   datasheet: { src: 'assets/icons/pdf.png', pos: 'corner' },
  //   presentation: { src: 'assets/icons/ppt.png', pos: 'corner' },
  //   sop: { src: 'assets/icons/pdf.png', pos: 'corner' },
  //   video: { src: 'assets/icons/play-solid.svg', pos: 'center' }
  // }
  // salesAssesSubscription$!: Subscription;
  // isLoading: boolean = false;
  // clientChangeSub$: Subscription;
  // categoryName: any;
  // filterSalesAssetsData!: SalesAssetsGroup[];
  constructor(
    private salesAssetsService: SalesAssetsService,
    private router: Router,
    private dialog: MatDialog,
    private eventBusService: EventBusService,
    private util: CommonUtilService,
    private authService: AuthenticationService,
    private alertUtil: AlertUtility
  ) {
    // if (this.util.getClientId())
    //   this.getSalesAssetsList();
    // this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (arg: any) => {
    //   this.getSalesAssetsList();
    // });
  }

  ngOnInit(): void {
    // this.tabs.unshift({ label: 'All', category: 'all' });
    // // this.getSalesAssetsList();
    // this.innerWidth = window.innerWidth;
  }
  onMoreClick(){
    this.router.navigate(['collateral'], {
      queryParams: { realm: this.authService.getRealm() }
    });
  }
  // onMenuClick(url: string) {
  //   this.router.navigate(
  //     [`/${url}`],
  //     { queryParams: { realm: this.authService.getRealm() } }
  //   );
  // }

  // @HostListener('window:resize', ['$event'])
  // onResize(event: any) {
  //   this.innerWidth = window.innerWidth;
  // }
  // onClick(asset: SalesAsset) {
  //   if (asset.field_assets_type === SalesAssetsType.PRODUCT_VIDEOS) {
  //     this.router.navigate([asset.field_asserts_link]);
  //     return;
  //   }
  //   const target = asset.field_assets_file_type === 'pdf' ? '_blank' : '_self';
  //   window.open(asset.field_asserts_file, target);
  // }


  // onPreview(asset: SalesAsset) {
  //   if (asset.field_assets_type === SalesAssetsType.PRODUCT_VIDEOS) {
  //     this.dialog.open(VideoPlayerComponent, {
  //       height: '80%',
  //       width: '80%',
  //       data: { playbackUrl: "https://" + asset.field_asserts_link}
  //     })
  //   }
  //   else
  //     this.dialog.open(DocumentPreviewComponent, {
  //       height: '80%',
  //       width: '80%',
  //       panelClass: 'modal-class',
  //       data: { link: asset.field_asserts_file },
  //       disableClose: true
  //     })
  // }

  // getSalesAssetsList() {
  //   this.isLoading = true;
  //   this.salesAssesSubscription$ = this.salesAssetsService.getSalesAssetsByGroup().subscribe(({ all, group }) => {
  //     this.salesAssetsGroup = [{
  //       category: 'all',
  //       data: all
  //     }, ...group];
  //     this.isLoading = false;
  //     this.marketingTabClick("")
  //   }, (error) => {
  //     this.alertUtil.notifyToast(error.message, "error")
  //     this.isLoading = false
  //   })
  // }
  ngOnDestroy() {
    // this.salesAssesSubscription$?.unsubscribe();
    // this.clientChangeSub$?.unsubscribe();
  }
  // marketingTabClick(event: any) {
  //   const selected = this.tabs.filter(
  //     ((item: any) => item?.label === event?.tab?.textLabel)
  //   )
  //   this.categoryName = event?.tab?.textLabel
  //     ? selected[0].category
  //     : "All";
  //   if (this.categoryName === "All") {
  //     this.filterSalesAssetsData = this.salesAssetsGroup
  //       .filter(
  //         (item: any) => item?.category === "all"
  //       )
  //   } else {
  //     this.filterSalesAssetsData = this.salesAssetsGroup
  //       .filter(
  //         (item: any) =>
  //           item?.category === this.categoryName
  //       )
  //   }
  // }

}
// interface MediaIcon {
//   src: string, pos: string
// }
