import { Component, Input, OnInit, SimpleChanges } from "@angular/core";
import { Router } from "@angular/router";
import { NewsList } from "src/app/models/news.model";
import { AuthenticationService } from "../../authentication/authentication.service";
import { ApiService } from "../../shared/api.service";

@Component({
  selector: "app-announcements",
  templateUrl: "./announcements.component.html",
  styleUrls: ["./announcements.component.scss"],
})
export class AnnouncementsComponent implements OnInit {
  @Input() newsList: Array<NewsList> = [];
  constructor(private apiService: ApiService, private router: Router, private authService: AuthenticationService) { }

  ngOnInit(): void {
    // this.filterNewsList();
  }
  onNewsClick(childRoute: string, queryParams: any) {
    queryParams['realm'] = this.authService.getRealm()
    this.router.navigate(
      // [`/${parentRoute}`, childRoute],
      [`/${childRoute}`],
      { queryParams: queryParams }
    );
  }

  ngOnChanges(changes: SimpleChanges) {
    this.filterNewsList(changes.newsList.currentValue);

  }
  public filterNewsList(newsList: NewsList[]) {
    const newsDetails: Array<NewsList> = newsList;
    this.newsList = newsDetails.filter(
      (item) => item.category === "Announcements"
    );
    
  }
}
