import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { AttributesData } from 'src/app/models/pages.model';
import { ApiService } from '../../shared/api.service';
import { NETWORK_ERROR } from '../../shared/constant';

@Component({
  selector: 'app-partnership',
  templateUrl: './partnership.component.html',
  styleUrls: ['./partnership.component.scss']
})
export class PartnershipComponent implements OnInit {

  pageInfo?: AttributesData;
  isLoading = true;
  error:boolean=false;
  errorMsg!:string;

  constructor(private route: ActivatedRoute, private apiService: ApiService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.getSelectedItemDetails(params && params.get('id') || '');
    })
  }
  
  getSelectedItemDetails(id: string) {
    this.isLoading = true;
    this.apiService.getPagesById(id).subscribe(({ data }) => {
      this.pageInfo = data.attributes;
      this.isLoading = false;
    }, err => {
       this.isLoading = false;
       this.pageInfo = undefined;
       this.error = true;
       this.errorMsg = NETWORK_ERROR; 
    })
  }

}
