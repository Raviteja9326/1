
import {
  Component,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { Subscription } from "rxjs";
import { ApiService } from "../../shared/api.service";
import { AlertUtility } from "../../utils/alert.util";
import { CommonUtilService } from "../../utils/common-util.service";
import { SalesAssetsService } from "../../shared/services/sales-assets.service";
import { environment } from "src/environments/environment";
import { SalesAsset, SalesAssetsType } from "src/app/models/sales-assets.model";
import { VideoPlayerComponent } from "../../shared/video-player/video-player.component";
import { MatDialog } from "@angular/material/dialog";
import { DocumentPreviewComponent } from "../../shared/components/document-preview/document-preview.component";
import { CardListingComponent } from "../../shared/components/card-listing/card-listing.component";
import { ngDebounce } from "../../shared/debounce.decorator";

@Component({
  selector: 'app-collateral-list',
  templateUrl: './collateral-list.component.html',
  styleUrls: ['./collateral-list.component.scss']
})
export class CollateralListComponent implements OnInit, OnDestroy {

  public itemList: any;
  public isLoading = false;
  public itemListSub$!: Subscription;
  public lmsLink = "https://lms.trianz.com";
  tabs: { name: string; value: string; }[] = [];
  tabsSub$: any;
  constructor(private apiService: ApiService,
    private util: CommonUtilService,
    private alertUtil: AlertUtility,
    private salesAssetsService: SalesAssetsService,
    private dialog: MatDialog,
  ) {
    // super()
  }

  @Input("origin") origin = "";
  maxItems: number = Number.MAX_SAFE_INTEGER;
  @HostListener('window:resize', ['$event'])
  @ngDebounce(500)
  onResize(event: Event) {
    this.setMaxItemsCount();
  }
  private setMaxItemsCount() {
    if (this.origin.toLowerCase() === "details")
      this.maxItems = Number.MAX_SAFE_INTEGER
    else
      if (window.innerWidth >= 1400) {
        this.maxItems = 8;
      } else {
        this.maxItems = 6;
      }
  }

  ngOnInit(): void {
    this.loadTabs()
    this.setMaxItemsCount();
  }

  loadTabs() {
    this.isLoading = true;
    this.tabsSub$ = this.apiService.getMenu('collateral').subscribe({
      next: (resp: any) => {
        if (resp.length) {
          this.tabs = resp.map((tab: { title: any; url: any; }) => ({ name: tab.title, value: tab.url }))
        } else {
          this.tabs = this.getTabs();
        }
        this.isLoading = false;
      },
      error: (error: any) => {
        this.alertUtil.showAlert('error', error);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
  getTabs() {
    const tabs: { name: string, value: string }[] = [
      {
        "name": "All",
        "value": ""
      },
      {
        "name": "Product Data Sheets",
        "value": "PROD_DATA_SHEETS"
      },
      {
        "name": "Customer Presentations",
        "value": "CUSTOMER_PRESENTATIONS"
      },
      {
        "name": "Customer Onboarding Sops",
        "value": "CUSTOMER_ONBOARDING_SOPS"
      },
      {
        "name": "Product Videos",
        "value": "PRODUCT_VIDEOS"
      },
    ];

    return tabs
  }


  loadTutorials(category: string) {
    this.isLoading = true
    this.itemListSub$ = this.salesAssetsService.getSalesAssets(category).subscribe((resp: any) => {
      // this.maxItems = this.origin === 'home' ? 6 : resp?.length;
      this.itemList = this.processData(resp);
      this.isLoading = false;

    },
      (error) => {
        this.alertUtil.showAlert(error.message, "error")
        this.isLoading = false;
      }
    );
  }
  processData(resp: any): any {
    resp.map((item: any) => {
      item.image = item.field_asserts_banner.replaceAll("//", "/").replace("/", "//");
      item.field_asserts_file = item.field_asserts_file.replaceAll("//", "/").replace("/", "//");
    });
    return resp
  }

  selectedIndex: number = 0
  onTabChange(event: any) {
    this.selectedIndex = event.index || 0;
    const selectedTab: { name: string; value: string; } | undefined = this.tabs.find(
      ((item: any) => item?.name === event?.tab?.textLabel)
    )
    const type = selectedTab?.value || "trending"
    this.loadTutorials(type)
  }
  onItemClick(asset: SalesAsset) {

    switch (asset.field_assets_file_type.toLowerCase()) {
      // case SalesAssetsType.PROD_DATA_SHEETS:
      // case SalesAssetsType.CUSTOMER_PRESENTATIONS:
      // case SalesAssetsType.CUSTOMER_ONBOARDING_SOPS:
      // case SalesAssetsType.PRODUCT_VIDEOS:
      case "mpeg":
      case "mp4":
      case "video":
        this.dialog.open(VideoPlayerComponent, {
          height: '80%',
          width: '80%',
          data: { playbackUrl: asset.field_asserts_file }
        })
        break;
      case "pdf":
        window.open(asset.field_asserts_link, '_blank');
        break;
      default:
        const ext = this.util.getFileExtension(asset.field_asserts_file)
        this.util.downloadFile(asset.field_asserts_file, asset.title.replaceAll(' ', '-') + "." + ext)
        break;
    }
    // if (asset.field_assets_type === SalesAssetsType.PRODUCT_VIDEOS) {
    //   this.dialog.open(VideoPlayerComponent, {
    //     height: '80%',
    //     width: '80%',
    //     data: { playbackUrl: "https://" + asset.field_asserts_link }
    //   })
    // }
    // else
    //   this.dialog.open(DocumentPreviewComponent, {
    //     height: '80%',
    //     width: '80%',
    //     panelClass: 'modal-class',
    //     data: { link: asset.field_asserts_file },
    //     disableClose: true
    //   })
  }
  ngOnDestroy() {
    this.itemListSub$?.unsubscribe();
    this.tabsSub$?.unsubscribe();
  }
}
