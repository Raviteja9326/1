import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { Events } from 'src/app/models/app.enums';
// import { AddTenantComponent } from '../../shared/add-tenant/add-tenant.component';
import { EventBusService } from '../../shared/event-bus.service';
import { MyForecastService } from '../../shared/services/my-forecast.service';
import { appConfig } from 'src/app/app.config';
import { CommonUtilService } from '../../utils/common-util.service';

@Component({
  selector: 'app-my-forecast',
  templateUrl: './my-forecast.component.html',
  styleUrls: ['./my-forecast.component.scss']
})
export class MyForeCastComponent implements OnInit {
  clientChangeSub$!: Subscription;
  tenantSubscription$!: Subscription;
  tenantData: any;
  tenantGraphData: any = [];
  isLoading: boolean = false;

  constructor(private dialog: MatDialog, private eventBusService: EventBusService, private forecastService: MyForecastService, private util: CommonUtilService) {

  }

  ngOnInit(): void {
    if (this.util.getClientId())
      this.loadTenants();
      this.clientChangeSub$ = this.eventBusService.on(Events.ClientChanged, (arg: any) => {
      this.loadTenants();
    });
  }
  loadTenants() {
    this.isLoading = true
    const payload = {
      filter: {
        skip: 0,
        limit: 10
      }
    }
    this.tenantSubscription$ = this.forecastService.getMyTenants(payload).subscribe((resp: any) => {
      this.tenantData = resp.data.clients
      this.isLoading = false
      if (this.tenantData) {
        this.tenantGraphData = Object.entries(resp.data?.consolidatedStatusCount)
          .map(([name, value]) => ({
            name,
            value,
          }));
        this.tenantGraphData.forEach((tenant: any) => {
          tenant.name = tenant.name.replace(/([A-Z])/g, "-$1")
            .capitalize();
        });
      }
    });
  }

  // configuration for tenant-Table
  tableConfig: any = {
    hideOnClickOutside: true,
    showFooter: false,
    pagination: {
      pageSize: 2
    },
    columns: [
      {
        columnTitle: "Tenant Name",
        dataField: "name",
        headerStyle: {
          'width': '150px'
        },
      }, {
        columnTitle: "Status",
        dataField: "consolidatedStatus",
      }, {
        columnTitle: "Support",
        dataField: "supportLevelName",
        isFilterable: false,
        style: {
          'width': '100px'
        },
      }, {
        columnTitle: "Contact",
        dataField: "primaryContact",
        isFilterable: false,
        style: {
          width: '100px'
        }
      },
    ]
  }
  openModal() {
    // this.dialog.open(AddTenantComponent, {
    //   panelClass: 'add-tenant-container'
    // })
  }
  ngOnDestroy() {
    this.clientChangeSub$?.unsubscribe();
    this.tenantSubscription$?.unsubscribe();
  }
}
