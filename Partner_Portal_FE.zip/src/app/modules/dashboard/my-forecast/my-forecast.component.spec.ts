import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MyForeCastComponent } from './my-forecast.component';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { HttpClientModule } from '@angular/common/http';


describe('MyForeCastComponent', () => {
  let component: MyForeCastComponent;
  let fixture: ComponentFixture<MyForeCastComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyForeCastComponent ],
      imports:[HttpClientModule],
      providers: [{ provide: MatDialogRef, useValue: {} },{ provide: MatDialog, useValue: {} }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyForeCastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
