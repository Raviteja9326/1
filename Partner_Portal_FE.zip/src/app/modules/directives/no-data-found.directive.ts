import { Directive, Input, TemplateRef, ViewContainerRef, OnInit, SimpleChanges } from '@angular/core';
import { ComponentFactoryResolver } from '@angular/core';
import { NoDataFoundComponent } from './components/no-data-found/no-data-found.component';
declare var _: any;

@Directive({
  selector: '[noDataFound]'
})
export class NoDataFoundDirective implements OnInit {
  @Input() noDataFound: any;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver
  ) {}

  ngOnInit() {
    // this.updateView();
  }
  ngOnChanges(changes: SimpleChanges){
    this.updateView();
    
  }

  private updateView() {
    this.viewContainer.clear();
    // if (this.noDataFound && this.noDataFound.length === 0) {
    if (_.isEmpty(this.noDataFound)) {
      const factory = this.componentFactoryResolver.resolveComponentFactory(NoDataFoundComponent);
      this.viewContainer.createComponent(factory);
    } else {
      this.viewContainer.createEmbeddedView(this.templateRef);
    }
  }
}
