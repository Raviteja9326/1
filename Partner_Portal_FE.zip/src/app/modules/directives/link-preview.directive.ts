import { Directive, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DocumentPreviewComponent } from '../shared/components/document-preview/document-preview.component';

const ALLOWED_DOC_TYPES = ['pdf', 'xlsx', 'xls', 'pptx', 'ppt'];

@Directive({
  selector: '[appLinkPreview]'
})
export class LinkPreviewDirective {

  @HostListener('click', ['$event'])
  onClick(event: any) {
    const link = event.target.href;
    if (!link) return;
    const linkParts = link.split('.');
    const linkExtension = linkParts[linkParts.length - 1];
    if (ALLOWED_DOC_TYPES.includes(linkExtension)) {
      event.preventDefault();
      this.dialog.open(DocumentPreviewComponent, {
        height: '80%',
        width: '80%',
        panelClass: 'modal-class',
        data: { link: event.target.href },
        disableClose: true
      })
    }
  }

  constructor(private dialog: MatDialog) { }

}
