import { NoDataFoundDirective } from './no-data-found.directive';

describe('NoDataFoundDirective', () => {
  it('should create an instance', () => {
    const directive = new NoDataFoundDirective();
    expect(directive).toBeTruthy();
  });
});
