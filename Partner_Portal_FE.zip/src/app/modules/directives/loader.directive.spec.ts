import { LoaderDirective } from './loader.directive';

describe('LoaderDirective', () => {
  it('should create an instance', () => {
    let templateRef:any;
    let vcRef:any;
    let componentFactoryResolver:any
    const directive = new LoaderDirective(templateRef, vcRef, componentFactoryResolver);
    expect(directive).toBeTruthy();
  });
});
