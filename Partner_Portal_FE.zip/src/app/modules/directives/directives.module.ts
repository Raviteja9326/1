import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderDirective } from './loader.directive';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { LinkPreviewDirective } from './link-preview.directive';
import { CurrencyMaskDirective } from './curreny-mask.directive';
import { FocusFirstInvalidFieldDirective } from './focus-first-invalid-field.directive';
import { NoDataFoundDirective } from './no-data-found.directive';
import { MaterialModule } from '../shared/material/material.module';
import { NoDataFoundComponent } from './components/no-data-found/no-data-found.component';

const sharedComponents = [
  LoaderDirective,
  SpinnerComponent,
  LinkPreviewDirective,
  CurrencyMaskDirective,
  NoDataFoundDirective,
  FocusFirstInvalidFieldDirective,
  NoDataFoundComponent,
];
@NgModule({
  declarations: [
    ...sharedComponents,
  ],
  imports: [
    CommonModule,
    MaterialModule
  ],
  exports: [
    ...sharedComponents,
  ]

})
export class DirectivesModule { }
