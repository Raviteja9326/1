import { FocusFirstInvalidFieldDirective } from './focus-first-invalid-field.directive';

describe('FocusFirstInvalidFieldDirective', () => {
  it('should create an instance', () => {
    const directive = new FocusFirstInvalidFieldDirective();
    expect(directive).toBeTruthy();
  });
});
