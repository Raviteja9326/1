import { CurrenyMaskDirective } from './curreny-mask.directive';

describe('CurrenyMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new CurrenyMaskDirective();
    expect(directive).toBeTruthy();
  });
});
