import { Validators } from "@angular/forms";
import { environment } from "src/environments/environment";
import { NoWhitespaceValidator } from "./modules/validation/validators/no-whitespace-validator";
import { SmartTextEditorValidator } from "./modules/validation/validators/smart-text-editor-validator";
export enum ticketType {
  Incident = "TT_1",
  Problem = "TT_2"
}
export const appConfig: any = {
  blobConfig: {
    storage: environment.blobStorageConfig,
    blob: {
      maxSize: 100 * 1024 * 1024, //100 MB
      aspectRatio: { width: 220, height: 220, validate: true, tolerance: .1 },
      supportedExtn: [".png", ".jpg", ".jpeg"]
    },
    preview: {
      width: 300,
      flag: true
    },
    validate: true
    // sas: "sp=racwdli&st=2022-03-01T07:24:06Z&se=2022-09-30T15:24:06Z&sip=0.0.0.0-255.255.255.255&spr=https&sv=2020-08-04&sr=c&sig=OYqz6QRaZXKFjg8y0fBw8oehEhx%2FuX7eCfZopSmArmc%3D"
  },
  storageKeys: {
    reloading: "reloading",
    allRoles: "all-roles",
    loginType: "loginType",
    tokenLife: "token-life",
    permittedFeatures: "permitted-features"
  },
  minSearchTermlength:2,
  maxReloadingCount: 0,
  idleTimeout: 10, //in minutes
  adminActions: {
    "contact": ["create", "update", "delete"],
    "news": ["create", "update", "delete"],
    "product updates": ["create", "update", "delete"],
  },
  concierto: {
    storageKeys: {
      loginInfo: "concierto-login-info",
      accessToken: "access_token",
      refreshToken: "refresh_token",
    },
    maxTokenLife: 80, //in percentage of Token Life time
    config: {
      featureName: "Onboarding Wizard",
      originId: "RE_6232f7ec44548bf26a0d10b1",
      deviceId: "DM_5bf16c9f3310236c0482b8a4",
      sourceId: "FE_61a75a142626ed0017844d3a",
      phone: "918147855680", //currently hardcoded as we are not capturing mobile number
      sendAlertToUser: 1,    //not getting from UX
      vipUser: false,        //Not getting from UX

    }
  },
  drupal: {
    storageKeys: {
      loginInfo: "drupal-login-info",
      accessToken: "access_token",
      csrfToken: "csrf_token",
    },
    maxTokenLife: 80, //in percentage of Token Life time
  },
  clientMenu: [
    {
      name: "AWS",
      link: "",
      childrens: [
        {
          name: "Migration",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Cloud Ops",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Fin Ops",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Monitoring",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Analytics",
          link: "https://www.softwareone.com/en-us/",
        },
      ],
    },
    {
      name: "Azure",
      link: "",
      childrens: [
        {
          name: "Migration",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Cloud Ops",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Fin Ops",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Monitoring",
          link: "https://www.softwareone.com/en-us/",
        },
        {
          name: "Analytics",
          link: "https://www.softwareone.com/en-us/",
        },
      ],
    },
    // {
    //   name: "Lorem Ipsum",
    //   // link: "https://www.softwareone.com/en-us/",
    //   childrens: []
    // }
  ],
  textMaxLength: {
    xs: 100,
    sm: 255,
    md: 1000,
    lg: 10000
  }
};

export const maxLengthValidator = {
  singleLine: [
    Validators.required,
    NoWhitespaceValidator.isValid(),
    Validators.maxLength(appConfig.textMaxLength.sm)
  ],
  multiLine: [
    Validators.required,
    NoWhitespaceValidator.isValid(),
    Validators.maxLength(appConfig.textMaxLength.md)
  ],
  short: [
    Validators.required,
    NoWhitespaceValidator.isValid(),
    Validators.maxLength(appConfig.textMaxLength.sm)
  ],
  medium: [
    Validators.required,
    Validators.maxLength(appConfig.textMaxLength.md)
  ],
  long: [
    Validators.required,
    NoWhitespaceValidator.isValid(),
    Validators.maxLength(appConfig.textMaxLength.lg)
  ],
  small: [
    Validators.required,
    NoWhitespaceValidator.isValid(),
    Validators.maxLength(appConfig.textMaxLength.xs)
  ],
  smarteditor:[
    
      Validators.required,
      SmartTextEditorValidator.isValid(),
      Validators.maxLength(appConfig.textMaxLength.lg)
    
  ]
}


export const HOW_HEARD_ABOUT_US_LISTING = [
  "AWS MP",
  "Through existing Concierto Partner",
  "AWS Reference",
  "Events",
  "Social Channels",
  // "Other(Please Provide Details)"
];
export const INFRA_ENVIRONMENT_DETAILS=[
  "Hybrid Onprem + AWS +Azure",
  "Hybrid Onprem + AWS",
  "Mulitcloud + AWS + Azure",
  "On-Premise Only",
  "Other(Please Provide Details)"
];
export const PRODUCT_INTERESTED_IN=[
  "Concierto Migrate and Modernize",
  "Concierto Manage and Maximise",
  "Both"
];
export const PARTNER_TYPE=[
  "System Integrator",
  "Managed Service Provider",
  "ISV/Technology Partner",
  "Distributor",
  "Other(Please Provide Details)"
]


export const NEWS_CATEGORY_LISTING = [
  {
    categoryName: "ALL",
    href: "#all",
    id: "All",
    active: true,
    publishContent: "All",
  },
  {
    categoryName: "IT UPDATES",
    href: "#itupdates",
    id: "IT Updates",
    active: false,
    publishContent: "IT Updates",
  },
  {
    categoryName: "ORGANIZATION UPDATES",
    href: "#organizationupdates",
    id: "Organization Updates",
    active: false,
    publishContent: "Organization Updates",
  },
  {
    categoryName: "ANNOUNCEMENTS",
    href: "#announcements",
    id: "announcements",
    active: false,
    publishContent: "Announcements",
  },
];

export const PUBLISH_CONTENT_LISTING = [
  {
    active: true,
    publishContent: "All",
  },
  {
    active: false,
    publishContent: "IT Updates",
  },
  {
    active: false,
    publishContent: "Organization Updates",
  },
  {
    active: false,
    publishContent: "Announcements",
  },
  {
    active: false,
    publishContent: "Client Intro",
  },
];
