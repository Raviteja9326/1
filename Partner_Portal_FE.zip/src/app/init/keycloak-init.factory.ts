import { KeycloakService } from "keycloak-angular";
import { AuthenticationService } from "../modules/authentication/authentication.service";

export function initializeKeycloak(
  keycloak: KeycloakService, authService: AuthenticationService
) {
  return async () => {
    const config = await authService.getKeycloakConfig()
    return keycloak.init({
      config: {
        url: config.url,// 'https://signin-dev.concierto.cloud/auth',
        realm: config.realm,// 'trianz',
        clientId: config.clientId,
        // credentials:{
        //   secret:"140ba32e-c9ea-496e-a0f8-50421ff47ba6"
        // }

      },
      initOptions: {

        // pkceMethod: 'S256',
        // must match to the configured value in keycloak
        redirectUri: config.redirectUri,
        // this will solved the error
        // checkLoginIframe: true,
        // checkLoginIframeInterval: 25
      }
    });
  }
}
