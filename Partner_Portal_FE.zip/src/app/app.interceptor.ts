import { Injectable, isDevMode } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError, finalize, timeout } from "rxjs/operators";
import { AuthenticationService } from "./modules/authentication/authentication.service";
import { appConfig } from "./app.config";
import { Platform } from "./models/app.enums";
import { CommonUtilService } from "./modules/utils/common-util.service";
import { environment } from "src/environments/environment";
import { AlertUtility } from "./modules/utils/alert.util";
import _ from 'lodash';

@Injectable()
export class AppInterceptor implements HttpInterceptor {
  isSessionAlertOpened = false;
  private excludedUrlsRegex: RegExp[];
  private excludedUrls = [".svg"];

  constructor(
    private authService: AuthenticationService,
    private util: CommonUtilService,
    private alertUtil: AlertUtility) {
    this.excludedUrlsRegex = this.excludedUrls.map(urlPattern => new RegExp(urlPattern, 'i')) || [];
  }
  triggerLogout() {
    this.isSessionAlertOpened = false;
    localStorage.clear();
    location.reload();
  }
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const passThrough: boolean =
      !!this.excludedUrlsRegex.find(regex => regex.test(request.url));

    if (passThrough) {
      return next.handle(request);
    }
    const platform = this.getPlatform(request.url)
    const loginInfo = this.util.getLocalStorage(appConfig[platform].storageKeys.loginInfo)
    const conciertoLoginInfo = this.util.getLocalStorage(appConfig["concierto"].storageKeys.loginInfo)
    if (!this.isEmptyObject(loginInfo) && !request.url.toLowerCase().includes("getuserdetails")) {
      const headers = isDevMode() ? {} : { "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload" }
      request = request.clone({
        setHeaders: platform === Platform.Drupal ?
          _.merge(headers, this.getDrupalHeader(request, loginInfo, conciertoLoginInfo.clientId)) :
          _.merge(headers, this.getConciertoHeader(request, loginInfo))
      });
    }
    return this.callApi(next, request);

  }
  getDrupalHeader(request: HttpRequest<any>, loginInfo: any, clientId: string): { [name: string]: string | string[]; } | undefined {
    if (request.url.toLowerCase().includes("login")) return;
    let headers: any = {
      "Content-Type": "application/json",
      "X-CSRF-Token": loginInfo.csrf_token || "",
      Authorization: `Bearer ${loginInfo.access_token}`,
      jwt: `Bearer ${loginInfo.access_token}`,
      token: loginInfo.access_token,
    };
    if (!request.url.toLowerCase().includes("userinfo"))
      if (clientId)
        headers["Client-Id"] = clientId
      else
        this.handleError({ message: "ClientId not found!" }, request)
    return headers;
  }
  getPlatform(url: string) {
    const platform = url.includes(environment.endpoints[Platform.Concierto]) ? Platform.Concierto : Platform.Drupal
    return platform
  }

  private callApi(
    next: HttpHandler,
    request: HttpRequest<any>
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      // retry(2), //call two more times if the response is failed
      // timeout(3000),
      catchError((err) => {
        return this.handleError(err, request);
      }),
      finalize(() => {
        // this.showTokenInfo(Platform.Drupal);
      })
    );
  }
  private showTokenInfo(platform: string) {
    const loginInfo = this.util.getLocalStorage(
      appConfig[platform].storageKeys.loginInfo
    );
    const tokenLife: any = this.authService?.getTokenInfo(
      loginInfo.access_token
    );
    tokenLife.max = appConfig[platform].maxTokenLife;
    const isTokenExpired =
      Number(((tokenLife.duration - tokenLife.timePassed) / 60).toFixed(3)) <=
      0;
    if (isTokenExpired && !this.isSessionAlertOpened) {
      const config = {
        icon: "question",
        title: "Sorry for any inconvenience",
        message: "Your session has expired. Can you please Login again?",
        confirmButtonText: "Logout",
        confirmButtonCallback: this.triggerLogout,
        scope: this,
      };
      this.alertUtil.showQuestionAlert(config);
      this.isSessionAlertOpened = true;
    }
    console.log(
      `At ${new Date().toLocaleTimeString()},   ${platform.toUpperCase()} token: LIFE (${(
        (tokenLife.duration - tokenLife.timePassed) /
        60
      ).toFixed(3)} min), UPDATING after (${(
        ((tokenLife.max * tokenLife.duration) / 100 - tokenLife.timePassed) /
        60
      ).toFixed(3)} min)`
    );
  }

  private getConciertoHeader(request: HttpRequest<any>, loginInfo: any): any {
    if (request.url.toLowerCase().includes("login")) return;
    const drupalLoginInfo = this.util.getLocalStorage(appConfig.drupal.storageKeys.loginInfo)
    const headers: any = {
      realm: drupalLoginInfo.profile.realmid,
    }
    if (request.url.includes("uploadFileForClient")) {
      // headers['Content-Type'] = 'multipart/form-data'
      headers['Authorization'] = `Bearer ${loginInfo.access_token}`
    }
    else
      headers['Content-Type'] = 'application/json'

    return { ...headers, ...loginInfo.headers || {} }
  }

  /****************************************************************
   * This Error Handler should be responsible to handle all error
   * if there is anything goes wrong (return error code like 404,
   * oo1 etc) with api response. It will create a string with
   * status and error message and return the message as observable.
   ***************************************************************/
  private handleError(err: any, request: HttpRequest<any>) {
    if (!request.url.includes("logout")) {
      // console.error("Error Found: ", "Request Details:", request, "Error Details", err);
      this.alertUtil.notifyToast(err, "error");
    }
    return throwError(err);
  }

  private isEmptyObject(obj: any) {
    if (!obj) return;
    return !Object.keys(obj)?.length;
  }
}
