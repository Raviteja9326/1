import { Component, OnInit } from '@angular/core';
import { ResponseServiceProvider } from '../services/responses.service';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss']
})
export class ErrorComponent implements OnInit {

  engshow :boolean = false
  arabicshow:boolean = true

  constructor(private apis:ResponseServiceProvider) 
  {
    if(this.apis.catchlang == 'en'){
      this.engshow = true
      this.arabicshow= false
    }
    else  if(this.apis.catchlang == 'ar'){
      this.engshow = false
      this.arabicshow= true
    }
    console.log(this.apis.catchlang )
   }

  ngOnInit(): void {
  }

}
