import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { ArCelebComponent } from './arabic/celebrity/arceleb.component';
import { ArforgotpasswordComponent } from './arabic/general/forgotpassword/arforgotpassword.component';
import { ArLoginComponent } from './arabic/general/login/arlogin.component';
import { ArPrivacypolicyComponent } from './arabic/general/privacypolicy/arprivacypolicy.component';
import { ArRegisterComponent } from './arabic/general/register/arregister.component';
import { ArTermsconditonsComponent } from './arabic/general/termsconditons/artermsconditons.component';
import { ArUserComponent } from './arabic/user/aruser.component';
import { CelebComponent } from './english/celebrity/celeb.component';
import { ForgotpasswordComponent } from './english/general/forgotpassword/forgotpassword.component';
import { LoginComponent } from './english/general/login/login.component';
import { PrivacypolicyComponent } from './english/general/privacypolicy/privacypolicy.component';
import { RegisterComponent } from './english/general/register/register.component';
import { SearchComponent } from './english/general/search/search.component';
import { TermsconditonsComponent } from './english/general/termsconditons/termsconditons.component';
import { UserComponent } from './english/user/user.component';
import { ErrorComponent } from './error/error.component';

const routes: Routes = [
  { path: "login", component: LoginComponent},
  { path: "register", component: RegisterComponent},
  { path: "changepassword/:id", component: ForgotpasswordComponent},
  { path: "termsconditions", component: TermsconditonsComponent},
  { path: "privacypolicy", component: PrivacypolicyComponent},
  { path: "arlogin", component: ArLoginComponent},
  { path: "search", component: SearchComponent},
  { path: "error", component: ErrorComponent},
  { path: "arregister", component: ArRegisterComponent},
  { path: "arforgot", component: ArforgotpasswordComponent},
  { path: "artermsconditions", component: ArTermsconditonsComponent},
  { path: "arprivacypolicy", component: ArPrivacypolicyComponent},
  {path:'',redirectTo:'arhome',pathMatch:'full'},

  { 
    path: '', component: ArUserComponent,
    children: [
         {
            path: '', 
             loadChildren: () => import(`./arabic/user/aruser.module`).then(
               module => module.ArUserModule
             )
           }]
   },

   { path: '',component: ArCelebComponent,
     children: [
                 {
                    path: '', 
                     loadChildren: () => import(`./arabic/celebrity/arceleb.module`).then(
                       module => module.ArCelebModule
                     )
                   }]},
  
    { 
     path: '', component: UserComponent,
     children: [
          {
             path: '', 
              loadChildren: () => import(`./english/user/user.module`).then(
                module => module.UserModule
              )
            }]
    },

    { path: '',component: CelebComponent,
      children: [
                  {
                     path: '', 
                      loadChildren: () => import(`./english/celebrity/celeb.module`).then(
                        module => module.CelebModule
                      )
                    }]},
];

@NgModule({
  imports: [ CommonModule,BrowserModule,RouterModule.forRoot(routes,{useHash:true})],
  exports: [],
})
export class AppRoutingModule { }
