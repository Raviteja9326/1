import { DOCUMENT } from '@angular/common';
import { AfterViewInit, Component, DoCheck, ElementRef, Inject, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { interval } from 'rxjs';
declare let $:any
import { LoginRegisterService } from './services/login&register.service';
import { ResponseServiceProvider } from './services/responses.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, DoCheck{
  title = 'Mashhor';
  datamsg: string;
  sub:any;
  message: any;
  data:any;
  routerSubscription: any;

constructor(private router: Router,private service:ResponseServiceProvider, private user:LoginRegisterService, private elementRef: ElementRef) 
{

} 




 ngOnInit()
 {   
   this.router.events.subscribe((evt) => {
    if (!(evt instanceof NavigationEnd)) 
    {
        return;
    }
    window.scrollTo(0, 0)
});   
  }

 
  ngDoCheck() 
  { 
    this.service.currentMessage.subscribe(message =>{
      //console.log(message);
      this.data=message;
     })  
  }

 
  
  

 
 

}
