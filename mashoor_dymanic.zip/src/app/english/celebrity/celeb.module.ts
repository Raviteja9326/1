import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { celebroutes } from './celeb-routing.module';
import { celebProductModule } from './product/product.module';
import { celebDashboardModule } from './dashboard/dashboard.module';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(celebroutes),
    celebProductModule,
    celebDashboardModule,
  ]
})
export class CelebModule { }
