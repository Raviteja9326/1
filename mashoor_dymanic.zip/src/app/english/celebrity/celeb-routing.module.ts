import { Routes } from '@angular/router';

export const celebroutes: Routes = 
[

  { 
    path: 'celebrity', 
    loadChildren: () => import(`./dashboard/dashboard.module`).then(
      module => module.celebDashboardModule
    )
  },

 
];

