import { Component, ElementRef, OnInit } from '@angular/core';

@Component({
  selector: 'app-celeb',
  templateUrl: './celeb.component.html',
  styleUrls: ['./celeb.component.scss']
})
export class CelebComponent implements OnInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void 
  {

  }

}
