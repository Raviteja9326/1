import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Celebdashboardroutes } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { MybookingComponent } from './mybooking/mybooking.component';
import { ProfileComponent } from './profile/profile.component';
import { AddPostComponent } from './addposts/addpost.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdatepwdComponent } from './updatepwd/updatepwd.component';
import { GeneralModule } from '../../general/general.module';
import { WalletsComponent } from './wallet/wallet.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    GeneralModule,
    RouterModule.forChild(Celebdashboardroutes)
  ],
  declarations: [DashboardComponent, MybookingComponent, ProfileComponent,AddPostComponent, UpdatepwdComponent, WalletsComponent]
})
export class celebDashboardModule { }
