import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LoginRegisterService } from 'src/app/services/login&register.service';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

@Component({
  selector: 'app-mybooking',
  templateUrl: './mybooking.component.html',
  styleUrls: ['./mybooking.component.scss']
})
export class MybookingComponent implements OnInit {

  constructor(private apis:ResponseServiceProvider, private user:LoginRegisterService, private router:Router,private toastr:ToastrService) 
  { 
    if(this.apis.getdts == undefined)
    {
      this.apis.showmenu = true;
      this.apis.hidemenu = false;
      this.apis.celhidemenu = false;
      this.apis.getdts =false;
      this.apis.hidemenu1=false;
      this.apis.nameUser = undefined;
      this.apis.nextMessage("default message")
      this.toastr.success('Your Session Has Expired Please Login To Continue');
      this.router.navigate(['/login'])
    }
  }

  offsetFlag:boolean=true;

  ngOnInit(): void {
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  changar()
{
  this.apis.catchlang="ar"
}

}
