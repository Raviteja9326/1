import { Routes } from '@angular/router';
import { AddPostComponent } from './addposts/addpost.component';
import { DashboardComponent } from './dashboard.component';
import { MybookingComponent } from './mybooking/mybooking.component';
import { ProfileComponent } from './profile/profile.component';
import { UpdatepwdComponent } from './updatepwd/updatepwd.component';
import { WalletsComponent } from './wallet/wallet.component';

export const Celebdashboardroutes: Routes = 
[
  { path: '', component: DashboardComponent,
  children: [
    { path: 'customerwishrequests', component: MybookingComponent},
    { path: 'profile', component: ProfileComponent},
    { path: "postlist", component: AddPostComponent},
    { path: "resetpassword", component: UpdatepwdComponent},
    { path: "wallet", component: WalletsComponent},
  ]}
];

