import { Component, HostListener, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { CelebrityService } from 'src/app/services/celebrity.service';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
      const control = updateforgotpasswordform.controls[controlName];
      const matchingControl = updateforgotpasswordform.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-updatepwd',
  templateUrl: './updatepwd.component.html',
  styleUrls: ['./updatepwd.component.scss']
})
export class UpdatepwdComponent implements OnInit {
  fieldTextType:boolean;
  fieldTextType2:boolean;
  fieldTextType3:boolean;
  submitpass:boolean=false;
  better:any;
  offsetFlag:boolean=true;

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  changar()
  {
    this.apis.catchlang="ar"
  }

  updateforgotpasswordform = this.formBuilder.group({ 
    
    oldCred: ['', [Validators.required,spaceValidator]],
    newCred: ['', [Validators.required, spaceValidator,Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@('@')$!%*#?&{}[\]<>()~`"^_+=,.;:'&quot;/\\|-])[A-Za-z\d$@('@')$!%*#?&{}[\]<>()~`"^_+=;.,:'&quot;/\\|-]{8,20}$/)]],
    conformCred: ['', [Validators.required,spaceValidator,Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@('@')$!%*#?&{}[\]<>()~`"^_+=,.;:'&quot;/\\|-])[A-Za-z\d$@('@')$!%*#?&{}[\]<>()~`"^_+=;.,:'&quot;/\\|-]{8,20}$/)]],
  },{
    validator: MustMatch('newCred', 'conformCred')
  });

  get forgotpasswordControllers() { return this.updateforgotpasswordform.controls }

  constructor(private ngxLoader: NgxUiLoaderService, private formBuilder: FormBuilder, private router:Router,private user:CelebrityService, private apis:ResponseServiceProvider, private toastr:ToastrService) 
  { 
    if(this.apis.getdts == undefined)
    {
      this.apis.showmenu = true;
      this.apis.hidemenu = false;
      this.apis.celhidemenu = false;
      this.apis.getdts =false;
      this.apis.hidemenu1=false;
      this.apis.nameUser = undefined;
      this.apis.nextMessage("default message");
      this.toastr.success('Your Session Has Expired Please Login To Continue');
      this.router.navigate(['/login'])
    }
  }


  ngOnInit(): void {
  }



  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  toggleFieldTextType2() {
    this.fieldTextType2 = !this.fieldTextType2;
  }
  toggleFieldTextType3() {
    this.fieldTextType3 = !this.fieldTextType3;
  }

  Userupwds()
  {
    if (!this.updateforgotpasswordform.valid) {
      Object.keys(this.updateforgotpasswordform.controls).forEach(field => {
        const control:any = this.updateforgotpasswordform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitpass = true;
    }
  
  else {
    if(this.updateforgotpasswordform.value.newCred == this.updateforgotpasswordform.value.oldCred)
    {
      this.toastr.success("Old Password And New Password Should Not be Same");
    }
    else
    {
      this.ngxLoader.start();
      this.user.userprofileUpdtpwd(this.updateforgotpasswordform.value)
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res)
        if(res['status']=='1005'){
          this.toastr.success("Your password Sucessfully Updated");
          this.updateforgotpasswordform.reset();
          this.router.navigate(['/celebrity/profile'])
        }
       else if(res['status']=='1097'){
          this.toastr.success("Please Wait For 48hrs to Update NewPassword");
          this.updateforgotpasswordform.reset();
        }
     
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse();
           this.toastr.success(this.better);
           this.ngxLoader.stop()
        }
      })
      .add(this.ngxLoader.stop())
        }
  }
  }
}
