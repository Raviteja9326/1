import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FollowListComponent } from './follow-list/follow-list.component';
import { TwoDigitDecimaNumberDirective } from 'src/app/shared/directives/TwoDigitDecimaNumber.directive';



@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  declarations: [
    FooterComponent,
    HeaderComponent,
    SidebarComponent,
    FollowListComponent,
    TwoDigitDecimaNumberDirective

  ],
  exports: [
    TwoDigitDecimaNumberDirective,
    FooterComponent,
    HeaderComponent,
    SidebarComponent,
    FollowListComponent
  ]
})
export class GeneralModule { }
