import { Component, OnInit, ElementRef, Inject, HostListener, OnDestroy, AfterViewInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { filter, first } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';
declare let $:any

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy, AfterViewInit {

  imagesList:any=[];
  offsetFlag:boolean=true;
  hidecoming:boolean=false;
  celeblist:any;
  objectKeys = Object.keys;
  celebname:any;
  loadAPI: Promise<any>;
  baseUrl: any =  "https://images.mrmashhor.sa/profile/celebrity/";

  constructor( private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute, private router: Router, private apis:ResponseServiceProvider, private userService:UserService,private elementRef: ElementRef) 
  {
    this.Getbannerlist(); 
    this.Getceleblist();
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  changlagen(){
    this.apis.catchlang = "ar";
  }

  ngOnDestroy() 
  {  
  }

  ngAfterViewInit()
  {
    var s1 = document.createElement("script");
    s1.type = "text/javascript";
    s1.src = "/assets/js/mashhormain.js";
    this.elementRef.nativeElement.appendChild(s1);
  } 
 

  ngOnInit()
  {
    this.apis.catchlang = "en";
  }

  jqureyfiles()
  {
     
  }

  routeid(data)
  {
    console.log(data)
    this.router.navigate(['/categories',data])
  }

  Getbannerlist(){
    this.ngxLoader.start();
    this.userService.userbannerlst()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res);
      this.imagesList = res.bannerTypes_en;
    })
    .add(() => this.ngxLoader.stop());
    }

    Getceleblist(){
      this.ngxLoader.start();
      this.userService.usercelebritylst()
      .pipe(first())
      .subscribe((res:any) => {
        if(res['response']=='1005' && res['responseStatus']=='1094'){
        this.celeblist = res.responseList;
        console.log(this.celeblist)
        this.ngxLoader.stop();
        this.hidecoming = false
        }
        else if(res['responseStatus']=='1095'){
          this.hidecoming= true
        }
      })
      .add(() => this.ngxLoader.stop());
      }

      getcelebdatas(data)
      {
        console.log(data)
        this.celebname = data.firstName;
        this.router.navigate(['/details',data.categoryTypeEn,this.celebname])
      }
}
