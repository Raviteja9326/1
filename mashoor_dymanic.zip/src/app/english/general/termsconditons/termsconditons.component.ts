import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsconditons',
  templateUrl: './termsconditons.component.html',
  styleUrls: ['./termsconditons.component.scss']
})
export class TermsconditonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
