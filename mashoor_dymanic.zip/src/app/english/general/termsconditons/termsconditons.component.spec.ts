import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsconditonsComponent } from './termsconditons.component';

describe('TermsconditonsComponent', () => {
  let component: TermsconditonsComponent;
  let fixture: ComponentFixture<TermsconditonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TermsconditonsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TermsconditonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
