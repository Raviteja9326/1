import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { LoginRegisterService } from 'src/app/services/login&register.service';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { PhoneNumberValidator } from '../login/login.component';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
      const control = updateforgotpasswordform.controls[controlName];
      const matchingControl = updateforgotpasswordform.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.scss']
})
export class ForgotpasswordComponent implements OnInit {
  forgotform:FormGroup
  defaultlang: string;
  errormsg: string;
  msgdis1: boolean;
  succemsg: string;
  scmsgdis1:boolean= false;
  submitpass:boolean=false;
  fieldTextType2:boolean;
  fieldTextType3:boolean;
  id: any;
  better: string;

  constructor(private fb:FormBuilder,private router:Router,private route: ActivatedRoute,private forgotservice:LoginRegisterService, private ngxLoader: NgxUiLoaderService, private toastr:ToastrService, private apis:ResponseServiceProvider) 
  {
    this.id = this.route.snapshot.params['id'];
  }

  ngOnInit(): void {}
 
  updateforgotpasswordform = this.fb.group({ 
    
    newCred: ['', [Validators.required, spaceValidator,Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@('@')$!%*#?&{}[\]<>()~`"^_+=,.;:'&quot;/\\|-])[A-Za-z\d$@('@')$!%*#?&{}[\]<>()~`"^_+=;.,:'&quot;/\\|-]{8,20}$/)]],
    conformCred: ['', [Validators.required,spaceValidator,Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@('@')$!%*#?&{}[\]<>()~`"^_+=,.;:'&quot;/\\|-])[A-Za-z\d$@('@')$!%*#?&{}[\]<>()~`"^_+=;.,:'&quot;/\\|-]{8,20}$/)]],
    
  },
  
  {
    validator: MustMatch('newCred', 'conformCred')
  });

  get forgotpasswordControllers() { return this.updateforgotpasswordform.controls }

  toggleFieldTextType2() {
    this.fieldTextType2 = !this.fieldTextType2;
  }
  toggleFieldTextType3() {
    this.fieldTextType3 = !this.fieldTextType3;
  }

  updateSend()
  {

    if (!this.updateforgotpasswordform.valid) {
      Object.keys(this.updateforgotpasswordform.controls).forEach(field => {
        const control:any = this.updateforgotpasswordform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitpass = true;
    }
  
  else 
  {
    const obj:any={}

    obj['verifyKey'] = this.id;
    obj["deviceType"] = 'Web';
		obj["deviceId"] = "f6f1d0e2c1fcc8e72af497068f807a90";
    obj["ipAddress"]= "192.2.3.4";
    obj["latitude"]="NA";
    obj["longitude"]="NA";
    obj["language"]= "en",
    obj["newCred"]= this.updateforgotpasswordform.value.newCred;
    obj["conformCred"]= this.updateforgotpasswordform.value.conformCred;
    console.log(this.updateforgotpasswordform.value)
  
    this.ngxLoader.start(); 
    this.forgotservice.userpwdupdate(obj).subscribe((res:any) => {
      if(res["status"]=="1005")
      {
        this.toastr.success("Sucessfully Password changed");
        this.ngxLoader.stop();
        return this.router.navigate(['/login']);
      }
     else if(res["status"]=="1056")
      {
        this.toastr.success("Reset Password Link is Invalid");
        this.ngxLoader.stop();
      }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse();
           this.toastr.success(this.better);
           this.ngxLoader.stop()
        }
    })
    .add(this.ngxLoader.stopAll())
  }

  }

}
