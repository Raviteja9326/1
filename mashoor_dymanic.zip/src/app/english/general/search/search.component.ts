import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  searchlist: any;
  sugesstionstatus: boolean;
  sugeestionmsg: string;
  celebname: any;
  engshow :boolean = false
  arabicshow:boolean = true
  arcelebname: any;

  constructor(private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseServiceProvider, private userService:UserService,public dialogRef: MatDialogRef<SearchComponent>,@Inject(MAT_DIALOG_DATA) public data: any,) {
    
    if(this.apis.catchlang == 'en'){
      this.engshow = true
      this.arabicshow= false
    }
    else  if(this.apis.catchlang == 'ar'){
      this.engshow = false
      this.arabicshow= true
    }
    console.log(this.apis.catchlang )
   }

  ngOnInit(): void {
  }

  getcelebrity(data)
  {
    this.celebname = data.firstName;
    this.router.navigate(['/details',data.categoryNameEn,this.celebname])
    this.dialogRef.close();

  }
  argetcelebrity(data)
  {
    this.arcelebname = data.firstName;
    this.router.navigate(['/ardetails',data.categoryNameEn,this.arcelebname])
    this.dialogRef.close();

  }
  onSearchChange(searchValue) {  

    if(searchValue == "" ){
      this.searchlist=[]
    }
        const object={}
        object[ 'searchName']=searchValue
            this.userService.autosuggestions(object).subscribe(res =>{
              console.log(res) 
             

              if( res['responseStatus']=='1005'){
                 
                  // console.log( this.searchlist)
                  // console.log( this.searchlist.firstName)

                  if(res.response.length == 0){
                      this.searchlist =[]
                      this.sugesstionstatus=true
                  }
                  else{
                      this.sugesstionstatus=false
                      this.searchlist =res.response
                  }
                }
                
              
              else if(res['responseStatus']=='1095'){
                 this.ngxLoader.stop()
                 this.searchlist =''
              }
             
             
            }) 
      }
}
