import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { CelebrityService } from 'src/app/services/celebrity.service';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-follow-list',
  templateUrl: './follow-list.component.html',
  styleUrls: ['./follow-list.component.scss']
})
export class FollowListComponent implements OnInit {

  getdts:boolean = false;
  getdts2:boolean = false;
  followList: any;
  followerList: any;
  followcount: any;
  better:string
  followrstatus: boolean;
  celbfollowrstatus: boolean;
  baseurl="https://images.mrmashhor.sa/profile/users/"
  baseurl2="https://images.mrmashhor.sa/profile/celebrity/"
  favfollowcount: any;
  id: any;
  celebname: any;

  constructor(private apis:ResponseServiceProvider,private route: ActivatedRoute,private userService:UserService,private router:Router, private celbService: CelebrityService ,private ngxLoader: NgxUiLoaderService) 
  {
     this.hidefunc()
  }


  hidefunc()
  {
    if(this.apis.getdts==true)
    {
      this.getfollowlist()

      this.getdts2 = false;
      this.getdts = true;
    }
   else if(this.apis.getdts==false)
   {
    this.getfollowerList()

    this.getdts = false;
    this.getdts2 = true;
  }
    }

    ngOnInit()
    {
      this.route.params.subscribe(routeParams => {
        console.log(routeParams)
        this.id = routeParams.id;
       
      });
    }


    getcelebdatas(data)
    {
      console.log(data)
      this.router.navigate(['/details',data.categoryEn,data.name])
    }
    
    getfollowlist(){
      console.log("followlist")
      this.ngxLoader.start();
     
      this.userService.followList()
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res)
      

        if( res['Token_Status']=='1060'){
       
          if(res.status == "1095"){
            this.followrstatus = true
          }
          else{
            this.followList = res.favCelebrityList;
            this.favfollowcount =res.favCelebrityCount
            this.followrstatus = false
  
  
          }
        }
      
     if(res['Token_Status']=='1061'){
      this.better = "Your Session Has Expired";
      this.apis.nextMessage("default message")
      this.ngxLoader.stop();
      this.router.navigate(['/login'])
    }
    else if(res['Token_Status']=='1094'){
       this.ngxLoader.stop()
    }
    else if(res['Token_Status']=='1095'){
      this.ngxLoader.stop()
      console.log("nodata")
   }
    else if(res['Token_Status']){
      this.apis.getallres = res['Token_Status'] ;
       this.better = this.apis.allrespnse();
       this.ngxLoader.stop()
    }
      })
      .add(() => this.ngxLoader.stop());
      }
  getfollowerList(){
  console.log("followerslist")
      this.ngxLoader.start();
     
      this.celbService.followerList()
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res)
      
        if( res['tokenStatus']=='1060'){
      

          if(res.status == "1095"){
           this.celbfollowrstatus = true
         }
         else{
           this.celbfollowrstatus=false
           this.followerList = res.usersList;
           this.followcount =res.Celebrity_FollowCount     
          }
         }
      
     if(res['tokenStatus']=='1061'){
      this.better = "Your Session Has Expired";
      this.apis.nextMessage("default message")
      this.ngxLoader.stop();
      this.router.navigate(['/login'])
    }
    else if(res['tokenStatus']=='1094'){
       this.ngxLoader.stop()
    }
    else if(res['tokenStatus']=='1095'){
      this.ngxLoader.stop()
      console.log("nodata")
   }
    else if(res['tokenStatus']){
      this.apis.getallres = res['tokenStatus'] ;
       this.better = this.apis.allrespnse();
       this.ngxLoader.stop()
    }
       
      })
      .add(() => this.ngxLoader.stop());
}
}
