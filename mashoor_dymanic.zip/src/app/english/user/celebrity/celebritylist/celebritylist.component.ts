import { AfterViewChecked, Component, ElementRef, HostListener, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { UserService } from 'src/app/services/user.service';
import { first } from 'rxjs/operators';
import { DOCUMENT } from '@angular/common';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

@Component({
  selector: 'app-celebritylist',
  templateUrl: './celebritylist.component.html',
  styleUrls: ['./celebritylist.component.scss']
})
export class CelebritylistComponent implements OnInit  {

  id:any;
  celeblist:any;
  keys:any;
  hidecoming:boolean;
  celebname:any;
  offsetFlag:boolean=true;
  baseUrl: any =  "https://images.mrmashhor.sa/profile/celebrity/";
  

  constructor(private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router,private elementRef: ElementRef,@Inject(DOCUMENT) private doc, private apis:ResponseServiceProvider) 
  {
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  ngOnInit(): void { 
    this.route.params.subscribe(routeParams => {
    console.log(routeParams)
    this.id = routeParams.id
    this.Getceleblists();
	}); }


  clickar(data)
  {
console.groupCollapsed(data)
this.router.navigate(['/arcategories',this.id])
  }



  Getceleblists(){
    this.ngxLoader.start();
    this.userService.usercelebritylst()
    .pipe(first())
    .subscribe((res:any) => {
      if(res['response']=='1005' && res['responseStatus']=='1094'){
        this.celeblist = res.responseList[this.id];
        this.ngxLoader.stop();
        this.hidecoming = false
        }
        else if(res['responseStatus']=='1095'){
          this.hidecoming= true
        }
    
    })
    .add(() => this.ngxLoader.stop());
    }

    getcelebdatas(data)
    {
      this.celebname = data.firstName;
      this.router.navigate(['/details',this.id,this.celebname])
    }


    onclickid()
    {
      this.router.navigate(['/ArUserCelebrity/Arlist', this.id])
    }

}
