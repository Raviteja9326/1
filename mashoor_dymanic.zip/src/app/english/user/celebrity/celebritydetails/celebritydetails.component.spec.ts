import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CelebritydetailsComponent } from './celebritydetails.component';

describe('CelebritydetailsComponent', () => {
  let component: CelebritydetailsComponent;
  let fixture: ComponentFixture<CelebritydetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CelebritydetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CelebritydetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
