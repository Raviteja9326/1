import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookvideoComponent } from './bookvideo.component';

describe('BookvideoComponent', () => {
  let component: BookvideoComponent;
  let fixture: ComponentFixture<BookvideoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookvideoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
