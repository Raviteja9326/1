import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookvideo',
  templateUrl: './bookvideo.component.html',
  styleUrls: ['./bookvideo.component.scss']
})
export class BookvideoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
