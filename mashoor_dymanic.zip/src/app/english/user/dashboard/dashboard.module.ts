import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { userdashboardroutes } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { WalletComponent } from './wallet/wallet.component';
import { AddressComponent } from './address/address.component';
import { UpdatepasswordComponent } from './updatepassword/updatepassword.component';
import { BooklistComponent } from './booklist/booklist.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PostlistComponent } from './postlist/postlist.component';
import { GeneralModule } from '../../general/general.module';
import { ProgressiveImageModule } from 'src/app/progressive-image/progressive-image.module';


@NgModule({
  imports: [
    ReactiveFormsModule,
    ProgressiveImageModule,
    FormsModule,
    CommonModule,
    GeneralModule,
    RouterModule.forChild(userdashboardroutes)
  ],
  declarations: [DashboardComponent, UserprofileComponent, WalletComponent, AddressComponent, UpdatepasswordComponent, BooklistComponent, PostlistComponent]
})
export class UserDashboardModule { }
