import { Component, OnInit } from '@angular/core';
import {HostListener } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';



export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.scss']
})
export class WalletComponent implements OnInit {

  offsetFlag:boolean = true;



  constructor(private ngxLoader: NgxUiLoaderService, private formBuilder: FormBuilder, private router:Router,private user:UserService, private apis:ResponseServiceProvider, private toastr:ToastrService) 
  { 
    if(this.apis.getdts == undefined)
    {
      this.apis.showmenu = true;
      this.apis.hidemenu = false;
      this.apis.celhidemenu = false;
      this.apis.getdts =false;
      this.apis.hidemenu1=false;
      this.apis.nameUser = undefined;
      this.apis.nextMessage("default message");
      this.toastr.success('Your Session Has Expired Please Login To Continue');
      this.router.navigate(['/login'])
    }
  }


  updateMoneyForm = this.formBuilder.group({ 
    
    amount: ['', [Validators.required,spaceValidator]],
  });

  get userWalletControllers() { return this.updateMoneyForm.controls }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
 }

  ngOnInit(): void {
  }

  changar()
  {
    this.apis.catchlang="ar"
  }



  UserWallet()
  {
    console.log(this.updateMoneyForm.value)
    this.user.Useraddbalance(this.updateMoneyForm.value)
  .pipe(first())
  .subscribe((res:any) => {
    console.log(res)
  })
}
  


}
