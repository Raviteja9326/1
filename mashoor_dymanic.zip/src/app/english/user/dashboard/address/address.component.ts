import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';
import {HostListener } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit {

  addressData:any;
  profileshow:boolean=true;
  profilehide:boolean=false;
  hidebtn:boolean=false;
  showbtn:boolean=true;
  showaddbtn:boolean=true;
  hideaddbtn:boolean = false;
  submitted:boolean=false;
  offsetFlag:boolean = true;
  objectKeys = Object.values;

  profileupdateform = this.formBuilder.group({
    addressLine1: [''],
      addressLine2: [''],
      addressLine3 : [''],
      city :[''],
      state : [''],
      country : [''],
      postalCode : [''],
      isPrimary:['']
  })
  better: string;

  constructor(private users:UserService, private apis:ResponseServiceProvider, private ngxLoader: NgxUiLoaderService, private formBuilder: FormBuilder, private router:Router, private toastr:ToastrService) 
  { 
    this.getuserprofiledata();
    if(this.apis.getdts == undefined)
    {
      this.apis.showmenu = true;
      this.apis.hidemenu = false;
      this.apis.celhidemenu = false;
      this.apis.getdts =false;
      this.apis.hidemenu1=false;
      this.apis.nameUser = undefined;
      this.apis.nextMessage("default message");
      this.toastr.success('Your Session Has Expired Please Login To Continue');
      this.router.navigate(['/login'])
    }
  }

  ngOnInit(): void 
  {
    this.togglenable()
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
 }

 changar()
 {
   this.apis.catchlang="ar"
 }

  getuserprofiledata()
  {
    this.ngxLoader.start();
    this.users.getUseraddress()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res)
      if( res['tokenStatus']=='1060'){
        console.log(res)
    for(let keys of Object.values(res['customerAddress']))
    {
      this.addressData = keys
    }
        this.updateaddress();
      }
      if(res['tokenStatus']=='1061'){
        this.better = "Your Session Has Expired";
        this.apis.nextMessage("default message")
        this.ngxLoader.stop();
        this.router.navigate(['/login'])
      }
      else if(res['tokenStatus']=='1094'){
         this.ngxLoader.stop()
      }
      else if(res['tokenStatus']=='1095'){
        this.ngxLoader.stop()
        console.log("nodata")
     }
      else if(res['tokenStatus']){
        this.apis.getallres = res['tokenStatus'] ;
         this.better = this.apis.allrespnse();
         this.ngxLoader.stop()
      }
    })
    .add(() => this.ngxLoader.stop());
  
}



toggleDisable() {
  this.profileupdateform.get('addressLine1').enable();
  this.profileupdateform.get('addressLine2').enable();
  this.profileupdateform.get('addressLine3').enable();
  this.profileupdateform.get('city').enable();
  this.profileupdateform.get('country').enable();
  this.profileupdateform.get('isPrimary').enable();
  this.profileupdateform.get('postalCode').enable();
  this.profileupdateform.get('state').enable();
  this.showbtn = false;
  this.hidebtn = true;
  this.showaddbtn =false;
  this.hideaddbtn = false;
}

togglenable()
{
  this.showbtn = true;
  this.hidebtn = false;
  this.showaddbtn =true;
  this.hideaddbtn = false;
  this.profileupdateform.get('addressLine1').disable();
  this.profileupdateform.get('addressLine2').disable();
  this.profileupdateform.get('addressLine3').disable();
  this.profileupdateform.get('city').disable();
  this.profileupdateform.get('country').disable();
  this.profileupdateform.get('isPrimary').disable();
  this.profileupdateform.get('postalCode').disable();
  this.profileupdateform.get('state').disable();
  this.getuserprofiledata();
}

toggleDisables()
{
  this.profileupdateform.get('addressLine1').enable();
  this.profileupdateform.get('addressLine2').enable();
  this.profileupdateform.get('addressLine3').enable();
  this.profileupdateform.get('city').enable();
  this.profileupdateform.get('country').enable();
  this.profileupdateform.get('isPrimary').enable();
  this.profileupdateform.get('postalCode').enable();
  this.profileupdateform.get('state').enable();
  this.showbtn = false;
  this.hidebtn = false;
  this.showaddbtn =false;
  this.hideaddbtn = true;
}

getdatadd()
{
  if (!this.profileupdateform.valid) {
    Object.keys(this.profileupdateform.controls).forEach(field => {
      const control:any = this.profileupdateform.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    this.submitted = true;
  }
  else
  {
    this.ngxLoader.start();
    this.users.useraddad(this.profileupdateform.value)
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res) 
      })
      .add(() => this.ngxLoader.stop());
  }
}

getdatas()
  {
    if (!this.profileupdateform.valid) {
      Object.keys(this.profileupdateform.controls).forEach(field => {
        const control:any = this.profileupdateform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }
    else
    {
     
   const objk:any={};
   objk['id'] = this.addressData['id']
      this.ngxLoader.start();
      this.users.useraddupd(this.profileupdateform.value, objk)
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res) 
        if(res['response']=='1005' && res['tokenStatus']=='1060'){
          console.log("sucellfuly")
          this.togglenable();
        }
       else if(res['response']=='1006' || res['tokenStatus']=='1061'){
          this.better = "Your Session Has Expired";
          this.apis.nextMessage("default message")
          this.ngxLoader.stop();
          this.router.navigate(['/login'])
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse();
           console.log(this.better)
           this.ngxLoader.stop()
        }
        })
        .add(() => this.ngxLoader.stop());
    }
  }

updateaddress()
{
  console.log("asdddddd")
  this.ngxLoader.start();
  this.profilehide=true;
  this.profileshow=false;
  this.profileupdateform.setValue({
    addressLine1 : this.addressData['addressLine1'],
    addressLine2 : this.addressData['addressLine2'],
    addressLine3 : this.addressData['addressLine3'],
    country: this.addressData['country'],
    city: this.addressData['city'],
    isPrimary : this.addressData['isPrimary'],
    postalCode : this.addressData['postalCode'],
    state:this.addressData['state']
  });
  console.log(this.profileupdateform.value)
  this.ngxLoader.stop();
}

updateprofiledetails()
  {
    this.ngxLoader.start();
    this.profilehide=false;
    this.profileshow=true;
    this.showaddbtn = false;
    this.ngxLoader.stop();
  }

}
