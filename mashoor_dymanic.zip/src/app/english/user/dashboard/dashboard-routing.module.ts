import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { WalletComponent } from './wallet/wallet.component';
import { AddressComponent } from './address/address.component';
import { UpdatepasswordComponent } from './updatepassword/updatepassword.component';
import { BooklistComponent } from './booklist/booklist.component';
import { PostlistComponent } from './postlist/postlist.component';

export const userdashboardroutes: Routes = 
[
  { path: '', component: DashboardComponent,
  children: [
    { path: 'profile', component: UserprofileComponent},
    { path: 'wallet', component: WalletComponent},
    { path: 'address', component: AddressComponent},
    { path: 'resetpassword', component: UpdatepasswordComponent},
    { path: 'booklist', component: BooklistComponent},
    { path: "postlist", component: PostlistComponent},
  ]}
];

