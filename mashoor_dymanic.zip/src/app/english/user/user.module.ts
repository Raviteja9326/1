import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { userroutes } from './user-routing.module';
import { UserDashboardModule } from './dashboard/dashboard.module';
import { UserProductModule } from './product/product.module';
import { HomeComponent } from '../general/home/home.component';
import { CelebritydetailsComponent } from './celebrity/celebritydetails/celebritydetails.component';
import { CelebritylistComponent } from './celebrity/celebritylist/celebritylist.component';
import { ProgressiveImageModule } from 'src/app/progressive-image/progressive-image.module';
import { BookvideoComponent } from './celebrity/bookvideo/bookvideo.component';
import { CartComponent } from './celebrity/cart/cart.component';


@NgModule({
  imports: [
    CommonModule,
    ProgressiveImageModule,
    RouterModule.forChild(userroutes),
    UserProductModule,
    UserDashboardModule
  ],
  declarations: [HomeComponent,CelebritydetailsComponent,CelebritylistComponent, BookvideoComponent, CartComponent]
})
export class UserModule { }
