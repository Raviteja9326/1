import { Routes } from '@angular/router';
import { HomeComponent } from '../general/home/home.component';
import { CartComponent } from './celebrity/cart/cart.component';
import { CelebritydetailsComponent } from './celebrity/celebritydetails/celebritydetails.component';
import { CelebritylistComponent } from './celebrity/celebritylist/celebritylist.component';

export const userroutes: Routes = 
[
  { path: 'home', component: HomeComponent },

  { path: "details/:id/:id1", component: CelebritydetailsComponent},

  { path: "categories/:id", component: CelebritylistComponent},

  { path: "cart", component: CartComponent},

  { 
    path: 'customer', 
    loadChildren: () => import(`./dashboard/dashboard.module`).then(
      module => module.UserDashboardModule
    )
  },
];

