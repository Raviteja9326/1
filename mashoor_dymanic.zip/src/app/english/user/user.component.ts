import { DOCUMENT } from '@angular/common';
import { AfterViewChecked, AfterViewInit, Component, DoCheck, ElementRef, Inject, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit, DoCheck, OnDestroy  {

  routerSubscription: any;
  constructor(private apis:ResponseServiceProvider, private elementRef: ElementRef, private router: Router, ) 
  {
    this.apis.catchlang = "en";
  }
  ngOnInit(): void 
  { 
  }

  ngDoCheck()
  {
  }


  ngOnDestroy() 
  {  
  }

  
 


}