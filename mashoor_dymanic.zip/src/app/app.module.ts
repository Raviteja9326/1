import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { MaterialModule } from './shared/material.module';
import { NgxUiLoaderConfig, NgxUiLoaderModule, SPINNER, POSITION,PB_DIRECTION, NgxUiLoaderRouterModule, NgxUiLoaderService } from 'ngx-ui-loader';
import { NgOtpInputModule } from  'ng-otp-input';
import { ToastrModule,ToastrService } from 'ngx-toastr';
import { LoginComponent } from './english/general/login/login.component';
import { RegisterComponent } from './english/general/register/register.component';
import { UserComponent } from './english/user/user.component';
import { CelebComponent } from './english/celebrity/celeb.component';
import { ForgotpasswordComponent } from './english/general/forgotpassword/forgotpassword.component';
import { TermsconditonsComponent } from './english/general/termsconditons/termsconditons.component';
import { PrivacypolicyComponent } from './english/general/privacypolicy/privacypolicy.component';
import { GeneralModule } from './english/general/general.module';
import { ArLoginComponent } from './arabic/general/login/arlogin.component';
import { ArRegisterComponent } from './arabic/general/register/arregister.component';
import { ArforgotpasswordComponent } from './arabic/general/forgotpassword/arforgotpassword.component';
import { ArTermsconditonsComponent } from './arabic/general/termsconditons/artermsconditons.component';
import { ArPrivacypolicyComponent } from './arabic/general/privacypolicy/arprivacypolicy.component';
import { ArGeneralModule } from './arabic/general/argeneral.module';
import { ArUserComponent } from './arabic/user/aruser.component';
import { ArCelebComponent } from './arabic/celebrity/arceleb.component';
import { ErrorIntercept } from './services/exception.interceptor';
import { ImageDirective } from './shared/img';
import { CountdownModule } from 'ngx-countdown';
import { SearchComponent } from './english/general/search/search.component';
import { ErrorComponent } from './error/error.component';



const ngxUiLoaderConfig: NgxUiLoaderConfig =
{
    "bgsColor": "#f5ab17",
    "bgsOpacity": 0.5,
    "bgsPosition": "center-center",
    "bgsSize": 60,
    "bgsType": "three-strings",
    "blur": 5,
    "delay": 0,
    "fastFadeOut": true,
    "fgsColor": "#f5ab17",
    "fgsPosition": "center-center",
    "fgsSize": 60,
    "fgsType": "three-strings",
    "gap": 24,
    "logoPosition": "center-center",
    "logoSize": 120,
    "logoUrl": "",
    "masterLoaderId": "master",
    "overlayBorderRadius": "0",
    "overlayColor": "rgba(40, 40, 40, 0.8)",
    "pbColor": "#f5ab17",
    "pbDirection": "ltr",
    "pbThickness": 3,
    "hasProgressBar": true,
    "text": "",
    "textColor": "#FFFFFF",
    "textPosition": "center-center",
    "maxTime": -1,
    "minTime": 300
}


@NgModule({
  declarations: [
    AppComponent,
    ArLoginComponent,
    ArRegisterComponent,
    LoginComponent,
    SearchComponent,
    ImageDirective,
    RegisterComponent,
    ArCelebComponent,
    UserComponent,
    CelebComponent,
    ArUserComponent,
    ForgotpasswordComponent,
    TermsconditonsComponent,
    PrivacypolicyComponent,
    ArforgotpasswordComponent,
    ArTermsconditonsComponent,
    ArPrivacypolicyComponent,
    ErrorComponent
  ],
  imports: [
    CountdownModule,
    NgOtpInputModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgxUiLoaderRouterModule,
    MaterialModule,
    RouterModule,
    GeneralModule,
    ArGeneralModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 6000,
      positionClass: "toast-top-right",
      preventDuplicates: true,
      closeButton: false,
      newestOnTop: true,
      extendedTimeOut: 1800
    }),
  ],
  exports: [ImageDirective],
  entryComponents: [SearchComponent],
  providers: [ToastrService,{
    provide: HTTP_INTERCEPTORS,
    useClass: ErrorIntercept,
    multi: true,
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
