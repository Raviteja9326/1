export enum Display {
  flex = 'flex',
  none = 'none'
}
export abstract class Dimensions {
  width: number;
  height: number;
}
