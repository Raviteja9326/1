import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ResponseServiceProvider } from './responses.service';
const baseUrl = `${environment.baseUrl}/v1`;


@Injectable({
  providedIn: 'root'
})
export class CelebrityService {

  datas:any
  constructor(private http:HttpClient, private api:ResponseServiceProvider) { }


  getpostlist() :Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    console.log(this.api.accesstoken)
  return this.http.post<any>(baseUrl+'/celeberitylikesandcomments',this.datas,httpOptions)
  }
  followerList():Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    console.log(this.api.accesstoken)

    return this.http.post<any>(baseUrl+'/getcelebrityfollowinglist',this.datas,httpOptions)
  }
  postMessage(obj):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    return this.http.post<any>(baseUrl+'/post/message',obj,httpOptions)
  }
  deleteMsg(obj):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    return this.http.post<any>(baseUrl+'/delete/message',obj,httpOptions)
  }

   // profile Details
   getUserProfile() :Observable<any>{
    console.log(this.api.accesstoken)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
  return this.http.post<any>(baseUrl+'/getCelebrityProfileDetails',this.api.getResponse(),httpOptions)
  }

  userprofileUpdt(obj:any){
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    //console.log(this.api.accesstoken)
  return this.http.post<any>(baseUrl+'/updateCelebrityProfileDetails',obj,httpOptions)
  }

  userprofileUpdtpwd(obj:any){
    const obj2 = Object.assign({}, obj, this.api.getResponse());
    //console.log(obj2)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    //console.log(this.api.accesstoken)
  return this.http.post<any>(baseUrl+'/changeCred',obj2,httpOptions)
  }

}
