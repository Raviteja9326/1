import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ResponseServiceProvider } from './responses.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
const baseUrl = `${environment.baseUrl}/v1`;

@Injectable({
  providedIn: 'root'
})
export class LoginRegisterService {
  baseUrl: string;
  datas:any;
  better: string;

  constructor(private http:HttpClient, private apis:ResponseServiceProvider,private ngxLoader: NgxUiLoaderService, private router:Router, private toastr:ToastrService ) {

    this.baseUrl=environment.baseUrl
   }

   userlogout(){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.apis.accesstoken)
      })
    }
  return this.http.post<any>(baseUrl+'/logout',this.datas,httpOptions)
  }

   userRefreshtoken(){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.apis.accesstoken)
      })
    }
    console.log("werrrrrrr",this.apis.accesstoken)
  return this.http.post<any>(baseUrl+'/refreshtoken',this.datas,httpOptions)
  }


  usermobilelogin(mobilenumber ,password):Observable<any> {
    console.log(mobilenumber,password)
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          // 'X-XSRF-TOKEN': this.csrftoken,
          'Authorization': 'Basic ' + btoa(mobilenumber + ':' + password)
        })
    
      }
      return this.http.post<any>(baseUrl+'/login/credentials',this.apis.getResponse(),httpOptions);
    }
 

    userregistration(obj,mobilenumber ,password):Observable<any> {
      let authorizationData = 'Basic ' + btoa(mobilenumber + ':' + password);
      console.log(obj)
      const httpOptions = {
        headers: new HttpHeaders({
          'Authorization': authorizationData
        })
      }
        return this.http.post<any>(baseUrl+'/register/verifyMobnEmail/otp',obj,httpOptions)
      }

      registerOtp(obj,mobilenumber ,password):Observable<any> {
        let authorizationData = 'Basic ' + btoa(mobilenumber + ':' + password);
        console.log(obj)
        const httpOptions = {
          headers: new HttpHeaders({
            'Authorization': authorizationData
          })
        }
          return this.http.post<any>(baseUrl+'/register/verifyOTP',obj,httpOptions)
        }

        userpwdupdate(object:any){
        return this.http.post<any>(baseUrl+'/forget/cred/link/updateCred',object)
        }

        categorylist():Observable<any> {
            const httpOptions = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
              })
            }
            return this.http.post<any>(this.baseUrl+'v1/categories/list',httpOptions)
          }


          forgotpasswordlink(mobilenumber):Observable<any> {

            console.log(mobilenumber)
            const httpOptions = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
             
                // 'X-XSRF-TOKEN': this.csrftoken,
                'Authorization': 'Basic ' + btoa(mobilenumber )
              })
          
            }
              return this.http.post<any>(baseUrl+'/forget/cred/link',this.apis.getResponse(),httpOptions)
            }

            getlogout(){
              this.ngxLoader.start();
              this.userlogout()
              .pipe(first())
              .subscribe((res:any) => {
                console.log(res)
                this.apis.showmenu = true;
                this.apis.hidemenu = false;
                this.apis.celhidemenu = false;
                this.apis.getdts =false
                this.apis.nameUser = undefined;
                this.apis.nextMessage("default message");
                this.toastr.success('logout sucessfully');
                 this.router.navigate(['/home'])
                 this.ngxLoader.stop();  
              })
              .add(() => this.ngxLoader.stop());
              }


              getlogout2(){
                this.ngxLoader.start();
                this.userlogout()
                .pipe(first())
                .subscribe((res:any) => {
                  console.log(res)
                  this.apis.showmenu = true;
                this.apis.hidemenu = false;
                this.apis.celhidemenu = false;
                this.apis.getdts =false
                this.apis.nameUser = undefined;
                  this.apis.nextMessage("default message");
                  this.toastr.success('مرحبًا ، انتهت جلستك');
                   this.router.navigate(['/arhome'])
                   this.ngxLoader.stop();  
                })
                .add(() => this.ngxLoader.stop());
                }
      
}


