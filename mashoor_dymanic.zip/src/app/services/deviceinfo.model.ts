export class deviceinfo {
    deviceId: string;
    deviceType: string;
    deviceService: string;
    latitude: string;
    logintude: string;
    longitude: string;
    ipAddress: string;
    browserType:string;
    browserVersion:string;
    osType:string;
    osVersion:string;
    accesstoken:string;

    constructor(devicedata?) {
        this.deviceId = '';
        this.deviceType = 'Web';
        this.latitude = '';
        this.logintude = '';
        this.ipAddress = '';
       this. browserType ='';
       this. browserVersion = '';
       this. osType ='';
        this.osVersion = '';
        this.accesstoken = '';
    }

}

