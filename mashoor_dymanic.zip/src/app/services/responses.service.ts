import {Injectable} from '@angular/core';
import {environment} from 'src/environments/environment';
import {Router} from '@angular/router';
import {DeviceinfoserviceService} from './deviceinfoservice.service';
import { BehaviorSubject } from 'rxjs';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { first } from 'rxjs/operators';

@Injectable({
	providedIn: 'root'
})

export class ResponseServiceProvider {

	baseURL: any;
	source$: any;
	totalcount=0;
	message: any;
	token: any;
	getallres: any;
	deviceinfer: any;
	loginhide:boolean;
	loginshow:boolean;
	type:any;
	getdts:boolean;
	hidemenu:boolean;
	showmenu:boolean;
	celhidemenu:boolean;
	hidemenu1:boolean;
	public catchlang:any;
	nameUser:any;
	nameUser2:any;
	celebobj:any={};
	better:any;

	public accesstoken:string;
	private messageSource = new BehaviorSubject('default message');
	currentMessage = this.messageSource.asObservable();


	constructor(private deviceInfo: DeviceinfoserviceService) {
		this.baseURL = environment.baseUrl;
	}

	changeMessages(message:any) {
		this.messageSource.next(message)
		console.log("newwww",this.accesstoken)
		return this.accesstoken = message.token;
	}


	
	nextMessage(message:any) {
		this.messageSource.next(message)
		console.log(this.accesstoken)
		return this.accesstoken = message.token;
	  }
	  

	  private unauthirize = new BehaviorSubject('default token');
     unauthmsg = this.unauthirize.asObservable();

	getResponse() {
		const obj: any = {}
		obj["iPAddress"] = this.deviceInfo.deviceinfo.ipAddress,
		obj["deviceId"] = "f6f1d0e2c1fcc8e72af497068f807a90";
		obj["deviceType"] = 'Web';
		obj["deviceVersion"]="10.0",
		obj["latitude"] = this.deviceInfo.deviceinfo.latitude ;
		obj["longitude"] = this.deviceInfo.deviceinfo.logintude;
		obj['browserVersion'] = this.deviceInfo.deviceinfo.browserVersion;
		obj['osVersion'] = this.deviceInfo.deviceinfo.osVersion;
		obj['osType'] = this.deviceInfo.deviceinfo.osType;
		obj["language"] = this.catchlang;
		obj["browserType"] = this.deviceInfo.deviceinfo.browserType;
		obj["deviceName"]= "NA";
		obj["deviceModel"]= "NA";
		obj["deviceMac"]= "NA";
		obj["appVersion"]= "NA";
		obj["pushNotificationToken"]= "NA";
		return obj;
	}

	public getObservable(value:any) {
		this.source$ = new BehaviorSubject < number > (value);
		this.totalcount = this.totalcount + 1;
   
		if (this.totalcount == 1) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
					//  //console.log(newVal)
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				1000);
		}
		if (this.totalcount == 2) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				132000);
		}
		if (this.totalcount == 3) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				176000);
		}
		if (this.totalcount == 4) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				220000);
		}
		if (this.totalcount == 5) {
   
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				32000);
		}
		if (this.totalcount == 6) {
   
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				42000);
		}
		return this.source$.asObservable();
	}




	allrespnse() {

		if (this.getallres == '1001') {
			var readdy = "Mobile Number is required"
			return readdy

		}
		if (this.getallres == '1002') {
			var readdy = "EMail is required"
			return readdy
		}
		if (this.getallres == '1003') {
			var readdy = "first name is required"
			return readdy
		}
		if (this.getallres == '1004') {
			var readdy = "last name is required"
			return readdy
		}
		if (this.getallres == '1006') {
			var readdy = "Failure"
			return readdy
		}
		if (this.getallres == '1007') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1008') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1009') {
			var readdy = " Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1010') {
			var readdy = "Customer Type is required"
			return readdy
		}
		if (this.getallres == '1011') {
			var readdy = "Please enter valid mobile number"
			return readdy
		}
		if (this.getallres == '1012') {
			var readdy = "Please enter valid EMail Address"
			return readdy
		}
		if (this.getallres == '1013') {
			var readdy = " Please enter valid First Name"
			return readdy
		}
		if (this.getallres == '1014') {
			var readdy = "Please enter valid Last Name"
			return readdy
		}
		if (this.getallres == '1015') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1016') {
			var readdy = "Please enter valid Device type"
			return readdy
		}
		if (this.getallres == '1017') {
			var readdy = "Please enter valid Customer type"
			return readdy
		}
		if (this.getallres == '1018') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1019') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1020') {
			var readdy = "Invalid Mobile Number or Password"
			return readdy
		}
		if (this.getallres == '1021') {
			var readdy = "Mobile Number already registered"
			return readdy
		}
		if (this.getallres == '1022') {
			var readdy = "Email already registered"
			return readdy
		}
		if (this.getallres == '1023') {
			var readdy = "OTP Sent"
			return readdy
		}
		if (this.getallres == '1024') {
			var readdy = " Looks Like our Servers are busy! Please try again later!"
			return readdy
		}


		if (this.getallres == '1025') {
			var readdy = "Password is required"
			return readdy
		}
		if (this.getallres == '1026') {
			var readdy = " Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1027') {
			var readdy = "Gender is required"
			return readdy
		}
		if (this.getallres == '1028') {
			var readdy = "Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
			return readdy
		}
		if (this.getallres == '1029') {
			var readdy = " Password length should be between 8-20"
			return readdy
		}
		if (this.getallres == '1030') {
			var readdy = "Please enter valid Gender"
			return readdy
		}
		if (this.getallres == '1031') {
			var readdy = "OTP is not valid"
			return readdy
		}
		if (this.getallres == '1032') {
			var readdy = " OTP is not valid"
			return readdy
		}
		if (this.getallres == '1033') {
			var readdy = "Please try again after 30 minutes or contact customer care at +966-xxxxxxxxx or write to support@mrmashhor.com"
			return readdy
		}
		if (this.getallres == '1034') {
			var readdy = "Please contact customer care at +966-xxxxxxxxx or write to support@mrmashhor.com"
			return readdy
		}
		if (this.getallres == '1035') {
			var readdy = "OTP is required"
			return readdy
		}
		if (this.getallres == '1036') {
			var readdy = "OTP is required"
			return readdy
		}

		if (this.getallres == '1037') {
			var readdy = "Device Version is required"
			return readdy
		}
		if (this.getallres == '1038') {
			var readdy = "DEVICE VERSION SHOULD NOT BE MORE THAN 30 CHARACTERS"
			return readdy
		}
		if (this.getallres == '1039') {
			var readdy = "App Version is required"
			return readdy
		}
		if (this.getallres == '1040') {
			var readdy = "APP VERSION SHOULD NOT BE MORE THAN 30 CHARACTERS"
			return readdy
		}
		if (this.getallres == '1041') {
			var readdy = "Device Mac is required"
			return readdy
		}
		if (this.getallres == '1042') {
			var readdy = "DEVICE MAC SHOULD NOT BE MORE THAN 30 CHARACTERS"
			return readdy
		}
		if (this.getallres == '1043') {
			var readdy = "Device Model is required"
			return readdy
		}
		if (this.getallres == '1044') {
			var readdy = "DEVICE MODEL SHOULD NOT BE MORE THAN 30 CHARACTERS"
			return readdy
		}
		if (this.getallres == '1045') {
			var readdy = "Invalid Mobile Number or Password"
			return readdy
		}
		if (this.getallres == '1046') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1047') {
			var readdy = "Looks Like our Servers are busy! Please try again later!"
			return readdy
		}
		if (this.getallres == '1048') {
			var readdy = "New Password is required"
			return readdy
		}
		if (this.getallres == '1049') {
			var readdy = "CONFORM CRED SHOULD NOT BE EMPTY"
			return readdy
		}
		if (this.getallres == '1050') {
			var readdy = "NEW CRED SHOULD BE MIN 8 AND MAX 20"
			return readdy
		}
		if (this.getallres == '1051') {
			var readdy = "CONFORM CRED SHOULD BE MIN 8 AND MAX 20"
			return readdy
		}
		if (this.getallres == '1052') {
			var readdy = "CONFORM CRED SHOULD BE MIN 8 AND MAX 20"
			return readdy
		}
		if (this.getallres == '1053') {
			var readdy = "CONFORM CRED SHOULD CONTAIN ONE CAPITAL LETTER AND ONE SMALL LETTER ONE NUMBER ONE SPECIAL CHARACTER"
			return readdy
		}
		if (this.getallres == '1054') {
			var readdy = "NEW CRED SHOULD CONTAIN ONE CAPITAL LETTER AND ONE SMALL LETTER ONE NUMBER ONE SPECIAL CHARACTER"
			return readdy
		}
		if (this.getallres == '1055') {
			var readdy = "The link has expired!"
			return readdy
		}
		if (this.getallres == '1057') {
			var readdy = "Old Password is required"
			return readdy
		}
		if (this.getallres == '1058') {
			var readdy = "OLD CRED SHOULD CONTAIN ONE CAPITAL LETTER AND ONE SMALL LETTER ONE NUMBER ONE SPECIAL CHARACTER"
			return readdy
		}
		if (this.getallres == '1059') {
			var readdy = "OLD CRED SHOULD BE MIN 8 AND MAX 20"
			return readdy
		}
		if (this.getallres == '1060') {
			var readdy = "AUTHORIZED"
			return readdy
		}
		if (this.getallres == '1061') {
			var readdy = "UNAUTHORIZED"
			return readdy
		}
		if (this.getallres == '1062') {
			var readdy = "You session has expired, Please login again"
			return readdy
		}
		if (this.getallres == '1063') {
			var readdy = "Device name is required"
			return readdy
		}
		if (this.getallres == '1064') {
			var readdy = "DEVICE NAME SHOULD NOT BE MORE THAN 30 CHARACTERS"
			return readdy
		}
		if (this.getallres == '1065') {
			var readdy = "Push Notification Token is required"
			return readdy
		}
	
		if (this.getallres == '1066') {
			var readdy = "Search Name is empty"
			return readdy
		}
		if (this.getallres == '1067') {
			var readdy = "Occasion should not be Empty"
			return readdy
		}
		if (this.getallres == '1068') {
			var readdy = "Whsh date is requred"
			return readdy
		}
		if (this.getallres == '1069') {
			var readdy = "Wysh is for should not be Empty"
			return readdy
		}
		if (this.getallres == '1070') {
			var readdy = "Name should not be empty"
			return readdy
		}
		if (this.getallres == '1071') {
			var readdy = "Person name should not be Empty"
			return readdy
		}
			if (this.getallres == '1072') {
			var readdy = "Message should not be Empty"
			return readdy
		}
		if (this.getallres == '1073') {
			var readdy = "Address Line1 is Empty"
			return readdy
		}
		if (this.getallres == '1074') {
			var readdy = "Address Line1 is Empty"
			return readdy
		}
		if (this.getallres == '1075') {
			var readdy = "Address Line1 is Empty"
			return readdy
		}
		if (this.getallres == '1076') {
			var readdy = "City is Empty"
			return readdy
		}
		if (this.getallres == '1077') {
			var readdy = "Country code is Empty"
			return readdy
		}
		if (this.getallres == '1078') {
			var readdy = "State is Empty"
			return readdy
		}
		if (this.getallres == '1079') {
			var readdy = "Postal code is Empty"
			return readdy
		}
	
		if (this.getallres == '1080') {
			var readdy = "Invalid Occasion"
			return readdy
		}
		if (this.getallres == '1081') {
			var readdy = "Invalid Wysh Date"
			return readdy
		}
		if (this.getallres == '1082') {
			var readdy = "Name is Invalid"
			return readdy
		}
		if (this.getallres == '1083') {
			var readdy = "Person Name is Invalid"
			return readdy
		}
		if (this.getallres == '1084') {
			var readdy = "Message Length should be min 20 and max 250 characters"
			return readdy
		}
		if (this.getallres == '1085') {
			var readdy = "Id Cannot be Empty"
			return readdy
		}
			if (this.getallres == '1086') {
			var readdy = "Follow type shoould not be Empty"
			return readdy
		}
		if (this.getallres == '1087') {
			var readdy = "Invalid Follow Type"
			return readdy
		}
		if (this.getallres == '1088') {
			var readdy = "Require Post Message or Post Image"
			return readdy
		}
		if (this.getallres == '1089') {
			var readdy = "Post Message length max 260 characters allowed"
			return readdy
		}
		if (this.getallres == '1090') {
			var readdy = "Post message should not be greater than 5 Mb"
			return readdy
		}
		if (this.getallres == '1091') {
			var readdy = "Category type should not be Empty"
			return readdy
		}
		if (this.getallres == '1092') {
			var readdy = "Invalid Category type"
			return readdy
		}
	
		if (this.getallres == '1093') {
			var readdy = "Attachment has Virus"
			return readdy
		}
		if (this.getallres == '1094') {
			var readdy = "Data Available"
			return readdy
		}
		if (this.getallres == '1095') {
			var readdy = "Data not Available"
			return readdy
		}
		if (this.getallres == '1096') {
			var readdy = "Invalid Category type"
			return readdy
		}
		if (this.getallres == '1098') {
			var readdy = "Insufficient Funds"
			return readdy
		}
		if (this.getallres == '1099') {
			var readdy = "Your Wallet is not Enabled please contact customer support"
			return readdy
		}
		if (this.getallres == '1100') {
			var readdy = "Category Id should not be Empty"
			return readdy
		}
		if (this.getallres == '1101') {
			var readdy = "Allowed File Formats are PNG, JPG,PDF,XLS,XLSX"
			return readdy
		}
		if (this.getallres == '1102') {
			var readdy = "Type Should not be Empty"
			return readdy
		}
		if (this.getallres == '1103') {
			var readdy = "Invald Type Should be Like Dislike"
			return readdy
		}
		if (this.getallres == '1130') {
			var readdy = "Old Password Is Invalid"
			return readdy
		}
		
	}

allrespnse2() {

		if (this.getallres == '1001') {
			var readdy = "رقم الهاتف المحمول مطلوب"   
			return readdy

		}
		if (this.getallres == '1002') {
			var readdy = "البريد الالكتروني مطلوب" 
			return readdy
		}
		if (this.getallres == '1003') {
			var readdy = "الإسم الأول مطلو "  
			return readdy
		}
		if (this.getallres == '1004') {
			var readdy = "الإسم الأخير مطلوب"
			return readdy
		}
		if (this.getallres == '1006') {
			var readdy = "فشل"
			return readdy
		}
		if (this.getallres == '1007') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله مرة اخري "
			return readdy
		}
		if (this.getallres == '1008') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله مرة اخري"  
			return readdy
		}
		if (this.getallres == '1009') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله مرة اخري "
			return readdy
		}
		if (this.getallres == '1010') {
			var readdy = "نوع العميل مطلوب" 
			return readdy
		}
		if (this.getallres == '1011') {
			var readdy = " أدخال الرقم الصحيح "
			return readdy
		}
		if (this.getallres == '1012') {
			var readdy = " أدخال البريد الصحيح "
			return readdy
		}
		if (this.getallres == '1013') {
			var readdy = " أدخال الأسم الأول الصحيح "
			return readdy
		}
		if (this.getallres == '1014') {
			var readdy = " أدخال الأسم الأخير الصحيح "
			return readdy
		}
		if (this.getallres == '1015') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقاً"
			return readdy
		}
		if (this.getallres == '1016') {
			var readdy = "إدخال نوع جهاز الصحيح "
			return readdy
		}
		if (this.getallres == '1017') {
			var readdy = "إدخال نوع العميل الصحيح"
			return readdy
		}
		if (this.getallres == '1018') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقاً"
			return readdy
		}
		if (this.getallres == '1019') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقا"
			return readdy
		}
		if (this.getallres == '1020') {
			var readdy = "رقم الهاتف  أو كلمة المرور غير صحيحة"
			return readdy
		}
		if (this.getallres == '1021') {
			var readdy = "رقم الهاتف  مسجل بالفعل"
			return readdy
		}
		if (this.getallres == '1022') {
			var readdy = "رقم البريد الألكتروني  مسجل بالفعل"
			return readdy
		}
		if (this.getallres == '1023') {
			var readdy = "تم إرسال OTP"
			return readdy
		}
		
		if (this.getallres == '1024') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقاً"
			return readdy
		}


		if (this.getallres == '1025') {
			var readdy = "كلمة السر مطلوبة"
			return readdy
		}
		if (this.getallres == '1026') {
			var readdy = " عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقاً"
			return readdy
		}
		if (this.getallres == '1027') {
			var readdy = "النوع مطلوب"
			return readdy
		}
		if (this.getallres == '1028') {
			var readdy = "يجب أن تحتوي كلمة السر على حرف  كبير و صغير و خاص واحد.  مثال"
			return readdy
		}
		if (this.getallres == '1029') {
			var readdy = "  تتكون كلمة السر  من  8 الي 20 حرفأُ"
			return readdy
		}
		if (this.getallres == '1030') {
			var readdy = " إدخال النوع الصحيح "
			return readdy
		}
		if (this.getallres == '1031') {
			var readdy = "OTP غير صحيح  "
			return readdy
		}
		if (this.getallres == '1032') {
			var readdy = " OTP غير صحيح " 
			return readdy
		}
		if (this.getallres == '1033') {
			var readdy = "يرجى المحاولة مرة أخرى بعد 30 دقيقة أو الاتصال بخدمة العملاء على + 966-xxxxxxxxx أو عبر البريد الألكتروني : support@mrmashhor.com"
			return readdy
		}
		if (this.getallres == '1034') {
			var readdy = "يرجى الاتصال بخدمة العملاء على الرقم + 966-xxxxxxxxx أو عبر  البريد الألكتروني  للدعم  support@mrmashhor.com"
			return readdy
		}
		if (this.getallres == '1035') {
			var readdy = "مطلوب OTP"
			return readdy
		}
		if (this.getallres == '1036') {
			var readdy = "مطلوب OTP"
			return readdy
		}

		if (this.getallres == '1037') {
			var readdy = "إصدار الجهاز مطلوب"
			return readdy
		}
		if (this.getallres == '1038') {
			var readdy = "اسم إلاصدار الجهاز لا يزيد عن 30 حرفًا"
			return readdy
		}
		if (this.getallres == '1039') {
			var readdy = " إصدار التطبيق مطلوب"
			return readdy
		}
		if (this.getallres == '1040') {
			var readdy = "اسم اصدار التطبيق لا يزيد عن 30 حرفًا"
			return readdy
		}
		if (this.getallres == '1041') {
			var readdy = "عنوان الانترنت مطلوب  Mac"
			return readdy
		}
		if (this.getallres == '1042') {
			var readdy = "لا يزيد عنوان الشبكة  MAC عن 30 حرفًا"
			return readdy
		}
		if (this.getallres == '1043') {
			var readdy = "طراز الجهاز مطلوب"
			return readdy
		}
		if (this.getallres == '1044') {
			var readdy = "لا يزيد طراز الجهاز عن 30 حرفًا"
			return readdy
		}
		if (this.getallres == '1045') {
			var readdy = "رقم الهاتف  أو كلمة المرور غير صحيحة"
			return readdy
		}
		if (this.getallres == '1046') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقاً"
			return readdy
		}
		if (this.getallres == '1047') {
			var readdy = "عذراً خوادمنا مشغولة ! يرجى المحاوله لاحقاً"
			return readdy
		}
		if (this.getallres == '1048') {
			var readdy = "كلمة السر الجديدة مطلوبة"
			return readdy
		}
		if (this.getallres == '1049') {
			var readdy = "يجب ألا تكون كلمة السر المطابق فارغًا"
			return readdy
		}
		if (this.getallres == '1050') {
			var readdy = "كلمة السر الجديدة  من  8 الي 20 حرفأُ"
			return readdy
		}
		if (this.getallres == '1051') {
			var readdy = "تاكيد كلمة السر  من  8 الي 20 حرفأُ"
			return readdy
		}
		if (this.getallres == '1052') {
			var readdy = "تاكيد كلمة السر  من  8 الي 20 حرفأُ"
			return readdy
		}
		if (this.getallres == '1053') {
			var readdy = "تاكيد كلمة السر على حرف  كبير و صغير و خاص واحد.  مثال "
			return readdy
		}
		if (this.getallres == '1054') {
			var readdy = "تاكيد كلمة السر على حرف  كبير و صغير و خاص واحد.  مثال"
			return readdy
		}
		if (this.getallres == '1055') {
			var readdy = "انتهت صلاحية الرابط !"
			return readdy
		}
		if (this.getallres == '1057') {
			var readdy = "كلمة السر القديمة مطلوبة"
			return readdy
		}
		if (this.getallres == '1058') {
			var readdy = "تحتوي كلمة السر  القديمة على حرف كبير و صغير و خاص واحد.  مثال"
			return readdy
		}
		if (this.getallres == '1059') {
			var readdy = "تاكيد كلمة السر  القديمة من  8 الي 20 حرفأُ"
			return readdy
		}
		if (this.getallres == '1060') {
			var readdy = "تصريح "
			return readdy
		}
		if (this.getallres == '1061') {
			var readdy = "غير مصرح "
			return readdy
		}
		if (this.getallres == '1062') {
			var readdy = "لقد انتهت المدة ، يرجى تسجيل الدخول مرة اخري (الذهاب لتسجيل الدخول )"
			return readdy
		}
		if (this.getallres == '1063') {
			var readdy = "اسم الجهاز مطلوب"
			return readdy
		}
		if (this.getallres == '1064') {
			var readdy = "يجب ألا يزيد اسم الجهاز عن 30 حرفًا"
			return readdy
		}
		if (this.getallres == '1065') {
			var readdy = "رقم اشعار الدفع  مطلوب"
			return readdy
		}
	
		if (this.getallres == '1066') {
			var readdy =  "اسم البحث فارغ"
			return readdy
		}
		if (this.getallres == '1067') {
			var readdy = "يجب ألا تكون المناسبة فارغة"
			return readdy
		}
		if (this.getallres == '1068') {
			var readdy = "التاريخ المطلوب"
			return readdy
		}
		if (this.getallres == '1069') {
			var readdy = "يجب ألا يكون Wysh لـ فارغًا"
			return readdy
		}
		if (this.getallres == '1070') {
			var readdy = "يجب ألا يكون الاسم فارغًا"
			return readdy
		}
		if (this.getallres == '1071') {
			var readdy = "يجب ألا يكون اسم الشخص فارغًا"
			return readdy
		}
			if (this.getallres == '1072') {
			var readdy = "يجب ألا تكون الرسالة فارغة"
			return readdy
		}
		if (this.getallres == '1073') {
			var readdy = "سطر العنوان 1 فارغ"
			return readdy
		}
		if (this.getallres == '1074') {
			var readdy = "سطر العنوان 1 فارغ"
			return readdy
		}
		if (this.getallres == '1075') {
			var readdy = "سطر العنوان 1 فارغ"
			return readdy
		}
		if (this.getallres == '1076') {
			var readdy = "المدينة فارغة"
			return readdy
		}
		if (this.getallres == '1077') {
			var readdy = "رمز البلد فارغ"
			return readdy
		}
		if (this.getallres == '1078') {
			var readdy = "الحالة فارغة"
			return readdy
		}
		if (this.getallres == '1079') {
			var readdy = "الرمز البريدي فارغ"
			return readdy
		}
	
		if (this.getallres == '1080') {
			var readdy = "مناسبة غير صحيحة"
			return readdy
		}
		if (this.getallres == '1081') {
			var readdy = "تاريخ Wysh غير صالح"
			return readdy
		}
		if (this.getallres == '1082') {
			var readdy = "الاسم غير صحيح"
			return readdy
		}
		if (this.getallres == '1083') {
			var readdy = "اسم الشخص غير صالح"
			return readdy
		}
		if (this.getallres == '1084') {
			var readdy = "يجب ألا يقل طول الرسالة عن 20 حرفًا ولا يزيد عن 250 حرفًا"
			return readdy
		}
		if (this.getallres == '1085') {
			var readdy = "لا يمكن أن يكون المعرف فارغًا"
			return readdy
		}
			if (this.getallres == '1086') {
			var readdy = "يجب ألا يكون نوع المتابعة فارغًا"
			return readdy
		}
		if (this.getallres == '1087') {
			var readdy = "نوع المتابعة غير صالح"
			return readdy
		}
		if (this.getallres == '1088') {
			var readdy = "طلب نشر الرسالة أو نشر الصورة"
			return readdy
		}
		if (this.getallres == '1089') {
			var readdy = "الحد الأقصى لطول رسالة البريد 260 حرفًا"
			return readdy
		}
		if (this.getallres == '1090') {
			var readdy = "يجب ألا تكون رسالة النشر أكبر من 5 ميغا بايت"
			return readdy
		}
		if (this.getallres == '1091') {
			var readdy = "يجب ألا يكون نوع الفئة فارغًا"
			return readdy
		}
		if (this.getallres == '1092') {
			var readdy = "نوع فئة غير صالح"
			return readdy
		}
	
		if (this.getallres == '1093') {
			var readdy = "مرفق به فيروس"
			return readdy
		}
		if (this.getallres == '1094') {
			var readdy = "البيانات المتاحة"
			return readdy
		}
		if (this.getallres == '1095') {
			var readdy = "البيانات غير متوفرة"
			return readdy
		}
		if (this.getallres == '1096') {
			var readdy = "نوع فئة غير صالح"
			return readdy
		}
		if (this.getallres == '1098') {
			var readdy = "رصيد غير كاف"
			return readdy
		}
		if (this.getallres == '1099') {
			var readdy = "محفظتك غير ممكّنة ، يرجى الاتصال بدعم العملاء"
			return readdy
		}
		if (this.getallres == '1100') {
			var readdy = "يجب ألا يكون معرف الفئة فارغًا"
			return readdy
		}
		if (this.getallres == '1101') {
			var readdy = "تنسيقات الملفات المسموح بها هي PNG و JPG و PDF و XLS و XLSX"
			return readdy
		}
		if (this.getallres == '1102') {
			var readdy = "يجب ألا يكون النوع فارغًا"
			return readdy
		}
		if (this.getallres == '1103') {
			var readdy = "يجب أن يكون النوع غير الصالح مثل لم يعجبني"
			return readdy
		}
		
	}



}