import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
 
  // baseUrl: string;

  
  private messageSource = new BehaviorSubject('default message');
  currentMessage = this.messageSource.asObservable();
  baseUrl: string;
  data: any;
  source$: any;
  totalcount=0;


  constructor(private http:HttpClient,
    ) {

      this.baseUrl = environment.baseUrl;
     }
     private unauthirize = new BehaviorSubject('default token');
     unauthmsg = this.unauthirize.asObservable();

     public getObservable(value) {
      this. source$ = new BehaviorSubject<number>(value);
      this.totalcount=this.totalcount+1;
     
      if(this.totalcount ==1){
          setInterval(() => {
         const newVal = this.source$.getValue() - 1;
    //  //console.log(newVal)
         if(newVal > -1){
         this.source$.next(newVal);
        
         }
       }, 
       
       1000);
       } if(this.totalcount == 2){
         setInterval(() => {
           const newVal = this.source$.getValue() - 1;
       
           if(newVal > -1){
           this.source$.next(newVal);
          
           }
         }, 
         
         132000);
       }
       if(this.totalcount == 3){
         setInterval(() => {
           const newVal = this.source$.getValue() - 1;
       
           if(newVal > -1){
           this.source$.next(newVal);
          
           }
         }, 
         
         176000);
       } if(this.totalcount == 4){
         setInterval(() => {
           const newVal = this.source$.getValue() - 1;
       
           if(newVal > -1){
           this.source$.next(newVal);
          
           }
         }, 
         
         220000);
       } if(this.totalcount == 5){
        
         setInterval(() => {
           const newVal = this.source$.getValue() - 1;
       
           if(newVal > -1){
           this.source$.next(newVal);
          
           }
         }, 
         
         32000);
       }
       if(this.totalcount == 6){
        
         setInterval(() => {
           const newVal = this.source$.getValue() - 1;
       
           if(newVal > -1){
           this.source$.next(newVal);
          
           }
         }, 
         
         42000);
       }
       return this.source$.asObservable();
     }

     changeMessage(message: any) {
      // console.log(message)
      this.messageSource.next(message)
    }
    refreshToken(accesstoken){
      console.log(accesstoken)
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (accesstoken)
        })
      }
      console.log("refreshtoken")
  
      return this.http.post(this.baseUrl+"v1/refreshtoken",this.data,httpOptions);
     
    }
    unAuthorize(artheriauth:any) {
  
      console.log(artheriauth)
  
      this.unauthirize.next(artheriauth)
    }

  logOut(accesstoken):Observable<any> {

  
  
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (accesstoken)
       
      })
    
    }
      
      return this.http.post<any>(this.baseUrl+'v1/logout',this.data,httpOptions)
    }
}

