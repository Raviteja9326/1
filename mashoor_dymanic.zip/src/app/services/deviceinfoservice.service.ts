
import { Injectable } from '@angular/core';
import { deviceinfo } from './deviceinfo.model';
import { HttpClient } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';
import { BehaviorSubject } from 'rxjs';
declare var Fingerprint2: any;
@Injectable({
  providedIn: 'root'
})
export class DeviceinfoserviceService {

	private message = new BehaviorSubject('First Message');
	sharedMessage = this.message.asObservable();

	getDeviceId;
	deviceInfo = null;
	deviceId;
	geolocationPosition: object;
	longitude: string;
	latitude: string;
	ipAddress: string;
	deviceinfo: deviceinfo;


	constructor(private http: HttpClient, private deviceService: DeviceDetectorService) {
		this.getInfo();
	}

	changeMessage(message) {
		this.message.next(message)
		this.deviceinfo.accesstoken = message.token;
		console.log(message)
	}
	
	nextMessage(message) {
		this.message.next(message)
	  
	
		this.deviceinfo.accesstoken = message.token;
		console.log(this.deviceinfo.accesstoken)
	  }
	

	getInfo() {

		this.deviceinfo = new deviceinfo();

		


		this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
			this.ipAddress = geoLocationResponse.ip;
			// console.log(geoLocationResponse.ip);
			this.deviceinfo.ipAddress = (geoLocationResponse.ip);
		});
		this.geolocationPosition = {};
		if (window.navigator && window.navigator.geolocation) {
			window.navigator.geolocation.getCurrentPosition(
				position => {
					this.geolocationPosition = position;
					// console.log(this.geolocationPosition);
					this.showPosition(position);
				}
			);
		}
		this.epicFunction();
		// console.log(this.deviceInfo)
	}

	showPosition(position) {
		if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
			this.latitude = position.coords.latitude;
			this.longitude = position.coords.longitude;
			this.deviceinfo.latitude = String(position.coords.latitude);
			this.deviceinfo.logintude = String(position.coords.longitude);

			console.log(this.latitude)

		} else {}
		// console.log(this.deviceinfo);
	}


	epicFunction() {
		// console.log('hello `Home` component');
		this.deviceInfo = this.deviceService.getDeviceInfo();
		const isMobile = this.deviceService.isMobile();
		const isTablet = this.deviceService.isTablet();
		const isDesktopDevice = this.deviceService.isDesktop();
		// returns if the app is running on a Desktop browser.
		this.deviceinfo.browserType = this.deviceService.browser;
		this.deviceinfo.browserVersion = this.deviceService.browser_version;
		this.deviceinfo.osType = this.deviceService.os;
		this.deviceinfo.osVersion = this.deviceService.os_version;
	}

}