import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ResponseServiceProvider } from './responses.service';
const baseUrl = `${environment.baseUrl}/v1`;

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl: any;
  datas:any

  constructor(private http:HttpClient, private api:ResponseServiceProvider) 
  {}


  occasionList():Observable<any> {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
       
          // 'X-XSRF-TOKEN': this.csrftoken,
        })
    
      }
      return this.http.post<any>(baseUrl+'v1/occasions/list',httpOptions)
    }

    
    wishisforList():Observable<any> {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
       
          // 'X-XSRF-TOKEN': this.csrftoken,
        })
      }
      return this.http.post<any>(baseUrl+'v1/WishIsFor/list',httpOptions)
    }


    bookwish(obj,accesstoken):Observable<any>{
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (accesstoken)
        })
      }
      return this.http.post<any>(baseUrl+'v1/book/wish',obj,httpOptions)
    }


    // profile Details
    getUserProfile() :Observable<any>{
      console.log(this.api.accesstoken)
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
    return this.http.post<any>(baseUrl+'/profiledetails',this.api.getResponse(),httpOptions)
    }

    getUseraddress() :Observable<any>{
      console.log(this.api.accesstoken)
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
    return this.http.post<any>(baseUrl+'/getCustomerAddressDetails',this.api.getResponse(),httpOptions)
    }

    Useraddbalance(money:any) :Observable<any>{
      const obj2 = Object.assign({}, money, this.api.getResponse());
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
    return this.http.post<any>(baseUrl+'/addMoney',obj2,httpOptions)
    }

    userprofileUpdt(obj:any){
      const httpOptions = {
        headers: new HttpHeaders({
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
      //console.log(this.api.accesstoken)
    return this.http.post<any>(baseUrl+'/updateprofiledetails',obj,httpOptions)
    }

    useraddupd(obj:any, objk:any){
      const obj2 = Object.assign({}, obj, objk);
      const httpOptions = {
        headers: new HttpHeaders({
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
      //console.log(this.api.accesstoken)
    return this.http.post<any>(baseUrl+'/updateCustomerAddress',obj2,httpOptions)
    }

    useraddad(obj:any){
      const httpOptions = {
        headers: new HttpHeaders({
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
      //console.log(this.api.accesstoken)
    return this.http.post<any>(baseUrl+'/addCustomerAddress',obj,httpOptions)
    }

    userprofileUpdtpwd(obj:any){
      const obj2 = Object.assign({}, obj, this.api.getResponse());
      //console.log(obj2)
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (this.api.accesstoken)
        })
      }
      //console.log(this.api.accesstoken)
    return this.http.post<any>(baseUrl+'/changeCred',obj2,httpOptions)
    }


    getcelebsingle(obj:any):Observable<any>{
    return this.http.post<any>(baseUrl+'/getcelebritydetails',obj)
    }


    usercatlyst() :Observable<any>{
    return this.http.post<any>(baseUrl+'/getcategorieslist',this.api.getResponse())
    }

    usercatlyst2() :Observable<any>{
      return this.http.post<any>(baseUrl+'/categories/list',this.api.getResponse())
      }

    userbannerlst() :Observable<any>{
      return this.http.post<any>(baseUrl+'/banners/list',this.api.getResponse())
      }

    usercelebritylst() :Observable<any>{
        return this.http.post<any>(baseUrl+'/celebritylistwotfollcout',this.api.getResponse())
        }




        postList():Observable<any>{
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          console.log(this.api.accesstoken)
          return this.http.post<any>(baseUrl+'/userlikesandcomments',this.datas,httpOptions)
        }
    
    
        followList():Observable<any>{
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          console.log(this.api.accesstoken)
    
          return this.http.post<any>(baseUrl+'/customer/celebrityfollowlist',this.api.getResponse(),httpOptions)
        }
    
        postComment(obj):Observable<any>{
          const httpOptions = {
            headers: new HttpHeaders({
              // 'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/post/comment',obj,httpOptions)
        }
        deleteComment(obj):Observable<any>{
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/post/delete/comment',obj,httpOptions)
        }
    
         commentList(obj):Observable<any>{
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          console.log(this.api.accesstoken)
    
          return this.http.post<any>(baseUrl+'/getcommentsbypostid',obj,httpOptions)
        }
        userlikeanddislike(obj):Observable<any>{
    
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/like/dislike',obj,httpOptions)
        }
        autosuggestions(obj):Observable<any>{
    
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              // 'Authorization': 'Bearer ' + (accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/autosuggestion',obj,httpOptions)
        }

        userfollowunfollow(obj):Observable<any>{
    
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/follow/unfollow',obj,httpOptions)
        }
        userfollowstatus(obj):Observable<any>{
    
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/followStatus',obj,httpOptions)
        }
        getcelbdetails(obj):Observable<any>{
    
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              // 'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/getcelebritydetails',obj,httpOptions)
        }
        getfollowcount(obj):Observable<any>{

          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              // 'Authorization': 'Bearer ' + (this.api.accesstoken)
            })
          }
          return this.http.post<any>(baseUrl+'/getfollowingcount',obj,httpOptions)
        }
}

