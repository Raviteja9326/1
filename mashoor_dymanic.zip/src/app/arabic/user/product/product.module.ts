import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UserProductroutes } from './product-routing.modules';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [ProductdetailsComponent,ProductlistComponent],
  imports: [
    CommonModule,
    NgbModule,
    RouterModule.forChild(UserProductroutes),
  ]
})
export class UserProductModule { }
