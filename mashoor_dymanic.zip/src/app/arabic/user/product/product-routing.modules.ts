import {Routes } from '@angular/router';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { ProductlistComponent } from './productlist/productlist.component';

export const UserProductroutes: Routes = 
[
    { path: "ProductDetail", component: ProductdetailsComponent},
    { path: "Productlist", component: ProductlistComponent},
];


