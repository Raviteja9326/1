import { AfterContentChecked, AfterViewChecked, AfterViewInit, Component, ElementRef, HostListener, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { UserService } from 'src/app/services/user.service';
import { first } from 'rxjs/operators';
import { DOCUMENT } from '@angular/common';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

@Component({
  selector: 'app-arcelebritylist',
  templateUrl: './arcelebritylist.component.html',
  styleUrls: ['./arcelebritylist.component.scss']
})
export class ArCelebritylistComponent implements OnInit {

  id:any;
  celeblists:any;
  keys:any;
  celebname:any;
  offsetFlag:boolean=true;
  baseUrl: any =  "https://images.mrmashhor.sa/profile/celebrity/";
  categorysslist: any;
  categoryssdata: any;
  getssrout: any;
  hidecoming:boolean;

  constructor(private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router,private elementRef: ElementRef,@Inject(DOCUMENT) private doc, private apis:ResponseServiceProvider) 
  {
    
  }



  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  




  ngOnInit(): void 
{ 
  this.route.params.subscribe(routeParams => {
    this.id = routeParams.id;
    this.GetGategoriess()
    this.Getceleblists();
  });  
}



  clicken(data)
  {
this.router.navigate(['/categories',this.id])
  }

  getKeyByValue(object, value) {
    return Object.keys(object).find(key => object[key] === value);
  }

  GetGategoriess(){
    this.userService.usercatlyst2()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res);
      this.categorysslist = res.categoryname_en;
    this.categoryssdata= res.categoryname_ar;
    var xss = this.getKeyByValue(this.categorysslist, this.id)
    this.getssrout = this.categoryssdata[xss];
    console.log( this.getssrout)
    })
    .add(() => this.ngxLoader.stop());
    this.Getceleblists();
    }


  
    Getceleblists(){
      this.ngxLoader.start();
      this.userService.usercelebritylst()
      .pipe(first())
      .subscribe((res:any) => {
        if(res['response']=='1005' && res['responseStatus']=='1094'){
          this.celeblists = res.responseList[this.getssrout];
          this.ngxLoader.stop();
          this.hidecoming = false
          }
          else if(res['responseStatus']=='1095'){
            this.hidecoming= true
          }
      
      })
      .add(() => this.ngxLoader.stop());
      }

    getcelebdatas(data)
    {
      this.celebname = data.firstName;
      this.router.navigate(['/ardetails',this.id,this.celebname])
    }



   




}
