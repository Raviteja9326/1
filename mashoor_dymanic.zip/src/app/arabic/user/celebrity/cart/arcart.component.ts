import { Route } from '@angular/compiler/src/core';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-arcart',
  templateUrl: './arcart.component.html',
  styleUrls: ['./arcart.component.scss']
})
export class ArCartComponent implements OnInit {

  offsetFlag:boolean=true;

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  rouk()
      {
        this.router.navigate(['/cart'])
      }
}
