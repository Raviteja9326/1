import { Component, OnInit, ElementRef, Inject, HostListener } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { UserService } from 'src/app/services/user.service';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
declare var jQuery:any;

@Component({
  selector: 'app-arcelebritydetails',
  templateUrl: './arcelebritydetails.component.html',
  styleUrls: ['./arcelebritydetails.component.scss']
})
export class ArCelebritydetailsComponent implements OnInit {

  celedata:any;
  id:any;
  unfollow: boolean;
  follow: boolean;
  follwstatus: any;
  data: string;
  better:any;
  id1:any;
  offsetFlag:boolean=true;
  baseUrl: any =  "https://images.mrmashhor.sa/profile/celebrity/";
  categorylist: any;
  categorydata: any;
  getrout: any;
  followCount: any;
 
  constructor(private elementRef: ElementRef,@Inject(DOCUMENT) private doc ,public dialog: MatDialog,private apis:ResponseServiceProvider, private toastr:ToastrService,private ngxLoader: NgxUiLoaderService, private userService:UserService, private router:Router, private route: ActivatedRoute) 
  { 
  
    this.apis.currentMessage.subscribe(message =>{
      //console.log(message);
      this.data=message;
     })
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

 

  ngOnInit(): void {

    this.route.params.subscribe(routeParams => {
      console.log(routeParams)
      this.id = routeParams.id;
      this.id1 = routeParams.id1
     
  
    })
    this.GetGategories();
  }

  getKeyByValue(object, value) {
    return Object.keys(object).find(key => object[key] === value);
  }

  GetGategories(){
    this.ngxLoader.start();
    this.userService.usercatlyst2()
    .subscribe((res:any) => {
      console.log(res);
      this.categorylist = res.categoryname_en;
    this.categorydata= res.categoryname_ar;
    var x = this.getKeyByValue(this.categorylist, this.id)
    return this.getrout = this.categorydata[x];
    
    })
    
    .add(() => this.ngxLoader.stop());
    
    this.Getceledetails();
    }

 Getceledetails(){
  
    this.ngxLoader.start();
    this.userService.usercelebritylst()
    .subscribe((res:any) => {
      console.log(res.responseList)
      for(let itemobj of res.responseList[this.getrout])
      {
        console.log("88888")
        if(itemobj.firstName==this.id1)
        {
          console.log("88888")
           this.celedata = itemobj;
        }
      }
      console.log(this.celedata,"jkjkj")
      console.log("999999999999")
      console.log("deeeeeeeeeeee")
      this.followstatus();
      this.getfollowcount()
    })
   
    this.ngxLoader.stop();
  }

  comisoon()
  {
    this.toastr.success("قريبا");
  }

  followstatus(){
    console.log("follow status")
        if(this.data == "default message"){
          this.follow=true
        }
        else if(this.data != 'default message'){
        console.log("folow")
        const obj={}
    
        obj["celebrity_id"]=this.celedata.id
       
        this.ngxLoader.start();
        
           
        this.userService.userfollowstatus(obj)
        .pipe(first())
        .subscribe((res:any) => {
          console.log(res)
        if( res['tokenStatus']=='1060'){
          if(res.followStatus == "UnFollow"){
            this.unfollow= false
            this.follow=true
          }
          else{
            this.unfollow= true
            this.follow=false
          }
        }
        
       if(res['tokenStatus']=='1061'){
        this.better = "انتهت صلاحية جلسة العمل الخاصة بك";
        this.apis.nextMessage("default message")
        this.ngxLoader.stop();
        this.router.navigate(['/arlogin'])
      }
      else if(res['tokenStatus']=='1094'){
         this.ngxLoader.stop()
      }
      else if(res['tokenStatus']=='1095'){
        this.ngxLoader.stop()
        console.log("nodata")
     }
      else if(res['tokenStatus']){
        this.apis.getallres = res['tokenStatus'] ;
         this.better = this.apis.allrespnse();
         this.ngxLoader.stop()
      }
        })
        .add(() => this.ngxLoader.stop());
        }
      }



    
      followcel()
      {
        if(this.data == "default message"){
          this.router.navigate(['/arlogin'])
        }else if(this.data != "default message"){
        console.log("folow")
        const obj={}
    
        obj["id"]=this.celedata.id
        obj["deviceId"]="7b5014df8e2f845e671d4dc8af3614e4"
        obj["deviceType"]="Web"
        obj["language"]="en"
        obj["type"]="Follow"
        this.ngxLoader.start();
        this.userService.userfollowunfollow(obj)
        .pipe(first())
        .subscribe((res:any) => {
          console.log(res)
        if( res['tokenStatus']=='1060'){
          this.unfollow= true
          this.follow=false
          this.getfollowcount()
        }
       if(res['tokenStatus']=='1061'){
        this.better = "انتهت صلاحية جلسة العمل الخاصة بك";
        this.apis.nextMessage("default message")
        this.ngxLoader.stop();
        this.router.navigate(['/arlogin'])
      }
      else if(res['tokenStatus']=='1094'){
         this.ngxLoader.stop()
      }
      else if(res['tokenStatus']=='1095'){
        this.ngxLoader.stop()
        console.log("nodata")
     }
      else if(res['tokenStatus']){
        this.apis.getallres = res['tokenStatus'] ;
         this.better = this.apis.allrespnse();
         this.ngxLoader.stop()
      }
        })
        
        .add(() => this.ngxLoader.stop());
        }
      }
getfollowcount(){
  const obj={}
  obj["celebrityId"]=this.celedata.id
       
  this.ngxLoader.start();
  
     
  this.userService.getfollowcount(obj)
  .pipe(first())
  .subscribe((res:any) => {
    console.log(res)
  if( res['tokenStatus']=='1060'){
   this.followCount=res.followingCount
  }
  
 if(res['tokenStatus']=='1061'){
  this.better = "انتهت صلاحية جلسة العمل الخاصة بك";
  this.apis.nextMessage("default message")
  this.ngxLoader.stop();
  this.router.navigate(['/arlogin'])
}
else if(res['tokenStatus']=='1094'){
   this.ngxLoader.stop()
}
else if(res['tokenStatus']=='1095'){
  this.ngxLoader.stop()
  console.log("nodata")
}
else if(res['tokenStatus']){
  this.apis.getallres = res['tokenStatus'] ;
   this.better = this.apis.allrespnse();
   this.ngxLoader.stop()
}
  })
  .add(() => this.ngxLoader.stop());
  
}

      rouk()
      {
        this.router.navigate(['/details', this.id,this.id1])
      }


      unfollowcel()
      {
        if(this.data == "default message"){
          this.router.navigate(['/arlogin'])
        }else if(this.data != "default message"){
        console.log("unfollow")
        const obj={}
    
        obj["id"]=this.celedata.id
        obj["deviceId"]="7b5014df8e2f845e671d4dc8af3614e4"
        obj["deviceType"]="Web"
        obj["language"]="en"
        obj["type"]="UnFollow"
       
        this.ngxLoader.start();
        
           
        this.userService.userfollowunfollow(obj)
        .pipe(first())
        .subscribe((res:any) => {
          console.log(res)
         
        if( res['tokenStatus']=='1060'){
          this.unfollow= false
          this.follow=true
          this.getfollowcount()
      
        }
        
       if(res['tokenStatus']=='1061'){
        this.better = "انتهت صلاحية جلسة العمل الخاصة بك";
        this.apis.nextMessage("default message")
        this.ngxLoader.stop();
        this.router.navigate(['/arlogin'])
      }
      else if(res['tokenStatus']=='1094'){
         this.ngxLoader.stop()
      }
      else if(res['tokenStatus']=='1095'){
        this.ngxLoader.stop()
        console.log("nodata")
     }
      else if(res['tokenStatus']){
        this.apis.getallres = res['tokenStatus'] ;
         this.better = this.apis.allrespnse();
         this.ngxLoader.stop()
      }
        })
        .add(() => this.ngxLoader.stop());
        }
      }

}
