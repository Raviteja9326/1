import { ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-aruserprofile',
  templateUrl: './aruserprofile.component.html',
  styleUrls: ['./aruserprofile.component.scss']
})
export class ArUserprofileComponent implements OnInit {

 
  imageUrl: any;
  fileData: any;
  editFile: boolean = true;
	removeUpload: boolean = false;
  profileData:any = [];
  apiresponse:any;
  profileshow:boolean=true;
  profilehide:boolean=false;
  updatid:any={};
  better: string;
  hidebtn:boolean=false;
  showbtn:boolean=true;
  submitted:boolean=false;
  offsetFlag:boolean = true;
  isEnabled:boolean=false;
  baseUrl: any =  "https://images.mrmashhor.sa/profile/users/";


  constructor(private cd: ChangeDetectorRef, private users:UserService, private apis:ResponseServiceProvider, private ngxLoader: NgxUiLoaderService, private formBuilder: FormBuilder, private router:Router, private toastr:ToastrService) { 
    this.getuserprofiledata();}

  ngOnInit(): void {this.togglenable()}

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  @ViewChild("myinput") myInputField: ElementRef;


  profileupdateform = this.formBuilder.group({
    firstName: ['',[Validators.required,spaceValidator, 
      Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$'), Validators.maxLength(25)]],
    lastName: ['',[Validators.required, spaceValidator,
      Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$'), Validators.maxLength(16)]],
    gender : ['',[Validators.required]],
    EmailId :[''],
    mobileNumber : ['']
  })

  uploadFile(event) {
		let reader = new FileReader();
		this.fileData = event.target.files[0];
		//console.log(this.fileData)
		if (event.target.files && event.target.files[0]) {
			reader.readAsDataURL(this.fileData);

			// When file uploads set it to file formcontrol
			reader.onload = () => {
				this.imageUrl = reader.result;
				this.editFile = false;
				this.removeUpload = true;
			}
			// ChangeDetectorRef since file is loading outside the zone
			this.cd.markForCheck();
		}
	}

  get profileControllers() { return this.profileupdateform.controls }

  @ViewChild('fileUploader') fileUploader: ElementRef;

  toggleDisable() {
    this.profileupdateform.get('firstName').enable();
    this.profileupdateform.get('lastName').enable();
    this.profileupdateform.get('gender').enable();
    this.showbtn = false;
    this.hidebtn = true;
    this.isEnabled = false;
  }

  togglenable()
  {
    this.showbtn = true;
    this.hidebtn = false;
    this.isEnabled = true;
    this.profileupdateform.get('firstName').disable();
    this.profileupdateform.get('lastName').disable();
    this.profileupdateform.get('gender').disable();
    this.getuserprofiledata();
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }

  getdatas()
  {
    if (!this.profileupdateform.valid) {
      Object.keys(this.profileupdateform.controls).forEach(field => {
        const control:any = this.profileupdateform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }
    else
    {
      var formData = new FormData();
      if(this.fileData =='' || this.fileData == null || this.fileData == undefined) { 
       var f = new File([""], "filename");
        formData.append("attachement", f);
      }
      else
      {
        var f2 = this.fileData;
        formData.append("attachement", f2);
      }
      formData.append('firstName', this.profileupdateform.value.firstName);
      formData.append('lastName', this.profileupdateform.value.lastName);
      formData.append('gender', this.profileupdateform.value.gender);
      console.log(this.fileData)
      this.ngxLoader.start();
      this.users.userprofileUpdt(formData)
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res)
        if(res['response']=='1005' && res['tokenStatus']=='1060'){
          this.toastr.success("ستنعكس تغييراتك عند تسجيل الدخول التالي");
          this.togglenable();
        }
       else if(res['response']=='1006' || res['tokenStatus']=='1061'){
        this.toastr.success('لقد انتهت الجلسة الخاصة بك الرجاء تسجيل الدخول للمتابعة');
          this.apis.nextMessage("default message")
          this.ngxLoader.stop();
          this.router.navigate(['/arlogin'])
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse2();
           this.toastr.success(this.better);
           this.ngxLoader.stop()
        }
       
        })
        .add(() => this.ngxLoader.stop());
    }
  }


  getuserprofiledata()
  {
    this.ngxLoader.start();
    this.users.getUserProfile()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res)
      if( res['tokenStatus']=='1060')
      {
        if(res.profilePhoto =="NA")
        {
          this.imageUrl = "https://staticimages.mrmashhor.sa/noImage_ar.png"
        }
        else
        {
          this.imageUrl=this.baseUrl+res.profilePhoto;
          console.log(this.imageUrl)
        }
        this.profileData= res;
        this.updateprofile();
      }
     else if(res['tokenStatus']=='1061'){
      this.toastr.success('لقد انتهت الجلسة الخاصة بك الرجاء تسجيل الدخول للمتابعة');
        this.apis.nextMessage("default message")
        this.ngxLoader.stop();
        this.router.navigate(['/arlogin'])
      }
      else if(res['tokenStatus']=='1094'){
         this.ngxLoader.stop()
      }
      else if(res['tokenStatus']=='1095'){
        this.ngxLoader.stop()
        console.log("nodata")
     }
      else if(res['tokenStatus']){
        this.apis.getallres = res['tokenStatus'] ;
         this.better = this.apis.allrespnse2();
         this.ngxLoader.stop()
      }
    })
    .add(() => this.ngxLoader.stop());
  
}

  updateprofile()
  {
    this.imageUrl;
    console.log(this.updatid)
    this.profilehide=true;
    this.profileshow=false;
    if(this.profileData.fistName=="NA" || this.profileData.lastName=="NA" || this.profileData.gender=="NA")
    {
      this.profileData.fistName = "";
      this.profileData.lastName = "";
      this.profileData.gender = "";
    this.profileupdateform.setValue({
      firstName: this.profileData.fistName,
      lastName: this.profileData.lastName,
      gender : this.profileData.gender,
      EmailId : this.profileData.EmailId,
      mobileNumber : this.profileData.mobileNumber
    });
  }
  else
  {
    this.profileupdateform.setValue({
      firstName: this.profileData.fistName,
      lastName: this.profileData.lastName,
      gender : this.profileData.gender,
      EmailId : this.profileData.EmailId,
      mobileNumber : this.profileData.mobileNumber
    });
  }
    this.ngxLoader.stop();
    console.log(this.profileupdateform.value.firstName)
  }

  updateprofiledetails()
  {
    this.ngxLoader.start();
    this.profilehide=false;
    this.profileshow=true;
    this.ngxLoader.stop();
  }

  changen()
  {
    this.apis.catchlang="en"
  }
  

}
