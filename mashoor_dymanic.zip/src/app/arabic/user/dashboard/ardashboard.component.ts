import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, OnInit } from '@angular/core';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

@Component({
  selector: 'app-ardashboard',
  templateUrl: './ardashboard.component.html'
})
export class ArDashboardComponent implements OnInit {

 

  constructor(private apis:ResponseServiceProvider, private elementRef: ElementRef) 
  {
    this.apis.catchlang = "ar";
  }

  


  ngOnInit(): void 
  { 
   
  }
}