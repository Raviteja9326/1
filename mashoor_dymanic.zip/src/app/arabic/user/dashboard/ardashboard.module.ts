import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ArGeneralModule } from '../../general/argeneral.module';
import { Aruserdashboardroutes } from './ardashboard-routing.module';
import { ArDashboardComponent } from './ardashboard.component';
import { ArUserprofileComponent } from './userprofile/aruserprofile.component';
import { ArWalletComponent } from './wallet/arwallet.component';
import { ArAddressComponent } from './address/araddress.component';
import { ArUpdatepasswordComponent } from './updatepassword/arupdatepassword.component';
import { ArBooklistComponent } from './booklist/arbooklist.component';
import { ArPostlistComponent } from './postlist/arpostlist.component';


@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    ArGeneralModule,
    RouterModule.forChild(Aruserdashboardroutes)
  ],
  declarations: [ArDashboardComponent, ArUserprofileComponent, ArWalletComponent, ArAddressComponent, ArUpdatepasswordComponent, ArBooklistComponent, ArPostlistComponent]
})
export class ArUserDashboardModule { }
