import { Routes } from '@angular/router';
import { ArAddressComponent } from './address/araddress.component';
import { ArDashboardComponent } from './ardashboard.component';
import { ArBooklistComponent } from './booklist/arbooklist.component';
import { ArPostlistComponent } from './postlist/arpostlist.component';
import { ArUpdatepasswordComponent } from './updatepassword/arupdatepassword.component';
import { ArUserprofileComponent } from './userprofile/aruserprofile.component';
import { ArWalletComponent } from './wallet/arwallet.component';

export const Aruserdashboardroutes: Routes = 
[
  { path: '', component: ArDashboardComponent,
  children: [
    { path: 'arprofile', component: ArUserprofileComponent},
    { path: 'arwallet', component: ArWalletComponent},
    { path: 'araddress', component: ArAddressComponent},
    { path: 'arresetpassword', component: ArUpdatepasswordComponent},
    { path: 'arbooklist', component: ArBooklistComponent},
    { path: "arpostlist", component: ArPostlistComponent},
  ]}
];

