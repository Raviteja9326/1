import { Routes } from '@angular/router';
import { ArHomeComponent } from '../general/home/arhome.component';
import { ArCartComponent } from './celebrity/cart/arcart.component';
import { ArCelebritydetailsComponent } from './celebrity/celebritydetails/arcelebritydetails.component';
import { ArCelebritylistComponent } from './celebrity/celebritylist/arcelebritylist.component';

export const Aruserroutes: Routes = 
[
  { path: 'arhome', component: ArHomeComponent },

  { path: "ardetails/:id/:id1", component: ArCelebritydetailsComponent},

  { path: "arcategories/:id", component: ArCelebritylistComponent},

  { path: "arcart", component: ArCartComponent},


  { 
    path: 'arcustomer', 
    loadChildren: () => import(`./dashboard/ardashboard.module`).then(
      module => module.ArUserDashboardModule
    )
  },

];

