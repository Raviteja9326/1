import { DOCUMENT } from '@angular/common';
import { AfterViewInit, Component, DoCheck, ElementRef, Inject, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
declare let $:any;

@Component({
  selector: 'app-aruser',
  templateUrl: './aruser.component.html',
  styleUrls: ['./aruser.component.scss']
})
export class ArUserComponent implements OnInit, OnDestroy, DoCheck{

  routerSubscription: any;
  constructor(private apis:ResponseServiceProvider, private elementRef: ElementRef, private router: Router) 
  {
    this.apis.catchlang = "ar";
  }
  ngOnInit(): void 
  { 
  }

  ngDoCheck()
  {
  }


  ngOnDestroy() 
  {  
  }


  ngAfterViewInit()
  {
  
  }




}