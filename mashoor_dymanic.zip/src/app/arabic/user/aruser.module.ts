import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UserProductModule } from './product/product.module';
import { ArHomeComponent } from '../general/home/arhome.component';
import { Aruserroutes } from './aruser-routing.module';
import { ArUserDashboardModule } from './dashboard/ardashboard.module';
import { ArCelebritydetailsComponent } from './celebrity/celebritydetails/arcelebritydetails.component';
import { ArCelebritylistComponent } from './celebrity/celebritylist/arcelebritylist.component';
import { ProgressiveImageModule } from 'src/app/progressive-image/progressive-image.module';
import { ArCartComponent } from './celebrity/cart/arcart.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(Aruserroutes),
    UserProductModule,
    ProgressiveImageModule,
    ArUserDashboardModule
  ],
  declarations: [ArHomeComponent,ArCelebritydetailsComponent,ArCelebritylistComponent,ArCartComponent]
})
export class ArUserModule { }
