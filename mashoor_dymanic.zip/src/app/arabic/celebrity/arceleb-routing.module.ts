import { Routes } from '@angular/router';

export const Arcelebroutes: Routes = 
[

  { 
    path: 'arcelebrity', 
    loadChildren: () => import(`./dashboard/ardashboard.module`).then(
      module => module.ArcelebDashboardModule
    )
  },

  // { 
  //   path: 'ArCelebproduct', 
  //   loadChildren: () => import(`./product/product.module`).then(
  //     module => module.celebProductModule
  //   )
  // }
 
 
];

