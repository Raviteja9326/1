import { Component, ElementRef, OnInit } from '@angular/core';

@Component({
  selector: 'app-ardashboard',
  templateUrl: './ardashboard.component.html'
})
export class ArDashboardComponent implements OnInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void 
  {
  
  }

}
