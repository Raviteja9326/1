import { Routes } from '@angular/router';
import { ArAddPostComponent } from './addposts/araddpost.component';
import { ArDashboardComponent } from './ardashboard.component';
import { ArMybookingComponent } from './mybooking/armybooking.component';
import { ArProfileComponent } from './profile/arprofile.component';
import { ArUpdatepwdComponent } from './updatepwd/arupdatepwd.component';
import { ArWalletComponent } from './wallet/arwallet.component';

export const ArCelebdashboardroutes: Routes = 
[
  { path: '', component: ArDashboardComponent,
  children: [
    { path: 'arcustomerwishrequests', component: ArMybookingComponent},
    { path: 'arwallet', component: ArWalletComponent},
    { path: 'arprofile', component: ArProfileComponent},
    { path: "arpostlist", component: ArAddPostComponent},
    { path: "arresetpassword", component: ArUpdatepwdComponent},
  ]}
];

