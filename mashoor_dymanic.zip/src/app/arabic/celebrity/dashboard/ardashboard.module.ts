import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ArMybookingComponent } from './mybooking/armybooking.component';
import { ArProfileComponent } from './profile/arprofile.component';
import { ArAddPostComponent } from './addposts/araddpost.component';
import { ArUpdatepwdComponent } from './updatepwd/arupdatepwd.component';
import { ArDashboardComponent } from './ardashboard.component';
import { ArCelebdashboardroutes } from './ardashboard-routing.module';
import { ArGeneralModule } from '../../general/argeneral.module';
import { ArWalletComponent } from './wallet/arwallet.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ArGeneralModule,
    RouterModule.forChild(ArCelebdashboardroutes)
  ],
  declarations: [ArDashboardComponent, ArMybookingComponent, ArProfileComponent,ArAddPostComponent, ArUpdatepwdComponent,ArWalletComponent]
})
export class ArcelebDashboardModule { }
