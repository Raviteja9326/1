import { ThrowStmt } from '@angular/compiler';
import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { CelebrityService } from 'src/app/services/celebrity.service';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';


export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }
@Component({
  selector: 'app-araddpost',
  templateUrl: './araddpost.component.html',
  styleUrls: ['./araddpost.component.scss']
})
export class ArAddPostComponent implements OnInit {

 
  showcomment = false;
  hidecomment = true;
  postlist: any;
  message: any;
  commentForm : FormGroup;
  postForm:FormGroup;
  submit:any
  posterid: string | Blob;
  usercommentlist: any;
  userArray =[];
  otheruserArray=[];
  hideme  = {};
  likeshow: boolean = true;
  dislikeshow: boolean;
  celimg: any;
  celbname: any;
  offsetFlag:boolean=true;
  better: string;
  posterrorMsg: boolean;
  posterror: boolean = false;
  baseurl="https://images.mrmashhor.sa/posts/celebrity/"
  commentliststatus: boolean;


  constructor(private userService:UserService,private celbService : CelebrityService,private toastr:ToastrService,private router :Router, private apis:ResponseServiceProvider, private ngxLoader: NgxUiLoaderService,private fb:FormBuilder,public dialog: MatDialog,) 
  { 
    this.apis.currentMessage.subscribe(message =>{
      //console.log(message);
      this.message=message;
     })
     this.hideme = {};

     if(this.apis.getdts == undefined)
     {
       this.apis.showmenu = true;
       this.apis.hidemenu = false;
       this.apis.celhidemenu = false;
       this.apis.getdts =false;
       this.apis.hidemenu1=false;
       this.apis.nameUser = undefined;
       this.apis.nextMessage("default message");
       this.toastr.success('Your Session Has Expired Please Login To Continue');
       this.router.navigate(['/login'])
     }
  }

  comtarray=[   {
    "userImagePath": "2ae571a8-abe1-4f2a-ad0b-bc30e19985e9.png",
    "commentId": "1",
    "comment": "nice",
    "commentCreatedDateTime": "2021-02-20 10:21:36.0",
    "nameOfTheUser": true
},
{
    "userImagePath": "2ae571a8-abe1-4f2a-ad0b-bc30e19985e9.png",
    "commentId": "2",
    "comment": "good",
    "commentCreatedDateTime": "2021-02-20 10:21:52.0",
    "nameOfTheUser": false
}
]
  

  ngOnInit(): void {
    this.commentForm = this.fb.group({
      comment:['',Validators.required],
      commentimg:[""]
      
    })
    // this.postlist.celebrityPostsResponseDTO.forEach(e => {
    //   this.hideme[e.id] = false;
    // });
    this.getPostDetails()
  }


  onFileChanged(event) {
   const img = event.target.files[0];
    this.commentForm.get('commentimg').setValue(img);
  }

  get commentcontrolers(){
    return this.commentForm.controls
  }
  showcomm(){
    console.log("show")
  
    this.showcomment=true; this.hidecomment=false
  }
  showcomm2(id){
    console.log("hide")
    Object.keys(this.hideme).forEach(h => {
      this.hideme[h] = true;
    });
    this.hideme[id] = false;
    
        this.showcomment=false; 
        this.hidecomment=true
      }
  
 

  
  

  getPostDetails(){
    console.log("celbpostlist")
    this.ngxLoader.start();
   
    this.celbService.getpostlist()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res)

      if( res['tokenStatus']=='1060'){
        if( res['response']=='1005'){

        if(res.CelebrityLikesCommentsList.length == 0 ){
          console.log("no data")
          this.posterror =true
          this.posterrorMsg =true
        }else{
          this.postlist = res.CelebrityLikesCommentsList
          this.celimg =res.profilePhoto
          this.celbname =res.celbName
        }
       
      }
      else if( res['responseStatus']=='1095'){
        console.log("no data")
        this.posterror =true
        this.posterrorMsg =true
      }
    }
     if(res['tokenStatus']=='1061'){
      this.better = "Your Session Has Expired";
      this.apis.nextMessage("default message")
      this.ngxLoader.stop();
      this.router.navigate(['/Login'])
    }
    else if(res['tokenStatus']=='1094'){
       this.ngxLoader.stop()
    }
    else if(res['tokenStatus']=='1095'){
      this.ngxLoader.stop()
      console.log("nodata")
   }
    else if(res['tokenStatus']){
      this.apis.getallres = res['tokenStatus'] ;
       this.better = this.apis.allrespnse2();
       this.ngxLoader.stop()
    }
     
    })
    .add(() => this.ngxLoader.stop());
    }

commentlist(id){


  Object.keys(this.hideme).forEach(h => {
    this.hideme[h] = false;
  });
  this.hideme[id] = true;
  
      // this.showcomment=true; 
      // this.hidecomment=false
  this.userArray=[]
  this.otheruserArray=[]
console.log("commentlist")
console.log(id)
const obj ={}

obj['postId']=id
    this.ngxLoader.start();
   
    this.userService.commentList(obj)
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res)

     
    if( res['tokenStatus']=='1060'){
      if(res['response']=='1094'){

        this.commentliststatus = false

      this.usercommentlist = res.CommentsList
//      for (let i = 0; i <  this.usercommentlist.length; i++) {


//   if(this.usercommentlist[i].userCommentOrNot == "Yes"){
//     this.userArray.push(this.usercommentlist[i])
//   }else{
// this.otheruserArray.push(this.usercommentlist[i])
//   }
//     }

    // console.log( this.userArray)
    // console.log(this.otheruserArray)

      }else if(res['response']=='1095'){
        this.commentliststatus = true
      }

    
    }
    
   if(res['tokenStatus']=='1061'){
    this.better = "Your Session Has Expired";
    this.apis.nextMessage("default message")
    this.ngxLoader.stop();
    this.router.navigate(['/Login'])
  }
  else if(res['tokenStatus']=='1094'){
     this.ngxLoader.stop()
  }
  else if(res['tokenStatus']=='1095'){
    this.ngxLoader.stop()
    console.log("nodata")
 }
  else if(res['tokenStatus']){
    this.apis.getallres = res['tokenStatus'] ;
     this.better = this.apis.allrespnse2();
     this.ngxLoader.stop()
  }
   
    
   
    })
    .add(() => this.ngxLoader.stop());
}

@HostListener('window:scroll', ['$event'])

getScrollHeight(event) {
  if(window.pageYOffset>1 )
   this.offsetFlag = false;
  else
    this.offsetFlag = true;
}

Postmessage(){
  if((this.commentForm.value.commentimg =='' || this.commentForm.value.commentimg == null) && (this.commentForm.value.comment == '' || this.commentForm.value.comment == null) ){ 
    this.submit = true

    setTimeout(() => {
      this.submit = false

    },2000)
  

  }
  else{
    this.submit = false
  
console.log("post comment")
      var formData = new FormData();

      var f = new File([""], "filename");
      if(this.commentForm.value.commentimg =='' || this.commentForm.value.commentimg == null){ 
        // console.log('doc1')
             formData.append('attachement',f);
            
          }else{
            formData.append('attachement',this.commentForm.value.commentimg);
            console.log(this.commentForm.value.commentimg)
          }

      formData.append('deviceId',"7b5014df8e2f845e671d4dc8af3614e4");
      formData.append('deviceType',"Web");
      formData.append('language',"en");
      // formData.append('attachement',this.commentForm.value.commentimg);
      formData.append('message',this.commentForm.value.comment);
      console.log("postcomment")
      this.getPostDetails()
     
      console.log(formData)
      this.ngxLoader.start();
      

      this.celbService.postMessage(formData)
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res)
     

      if( res['tokenStatus']=='1060'){
        this.commentForm.reset()
        this.commentForm.value.commentimg =""
        this.toastr.success("تم قبول التعليق  في انتظار التحقق .");
        this.getPostDetails();

      //  this.postlist = res.responseList[this.id];
      }
      
     if(res['tokenStatus']=='1061'){
      this.better = "Your Session Has Expired";
      this.apis.nextMessage("default message")
      this.ngxLoader.stop();
      this.router.navigate(['/arLogin'])
    }
    else if(res['tokenStatus']=='1094'){
       this.ngxLoader.stop()
    }
    else if(res['tokenStatus']=='1095'){
      this.ngxLoader.stop()
      console.log("nodata")
   }
    else if(res['tokenStatus']){
      this.apis.getallres = res['tokenStatus'] ;
       this.better = this.apis.allrespnse2();
       this.ngxLoader.stop()
    }
      })
      .add(() => this.ngxLoader.stop());
    }
    }
    deletemesg(id){
      const dialogRef = this.dialog.open(DeleteComponent, {
        width: '250px',
        data:{id:id}
  
  
      });
      dialogRef.afterClosed().subscribe(result => {
        this.getPostDetails()
  
      });
    }
}



@Component({
  selector: 'app-delete',
  template: `
  <div class="row">
  <div class="col-lg-12">
<div class="row" style="padding-left: 15px;">
Are you sure want to Delete this comment?
</div>
<div class="row" style="margin-top: 11%;">
<div class="col-lg-6 col-md-6 col-6">
<button type="button" class="theme-btn btn-style-one lift " (click)="delete()" ><span class="txt" >OK</span></button>
</div>
<div class="col-lg-6 col-md-6 col-6">
<button type="button" class="theme-btn btn-style-two lift "  (click)="onNoClick()"><span class="txt" >Close</span></button>
</div>
</div>

</div>
</div>



  `
})
export class DeleteComponent implements OnInit {

  id;
  user: any;
  
  listError: boolean;
  sucessMessage: string;
  errorMessage: string;
  makercheckerlist: any;
  message: any;
  rulesdeleteerrormsg: string;
  better: string;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  offsetFlag:boolean = true;

  constructor(
    public dialogRef: MatDialogRef<DeleteComponent>,@Inject(MAT_DIALOG_DATA) public data: any,private apis:ResponseServiceProvider,private celbService:CelebrityService, private ngxLoader: NgxUiLoaderService,
    private router:Router,
   
    // @Optional() @Inject(MAT_DIALOG_DATA) public data: dataSource
  ) {
    
 
this.id=data.id
  }


  ngOnInit() {
    

  }
  onNoClick() {
    this.dialogRef.close();
  }

  delete(){
      console.log("delete comment")
    const obj={}

    obj["postId"]=this.id
    obj["deviceId"]="7b5014df8e2f845e671d4dc8af3614e4"
    obj["deviceType"]="Web"
    obj["language"]="en"
   
   

 
   
    this.ngxLoader.start();
    
       
    this.celbService.deleteMsg(obj)
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res)
      if( res['tokenStatus']=='1060'){
     
        this.dialogRef.close();
      }
      
     if(res['tokenStatus']=='1061'){
      this.dialogRef.close();
      this.better = "Your Session Has Expired";
      this.apis.nextMessage("default message")
      this.ngxLoader.stop();
      this.router.navigate(['/Login'])
    }
    else if(res['tokenStatus']=='1094'){
       this.ngxLoader.stop()
    }
    else if(res['tokenStatus']=='1095'){
      this.ngxLoader.stop()
      console.log("nodata")
   }
    else if(res['tokenStatus']){
      this.dialogRef.close();
      this.apis.getallres = res['tokenStatus'] ;
       this.better = this.apis.allrespnse2();
       this.ngxLoader.stop()
    }
  
    })
    .add(() => this.ngxLoader.stop());
}

@HostListener('window:scroll', ['$event'])

getScrollHeight(event) {
  if(window.pageYOffset>1 )
   this.offsetFlag = false;
  else
    this.offsetFlag = true;
}
  
changen()
{
  this.apis.catchlang="en"
}

}