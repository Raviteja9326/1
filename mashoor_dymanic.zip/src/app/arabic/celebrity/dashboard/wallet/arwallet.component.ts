import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ResponseServiceProvider } from 'src/app/services/responses.service';

@Component({
  selector: 'app-arwallet',
  templateUrl: './arwallet.component.html',
  styleUrls: ['./arwallet.component.scss']
})
export class ArWalletComponent implements OnInit {

  offsetFlag:boolean = true;

  constructor(private apis:ResponseServiceProvider, private toastr:ToastrService, private router:Router) 
  {
    if(this.apis.getdts == undefined)
    {
      this.apis.showmenu = true;
      this.apis.hidemenu = false;
      this.apis.celhidemenu = false;
      this.apis.getdts =false;
      this.apis.hidemenu1=false;
      this.apis.nameUser = undefined;
      this.apis.nextMessage("default message")
      this.toastr.success('لقد انتهت الجلسة الخاصة بك الرجاء تسجيل الدخول للمتابعة');
      this.router.navigate(['/arlogin'])
    }
   }

  ngOnInit(): void {
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
 }

 changen()
  {
    this.apis.catchlang="en"
  }

}
