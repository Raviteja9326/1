import { Component, ElementRef, OnInit } from '@angular/core';

@Component({
  selector: 'app-arceleb',
  templateUrl: './arceleb.component.html',
  styleUrls: ['./arceleb.component.scss']
})
export class ArCelebComponent implements OnInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void {
  }



}
