import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { celebProductroutes } from './product-routing.modules';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { AddProductComponent } from './addproduct/addproduct.component';

@NgModule({
  declarations: [ProductdetailsComponent,AddProductComponent],
  imports: [
    CommonModule,
    NgbModule,
    RouterModule.forChild(celebProductroutes),
  ]
})
export class celebProductModule { }
