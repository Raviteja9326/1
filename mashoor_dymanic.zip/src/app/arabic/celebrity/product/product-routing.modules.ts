import {Routes } from '@angular/router';
import { AddProductComponent } from './addproduct/addproduct.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';

export const celebProductroutes: Routes = 
[
    { path: "ProductDetail", component: ProductdetailsComponent},
    { path: "AddProduct", component: AddProductComponent},
];


