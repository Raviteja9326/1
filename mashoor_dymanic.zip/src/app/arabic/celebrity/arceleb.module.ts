import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Arcelebroutes } from './arceleb-routing.module';
import { celebProductModule } from './product/product.module';
import { ArcelebDashboardModule } from './dashboard/ardashboard.module';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(Arcelebroutes),
    celebProductModule,
    ArcelebDashboardModule,
  ]
})
export class ArCelebModule { }
