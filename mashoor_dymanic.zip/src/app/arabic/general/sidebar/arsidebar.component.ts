import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginRegisterService } from 'src/app/services/login&register.service';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
declare var $: any;

@Component({
  selector: 'app-arsidebar',
  templateUrl: './arsidebar.component.html',
  styleUrls: ['./arsidebar.component.scss']
})
export class ArSidebarComponent implements OnInit {
  getdts:boolean = false;
  getdts2:boolean = false;
  names:any=[];
  names2:any=[];

  constructor(private apis:ResponseServiceProvider, private useservice:LoginRegisterService) 
  { 
    this.hidefunc();
    if( this.apis.nameUser == 'NA' || this.apis.nameUser == undefined)
     {
     this.names = "أهلا بك";
     }
     else
     {
       this.names = this.apis.nameUser;
     }
  }


  hidefunc()
  {
    if(this.apis.getdts==true)
    {
      this.getdts2 = false;
      this.getdts = true;
    }
   else if(this.apis.getdts==false)
   {
    this.getdts = false;
    this.getdts2 = true;
  }
    }

  ngOnInit(): void 
  {}

  logout(){
    this.useservice.getlogout2();
  }
  

}
