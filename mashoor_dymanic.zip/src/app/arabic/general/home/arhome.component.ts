import { Component, OnInit, ElementRef, Inject, HostListener, AfterViewChecked, DoCheck, OnDestroy, AfterViewInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { filter, first } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { UserService } from 'src/app/services/user.service';
declare let $:any

@Component({
  selector: 'app-arhome',
  templateUrl: './arhome.component.html',
  styleUrls: ['./arhome.component.scss']
})
export class ArHomeComponent implements OnInit , DoCheck,OnDestroy, AfterViewInit  {

  imagesList:any=[];
  hidecoming:boolean = false;
  offsetFlag:boolean=true;
  celeblist:any;
  objectKeys = Object.keys;
  celebname:any;
  loadAPI: Promise<any>;
  baseUrl: any =  "https://images.mrmashhor.sa/profile/celebrity/";
  categorylist: any;
  categorydata: any;
  getrout: any;
  leterr:boolean = false; 

  constructor( private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute, private router: Router, private apis:ResponseServiceProvider, private userService:UserService,private elementRef: ElementRef) 
  {
    this.GetGategoriesjk();
    this.Getbannerlist(); 
    this.Getceleblist();
  }

 

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event) {
    if(window.pageYOffset>1 )
     this.offsetFlag = false;
    else
      this.offsetFlag = true;
  }


  ngDoCheck() 
  {
  }



  ngOnInit()
  {
    this.apis.catchlang = "ar";
  }

  ngOnDestroy() 
  {
  }

  routeid(data)
  {
    console.log(data)
    var x = this.getKeyByValue(this.categorydata, data)
    var getrout = this.categorylist[x]
    console.log(getrout) 
    this.router.navigate(['/arcategories', getrout])     
  }

  Getbannerlist(){
    this.ngxLoader.start();
    this.userService.userbannerlst()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res);
      this.imagesList = res.bannerTypes_ar;
    })
    .add(() => this.ngxLoader.stop());
    }

    getKeyByValue(object, value) {
      return Object.keys(object).find(key => object[key] === value);
    }
  
    GetGategoriesjk(){
      this.userService.usercatlyst2()
      .subscribe((res:any) => {
        console.log(res);
      this.categorylist = res.categoryname_en;
      this.categorydata= res.categoryname_ar;
      })
      .add(() => this.ngxLoader.stop());
      }
 

  

      Getceleblist(){
        this.ngxLoader.start();
        this.userService.usercelebritylst()
        .pipe(first())
        .subscribe((res:any) => {
            if(res['response']=='1005' && res['responseStatus']=='1094'){
            this.celeblist = res.responseList;
            console.log(this.celeblist)
            this.ngxLoader.stop();
            this.hidecoming = false
            }
            else if(res['responseStatus']=='1095'){
              this.hidecoming= true
            }
        })
        .add(() => this.ngxLoader.stop());
        }

      getcelebdatas(data)
    {
      console.log(data)
      this.celebname = data.firstName;
      this.router.navigate(['/ardetails',data.categoryTypeEn,this.celebname])
    }


  

    changen()
    {
      this.apis.catchlang = "en"
    }

  
    ngAfterViewInit()
    {
      var s1 = document.createElement("script");
      s1.type = "text/javascript";
      s1.src = "/assets/js/mashhormain.js";
      this.elementRef.nativeElement.appendChild(s1);
    }   
   
 
    
}
