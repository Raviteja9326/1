import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arprivacypolicy',
  templateUrl: './arprivacypolicy.component.html',
  styleUrls: ['./arprivacypolicy.component.scss']
})
export class ArPrivacypolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
