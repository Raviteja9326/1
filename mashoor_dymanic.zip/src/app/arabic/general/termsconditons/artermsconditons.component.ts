import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artermsconditons',
  templateUrl: './artermsconditons.component.html',
  styleUrls: ['./artermsconditons.component.scss']
})
export class ArTermsconditonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
