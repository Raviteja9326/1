import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { LoginRegisterService } from 'src/app/services/login&register.service';

@Component({
  selector: 'app-arforgotpassword',
  templateUrl: './arforgotpassword.component.html',
  styleUrls: ['./arforgotpassword.component.scss']
})
export class ArforgotpasswordComponent implements OnInit {
  forgotform:FormGroup
  defaultlang: string;
  errormsg: string;
  msgdis1: boolean;
  succemsg: string;
  scmsgdis1:boolean= false
  constructor(private fb:FormBuilder,private router:Router,private forgotservice:LoginRegisterService) { }

  ngOnInit(): void {
    this.forgotform = this.fb.group({
      mobilenumber:['',[Validators.required]]
    })
  }
  get forgotcontrolers(){
    return this.forgotform.controls
  }
  changeen(lang:string)
  {
  this.defaultlang = lang
   
  }
  Submit(){
   

           
    const obj:any = {}
      
    obj['deviceId'] = "7b5014df8e2f845e671d4dc8af3614e4";
  
    obj['deviceType'] = 'Web';
    obj['language'] ='en';
   
  
  console.log(obj)
  this.forgotservice.forgotpasswordlink(obj).subscribe(res =>{
    console.log(res)
    if(res.status == "1005"){
      this.succemsg ='We have sent link to you register mobile number';
      this.scmsgdis1 = true;
       setTimeout(() => {
        this.scmsgdis1 = false;
       }, 3000);
    }
   else if(res.status == "1097"){
      this.errormsg ='PLEASE_WAIT_FOR_48HRS_FOR_NEXT_CRED_UPDATE';
      this.msgdis1 = true;
       setTimeout(() => {
        this.msgdis1 = false;
       }, 3000);
    }else{
      this.errormsg ='SOME THING WENT WRONG';
      this.msgdis1 = true;
       setTimeout(() => {
        this.msgdis1 = false;
       }, 3000);
    }
  })
  
  }
}
