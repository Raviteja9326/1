import { Component, ElementRef, OnInit, ViewEncapsulation} from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors,ValidatorFn,Validators } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PhoneNumberUtil, PhoneNumber } from 'google-libphonenumber';
import { DeviceinfoserviceService } from 'src/app/services/deviceinfoservice.service';
import { LoginRegisterService } from 'src/app/services/login&register.service';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

export function noWhitespaceValidator(control: FormControl) {
  const isSpace = (control.value || '').match(/\s/g);
  return isSpace ? {'whitespace': true} : null;
}
export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

  const phoneNumberUtil = PhoneNumberUtil.getInstance();
export function PhoneNumberValidator(regionCode: string = undefined): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    let validNumber = false;
    try {
      const phoneNumber = phoneNumberUtil.parseAndKeepRawInput(
        control.value, regionCode
      );
      validNumber = phoneNumberUtil.isValidNumber(phoneNumber);
      console.log(validNumber)
    } catch (e) { }
    return validNumber ? null : { 
      'wrongNumber': { value: control.value }
    };  
  }
}


@Component({
  selector: 'app-arlogin',
  templateUrl: './arlogin.component.html',
  styleUrls: ['./arlogin.component.scss'],
})
export class ArLoginComponent implements OnInit {

 
submitted:Boolean=false
fieldTextType: boolean;
submitpass: boolean;
better:any;
mainlog:boolean = true;
forgotlog:boolean= false;


constructor(private ngxLoader: NgxUiLoaderService,private fb: FormBuilder,private deviceservice:DeviceinfoserviceService, private loginservice: LoginRegisterService,private router:Router, private apis:ResponseServiceProvider, private toastr:ToastrService) 
  {
    this.apis.catchlang = "ar";
  }

loginform = this.fb.group({
  mobilenumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]],
  cred:['', [Validators.required, spaceValidator,Validators.minLength(8), Validators.maxLength(16),Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@('@')$!%*#?&{}[\]<>()~`"^_+=,.;:'&quot;/\\|-])[A-Za-z\d$@('@')$!%*#?&{}[\]<>()~`"^_+=;.,:'&quot;/\\|-]{8,20}$/)]]

})

forgotform = this.fb.group({
  mobilenumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]]
})


get forgotcontrolers(){
  return this.forgotform.controls
}

  ngOnInit(): void {}

  get logincontrolers(){
    return this.loginform.controls
  }

  getforgot()
  {
    this.mainlog = false;
    this.forgotlog = true;
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  changeen()
  {
    this.apis.catchlang = "en";
  }
  
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  gobackLogin()
  {
    this.mainlog = true;
    this.forgotlog = false
    this.forgotform.reset();
  }

  Submit(){

    if (!this.forgotform.valid) {
      Object.keys(this.forgotform.controls).forEach(field => {
        const control:any = this.forgotform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
        this.submitpass=true;
    }
 
    else {
      this.ngxLoader.start();
      var mobileobj= 966 + this.forgotform.value.mobilenumber;
      this.loginservice.forgotpasswordlink(mobileobj).subscribe(res =>{
    
    if(res['status']=='1005'){
      this.toastr.success("لقد أرسلنا رابطًا لك لتسجيل رقم هاتفك المحمول");
      this.gobackLogin();
      this.ngxLoader.stop();
    }
    
   else if(res['status']=='1097'){
      this.toastr.success("يرجى الانتظار لمدة 48 ساعة لتحديث كلمة المرور الجديدة");
      this.gobackLogin();
      this.ngxLoader.stop();
    }

    else if(res['status']){
      this.apis.getallres = res['status'] ;
       this.better = this.apis.allrespnse2();
       this.toastr.success(this.better);
       this.ngxLoader.stop();
    }
  })
  .add(this.ngxLoader.stopAll())
}
  
  }

  loginSend()
  {
    if (!this.loginform.valid) {
      Object.keys(this.loginform.controls).forEach(field => {
        const control:any = this.loginform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
        this.submitpass=true;
    }

      else {

        var mobileobj= 966 + this.loginform.value.mobilenumber;
        var credobj=this.loginform.value.cred
          
    
          this.ngxLoader.start();
          this.loginservice.usermobilelogin(mobileobj,credobj)
          .pipe(first())
          .subscribe((res:any) => {
        if(res['status']=='1005' && res['customerType']=="User"){
              this.apis.nameUser=res.customerName;
              this.apis.changeMessages(res);
              this.apis.nextMessage(res);
              this.apis.showmenu = false;
              this.apis.getdts = true;
              this.ngxLoader.stop();
              return this.router.navigate(['/arhome']);
              }

         if(res['status']=='1005' && res['customerType']=="Celebrity"){
            this.apis.changeMessages(res);
            this.apis.nextMessage(res);
            this.apis.celhidemenu = true;
            this.apis.getdts = false;
            this.apis.nameUser=res.customerName;
            this.ngxLoader.stop()
            return this.router.navigate(['/arcelebrity/arpostlist']);
          }

            else if(res['status']){
              this.apis.getallres = res['status'] ;
               this.better = this.apis.allrespnse2();
               this.toastr.success(this.better);
               this.ngxLoader.stop()
            }
          })
          .add(() => this.ngxLoader.stop());
        }
    
  }
    
    }
    