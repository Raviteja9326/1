import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arfooter',
  templateUrl: './arfooter.component.html',
  styleUrls: ['./arfooter.component.scss']
})
export class ArfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
