import { ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AbstractControl, FormControl, ValidationErrors,ValidatorFn,Validators } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PhoneNumberUtil } from 'google-libphonenumber';
import { LoginRegisterService } from 'src/app/services/login&register.service';
import { DeviceinfoserviceService } from 'src/app/services/deviceinfoservice.service';
import { Router } from '@angular/router';
import { CountdownComponent } from 'ngx-countdown';
import { UserService } from 'src/app/services/user.service';
import { first } from 'rxjs/operators';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { ToastrService } from 'ngx-toastr';


const phoneNumberUtil = PhoneNumberUtil.getInstance();
export function PhoneNumberValidator(regionCode: string = undefined): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    let validNumber = false;
    try {
      const phoneNumber = phoneNumberUtil.parseAndKeepRawInput(
        control.value, regionCode
      );
      validNumber = phoneNumberUtil.isValidNumber(phoneNumber);
      console.log(validNumber)
    } catch (e) { }
    return validNumber ? null : { 
      'wrongNumber': { value: control.value }
    };  
  }
}
@Component({
  selector: 'app-arregister',
  templateUrl: './arregister.component.html',
  styleUrls: ['./arregister.component.scss']
})
export class ArRegisterComponent implements OnInit {

  defaultlang:any = "English";
  otp: any;
  fieldTextType: boolean;
  showlogin:boolean = true;
  hidelogin:boolean = false;
  showinput:boolean = false;
  resndopt:boolean = true;
  resndopt2:boolean = false
  fileData: any;
  editFile: boolean = true;
	removeUpload: boolean = false;
  datacat:any=[];
  imageUrl: any;
  f: File;
  better:any;
  submitted:boolean= false;
  timeData = "120"
  config:any;


  static patternValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        // if control is empty return no error
        return null;
      }
  
      // test the value of the control against the regexp supplied
      const valid = regex.test(control.value);
  
      // if true, return no error (no error), else return error passed in the second parameter
      return valid ? null : error;
    };
  }

  constructor(private fb: FormBuilder, private ngxLoader: NgxUiLoaderService, private registerservice:LoginRegisterService,private deviceservice:DeviceinfoserviceService,private router:Router, private apis:ResponseServiceProvider, private users:UserService,private cd: ChangeDetectorRef,private toastr:ToastrService) {this.apis.catchlang = "ar";}


  @ViewChild('countdown') counter: CountdownComponent;

  registerform = this.fb.group({
    emailId:["", [Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"), Validators.required]],
    customerType:["", Validators.required],
    mobilenumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9), Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]],
    cred:['', [Validators.required,Validators.minLength(8), Validators.maxLength(16),Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@('@')$!%*#?&{}[\]<>()~`"^_+=,.;:'&quot;/\\|-])[A-Za-z\d$@('@')$!%*#?&{}[\]<>()~`"^_+=;.,:'&quot;/\\|-]{8,20}$/)]],
  })

  register2form = this.fb.group
  ({
    categoryType:["",[Validators.required]],
    samplecompost:["",[Validators.required]]
  })

  

  get registerControllers() { return this.registerform.controls }
  get registerControllers2() { return this.register2form.controls }


  ngOnInit(): void {
    this.getlist();
    this.config = {leftTime: this.timeData, demand:true};
  }
  
  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  uploadFile(event) {
		let reader = new FileReader();
		this.fileData = event.target.files[0];
		//console.log(this.fileData)
		if (event.target.files && event.target.files[0]) {
			reader.readAsDataURL(this.fileData);

			// When file uploads set it to file formcontrol
			reader.onload = () => {
				this.imageUrl = reader.result;
				this.editFile = false;
				this.removeUpload = true;
			}
			// ChangeDetectorRef since file is loading outside the zone
			this.cd.markForCheck();
		}
	}



  registerSend(){
    if (!this.registerform.valid) {
      Object.keys(this.registerform.controls).forEach(field => {
        const controlk:any = this.registerform.get(field);
        controlk.markAsTouched({ onlySelf: true });
      });
        this.submitted = true;
    }
    
    
   else { 
    if(this.registerform.value.customerType=="Celebrity")
    {
      if (!this.register2form.valid) {
        Object.keys(this.register2form.controls).forEach(field => {
          const controlk:any = this.register2form.get(field);
          controlk.markAsTouched({ onlySelf: true });
        });
          this.submitted = true;
      }
      else{
        var mobileobj= 966 + this.registerform.value.mobilenumber;
        var credobj=this.registerform.value.cred;
    
        var formData = new FormData();
        if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
          this.f = new File([""], "filename");
          formData.append("attachement", this.f);
        }
        else
        {
          this.f = this.fileData;
          formData.append("attachement", this.f);
        }
        formData.append("emailId", this.registerform.value.emailId);
        formData.append("customerType", this.registerform.value.customerType);
        formData.append("iPAddress", "122.32.252");
        formData.append("deviceId", "f6f1d0e2c1fcc8e72af497068f807a90");
        formData.append("deviceType" , "Web");
        formData.append("deviceVersion",null);
        formData.append("categoryType",this.register2form.value.categoryType);
        formData.append("latitude", "203.253.29") ;
        formData.append("longitude", "22.02.23");
        formData.append("browserVersion", null);
        formData.append("osVersion",null);
        formData.append("osType",null);
        formData.append("language", "ar");
        formData.append("browserType", null);
        formData.append("deviceName", null);
        formData.append("deviceModel", null);
        formData.append("deviceMac", null);
        formData.append("appVersion", null);
        formData.append("pushNotificationToken", null);
        this.ngxLoader.start();
        this.registerservice.userregistration(formData,mobileobj,credobj)
        .pipe(first())
        .subscribe((res:any) => {
          console.log(res)
          this.start()
        if(res["status"]=="1023")
        {
          this.toastr.success("تم إرسال OTP بنجاح");
          this.lateLogin();
          this.ngxLoader.stop();
        }
          else if(res['status']){
            this.apis.getallres = res['status'] ;
             this.better = this.apis.allrespnse2();
             this.toastr.success(this.better);
             this.stop()
             this.ngxLoader.stop()
          }
        })
        .add(this.ngxLoader.stop())
       }
    }

    if(this.registerform.value.customerType=="User")
    {
      console.log(this.registerform.value)
      var mobileobj= 966 + this.registerform.value.mobilenumber;
        var credobj=this.registerform.value.cred;
    
        var formData = new FormData();
        if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
          this.f = new File([""], "filename");
          formData.append("attachement", this.f);
        }
        else
        {
          this.f = this.fileData;
          formData.append("attachement", this.f);
        }
        formData.append("emailId", this.registerform.value.emailId);
        formData.append("customerType", this.registerform.value.customerType);
        formData.append("iPAddress", "122.32.252");
        formData.append("deviceId", "f6f1d0e2c1fcc8e72af497068f807a90");
        formData.append("deviceType" , "Web");
        formData.append("deviceVersion",null);
        formData.append("categoryType",null);
        formData.append("latitude", "203.253.29") ;
        formData.append("longitude", "22.02.23");
        formData.append("browserVersion", null);
        formData.append("osVersion",null);
        formData.append("osType",null);
        formData.append("language", "ar");
        formData.append("browserType", null);
        formData.append("deviceName", null);
        formData.append("deviceModel", null);
        formData.append("deviceMac", null);
        formData.append("appVersion", null);
        formData.append("pushNotificationToken", null);
        this.ngxLoader.start();
        this.registerservice.userregistration(formData,mobileobj,credobj)
        .pipe(first())
        .subscribe((res:any) => {
          console.log(res)
        if(res["status"]=="1023")
        {
          this.start()
          this.toastr.success("تم إرسال OTP بنجاح");
          this.lateLogin();
          this.ngxLoader.stop();
        }
          else if(res['status']){
            this.apis.getallres = res['status'] ;
             this.better = this.apis.allrespnse2();
             this.toastr.success(this.better);
             this.stop()
             this.ngxLoader.stop()
          }
        })
        .add(this.ngxLoader.stop())
    }
    
  }
}
 
 
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  changeen(lang:string)
  {
  this.defaultlang = lang
   
  }

  getlist()
  {
    this.ngxLoader.start();
    this.users.usercatlyst()
    .pipe(first())
    .subscribe((res:any) => {
if(res['response']=="1005")
{
this.datacat = res.categoriesList
console.log(this.datacat)
}
    })
    .add(this.ngxLoader.stop())
  }


  onOtpChange($event:any){
    //console.log($event)
    this.otp =$event
  }
  
  lateLogin()
  {
this.showlogin = false;
this.hidelogin = true;
  }

  gobackLogin()
  {
this.showlogin = true;
this.hidelogin = false;
if (!this.register2form.valid) {
  Object.keys(this.register2form.controls).forEach(field => {
    const controlk:any = this.register2form.get(field);
    controlk.markAsTouched({ onlySelf: true });
  });
    this.submitted = true;
}
  }

  show()
  {
this.showinput = false; 
  }

  hide()
  {
this.showinput = true; 
  }

  getotp()
  {

    var mobileobj= 966 + this.registerform.value.mobilenumber;
    var credobj=this.registerform.value.cred;
    console.log(mobileobj,credobj)
    var formData = new FormData();
    if(this.fileData =='' || this.fileData == null || this.fileData == undefined) { 
      var f = new File([""], "filename");
       formData.append("attachement", f);
     }
     else
     {
       var f2 = this.fileData;
       formData.append("attachement", f2);
     }
    formData.append("otp", this.otp);
    formData.append("iPAddress", "122.32.252");
		formData.append("deviceId", "f6f1d0e2c1fcc8e72af497068f807a90");
    formData.append("emailId", this.registerform.value.emailId);
    formData.append("customerType", this.registerform.value.customerType);
    formData.append("categoryType",this.register2form.value.categoryType);
    formData.append("deviceType" , "Web");
		formData.append("deviceVersion",null);
		formData.append("latitude", "203.253.29") ;
		formData.append("longitude", "22.02.23");
    formData.append("browserVersion", null);
		formData.append("osVersion",null);
		formData.append("osType",null);
		formData.append("language", "ar");
		formData.append("browserType", null);
		formData.append("deviceName", null);
    formData.append("deviceModel", null);
		formData.append("deviceMac", null);
		formData.append("appVersion", null);
		formData.append("pushNotificationToken", null);
    this.ngxLoader.start();
    this.registerservice.registerOtp(formData,mobileobj,credobj)
    .pipe(first())
      .subscribe((res:any) => {
        if(res['status']=='1005' && this.registerform.value.customerType=="User"){
          console.log(res.customerName)
        this.apis.nameUser=res.customerName;
        this.apis.changeMessages(res);
        this.apis.nextMessage(res);
        this.apis.showmenu = false;
        this.apis.getdts = true;
        return this.router.navigate(['/arhome']);
        }

   else if(res['status']=='1005' && this.registerform.value.customerType=="Celebrity"){
      console.log(res)
      this.apis.changeMessages(res);
      this.apis.nextMessage(res);
      this.apis.celhidemenu = true;
      this.apis.getdts = false;
      this.apis.nameUser=res.customerName;
      return this.router.navigate(['/arcelebrity/arpostlist']);
    }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse2();
           this.toastr.success(this.better);
           //console.log(this.better)
           this.ngxLoader.stop()
        }
    })
    .add(this.ngxLoader.stop())
  }


  start(){
    this.config = {leftTime:this.timeData, demand:false};
    this.resndopt=true;
    this.resndopt2=false;
    
  }
  stop(){
     this.config = {leftTime:this.timeData, demand:true};
     this.resndopt=false;
  }
  handleEvent(event){
    console.log(event.action)
    if(event.action =="start")
    {
      this.resndopt=true;
    }
    else if(event.action =="done")
    {
      this.submitted = false;
      this.resndopt=false;
      this.resndopt2=true;
    }
    
  }

}
