import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ArfooterComponent } from './footer/arfooter.component';
import { ArHeaderComponent } from './header/arheader.component';
import { ArFollowListComponent } from './follow-list/arfollow-list.component';
import { ArSidebarComponent } from './sidebar/arsidebar.component';
import { ErrorComponent } from './error/error.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  declarations: [
    ArfooterComponent,
    ArHeaderComponent,
    ArSidebarComponent,
    ArFollowListComponent,
    ErrorComponent
  ],
  exports: [
    ArfooterComponent,
    ArHeaderComponent,
    ArSidebarComponent,
    ArFollowListComponent
  ]
})
export class ArGeneralModule { }
