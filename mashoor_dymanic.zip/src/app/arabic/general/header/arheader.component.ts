import { Component, OnInit, ElementRef, Inject, OnDestroy, AfterViewInit, DoCheck, AfterContentChecked, AfterViewChecked, AfterContentInit } from '@angular/core';
import { ResponseServiceProvider } from 'src/app/services/responses.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { filter, first } from 'rxjs/operators';
import { LoginRegisterService } from 'src/app/services/login&register.service';
import { MatDialog } from '@angular/material/dialog';
import { SearchComponent } from 'src/app/english/general/search/search.component';
declare var $:any;
declare var jQuery: any;

@Component({
  selector: 'app-arheader',
  templateUrl: './arheader.component.html',
  styleUrls: ['./arheader.component.scss']
})
export class ArHeaderComponent implements OnInit, DoCheck, OnDestroy, AfterViewInit, AfterContentInit {

hidemenu:boolean = false;
showmenu:boolean = true;
hidemenu1:boolean = true;
sedlog:boolean = false;
sedlog1:boolean = false;
type:any;
closeResult: string;
defaultlang:any = "English";
categorydata:any;
better:any;
categorylist:any=[];
names:any;
names2:any;
celhidemenu:boolean=false;
searchlist: any;
celebname:any;
sugesstionstatus: boolean;
sugeestionmsg: string;
routerSubscription:any
SlideOptions = { items: 1, dots: true, nav: true };  
CarouselOptions = { items: 3, dots: true, nav: true };


  constructor(private useservice:LoginRegisterService,private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseServiceProvider, private userService:UserService,  private elementRef: ElementRef, public dialog: MatDialog) {
    this.GetGategories();
    this.hidefunc();
    if(this.apis.showmenu==true && this.apis.celhidemenu==false)
    {
      this.showmenu = true;
      this.celhidemenu = false;
      this.hidemenu1 = true;
      this.hidemenu = false;
      this.sedlog = false;
      this.sedlog1=false;
   }  
     this.type = this.apis.type;
     if( this.apis.nameUser == 'NA' || this.apis.nameUser == undefined)
     {
     this.names = "أهلا بك";
     }
     else
     {
       this.names = this.apis.nameUser;
     }
  }




  ngOnDestroy()
  {
    
  }


  jqreyset()
  {
    $(function () {
      const body = $('body');
      const sidebar = $('.sidebar');
      const offcanvas = sidebar.hasClass('sidebar--offcanvas--mobile') ? 'mobile' : 'always';
      const media = matchMedia('(max-width: 991px)');

      if (sidebar.length) {
          const open = function() {
              if (offcanvas === 'mobile' && !media.matches) {
                  return;
              }

              const bodyWidth = body.width();
              body.css('overflow', 'auto');
              body.css('paddingRight', (body.width() - bodyWidth) + 'px');

              sidebar.addClass('sidebar--open');
          };
          const close = function() {
              body.css('overflow', 'auto');
              body.css('paddingRight', '');

              sidebar.removeClass('sidebar--open');
          };
          const onMediaChange = function() {
              if (offcanvas === 'mobile') {
                  if (!media.matches && sidebar.hasClass('sidebar--open')) {
                      close();
                  }
              }
          };

          if (media.addEventListener) {
              media.addEventListener('change', onMediaChange);
          } else {
              media.addListener(onMediaChange);
          }

          $('.filters-button').on('click', function() {
              open();
          });
          $('.sidebar__backdrop, .sidebar__close').on('click', function() {
              close();
          });
      }
  });


  $(function() {
    $('.topbar__menu-button').on('click', function() {
        $(this).closest('.topbar__menu').toggleClass('topbar__menu--open');
    });

    $(document).on('click', function (event) {
        $('.topbar__menu')
            .not($(event.target).closest('.topbar__menu'))
            .removeClass('topbar__menu--open');
    });
});



    $(function () {
      const body = $('body');
      const mobileMenu = $('.mobile-menu');
      const mobileMenuBody = mobileMenu.children('.mobile-menu__body');

      if (mobileMenu.length) {
          const open = function() {
              const bodyWidth = body.width();
              body.css('overflow', 'auto');
              body.css('paddingRight', (body.width() - bodyWidth) + 'px');

              mobileMenu.addClass('mobile-menu--open');
          };
          const close = function() {
              body.css('overflow', 'auto');
              body.css('paddingRight', '');

              mobileMenu.removeClass('mobile-menu--open');
          };

          $('.mobile-header__menu-button').on('click', function() {
              open();
          });
          $('.mobile-menu__backdrop,.mobile-menu__indicator, .mobile-menu__close, .mobile-menu__links li').on('click', function() {
              close();
          });
      }

      const panelsStack = [];
      let currentPanel = mobileMenuBody.children('.mobile-menu__panel');

      mobileMenu.on('click', '[data-mobile-menu-trigger]', function(event) {
          const trigger = $(this);
          const item = trigger.closest('[data-mobile-menu-item]');
          let panel = item.data('panel');

          if (!panel) {
              panel = item.children('[data-mobile-menu-panel]').children('.mobile-menu__panel');

              if (panel.length) {
                  mobileMenuBody.append(panel);
                  item.data('panel', panel);
                  panel.width(); // force reflow
              }
          }

          if (panel && panel.length) {
              event.preventDefault();

              panelsStack.push(currentPanel);
              currentPanel.addClass('mobile-menu__panel--hide');

              panel.removeClass('mobile-menu__panel--hidden');
              currentPanel = panel;
          }
      });
      mobileMenu.on('click', '.mobile-menu__panel-back', function() {
          currentPanel.addClass('mobile-menu__panel--hidden');
          currentPanel = panelsStack.pop();
          currentPanel.removeClass('mobile-menu__panel--hide');
      });
  });


    $(function() {
      $('.indicator--trigger--click  ').on('click', function(event) {
          event.preventDefault();

          const dropdown = $(this).closest('.indicator');

          if (dropdown.is('.indicator--open')) {
              dropdown.removeClass('indicator--open');
          } else {
              dropdown.addClass('indicator--open');
          }
      });

      $(document).on('click', function (event) {
          $('.indicator')
              .not($(event.target).closest('.indicator'))
              .removeClass('indicator--open');
      });
  });
  }
 
  ngAfterViewInit()
  {
    var s1 = document.createElement("script");
    s1.type = "text/javascript";
    s1.src = "/assets/js/mashhormain.js";
    this.elementRef.nativeElement.appendChild(s1);
  } 
  



  hidefunc()
  {
    if(this.apis.showmenu==false)
    {
      this.hidemenu = true;
      this.showmenu = false;
      this.sedlog = true;
    }
   
if(this.apis.celhidemenu==true)
   {
     this.celhidemenu = true;
     this.showmenu = false;
     this.hidemenu1 = false;
     this.hidemenu = false;
     this.sedlog = false;
     this.sedlog1=true;
  }


    }

 
 ngAfterContentInit()
 {

 }   


    openCompaniesModal(): void {
      const dialogRef = this.dialog.open(SearchComponent, {
        width: '500px',
        data: {},
        position: {
          top: '20px'
        }
      });
  
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      });
    }
  

  ngOnInit()
  {
    this.jqreyset();
  }


  ngDoCheck()
  {   
    if(this.apis.showmenu==true && this.apis.celhidemenu==false)
    {
      this.showmenu = true;
      this.celhidemenu = false;
      this.hidemenu1 = true;
      this.hidemenu = false;
      this.sedlog = false;
      this.sedlog1=false;
   } 
 
  }

 

 
 


  changeen(lang:string)
  {
  this.defaultlang = lang
   
  }




  getcelebrity(data)
  {
    this.celebname = data.firstName;
    this.router.navigate(['/ardetails',data.categoryNameEn,this.celebname])
  }
 

  GetGategories(){
    this.userService.usercatlyst2()
    .pipe(first())
    .subscribe((res:any) => {
      console.log(res);
      this.categorylist = res.categoryname_en;
    this.categorydata= res.categoryname_ar;
    console.log(this.categorydata)
    })
    .add(() => this.ngxLoader.stop());
    }

    getKeyByValue(object, value) {
      return Object.keys(object).find(key => object[key] === value);
    }


    routeid(data)
    {
      var x = this.getKeyByValue(this.categorydata, data)
      var getrout = this.categorylist[x]
      console.log(getrout) 
      this.router.navigate(['/arcategories', getrout])     
    }



    
    
    onSearchChange(searchValue) {  

        if(searchValue == "" ){
          this.searchlist=[]
        }
            const object={}
            object[ 'searchName']=searchValue
                this.userService.autosuggestions(object).subscribe(res =>{
                  console.log(res) 
                 
  
                  if( res['responseStatus']=='1005'){
                     
                      // console.log( this.searchlist)
                      // console.log( this.searchlist.firstName)
  
                      if(res.response.length == 0){
                          this.searchlist =[]
                          this.sugesstionstatus=true
                          this.sugeestionmsg ="لم يتم العثور على مثل هذه النتائج"
                      }
                      else{
                          this.sugesstionstatus=false
  
                          this.searchlist =res.response
                      }
                    }
                    
                  
                  else if(res['responseStatus']=='1094'){
                     this.ngxLoader.stop()
                     this.searchlist =''
                  }
                 
                 
                }) 
          }




    logout(){
      this.useservice.getlogout2();
    }

 

}










