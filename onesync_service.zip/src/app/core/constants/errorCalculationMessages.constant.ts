export const errorCalculationMessages = {
  OneClickCategoryName:"Category Name is Required",
  LocalizedDisplayName_Xml: "Title is Required. Maximum Length Allowed For Title is 25",
  LocalizedDescription_Xml: "Description is Required",
  Expression:"Expression is Required",
  TypeName: "Unit Type is Required",
  };