export const defaultUnitSystem = {
    "unitSystem": {
        "unitName": 1,
        "precision": 0
    },
    "acceleration": {
        "unitName": 1,
        "precision": 2
    },
    "angle": {
        "unitName": 1,
        "precision": 2
    },
    "area": {
        "unitName": 1,
        "precision": 2
    },
    "capacity": {
        "unitName": 1,
        "precision": 2
    },
    "concentration": {
        "unitName": 1,
        "precision": 2
    },
    "conductivity": {
        "unitName": 1,
        "precision": 2
    },
    "curvature": {
        "unitName": 1,
        "precision": 2
    },
    "density": {
        "unitName": 1,
        "precision": 2
    },
    "differentialPressure": {
        "unitName": 1,
        "precision": 2
    },
    "dLS": {
        "unitName": 1,
        "precision": 2
    },
    "electricCurrent": {
        "unitName": 1,
        "precision": 2
    },
    "electricPotential": {
        "unitName": 1,
        "precision": 2
    },
    "electricResistance": {
        "unitName": 1,
        "precision": 2
    },
    "electricResistivity": {
        "unitName": 1,
        "precision": 2
    },
    "energy": {
        "unitName": 1,
        "precision": 2
    },
    "fann": {
        "unitName": 1,
        "precision": 2
    },
    "flow": {
        "unitName": 1,
        "precision": 2
    },
    "flowConsistencyIndex": {
        "unitName": 1,
        "precision": 2
    },
    "flowMeterKFactor": {
        "unitName": 1,
        "precision": 2
    },
    "fluidLoss": {
        "unitName": 1,
        "precision": 2
    },
    "force": {
        "unitName": 1,
        "precision": 2
    },
    "freight": {
        "unitName": 1,
        "precision": 2
    },
    "frequency": {
        "unitName": 1,
        "precision": 2
    },
    "gammaRay": {
        "unitName": 1,
        "precision": 2
    },
    "gasFlow": {
        "unitName": 1,
        "precision": 2
    },
    "gasOilRatio": {
        "unitName": 1,
        "precision": 2
    },
    "gasUnit": {
        "unitName": 1,
        "precision": 2
    },
    "gasVolume": {
        "unitName": 1,
        "precision": 2
    },
    "hydrocarbonDensity": {
        "unitName": 1,
        "precision": 2
    },
    "inverseCapacity": {
        "unitName": 1,
        "precision": 2
    },
    "intensity": {
        "unitName": 1,
        "precision": 2
    },
    "length": {
        "unitName": 1,
        "precision": 2
    },
    "linearMassDensity": {
        "unitName": 1,
        "precision": 2
    },
    "magneticField": {
        "unitName": 1,
        "precision": 2
    },
    "magneticFlux": {
        "unitName": 1,
        "precision": 2
    },
    "mass": {
        "unitName": 1,
        "precision": 2
    },
    "massFlow": {
        "unitName": 1,
        "precision": 2
    },
    "nozzleSize": {
        "unitName": 1,
        "precision": 2
    },
    "penetrationRate": {
        "unitName": 1,
        "precision": 2
    },
    "percentage": {
        "unitName": 1,
        "precision": 2
    },
    "permeability": {
        "unitName": 1,
        "precision": 2
    },
    "power": {
        "unitName": 1,
        "precision": 2
    },
    "pressure": {
        "unitName": 1,
        "precision": 2
    },
    "pressureGradient": {
        "unitName": 1,
        "precision": 2
    },
    "pumpOutput": {
        "unitName": 1,
        "precision": 2
    },
    "pumpSpeed": {
        "unitName": 1,
        "precision": 2
    },
    "rate": {
        "unitName": 1,
        "precision": 2
    },
    "resistivityPerLength": {
        "unitName": 1,
        "precision": 2
    },
    "rotationVelocity": {
        "unitName": 1,
        "precision": 2
    },
    "shortLength": {
        "unitName": 1,
        "precision": 2
    },
    "slowness": {
        "unitName": 1,
        "precision": 2
    },
    "specificHeatCapacity": {
        "unitName": 1,
        "precision": 2
    },
    "stiffness": {
        "unitName": 1,
        "precision": 2
    },
    "stress": {
        "unitName": 1,
        "precision": 2
    },
    "stressCoeff": {
        "unitName": 1,
        "precision": 2
    },
    "temperature": {
        "unitName": 1,
        "precision": 2
    },
    "thermalCoefficient": {
        "unitName": 1,
        "precision": 2
    },
    "thermalConductivity": {
        "unitName": 1,
        "precision": 2
    },
    "thermalGradient": {
        "unitName": 1,
        "precision": 2
    },
    "time": {
        "unitName": 1,
        "precision": 2
    },
    "torque": {
        "unitName": 1,
        "precision": 2
    },
    "velocityFluid": {
        "unitName": 1,
        "precision": 2
    },
    "velocityRunningSpeed": {
        "unitName": 1,
        "precision": 2
    },
    "viscosity": {
        "unitName": 1,
        "precision": 2
    },
    "volume": {
        "unitName": 1,
        "precision": 2
    },
    "yieldPoint": {
        "unitName": 1,
        "precision": 2
    },
    "unitlessPrecision": {
        "unitName": 1,
        "precision": 2
    }
};