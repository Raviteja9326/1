export const errorMessages = {
  TrueVerticalDepth:"TVD must be in increasing order",
  Temperature:"",
  GeothermalGradient:"GeothermalGradient must be less than 2.48"
  };