export const errorConditionMessages = {
  OneClickCategoryName:"Category Name is mandatory",
  LocalizedConditionName_Xml: "Name is mandatory",
  LocalizedConditionDescription_Xml: "Description is mandatory",
  Expression:"Expression is mandatory",
  };