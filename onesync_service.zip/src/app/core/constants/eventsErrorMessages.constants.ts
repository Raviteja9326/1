export const errorMessages = {
    OneClickCategoryName:"",
    LocalizedName_Xml:"Event Name is Required",
    LocalizedDescription_Xml:"Event Description is Required"
  };