export const CuttingSizes = [
    { label: "Custom", value: 1, diameter: 0 },
    { label: "Large", value: 2, diameter: 0.25 },
    { label: "Medium", value: 3, diameter: 0.15 },
    { label: "Medium Large", value: 4, diameter: 0.2 },
    { label: "Medium Small", value: 5, diameter: 0.1 },
    { label: "Small", value: 6, diameter: 0.05 },
]

/* .NET code
private void applyCuttingsSizeProperty()
{
    if (CuttingsSize == Cuttings.Small)
        CuttingsDiameter = 0.05;
    else if (CuttingsSize == Cuttings.MediumSmall)
        CuttingsDiameter = 0.1;
    else if (CuttingsSize == Cuttings.Medium)
        CuttingsDiameter = 0.15;
    else if (CuttingsSize == Cuttings.MediumLarge)
        CuttingsDiameter = 0.2;
    else if (CuttingsSize == Cuttings.Large)
        CuttingsDiameter = 0.25;

    OnPropertyChanged(nameof(CuttingsDiameter));
    OnPropertyChanged(nameof(CanEditCuttingsDiameter));
}
*/