//  ALLOWS
//  A-Z,a-z
//  0-9

import { FormControl } from '@angular/forms';
import { AbstractControl, Validators } from '@angular/forms';
//  [!@#$%^&\*-/_.]
export const TEXT_REGEX_1 = '^[a-zA-Z0-9!@#$%^&*\\-/_.]+$';
//  ALLOWS
//  A-Z,a-z
//  0-9
//  [.-_]
export const TEXT_REGEX_2 = '^[A-Za-z0-9._-]+$';
//  ALLOWS
//  A-Z,a-z
//  0-9
//  [.-_]
// SPACE
export const TEXT_REGEX_3 = '^[A-Za-z0-9._ -]+$';
//  ALLOWS
//  A-Z,a-z
//  0-9
//  [!@#$%^&\*-/_.]
//space
export const TEXT_REGEX_4 = '^[a-zA-Z0-9!@#$%^)(&*\\-/_ .]+$';
export const TEXT_REGEX_5 = '^[a-zA-Z0-9!@#$%^)(&*\\-/_.]+$';
//Email
export const emailRegex =
  '^[a-zA-Z0-9._%+-]+@(?!.*.com.*.com)([a-zA-Z0-9-]+.)+[a-zA-Z]{2,}$';

//IP ADDRESS
export const IP_REGEX =
  '^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?).){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$';
// DOMAIN ADDRESS
export const DOMAIN_REGEX =
  '^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?.)+[a-zA-Z]{2,}$';
//
export const validateHostAddress = (c: FormControl) => {
  //console.log('sdsd', c.value);
  if (c.value == null) return null;
  return c.value.match(DOMAIN_REGEX) || c.value.match(IP_REGEX)
    ? null
    : { pattern: true };
};

export class CustomValidators {
  static requiredIfEditable(editable: boolean) {
    return editable ? Validators.required : null;
  }

  static maxLengthIfEditable(editable: boolean, maxLength: number) {
    return editable ? Validators.maxLength(maxLength) : null;
  }

  static noContinuousSpaces(control) {
    if (/^\s+$/.test(control.value)) {
      return { continuousSpaces: true };
    }
    return null;
  }

  static greaterThanZero(control: AbstractControl) {

    const value = parseFloat(control.value);
    if (value <= 0.00) {
      return { greaterThanZero: true };
    }
    return null;
  }

  static greaterThanMin(minValue: number, isIncludeNum: boolean = true) {
    return (control: AbstractControl) => {
      const value = parseFloat(control.value);
      if (isIncludeNum) {
        if (value <= minValue) {
          return { greaterThanMin: true };  // Validation passed
        }
      } else {
        if (value < minValue) {
          return { greaterThanMin: true };
        }
      }
      return null;
    };
  }

  static lessThanMax(maxValue: number, isIncludeNum: boolean = true) {
    return (control: AbstractControl) => {
      const value = parseFloat(control.value);
      if (isIncludeNum) {
        if (value >= maxValue) {
          return { lessThanMax: true };  // Validation passed
        }
      } else {
        if (value > maxValue) {
          return { lessThanMax: true };
        }
      }
      return null;
    };
  }

  static lessThanMaxOrEqual(maxValue: number, isIncludeNum: boolean = true) {
    return (control: AbstractControl) => {
      const value = parseFloat(control.value);
      if (isIncludeNum) {
        if (value > maxValue) {
          return { lessThanMaxOrEqual: true };  // Validation passed
        }
      } else {
        if (value > maxValue) {
          return { lessThanMaxOrEqual: true };
        }
      }
      return null;
    };
  }

  static wholeNumber(control: AbstractControl){
   
      // Check if the control value is a number
      if (isNaN(control.value)) {
        return null;
      }
  
      // Check if the control value is a whole number
      if (control.value % 1 !== 0) {
        return { 'wholeNumber': true };
      }
  
      return null; // Validation passes
  }
}