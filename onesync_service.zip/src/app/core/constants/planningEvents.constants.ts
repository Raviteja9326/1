export const planningEvents = [
    { label: 'Auto', value: '0' },
    { label: 'Other', value: '1' },
    { label: 'KPIs', value: '2' },

]