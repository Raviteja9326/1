/**
 * Below is the class for roles
 */
export const roleDefinitions =  {

    roles : {
        0: 'Creator',
        1: 'Reviewer',
        2: 'Approver',
        3: 'CFS Operator',
        4: 'Client Representative',
        5: 'Crew',
        6: 'DAQ Operator',
        7: 'Data Engineer',
        8: 'DD Coordinator',
        9: 'Derrickhand'
    }, //end of 'roles'

    rolesId :{
        'Creator': 0,
        'Reviewer': 1,
        'Approver':2,
        'CFS Operator':3,
        'Client Representative':4,
        'Crew':5,
        'DAQ Operator':6,
        'Data Engineer':7,
        'DD Coordinator':8,
        'Derrickhand':9
    } //end of 'roles'
} //end of 'roleDefinitions'