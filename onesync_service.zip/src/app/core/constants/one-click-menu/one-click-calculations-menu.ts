export const CalculationsMenu = [
    {
        label: 'Configuration',
        submenu:[
            {
            label:"DrillString Configuration",
            submenu:[
                { "label": "Azimuth Error" },
                { "label": "Azimuth Error Status" },
                { "label": "BHA Jar Placement Adequate" },
                { "label": "Bit TFA", unittype:"tfa" },
                { "label": "Bit OD", unittype:"length" },
                { "label": "BSR" },
                { "label": "Drill Stream Jars Placement Adequate" },
                { "label": "Drilling Motor Bearing Pack Bypass TFA", unittype:"tfa" },
                { "label": "Has Drilling Motor" },
                { "label": "Has Magnus RSS" },
                { "label": "Has Mk3/Mk4 RSS" },
                { "label": "Hole/Bit Size Collar Ratio" },
                { "label": "JSA" },
                { "label": "Magnus RSS Restrictors Size", unittype:"shortlength"  },
                { "label": "Min BHA OD", unittype:"length" },
                { "label": "Motor Flow Rate Max", unittype:"flow" },
                { "label": "Motor Flow Rate Min", unittype:"flow" },
                { "label": "Motor Max Bit Overpull Operating", unittype:"force" },
                { "label": "Motor Max Bit Overpull Static", unittype:"force" },
                { "label": "Motor Max Body Overpull Operating", unittype:"force" },
                { "label": "Motor Max Body Overpull Static", unittype:"force" },
                { "label": "Motor Max Differential Pressure", unittype:"pressure" },
                { "label": "Motor Max Torque" , unittype:"torque"},
                { "label": "Motor Max WOB", unittype:"force" },
                { "label": "Motor Power Performance Speed Ratio", unittype:"speedratio" },
                { "label": "Motor Speed Range Max", unittype:"rotatoryspeed" },
                { "label": "Motor Speed Range Min", unittype:"rotatoryspeed" },
                { "label": "Motor Speed Ratio", unittype:"speedratio"},
                { "label": "Motor Torque Ratio", unittype:"torqueratio" },
                { "label": "Stiffness Ratio" }
            ]
            },
            {
                label:"Equipment Configuration",
                submenu:[
                    { "label": "AirGap", unittype:"length"  },
                    { "label": "Block Max Height", unittype:"length" },
                    { "label": "Block Weight" , unittype:"force"},
                    { "label": "Max Hoisting Capacity", unittype:"force" },
                    { "label": "Max Torque", unittype:"torque"},
                    { "label": "Pump Pop Off Pressure", unittype:"pressure"  },
                    { "label": "Water Depth", unittype:"length"  }
                  ]
            },
            {
                label:"Well Interval Configuration",
                submenu:[
                    { "label": "Casing Depth", unittype:"length"  },
                  ]
                  
            },
            {
              label:"WellPath Configuration",
              submenu:[
                { "label": "Absolute Tortuosity",unittype:"doglegseverity"},
                    { "label": "Azimuth" , unittype:"angle"},
                    { "label": "Build Rate", unittype:"doglegseverity" },
                    { "label": "Course Length", unittype:"length"  },
                    { "label": "DDI" },
                    { "label": "DLS",unittype:"doglegseverity" },
                    { "label": "East West", unittype:"length"  },
                    { "label": "H.Disp", unittype:"length" },
                    { "label": "Inclination", unittype:"angle" },
                    { "label": "Lateral Distance" , unittype:"length"},
                    { "label": "Measured Depth" , unittype:"length"},
                    { "label": "North South", unittype:"length" },
                    { "label": "Tool Face", unittype:"angle" },
                    { "label": "Tortuosity" , unittype:"angle"},
                    { "label": "True Vertical Depth" , unittype:"length"},
                    { "label": "Turn Rate", unittype:"doglegseverity" },
                    { "label": "TVDSS", unittype:"length" },
                    { "label": "VS", unittype:"length" }
              ]
            }
        ]
            
        
    },
    {
        label:"Analysis Data",
        submenu:[
            {
                label:"BHA Static",
                submenu:[
                    { "label": "75% of VM Stress Threshold", unittype:"stress" },
                    { "label": "Axial Force", unittype:"force" },
                    { "label": "Axial Stress", unittype:"stress" },
                    { "label": "Bending Stress", unittype:"torque" },
                    { "label": "Bending Moment", unittype:"torque" },
                    { "label": "CF Threshold" , unittype:"force"},
                    { "label": "Horizontal Displacement", unittype:"length" },
                    { "label": "Minimum Clearance" , unittype:"shortlength"},
                    { "label": "Vertical Displacement", unittype:"length" },
                    { "label": "VM Stress Threshold" , unittype:"stress"},
                    { "label": "Von Mises Stress", unittype:"stress" },
                    { "label": "Wellbore Contact", unittype:"force" }
                  ]
                  
            },
            {
                label:"BHA Vibrational",
                submenu:[
                  { "label": "75% of VM Stress Threshold", unittype:"stress" },
                  { "label": "Axial Force", unittype:"force" },
                  { "label": "Axial Stress", unittype:"stress" },
                    { "label": "Axial Vibrations" },
                    { "label": "Bending Stress", unittype:"torque" },
                    { "label": "Bending Moment", unittype:"torque" },
                    { "label": "CF Threshold" , unittype:"force"},
                    { "label": "Horizontal Displacement", unittype:"length" },
                    { "label": "Lateral Vibrations" },
                    { "label": "Minimum Clearance" , unittype:"shortlength"},
                    { "label": "Torsional Vibrations" },
                    { "label": "Vertical Displacement", unittype:"length" },
                    { "label": "VM Stress Threshold" , unittype:"stress"},
                    { "label": "Von Mises Stress", unittype:"stress" },
                    { "label": "Wellbore Contact", unittype:"force" },
                   
                    
                  ]                  
                  
            },
            {
                label:"Directional Tendencies(rotory)",
                submenu:[
                    { "label": "Build Rate", unittype:"doglegseverity" },
                    { "label": "DLS", unittype:"doglegseverity"  },
                    { "label": "Turn Rate", unittype:"doglegseverity"  }
                  ]
                                  
                  
            },
            {
                label:"Directional Tendencies(Sliding)",
                submenu:[
                    { "label": "Build Rate", unittype:"doglegseverity"  },
                    { "label": "DLS", unittype:"doglegseverity"  },
                    { "label": "Turn Rate", unittype:"doglegseverity"  }
                  ]      
            },
            {
                label:"Drillstring Design",
                submenu: [
                    { "label": "Axial Load(Rotary)",unittype:"force" },
                    { "label": "Axial Load(Sliding)" ,unittype:"force" },
                    { "label": "Axial Load(Running In)" ,unittype:"force" },
                    { "label": "Axial Load(Pulling Out)",unittype:"force"  },
                    { "label": "Axial Load(RoffB)" ,unittype:"force" },
                    { "label": "Axial Load(Reaming)",unittype:"force"  },
                    { "label": "Axial Load(Pick Up)",unittype:"force"  },
                    { "label": "Axial Load(Slack Off)" ,unittype:"force" },
                    { "label": "Axial Load(Underreaming)" ,unittype:"force" },
                    { "label": "Axial Load(Cutting)" ,unittype:"force" },
                    { "label": "Axial Load(Custom Up)" ,unittype:"force" },
                    { "label": "Axial Load(Custom Down)",unittype:"force"  },
                    { "label": "Axial Load(Custom Stationary)" ,unittype:"force" },
                    { "label": "Axial Load(Back Reaming)",unittype:"force"  },
                    { "label": "Axial Stress(Rotary)",unittype:"stress" },
                    { "label": "Axial Stress(Sliding)" ,unittype:"stress"},
                    { "label": "Axial Stress(Running In)" ,unittype:"stress"},
                    { "label": "Axial Stress(Pulling Out)" ,unittype:"stress"},
                    { "label": "Axial Stress(RoffB)",unittype:"stress" },
                    { "label": "Axial Stress(Reaming)",unittype:"stress" },
                    { "label": "Axial Stress(Pick Up)" ,unittype:"stress"},
                    { "label": "Axial Stress(Slack Off)" ,unittype:"stress"},
                    { "label": "Axial Stress(Underreaming)",unittype:"stress" },
                    { "label": "Axial Stress(Cutting)",unittype:"stress" },
                    { "label": "Axial Stress(Custom Up)" ,unittype:"stress"},
                    { "label": "Axial Stress(Custom Down)",unittype:"stress" },
                    { "label": "Axial Stress(Custom Stationary)",unittype:"stress" },
                    { "label": "Axial Stress(Back Reaming)" ,unittype:"stress"},
                    { "label": "Bending Moment(Rotary)" , unittype:"torque"},
                    { "label": "Bending Moment(Sliding)" , unittype:"torque"},
                    { "label": "Bending Moment(Running In)" , unittype:"torque"},
                    { "label": "Bending Moment(Pulling Out)" , unittype:"torque"},
                    { "label": "Bending Moment(RoffB)", unittype:"torque" },
                    { "label": "Bending Moment(Reaming)" , unittype:"torque"},
                    { "label": "Bending Moment(Pick Up)" , unittype:"torque"},
                    { "label": "Bending Moment(Slack Off)" , unittype:"torque"},
                    { "label": "Bending Moment(Underreaming)" , unittype:"torque"},
                    { "label": "Bending Moment(Cutting)" , unittype:"torque"},
                    { "label": "Bending Moment(Custom Up)", unittype:"torque" },
                    { "label": "Bending Moment(Custom Down)", unittype:"torque" },
                    { "label": "Bending Moment(Custom Stationary)", unittype:"torque" },
                    { "label": "Bending Moment(Back Reaming)", unittype:"torque" },
                    { "label": "Bending Stress(Rotary)" , unittype:"stress"},
                    { "label": "Bending Stress(Sliding)" , unittype:"stress"},
                    { "label": "Bending Stress(Running In)" , unittype:"stress"},
                    { "label": "Bending Stress(Pulling Out)" , unittype:"stress"},
                    { "label": "Bending Stress(RoffB)", unittype:"stress" },
                    { "label": "Bending Stress(Reaming)" , unittype:"stress"},
                    { "label": "Bending Stress(Pick Up)" , unittype:"stress"},
                    { "label": "Bending Stress(Slack Off)" , unittype:"stress"},
                    { "label": "Bending Stress(Underreaming)" , unittype:"stress"},
                    { "label": "Bending Stress(Cutting)" , unittype:"stress"},
                    { "label": "Bending Stress(Custom Up)", unittype:"stress" },
                    { "label": "Bending Stress(Custom Down)", unittype:"stress" },
                    { "label": "Bending Stress(Custom Stationary)", unittype:"stress" },
                    { "label": "Bending Stress(Back Reaming)", unittype:"stress" },
                    { "label": "Compression Limit", unittype:"force"},
                    { "label": "Contact Force(Rotary)" ,unittype:"force" },
                    { "label": "Contact Force(Sliding)",unittype:"force"  },
                    { "label": "Contact Force(Running In)" ,unittype:"force" },
                    { "label": "Contact Force(Pulling Out)",unittype:"force"  },
                    { "label": "Contact Force(RoffB)" ,unittype:"force" },
                    { "label": "Contact Force(Reaming)" ,unittype:"force" },
                    { "label": "Contact Force(Pick Up)" ,unittype:"force" },
                    { "label": "Contact Force(Slack Off)",unittype:"force"  },
                    { "label": "Contact Force(Underreaming)" ,unittype:"force" },
                    { "label": "Contact Force(Cutting)" ,unittype:"force" },
                    { "label": "Contact Force(Custom Up)",unittype:"force"  },
                    { "label": "Contact Force(Custom Down)",unittype:"force"  },
                    { "label": "Contact Force(Custom Stationary)" ,unittype:"force" },
                    { "label": "Contact Force(Back Reaming)" ,unittype:"force" },
                    { "label": "Eccentricity(Rotary)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Sliding)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Running In)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Pulling Out)",unittype:"percentage"  },
                    { "label": "Eccentricity(RoffB)",unittype:"percentage"  },
                    { "label": "Eccentricity(Reaming)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Pick Up)",unittype:"percentage"  },
                    { "label": "Eccentricity(Slack Off)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Underreaming)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Cutting)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Custom Up)",unittype:"percentage"  },
                    { "label": "Eccentricity(Custom Down)" ,unittype:"percentage" },
                    { "label": "Eccentricity(Custom Stationary)",unittype:"percentage"  },
                    { "label": "Eccentricity(Back Reaming)",unittype:"percentage"  },
                    { "label": "Hel. Buckling" ,unittype:"force" },
                    { "label": "Hel. Buckling HL Threshold",unittype:"force" },
                    { "label": "Hel. Buckling Threshold" , unittype:"force"},
                    { "label": "Hel. Buckling Threshold Rotary" ,unittype:"force"},
                    { "label": "Hook Load(Rotary)" , unittype:"force"},
                    { "label": "Hook Load(Sliding)", unittype:"force" },
                    { "label": "Hook Load(Running In)", unittype:"force"},
                    { "label": "Hook Load(Pulling Out)" , unittype:"force"},
                    { "label": "Hook Load(RoffB)" , unittype:"force"},
                    { "label": "Hook Load(Reaming)" , unittype:"force"},
                    { "label": "Hook Load(Pick Up)" , unittype:"force"},
                    { "label": "Hook Load(Slack Off)" , unittype:"force"},
                    { "label": "Hook Load(Underreaming)" , unittype:"force"},
                    { "label": "Hook Load(Cutting)" , unittype:"force"},
                    { "label": "Hook Load(Custom Up)" , unittype:"force"},
                    { "label": "Hook Load(Custom Down)", unittype:"force" },
                    { "label": "Hook Load(Custom Stationary)", unittype:"force" },
                    { "label": "Hook Load(RoffB actual)" , unittype:"force"},
                    { "label": "Hook Load(Running In Actual)" , unittype:"force"},
                    { "label": "Hook Load(Pulling Out Actual)", unittype:"force" },
                    { "label": "Hook Load(Back Reaming)" , unittype:"force"},
                    { "label": "Hoop Stress(Rotary)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Sliding)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Running In)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Pulling Out)" ,unittype:"stress"},
                    { "label": "Hoop Stress(RoffB)",unittype:"stress" },
                    { "label": "Hoop Stress(Pick Up)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Slack Off)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Underreaming)",unittype:"stress" },
                    { "label": "Hoop Stress(Cutting)",unittype:"stress" },
                    { "label": "Hoop Stress(Custom Up)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Custom Down)",unittype:"stress" },
                    { "label": "Hoop Stress(Custom Stationary)" ,unittype:"stress"},
                    { "label": "Hoop Stress(Back Reaming)" ,unittype:"stress"},
                    { "label": "Make Up Torque", unittype:"torque" },
                    { "label": "Neutral Point Check(Rotary)" },
                    { "label": "Neutral Point Check(Sliding)" },
                    { "label": "Neutral Point Check(Running In)" },
                    { "label": "Neutral Point Check(Pulling Out)" },
                    { "label": "Neutral Point Check(RoffB)" },
                    { "label": "Neutral Point Check(Reaming)" },
                    { "label": "Neutral Point Check(Pick Up)" },
                    { "label": "Neutral Point Check(Slack Off)" },
                    { "label": "Neutral Point Check(Underreaming)" },
                    { "label": "Neutral Point Check(Cutting)" },
                    { "label": "Neutral Point Check(Custom Up)" },
                    { "label": "Neutral Point Check(Custom Down)" },
                    { "label": "Neutral Point Check(Custom Stationary)" },
                    { "label": "Neutral Point Check(Back Reaming)" },
                    { "label": "Pressure In Annulus(Rotary)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Sliding)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Running In)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Pulling Out)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(RoffB)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Reaming)",unittype:"stress" },
                    { "label": "Pressure In Annulus(Pick Up)",unittype:"stress" },
                    { "label": "Pressure In Annulus(Slack Off)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Underreaming)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Cutting)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Custom Up)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Custom Down)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Custom Stationary)" ,unittype:"stress"},
                    { "label": "Pressure In Annulus(Back Reaming)",unittype:"stress" },
                    { "label": "Pressure Inside Drillstring(Rotary)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Sliding)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Running In)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Pulling Out)",unittype:"stress" },
                    { "label": "Pressure Inside Drillstring(RoffB)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Reaming)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Pick Up)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Slack Off)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Underreaming)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Cutting)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Custom Up)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Custom Down)",unittype:"stress" },
                    { "label": "Pressure Inside Drillstring(Custom Stationary)" ,unittype:"stress"},
                    { "label": "Pressure Inside Drillstring(Back Reaming)" ,unittype:"stress"},
                    { "label": "Radial Clearance(Rotary)" ,unittype:"length"},
                    { "label": "Radial Clearance(Sliding)" ,unittype:"length"},
                    { "label": "Radial Clearance(Running In)" ,unittype:"length"},
                    { "label": "Radial Clearance(Pulling Out)",unittype:"length" },
                    { "label": "Radial Clearance(RoffB)" ,unittype:"length"},
                    { "label": "Radial Clearance(Reaming)" ,unittype:"length"},
                    { "label": "Radial Clearance(Pick Up)",unittype:"length" },
                    { "label": "Radial Clearance(Slack Off)" ,unittype:"length"},
                    { "label": "Radial Clearance(Underreaming)" ,unittype:"length"},
                    { "label": "Radial Clearance(Cutting)" ,unittype:"length"},
                    { "label": "Radial Clearance(Custom Up)" ,unittype:"length"},
                    { "label": "Radial Clearance(Custom Down)",unittype:"length" },
                    { "label": "Radial Clearance(Custom Stationary)" ,unittype:"length"},
                    { "label": "Radial Clearance(Back Reaming)" ,unittype:"length"},
                    { "label": "Radial Stress(Rotary)",unittype:"stress" },
                    { "label": "Radial Stress(Sliding)",unittype:"stress" },
                    { "label": "Radial Stress(Running In)",unittype:"stress" },
                    { "label": "Radial Stress(Pulling Out)",unittype:"stress" },
                    { "label": "Radial Stress(RoffB)",unittype:"stress" },
                    { "label": "Radial Stress(Reaming)",unittype:"stress" },
                    { "label": "Radial Stress(Pick Up)" ,unittype:"stress"},
                    { "label": "Radial Stress(Slack Off)" ,unittype:"stress"},
                    { "label": "Radial Stress(Underreaming)" ,unittype:"stress"},
                    { "label": "Radial Stress(Cutting)" ,unittype:"stress"},
                    { "label": "Radial Stress(Custom Up)" ,unittype:"stress"},
                    { "label": "Radial Stress(Custom Down)" ,unittype:"stress"},
                    { "label": "Radial Stress(Custom Stationary)",unittype:"stress" },
                    { "label": "Radial Stress(Back Reaming)",unittype:"stress" },
                    { "label": "Rig Hoisting Capacity",unittype:"force" },
                    { "label": "Rig Torque Capacity" ,unittype:"force"},
                    { "label": "Shear Stress(Rotary)" ,unittype:"stress"},
                    { "label": "Shear Stress(Sliding)" ,unittype:"stress"},
                    { "label": "Shear Stress(Running In)" ,unittype:"stress"},
                    { "label": "Shear Stress(Pulling Out)" ,unittype:"stress"},
                    { "label": "Shear Stress(RoffB)" ,unittype:"stress"},
                    { "label": "Shear Stress(Reaming)" ,unittype:"stress"},
                    { "label": "Shear Stress(Pick Up)",unittype:"stress" },
                    { "label": "Shear Stress(Slack Off)" ,unittype:"stress"},
                    { "label": "Shear Stress(Underreaming)" ,unittype:"stress"},
                    { "label": "Shear Stress(Cutting)" ,unittype:"stress"},
                    { "label": "Shear Stress(Custom Up)" ,unittype:"stress"},
                    { "label": "Shear Stress(Custom Down)" ,unittype:"stress"},
                    { "label": "Shear Stress(Custom Stationary)",unittype:"stress" },
                    { "label": "Shear Stress(Back Reaming)",unittype:"stress" },
                    { "label": "Sin. Buckling" ,unittype:"force"},
                    { "label": "Sin. Buckling HL Threshold" ,unittype:"force"},
                    { "label": "Sin. Buckling Threshold",unittype:"force" },
                    { "label": "Stretch/Shortening (Rotary)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Sliding)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Running In)",unittype:"length" },
                    { "label": "Stretch/Shortening (Pulling Out)",unittype:"length" },
                    { "label": "Stretch/Shortening (RoffB)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Reaming)",unittype:"length" },
                    { "label": "Stretch/Shortening (Pick Up)",unittype:"length" },
                    { "label": "Stretch/Shortening (Slack Off)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Underreaming)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Cutting)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Custom Up)",unittype:"length" },
                    { "label": "Stretch/Shortening (Custom Down)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Custom Stationary)" ,unittype:"length"},
                    { "label": "Stretch/Shortening (Back Reaming)",unittype:"length" },
                    { "label": "String Buoyant Weight Per unit Length", },
                    { "label": "String Position Y(Rotary)",unittype:"shortlength" },
                    { "label": "String Position Y(Sliding)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Running In)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Pulling Out)" ,unittype:"shortlength"},
                    { "label": "String Position Y(RoffB)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Reaming)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Pick Up)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Slack Off)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Underreaming)",unittype:"shortlength" },
                    { "label": "String Position Y(Cutting)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Custom Up)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Custom Down)",unittype:"shortlength" },
                    { "label": "String Position Y(Custom Stationary)" ,unittype:"shortlength"},
                    { "label": "String Position Y(Back Reaming)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Rotary)",unittype:"shortlength" },
                    { "label": "String Position Z(Sliding)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Running In)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Pulling Out)",unittype:"shortlength" },
                    { "label": "String Position Z(RoffB)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Reaming)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Pick Up)",unittype:"shortlength" },
                    { "label": "String Position Z(Slack Off)",unittype:"shortlength" },
                    { "label": "String Position Z(Underreaming)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Cutting)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Custom Up)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Custom Down)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Custom Stationary)" ,unittype:"shortlength"},
                    { "label": "String Position Z(Back Reaming)",unittype:"shortlength" },
                    { "label": "Surface Torque(Rotary)",unittype:"torque"  },
                    { "label": "Surface Torque(Sliding)" ,unittype:"torque"},
                    { "label": "Surface Torque(Running In)" ,unittype:"torque"},
                    { "label": "Surface Torque(Pulling Out)",unittype:"torque" },
                    { "label": "Surface Torque(RoffB)",unittype:"torque" },
                    { "label": "Surface Torque(Reaming)",unittype:"torque" },
                    { "label": "Surface Torque(Pick Up)" ,unittype:"torque"},
                    { "label": "Surface Torque(Slack Off)" ,unittype:"torque"},
                    { "label": "Surface Torque(Underreaming)",unittype:"torque" },
                    { "label": "Surface Torque(Cutting)",unittype:"torque" },
                    { "label": "Surface Torque(Custom Up)",unittype:"torque" },
                    { "label": "Surface Torque(Custom Down)" ,unittype:"torque"},
                    { "label": "Surface Torque( RoffB Actual)" ,unittype:"torque"},
                    { "label": "Surface Torque( Back Reaming)" ,unittype:"torque"},
                    { "label": "Surface Torque Threshold" ,unittype:"torque"},
                    { "label": "Tensile OverLoad HL Threshold",unittype:"force"  },
                    { "label": "Tension Threshold",unittype:"force"  },
                    { "label": "Torque(Rotary)",unittype:"torque" },
                    { "label": "Torque(Sliding)" ,unittype:"torque"},
                    { "label": "Torque(Running In)",unittype:"torque" },
                    { "label": "Torque(Pulling Out)" ,unittype:"torque"},
                    { "label": "Torque(RoffB)" ,unittype:"torque"},
                    { "label": "Torque(Reaming)" ,unittype:"torque"},
                    { "label": "Torque(Pick Up)",unittype:"torque" },
                    { "label": "Torque(Slack Off)" ,unittype:"torque"},
                    { "label": "Torque(Underreaming)",unittype:"torque" },
                    { "label": "Torque(Cutting)" ,unittype:"torque"},
                    { "label": "Torque(Custom Up)" ,unittype:"torque"},
                    { "label": "Torque(Custom Down)",unittype:"torque" },
                    { "label": "Torque(Custom Stationary)" ,unittype:"torque"},
                    { "label": "Torque(Back Reaming)" ,unittype:"torque"},
                    { "label": "Torque Threshold",unittype:"torque" },
                    { "label": "Torsional Stress(Rotary)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Sliding)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Running In)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Pulling Out)" ,unittype:"stress"},
                    { "label": "Torsional Stress(RoffB)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Reaming)",unittype:"stress" },
                    { "label": "Torsional Stress(Pick Up)",unittype:"stress" },
                    { "label": "Torsional Stress(Slack Off)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Underreaming)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Cutting)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Custom Up)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Custom Down)",unittype:"stress" },
                    { "label": "Torsional Stress(Custom Stationary)" ,unittype:"stress"},
                    { "label": "Torsional Stress(Back Reaming)" ,unittype:"stress"},
                    { "label": "True Axial Load(Rotary)" ,unittype:"force"},
                    { "label": "True Axial Load(Sliding)",unittype:"force" },
                    { "label": "True Axial Load(Running In)" ,unittype:"force"},
                    { "label": "True Axial Load(Pulling Out)",unittype:"force" },
                    { "label": "True Axial Load(RoffB)" ,unittype:"force"},
                    { "label": "True Axial Load(Reaming)",unittype:"force" },
                    { "label": "True Axial Load(Pick Up)" ,unittype:"force"},
                    { "label": "True Axial Load(Slack Off)" ,unittype:"force"},
                    { "label": "True Axial Load(Underreaming)" ,unittype:"force"},
                    { "label": "True Axial Load(Cutting)" ,unittype:"force"},
                    { "label": "True Axial Load(Custom Up)" ,unittype:"force"},
                    { "label": "True Axial Load(Custom Down)" ,unittype:"force"},
                    { "label": "True Axial Load(Custom Stationary)" ,unittype:"force"},
                    { "label": "True Axial Load(Back Reaming)",unittype:"force" },
                    { "label": "Twist Angle(Rotary)" ,unittype:"angle"},
                    { "label": "Twist Angle(Sliding)" ,unittype:"angle"},
                    { "label": "Twist Angle(Running In)" ,unittype:"angle"},
                    { "label": "Twist Angle(Pulling Out)",unittype:"angle" },
                    { "label": "Twist Angle(RoffB)" ,unittype:"angle"},
                    { "label": "Twist Angle(Reaming)",unittype:"angle" },
                    { "label": "Twist Angle(Pick Up)" ,unittype:"angle"},
                    { "label": "Twist Angle(Slack Off)" ,unittype:"angle"},
                    { "label": "Twist Angle(Underreaming)",unittype:"angle" },
                    { "label": "Twist Angle(Cutting)" ,unittype:"angle"},
                    { "label": "Twist Angle(Custom Up)",unittype:"angle" },
                    { "label": "Twist Angle(Custom Down)" ,unittype:"angle"},
                    { "label": "Twist Angle(Custom Stationary)",unittype:"angle" },
                    { "label": "Twist Angle(Back Reaming)",unittype:"angle" },
                    { "label": "Von Mises Stress(Rotary)",unittype:"stress" },
                    { "label": "Von Mises Stress(Sliding)",unittype:"stress"  },
                    { "label": "Von Mises Stress(Running In)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Pulling Out)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(RoffB)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Reaming)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Pick Up)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Slack Off)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Underreaming)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Cutting)" ,unittype:"stress" },
                    { "label": "Von Mises Stress(Custom Up)",unittype:"stress"  },
                    { "label": "Von Mises Stress(Custom Down)",unittype:"stress"  },
                    { "label": "Von Mises Stress(Custom Stationary)",unittype:"stress"  },
                    { "label": "Von Mises Stress(Back Reaming)" ,unittype:"stress" },
                    { "label": "Yield Stress Threshold" ,unittype:"stress" }
                  ] 
            },
            {
                label:"Hydraulic Bit Optimization",
                submenu:[
                    { "label": "% System Pressure Loss @ Bit" },
                    { "label": "Bit Impact Force",unittype:"force"  },
                    { "label": "Bit Power" ,unittype:"power" },
                    { "label": "Bit Power Expended"  ,unittype:"power"},
                    { "label": "Min. Flow Rate",unittype:"flow" },
                    { "label": "Opt. Bit Pressure Drop",unittype:"pressure" },
                    { "label": "Opt. Flow Rate",unittype:"flow" },
                    { "label": "Rec.Nozzle Size",unittype:"nozzlesize"},
                    { "label": "Rec. TFA" ,unittype:"tfa"}
                  ]      
            },
            {
                label:"Hydraulic Displacment (Circulation)",
                submenu:[
                    { "label": "BH ECD" },
                    { "label": "BH P" },
                    { "label": "CS ECD" },
                    { "label": "CS P" },
                    { "label": "Flow In"  ,unittype:"flow"},
                    { "label": "Flow Out" ,unittype:"flow" },
                    { "label": "Free Fall Height" ,unittype:"length" },
                    { "label": "Pump Output" },
                    { "label": "Pump Speed" },
                    { "label": "SBP To Trap" },
                    { "label": "SPP",unittype:"pressure"}
                ]
            },
            {
                label:"Hydraulic Displacment (Pumping)",
                submenu:[
                  { "label": "BH ECD" },
                  { "label": "BH P" },
                  { "label": "CS ECD" },
                  { "label": "CS P" },
                  { "label": "Flow In"  ,unittype:"flow"},
                  { "label": "Flow Out" ,unittype:"flow" },
                  { "label": "Free Fall Height" ,unittype:"length" },
                  { "label": "Pump Output" },
                  { "label": "Pump Speed" },
                  { "label": "SBP To Trap" },
                  { "label": "SPP",unittype:"pressure"}
              ]
            },
            {
                label:"Hydraulic Parametric",
                submenu:[
                    { "label": "Bed Height"  ,unittype:"length"},
                    { "label": "Bit HHP"  ,unittype:"power"},
                    { "label": "Bit Press.",unittype:"pressure"  },
                    { "label": "ECD+Cuttings DOI",unittype:"density" },
                    { "label": "ECD+Cuttings Shoe",unittype:"density" },
                    { "label": "ECD+Cuttings TD" ,unittype:"density"},
                    { "label": "Pump HHP"  ,unittype:"power"},
                    { "label": "Cuttings"  ,unittype:"percentage"},
                    { "label": "SPP",unittype:"pressure" },
                    { "label": "WS Press." ,unittype:"pressure" }
                ]
            },
            {
                label:"Hydraulic Snapshot",
                submenu:[
                    { "label": "AnnularPressure (Case Hole)",unittype:"pressure" },
                    { "label": "AnnularPressure (Open Hole)",unittype:"pressure" },
                    { "label": "AnnularPressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "AnnularVelocity (Case Hole)",unittype:"velocity" },
                    { "label": "AnnularVelocity (Open Hole)",unittype:"velocity" },
                    { "label": "AnnularVelocity (Whole Well)",unittype:"velocity" },
                    { "label": "AnnulusApparentViscosity (Case Hole)" ,unittype:"viscosity"},
                    { "label": "AnnulusApparentViscosity (Open Hole)" ,unittype:"viscosity"},
                    { "label": "AnnulusApparentViscosity (Whole Well)" ,unittype:"viscosity"},
                    { "label": "AnnulusFrictionalPressure (Case Hole)",unittype:"pressure" },
                    { "label": "AnnulusFrictionalPressure (Open Hole)",unittype:"pressure" },
                    { "label": "AnnulusFrictionalPressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "AnnulusTemperature (Case Hole)",unittype:"temperature" },
                    { "label": "AnnulusTemperature (Open Hole)",unittype:"temperature"  },
                    { "label": "AnnulusTemperature (Whole Well)",unittype:"temperature"  },
                    { "label": "Azimuth (Case Hole)",unittype:"angle"  },
                    { "label": "Azimuth (Open Hole)",unittype:"angle"  },
                    { "label": "Azimuth (Whole Well)",unittype:"angle"  },
                    { "label": "Bed Height (Case Hole)" ,unittype:"length" },
                    { "label": "Bed Height (Open Hole)"  ,unittype:"length"},
                    { "label": "Bed Height (Whole Well)"  ,unittype:"length"},
                    { "label": "Burst (Case Hole)"  ,unittype:"angle"},
                    { "label": "Burst (Open Hole)" ,unittype:"angle"},
                    { "label": "Burst (Whole Well)",unittype:"angle" },
                    { "label": "Collapse (Case Hole)" },
                    { "label": "Collapse (Open Hole)" },
                    { "label": "Collapse (Whole Well)" },
                    { "label": "DiffPressure (Case Hole)",unittype:"pressure" },
                    { "label": "DiffPressure (Open Hole)",unittype:"pressure" },
                    { "label": "DiffPressure (Whole Well)",unittype:"pressure" },
                    { "label": "DrillStringFrictionalPressure (Case Hole)",unittype:"pressure" },
                    { "label": "DrillStringFrictionalPressure (Open Hole)" ,unittype:"pressure"},
                    { "label": "DrillStringFrictionalPressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "DrillStringPressure (Case Hole)" ,unittype:"pressure"},
                    { "label": "DrillStringPressure (Open Hole)" ,unittype:"pressure"},
                    { "label": "DrillStringPressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "Eccentricity (Case Hole)",unittype:"percentage" },
                    { "label": "Eccentricity (Open Hole)" ,unittype:"percentage"},
                    { "label": "Eccentricity (Whole Well)",unittype:"percentage" },
                    { "label": "EquivalentCirculatingDensity (Case Hole)",unittype:"density" },
                    { "label": "EquivalentCirculatingDensity (Open Hole)" ,unittype:"density" },
                    { "label": "EquivalentCirculatingDensity (Whole Well)",unittype:"density"  },
                    { "label": "EquivalentCirculatingDensityPlusCuttings (Case Hole)" },
                    { "label": "EquivalentCirculatingDensityPlusCuttings (Open Hole)" },
                    { "label": "EquivalentCirculatingDensityPlusCuttings (Whole Well)" },
                    { "label": "EquivalentStaticDensity (Case Hole)",unittype:"density"  },
                    { "label": "EquivalentStaticDensity (Open Hole)" ,unittype:"density" },
                    { "label": "EquivalentStaticDensity (Whole Well)" ,unittype:"density" },
                    { "label": "FormationTemperature (Case Hole)" ,unittype:"temperature" },
                    { "label": "FormationTemperature (Open Hole)" ,unittype:"temperature" },
                    { "label": "FormationTemperature (Whole Well)",unittype:"temperature"  },
                    { "label": "FracturePressure (Case Hole)",unittype:"pressure"  },
                    { "label": "FracturePressure (Open Hole)" ,unittype:"pressure"},
                    { "label": "FracturePressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "HoleCleaning (Case Hole)" },
                    { "label": "HoleCleaning (Open Hole)" },
                    { "label": "HoleCleaning (Whole Well)" },
                    { "label": "Inclination (Case Hole)" ,unittype:"angle"},
                    { "label": "Inclination (Open Hole)" ,unittype:"angle"},
                    { "label": "Inclination (Whole Well)" ,unittype:"angle"},
                    { "label": "LowerShearYieldPoint (Case Hole)" ,unittype:"yieldpoint"},
                    { "label": "LowerShearYieldPoint (Open Hole)" ,unittype:"yieldpoint"},
                    { "label": "LowerShearYieldPoint (Whole Well)" ,unittype:"yieldpoint"},
                    { "label": "PipeApparentViscosity (Case Hole)" ,unittype:"viscosity"},
                    { "label": "PipeApparentViscosity (Open Hole)" ,unittype:"viscosity"},
                    { "label": "PipeApparentViscosity (Whole Well)" ,unittype:"viscosity"},
                    { "label": "PipeTemperature (Case Hole)" ,unittype:"temperature"},
                    { "label": "PipeTemperature (Open Hole)" ,unittype:"temperature"},
                    { "label": "PipeTemperature (Whole Well)" ,unittype:"temperature"},
                    { "label": "PipeVelocity (Case Hole)" ,unittype:"velocity"},
                    { "label": "PipeVelocity (Open Hole)",unittype:"velocity" },
                    { "label": "PipeVelocity (Whole Well)",unittype:"velocity" },
                    { "label": "PlasticViscosity (Case Hole)",unittype:"viscosity" },
                    { "label": "PlasticViscosity (Open Hole)",unittype:"viscosity" },
                    { "label": "PlasticViscosity (Whole Well)" ,unittype:"viscosity"},
                    { "label": "PurePressure (Case Hole)" ,unittype:"pressure"},
                    { "label": "PurePressure (Open Hole)",unittype:"pressure"},
                    { "label": "PurePressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "Cuttings (Case Hole)" ,unittype:"percentage"},
                    { "label": "Cuttings (Open Hole)" ,unittype:"percentage"},
                    { "label": "Cuttings (Whole Well)" ,unittype:"percentage"},
                    { "label": "SlipVelocity (Case Hole)" ,unittype:"velocity"},
                    { "label": "SlipVelocity (Open Hole)" ,unittype:"velocity"},
                    { "label": "SlipVelocity (Whole Well)",unittype:"velocity" },
                    { "label": "CuttingsTranspotRatio (Case Hole)" },
                    { "label": "CuttingsTranspotRatio (Open Hole)" },
                    { "label": "CuttingsTranspotRatio (Whole Well)" },
                    { "label": "CuttingsVelocity (Case Hole)",unittype:"velocity" },
                    { "label": "CuttingsVelocity (Open Hole)" ,unittype:"velocity"},
                    { "label": "CuttingsVelocity (Whole Well)",unittype:"velocity" },
                    { "label": "TrueVerticalDepth (Case Hole)" ,unittype:"length"},
                    { "label": "TrueVerticalDepth (Open Hole)" ,unittype:"length"},
                    { "label": "TrueVerticalDepth (Whole Well)",unittype:"length" },
                    { "label": "ViscousFrictionCoefficient (Case Hole)" },
                    { "label": "ViscousFrictionCoefficient (Open Hole)" },
                    { "label": "ViscousFrictionCoefficient (Whole Well)" },
                    { "label": "WellBoreStabilityPressure (Case Hole)" ,unittype:"pressure"},
                    { "label": "WellBoreStabilityPressure (Open Hole)" ,unittype:"pressure"},
                    { "label": "WellBoreStabilityPressure (Whole Well)" ,unittype:"pressure"},
                    { "label": "YieldPoint (Case Hole)" ,unittype:"yieldpoint"},
                    { "label": "YieldPoint (Open Hole)" ,unittype:"yieldpoint"},
                    { "label": "YieldPoint (Whole Well)" ,unittype:"yieldpoint"}
                  ]
                  
            },
            {
                label:"Hydraulic Snapshot Summary",
                submenu:[
                    { "label": "Annulus Flow Regime Check" },
                    { "label": "Annulus Velocity Check" },
                    { "label": "Bit HSI Check" },
                    { "label": "Bit Impact Force" ,unittype:"force"},
                    { "label": "Bit Jet Velocity" ,unittype:"velocity"},
                    { "label": "Bit Pressure Drop" ,unittype:"pressure"},
                    { "label": "Pipe Flow Regime Check" },
                    { "label": "Pump Pressure" ,unittype:"pressure"},
                    { "label": "SPP" ,unittype:"pressure"}
                  ]
                  
            },
            {
                label:"Hydraulic Tripping(Surge)",
                submenu:[
                    { "label": "Accelaration (Case Hole)",unittype:"acceleration" },
                    { "label": "Accelaration (Open Hole)",unittype:"acceleration" },
                    { "label": "Accelaration (Whole Well)",unittype:"acceleration" },
                    { "label": "BottomHoleStaticGauge (Case Hole)", unittype:"density" },
                    { "label": "BottomHoleStaticGauge (Open Hole)", unittype:"density" },
                    { "label": "BottomHoleStaticGauge (Whole Well)",unittype:"density" },
                    { "label": "CasingShoeStaticGauge (Case Hole)",unittype:"density" },
                    { "label": "CasingShoeStaticGauge (Open Hole)" ,unittype:"density"},
                    { "label": "CasingShoeStaticGauge (Whole Well)" ,unittype:"density"},
                    { "label": "DynamicGauge (Case Hole)",unittype:"density" },
                    { "label": "DynamicGauge (Open Hole)" ,unittype:"density"},
                    { "label": "DynamicGauge (Whole Well)" ,unittype:"density"},
                    { "label": "FracturePressureGradient (Case Hole)",unittype:"density" },
                    { "label": "FracturePressureGradient (Open Hole)" ,unittype:"density"},
                    { "label": "FracturePressureGradient (Whole Well)" ,unittype:"density"},
                    { "label": "Inclination (Case Hole)",unitType:"angle" },
                    { "label": "Inclination (Open Hole)" ,unitType:"angle"},
                    { "label": "Inclination (Whole Well)",unitType:"angle" },
                    { "label": "LowerShearYeildPoint (Case Hole)" ,unitType:"yieldpoint"},
                    { "label": "LowerShearYeildPoint (Open Hole)" ,unitType:"yieldpoint"},
                    { "label": "LowerShearYeildPoint (Whole Well)" ,unitType:"yieldpoint"},
                    { "label": "PlasticViscosity (Case Hole)" ,unitType:"viscosity"},
                    { "label": "PlasticViscosity (Open Hole)" ,unitType:"viscosity"},
                    { "label": "PlasticViscosity (Whole Well)" ,unitType:"viscosity"},
                    { "label": "PorePressureGradient (Case Hole)" ,unitType:"density"},
                    { "label": "PorePressureGradient (Open Hole)" ,unitType:"density"},
                    { "label": "PorePressureGradient (Whole Well)" ,unitType:"density"},
                    { "label": "Velocity (Case Hole)" ,unitType:"velocity"},
                    { "label": "Velocity (Open Hole)",unitType:"velocity" },
                    { "label": "Velocity (Whole Well)" ,unitType:"velocity"},
                    { "label": "WellBoreStabilityGradient (Case Hole)" ,unittype:"density"},
                    { "label": "WellBoreStabilityGradient (Open Hole)" ,unittype:"density"},
                    { "label": "WellBoreStabilityGradient (Whole Well)",unittype:"density" },
                    { "label": "YeildPoint (Case Hole)" ,unitType:"yieldpoint" },
                    { "label": "YeildPoint (Open Hole)"  ,unitType:"yieldpoint"},
                    { "label": "YeildPoint (Whole Well)" ,unitType:"yieldpoint" }
                  ]
                  
                  
            },
            {
                label:"Hydraulic Tripping(Swab)",
                submenu:[
                  { "label": "Accelaration (Case Hole)",unittype:"acceleration" },
                  { "label": "Accelaration (Open Hole)",unittype:"acceleration" },
                  { "label": "Accelaration (Whole Well)",unittype:"acceleration" },
                  { "label": "BottomHoleStaticGauge (Case Hole)", unittype:"density" },
                  { "label": "BottomHoleStaticGauge (Open Hole)", unittype:"density" },
                  { "label": "BottomHoleStaticGauge (Whole Well)",unittype:"density" },
                  { "label": "CasingShoeStaticGauge (Case Hole)",unittype:"density" },
                  { "label": "CasingShoeStaticGauge (Open Hole)" ,unittype:"density"},
                  { "label": "CasingShoeStaticGauge (Whole Well)" ,unittype:"density"},
                  { "label": "DynamicGauge (Case Hole)",unittype:"density" },
                  { "label": "DynamicGauge (Open Hole)" ,unittype:"density"},
                  { "label": "DynamicGauge (Whole Well)" ,unittype:"density"},
                  { "label": "FracturePressureGradient (Case Hole)",unittype:"density" },
                  { "label": "FracturePressureGradient (Open Hole)" ,unittype:"density"},
                  { "label": "FracturePressureGradient (Whole Well)" ,unittype:"density"},
                  { "label": "Inclination (Case Hole)",unitType:"angle" },
                  { "label": "Inclination (Open Hole)" ,unitType:"angle"},
                  { "label": "Inclination (Whole Well)",unitType:"angle" },
                  { "label": "LowerShearYeildPoint (Case Hole)" ,unitType:"yieldpoint"},
                  { "label": "LowerShearYeildPoint (Open Hole)" ,unitType:"yieldpoint"},
                  { "label": "LowerShearYeildPoint (Whole Well)" ,unitType:"yieldpoint"},
                  { "label": "PlasticViscosity (Case Hole)" ,unitType:"viscosity"},
                  { "label": "PlasticViscosity (Open Hole)" ,unitType:"viscosity"},
                  { "label": "PlasticViscosity (Whole Well)" ,unitType:"viscosity"},
                  { "label": "PorePressureGradient (Case Hole)" ,unitType:"pressuregradient"},
                  { "label": "PorePressureGradient (Open Hole)" ,unitType:"pressuregradient"},
                  { "label": "PorePressureGradient (Whole Well)" ,unitType:"pressuregradient"},
                  { "label": "Velocity (Case Hole)" ,unitType:"velocity"},
                  { "label": "Velocity (Open Hole)",unitType:"velocity" },
                  { "label": "Velocity (Whole Well)" ,unitType:"velocity"},
                  { "label": "WellBoreStabilityGradient (Case Hole)",unittype:"density" },
                  { "label": "WellBoreStabilityGradient (Open Hole)" ,unittype:"density"},
                  { "label": "WellBoreStabilityGradient (Whole Well)",unittype:"density" },
                  { "label": "YeildPoint (Case Hole)" ,unitType:"yieldpoint" },
                  { "label": "YeildPoint (Open Hole)"  ,unitType:"yieldpoint"},
                  { "label": "YeildPoint (Whole Well)" ,unitType:"yieldpoint" }
                  ]
                  
            },
            
        ],
        
    },
    {
        label:"Numeric",
        submenu:[
            {
              "label": "Value",
            },
            {
              "label": "Pi (π)",
            },
            {
              "label": "e",
            }
          ]
          
    },
    {
        label:"Boolean",
        submenu:[
            {
              "label": "TRUE",
            },
            {
              "label": "FALSE",
            }
          ]
          
    },
    {
        label:"Enum",
        submenu:[
            {
                label:"Boolean",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                      "label": "Pass",
                    }
                  ]
                  
            },
            {
              "label": "BSR",
              submenu:[
                  {
                    "label": "Fail",
                  },
                  {
                    "label": "Consider",
                  },
                  {
                    "label": "Pass",
                  }
              ]
            },
            {
                "label": "Azimuth Error",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "Drill Stem Jars Placement Adequate",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                    "label": "Consider",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "Neutral Point Check",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "Hole/Bit Size Collar Size Ratio",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                    "label": "Consider",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "BHA Jar Placement Adequate",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                    "label": "Consider",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "JSA",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                    "label": "Consider",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "Stiffness ratio",
                submenu:[
                    {
                      "label": "Fail",
                    },
                    {
                    "label": "Consider",
                    },
                    {
                      "label": "Pass",
                    }
                ]
              },
              {
                "label": "SBP Sources",
                submenu:[
                    { "label": "Digital" },
                    { "label": "Analog 1" },
                    { "label": "Analog 2" },
                    { "label": "Analog 3" }
                  ]
                  
              },
              {
                "label": "SPP Sources",
                submenu:[
                    { "label": "External" },
                    { "label": "Digital" },
                    { "label": "Analog 1" },
                    { "label": "Analog 2" },
                    { "label": "Analog 3" }
                  ]                  
                  
              },
              {
                label:"Meter Types",
                submenu:[
                    { "label": "Orifice" },
                    { "label": "V Cone" },
                    { "label": "Wafer Cone" },
                    { "label": "Turbine" },
                    { "label": "Coriolis" }
                  ]
                  
              },
              {
                label:"Termination Conditions",
                submenu:[
                    { "label": "Time Based" },
                    { "label": "Volume Based" },
                    { "label": "Depth Based" },
                    { "label": "Pressure Based" }
                  ]  
              },
              {
                label:"Bit Types",
                submenu:[
                    { "label": "PDC Bit" },
                    { "label": "Roller Cone(TCI) Bit" },
                    { "label": "Mill Tooth Bit" },
                    { "label": "Hybrid Bit" },
                    { "label": "Bi-Center Bit" },
                    { "label": "Digger Bit" },
                    { "label": "Diamond Impregnated Bit" },
                    { "label": "Extended Gauge PDC Bit" },
                    { "label": "Extended Gauge Diamond Impregnated Bit" },
                    { "label": "Bit" }
                  ]
                  
              },
              {
                label:"Blow Out Preventers",
                submenu:[
                    { "label": "Surface BOP" },
                    { "label": "Subsea BOP" },
                    { "label": "None" }
                  ]
                  
              },
              {
                label:"Choke Models",
                submenu:[
                    { "label": "Expro SCB2 3\"" },
                    { "label": "Cortec CX3 3\"" },
                    { "label": "Cortec CX6 6\"" },
                    { "label": "None" },
                    { "label": "Cortec CX6 4\"" },
                    { "label": "Expro SCB4 3\"" },
                    { "label": "SRI SCMS 4\"" },
                    { "label": "Cortec CX4 4\"" }
                  ]
                             
              },
              {
                label:"Choke Modes",
                submenu:[
                    { "label": "Disabled" },
                    { "label": "Auto" },
                    { "label": "Manual" },
                    { "label": "Swap" }
                  ]
                  
              },
              {
                label:"Hydraulics Model Types",
                submenu:[
                    { "label": "Isothermal Model" },
                    { "label": "Non Isothermal Model" }
                  ]
                  
              },
              {
                label:"RCD Type",
                submenu:[
                    { "label": "Below Tensioner Ring" },
                    { "label": "Above Tensioner Ring" }
                  ]
                  
              },
              {
                label:"Reamer Types",
                submenu:[
                    { "label": "Mechanical" },
                    { "label": "RFID" },
                    { "label": "Regular" },
                    { "label": "Hydraulic" },
                    { "label": "Bicentric" }
                  ]
                  
              },
              {
                label:"Rig Sizes",
                submenu:[
                    {
                      "label": "Small rig (SP-40ft x 3.0in;hose - 45ft x 2.0in; Swivel - 4ft x 2.0in; Kelly - 40ft x 2.25in)"
                    },
                    {
                      "label": "Medium rig (8000 - 12000ft) (SP-40ft x 3.5in;hose - 55ft x 2.5in; Swivel - 5ft x 2.5in; Kelly - 40ft x 3.25in)"
                    },
                    {
                      "label": "Medium rig (12000 - 20000ft) (SP-45ft x 4.0in;hose - 55ft x 3.0in; Swivel - 5ft x 2.5in; Kelly - 40ft x 3.25in)"
                    },
                    {
                      "label": "Rig over 20,000 ft (SP - 45ft x 4.0in; hose-55ftx3.0in; SWIVL - 6ft x 3.0in; Kelly - 40ft x 4.0in)"
                    },
                    {
                      "label": "Rig over 20,000 ft (SP - 100ft x 5.0in; hose-85ftx3.5in; SWIVL - 22ft x 3.5in)"
                    },
                    { "label": "Unknown" },
                    { "label": "Custom" }
                  ]
                  
              },
              {
                label:"Rubber Types",
                submenu:[
                    { "label": "Natural" },
                    { "label": "Polyurethane" },
                    { "label": "HF Poly" }
                  ]
                  
              },
              {
                label:"Salt Types",
                submenu:[
                    { "label": "None" },
                    { "label": "NaCl" },
                    { "label": "CaCl2" },
                    { "label": "KCl" }
                  ]
                  
              },
              {
                label:"Choke Types",
                submenu:[
                    { "label": "Hydraulic Driven" },
                    { "label": "Electric Driven" }
                  ]
                  
              },
              {
                label:"MPD Tasks",
                submenu:[
                    { "label": "None" },
                    { "label": "SBP" },
                    { "label": "SPP" },
                    { "label": "F" },
                    { "label": "AP" },
                    { "label": "C" }
                  ]
                  
              },
              {
                label:"Countries",
                submenu:[
                    {"label": "Afghanistan"},
                    {"label": "Albania"},
                    {"label": "Algeria"},
                    {"label": "Andorra"},
                    {"label": "Angola"},
                    {"label": "Antigua and Barbuda"},
                    {"label": "Argentina"},
                    {"label": "Armenia"},
                    {"label": "Australia"},
                    {"label": "Austria"},
                    {"label": "Azerbaijan"},
                    {"label": "Bahamas, The"},
                    {"label": "Bahrain"},
                    {"label": "Bangladesh"},
                    {"label": "Barbados"},
                    {"label": "Belarus"},
                    {"label": "Belgium"},
                    {"label": "Belize"},
                    {"label": "Benin"},
                    {"label": "Bhutan"},
                    {"label": "Bolivia"},
                    {"label": "Bosnia and Herzegovina"},
                    {"label": "Botswana"},
                    {"label": "Brazil"},
                    {"label": "Brunei"},
                    {"label": "Bulgaria"},
                    {"label": "Burkina Faso"},
                    {"label": "Burundi"},
                    {"label": "Cambodia"},
                    {"label": "Cameroon"},
                    {"label": "Canada"},
                    {"label": "Cape Verde"},
                    {"label": "Central African Republic"},
                    {"label": "Chad"},
                    {"label": "Chile"},
                    {"label": "People's Republic of China"},
                    {"label": "Colombia"},
                    {"label": "Comoros"},
                    {"label": "Congo, (Congo – Kinshasa)"},
                    {"label": "Congo, (Congo – Brazzaville)"},
                    {"label": "Costa Rica"},
                    {"label": "Cote d'Ivoire (Ivory Coast)"},
                    {"label": "Croatia"},
                    {"label": "Cuba"},
                    {"label": "Cyprus"},
                    {"label": "Czech Republic"},
                    {"label": "Denmark"},
                    {"label": "Djibouti"},
                    {"label": "Dominica"},
                    {"label": "Dominican Republic"},
                    {"label": "Ecuador"},
                    {"label": "Egypt"},
                    {"label": "El Salvador"},
                    {"label": "Equatorial Guinea"},
                    {"label": "Eritrea"},
                    {"label": "Estonia"},
                    {"label": "Ethiopia"},
                    {"label": "Fiji"},
                    {"label": "Finland"},
                    {"label": "France"},
                    {"label": "Gabon"},
                    {"label": "Gambia"},
                    {"label": "Georgia"},
                    {"label": "Germany"},
                    {"label": "Ghana"},
                    {"label": "Greece"},
                    {"label": "Grenada"},
                    {"label": "Guatemala"},
                    {"label": "Guinea"},
                    {"label": "Guinea-Bissau"},
                    {"label": "Guyana"},
                    {"label": "Haiti"},
                    {"label": "Honduras"},
                    {"label": "Hungary"},
                    {"label": "Iceland"},
                    {"label": "India"},
                    {"label": "Indonesia"},
                    {"label": "Iran"},
                    {"label": "Iraq"},
                    {"label": "Ireland"},
                    {"label": "Israel"},
                    {"label": "Italy"},
                    {"label": "Jamaica"},
                    {"label": "Japan"},
                    {"label": "Jordan"},
                    {"label": "Kazakhstan"},
                    {"label": "Kenya"},
                    {"label": "Kiribati"},
                    {"label": "Korea, North"},
                    {"label": "Korea, South"},
                    {"label": "Kuwait"},
                    {"label": "Kyrgyzstan"},
                    {"label": "Laos"},
                    {"label": "Latvia"},
                    {"label": "Lebanon"},
                    {"label": "Lesotho"},
                    {"label": "Liberia"},
                    {"label": "Libya"},
                    {"label": "Liechtenstein"},
                    {"label": "Lithuania"},
                    {"label": "Luxembourg"},
                    {"label": "Macedonia"},
                    {"label": "Madagascar"},
                    {"label": "Malawi"},
                    {"label": "Malaysia"},
                    {"label": "Maldives"},
                    {"label": "Mali"},
                    {"label": "Malta"},
                    {"label": "Marshall Islands"},
                    {"label": "Mauritania"},
                    {"label": "Mauritius"},
                    {"label": "Mexico"},
                    {"label": "Micronesia"},
                    {"label": "Moldova"},
                    {'label': 'Monaco'},
                   {'label': 'Mongolia'},
                   {'label': 'Montenegro'},
                   {'label': 'Morocco'},
                   {'label': 'Mozambique'},
                   {'label': 'Myanmar (Burma)'},
                   {'label': 'Namibia'},
                   {'label': 'Nauru'},
                   {'label': 'Nepal'},
                   {'label': 'Netherlands'},
                   {'label': 'New Zealand'},
                   {'label': 'Nicaragua'},
                   {'label': 'Niger'},
                   {'label': 'Nigeria'},
                   {'label': 'Norway'},
                   {'label': 'Oman'},
                   {'label': 'Pakistan'},
                   {'label': 'Palau'},
                   {'label': 'Panama'},
                   {'label': 'Papua New Guinea'},
                   {'label': 'Paraguay'},
                   {'label': 'Peru'},
                   {'label': 'Philippines'},
                   {'label': 'Poland'},
                   {'label': 'Portugal'},
                   {'label': 'Qatar'},
                   {'label': 'Romania'},
                   {'label': 'Russia'},
                   {'label': 'Rwanda'},
                   {'label': 'Saint Kitts and Nevis'},
                   {'label': 'Saint Lucia'},
                   {'label': 'Saint Vincent and the Grenadines'},
                   {'label': 'Samoa'},
                   {'label': 'San Marino'},
                   {'label': 'Sao Tome and Principe'},
                   {'label': 'Saudi Arabia'},
                   {'label': 'Senegal'},
                   {'label': 'Serbia'},
                   {'label': 'Seychelles'},
                   {'label': 'Sierra Leone'},
                   {'label': 'Singapore'},
                   {'label': 'Slovakia'},
                   {'label': 'Slovenia'},
                   {'label': 'Solomon Islands'},
                   {'label': 'Somalia'},
                   {'label': 'South Africa'},
                   {'label': 'Spain'},
                   {'label': 'Sri Lanka'},
                   {'label': 'Sudan'},
                   {'label': 'Suriname'},
                   {'label': 'Swaziland'},
                   {'label': 'Sweden'},
                   {'label': 'Switzerland'},
                   {'label': 'Syria'},
                   {'label': 'Tajikistan'},
                   {'label': 'Tanzania'},
                   {'label': 'Thailand'},
                   {'label': 'Timor-Leste (East Timor)'},
                   {'label': 'Togo'},
                   {'label': 'Tonga'},
                   {'label': 'Trinidad and Tobago'},
                   {'label': 'Tunisia'},
                   {'label': 'Turkey'},
                   {'label': 'Turkmenistan'},
                   {'label': 'Tuvalu'},
                   {'label': 'Uganda'},
                   {'label': 'Ukraine'},
                   {'label': 'United Arab Emirates'},
                   {'label': 'United Kingdom'},
                   {'label': 'United States'},
                   {'label': 'Uruguay'},
                   {'label': 'Uzbekistan'},
                   {'label': 'Vanuatu'},
                   {'label': 'Vatican City'},
                   {'label': 'Venezuela'},
                   {'label': 'Vietnam'},
                   {'label': 'Yemen'},
                   {'label': 'Zambia'},
                   {'label': 'Zimbabwe'},
                   {'label': 'Abkhazia'},
                   {'label': 'China, Republic of (Taiwan)'},
                   {'label': 'Nagorno-Karabakh'},
                   {'label': 'Northern Cyprus'},
                   {'label': 'Pridnestrovie (Transnistria)'},
                   {'label': 'Somaliland'},
                   {'label': 'South Ossetia'},
                   {'label': 'Ashmore and Cartier Islands'},
                   {'label': 'Christmas Island'},
                   {'label': 'Cocos (Keeling), Islands'},
                   {'label': 'Coral Sea Islands'},
                   {'label': 'Heard Island and McDonald Islands'},
                   {'label': 'Norfolk Island'},
                   {'label': 'New Caledonia'},
                   {'label': 'French Polynesia'},
                   {'label': 'Mayotte'},
                   {'label': 'Saint Barthelemy'},
                   {'label': 'Saint Martin'},
                   {'label': 'Saint Pierre and Miquelon'},
                   {'label': 'Wallis and Futuna'},
                   {'label': 'French Southern and Antarctic Lands'},
                   {'label': 'Clipperton Island'},
                   {'label': 'Bouvet Island'},
                   {'label': 'Cook Islands'},
                   {'label': 'Niue'},
                   {'label': 'Tokelau'},
                   {'label': 'Guernsey'},
                   {'label': 'Isle of Man'},
                   {'label': 'Jersey'},
                   {'label': 'Anguilla'},
                   {'label': 'Bermuda'},
                   {'label': 'British Indian Ocean Territory'},
                   {'label': 'British Sovereign Base Areas'},
                   {'label': 'British Virgin Islands'},
                   {'label': 'Cayman Islands'},
                   {'label': 'Falkland Islands (Islas Malvinas),'},
                   {'label': 'Gibraltar'},
                   {'label': 'Montserrat'},
                   {'label': 'Pitcairn Islands'},
                   {'label': 'Saint Helena'},
                   {'label': 'South Georgia & South Sandwich Islands'},
                   {'label': 'Turks and Caicos Islands'},
                   {'label': 'Northern Mariana Islands'},
                   {'label': 'Puerto Rico'},
                   {'label': 'American Samoa'},
                   {'label': 'Baker Island'},
                   {'label': 'Guam'},
                   {'label': 'Howland Island'},
                   {'label': 'Jarvis Island'},
                   {'label': 'Johnston Atoll'},
                   {'label': 'Kingman Reef'},
                   {'label': 'Midway Islands'},
                   {'label': 'Navassa Island'},
                   {'label': 'Palmyra Atoll'},
                   {'label': 'U.S. Virgin Islands'},
                   {'label': 'Wake Island'},
                   {'label': 'Hong Kong'},
                   {'label': 'Macau'},
                   {'label': 'Faroe Islands'},
                   {'label': 'Greenland'},
                   {'label': 'French Guiana'},
                   {'label': 'Guadeloupe'},
                   {'label': 'Martinique'},
                   {'label': 'Reunion'},
                   {'label': 'Aland'},
                   {'label': 'Aruba'},
                   {'label': 'Netherlands Antilles'},
                   {'label': 'Svalbard'},
                   {'label': 'Ascension'},
                   {'label': 'Tristan da Cunha'},
                   {'label': 'Australian Antarctic Territory'},
                   {'label': 'Ross Dependency'},
                   {'label': 'Peter I Island'},
                   {'label': 'Queen Maud Land'},
                   {'label': 'British Antarctic Territory'}
                  ]
                  
              },
              {
                label:"Density Checks",
                submenu: [
                    {'label': 'No Operation'},
                    {'label': 'Erratic'},
                    {'label': 'Gas at Surface'},
                    {'label': 'Erratic and Gas at Surface'}
                ]

              },
              {
                label:"Detection States",
                submenu: [
                  {'label': 'No Operation'},
                  {'label': 'Detecting'},
                  {'label': 'Influx Detected'},
                  {'label': 'Loss Flux Detected'},
                  {'label': 'Influx Detect'},
                  {'label': 'Reaching Circulation Pressure'},
                  {'label': 'Circulation Influx Out'},
                  {'label': 'Influx Nearing Surface'},
                  {'label': 'Influx Out of Well'},
                  {'label': 'Kill Mud Weight Selection'},
                  {'label': 'Kill Mud Falling'},
                  {'label': 'Kill Mud Reaching Bit'},
                  {'label': 'Kill Mud Rising'},
                  {'label': 'Kill Mud Rising User Confirm'},
                  {'label': 'Emergency Shutdown'},
                  {'label': 'Kill Mud Nearing Surface'},
                  {'label': 'Classify Kick'},
                  {'label': 'Classify Depletion Type'},
                  // {'label': 'Depleting Type'},
                  {'label': 'Depleting Well'},
                  {'label': 'Loss Detected'},
                  {'label': 'Irrecoverable Loss'},
                  {'label': 'Loss Minimum SBP'},
                  {'label': 'Loss Minimum BHECD'},
                  {'label': 'Loss Minimum SPP'},
                  {'label': 'Dynamic FIT with Loss'},
                  {'label': 'Dynamic FIR at Target'},
                  {'label': 'Dynamic LOT with Loss'},
                  {'label': 'Dynamic PPT with Kick'}
              ]
              
              },
              {
                label:"Flow Meter Type",
                submenu:[
                  {'label': 'CMF400(4")'},
                  {'label': 'HC2(6")'},
                  {'label': 'HC3(8")'},
                  {'label': 'HC4(10")'},
                  {'label': 'None'}
              ]
              },
              {
                label:"High Limit Status",
                submenu:[
                  {'label': 'No Operation'},
                  {'label': 'Alarm'},
                  {'label': 'Holding'},
                  {'label': 'Emergency'},
                  {'label': 'SPP Alarm'},
                  {'label': 'BOP Alarm High'},
                  {'label': 'BOP Alarm Low'},
                  {'label': 'Riser Alarm High'},
                  {'label': 'Riser Alarm Low'}
              ]
              },
              {
                label:"Job Type",
                submenu:[
                  {'label': 'None'},
                  {'label': 'Monitoring & Early Detection'},
                  {'label': 'Constant Bottom Hole Pressure'},
                  {'label': 'Mud Cap'},
                  {'label': 'Dual Gradient'},
                  {'label': 'Cementing'},
                  {'label': 'Wellbore Strengthening'},
                  {'label': 'Casing Run'},
                  {'label': 'Coring'},
                  {'label': 'Logging'},
                  {'label': 'Surface Well Testing'},
                  {'label': 'Frac Flow Back'},
                  {'label': 'Well Cleanup'},
                  {'label': 'Production Testing'},
                  {'label': 'Multi-Well Production Monitoring'},
                  {'label': 'Extended Well Testing'},
                  {'label': 'NCD'}
              ]
              },
              {
                label:"Kick Classification",
                submenu: [
                  {'label': 'Unclassified'},
                  {'label': 'Sustained'},
                  {'label': 'Depleting'},
                  {'label': 'Depleted Before Limit'},
                  {'label': 'Depleted After Limit'}
              ]
              },
              {
                label:"Kick Positions",
                submenu:[
                  {'label': 'N/A'},
                  {'label': 'Bore'},
                  {'label': 'Riser'},
                  {'label': 'Surface Piping'}
              ]
              },
              {
                label:"Manifolds",
                submenu:[
                  {'label': 'Flow (Only)'},
                  {'label': 'Single Skid ICU'},
                  {'label': 'Split Skid (IU/CU)'},
                  {'label': 'None'},
                  {'label': 'Choke (Only)'},
                  {'label': 'Set Point Choke'},
                  {'label': 'Single Skid ICU (Up to 4 Hydraulic Chokes)'},
                  {'label': 'Single Skid ICU (Up to 4 Electric Chokes)'}
              ]
              },
              {
                label:"MPD Status",
                submenu:[
                  {'label': 'No Operation'},
                  {'label': 'Idle'},
                  {'label': 'Chasing Pressure'},
                  {'label': 'Chasing Strokes'},
                  {'label': 'Connection'}
              ]
              },
              {
                label:"Pump Sources",
                submenu:[
                  {'label': 'Stroke Counter'},
                  {'label': 'Half Stroke Counter'},
                  {'label': 'Spare 1'},
                  {'label': 'Spare 2'},
                  {'label': 'External'},
                  {'label': 'Inverse Half Stroke Counter'},
                  {'label': 'Spare 3'},
                  {'label': 'Spare 4'},
                  {'label': 'RPM'}
              ]
              },
              {
                label:"Pump States",
                submenu:  [
                  {'label': 'Disabled'},
                  {'label': 'Main'},
                  {'label': 'Aux'},
                  {'label': 'Boost'}
              ]
              },
              {
                label:"RCDs",
                submenu:[
                  {'label': 'IP-1000'},
                  {'label': '7000 / 7100'},
                  {'label': '7800'},
                  {'label': '7875 DS'},
                  {'label': '7875 BTR'},
                  {'label': 'BTR-S'},
                  {'label': 'Other'},
                  {'label': 'None'}
              ]
              
              },
              {
                label:"Regions",
                submenu:[
                  {'label': 'Asia Pacific'},
                  {'label': 'Canada'},
                  {'label': 'Europe West Africa'},
                  {'label': 'Latin America'},
                  {'label': 'Middle East North Africa'},
                  {'label': 'United States'}
              ]
              },
              {
                label:"Rig Type",
                submenu:[
                  {'label': 'Compliant Tower'},
                  {'label': 'Drill Ship'},
                  {'label': 'Fixed Platform'},
                  {'label': 'Floater'},
                  {'label': 'Jack-up'},
                  {'label': 'Land'}
              ]
              },
              {
                label:"Aux Pump Sources",
                submenu:[
                  {'label': 'Weatherford'},
                  {'label': 'Rig Pump'},
                  {'label': 'None'}
              ]
              },
              {
                label:"Trends",
                submenu:[
                  {'label': 'Increasing'},
                  {'label': 'Decreasing'},
                  {'label': 'Stable'},
                  {'label': 'Invalid'}
              ]
                
              },
             
             
          ]
          
    },
    {
      label:"Operation",
      submenu:[
        {
          "label":"No Data",
          submenu:[
            {label:"No Data"}
          ]
        },
        {
          "label":"Waiting On",
          submenu:[
            {'label': 'Waiting On Decision'},
            {'label': 'Waiting On Rig'},
            {'label': 'Waiting On Maintenance'},
            {'label': 'Waiting On Weather'},
            {'label': 'Waiting On Survey'},
            {'label': 'Waiting On Handle Tools'}
        ]
        },
        {
          "label":"Tripping",
          submenu:[
            {'label': 'Running In'},
            {'label': 'Pulling Out'},
            {'label': 'Dry Rotating Off Bottom'},
            {'label': 'Circulating Off Bottom'},
            {'label': 'Rotating & Circulating Off Bottom'},
            {'label': 'Reaming'},
            {'label': 'Back Reaming'},
            {'label': 'Washing'},
            {'label': 'Back Washing'},
            {'label': 'Dry Reaming'},
            {'label': 'Dry Back Reaming'},
            {'label': 'Off Bottom Inactive'},
            {'label': 'In Slips - Rotating'},
            {'label': 'In Slips - Circulating'},
            {'label': 'In Slips - Rotating & Circulating'},
            {'label': 'In Slips - Active'},
            {'label': 'In Slips - InActive'}
        ]
        },
        {
          "label":"Drilling",
          submenu:[
            {'label': 'Rotary Drilling'},
            {'label': 'Slide Drilling'},
            {'label': 'Dry Rotary Drilling'},
            {'label': 'Picking Up'},
            {'label': 'Letting Down'},
            {'label': 'Dry Rotating Off Bottom'},
            {'label': 'Circulating Off Bottom'},
            {'label': 'Circulating On Bottom'},
            {'label': 'Rotating & Circulation Off Bottom'},
            {'label': 'Reaming'},
            {'label': 'Back Reaming'},
            {'label': 'Washing'},
            {'label': 'Back Washing'},
            {'label': 'Dry Washing'},
            {'label': 'Dry Reaming'},
            {'label': 'Dry Back Reaming'},
            {'label': 'On Bottom Inactive'},
            {'label': 'Off Bottom Inactive'},
            {'label': 'In Slips - Inactive'},
            {'label': 'In Slips - Rotating'},
            {'label': 'In Slips - Circulating'},
            {'label': 'In Slips - Rotating & Circulating'},
            {'label': 'In Slips - Active'}
        ]
        },
        {
          "label":"At Surface",
          submenu:[
            {'label': 'Running In'},
            {'label': 'Pulling Out'},
            {'label': 'Reaming'},
            {'label': 'Back Reaming'},
            {'label': 'Washing'},
            {'label': 'Back Washing'},
            {'label': 'Dry Reaming'},
            {'label': 'Dry Back Reaming'},
            {'label': 'At Surface - Idle'},
            {'label': 'In Slips - Inactive'},
            {'label': 'In Slips - Rotating'},
            {'label': 'In Slips - Circulating'},
            {'label': 'In Slips - Rotating & Circulating'},
            {'label': 'In Slips - Active'},
            {'label': 'Dry Rotating Off Bottom'},
            {'label': 'Circulating Off Bottom'},
            {'label': 'Rotating & Circulating Off Bottom'},
            {'label': 'Off Bottom Inactive'}
        ]
        },
        
      ]
    },
    {
      "label":"Activity Code",
      submenu: [
        {'label': 'Undefined Status'},
        {'label': 'Rig Up & Tear Down'},
        {'label': 'Drilling'},
        {'label': 'Connection (Drilling)'},
        {'label': 'Reaming'},
        {'label': 'Hole Opening'},
        {'label': 'Coring'},
        {'label': 'Condition and/or Circulate Mud'},
        {'label': 'Tripping In'},
        {'label': 'Tripping Out'},
        {'label': 'Lubricate Rig'},
        {'label': 'Rig Repair'},
        {'label': 'Cut/Slip Drilling Line'},
        {'label': 'Deviation Survey'},
        {'label': 'Wireline Logs'},
        {'label': 'Run Casing'},
        {'label': 'Cementing'},
        {'label': 'Plug Back'},
        {'label': 'Squeeze Cementing'},
        {'label': 'Wait On Cement'},
        {'label': 'Drill Cement and/or Float Equipment'},
        {'label': 'Nipple Up/Nipple'},
        {'label': 'Test BOP'},
        {'label': 'Drill Steam Test'},
        {'label': 'Fishing'},
        {'label': 'Directional Work'},
        {'label': 'Well Control'},
        {'label': 'Stuck Pipe'},
        {'label': 'Wait on Weather'},
        {'label': 'Subsea'},
        {'label': 'Flow Check'},
        {'label': 'Pressure Integrity Test'},
        {'label': 'Lost Circulation'},
        {'label': 'Short Trip In'},
        {'label': 'Short Trip Out'}
    ]
    },
    {
      "label":"DateTime"
    },
    {
      "label":"Undefined"
    },

]