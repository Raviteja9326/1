export const witsOutErrorMessages = {
    Category:"Please select Category",
    Parameter:"Please select Parameter",
    WitsmlChannel:"Please select WITSMLChannel",
    WitsmlLogUId:"Please select WITSMLLog",
    WitsmlLogCurve:"Please select Log Curve",
  //  UnitType:"",
    //Unit:"",
   
  };