export const ToolStyles = {
    6:{  //Bit
        material:{
            color: 0xff0000, 
            wireframe: false,
            roughness: 0.2,  
            metalness: 0.1,
          },
          path:"assets/3d-objects/objects/PDCBit3_3.obj",
          cameraFactor:300,
          marginFromTop:100,
          scaleFactor:50,
          DimensionStartOffsety:20,
          DimensionEndOffsety:180,
          DimensionOffsetx:70,
          rotationX:3.65,
          
          operate:{
            material:{
                color: 0xff0000, 
                wireframe: false,
                roughness: 0.2,  
                metalness: 0.1,
              },
              path:"assets/3d-objects/objects/PDCBit3_3.obj",
              cameraFactor:300,
              marginFromTop:100,
              scaleFactor:50,
              DimensionStartOffsety:20,
              DimensionEndOffsety:180,
              DimensionOffsetx:70,
              rotationX:3.65,
              sketchOffset:{
                length:{
                  xOffset:65,yOffset:80
                },
                toolsize:{
                  xOffset:80,yOffset:10
                }
              }
          },
          diagramMaterial:{
            color:"0xBFC9CA"
          },
          sketchOffset:{
            length:{
              xOffset:65,yOffset:80
            },
            toolsize:{
              xOffset:80,yOffset:10
            }
          }
        
    },

    26:{  //Casing Pipe
      material:{
          color: 0x000000, 
          wireframe: false,
          roughness: 0.2,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/pipe.obj",
        cameraFactor:250,
        marginFromTop:110,
        scaleFactor:2.5,
        DimensionStartOffsety:10,
        DimensionEndOffsety:325,
        DimensionOffsetx:10,
        rotationX:3.18,
        operate:{
          material:{
              color: 0x000000, 
              wireframe: false,
              roughness: 0.9,  
              metalness: 0.1,
            },
            path:"assets/3d-objects/objects/pipe.obj",
            cameraFactor:280,
            marginFromTop:110,
            scaleFactor:2.5,
            DimensionStartOffsety:10,
            DimensionEndOffsety:325,
            DimensionOffsetx:10,
            rotationX:3.2,
            sketchOffset:{
              length:{
                xOffset:130,yOffset:100
              },
              toolsize:{
                xOffset:215,yOffset:10
              }
            }
        },
        diagramMaterial:{
          color:"0xBFC9CA",
        },
        sketchOffset:{
          length:{
            xOffset:65,yOffset:100
          },
          toolsize:{
            xOffset:160,yOffset:10
          }
        }
      
  },
  29:{ //Casing centralizer 
    material:{
        color: 0xff0000, 
        wireframe: false,
        roughness: 0.2,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/ring.obj",
      cameraFactor:300,
      marginFromTop:10,
      scaleFactor:1,
      DimensionStartOffsety:40,
      DimensionEndOffsety:50,
      DimensionOffsetx:70,
      rotationX:3.6,
      operate:{
        material:{
            color: 0xff0000, 
            wireframe: false,
            roughness: 0.2,  
            metalness: 0.1,
          },
          path:"assets/3d-objects/objects/ring.obj",
          cameraFactor:300,
          marginFromTop:10,
          scaleFactor:1,
          DimensionStartOffsety:40,
          DimensionEndOffsety:50,
          DimensionOffsetx:70,
          rotationX:3.65,
          sketchOffset:{
            length:{
              xOffset:100,yOffset:100
            },
            toolsize:{
              xOffset:200,yOffset:10
            }
          }
      },
      diagramMaterial:{
        color:"0xff0000"
      },
      sketchOffset:{
        length:{
          xOffset:65,yOffset:100
        },
        toolsize:{
          xOffset:160,yOffset:10
        }
      }
    
},
31:{  //DCV
  material:{
      color: 0xff0000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/ReceiverTop.obj",
    cameraFactor:300,
    marginFromTop:100,
    scaleFactor:20,
    DimensionStartOffsety:30,
    DimensionEndOffsety:270,
    DimensionOffsetx:70,
    rotationX:3.65,
    operate:{
      material:{
          color: 0xff0000, 
          wireframe: false,
          roughness: 0.2,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/ReceiverTop.obj",
        cameraFactor:400,
        marginFromTop:100,
        scaleFactor:20,
        DimensionStartOffsety:30,
        DimensionEndOffsety:270,
        DimensionOffsetx:70,
        rotationX:3.65,
        sketchOffset:{
          length:{
            xOffset:100,yOffset:100
          },
          toolsize:{
            xOffset:200,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0xff0000"
    },
    sketchOffset:{
      length:{
        xOffset:65,yOffset:100
      },
      toolsize:{
        xOffset:160,yOffset:10
      }
    }
  
},
35:{  //Fishing
  material:{
      color: 0x00ff00, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/ReceiverTop.obj",
    cameraFactor:300,
    marginFromTop:100,
    scaleFactor:20,
    DimensionStartOffsety:30,
    DimensionEndOffsety:270,
    DimensionOffsetx:70,
    rotationX:3.65,
    operate:{
      material:{
          color: 0x00ff00, 
          wireframe: false,
          roughness: 0.2,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/ReceiverTop.obj",
        cameraFactor:400,
        marginFromTop:100,
        scaleFactor:20,
        DimensionStartOffsety:30,
        DimensionEndOffsety:270,
        DimensionOffsetx:70,
        rotationX:3.65,
        sketchOffset:{
          length:{
            xOffset:150,yOffset:100
          },
          toolsize:{
            xOffset:235,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0xBFC9CA"
    },
    sketchOffset:{
      length:{
        xOffset:85,yOffset:100
      },
      toolsize:{
        xOffset:175,yOffset:10
      }
    }
  
},
1:{  //Drill pipe
  material:{
      color: 0x000000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/ReceiverTop.obj",
    cameraFactor:300,
    marginFromTop:100,
    scaleFactor:20,
    DimensionStartOffsety:30,
    DimensionEndOffsety:270,
    DimensionOffsetx:70,
    rotationX:3.65,
    operate:{
      material:{
          color: 0x000000, 
          wireframe: false,
          roughness: 0.2,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/ReceiverTop.obj",
        cameraFactor:400,
        marginFromTop:100,
        scaleFactor:20,
        DimensionStartOffsety:30,
        DimensionEndOffsety:270,
        DimensionOffsetx:70,
        rotationX:3.65,
        sketchOffset:{
          length:{
            xOffset:150,yOffset:100
          },
          toolsize:{
            xOffset:235,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0xBFC9CA"
    },
    sketchOffset:{
      length:{
        xOffset:85,yOffset:100
      },
      toolsize:{
        xOffset:175,yOffset:10
      }
    }
  
},
3:{  //Drill collar
  material:{
      color: 0x000000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/ReceiverTop.obj",
    cameraFactor:300,
    marginFromTop:100,
    scaleFactor:20,
    DimensionStartOffsety:30,
    DimensionEndOffsety:270,
    DimensionOffsetx:70,
    rotationX:3.65,
    operate:{
      material:{
          color: 0x000000, 
          wireframe: false,
          roughness: 0.2,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/ReceiverTop.obj",
        cameraFactor:400,
        marginFromTop:100,
        scaleFactor:20,
        DimensionStartOffsety:30,
        DimensionEndOffsety:270,
        DimensionOffsetx:70,
        rotationX:3.65,
        sketchOffset:{
          length:{
            xOffset:150,yOffset:100
          },
          toolsize:{
            xOffset:225,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0xBFC9CA"
    },
    sketchOffset:{
      length:{
        xOffset:85,yOffset:100
      },
      toolsize:{
        xOffset:160,yOffset:10
      }
    }
},
40:{  //float collar
  material:{
      color: 0x89CFF0, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/ReceiverTop.obj",
    cameraFactor:300,
    marginFromTop:100,
    scaleFactor:20,
    DimensionStartOffsety:30,
    DimensionEndOffsety:270,
    DimensionOffsetx:70,
    rotationX:3.65,
    operate:{
      material:{
          color: 0x89CFF0, 
          wireframe: false,
          roughness: 0.2,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/ReceiverTop.obj",
        cameraFactor:400,
        marginFromTop:100,
        scaleFactor:20,
        DimensionStartOffsety:30,
        DimensionEndOffsety:270,
        DimensionOffsetx:70,
        rotationX:3.65,
        sketchOffset:{
          length:{
            xOffset:65,yOffset:120
          },
          toolsize:{
            xOffset:150,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0x89CFF0"
    },
    sketchOffset:{
      length:{
        xOffset:65,yOffset:120
      },
      toolsize:{
        xOffset:150,yOffset:10
      }
    }
  
},
10:{  //Drill Motor
  material:{
      color: 0xff0000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/pipe.obj",
    cameraFactor:250,
    marginFromTop:110,
    scaleFactor:2.5,
    DimensionStartOffsety:10,
    DimensionEndOffsety:325,
    DimensionOffsetx:10,
    rotationX:3.18,
    operate:{
      material:{
          color: 0xff0000, 
          wireframe: false,
          roughness: 0.9,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/pipe.obj",
        cameraFactor:250,
        marginFromTop:110,
        scaleFactor:2.5,
        DimensionStartOffsety:10,
        DimensionEndOffsety:325,
        DimensionOffsetx:10,
        rotationX:3.2,
        sketchOffset:{
          length:{
            xOffset:130,yOffset:100
          },
          toolsize:{
            xOffset:215,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0xFF0000",
    },
    sketchOffset:{
      length:{
        xOffset:65,yOffset:100
      },
      toolsize:{
        xOffset:160,yOffset:10
      }
    }
  
},

34:{  //Float shoe
  material:{
      color: 0x89CFF0, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/floatpipe.obj",
    cameraFactor:250,
    marginFromTop:-30,
    scaleFactor:0.42,
    DimensionStartOffsety:0,
    DimensionEndOffsety:300,
    DimensionOffsetx:20,
    rotationX:3.18,
    operate:{
      material:{
          color: 0x89CFF0, 
          wireframe: false,
          roughness: 0.9,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/floatpipe.obj",
        cameraFactor:250,
        marginFromTop:-30,
        scaleFactor:0.42,
        DimensionStartOffsety:0,
        DimensionEndOffsety:300,
        DimensionOffsetx:20,
        rotationX:3.2,
        sketchOffset:{
          length:{
            xOffset:65,yOffset:120
          },
          toolsize:{
            xOffset:150,yOffset:10
          }}
    },
    diagramMaterial:{
      color:"0x89CFF0",
    },
    sketchOffset:{
      length:{
        xOffset:65,yOffset:120
      },
      toolsize:{
        xOffset:150,yOffset:10
      }}
  
},
25:{  //Guide Shoe
  material:{
      color: 0xff0000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/guideShoes.obj",
    cameraFactor:300,
    marginFromTop:50,
    scaleFactor:60,
    DimensionStartOffsety:0,
    DimensionEndOffsety:179,
    DimensionOffsetx:70,
    rotationX:3.5,
    operate:{
      material:{
        color: 0xff0000, 
        wireframe: false,
        roughness: 0.2,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/guideShoes.obj",
      cameraFactor:300,
      marginFromTop:50,
      scaleFactor:60,
      DimensionStartOffsety:0,
      DimensionEndOffsety:179,
      DimensionOffsetx:70,
      rotationX:3.5,
        sketchOffset:{
          length:{
            xOffset:65,yOffset:160
          },
          toolsize:{
            xOffset:150,yOffset:10
          }}
    },
    diagramMaterial:{
      color:"0xBFC9CA",
    },
    sketchOffset:{
      length:{
        xOffset:65,yOffset:140
      },
      toolsize:{
        xOffset:150,yOffset:10
      }}
  
},
4:{  //Jar
  material:{
      color: 0x89CFF0, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/pipe.obj",
    cameraFactor:250,
    marginFromTop:110,
    scaleFactor:2.5,
    DimensionStartOffsety:10,
    DimensionEndOffsety:325,
    DimensionOffsetx:10,
    rotationX:3.18,
    operate:{
      material:{
          color: 0x89CFF0, 
          wireframe: false,
          roughness: 0.9,  
          metalness: 0.1,
        },
        path:"assets/3d-objects/objects/pipe.obj",
        cameraFactor:250,
        marginFromTop:110,
        scaleFactor:2.5,
        DimensionStartOffsety:10,
        DimensionEndOffsety:325,
        DimensionOffsetx:10,
        rotationX:3.2,
        sketchOffset:{
          length:{
            xOffset:130,yOffset:100
          },
          toolsize:{
            xOffset:198,yOffset:10
          }
        }
    },
    diagramMaterial:{
      color:"0x89CFF0",
    },
    sketchOffset:{
      length:{
        xOffset:65,yOffset:100
      },
      toolsize:{
        xOffset:138,yOffset:10
      }
    }
  
},
2:{  //HWDP
  material:{
      color: 0x000000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/hwdp.obj",
    cameraFactor:300,
    marginFromTop:200,
    scaleFactor:0.23,
    DimensionStartOffsety:370,
    DimensionEndOffsety:5,
    DimensionOffsetx:30,
    rotationX:null,
    operate:{
      material:{
        color: 0x000000, 
        wireframe: false,
        roughness: 0.2,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/hwdp.obj",
      cameraFactor:300,
      marginFromTop:200,
      scaleFactor:0.23,
      DimensionStartOffsety:370,
      DimensionEndOffsety:5,
      DimensionOffsetx:30,
      rotationX:null,
        sketchOffset:{
          length:{
            xOffset:120,yOffset:120
          },
          toolsize:{
            xOffset:222,yOffset:10
          }}
    },
    diagramMaterial:{
      color:"0xBFC9CA",
    },
    sketchOffset:{
      length:{
        xOffset:90,yOffset:120
      },
      toolsize:{
        xOffset:160,yOffset:10
      }}
  
},
41:{  //POST
  material:{
    color: 0xff0000, 
    wireframe: false,
    roughness: 0.2,  
    metalness: 0.1,
  },
  path:"assets/3d-objects/objects/floatpipe.obj",
  cameraFactor:250,
  marginFromTop:-30,
  scaleFactor:0.42,
  DimensionStartOffsety:0,
  DimensionEndOffsety:300,
  DimensionOffsetx:20,
  rotationX:3.18,
  operate:{
    material:{
        color: 0xff0000, 
        wireframe: false,
        roughness: 0.9,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/floatpipe.obj",
      cameraFactor:250,
      marginFromTop:-30,
      scaleFactor:0.42,
      DimensionStartOffsety:0,
      DimensionEndOffsety:300,
      DimensionOffsetx:20,
      rotationX:3.2,
      sketchOffset:{
        length:{
          xOffset:140,yOffset:120
        },
        toolsize:{
          xOffset:220,yOffset:10
        }}
  },
  diagramMaterial:{
    color:"0xff0000"
  },
  sketchOffset:{
    length:{
      xOffset:90,yOffset:120
    },
    toolsize:{
      xOffset:168,yOffset:10
    }}
  
},
21:{  //RSS
  material:{
      color: 0x000000, 
      wireframe: false,
      roughness: 0.2,  
      metalness: 0.1,
    },
    path:"assets/3d-objects/objects/rss.obj",
    cameraFactor:300,
    marginFromTop:200,
    scaleFactor:0.23,
    DimensionStartOffsety:370,
    DimensionEndOffsety:5,
    DimensionOffsetx:30,
    rotationX:null,
    operate:{
      material:{
        color: 0x000000, 
        wireframe: false,
        roughness: 0.2,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/rss.obj",
      cameraFactor:300,
      marginFromTop:200,
      scaleFactor:0.23,
      DimensionStartOffsety:370,
      DimensionEndOffsety:5,
      DimensionOffsetx:30,
      rotationX:null,
        sketchOffset:{
          length:{
            xOffset:120,yOffset:120
          },
          toolsize:{
            xOffset:222,yOffset:10
          }}
    },
    diagramMaterial:{
      color:"0xBFC9CA",
    },
    sketchOffset:{
      length:{
        xOffset:90,yOffset:120
      },
      toolsize:{
        xOffset:160,yOffset:10
      }}
  
},
38:{  //Packer
  material:{
    color: 0x00ff00, 
    wireframe: false,
    roughness: 0.2,  
    metalness: 0.1,
  },
  path:"assets/3d-objects/objects/floatpipe.obj",
  cameraFactor:250,
  marginFromTop:-30,
  scaleFactor:0.42,
  DimensionStartOffsety:0,
  DimensionEndOffsety:300,
  DimensionOffsetx:20,
  rotationX:3.18,
  operate:{
    material:{
        color: 0x00ff00, 
        wireframe: false,
        roughness: 0.9,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/floatpipe.obj",
      cameraFactor:250,
      marginFromTop:-30,
      scaleFactor:0.42,
      DimensionStartOffsety:0,
      DimensionEndOffsety:300,
      DimensionOffsetx:20,
      rotationX:3.2,
      sketchOffset:{
        length:{
          xOffset:88,yOffset:120
        },
        toolsize:{
          xOffset:210,yOffset:10
        }}
  },
  diagramMaterial:{
    color:"0xBFC9CA"
  },
  sketchOffset:{
    length:{
      xOffset:78,yOffset:120
    },
    toolsize:{
      xOffset:168,yOffset:10
    }}
  
},

}