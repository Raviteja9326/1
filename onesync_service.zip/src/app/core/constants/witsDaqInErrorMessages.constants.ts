export const witsDaqInErrorMessages = {
    Category:"",
    TagId:"",
    Channel:"",
    Title:"Title is mandatory",
    Type:"",
    Unit:"",
  };