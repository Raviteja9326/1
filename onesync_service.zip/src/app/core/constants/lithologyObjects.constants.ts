export const lithologyStyles = {

        material:{
            color:  0x00FFFF, 
            wireframe: false,
            roughness: 0.2,  
            metalness: 0.1,
          },
          path:"assets/3d-objects/objects/ReceiverTop.obj",
          cameraFactor:300,
          marginFromTop:170,
          scaleFactor:20,
          DimensionStartOffsety:400,
          DimensionEndOffsety:270,
          DimensionOffsetx:100,
       //   LengthDimension:1,
          //ToolSizeDimension:0.813,
          dimensionText:'test',
        
          rotationX:3.06,
        
          
          operate:{
            material:{
                color: 0xff0000, 
                wireframe: false,
                roughness: 0.2,  
                metalness: 0.1,
              },
              path:"assets/3d-objects/objects/ReceiverTop.obj",
              cameraFactor:400,
              marginFromTop:200,
              scaleFactor:20,
              DimensionStartOffsety:100,
              DimensionEndOffsety:270,
              DimensionOffsetx:100,
              rotationX:3.65,
              sketchOffset:{
                length:{
                  xOffset:100,yOffset:290
                },
                toolsize:{
                  xOffset:200,yOffset:215
                }
              }
          },
          diagramMaterial:{
            color:0x00FFFF
          },
          sketchOffset:{
            length:{
              xOffset:65,yOffset:290
            },
            toolsize:{
              xOffset:80,yOffset:208
            }
          }
        
    }