export const CountrysData =
  [
    { id: 1, name: "Abkhazia", countryCode: "GE-AB", region: "EuropeWestAfrica" },
    { id: 2, name: "Afghanistan", countryCode: "AF", region: "AsiaPacific" },
    { id: 3, name: "Aland", countryCode: "AX", region: "EuropeWestAfrica" },
    { id: 4, name: "Albania", countryCode: "AL", region: "EuropeWestAfrica" },
    { id: 5, name: "Algeria", countryCode: "DZ", region: "MiddleEastNorthAfrica" },
    { id: 6, name: "American Samoa", countryCode: "AS", region: "AsiaPacific" },
    { id: 7, name: "Andorra", countryCode: "AD", region: "EuropeWestAfrica" },
    { id: 8, name: "Angola", countryCode: "AO", region: "MiddleEastNorthAfrica" },
    { id: 9, name: "Anguilla", countryCode: "AI", region: "LatinAmerica" },
    { id: 10, name: "Antigua and Barbuda", countryCode: "AG", region: "LatinAmerica" },
    { id: 11, name: "Argentina", countryCode: "AR", region: "LatinAmerica" },
    { id: 12, name: "Armenia", countryCode: "AM", region: "EuropeWestAfrica" },
    { id: 13, name: "Aruba", countryCode: "AW", region: "LatinAmerica" },
    { id: 14, name: "Ascension", countryCode: "AC", region: "EuropeWestAfrica" },
    { id: 15, name: "Ashmore and Cartier Islands", countryCode: "AU", region: "AsiaPacific" },
    { id: 16, name: "Australia", countryCode: "AU", region: "AsiaPacific" },
    { id: 17, name: "Austrian Antarctic Territory", countryCode: "AQ", region: "EuropeWestAfrica" },
    { id: 18, name: "Austria", countryCode: "AT", region: "EuropeWestAfrica" },
    { id: 19, name: "Azerbaijan", countryCode: "AZ", region: "EuropeWestAfrica" },
    { id: 20, name: "Bahamas, The", countryCode: "BS", region: "LatinAmerica" },
    { id: 21, name: "Bahrain", countryCode: "BH", region: "MiddleEastNorthAfrica" },
    { id: 22, name: "Baker Island", countryCode: "UM-86", region: "AsiaPacific" },
    { id: 23, name: "Bangladesh", countryCode: "BD", region: "AsiaPacific" },
    { id: 24, name: "Barbados", countryCode: "BB", region: "LatinAmerica" },
    { id: 25, name: "Belarus", countryCode: "BY", region: "EuropeWestAfrica" },
    { id: 26, name: "Belgium", countryCode: "BE", region: "EuropeWestAfrica" },
    { id: 27, name: "Belize", countryCode: "BZ", region: "LatinAmerica" },
    { id: 28, name: "Benin", countryCode: "BJ", region: "MiddleEastNorthAfrica" },
    { id: 29, name: "Bermuda", countryCode: "BM", region: "LatinAmerica" },
    { id: 30, name: "Bhutan", countryCode: "BT", region: "AsiaPacific" },
    { id: 31, name: "Bolivia", countryCode: "BO", region: "LatinAmerica" },
    { id: 32, name: "Bosnia and Herzegovina", countryCode: "BA", region: "EuropeWestAfrica" },
    { id: 33, name: "Botswana", countryCode: "BW", region: "MiddleEastNorthAfrica" },
    { id: 34, name: "Bouvet Island", countryCode: "BV", region: "EuropeWestAfrica" },
    { id: 35, name: "Brazil", countryCode: "BR", region: "LatinAmerica" },
    { id: 36, name: "British Antarctic Territory", countryCode: "AQ", region: "EuropeWestAfrica" },
    { id: 37, name: "British Indian Ocean Territory", countryCode: "IO", region: "AsiaPacific" },
    { id: 38, name: "British Sovereign Base Areas", countryCode: "GB", region: "EuropeWestAfrica" },
    { id: 39, name: "British Virgin Islands", countryCode: "VG", region: "LatinAmerica" },
    { id: 40, name: "Brunei", countryCode: "BN", region: "AsiaPacific" },
    { id: 41, name: "Bulgaria", countryCode: "BG", region: "EuropeWestAfrica" },
    { id: 42, name: "Burkina Faso", countryCode: "BF", region: "MiddleEastNorthAfrica" },
    { id: 43, name: "Burundi", countryCode: "BI", region: "MiddleEastNorthAfrica" },
    { id: 44, name: "Cambodia", countryCode: "KH", region: "AsiaPacific" },
    { id: 45, name: "Cameroon", countryCode: "CM", region: "MiddleEastNorthAfrica" },
    { id: 46, name: "Canada", countryCode: "CA", region: "Canada" },
    { id: 47, name: "Cape Verde", countryCode: "CV", region: "MiddleEastNorthAfrica" },
    { id: 48, name: "Cayman Islands", countryCode: "KY", region: "LatinAmerica" },
    { id: 49, name: "Central African Republic", countryCode: "CF", region: "MiddleEastNorthAfrica" },
    { id: 50, name: "Chad", countryCode: "TD", region: "MiddleEastNorthAfrica" },
    { id: 51, name: "Chile", countryCode: "CL", region: "LatinAmerica" },
    { id: 52, name: "China (Republic of Taiwan)", countryCode: "TW", region: "AsiaPacific" },
    { id: 53, name: "Christmas Island", countryCode: "CX", region: "AsiaPacific" },
    { id: 54, name: "Clipperton Island", countryCode: "FR", region: "LatinAmerica" },
    { id: 55, name: "Cocos (Keeling) Islands", countryCode: "CC", region: "AsiaPacific" },
    { id: 56, name: "Colombia", countryCode: "CO", region: "LatinAmerica" },
    { id: 57, name: "Comoros", countryCode: "KM", region: "MiddleEastNorthAfrica" },
    { id: 58, name: "Congo (Congo-Brazzaville)", countryCode: "CG", region: "MiddleEastNorthAfrica" },
    { id: 59, name: "Congo (Congo-Kinshasa)", countryCode: "CD", region: "MiddleEastNorthAfrica" },
    { id: 60, name: "Cook Islands", countryCode: "CK", region: "AsiaPacific" },
    { id: 61, name: "Coral Sea Islands", countryCode: "AU", region: "AsiaPacific" },
    { id: 62, name: "Costa Rica", countryCode: "CR", region: "LatinAmerica" },
    { id: 63, name: "Cote d'Ivoire (Ivory Coast)", countryCode: "CI", region: "MiddleEastNorthAfrica" },
    { id: 64, name: "Croatia", countryCode: "HR", region: "EuropeWestAfrica" },
    { id: 65, name: "Cuba", countryCode: "CU", region: "LatinAmerica" },
    { id: 66, name: "Cyprus", countryCode: "CY", region: "EuropeWestAfrica" },
    { id: 67, name: "Czech Republic", countryCode: "CZ", region: "EuropeWestAfrica" },
    { id: 68, name: "Denmark", countryCode: "DK", region: "EuropeWestAfrica" },
    { id: 69, name: "Djibouti", countryCode: "DJ", region: "MiddleEastNorthAfrica" },
    { id: 70, name: "Dominica", countryCode: "DM", region: "LatinAmerica" },
    { id: 71, name: "Dominican Republic", countryCode: "DO", region: "LatinAmerica" },
    { id: 72, name: "Ecuador", countryCode: "EC", region: "LatinAmerica" },
    { id: 73, name: "Egypt", countryCode: "EG", region: "MiddleEastNorthAfrica" },
    { id: 74, name: "El Salvador", countryCode: "SV", region: "LatinAmerica" },
    { id: 75, name: "Equatorial Guinea", countryCode: "GQ", region: "MiddleEastNorthAfrica" },
    { id: 76, name: "Eritrea", countryCode: "ER", region: "MiddleEastNorthAfrica" },
    { id: 77, name: "Estonia", countryCode: "EE", region: "EuropeWestAfrica" },
    { id: 78, name: "Ethiopia", countryCode: "ET", region: "MiddleEastNorthAfrica" },
    { id: 79, name: "Falkland Islands (Islas Malvinas)", countryCode: "FK", region: "LatinAmerica" },
    { id: 80, name: "Faroe Islands", countryCode: "FO", region: "EuropeWestAfrica" },
    { id: 81, name: "Fiji", countryCode: "FJ", region: "AsiaPacific" },
    { id: 82, name: "Finland", countryCode: "FI", region: "EuropeWestAfrica" },
    { id: 83, name: "France", countryCode: "FR", region: "EuropeWestAfrica" },
    { id: 84, name: "French Guiana", countryCode: "GF", region: "LatinAmerica" },
    { id: 85, name: "French Polynesia", countryCode: "PF", region: "AsiaPacific" },
    { id: 86, name: "French Southern and Antarctic Lands", countryCode: "TF", region: "AsiaPacific" },
    { id: 87, name: "Gabon", countryCode: "GA", region: "MiddleEastNorthAfrica" },
    { id: 88, name: "Gambia", countryCode: "GM", region: "MiddleEastNorthAfrica" },
    { id: 89, name: "Georgia", countryCode: "GE", region: "EuropeWestAfrica" },
    { id: 90, name: "Germany", countryCode: "DE", region: "EuropeWestAfrica" },
    { id: 91, name: "Ghana", countryCode: "GH", region: "MiddleEastNorthAfrica" },
    { id: 92, name: "Gibraltar", countryCode: "GI", region: "EuropeWestAfrica" },
    { id: 93, name: "Greece", countryCode: "GR", region: "EuropeWestAfrica" },
    { id: 94, name: "Greenland", countryCode: "GL", region: "EuropeWestAfrica" },
    { id: 95, name: "Grenada", countryCode: "GD", region: "LatinAmerica" },
    { id: 96, name: "Guadeloupe", countryCode: "GP", region: "LatinAmerica" },
    { id: 97, name: "Guam", countryCode: "GU", region: "AsiaPacific" },
    { id: 98, name: "Guatemala", countryCode: "GT", region: "LatinAmerica" },
    { id: 99, name: "Guernsey", countryCode: "GG", region: "EuropeWestAfrica" },
    { id: 100, name: "Guinea", countryCode: "GN", region: "MiddleEastNorthAfrica" },
    { id: 101, name: "Guinea-Bissau", countryCode: "GW", region: "MiddleEastNorthAfrica" },
    { id: 102, name: "Guyana", countryCode: "GY", region: "LatinAmerica" },
    { id: 103, name: "Haiti", countryCode: "HT", region: "LatinAmerica" },
    { id: 104, name: "Heard Island and McDonald Islands", countryCode: "HM", region: "AsiaPacific" },
    { id: 105, name: "Honduras", countryCode: "HN", region: "LatinAmerica" },
    { id: 106, name: "Hong Kong", countryCode: "HK", region: "AsiaPacific" },
    { id: 107, name: "Howland Island", countryCode: "UM", region: "UnitedStates" },
    { id: 108, name: "Hungary", countryCode: "HU", region: "EuropeWestAfrica" },
    { id: 109, name: "Iceland", countryCode: "IS", region: "EuropeWestAfrica" },
    { id: 110, name: "India", countryCode: "IN", region: "AsiaPacific" },
    { id: 111, name: "Indonesia", countryCode: "ID", region: "AsiaPacific" },
    { id: 112, name: "Iran", countryCode: "IR", region: "MiddleEastNorthAfrica" },
    { id: 113, name: "Iraq", countryCode: "IQ", region: "MiddleEastNorthAfrica" },
    { id: 114, name: "Ireland", countryCode: "IE", region: "EuropeWestAfrica" },
    { id: 115, name: "Isle of Man", countryCode: "IM", region: "EuropeWestAfrica" },
    { id: 116, name: "Israel", countryCode: "IL", region: "MiddleEastNorthAfrica" },
    { id: 117, name: "Italy", countryCode: "IT", region: "EuropeWestAfrica" },
    { id: 118, name: "Jamaica", countryCode: "JM", region: "LatinAmerica" },
    { id: 119, name: "Japan", countryCode: "JP", region: "AsiaPacific" },
    { id: 120, name: "Jarvis Island", countryCode: "UM", region: "UnitedStates" },
    { id: 121, name: "Jersey", countryCode: "JE", region: "EuropeWestAfrica" },
    { id: 122, name: "Johnston Atoll", countryCode: "UM", region: "UnitedStates" },
    { id: 123, name: "Jordan", countryCode: "JO", region: "MiddleEastNorthAfrica" },
    { id: 124, name: "Kazakhstan", countryCode: "KZ", region: "EuropeWestAfrica" },
    { id: 125, name: "Kenya", countryCode: "KE", region: "MiddleEastNorthAfrica" },
    { id: 126, name: "Kingman Reef", countryCode: "UM", region: "UnitedStates" },
    { id: 127, name: "Kiribati", countryCode: "KI", region: "AsiaPacific" },
    { id: 128, name: "Korea, North", countryCode: "KP", region: "AsiaPacific" },
    { id: 129, name: "Korea, South", countryCode: "KR", region: "AsiaPacific" },
    { id: 130, name: "Kuwait", countryCode: "KW", region: "MiddleEastNorthAfrica" },
    { id: 131, name: "Kyrgyzstan", countryCode: "KG", region: "EuropeWestAfrica" },
    { id: 132, name: "Laos", countryCode: "LA", region: "AsiaPacific" },
    { id: 133, name: "Latvia", countryCode: "LV", region: "EuropeWestAfrica" },
    { id: 134, name: "Lebanon", countryCode: "LB", region: "MiddleEastNorthAfrica" },
    { id: 135, name: "Lesotho", countryCode: "LS", region: "MiddleEastNorthAfrica" },
    { id: 136, name: "Liberia", countryCode: "LR", region: "MiddleEastNorthAfrica" },
    { id: 137, name: "Libya", countryCode: "LY", region: "MiddleEastNorthAfrica" },
    { id: 138, name: "Liechtenstein", countryCode: "LI", region: "EuropeWestAfrica" },
    { id: 139, name: "Lithuania", countryCode: "LT", region: "EuropeWestAfrica" },
    { id: 140, name: "Luxembourg", countryCode: "LU", region: "EuropeWestAfrica" },
    { id: 141, name: "Macau", countryCode: "MO", region: "AsiaPacific" },
    { id: 142, name: "Macedonia", countryCode: "MK", region: "EuropeWestAfrica" },
    { id: 143, name: "Madagascar", countryCode: "MG", region: "MiddleEastNorthAfrica" },
    { id: 144, name: "Malawi", countryCode: "MW", region: "MiddleEastNorthAfrica" },
    { id: 145, name: "Malaysia", countryCode: "MY", region: "AsiaPacific" },
    { id: 146, name: "Maldives", countryCode: "MV", region: "AsiaPacific" },
    { id: 147, name: "Mali", countryCode: "ML", region: "MiddleEastNorthAfrica" },
    { id: 148, name: "Malta", countryCode: "MT", region: "EuropeWestAfrica" },
    { id: 149, name: "Marshall Islands", countryCode: "MH", region: "AsiaPacific" },
    { id: 150, name: "Martinique", countryCode: "MQ", region: "LatinAmerica" },
    { id: 151, name: "Mauritania", countryCode: "MR", region: "MiddleEastNorthAfrica" },
    { id: 152, name: "Mauritius", countryCode: "MU", region: "MiddleEastNorthAfrica" },
    { id: 153, name: "Mayotte", countryCode: "YT", region: "MiddleEastNorthAfrica" },
    { id: 154, name: "Mexico", countryCode: "MX", region: "LatinAmerica" },
    { id: 155, name: "Micronesia", countryCode: "FM", region: "AsiaPacific" },
    { id: 156, name: "Midway Islands", countryCode: "UM", region: "UnitedStates" },
    { id: 157, name: "Moldova", countryCode: "MD", region: "EuropeWestAfrica" },
    { id: 158, name: "Monaco", countryCode: "MC", region: "EuropeWestAfrica" },
    { id: 159, name: "Mongolia", countryCode: "MN", region: "AsiaPacific" },
    { id: 160, name: "Montenegro", countryCode: "ME", region: "EuropeWestAfrica" },
    { id: 161, name: "Montserrat", countryCode: "MS", region: "LatinAmerica" },
    { id: 162, name: "Morocco", countryCode: "MA", region: "MiddleEastNorthAfrica" },
    { id: 163, name: "Mozambique", countryCode: "MZ", region: "MiddleEastNorthAfrica" },
    { id: 164, name: "Myanmar (Burma)", countryCode: "MM", region: "AsiaPacific" },
    { id: 165, name: "Nagorno-Karabakh", countryCode: "AZ", region: "EuropeWestAfrica" },
    { id: 166, name: "Namibia", countryCode: "NA", region: "MiddleEastNorthAfrica" },
    { id: 167, name: "Nauru", countryCode: "NR", region: "AsiaPacific" },
    { id: 168, name: "Navassa Island", countryCode: "UM", region: "UnitedStates" },
    { id: 169, name: "Nepal", countryCode: "NP", region: "AsiaPacific" },
    { id: 170, name: "Netherlands", countryCode: "NL", region: "EuropeWestAfrica" },
    { id: 171, name: "Netherlands Antilles", countryCode: "AN", region: "LatinAmerica" },
    { id: 172, name: "New Caledonia", countryCode: "NC", region: "AsiaPacific" },
    { id: 173, name: "New Zealand", countryCode: "NZ", region: "AsiaPacific" },
    { id: 174, name: "Nicaragua", countryCode: "NI", region: "LatinAmerica" },
    { id: 175, name: "Niger", countryCode: "NE", region: "MiddleEastNorthAfrica" },
    { id: 176, name: "Nigeria", countryCode: "NG", region: "MiddleEastNorthAfrica" },
    { id: 177, name: "Niue", countryCode: "NU", region: "AsiaPacific" },
    { id: 178, name: "Norfolk Island", countryCode: "NF", region: "AsiaPacific" },
    { id: 179, name: "Northern Cyprus", countryCode: "CY", region: "EuropeWestAfrica" },
    { id: 180, name: "Northern Mariana Islands", countryCode: "MP", region: "AsiaPacific" },
    { id: 181, name: "Norway", countryCode: "NO", region: "EuropeWestAfrica" },
    { id: 182, name: "Oman", countryCode: "OM", region: "MiddleEastNorthAfrica" },
    { id: 183, name: "Pakistan", countryCode: "PK", region: "AsiaPacific" },
    { id: 184, name: "Palau", countryCode: "PW", region: "AsiaPacific" },
    { id: 185, name: "Palmyra Atoll", countryCode: "UM", region: "UnitedStates" },
    { id: 186, name: "Panama", countryCode: "PA", region: "LatinAmerica" },
    { id: 187, name: "Papua New Guinea", countryCode: "PG", region: "AsiaPacific" },
    { id: 188, name: "Paraguay", countryCode: "PY", region: "LatinAmerica" },
    { id: 189, name: "People's Republic of China", countryCode: "CN", region: "AsiaPacific" },
    { id: 190, name: "Peru", countryCode: "PE", region: "LatinAmerica" },
    { id: 191, name: "Peter I Island", countryCode: "NO", region: "EuropeWestAfrica" },
    { id: 192, name: "Philippines", countryCode: "PH", region: "AsiaPacific" },
    { id: 193, name: "Pitcairn Islands", countryCode: "PN", region: "AsiaPacific" },
    { id: 194, name: "Poland", countryCode: "PL", region: "EuropeWestAfrica" },
    { id: 195, name: "Portugal", countryCode: "PT", region: "EuropeWestAfrica" },
    { id: 196, name: "Pridnestrovie (Transnistria)", countryCode: "MD", region: "EuropeWestAfrica" },
    { id: 197, name: "Puerto Rico", countryCode: "PR", region: "LatinAmerica" },
    { id: 198, name: "Qatar", countryCode: "QA", region: "MiddleEastNorthAfrica" },
    { id: 199, name: "Queen Maud Land", countryCode: "AQ", region: "EuropeWestAfrica" },
    { id: 200, name: "Reunion", countryCode: "RE", region: "MiddleEastNorthAfrica" },
    { id: 201, name: "Romania", countryCode: "RO", region: "EuropeWestAfrica" },
    { id: 202, name: "Ross Dependency", countryCode: "AQ", region: "EuropeWestAfrica" },
    { id: 203, name: "Russia", countryCode: "RU", region: "EuropeWestAfrica" },
    { id: 204, name: "Rwanda", countryCode: "RW", region: "MiddleEastNorthAfrica" },
    { id: 205, name: "Saint Barthelemy", countryCode: "BL", region: "LatinAmerica" },
    { id: 206, name: "Saint Helena", countryCode: "SH", region: "MiddleEastNorthAfrica" },
    { id: 207, name: "Saint Kitts and Nevis", countryCode: "KN", region: "LatinAmerica" },
    { id: 208, name: "Saint Lucia", countryCode: "LC", region: "LatinAmerica" },
    { id: 209, name: "Saint Martin", countryCode: "MF", region: "LatinAmerica" },
    { id: 210, name: "Saint Pierre and Miquelon", countryCode: "PM", region: "NorthAmerica" },
    { id: 211, name: "Saint Vincent and the Grenadines", countryCode: "VC", region: "LatinAmerica" },
    { id: 212, name: "Samoa", countryCode: "WS", region: "AsiaPacific" },
    { id: 213, name: "San Marino", countryCode: "SM", region: "EuropeWestAfrica" },
    { id: 214, name: "Sao Tome and Principe", countryCode: "ST", region: "MiddleEastNorthAfrica" },
    { id: 215, name: "Saudi Arabia", countryCode: "SA", region: "MiddleEastNorthAfrica" },
    { id: 216, name: "Senegal", countryCode: "SN", region: "MiddleEastNorthAfrica" },
    { id: 217, name: "Serbia", countryCode: "RS", region: "EuropeWestAfrica" },
    { id: 218, name: "Seychelles", countryCode: "SC", region: "MiddleEastNorthAfrica" },
    { id: 219, name: "Sierra Leone", countryCode: "SL", region: "MiddleEastNorthAfrica" },
    { id: 220, name: "Singapore", countryCode: "SG", region: "AsiaPacific" },
    { id: 221, name: "Slovakia", countryCode: "SK", region: "EuropeWestAfrica" },
    { id: 222, name: "Slovenia", countryCode: "SI", region: "EuropeWestAfrica" },
    { id: 223, name: "Solomon Islands", countryCode: "SB", region: "AsiaPacific" },
    { id: 224, name: "Somalia", countryCode: "SO", region: "MiddleEastNorthAfrica" },
    { id: 225, name: "Somaliland", countryCode: "SO", region: "MiddleEastNorthAfrica" },
    { id: 226, name: "South Africa", countryCode: "ZA", region: "MiddleEastNorthAfrica" },
    { id: 227, name: "South Georgia & South Sandwich Islands", countryCode: "GS", region: "LatinAmerica" },
    { id: 228, name: "South Ossetia", countryCode: "GE", region: "EuropeWestAfrica" },
    { id: 229, name: "Spain", countryCode: "ES", region: "EuropeWestAfrica" },
    { id: 230, name: "Sri Lanka", countryCode: "LK", region: "AsiaPacific" },
    { id: 231, name: "Sudan", countryCode: "SD", region: "MiddleEastNorthAfrica" },
    { id: 232, name: "Suriname", countryCode: "SR", region: "LatinAmerica" },
    { id: 233, name: "Svalbard", countryCode: "SJ", region: "EuropeWestAfrica" },
    { id: 234, name: "Swaziland", countryCode: "SZ", region: "MiddleEastNorthAfrica" },
    { id: 235, name: "Sweden", countryCode: "SE", region: "EuropeWestAfrica" },
    { id: 236, name: "Switzerland", countryCode: "CH", region: "EuropeWestAfrica" },
    { id: 237, name: "Syria", countryCode: "SY", region: "MiddleEastNorthAfrica" },
    { id: 238, name: "Tajikistan", countryCode: "TJ", region: "EuropeWestAfrica" },
    { id: 239, name: "Tanzania", countryCode: "TZ", region: "MiddleEastNorthAfrica" },
    { id: 240, name: "Thailand", countryCode: "TH", region: "AsiaPacific" },
    { id: 241, name: "Timor-Leste (East Timor)", countryCode: "TL", region: "AsiaPacific" },
    { id: 242, name: "Togo", countryCode: "TG", region: "MiddleEastNorthAfrica" },
    { id: 243, name: "Tokelau", countryCode: "TK", region: "AsiaPacific" },
    { id: 244, name: "Tonga", countryCode: "TO", region: "AsiaPacific" },
    { id: 245, name: "Trinidad and Tobago", countryCode: "TT", region: "LatinAmerica" },
    { id: 246, name: "Tristan da Cunha", countryCode: "TDC", region: "UnitedStates" },
    { id: 247, name: "Tunisia", countryCode: "TN", region: "MiddleEastNorthAfrica" },
    { id: 248, name: "Turkey", countryCode: "TR", region: "EuropeWestAfrica" },
    { id: 249, name: "Turkmenistan", countryCode: "TM", region: "EuropeWestAfrica" },
    { id: 250, name: "Turks and Caicos Islands", countryCode: "TC", region: "LatinAmerica" },
    { id: 251, name: "Tuvalu", countryCode: "TV", region: "AsiaPacific" },
    { id: 252, name: "U.S. Virgin Islands", countryCode: "USI", region: "UnitedStates" },
    { id: 253, name: "Uganda", countryCode: "UG", region: "MiddleEastNorthAfrica" },
    { id: 254, name: "Ukraine", countryCode: "UA", region: "EuropeWestAfrica" },
    { id: 255, name: "United Arab Emirates", countryCode: "AE", region: "MiddleEastNorthAfrica" },
    { id: 256, name: "United Kingdom", countryCode: "GB", region: "EuropeWestAfrica" },
    { id: 257, name: "United States", countryCode: "UM", region: "UnitedStates" },
    { id: 258, name: "Uruguay", countryCode: "UY", region: "LatinAmerica" },
    { id: 259, name: "Uzbekistan", countryCode: "UZ", region: "EuropeWestAfrica" },
    { id: 260, name: "Vanuatu", countryCode: "VU", region: "AsiaPacific" },
    { id: 261, name: "Vatican City", countryCode: "VA", region: "EuropeWestAfrica" },
    { id: 262, name: "Venezuela", countryCode: "VE", region: "LatinAmerica" },
    { id: 263, name: "Vietnam", countryCode: "VN", region: "AsiaPacific" },
    { id: 264, name: "Wake Island", countryCode: "UM", region: "UnitedStates" },
    { id: 265, name: "Wallis and Futuna", countryCode: "WF", region: "AsiaPacific" },
    { id: 266, name: "Yemen", countryCode: "YE", region: "MiddleEastNorthAfrica" },
    { id: 267, name: "Zambia", countryCode: "ZM", region: "MiddleEastNorthAfrica" },
    { id: 268, name: "Zimbabwe", countryCode: "ZW", region: "MiddleEastNorthAfrica" }
  ]




export const RegionData = [
  { name: 'Asia Pacific', id: 1, 'region': "AsiaPacific" },
  { name: 'Canada', id: 2, 'region': "Canada" },
  { name: 'Europe West Africa', id: 3, 'region': "EuropeWestAfrica" },
  { name: 'Latin America', id: 4, 'region': "LatinAmerica" },
  { name: 'Middle East North Africa', id: 5, 'region': "MiddleEastNorthAfrica" },
  { name: 'United States', id: 6, 'region': "UnitedStates" },
];

export const JobTypeOptions = [
  { name: 'Monitoring and Early Detection', id: 1 },
  { name: 'Constant Bottom Hole Pressure', id: 2 },
  { name: 'Mud Cap', id: 3 },
  { name: 'Dual Gradient', id: 4 },
  { name: 'Cementing', id: 5 },
  { name: 'Wellbore Strengthening', id: 6 },
  { name: 'Casing Run', id: 7 },
  { name: 'Coring', id: 8 },
  { name: 'Logging', id: 9 },
  { name: 'Surface Well Testing', id: 10 },
  { name: 'Frac Flow Back', id: 11 },
  { name: 'Well Cleanup', id: 12 },
  { name: 'Production Testing', id: 13 },
  { name: 'Multi-Well Production Monitoring', id: 14 },
  { name: 'Extended Well Testing', id: 15 },
  { name: 'NCD', id: 16 },
];

export const timeOptions = [
  {
      id: 1,
      "name": "(UTC-12:00) International Date Line West"
  },
  {
      id: 2,
      "name": "(UTC-11:00) Coordinated Universal Time-11"
  },
  {
      id: 3,
      "name": "(UTC-10:00) Hawaii"
  },
  {
      id: 4,
      "name": "(UTC-09:00) Alaska"
  },
  {
      id: 5,
      "name": "(UTC-08:00) Baja California"
  },
  {
      id: 6,
      "name": "(UTC-07:00) Pacific Daylight Time (US & Canada)"
  },
  {
      id: 7,
      "name": "(UTC-08:00) Pacific Standard Time (US & Canada)"
  },
  {
      id: 8,
      "name": "(UTC-07:00) Arizona"
  },
  {
      id: 9,
      "name": "(UTC-07:00) Chihuahua, La Paz, Mazatlan"
  },
  {
      id: 10,
      "name": "(UTC-07:00) Mountain Time (US & Canada)"
  },
  {
      id: 11,
      "name": "(UTC-06:00) Central America"
  },
  {
      id: 12,
      "name": "(UTC-06:00) Central Time (US & Canada)"
  },
  {
      id: 13,
      "name": "(UTC-06:00) Guadalajara, Mexico City, Monterrey"
  },
  {
      id: 14,
      "name": "(UTC-06:00) Saskatchewan"
  },
  {
      id: 15,
      "name": "(UTC-05:00) Bogota, Lima, Quito"
  },
  {
      id: 16,
      "name": "(UTC-05:00) Eastern Time (US & Canada)"
  },
  {
      id: 17,
      "name": "(UTC-04:00) Eastern Daylight Time (US & Canada)"
  },
  {
      id: 18,
      "name": "(UTC-05:00) Indiana (East)"
  },
  {
      id: 19,
      "name": "(UTC-04:30) Caracas"
  },
  {
      id: 20,
      "name": "(UTC-04:00) Asuncion"
  },
  {
      id: 21,
      "name": "(UTC-04:00) Atlantic Time (Canada)"
  },
  {
      id: 22,
      "name": "(UTC-04:00) Cuiaba"
  },
  {
      id: 23,
      "name": "(UTC-04:00) Georgetown, La Paz, Manaus, San Juan"
  },
  {
      id: 24,
      "name": "(UTC-04:00) Santiago"
  },
  {
      id: 25,
      "name": "(UTC-03:30) Newfoundland"
  },
  {
      id: 26,
      "name": "(UTC-03:00) Brasilia"
  },
  {
      id: 27,
      "name": "(UTC-03:00) Buenos Aires"
  },
  {
      id: 28,
      "name": "(UTC-03:00) Cayenne, Fortaleza"
  },
  {
      id: 29,
      "name": "(UTC-03:00) Greenland"
  },
  {
      id: 30,
      "name": "(UTC-03:00) Montevideo"
  },
  {
      id: 31,
      "name": "(UTC-03:00) Salvador"
  },
  {
      id: 32,
      "name": "(UTC-02:00) Coordinated Universal Time-02"
  },
  {
      id: 33,
      "name": "(UTC-02:00) Mid-Atlantic - Old"
  },
  {
      id: 34,
      "name": "(UTC-01:00) Azores"
  },
  {
      id: 35,
      "name": "(UTC-01:00) Cape Verde Is."
  },
  {
      id: 36,
      "name": "(UTC) Casablanca"
  },
  {
      id: 37,
      "name": "(UTC) Coordinated Universal Time"
  },
  {
      id: 38,
      "name": "(UTC) Edinburgh, London"
  },
  {
      id: 39,
      "name": "(UTC+01:00) Edinburgh, London"
  },
  {
      id: 40,
      "name": "(UTC) Dublin, Lisbon"
  },
  {
      id: 41,
      "name": "(UTC) Monrovia, Reykjavik"
  },
  {
      id: 42,
      "name": "(UTC+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna"
  },
  {
      id: 43,
      "name": "(UTC+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague"
  },
  {
      id: 44,
      "name": "(UTC+01:00) Brussels, Copenhagen, Madrid, Paris"
  },
  {
      id: 45,
      "name": "(UTC+01:00) Sarajevo, Skopje, Warsaw, Zagreb"
  },
  {
      id: 46,
      "name": "(UTC+01:00) West Central Africa"
  },
  {
      id: 47,
      "name": "(UTC+01:00) Windhoek"
  },
  {
      id: 48,
      "name": "(UTC+02:00) Athens, Bucharest"
  },
  {
      id: 49,
      "name": "(UTC+02:00) Beirut"
  },
  {
      id: 50,
      "name": "(UTC+02:00) Cairo"
  },
  {
      id: 51,
      "name": "(UTC+02:00) Damascus"
  },
  {
      id: 52,
      "name": "(UTC+02:00) E. Europe"
  },
  {
      id: 53,
      "name": "(UTC+02:00) Harare, Pretoria"
  },
  {
      id: 54,
      "name": "(UTC+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius"
  },
  {
      id: 55,
      "name": "(UTC+03:00) Istanbul"
  },
  {
      id: 56,
      "name": "(UTC+02:00) Jerusalem"
  },
  {
      id: 57,
      "name": "(UTC+02:00) Tripoli"
  },
  {
      id: 58,
      "name": "(UTC+03:00) Amman"
  },
  {
      id: 59,
      "name": "(UTC+03:00) Baghdad"
  },
  {
      id: 60,
      "name": "(UTC+02:00) Kaliningrad"
  },
  {
      id: 61,
      "name": "(UTC+03:00) Kuwait, Riyadh"
  },
  {
      id: 62,
      "name": "(UTC+03:00) Nairobi"
  },
  {
      id: 63,
      "name": "(UTC+03:00) Moscow, St. Petersburg, Volgograd, Minsk"
  },
  {
      id: 64,
      "name": "(UTC+04:00) Samara, Ulyanovsk, Saratov"
  },
  {
      id: 65,
      "name": "(UTC+03:30) Tehran"
  },
  {
      id: 66,
      "name": "(UTC+04:00) Abu Dhabi, Muscat"
  },
  {
      id: 67,
      "name": "(UTC+04:00) Baku"
  },
  {
      id: 68,
      "name": "(UTC+04:00) Port Louis"
  },
  {
      id: 69,
      "name": "(UTC+04:00) Tbilisi"
  },
  {
      id: 70,
      "name": "(UTC+04:00) Yerevan"
  },
  {
      id: 71,
      "name": "(UTC+04:30) Kabul"
  },
  {
      id: 72,
      "name": "(UTC+05:00) Ashgabat, Tashkent"
  },
  {
      id: 73,
      "name": "(UTC+05:00) Yekaterinburg"
  },
  {
      id: 74,
      "name": "(UTC+05:00) Islamabad, Karachi"
  },
  {
      id: 75,
      "name": "(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi"
  },
  {
      id: 76,
      "name": "(UTC+05:30) Sri Jayawardenepura"
  },
  {
      id: 77,
      "name": "(UTC+05:45) Kathmandu"
  },
  {
      id: 78,
      "name": "(UTC+06:00) Nur-Sultan (Astana)"
  },
  {
      id: 79,
      "name": "(UTC+06:00) Dhaka"
  },
  {
      id: 80,
      "name": "(UTC+06:30) Yangon (Rangoon)"
  },
  {
      id: 81,
      "name": "(UTC+07:00) Bangkok, Hanoi, Jakarta"
  },
  {
      id: 82,
      "name": "(UTC+07:00) Novosibirsk"
  },
  {
      id: 83,
      "name": "(UTC+08:00) Beijing, Chongqing, Hong Kong, Urumqi"
  },
  {
      id: 84,
      "name": "(UTC+08:00) Krasnoyarsk"
  },
  {
      id: 85,
      "name": "(UTC+08:00) Kuala Lumpur, Singapore"
  },
  {
      id: 86,
      "name": "(UTC+08:00) Perth"
  },
  {
      id: 87,
      "name": "(UTC+08:00) Taipei"
  },
  {
      id: 88,
      "name": "(UTC+08:00) Ulaanbaatar"
  },
  {
      id: 89,
      "name": "(UTC+08:00) Irkutsk"
  },
  {
      id: 90,
      "name": "(UTC+09:00) Osaka, Sapporo, Tokyo"
  },
  {
      id: 91,
      "name": "(UTC+09:00) Seoul"
  },
  {
      id: 92,
      "name": "(UTC+09:30) Adelaide"
  },
  {
      id: 93,
      "name": "(UTC+09:30) Darwin"
  },
  {
      id: 94,
      "name": "(UTC+10:00) Brisbane"
  },
  {
      id: 95,
      "name": "(UTC+10:00) Canberra, Melbourne, Sydney"
  },
  {
      id: 96,
      "name": "(UTC+10:00) Guam, Port Moresby"
  },
  {
      id: 97,
      "name": "(UTC+10:00) Hobart"
  },
  {
      id: 98,
      "name": "(UTC+09:00) Yakutsk"
  },
  {
      id: 99,
      "name": "(UTC+11:00) Solomon Is., New Caledonia"
  },
  {
      id: 100,
      "name": "(UTC+11:00) Vladivostok"
  },
  {
      id: 101,
      "name": "(UTC+12:00) Auckland, Wellington"
  },
  {
      id: 102,
      "name": "(UTC+12:00) Coordinated Universal Time+12"
  },
  {
      id: 103,
      "name": "(UTC+12:00) Fiji"
  },
  {
      id: 104,
      "name": "(UTC+12:00) Magadan"
  },
  {
      id: 105,
      "name": "(UTC+12:00) Petropavlovsk-Kamchatsky - Old"
  },
  {
      id: 106,
      "name": "(UTC+13:00) Nuku'alofa"
  },
  {
      id: 107,
      "name": "(UTC+13:00) Samoa"
  }
]

