export const DefaultValues = {
  torqueDrag: {
    FlowRate: { unitName: "flow", value: 0, from: 0, to: 2000.0 },
    BitDepth: { unitName: "length", value: 3000.0, from: 0, to: 50000.0 },
    ROBTDS: { operationValue: 1, unitName: "rotationVelocity", value: 100, from: 0, to: 600.0 },
    TrippingInRS: { operationValue: 2, unitName: "velocityRunningSpeed", value: 600, from: 0, to: 3937.007874 },
    TrippingOutRS: { operationValue: 4, unitName: "velocityRunningSpeed", value: 600, from: 0, to: 3937.007874 },
    DrillingRotaryWOB: { operationValue: 8, unitName: "force", value: 10000.0000343069678, from: 0, to: 112404.472 },
    DrillingRotaryTOB: { operationValue: 8, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    DrillingRotaryTDS: { operationValue: 8, unitName: "rotationVelocity", value: 100, from: 0, to: 600.0 },
    DrillingRotaryROP: { operationValue: 8, unitName: "penetrationRate", value: 30, from: 0, to: 1500.0 },
    DrillingSlidingWOB: { operationValue: 16, unitName: "force", value: 2000.0000068613936, from: 0, to: 112404.472 },
    DrillingSlidingROP: { operationValue: 16, unitName: "penetrationRate", value: 25, from: 0, to: 1500.0 },
    ReamingTDS: { operationValue: 32, unitName: "rotationVelocity", value: 60, from: 0, to: 600.0 },
    ReamingRS: { operationValue: 32, unitName: "velocityRunningSpeed", value: 60, from: 0, to: 3937.007874 },
    BackReamingTDS: { operationValue: 64, unitName: "rotationVelocity", value: 60, from: 0, to: 600.0 },
    BackReamingRS: { operationValue: 64, unitName: "velocityRunningSpeed", value: 60, from: 0, to: 3937.007874 },
    PickupRS: { operationValue: 128, unitName: "velocityRunningSpeed", value: 60, from: 0, to: 3937.007874 },
    PickupStuckDepth: { operationValue: 128, unitName: "length", value: 3000, from: 0, to: 50000 },
    PickupStuckWeight: { operationValue: 128, unitName: "force", value: 10000, from: 0, to: 500000.0 },
    SlackOffRS: { operationValue: 256, unitName: "velocityRunningSpeed", value: 60, from: 0, to: 3937.007874 },
    SlackOffStuckDepth: { operationValue: 256, unitName: "length", value: 3000, from: 0, to: 50000 },
    SlackOffStuckWeight: { operationValue: 256, unitName: "force", value: 10000, from: -200000, to: 500000 },
    UnderreamingTDS: { operationValue: 512, unitName: "rotationVelocity", value: 100, from: 0, to: 600 },
    UnderreamingWOB: { operationValue: 512, unitName: "force", value: 10000, from: 0, to: 500000.0 },
    UnderreamingTOB: { operationValue: 512, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    UnderreamingROP: { operationValue: 512, unitName: "penetrationRate", value: 30, from: 0, to: 1500 },
    UnderreamingStuckDepth: { operationValue: 512, unitName: "length", value: 3000, from: 0, to: 50000 },
    UnderreamingStuckWeight: { operationValue: 512, unitName: "force", value: 10000, from: -200000, to: 500000 },
    UnderreamingStuckTorque: { operationValue: 512, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    CuttingTDS: { operationValue: 1024, unitName: "rotationVelocity", value: 100, from: 0, to: 600 },
    CuttingStuckDepth: { operationValue: 1024, unitName: "length", value: 3000, from: 0, to: 50000 },
    CuttingStuckTorque: { operationValue: 1024, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    CustomUpTDS: { operationValue: 2048, unitName: "rotationVelocity", value: 100, from: 0, to: 600 },
    CustomUpRS: { operationValue: 2048, unitName: "velocityRunningSpeed", value: 60, from: 0, to: 3937.007874 },
    CustomUpStuckDepth: { operationValue: 2048, unitName: "length", value: 3000, from: 0, to: 50000 },
    CustomUpStuckWeight: { operationValue: 2048, unitName: "force", value: 0, from: 0, to: 500000 },
    CustomUpStuckTorque: { operationValue: 2048, unitName: "torque", value: 0, from: 0, to: 73756.212116966 },
    CustomDownTDS: { operationValue: 4096, unitName: "rotationVelocity", value: 100, from: 0, to: 600 },
    CustomDownWOB: { operationValue: 4096, unitName: "force", value: 10000, from: 0, to: 112404.471549855 },
    CustomDownTOB: { operationValue: 4096, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    CustomDownROP: { operationValue: 4096, unitName: "penetrationRate", value: 30, from: 0, to: 1500 },
    CustomDownStuckDepth: { operationValue: 4096, unitName: "length", value: 3000, from: 0, to: 50000 },
    CustomDownStuckWeight: { operationValue: 4096, unitName: "force", value: 10000, from: -200000, to: 500000 },
    CustomDownStuckTorque: { operationValue: 4096, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    CustomStationaryTDS: { operationValue: 8192, unitName: "rotationVelocity", value: 100, from: 0, to: 600 },
    CustomStationaryWOB: { operationValue: 8192, unitName: "force", value: 10000, from: 0, to: 112404.471549855 },
    CustomStationaryTOB: { operationValue: 8192, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 },
    CustomStationaryStuckDepth: { operationValue: 8192, unitName: "length", value: 3000, from: 0, to: 50000 },
    CustomStationaryStuckTorque: { operationValue: 8192, unitName: "torque", value: 3000, from: 0, to: 73756.212116966 }
  },
  surgeSwab: {
    ReferenceECDForSwab: { value: 0, from: 0, to: 99, unitName: "density" },
    ECDReferenceDepth: { value: 0, from: 0, to: 99, unitName: "density" },
    ReferenceDepth: { value: 0, from: 0, to: 50000, unitName: "length" },

    StandLength: { value: 90, from: 10, to: 138, unitName: "length" },
    AccelerationTime: { value: 15, from: 3, to: 30, unitName: "time" },
    ConnectionTime: { value: 300, from: 0, to: 300, unitName: "time" },
    MaxPipeVelocity: { value: 0.2, from: 0.01, to: 10.0, unitName: "velocityRunningSpeed" },
    SurfaceBackPressure: { value: 0, from: 0, to: 2000.0, unitName: "pressure" },
    PumpFlowRate: { value: 0, from: 0, to: 2000, unitName: "flow" }
  },
  snapshot: {
    BitDepth: { value: 0, from: 0, to: 50000, unitName: "length" },
    FlowRate: { value: 0, from: 0, to: 2000, unitName: "flow" },
    DepthOfIntereset: { value: 0, from: 0, to: 50000, unitName: "length" },
    RotarySpeed: { value: 0, from: 0, to: 1000, unitName: "rotationVelocity" },
    SurfaceBackPressure: { value: 0, from: 0, to: 15000, unitName: "pressure" },
    MudInletTemperature: { value: 90, from: 40, to: 400, unitName: "temperature" }
  },
  bitOptimization: {
    DesiredPumpPressure: { value: 2000, from: 0, to: 7000, unitName: "pressure" },
    DesiredRateOfPenetration: { value: 100, from: 0, to: 1500, unitName: "penetrationRate" },
    // MinAnnularVelocity: { value: 0, from: 0, to: 50000, unitName: "velocityFluid" },
    MinBitTFA: { value: 0, from: 0, to: 6, unitName: "shortLength" },
    RotarySpeed: { value: 0, from: 0, to: 1000, unitName: "rotationVelocity" },
    DepthOfIntereset: { value: 11354.65, from: 0, to: 50000, unitName: "length" },
    MudInletTemperature: { value: 90, from: 40, to: 400, unitName: "temperature" },
    CuttingsDiameter: { value: 0, from: 0.005, to: 3, unitName: "shortLength" },
    CuttingsDensity: { value: 21.60, from: 0, to: 163.63, unitName: "density" },
  },
  parametric: {
    depthOfInterest: { value: 10000, maxRange: 50000, unitName: "length" },
    bitDepth: { From: 10000, To: null, maxRange: 10000, unitName: "length" },
    flowRate: { From: 350, To: 450, maxRange: 2000, unitName: "flow" },
    rop: { From: 40, To: 50, maxRange: 1500, unitName: "penetrationRate" },
    tds: { From: 30, To: 40, maxRange: 1000, unitName: "rotationVelocity" },
    sbp: { From: 0, To: null, maxRange: 2000, unitName: "pressure" },
    CuttingsDiameter: { value: 0, From: 0.005, To: 3, unitName: "shortLength" },
    CuttingsDensity: { value: 21.60, From: 0, To: 163.63, unitName: "density" },
    mudInletTemperature: { value: 90, unitName: "temperature" },
  }
}







// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_OperationType_DisplayName))]
// [DefaultValue(TorqueAndDragOperations.DrillingRotary | TorqueAndDragOperations.DrillingSliding | TorqueAndDragOperations.RunningIn | TorqueAndDragOperations.PullingOut | TorqueAndDragOperations.RoffB)]
// [EnumDefinedProperty(typeof(TorqueAndDragOperations))]
// [DataMember]
// public virtual int Operation { get; set; }

// /// <summary>
// /// Gets or sets the FlowRate
// /// </summary>
// [Category("General")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_FlowRate_DisplayName))]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_FlowRate_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [Browsable(true)]
// [Range(0.0, 2000.0)]
// [DefaultValue(0)]
// [UnitPropertyAttribute(UnitTypes.Flow, FlowUnits.GallonsPerMinute)]
// [DataMember]
// public virtual double FlowRate { get; set; }

// /// <summary>
// /// Gets or sets the depth of interest
// /// </summary>
// [Category("General")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_BitDepth_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_BitDepth_Description))]
// [DefaultValue(3000.0)]
// [UnitPropertyAttribute(UnitTypes.Length, LengthUnits.Feet)]
// [Range(0.0, 50000.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_BitDepth_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [DataMember]
// public virtual double BitDepth { get; set; }

// /// <summary>
// /// Gets or sets the Rotational Effects
// /// </summary>
// [Category("General")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_RotationalEffects_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_RotationalEffects_Description))]
// [DefaultValue(false)]
// [DataMember]
// public virtual bool RotationalEffects { get; set; }

// /// <summary>
// /// Gets or sets the CalculateBHAContactForce
// /// </summary>
// [Category("General")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_CalculateBHAContactForce_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_CalculateBHAContactForce_Description))]
// [DefaultValue(false)]
// [DataMember]
// public virtual bool CalculateBHAContactForce { get; set; }

// /// <summary>
// /// Gets or sets the Solver
// /// </summary>
// [Category("General")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_Solver_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_Solver_Description))]
// [DefaultValue(TnDSolvers.StaticSoft)]
// //[Browsable(false)]
// [DataMember]
// public virtual TnDSolvers Solver { get; set; }

// /// <summary>
// /// Gets or sets the Block Weight
// /// </summary>
// [Category("General")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_BlockWeight_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_BlockWeight_Description))]
// [Browsable(false)]
// [DefaultValue(0)]
// [UnitProperty(UnitTypes.Force, ForceUnits.Newton)]
// [DataMember]
// public virtual double BlockWeight { get; set; }





// [Category("DrillingRotary")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryWOB_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryWOB_Description))]
// [DefaultValue(44482.216152605)]
// [Range(0.0, 500000.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryWOB_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Force, ForceUnits.Newton)]
// [DataMember]
// public virtual double DrillingRotaryWOB { get; set; }

// [Category("DrillingRotary")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTOB_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTOB_Description))]
// [DefaultValue(3000)]
// [Range(0.0, 73756.212116966)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTOB_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public virtual double DrillingRotaryTOB { get; set; }

// [Category("DrillingRotary")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_Description))]
// [DefaultValue(100)]
// [Range(0.0, 600.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public virtual double DrillingRotaryTDS { get; set; }

// [Category("DrillingRotary")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryROP_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryROP_Description))]
// [DefaultValue(30)]
// [Range(0.0, 1500.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryROP_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.PenetrationRate, PenetrationRateUnits.FeetPerHour)]
// [DataMember]
// public virtual double DrillingRotaryROP { get; set; }

// [Category("DrillingSliding")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryWOB_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryWOB_Description))]
// [DefaultValue(8896.443230521)]
// [Range(0.0, 500000.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingSlidingWOB_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Force, ForceUnits.Newton)]
// [DataMember]
// public virtual double DrillingSlidingWOB { get; set; }

// [Category("DrillingSliding")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryROP_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryROP_Description))]
// [DefaultValue(25)]
// [Range(0.0, 1500.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingSlidingROP_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.PenetrationRate, PenetrationRateUnits.FeetPerHour)]
// [DataMember]
// public virtual double DrillingSlidingROP { get; set; }

// [Category("TrippingIn")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_Description))]
// [DefaultValue(600)]
// [Range(0.0, 3937.007874)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public virtual double TrippingInRS { get; set; }

// [Category("TrippingOut")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_Description))]
// [DefaultValue(600)]
// [Range(0.0, 3937.007874)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingOutRS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public virtual double TrippingOutRS { get; set; }

// [Category("ROB")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_Description))]
// [DefaultValue(100)]
// [Range(0.0, 600.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_ROBTDS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public virtual double ROBTDS { get; set; }

// [Category("Reaming")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_Description))]
// [DefaultValue(60)]
// [Range(0.0, 600.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_ReamingTDS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public virtual double ReamingTDS { get; set; }

// [Category("Reaming")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_Description))]
// [DefaultValue(60)]
// [Range(0.0, 3937.007874)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_ReamingRS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public virtual double ReamingRS { get; set; }

// [Category("BackReaming")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_DrillingRotaryTDS_Description))]
// [DefaultValue(60)]
// [Range(0.0, 600.0)]
// [Required(ErrorMessageResourceName = nameof(Localization.Properties.Resources.Model_PredrillInput_BackReamingTDS_Required), ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public virtual double BackReamingTDS { get; set; }

// [Category("BackReaming")]
// [DisplayNameResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_DisplayName))]
// [DescriptionResource(nameof(Localization.Properties.Resources.Model_PredrillInput_TrippingInRS_Description))]
// [DefaultValue(60)]
// [Range(0.0, 3937.007874)]
// [Required(ErrorMessageResourceName = "Model_PredrillInput_BackReamingRS_Required", ErrorMessageResourceType = typeof(Localization.Properties.Resources))]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public virtual double BackReamingRS { get; set; }

// [DefaultValue(60d)]
// [Range(0d, 3937.007874)]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public double? PickupRS { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? PickupStuckDepth { get; set; }

// [DefaultValue(10000d)]
// [Range(0d, 500000.0)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? PickupStuckWeight { get; set; }

// [DefaultValue(60d)]
// [Range(0d, 3937.007874)]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public double? SlackOffRS { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? SlackOffStuckDepth { get; set; }

// [DefaultValue(10000d)]
// [Range(-200000d, 500000d)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? SlackOffStuckWeight { get; set; }

// [DefaultValue(100d)]
// [Range(0d, 600d)]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public double? UnderreamingTDS { get; set; }

// [DefaultValue(10000d)]
// [Range(0d, 500000.0)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? UnderreamingWOB { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? UnderreamingTOB { get; set; }

// [DefaultValue(30d)]
// [Range(0d, 1500d)]
// [UnitProperty(UnitTypes.PenetrationRate, PenetrationRateUnits.FeetPerHour)]
// [DataMember]
// public double? UnderreamingROP { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? UnderreamingStuckDepth { get; set; }

// [DefaultValue(10000d)]
// [Range(-200000d, 500000d)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? UnderreamingStuckWeight { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? UnderreamingStuckTorque { get; set; }

// [DefaultValue(100d)]
// [Range(0d, 600d)]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public double? CuttingTDS { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? CuttingStuckDepth { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? CuttingStuckTorque { get; set; }

// [DefaultValue(100d)]
// [Range(0d, 600d)]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public double? CustomUpTDS { get; set; }

// [DefaultValue(60d)]
// [Range(0d, 3937.007874)]
// [UnitProperty(UnitTypes.Speed, SpeedUnits.FeetPerMinute)]
// [DataMember]
// public double? CustomUpRS { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? CustomUpStuckDepth { get; set; }

// [DefaultValue(0d)]
// [Range(0d, 500000d)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? CustomUpStuckWeight { get; set; }

// [DefaultValue(0d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? CustomUpStuckTorque { get; set; }

// [DefaultValue(100d)]
// [Range(0d, 600d)]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public double? CustomDownTDS { get; set; }

// [DefaultValue(10000d)]
// [Range(0d, 112404.471549855)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? CustomDownWOB { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? CustomDownTOB { get; set; }

// [DefaultValue(30d)]
// [Range(0d,1500d)]
// [UnitProperty(UnitTypes.PenetrationRate, PenetrationRateUnits.FeetPerHour)]
// [DataMember]
// public double? CustomDownROP { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? CustomDownStuckDepth { get; set; }

// [DefaultValue(10000d)]
// [Range(-200000d, 500000d)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? CustomDownStuckWeight { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? CustomDownStuckTorque { get; set; }

// [DefaultValue(100d)]
// [Range(0d, 600d)]
// [UnitProperty(UnitTypes.RotatorySpeed, RotatorySpeedUnits.RevolutionsPerMinute)]
// [DataMember]
// public double? CustomStationaryTDS { get; set; }

// [DefaultValue(10000d)]
// [Range(0d, 112404.471549855)]
// [UnitProperty(UnitTypes.Force, ForceUnits.PoundForce)]
// [DataMember]
// public double? CustomStationaryWOB { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? CustomStationaryTOB { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 50000d)]
// [UnitProperty(UnitTypes.Length, LengthUnits.Feet)]
// [DataMember]
// public double? CustomStationaryStuckDepth { get; set; }

// [DefaultValue(3000d)]
// [Range(0d, 73756.212116966)]
// [UnitProperty(UnitTypes.Torque, TorqueUnits.PoundForceFoot)]
// [DataMember]
// public double? CustomStationaryStuckTorque { get; set; }


