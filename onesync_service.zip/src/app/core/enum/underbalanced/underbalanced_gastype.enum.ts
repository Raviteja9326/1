export enum GasType {

  "Dry Air" = '1',
  "Nitrogen"= '2'

}