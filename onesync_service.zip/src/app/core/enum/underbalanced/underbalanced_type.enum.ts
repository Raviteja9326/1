export enum FluidType {

    'Dust' = '4',
    'Foam' = '6',
    'Mist/Gasified' = '5'
  }