export enum ProjectAction {
    ADD = "Add Project",
    EDIT = "Edit Project"
}