
/**
 * This file will hold the details of all the regions.
 */

export enum Region {

        'AsiaPacific' = '1',
        'Canada' = '2',
        'EuropeWestAfrica' = '3',
        'LatinAmerica' = '4',
        'MiddleEastNorthAfrica' = '5',
        'UnitedStates' = '6',
    
}

