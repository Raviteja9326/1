/**
 * This file will hold the details of all the Stabilizer types for workstring tools.
 */

export enum StabilizerType {
    "Gauge Extender" = '4',
    "Near-bit Stabilizer" = '2',
    "Non-Mag Near-bit Stabilizer" = '6',
    "Non-Mag Roller Reamer" = '7',
    "Non-Mag String Stabilizer" = '5',
    "Roller Reamer" = '3',
    "String Stabilizer" = '1'
}