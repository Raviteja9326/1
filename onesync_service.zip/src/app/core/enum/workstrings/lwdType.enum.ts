export enum LWDType{
    "AZD™-TNP™" = '1',
    "CrossWave™" = '2',
    "EMpulse™ HEL™" = '3',
    "GuideWave™" = '4',
    "HEL™" = '5',
    "HEX NEU" = '6',
    "IDS™" = '7',
    "MFR™" = '8',
    "PressureWave™" = '9',
    "ShockWave™" = '10',
    "SineWave™" = '11',
    "SpectraWave™" = '12',
    "UltraWave™" = '13'
}
