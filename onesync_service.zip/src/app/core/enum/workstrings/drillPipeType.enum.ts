/**
 * This file will hold the details of all the Drill Pipe types for workstring tools.
 */

export enum DrillPipeType {
    "Drill Pipe" = '1'
}