/**
 * This file will hold the details of all the Adjustable setting for custom tools.
 */

export const AdjustableSettings = 
    [
        0.00, 0.39, 0.78, 1.16, 1.53, 1.89, 2.20, 2.54, 2.83, 3.09, 3.33, 3.53, 3.70, 3.82, 3.92, 3.98, 4.00
    ]
