/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum SubType {
    "Ball Lock Sub" = '1',
    "Bit Sub" = '2',
    "Bottle-neck Crossover" = '3',
    "Crossover Sub" = '4',
    "Filter Sub" = '5',
    "Float Sub" = '6',
    "Non-Magnetic Bottle-neck Crossover" = '7',
    "Non-Magnetic Saver Sub" = '8',
    "Non-Magnetic Sub" = '9',
    "Saver Sub" = '10',
    "Sub" = '11',
    "UBHO Sub" = '12'
}