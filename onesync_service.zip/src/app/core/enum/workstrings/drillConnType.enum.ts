/**
 * This file will hold the details of all the Drill Pipe connection types for workstring tools.
 */

export enum DrillConnType {
    "N26" = '1',
    "HT26" = '2'
}