/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum GradeUpsetType {
    "E-75 EU" = '1',
    "G-105 EU" = '2',
    "S-135 EU" = '3',
    "V-150 EU" = '4',
    "X-95 EU"= '5',
    "Z-140 EU" = '6'
}