/**
 * This file will hold the details of all the Hole opener types for custom tools.
 */

export enum HoleOpenerType {
    "Rip Tide™" = '1',
}