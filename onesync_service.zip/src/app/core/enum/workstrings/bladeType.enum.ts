/**
 * This file will hold the details of all the blade types for workstring tools.
 */

export enum BladeType {
    "Clamp-On" = '1',
    "Integral" = '2',
    "None" = '3',
    "Unknown" = '4',
    "Weided" = '5'
}