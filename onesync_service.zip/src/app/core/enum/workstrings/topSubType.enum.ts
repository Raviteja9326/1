/**
 * This file will hold the details of Top Sub Type for drilling motor
 */

export enum TopSubType {
    "Plain"='1',
    "w/ Rotor Catch" = '2',
    "w/ Rotor Catch and Float Value"= '4',
}