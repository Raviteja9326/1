/**
 * This file will hold the details of all the Adjustable gauge Tool configurations for workstring tools.
 */

export const AdjustableToolConfiguration = {
    1:[
        {label:'GEN I', value:1}
    ],
    
}