/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum StablizersType {
    "Stab_1" = '1',
    "Stab_2" = '2',
    "Stab_3" = '3',
    "Stab_4" = '4',
    "Stab_5" = '5',
    "Stab_6" = '6',
    "Stab_7" = '7',
    "Stab_8" = '8',
    "Stab_9" = '9'
}