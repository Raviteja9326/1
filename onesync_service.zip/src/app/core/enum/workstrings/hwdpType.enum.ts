/**
 * This file will hold the details of all the HWDP types for workstring tools.
 */

export enum HWDPType {
    "Non-Mag Spriral Heavy Weight Drill Pipe" = '1',
    "Non-Mag Standard Heavy Weight Drill Pipe" = '2',
    "Non-Mag Tri-Spriral Heavy Weight Drill Pipe" = '3',
    "Spriral Heavy Weight Drill Pipe" = '4',
    "Standard Heavy Weight Drill Pipe" = '5',
    "Tri-Spriral Heavy Weight Drill Pipe" = '6',
}