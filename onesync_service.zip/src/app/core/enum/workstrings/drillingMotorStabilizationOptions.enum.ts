export enum DrillingMotorStabilizationOptions{
    'None' = '0',
    'SRSBearingMandrel' = '1',
    'ScrewOnStraightHousing' = '2',
    'IBSBearingHousing' = '4',
    'StatorHousingAdapter' = '8',
}