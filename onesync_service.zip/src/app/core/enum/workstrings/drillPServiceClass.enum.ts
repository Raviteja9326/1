/**
 * This file will hold the details of all the Tool configurations for custom tools.
 */

export const DrillPipeServiceClass = {
    1:{
        WallThicknessFactor:1.4,
        TSRFactor:0.7,
    },
    2:{
        WallThicknessFactor:2,
        TSRFactor:1,
    },
    3:{
        WallThicknessFactor:1.6,
        TSRFactor:0.8,
    },
    4:
    {
        WallThicknessFactor:1.6,
        TSRFactor:0.5,
    }
   
    
}