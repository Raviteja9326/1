/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum ThrutubingType {
    "CTD Drilex" = '1',
    "CTD M2M" = '2',
    "CTD PDM" = '3',
    "eCTD" = '4',
    "MacDrill" = '5',
}