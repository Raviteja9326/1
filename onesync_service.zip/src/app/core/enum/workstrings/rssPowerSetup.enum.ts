export enum PowerSetupOptions {
    'Turbine + 1 BAT'="TurbinePlusOneBat", //= 1, //Turbine + 1 BAT
    '3 BAT' = "ThreeBat", //= 2,//3 BAT
    'Turbine + 3 BAT' = "TurbinePlusThreeBat", //= 3, //Turbine + 3 BAT
    '5 BAT' = "FiveBat", //= 4, // 5 BAT
    'APS Turbine + 1 BAT' = "APSTurbinePlusOneBat", //= 5,//APS Turbine + 1 BAT
    'Turbine + 1 BAT + 2 Pulser + 1 Driver + 1 IDS' = "TurbinePlusOneBatPlusOnePulserPlusOneDriverPlusOneIDS", //= 6,//Turbine + 1 BAT + 2 Pulser + 1 Driver + 1 IDS
    'Turbine + 2 BAT' = "TurbinePlusTwoBat", //= 7,//Turbine + 2 BAT
    '4 BAT' = "FourBat", //= 8 //4 BAT
}
