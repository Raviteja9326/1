/**
 * This file will hold the details of all the Special Tool types for workstring tools.
 */

export enum SpecialToolState{
    "Annulus Only" = '1',
    "Pipe and Annulus" = '2',
    "Pipe Only" = '3',

}