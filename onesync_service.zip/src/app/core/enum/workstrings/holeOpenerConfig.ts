/**
 * This file will hold the details of all the Hole opener Tool configurations for workstring tools.
 */

export const HoleOpenerToolConfiguration = {
    1:[
        {label:'Mechanical', value:1},
        {label:'RFID', value:2},
    ],
    
}