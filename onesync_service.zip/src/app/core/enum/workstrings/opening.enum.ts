/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum Opening {
    "Closed" = '1',
    '6.250' = '2',
    '7.000' = '3',
    '7.250' = '4',
    '7.500' = '5',
    '7.880' = '6',
    '8.000' = '7',
    '8.500' = '8'
}