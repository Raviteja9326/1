/**
 * This file will hold the details of all the Adjustable gauge stabilizer piston position types for workstring tools.
 */

export enum PistonPosition {
    "Closed" = '1',
    "Open" = '2'
}