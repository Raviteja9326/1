/**
 * This file will hold the details of all the HWDP connection types for workstring tools.
 */

export enum HWDPConnType {
    "NC38" = '1',
    "3-1/2 IF" = '2'
}