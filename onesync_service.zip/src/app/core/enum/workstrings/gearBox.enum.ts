/**
 * This file will hold the details of all the Gear Box option for Thrutubing in workstring tools.
 */

export enum GearBox {
    "No" = '1'
}