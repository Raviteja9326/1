/**
 * This file will hold the details of all the Adjustable gauge stabilizer types for workstring tools.
 */

export enum AdjustableType {
    "StableLine™" = '1',
    
}