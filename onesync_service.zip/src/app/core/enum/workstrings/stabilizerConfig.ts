/**
 * This file will hold the details of all the Stabilizer Tool configurations for workstring tools.
 */

export const StabilizerToolConfiguration = {
    1:[
        {label:'6.75\' NSC435', value:1},
       
    ],
    2:[
        {label:'6.75\' Near-bit Stabilizer', value:1},
       
    ],
    3:[
        {label:'2.875\' Near-bit Stabilizer', value:1},
       
    ],
    4:[
        {label:'4.75\' x 5.825\' (HS), RR', value:1},
        {label:'4.75\' x 6\' (HS), RR', value:2},
        {label:'4.75\' x 6.125\' (HS), RR', value:3},
        {label:'4.75\' x 6.25\' (HS), RR', value:4},
        {label:'4.75\' x 6.5\' (HS), RR', value:5},
    ],
    5:[
        {label:'4.75\' String Stabilizer', value:1},
     
    ],
    6:[
        {label:'4.75\' x 5.825\' (HS), RR', value:1},
        {label:'4.75\' x 6\' (HS), RR', value:2},
        {label:'4.75\' x 6.125\' (HS), RR', value:3},
        {label:'4.75\' x 6.25\' (HS), RR', value:4},
        {label:'4.75\' x 6.5\' (HS), RR', value:5},
    ],
    7:[
        {label:'4.75\' String Stabilizer', value:1},
     
    ],
}