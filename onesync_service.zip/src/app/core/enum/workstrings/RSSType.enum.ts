/**
 * This file will hold the details of all the RSS types for workstring tools.
 */

export enum RSSType {
    "Custom" = '-1',
    "Revolution® RSS MK3" = '1',
    "Revolution® RSS MK4" = '2',
    "Magnus™ Rss" = '3',
}