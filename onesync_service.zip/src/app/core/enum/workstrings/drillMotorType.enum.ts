/**
 * This file will hold the details of all the Drill motor types for workstring tools.
 */

export enum DrillMotorType {
    "HyperLine™ 250" = '1',
}