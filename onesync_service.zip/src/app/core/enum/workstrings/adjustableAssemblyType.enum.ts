export enum AdjustableAssemblyType{
    "0°-2°"='1',//3
    "0°-3°"='2',//2
    "0°-4°"='4'//4
}