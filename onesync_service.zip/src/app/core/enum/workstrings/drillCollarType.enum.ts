/**
 * This file will hold the details of all the Drill collar types for workstring tools.
 */

export enum DrillCollarType {
    "Drill Collar" = '0',
    "Flex Drill Collar" = '7',
    "Flex Non-Mag Drill Collar" = '8',
    "Non-Mag Drill Collar" = '5',
    "Non-Mag Pony Drill Collar" = '6',
    "Non-Mag Spiral Drill Collar" = '12',
    "Pony Drill Collar" = '4',
    "Short Flex Drill Collar" = '9',
    "Short Flex Non-Mag Drill Collar" = '10',
    "Spiral Drill Collar" = '11'
}