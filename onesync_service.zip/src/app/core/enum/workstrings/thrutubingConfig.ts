/**
 * This file will hold the details of all the Hole opener Tool configurations for workstring tools.
 */

export const ThrutubingToolConfiguration = {
    1:[
        {label:'7:8,1.5 stages', value:1},
    ],
    2:[
        {label:'7:8,6.0 stages', value:1},
    ],
    3:[
        {label:'5:6,2.3 stages', value:1},
    ],
    4:[
        {label:'5:6,2.3 stages', value:1},
    ],
    5:[
       //no config
    ],
}