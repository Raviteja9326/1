/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum BitType {
    "Bi-center" = '5',
    "Diamond Impreg" = '7',
    "Digger" = '6',
    "Extended Gauge Diamond Impreg" = '9',
    "Extended Gauge PDC" = '8',
    "Hybrid" = '4',
    "Mill Tooth" = '3',
    "PDC" = '1',
    "Roller Cone" = '2'
}