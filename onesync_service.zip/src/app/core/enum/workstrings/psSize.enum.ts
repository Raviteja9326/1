/**
 * This file will hold the details of all the Adjustable setting for custom tools.
 */

export const PSSize = 
    [
        '3.750',
        '4.125',
        '4.750',
        '5.000',
        '6.250',
        '6.550',
        '6.750',
        '8.000',
        '9.625',
        '11.250'
    ]
