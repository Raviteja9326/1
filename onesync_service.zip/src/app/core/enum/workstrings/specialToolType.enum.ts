/**
 * This file will hold the details of all the Special Tool types for workstring tools.
 */

export enum SpecialToolType{
    "Circulating sub" = '1',
    "JetStream™ Circulation sub" = '2',
    "RCT Crossover" = '3',

}