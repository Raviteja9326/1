/**
 * This file will hold the details of all the Bit types for custom tools.
 */

export enum ModelRssType {
    "Model_RSSTypes_MK1" = '1',
    "Model_RSSTypes_MK2" = '2',
    "Model_RSSTypes_MK3" = '3',
    "Model_RSSTypes_MK4" = '4',
    "Model_RSSTypes_MK5" = '5',
    "Model_RSSTypes_MK6" = '6',
    "Model_RSSTypes_MK7" = '7',
    "Model_RSSTypes_MK8" = '8',
    "Model_RSSTypes_MK9" = '9'
}