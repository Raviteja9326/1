/**
 * This file will hold the details of all the Service class for drill pipe for workstring tools.
 */

export enum ServiceClass {
    "Class 2"='1',
    "New" = '2',
    "Premium" = '3',
    "Premium (reduced TSR)" = '4'
}
