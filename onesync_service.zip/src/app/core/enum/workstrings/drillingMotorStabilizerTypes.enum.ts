export enum DrillingMotorStabilizerTypes{
    'TopSub' = '1' ,
    'PowerSectionCentralizer' = '2',
    'IBSStatorHousingAdaptor' = '3',
    'KickPad' = '4',
    'IBSBearingHousingStab' = '5',
    'BitBox' = '6',
    'JunkSlot' = '7'
}