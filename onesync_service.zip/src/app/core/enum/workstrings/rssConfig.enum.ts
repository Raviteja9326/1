/**
 * This file will hold the details of all the RSS Config for workstring tools.
 */

export enum RSSConfig {
    "Standard Flex" = 'StandardFlex',
    "Flex" = 'Flex',
    "Short Slick" = 'ShortSlick',
    "All-In-One Flex" = 'AllInOneFlex',
    "All-In-One Slick" = 'AllInOneSlick',
    "All-In-One Long Flex" = 'AllInOneLongFlex',
    "Short Stiff" = 'ShortStiff',
    "All-In-One Stiff" = 'AllInOneStiff',
    "Short Flex" = 'ShortFlex',
    "Stiff" = 'Stiff',
    "All-In-One Long Stiff" = 'AllInOneLongStiff',
    "All-In-One Short Flex" = 'AllInOneShortFlex',
    "Long Stiff" = 'LongStiff',
    "4-BAT Stiff" = 'FourBatStiff',

}
