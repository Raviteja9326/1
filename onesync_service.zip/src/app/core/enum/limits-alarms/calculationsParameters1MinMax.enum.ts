/**
 * Bit depth
*/
export enum CalculationsParameters1MinMax {
    "Calculations / 1 AC:No Data" = 1,
    "Calculations / 10 AC:Slide Drilling"= 2,
    "Calculations / 11 AC:On Btm Inactive" = 3,
    "Calculations / 12 AC:Calculating On Btm"=4,
    "Calculations / 13 AC:Picking Up"= 5,
    "Calculations / 14 AC:Letting Down"= 6,
    "Calculations / 15 AC:Reaming" =7,
    "Calculations / 16 AC:Washing"= 8,
    "Calculations / 17 AC:Back Reaming"= 8,
}
