/**
 * Rate of penetration
*/
export enum ParametersMinMax3 {
    "--" = 1,
}
