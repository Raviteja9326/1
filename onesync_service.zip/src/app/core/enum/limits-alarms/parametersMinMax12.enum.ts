/**
 * Weight on Flow In
*/
export enum ParametersMinMax12 {
    "Calculations / Tool Flow Margin" = 1,
    "Calculations / Tool Min Flow Margin"= 2,
}
