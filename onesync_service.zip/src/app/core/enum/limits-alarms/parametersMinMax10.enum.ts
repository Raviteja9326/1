/**
 * Weight on Pump1 Speed
*/
export enum ParametersMinMax10 {
    "Well Parameters / Pump1" = 1,
    "Well Parameters / Pump2"= 2,
    "Well Parameters / Pump3" = 3,
    "Well Parameters / Pump4"=4,
    "Well Parameters / Pump5"= 5,
    "Well Parameters / Pump6" = 6,
    "Well Parameters / Pump7"=7,
}
