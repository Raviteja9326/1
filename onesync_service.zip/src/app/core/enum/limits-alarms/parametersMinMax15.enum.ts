/**
 * ECD(PWD)
*/
export enum ParametersMinMax15 {
    "Calculations / FP Weak Point ECD Margin" = 1,
    "Calculations / PP Weak Point ECD Margin"= 2,
    "Well Parameters / ESD (PWD)" = 3,
    
}
