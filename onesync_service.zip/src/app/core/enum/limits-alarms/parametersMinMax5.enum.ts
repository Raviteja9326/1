/**
 * Block Position
*/
export enum ParametersMinMax5 {
    "Calculations / Depth of Cut" = 1,
    "Calculations / Distance to Casing"= 2,
    "Calculations / Off Bottom Distance" = 3,
    "Calculations / Stands from Btm"=4,
    "Well Parameters / Bit Depth"= 5,
    "Well Parameters / Max Well Depth" = 6,
    "Well Parameters / Well Depth"=7,
    "Well Parameters / WS End Depth"= 8,
}
