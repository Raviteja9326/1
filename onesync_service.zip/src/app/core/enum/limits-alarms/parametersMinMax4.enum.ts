/**
 * Top drive Speed
*/
export enum ParametersMinMax4 {
    "Calculations / Bit RPM" = 1,
    "Calculations / Motor RPM"= 2,
    "Calculations / Tool RPM Margin" = 3,
    
}
