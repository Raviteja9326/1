/**
 * DownHole Torque
*/
export enum ParametersMinMax9 {
    "Calculations / Bit TRQ" = 1,
    "Calculations / Latched TRQ CircRot OffB"= 2,
    "Calculations / Max Rig Torque" = 3,
    "Calculations / Max Rig Torque SF"=4,
    "Calculations / Motor TRQ"= 5,
    "Calculations / SlackOff TRQ" = 6,
    "Calculations / Surface TRQ Margin"=7,
    "Calculations / Tool TRQ Margin"= 8,
    "Well Parameters / Rotary Torque"= 9,

}
