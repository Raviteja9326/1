/**
 * This file will hold the details of all the RotatingControlDT.
 (Compliant Tower,Floater,Fixed Platform,Jack-Up(None,Subsea BOP)),
 Floater(surfaceBOP)
*/
export enum HydraulicsMinMaxParameters2 {
    "Well Parameters / Bottom Hole Temperature" = 1,
}
