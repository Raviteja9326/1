/**
 * BP(PWD)
*/
export enum ParametersMinMax14 {
    "Calculations / BAP Differential Pressure" = 1,
    "Calculations / BAP Model"= 2,
    "Calculations / DH DSE" = 3,
    "Calculations / DH MSE Dupriest"=4,
    "Calculations / DH MSE Teale"= 5,
    "Calculations / DiffPress" = 6,
    "Calculations / Drilling Strength"=7,
    "Calculations / DSE"= 8,
    "Calculations / Latched SPP Circ OffB" = 9,
    "Calculations / Latched SPP CircRot OffB"=10,
    "Calculations / Max Pump Press SF"= 11,
    "Calculations / Max Pump Pressure" = 12,
    "Calculations / MSE Dupriest"=13,
    "Calculations / MSE Teale"= 14,
    "Calculations / Pad Differential Pressure" = 15,
    "Calculations / Pressure drop Across Bit"=16,
    "Well Paramters / AP (PWD)"=17,
    "Well Paramters / Stand Pipe Pressure"= 18,
    "Well Paramters / UCS" = 19,
}
