/**
 * This file will hold the details of all the HydraulicsMinMaxParameters1.
 ()
*/
export enum HydraulicsMinMaxParameters3 {
    "Calculations / FP Weak Point ECD Margin" = 1,
    "Calculations / PP Weak Point ECD Margin"= 2,
    "Well Parameters / ECD(PWD)" = 3,
    "Well Parameters / ESD (PWD)"=4,
}
