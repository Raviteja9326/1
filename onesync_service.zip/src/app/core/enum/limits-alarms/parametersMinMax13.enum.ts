/**
 * Max well Depth
*/
export enum ParametersMinMax13 {
    "Calculations / Depth of Cut" = 1,
    "Calculations / Distance to Casing"= 2,
    "Calculations / Off Bottom Distance" = 3,
    "Calculations / Stands from Btm"=4,
    "Well Parameters / Bit Depth"= 5,
    "Well Parameters / Block Position" = 6,
    "Well Parameters / Well Depth"=7,
    "Well Parameters / WS End Depth"= 8,
}
