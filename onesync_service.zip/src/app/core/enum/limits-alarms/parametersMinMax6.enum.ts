/**
 * Hook Load
*/
export enum ParametersMinMax6 {
    "Calculations / Bit Nozzle Jet impact F" = 1,
    "Calculations / Drag"= 2,
    "Calculations / Hel Buck Thresh Corrected" = 3,
    "Calculations / Hookload Model Corrected"=4,
    "Calculations / Hookload Off Bottom"= 5,
    "Calculations / Hookload On Bottom" = 6,
    "Calculations / Latched HKLD Circ OffB"=7,
    "Calculations / Latched HKLD CircRot OffB"= 8,
    "Calculations / Max Hoisting Capacity" = 9,
    "Calculations / Max Hoisting SF"= 10,
    "Calculations / Overpull Margin" = 11,
    "Calculations / Slackoff Margin" = 12,
    "Calculations / SlackOff WOB"= 13,
    "Calculations / SlackOff WOB Rot" = 14,
    "Calculations / SlackOff WOB Slide" = 15,
    "Calculations / Tensile Check"= 16,
    "Well Parameters / Measured String Weight" = 18,
    "Well Parameters / Weight on Bit" = 19,
    "Well Parameters / WS End Weight on Bit" = 20,

}
