/**
 * This file will hold the details of all the Auxilliary.
 */
export enum Auxilliary {
    'None' = '1',
    'Rig Pump'= '2',
    'Weatherford' = '3'
}