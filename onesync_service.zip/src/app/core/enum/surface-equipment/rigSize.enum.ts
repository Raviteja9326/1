/**
 * This file will hold the details of all the RigSize.
 */
export enum RigSize {

    'Custom' = '1',
    'Medium rig, 12000-20000ft (SP - 45ft x 4.0in: Hose - 55ft x 3.0in: Swivel - 5ft x 2.5in: Kelly - 40ft x 3.25in)' = '2',
    'Medium rig, 8000-12000ft (SP - 40ft x 3.5in: Hose - 55ft x 2.5in: Swivel - 5ft x 2.5in: Kelly - 40ft x 3.25in)' = '3',
    'Rig over 20000ft (SP - 100ft x 5.0in: Hose - 85ft x 3.5in: Swivel - 22ft x 3.5in)' = '4',
    'Rig over 20000ft (SP - 45ft x 4.0in: Hose - 55ft x 3.0in: Swivel - 6ft x 3.0in: Kelly - 40ft x 4.0in)' = '5',
    'Small rig,less than 8000ft (SP - 40ft x 3.0in: Hose - 45ft x 2.0in: Swivel - 4ft x 2.0in: Kelly - 40ft x 2.25in)' = '6',
    'Unknown'='7'
    
}