/**
 * This file will hold the details of all the BlowOutPreventer.
 */
export enum BlowOutPreventer {
    "None"=1,
    "Subsea BOP" =2, 
    "Surface BOP"=3,
}