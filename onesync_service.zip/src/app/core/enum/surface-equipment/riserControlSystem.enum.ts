/**
 * This file will hold the details of all the RiserControlSystem.
 */
export enum RiserControlSystem {
    'None'='1',
    'Weatherford RCS' ='2', 
}