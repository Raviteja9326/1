/**
 * This file will hold the details of all the RigType.
 */
export enum RigType {
    "Compliant Tower" = 1,
    "Drill Ship" = 2,
    "Fixed Platform" = 3,
    "Floater"=4,
    "Jack-Up"=5,
    "Land"=6,
}