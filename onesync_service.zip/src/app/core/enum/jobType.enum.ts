/**
 * This file will hold the details of all the jobtypes.
 */

export enum JobType {

    "Monitoring and Early Detection" = '1',
    "Constant Bottom Hole Pressure" = '2',
    "Mud Cap" = '3',
    "Dual Gradient" = '4',
    "Cementing" = '5',
    "Wellbore Strengthening" = '6',
    "Casing Run" = '7',
    "Coring" = '8',
    "Logging" = '9',
    "Surface Well Testing" = '10'
}