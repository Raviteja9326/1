/**
 * This file will hold the details of all the Mill types for custom tools.
 */

export enum MillType {
    "Bottom Mill" = '1',
    "Packer Mill" = '2',
    "Pilot Mill" = '3',
    "Section Mill" = '4',
    "String Mill" = '5',
}