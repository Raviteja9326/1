/**
 * This file will hold the details of all the Fishing types for custom tools.
 */

export enum FishingType {
    "Basket" = '1',
    "Casing Repair" = '2',
    "Clean Out" = '3',
    "Cutter" = '4',
    "External Catch" = '5',
    "Internal Catch" = '6',
    "Rope Spear" = '7',
    "Washover" = '8'
}