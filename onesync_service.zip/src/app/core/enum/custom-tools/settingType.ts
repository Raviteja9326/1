/**
 * This file will hold the details of all the Packer setting types for custom tools.
 */

export enum SettingType {
    "Hydraulic" = '1',
    "Mechanical" = '2',
}