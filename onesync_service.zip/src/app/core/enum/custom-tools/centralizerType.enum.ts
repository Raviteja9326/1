/**
 * This file will hold the details of all the Centralizer type for custom tools.
 */

export enum CentralizerType {
    "Bow Spring" = '1',
    "Roller" = '2',
    "Unknown" = '3'
}