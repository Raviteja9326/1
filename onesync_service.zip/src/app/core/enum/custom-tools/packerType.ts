/**
 * This file will hold the details of all the Packer types for custom tools.
 */

export enum PackerType {
    "Isolation" = '1',
    "Production" = '2',
}