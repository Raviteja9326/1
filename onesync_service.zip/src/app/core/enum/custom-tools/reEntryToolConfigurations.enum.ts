/**
 * This file will hold the details of all the Tool configurations for custom tools.
 */

export const ReEntryToolConfiguration = {
    1:[
       
    ],
    2:[
        
    ],
    3:[
        {label:'Lead Mill', value:1},
        {label:'Flex Mandrel', value:2},
        {label:'Flex Mill', value:3},
        {label:'Secondary Mill', value:4},
        {label:'Steering Mill', value:5},
        {label:'Window Mill', value:6},
    ],
    4:
    [
        {label:'Mill Through Whipstock', value:1},
        {label:'QuickCut - MultiCatch Hyd', value:2},
        {label:'QuickCut - MultiCatch Mech', value:3},
        {label:'QuickCut - PHS', value:4},
        {label:'QuickCut - RHS', value:5},
        {label:'SA QuickCut - MultiCatch Hyd', value:6},
        {label:'SA QuickCut - MultiCatch Mech', value:7},
        {label:'SA QuickCut - PHS', value:8},
        {label:'SA QuickCut - RHS', value:9},
        {label:'Starbust', value:10},
    ]
   
   
}