/**
 * This file will hold the details of all the Post types for custom tools.
 */

export enum PostType {
    "Compression Element" = '1',
    "Inflate" = '2',
    "SwagSet" = '3',
}