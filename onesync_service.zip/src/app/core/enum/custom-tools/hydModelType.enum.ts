/**
 * This file will hold the details of all the hyd model type for custom tools.
 */

export enum HydModelType {
    "Linear" = '1',
    "Power Law ρ².b.Qᶜ" = '2',
}