/**
 * This file will hold the details of all the weight options for custom tools.
 */

export enum SpecialToolStateOption {

    'Annulus Only'='0',
    'Pipe and Annulus'='1',
    'Pipe Only'='2',
 
 }