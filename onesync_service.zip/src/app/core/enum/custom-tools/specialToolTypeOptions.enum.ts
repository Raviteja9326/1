/**
 * This file will hold the details of all the weight options for custom tools.
 */

export enum SpecialToolTypeOption {

    'Circulating'='0',
 
 }