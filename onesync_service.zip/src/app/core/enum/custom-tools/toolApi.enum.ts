/**
 * This file will hold the details of all the API types for custom tools.
 */

export enum ToolAPIType {
    'API'='1',
    'Non API' = '0'
 }