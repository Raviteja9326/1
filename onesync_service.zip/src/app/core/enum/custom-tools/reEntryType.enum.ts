/**
 * This file will hold the details of all the ReEntry types for custom tools.
 */

export enum ReEntryType {
    "Box Tap" = '1',
    "Hook" = '2',
    "Mill" = '3',
    "Whipstock" = '4',
}