/**
 * This file will hold the details of all the Tool configurations for custom tools.
 */

export const MillToolConfiguration = {
    1:[
        {label:'Junk Mill', value:1},
        {label:'Taper Mill', value:2},
    ],
    2:[
        
    ],
    3:[
        
    ],
    4:
    [
        
    ],
    5:[
        {label:'Standard String Mill', value:1},
        {label:'Watermelon Mill', value:2},
    ]
   
   
}