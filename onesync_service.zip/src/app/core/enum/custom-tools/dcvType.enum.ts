/**
 * This file will hold the details of all the DCV types for custom tools.
 */

export enum DCVType {
    "FLV (Ball Valve)" = '1',
    "FLV (Flapper Valve)" = '2',
    "ICV" = '3',
    "Safety Valve" = '4',
    "Sliding Sleeve" = '5'
}