/**
 * This file will hold the details of all the Connection configuration for custom tools.
 */

export enum ConnectionConfiguration {
    "Box" = '5',
    "Box-Box" = '1',
    "Box-Pin" = '3',
    "Pin" = '6',
    "Pin-Box" = '4',
    "Pin-Pin" = '2'
   
}