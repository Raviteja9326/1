/**
 * This file will hold the details of all the Fishing types for custom tools.
 */

export enum JarType {
    "Other Jar" = '1',
    "Impact Hammer Slinger" = '2'
}