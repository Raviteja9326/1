/**
 * This file will hold the details of all the range types for custom tools.
 */

export enum RangeType {

   'Range 1'='1',
   'Range 2' = '2',
   'Range 3' = '3',

}