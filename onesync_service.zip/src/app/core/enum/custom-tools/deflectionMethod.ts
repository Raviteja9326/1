/**
 * This file will hold the details of all the Deflection Method for RSS.
 */

export enum DeflectionMethod {
    "Point Bit" = '1',
    "Push Bit" = '2',
}