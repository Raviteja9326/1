/**
 * This file will hold the details of all the TG Flow Range types for custom tools.
 */

export enum TGFLowRangeType {

    '325.00 - 500.00 gal/min'='1',
    'Flow 2' = '2',
    'Flow 3' = '3',
 
 }