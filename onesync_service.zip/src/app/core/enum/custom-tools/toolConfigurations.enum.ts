/**
 * This file will hold the details of all the Tool configurations for custom tools.
 */

export const ToolConfiguration = {
    1:[
        {label:'Globe', value:1},
        {label:'RCJB', value:2},
        {label:'Venturi', value:3},
        {label:'Boot', value:4},
        {label:'Kangaroo', value:5}
    ],
    2:[
        {label:'ExternalCasingPatch', value:1},
        {label:'CasingSwage', value:2}
    ],
    3:[
        {label:'CasingScraper', value:1},
        {label:'StringMagnet', value:2},
        {label:'CirculationSub', value:3}
    ],
    4:[
        {label:'Internal', value:1},
        {label:'External', value:2}
    ],
    5:[
       
    ],
    6:[
     
    ],
    7:[
    ],
    8:[
        {label:'DriveSub', value:1},
        {label:'Washpipe', value:2},
        {label:'Shoe', value:3}
    ]
}