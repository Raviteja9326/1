/**
 * This file will hold the details of all the weight options for custom tools.
 */

export enum ToolWeightOption {

    'Calculated'='0',
    'User Defined Adjusted Weight' = '1',
    'User Defined Mass' = '2',
 
 }