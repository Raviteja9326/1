/**
 * This file will hold the details of all the Lobe configuration for custom tools.
 */

export enum LobeConfiguration {
 "1:2"="1",
 "2:3"="2",
 "3:4"="3",
 "4:5"="4",
 "5:6"="5",
 "6:7"="6",
 "7:8"="7",
 "8:9"="8",
 "9:10"="9",
 "25:26"="10",
}