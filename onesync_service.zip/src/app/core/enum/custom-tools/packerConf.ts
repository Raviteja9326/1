/**
 * This file will hold the details of all the Packer Tool configurations for custom tools.
 */

export const PackerToolConfiguration = {
    1:[
        {label:'Annular Casing', value:1},
        {label:'Swellable', value:2},
    ],
    2:[
        {label:'Seal Bore', value:1},
        {label:'Tubing Mounted', value:2}
    ]
}