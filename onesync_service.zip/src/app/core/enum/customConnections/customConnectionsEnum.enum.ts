export enum CustomConnectionsEnum {
    "Top" = 1,
    "TopAndBottom" = 2,
}