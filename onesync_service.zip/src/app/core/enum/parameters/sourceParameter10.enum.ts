export enum sourceParameter10{

    '--No Mappings--' = 1,
    
  }