export enum sourceParameter3{

    'FP Weak point ECD Margin' = 1,
    'PP Weak Point ECD Margin' = 2,
    
   }