export enum sourceParameter7 {

    'Tool Flow Margin' = 1,
    'Tool Min Flow Margin' = 2,
 
}