export enum sourceParameter1 {

    'BAP Differential Pressure' = 1,
    'BAP Model' = 2,
    'DH DSE' = 3,
    'DH MSE Dupriest' = 4,
    'DH MSE Teale'=5,
    'DiffPress'=6,
    'Drilling Strength'=7,
    'DSE'=8,
    'Latched SPP Circ OffB'=9,
    'Latched SPP CircRot OffB'=10,
    'Max Pump Press SF'=11,
    'Max Pump Pressure'=12,
    'Mse Dupriest'=13,
    'MSE Teale'=14,
    'Pad Differential Pressure'=15,
    'Pressure drop Across Bit'=16,
  }