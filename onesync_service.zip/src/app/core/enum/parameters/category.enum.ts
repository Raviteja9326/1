export enum categoryType {

    'No Mappings' = '1',
    'Calculations' = '2',
    'Wits Data' = '3'
  
  }