export enum sourceParameter4 {

    'Bit TRQ' = 1,
    'Latched TRQ CircRot OffB' = 2,
    'Max Rig Torque' = 3,
    'Max Rig Torque SF' = 4,
    'Motor TRQ'=5,
    'Slackoff TRQ'=6,
    'Tool TRQ Margin'=7,
  
   }