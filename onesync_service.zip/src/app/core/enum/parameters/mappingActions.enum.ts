export enum mappingAction {

    'As Is' = 1,
    'Default' = 2,
    'Previous' = 3,
    'Override' = 4,
  
  }