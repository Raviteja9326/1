export enum sourceParameter6 {

    'Max Rig Torque' = 1,
    'Max Rig Torque SF' = 2,
    'Motor TRQ' =3
}