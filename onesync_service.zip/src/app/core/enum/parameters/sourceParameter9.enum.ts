export enum sourceParameter9{

    'Motor RPM' = 1,
    
  }