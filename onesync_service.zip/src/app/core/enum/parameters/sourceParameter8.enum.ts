export enum sourceParameter8 {

    'Bit Nozzle Jet Impact F' = 1,
    'CF Limit' = 2,
    'Max Hoisting Capacity' = 3,
    'Max Hoisting SF' = 4,
  
  }