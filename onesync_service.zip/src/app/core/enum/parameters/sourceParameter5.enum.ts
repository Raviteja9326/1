export enum sourceParameter5{

    'Depth of Cut' = 1,
   
   }