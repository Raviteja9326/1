export enum sourceParameter2 {

    'Bit Nozzle Jet Impact F' = 1,
    'CF Limit' = 2,
    'Drag' = 3,
    'Hookload Off Bottom' = 4,
    'Hookload on Bottom'=5,
    'Latched HKLD Circ OffB'=6,
    'Latched HKLD CircRot OffB'=7,
    'Max Hoisting Capacity'=8,
    'Max Hoisting SF'=9,
    'SlackOff WOB'=10,
    'SlackOff WOB Rot'=11,
    'SlackOff WOB Slide'=12,
   }