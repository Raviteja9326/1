
// -------------- Torque & Drag --------------
export enum CommonOperations {
    "RoffB" = "1",
    "Running In" = "2",
    "Pulling Out" = "4",
    "Drilling Rotary" = "8",
    "Drilling Sliding" = "16",
    "Reaming" = "32",
    "Back Reaming" = "64"
}

export enum AdditionalOperations {
    "Pick Up" = "128",
    "Slack Off" = "256",
    "Underreaming" = "512",
    "Cutting" = "1024",
    "Custom Up" = "2048",
    "Custom Down" = "4096",
    "Custom Stationary" = "8192"
}

export enum Solvers {
    "Simplified Soft String" = "1",
    "Soft String" = "2",
    "Semi Stiff String" = "3",
    "Stiff String" = "4"
}

// -------------- Snapshot --------------
export enum Operations {
    "Circulation" = "1",
    "Drilling" = "2",
    "Reverse Circulations" = "3",
    "Injection Annuluas" = "4",
    "Production Annuluas" = "5"
}

export enum HoleCleaningModels {
    "Basic" = "1",
    "Advanced" = "2"
}

export enum CuttingSizes {
    "Custom" = "1",
    "Large" = "2",
    "Medium" = "3",
    "Medium Large" = "4",
    "Medium Small" = "5",
    "Small" = "6",
}

// -------------- Parametric --------------
export enum ParametricOperations {
    "Circulation" = "1",
    "Drilling" = "2",
    "Reverse Circulations" = "3",
}

export enum IndependentParameters {
    "Flow Rate" = "1",
    "ROP" = "2",
    "Surface Back Pressure" = "3",
    "TDS" = "4",
    "Work String Depth" = "5"
}

export enum DependentParameters {
    "Bed Height" = "1",
    "Bit HHP" = "2",
    "Bit Press." = "3",
    "Cuttings" = "4",
    "ECD+Cuttings DOI" = "5",
    "ECD+Cuttings Shoe" = "6",
    "ECD+Cuttings TD" = "7",
    "Pump HHP" = "8",
    "SPP" = "9",
    "WS Press." = "10",
}

export enum CategoryAxes {
    "Flow Rate" = "1",
    "ROP" = "2",
    "Surface Back Pressure" = "3",
    "TDS" = "4",
}