/**
 * This file will hold the details of all the Energy.
 */
export enum Energy {
    'J' = 1,
}