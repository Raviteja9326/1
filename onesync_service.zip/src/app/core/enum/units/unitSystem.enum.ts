/**
 * This file will hold the details of all the MagneticFlux.
 */
export enum UnitSystem {
    'Imperial'=1,
    'Metric'=2,
    'Custom'=3,
}