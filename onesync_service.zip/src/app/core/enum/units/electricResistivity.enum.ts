/**
 * This file will hold the details of all the ElectricResistivity.
 */
export enum ElectricResistivity {
    'Ω ft' = 1,
    'Ω m' = 2,
    'Ω cm' = 3,
    'Ω in' = 4,
    'µΩ cm' = 5,
    'µΩ in' = 6,
}
