/**
 * This file will hold the details of all the Temperature.
 */
export enum Temperature {
    '°F' = 1,
    '°C' = 2,
    '°K' = 3,
    '°R' = 4,
}