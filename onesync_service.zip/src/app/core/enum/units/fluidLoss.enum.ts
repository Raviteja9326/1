/**
 * This file will hold the details of all the FluidLoss.
 */
export enum FluidLoss {
    'cc/30min' =1,
    'ml/30min'=2,
}