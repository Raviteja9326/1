/**
 * This file will hold the details of all the ElectricPotential.
 */
export enum ElectricPotential {
    'V'=1,
    'mV'=2,
}