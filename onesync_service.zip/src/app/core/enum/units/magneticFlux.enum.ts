/**
 * This file will hold the details of all the MagneticFlux.
 */
export enum MagneticFlux {
    'µWb' = 1,
    'mWb' = 2,
    'Wb' = 3,
    'Mw' = 4,
    'nWb' = 5,
}