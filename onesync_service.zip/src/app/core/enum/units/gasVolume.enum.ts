/**
 * This file will hold the details of all the GasVolume.
 */
export enum GasVolume {
    
    "in³" = 1,
    "m³" = 2,
    "ft³" = 3,
    "MCF" = 4,
    "MMCF" = 5,
    "MCM" = 6,
    "cm³" = 7,
    "mm³" = 8,
    "MMCM" = 9,
}