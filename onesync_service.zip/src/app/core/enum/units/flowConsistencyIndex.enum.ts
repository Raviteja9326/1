/**
 * This file will hold the details of all the FlowConsistencyIndex.
 */
export enum FlowConsistencyIndex {
    'lbfsⁿ/(100 ft²)' = 1,
    'Pa-secⁿ' = 2,
}