/**
 * This file will hold the details of all the ResistivityPerLength.
 */
export enum ResistivityPerLength {
    'ohm/m' = 1,
    'uohm/ft' = 2,
    'uohm/m' = 3,
}