/**
 * This file will hold the details of all the ElectricResistance.
 */
export enum ElectricResistance {
    'Ω' = 1,
    'kΩ' = 2,
    'MΩ' = 3,
    'mΩ' = 4,
}