/**
 * This file will hold the details of all the MagneticFlux.
 */
export enum MassFlow {

    "lb/min" = 1,
    "kg/min" = 2,
    "lb/day" = 3,
    "lb/sec" = 4,
    "t/sec" = 5,
    "t/min" = 6,
    "t/hr" = 7,
    "t/day" = 8,
    "lt/sec" = 9,
    "lt/min" = 10,
    "lt/hr" = 11,
    "lt/day" = 12,
    "oz/sec" = 13,
    "oz/min" = 14,
    "oz/hr" = 15,
    "oz/day" = 16,
    "g/sec" = 17,
    "g/min" = 18,
    "g/hr" = 19,
    "g/day" = 20,
    "kg/sec" = 21,
    "lb/hr" = 22,
    "kg/hr" = 23,
    "kg/day" = 24,
}