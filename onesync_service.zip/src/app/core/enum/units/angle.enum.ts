/**
 * This file will hold the details of all the angle.
 */
export enum Angle {
    '°' = 1,
    'rad' = 2,
    'min' = 3,
    'sec' = 4,
    'rev' = 5,
}