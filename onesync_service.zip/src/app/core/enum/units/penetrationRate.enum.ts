/**
 * This file will hold the details of all the MagneticFlux.
 */
export enum PenetrationRate {
    'ft/hr' = 1,
    'm/hr' = 2,
    'ft/s' = 3,
    'm/s' = 4,
    'ft/min' = 5,
    'm/min' = 6,
}