/**
 * This file will hold the details of all the GasOilRatio.
 */
export enum GasOilRatio {
    'scf/stb' = 1,
}