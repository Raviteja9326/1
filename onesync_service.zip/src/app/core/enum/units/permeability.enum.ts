/**
 * This file will hold the details of all the Permeability.
 */
export enum Permeability {
    'mD' = 1,
    'm²' = 2,
    'Darcy' = 3,
}