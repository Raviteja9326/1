/**
 * This file will hold the details of all the Power.
 */
export enum Power {
    'hp' = 1,
    'kW' = 2,
    'W' = 3,
}