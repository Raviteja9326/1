/**
 * This file will hold the details of all the DifferentialPressure.
 */
export enum DifferentialPressure {
    'inH₂O' = 1,
    'mmH₂O' = 2,
    'psi' = 3,
    'bar' = 4,
    'Pa' = 5,
    'Mpa' = 6,
    'ksi' = 7,
    'atm' = 8,
    'inHg' = 9,
    'mmHg' = 10,
    'kPa' = 11,
    'Torr' = 12,
    'mbar' = 13,
    'kg/cm²' = 14,
    'lb/100 ft²' = 15,
    'Gpa' = 16
}