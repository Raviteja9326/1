/**
 * This file will hold the details of all the VelocityFluid.
 */
export enum VelocityFluid {
    "ft/min" = 1,
    "m/min" = 2,
    "in/s" = 3,
    "mm/s" = 4,
    "cm/s" = 5,
    "ft/s" = 6,
    "m/s" = 7,
    "ft/hr" = 8,
    "m/hr" = 9,

   
}