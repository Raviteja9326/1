/**
 * This file will hold the details of all the ShortLength.
 */
export enum ShortLength {
    
    "in" = 1,
    "mm" = 2,
    "cm" = 3,
    "dm" = 4,
    "m" = 5,
    "x 1/32" = 6,
    "ft" = 7,
}