/**
 * This file will hold the details of all the GammaRay.
 */
export enum GammaRay {
    'gAPI' = 1,
}