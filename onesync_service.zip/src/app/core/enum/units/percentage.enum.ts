/**
 * This file will hold the details of all the MagneticFlux.
 */
export enum Percentage {
    '%' = 1,
    '0-1' = 2,
    'ppm' = 3,
    'per-mil' = 4,
    // "Euc" = 2,
    // "ppm" = 3,
    // "mEuc" = 4,
}