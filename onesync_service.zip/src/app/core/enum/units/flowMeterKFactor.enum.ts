/**
 * This file will hold the details of all the FlowMeterKFactor.
 */
export enum FlowMeterKFactor {
    'pulses/USgal' = 1,
    'pulses/m³' = 2,
    'pulses/bbl' = 3,
    'pulses/l' = 4,
    'pulses/ft³' = 5,
    
}