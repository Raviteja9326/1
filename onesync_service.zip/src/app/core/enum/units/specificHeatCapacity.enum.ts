/**
 * This file will hold the details of all the SpecificHeatCapacity.
 */
export enum SpecificHeatCapacity {
    "Btu/(lb-°F)" = 1,
    "J/(kg-°C)" = 2,
    "J/(kg-°K)" = 3,
    "kJ/(kg-°K)" = 4,
    "kJ/(kg-°C)" = 5,
    "kcal/(kg-°K)" = 6,
    "kcal/(kg-°C)" = 7,

    
}