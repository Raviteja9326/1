/**
 * This file will hold the details of all the ThermalGradient.
 */
export enum ThermalGradient {
    '°F/ft' = 1,
    '°C/m' = 2,
    '°K/m' = 3,
    '°F/100 ft' = 4,
    '°C/30 m' = 5,
}