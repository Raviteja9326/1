/**
 * This file will hold the details of all the Mass.
 */
export enum Mass {
    
    "lbm" = 1,
    "kg" = 2,
    "T" = 3,
    "oz" = 4,
    "t" = 5,
    "lt" = 6,
    "g" = 7,
    "Klbs" = 8,
}