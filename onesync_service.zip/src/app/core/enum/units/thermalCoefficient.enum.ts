/**
 * This file will hold the details of all the ThermalCoefficient.
 */
export enum ThermalCoefficient {
    '/°F' = 1,
    '/°C' = 2,
    '/°K' = 3,
    '/°R' = 4,
    'μ/°C' = 5,
}