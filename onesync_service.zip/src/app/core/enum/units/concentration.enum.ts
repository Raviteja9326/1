/**
 * This file will hold the details of all the Concentration.
 */
export enum Concentration {
    'ppm' = 1,
    'ppdk'= 2,
    'ppk' = 3
}