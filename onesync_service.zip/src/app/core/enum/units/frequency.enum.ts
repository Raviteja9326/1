/**
 * This file will hold the details of all the Frequency.
 */
export enum Frequency {
    'Hz' = 1,
}