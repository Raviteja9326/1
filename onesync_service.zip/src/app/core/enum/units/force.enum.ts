/**
 * This file will hold the details of all the Force.
 */
export enum Force {
    'lbf' = 1,
    'N' = 2,
    'kN' = 3,
    'dN' = 4,
    'ozf' = 5,
    'tDN' = 6,
    'kip' = 7,
    'tonf' = 8,
    'tf' = 9,
    'dyn' = 10
}