/**
 * This file will hold the details of all the MagneticField.
 */
export enum MagneticField {
    'nT' = 1,
    'μT' = 2,
    'T'=3
}