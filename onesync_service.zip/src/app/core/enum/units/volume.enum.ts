/**
 * This file will hold the details of all the Volume.
 */
export enum Volume {
    
    "USgal" = 1,
    "l" = 2,
    "bbl" = 3,
    "m³" = 4,
    "mm³" = 5,
    "cm³" = 6,
    "dm³" = 7,
    "in³" = 8,
    "ft³" = 9,
    "MCF" = 10,
    "MMCF" = 11,
    "MCM" = 12,
    "MMCM" = 13,
}