/**
 * This file will hold the details of all the Freight.
 */
export enum Freight {
    'TonMile' = 1,
}