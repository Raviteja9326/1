/**
 * This file will hold the details of all the conductivity.
 */
export enum Conductivity {
    'S/m'=1,
    'mho/m'=2,
    'mmho/m'=3,
    'mS/m'=4,
}