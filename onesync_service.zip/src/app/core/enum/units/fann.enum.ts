/**
 * This file will hold the details of all the Fann.
 */
export enum Fann {
    '°Fann' = 1,
}