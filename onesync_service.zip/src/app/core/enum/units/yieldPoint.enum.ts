/**
 * This file will hold the details of all the YieldPoint.
 */
export enum YieldPoint {
    'lbf/100ft²' = 1,
    'Pa' = 2,
}