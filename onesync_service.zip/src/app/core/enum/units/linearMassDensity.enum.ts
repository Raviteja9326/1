/**
 * This file will hold the details of all the LinearMassDensity.
 */
export enum LinearMassDensity {
    'lb/ft' = 1,
    'kg/m' = 2,
}