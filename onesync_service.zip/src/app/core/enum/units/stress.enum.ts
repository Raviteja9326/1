/**
 * This file will hold the details of all the Stress.
 */
export enum Stress {
    'ksi' = 1,
    'MPa' = 2,
    'Pa' = 3,
    'psi' = 4,
}