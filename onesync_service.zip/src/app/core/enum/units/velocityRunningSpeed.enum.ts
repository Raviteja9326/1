/**
 * This file will hold the details of all the VelocityRunningSpeed.
 */
export enum VelocityRunningSpeed {

    "ft/s" = 1,
    "m/s" = 2,
    "ft/min" = 3,
    "m/min" = 4,
    "ft/hr" = 5,
    "m/hr" = 6,
    "km/min" = 7,
    "km/hr" = 8,
    "km/sec" = 9,
    "kft/hr" = 10,
    "mi/min" = 11,
    "mi/hr" = 12,
    "mi/sec" = 13,
}