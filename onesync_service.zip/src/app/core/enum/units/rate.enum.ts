/**
 * This file will hold the details of all the Rate.
 */
export enum Rate {
    '/min' = 1,
    '/hr' = 2,
    '/day' = 3,
    '/sec' = 4,
    '/msec' = 5,
}