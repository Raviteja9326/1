/**
 * This file will hold the details of all the Capacity.
 */
export enum Capacity {
    'bbl/ft' = 1,
    'L/m'=2,
    'gal/ft' = 3,
}