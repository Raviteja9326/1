/**
 * This file will hold the details of all the Stiffness.
 */
export enum Stiffness {
    'lbf*in²' = 1,
    'N*m²' = 2,
}