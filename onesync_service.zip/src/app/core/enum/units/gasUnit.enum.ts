/**
 * This file will hold the details of all the GasUnit.
 */
export enum GasUnit {
    '%' =1,
    'ppm'=2,
    'gu50'=3,
    'gu100'=4,
}