/**
 * This file will hold the details of all the InverseCapacity.
 */
export enum InverseCapacity {
    'ft/bbl' = 1,
    'm/L'=2,
}