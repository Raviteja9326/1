/**
 * This file will hold the details of all the Pressure.
 */
export enum Pressure {
    'psi' = 1,
    'kPa' = 2,
    'bar' = 3,
    'Pa' = 4,
    'MPa' = 5,
    'ksi' = 6,
    'atm' = 7,
    'inHg' = 8,
    'mmHg' = 9,
    'inH₂O' = 10,
    'mmH₂O' = 11,
    'Torr' = 12,
    'mbar' = 13,
    'kg/cm²' = 14,
    'lbf/100ft²' = 15,
    'GPa' = 16,
}