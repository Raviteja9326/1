/**
 * This file will hold the details of all the UnitlessPrecision.
 */
export enum UnitlessPrecision {
    "--" = 1,
}