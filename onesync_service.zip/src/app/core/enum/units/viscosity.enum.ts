/**
 * This file will hold the details of all the Viscosity.
 */
export enum Viscosity {

    "cP" = 1,
    "Pa-sec" = 2,
    "P" = 3,
    "lb/ft-s" = 4,
    "lbf-s/in²" = 5,
    "lbf-s/ft²" = 6,
}