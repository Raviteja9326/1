/**
 * This file will hold the details of all the Density.
 */
export enum Density {
    'ppg' = 1,
    'kg/m³' = 2,
    'sg' = 3,
    'kg/L' = 4,
    'g/cm³' = 5,
    'lb/ft³' = 6,
    'lb/bbl' = 7,
    'mg/L' = 8,
    'pptf' = 9,
    'kpa/m' = 10,

}