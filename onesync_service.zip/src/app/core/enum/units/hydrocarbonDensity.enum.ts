/**
 * This file will hold the details of all the HydrocarbonDensity.
 */
export enum HydrocarbonDensity {
    'deg API' = 1,
    'sg' = 2,
    'ppg' = 3,
}