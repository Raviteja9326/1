/**
 * This file will hold the details of all the area.
 */
export enum Area {
    'ft²'=1,
    'm²' =2, 
    'cm²'=3,
    'mm²'=4,
    'in²'=5,
    'yd²'=6,
}