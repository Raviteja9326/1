/**
 * This file will hold the details of all the Torque.
 */
export enum Torque {
  
    "lbf-ft" = 1,
    "N-m" = 2,
    "kN-M" = 3,
    "pdl-ft" = 4,
    "lbf-in" = 5,
    "ozf-ft" = 6,
    "kp-m" = 7,
    "gf-cm" = 8,
    "kipf-ft" = 9,
}