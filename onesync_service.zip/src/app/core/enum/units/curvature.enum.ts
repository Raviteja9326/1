/**
 * This file will hold the details of all the curvature.
 */
export enum Curvature { 
    '1/ft'=1,
    '1/m' =2,
}