/**
 * This file will hold the details of all the Time.
 */
export enum Time {
    'sec' = 1,
    'min' = 2,
    'hr' = 3,
    'day' = 4,
    'msec' = 5,
    // "cs" = 6,
}