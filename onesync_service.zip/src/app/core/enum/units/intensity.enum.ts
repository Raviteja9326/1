/**
 * This file will hold the details of all the Intensity.
 */
export enum Intensity {
    // "hp/in²" = 1,
    'HSI' = 1,
    'HIS' =2,
}