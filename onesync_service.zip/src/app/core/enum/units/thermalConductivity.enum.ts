/**
 * This file will hold the details of all the ThermalConductivity.
 */
export enum ThermalConductivity {
    '(Btu/hr)/(ft-°F)' = 1,
    'W/(m-°C)' = 2,
    'W/(m-°K)' = 3,
}