/**
 * This file will hold the details of all the NozzleSize.
 */
export enum NozzleSize {
    'x 1/32"' = 1,
    "mm" = 2,
     
}