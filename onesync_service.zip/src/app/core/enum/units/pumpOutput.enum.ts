/**
 * This file will hold the details of all the PumpOutput.
 */
export enum PumpOutput {
    'gal/stk' = 1,
    'bbl/stk' = 2,
}