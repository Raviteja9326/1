/**
 * This file will hold the details of all the DLS.
 */
export enum DLS {
    '°/100ft' = 1,
    '°/30m' = 2,
    '°/30ft' = 3,
    '°/ft' = 4,
    '°/m' = 5,
    'c/m' = 6,
    'c/ft' = 7,
    '°/10m' = 8,
}