/**
 * This file will hold the details of all the PumpSpeed.
 */
export enum PumpSpeed {
    'spm' = 1,
    'sps' = 2,
}