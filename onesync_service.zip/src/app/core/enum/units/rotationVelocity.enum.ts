/**
 * This file will hold the details of all the RotationVelocity.
 */
export enum RotationVelocity {
    'rpm' = 1,
    'r/s' = 2,
    'rad/s' = 3,  
}