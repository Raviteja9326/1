/**
 * This file will hold the details of all the acceleration.
 */
export enum Acceleration {
    'ft/s²' = 1,
    'm/s²' = 2,
    'in/s²' = 3
}