/**
 * This file will hold the details of all the ElectricCurrent.
 */
export enum ElectricCurrent {
    'mA'=1,
    'A' =2,
    'nA'=3,
}