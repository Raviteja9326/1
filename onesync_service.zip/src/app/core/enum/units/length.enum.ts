/**
 * This file will hold the details of all the Length.
 */
export enum Length {

    "ft" = 1,
    "m" = 2,
    "cm" = 3,
    "dm" = 4,
    "mm" = 5,
    "in" = 6,
    "mi" = 7,
    "nmi" = 8,
    "km" = 9,
}