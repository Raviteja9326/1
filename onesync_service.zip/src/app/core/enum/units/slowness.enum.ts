/**
 * This file will hold the details of all the Slowness.
 */
export enum Slowness {
    'µs/ft' = 1,
    'µs/m' = 2,
    's/km' = 3,
    's/mi' = 4,
}