/**
 * This file will hold the details of all the StressCoeff.
 */
export enum StressCoeff {
    'ft/1000ft/klbs' = 1,
    'm/km/5kN' = 2,
}


