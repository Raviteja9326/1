/**
 * This file will hold the details of all the PressureGradient.
 */
export enum PressureGradient {
    'lbf/gal' = 1,
    'Pa/m' = 2,
    'bar/m' = 3,
    'psi/ft' = 4,
    'kPa/m' = 5,
}