/**
 * This file will hold the details of all the Manifold for Choke A.
 */
export enum ChokeA {
        'CORTEC CX3 3"'= '0',
        'CORTEC CX4 4"'= '1',
        'CORTEC CX6 4"'= '2',
        'CORTEC CX6 6"'= '3',
        'EXPRO SCB2 3"'= '4',
        'EXPRO SCB4 3"'= '5',
        'SRI SCM5 4"'= '6'
}
