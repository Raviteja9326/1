/**
 * This file will hold the details of all the Manifold for choke B.
 */
export enum PumpSource {
    'External'= 'External',
    'Half Stroke Counter'= '1',
    'Inverse Half Stroke Counter'= '5',
    'RPM'= '8',
    'Spare 1'= '2',
    'Spare 2'= '3',
    'Spare 3'= '6',
    'Spare 4'= '7',
    'Stroke Counter'= '0',
    // 'WITS' = '4',
}
