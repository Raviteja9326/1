/**
 * This file will hold the details of all the Manifold for choke B.
 */
export enum RubberType {
    'HF Poly'= '2',
    'Natural'= '0',
    'Polyurethane'= '1',
}
