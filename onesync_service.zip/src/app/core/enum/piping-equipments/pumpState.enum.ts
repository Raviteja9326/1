/**
 * This file will hold the details of all the Manifold for choke B.
 */
export enum PumpState {
    'Aux'= '2',
    'Boost'= '3',
    'Disable'= '0',
    'Main'= '1'
}
