/**
 * This file will hold the details of all the Manifold for choke B.
 */
export enum RCDType {
    'Above Tensioner Ring'= '1',
    'Below Tensioner Ring'= '0',
}
