/**
 * This file will hold the details of all the Manifold for choke B.
 */
export enum FlowMeter {
    'CMF400(4")'= '0',
    'HC2(6")'= '1',
    'HC3(8")'= '2',
    'HC4(10")'= '3',
    'None'= '4'
}
