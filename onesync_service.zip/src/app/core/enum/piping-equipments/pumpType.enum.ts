/**
 * This file will hold the details of all the Manifold for choke B.
 */
export enum PumpType {
    'Quadruplex'= '1',
    'Quintuplex'= '2',
    'Triplex'= '0',
}
