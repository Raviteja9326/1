/**
 * This file will hold the details of Acceleratin Time.
 */
export enum AccelerationTime {
    'Very Aggressive (5 secs)' = '5',
    'Aggressive (10 secs)' = '10',
    'Moderate (15 secs)' = '15',
    'Slow (20 secs)' = '20',
    'Very Slow (30 secs)' = '30',
    'Custom' = '0',
}  //end of Acceleratin Time enum

