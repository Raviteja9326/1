/**
 * This file will hold the details of Analysis Type.
 */
export enum Analysis {
    'Running Speed Optimization' = '0',
    'Fixed Running Speed' = '1',
}  //end of Analysis Type enum


