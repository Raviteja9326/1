/**
 * This file will hold the details of PipeEnd.
 */
export enum PipeEnd {
    'Closed Ended' = '0',
    'Open Ended' = '1',
}  //end of PipeEnd enum


