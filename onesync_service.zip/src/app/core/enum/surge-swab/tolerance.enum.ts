/**
 * This file will hold the details of Tolerance.
 */
export enum Tolerance {
    'Both' = '2',
    'Use PPG/FPG' = '1',
    'Use Ref. ECD/Ref. Depth' = '0',
}  //end of Tolerance enum

