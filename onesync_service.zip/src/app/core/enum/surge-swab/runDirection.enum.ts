/**
 * This file will hold the details of RunDirection.
 */
export enum RunDirection {
    'Downwards (Surge)' = '0',
    'Upwards (Swab)' = '1',
    'Both (Surge/Swab)' = '2',
}  //end of RunDirection enum


