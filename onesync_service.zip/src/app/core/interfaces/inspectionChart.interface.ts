/**
 * This file helps to create interface for Inspection charts.
 */

export interface ChartData {
    tortusity?: Array<number>;
    inclination?: Array<number>;
    azimuth?: Array<number>;
    dls?: Array<number>;
    northsouth?: Array<number>;
    eastwest?: Array<number>;
    turnrate?: Array<number>;
    buildrate?: Array<number>;
    ddi?: Array<number>;
}
export interface GetParameters {
    SurveyHeaderId?: string;
    SurveyCollectionId?: string;
}