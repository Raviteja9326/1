/**
 * This interface is used in CalculatorBit component.
 */

export interface CalculatorBit {
    Nozzle?: number;
    Size?: string;
    FlowArea: number;
    FlowRate: number;
    JetVelocity: number;
   
} //end of CalculatorBit interface class

