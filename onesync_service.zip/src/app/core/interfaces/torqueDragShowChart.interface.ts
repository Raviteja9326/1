/**
 * This file helps to create interface for surgeSwab charts.
 */

export interface TorqueDragShowChartData {
    axialLoad?: Array<number>;
    torque?: Array<number>;
    contactForce?: Array<number>;
    vonMisesStress?: Array<number>;
    hookLoad?: Array<number>;
    surfaceTorque?: Array<number>;
    trueAxialLoad?:Array<number>;
    axialStress?: Array<number>;
    torsionalStress?: Array<number>;
    shearStress?: Array<number>;
    bendingStress?: Array<number>;
    hoopStress?: Array<number>;
    radialStress?:Array<number>;
    stringPositionY?:Array<number>;
    stringPositionZ?:Array<number>;
    pressureInsideDrillstring?:Array<number>;
    pressureInAnnulus?:Array<number>;
    eccentricity?:Array<number>;
    bendingMoment?:Array<number>;
    radialClearance?:Array<number>;
    stretchShortening?:Array<number>;

}
