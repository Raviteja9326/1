export interface surveyRealTime {
  bitDepth: number,

  wellDepth: number,

  weightOnBit: number,

  hookLoad: number,

  pump1Speed: number,

  pump2Speed: number,

  densityIn: number,

  densityOut: number,

  flowIn: number,

  rotaryTorque: number,

  topDriveSpeed: number
  }