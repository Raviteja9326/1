/**
 * This file helps to create interface for surgeSwab charts.
 */

export interface SurgeSwabChartData {
    rheology?: Array<number>;
    inclination?: Array<number>;
    maxSpeed?: Array<number>;
    ecdTD?: Array<number>;
    ecdCS?: Array<number>;
    ecdWSEnd?: Array<number>;
}
