/**
 * This interface is used in custom-connection component.
 */

export interface WitDaqInInterface {
    Category ?:string;
    TagId ?:string;
    Channel ?:string;
    Title?:string;
    Type?:string;
    Unit?:string;
    isUpdated:boolean;
    isDeleted :boolean;
    isNewlyAdded :boolean;
    isAdded:boolean;





    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

