export interface oneClickCalculation {
    //FluidId:number,
    //MudType:number,
    ApplicationFlowType: number,
 
   
    Expression:string,
    OneClickCategoryId:number,
    OneClickCategoryName:string,
    LocalizedDisplayName_Xml:string,
    LocalizedDescription_Xml:string
    isAdded?: boolean;
     isUpdated?: boolean;
 
 
     
     
   
    }