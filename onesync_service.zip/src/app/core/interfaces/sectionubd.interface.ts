/**
 * This interface is used in custom-connection component.
 */

export interface SectionubdInterface {


    StartMD?: string;
    EndMD ?: string;
    StartTVD?: string;
    EndTVD?: string;
    AnnulusTotalPressure?: number;
    EquivalentCirculatingDensity?: number;
    MinimumCuttingTransportRatio?: number;
    MinimumVelocity?: number;
    AnnulusVolume?: number;
    Warning?: number;

    localRecordId: number;
    isUpdated: boolean;
    isDeleted: boolean;
    isNewlyAdded: boolean;
    isAdded: boolean;
    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

