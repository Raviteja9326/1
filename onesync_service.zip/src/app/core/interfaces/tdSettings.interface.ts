export interface TDSettingsInterface {
    
    DrillingRotaryWOB: number,
    DrillingRotaryTOB : number,    
    DrillingRotaryTDS: number, 
    DrillingRotaryROP: number,
    DrillingSlidingWOB: number,
    DrillingSlidingROP: number,   
    TrippingInRS : number,
    TrippingOutRS: number,
    ROBTDS: number,
    ReamingTDS: number,
    ReamingRS : number,
    BackReamingTDS: number,
    BackReamingRS: number,
    FlowRate : number,
    RotationalEffects: boolean,
    AnalysisSettingsId : number,
} //end of WITSM