export const filelist = {
    Name: 'file',
    file: [
        { menuName: 'Projects', menuImg: 'layers.png', menuPath: '/dashboard/projects', isActive: '1' }
    ],
};

export const setuplist = {
    Name: 'setup',
    file: [
        {
            menuName: 'Job Info', menuImg: 'info.png', menuPath: '/dashboard/jobinfo/jobinformation', isActive: '1', submenu: [
                { submenuName: 'General', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Personnel', menuImg: '', menuPath: '', isActive: '1' }
            ]
        },
        {
            menuName: 'Surface Equipment', menuImg: 'milling-machine.png', menuPath: '/dashboard/surface-equipment', isActive: '1', submenu: [
                { submenuName: 'Equipment Configuration', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Piping and Instrumentation', menuImg: '', menuPath: '',isActive:'1'}
            ]
        },
        {
            menuName: 'Wells', menuImg: 'oil-well.png', menuPath: '/dashboard/wells', isActive: '1', submenu: [
                { submenuName: 'Well Paths', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Formations', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Well Intervals', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Temperature', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'kick-loss-zones', menuImg: '', menuPath: '', isActive: '1' },
            ]
        },
        {
            menuName: 'Fluids', menuImg: 'water-drop.png', menuPath: '/dashboard/fluids', isActive: '1', submenu: [
                { submenuName: 'Mud', menuImg: '', menuPath: '', isActive: '1' },
            ]
        },
        {
            menuName: 'Mappings', menuImg: 'roadmap.png', menuPath: '/dashboard/mappings', isActive: '1', submenu: [
                { submenuName: 'Parameter', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Witsml Activity Code', menuImg: '', menuPath: '', isActive: '1' },

            ]
        },
        {
            menuName: 'Limits and Alarms ', menuImg: 'time.png', menuPath: '/dashboard/limits-alarms', isActive: '1', submenu: [
                { submenuName: 'Hydraulics', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Parameters', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'calculations', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'wits', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'witsml', menuImg: '', menuPath: '', isActive: '1' },
            ]
        },
        {
            menuName: 'MVA settings ', menuImg: 'MVASettings.png', menuPath: '/dashboard/mva-settings', isActive: '1', submenu: [
                { submenuName: 'tdPlannedsettings', menuImg: '', menuPath: '', isActive: '1' },
            ]
        },
        { menuName: 'Work String', menuImg: 'string.png', menuPath: '/dashboard/workstring', isActive: '1' },
        {
            menuName: 'Catalogs', menuImg: 'catalogue.png', menuPath: '/dashboard/catalogs', isActive: '1', submenu: [
                { submenuName: 'Materials', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Lithologies', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Connections', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Custom Connections', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Centeralizers', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Custom Tools', menuImg: '', menuPath: '', isActive: '1' },
            ]
        },
        {
            menuName: 'OneClick-Settings', menuImg: 'settings.png', menuPath: '/dashboard/oneclick-settings', isActive: '1', submenu: [
                { submenuName: 'Events', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Calculations', menuImg: '', menuPath: '', isActive: '0' },
                { submenuName: 'Conditions', menuImg: '', menuPath: '', isActive: '1' }//,
                // { submenuName: 'Flows', menuImg: '', menuPath: '', isActive: '1' },
                // { submenuName: 'Run', menuImg: '', menuPath: '', isActive: '0' },
            ]
        },
        {
            menuName: 'DAQ', menuImg: 'daq.png', menuPath: '/dashboard/daq', isActive: '1', submenu: [
                { submenuName: 'wits', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'witsmlDaq', menuImg: '', menuPath: '', isActive: '1' },

            ]
        },
        { menuName: 'Units', menuImg: 'cost.png', menuPath: '/dashboard/units', isActive: '1' },
        {
            menuName: 'System Preferences', menuImg: 'window.png', menuPath: '/dashboard/systemperferences', isActive: '1', submenu: [
                { submenuName: 'Well Schemes', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Color Schemes', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Graph Line Styles', menuImg: '', menuPath: '', isActive: '1' },
                { submenuName: 'Interface Settings', menuImg: '', menuPath: '', isActive: '1' },
            ]
        },
    ],
};

export const realtimelist = {
    Name: 'realtime',
    file: [
        { menuName: 'Survey', menuImg: 'New_Project.png', menuPath: '/dashboard/survey', isActive: '1' },
        { menuName: 'Flowchart', menuImg: 'New_Project.png', menuPath: '/dashboard/flowchart', isActive: '1' },
        { menuName: 'gridstack', menuImg: 'New_Project.png', menuPath: '/dashboard/gridstack/grid', isActive: '1' }
    ],
};

export const planslist = {
    Name :'plans',
    file: [ 
        { menuName: 'Oneclick', menuImg: 'daq.png', menuPath: '/dashboard/oneclick', isActive:'1', submenu:[
            { submenuName: 'bha-vibration', menuImg: '', menuPath: '',isActive:'1'},
        ] },
        { menuName: 'Mechanics', menuImg: 'layers.png', menuPath: '/dashboard/mechanics', isActive:'1', submenu:[
            { submenuName: 'bha-vibration', menuImg: '', menuPath: '',isActive:'1'},
        ] },
        { menuName: 'Hydraulics', menuImg: 'daq.png', menuPath: '/dashboard/hydraulics-Plan',isActive:'1', submenu:[
        { submenuName: 'snapshot', menuImg: '', menuPath: '',isActive:'1'},
        { submenuName: 'surge-swab', menuImg: '', menuPath: '',isActive:'1'},
        { submenuName: 'influx', menuImg: '', menuPath: '',isActive:'1'}
    ]},
    {
        menuName: 'Calculators', menuImg: 'layers.png', menuPath: '/dashboard/calculators', isActive: '1', submenu: [
            { submenuName: 'calculators', menuImg: '', menuPath: '', isActive: '1' },
            { submenuName: 'bit', menuImg: '', menuPath: '', isActive: '1' },
            { submenuName: 'unit-converter', menuImg: '', menuPath: '', isActive: '1' }
        ]
    },
]
};


export const reportslist = {
    Name: 'reports',
    file: []
};


export const realtimedashboardlist = {
    Name: 'realtimedashboard',
    file: [
        { menuName: 'Real-Time Dashboard', menuImg: 'window.png', menuPath: '/dashboard/real-time-dashboard', isActive: '1' },
        // { menuName: 'Real-Time Dashboard1', menuImg: 'New_Project.png', menuPath: '/dashboard/survey', isActive: '1' },
    ]
};