export class HydraulicSnapshotListItem {
    SnapshotConfigurationId?: number;
    WellboreIndex: string;
    DrillstringIndex: string;
    FluidIndex: number;
    SurveyIndex: string;
    ReservoirZones: number;
    FluidReturnPath: number;
    BitDepth: number;
    Operation: number;
    SurfaceBackPressure: number;
    CuttingsSize: number;
    WSTool: string;
    CuttingsDiameter: number;
    CuttingsDensity: number;
    BedPorosity: number;
    DepthOfIntereset: number;
    HoleCleaningDOI: number;
    BoostFlowRate: number;
    FlowRate: number;
    RotarySpeed: number;
    RateOfPenetration: number;
    MudInletTemperature: number;
    MudOutletTemperature: number;
    IncludeToolJointEffect: boolean;
    IncludeEccentricity: boolean;
    BottomHoleTemperature: number;
    GasInjectionRate: number;
    LiquidInjectionRate: number;
    IsUBD: boolean;
    SelectedColorMap: string;
    WellId: number;
    ConfigurationId: number;
    Name: string;
    PointOfInterest: string;
    DifferentialPressureAtBottom: number;
    ExperimentGroup: string;
    SnapshotAnalisysOutputGraphXML: {
        type: number;
        data: number[]
    };
    HoleCleaningModel: number;
    CuttingsMaterial: number;
    PipeSurfacePressure: number;
    PlugDepth: number;
    SandMeshSize: number;
    WSEnd: number;
    PerfDepth: number;
    SandConcentration: number;
    GasFlowRate: number;
    isAdded?: boolean;

    constructor() {
        this.BedPorosity = null;
        this.BoostFlowRate = null;
        this.BitDepth = null;
        this.CuttingsDiameter = null;
        this.CuttingsDensity = null;
        this.CuttingsSize = null;
        this.DepthOfIntereset = null;
        this.DrillstringIndex = null;
        this.FlowRate = null;
        this.FluidIndex = null;
        this.FluidReturnPath = null;
        this.HoleCleaningDOI = null;
        this.Operation = null;
        this.RateOfPenetration = null;
        this.ReservoirZones = null;
        this.RotarySpeed = null;
        this.SurfaceBackPressure = null;
        this.SurveyIndex = null;
        this.WellboreIndex = null;
        this.WSTool = null;
        this.MudInletTemperature = null;

        this.MudOutletTemperature = null;
        this.IncludeToolJointEffect = false;
        this.IncludeEccentricity = false;
        this.BottomHoleTemperature = null;
        this.GasInjectionRate = null;
        this.LiquidInjectionRate = null;
        this.IsUBD = false;
        this.SelectedColorMap = null;
        this.WellId = null;
        this.ConfigurationId = null;
        this.Name = null;
        this.PointOfInterest = null;
        this.DifferentialPressureAtBottom = null;
        this.ExperimentGroup = null;
        this.SnapshotAnalisysOutputGraphXML = {
            type: null,
            data: []
        },
            this.HoleCleaningModel = null;
        this.CuttingsMaterial = null;
        this.PipeSurfacePressure = null;
        this.PlugDepth = null;
        this.SandMeshSize = null;
        this.WSEnd = null;
        this.PerfDepth = null;
        this.SandConcentration = null;
        this.GasFlowRate = null
    }
}

const addSnapshots = [{
    "Name": "Snapshot 1",
    "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
    "DrillstringIndex": "1F5FBFC3-F101-46C6-A498-4F41B1A080DC",
    "FluidIndex": 58,
    "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
    "ReservoirZones": 1, //(for now send always as 1),
    "FluidReturnPath": 1,
    "BitDepth": 1, //(refering to work string depth field in UI),
    "Operation": 1,
    "SurfaceBackPressure": 1, //(refering to SBP field in UI),
    "WSTool": "Custom", //(refering to work string tool dropdown value in UI),
    "CuttingsSize": 1,
    "CuttingsDiameter": 1,
    "CuttingsDensity": 1,
    "BedPorosity": 1, //(always 1),
    "DepthOfIntereset": 435.28,
    "FlowRate": 1,
    "RotarySpeed": 1, //(refering to TDS field in UI),
    "RateOfPenetration": 1, //(refering to ROP field in UI),
    "MudInletTemperature": 1,
    "MudOutletTemperature": 1,
    "IncludeToolJointEffect": 1,
    "IncludeEccentricity": 1,
    "BottomHoleTemperature": 1,
    "IsUBD": 0, //(always 0),
    "WellId": 9,
    "SnapshotAnalisysOutputGraphXML": 1,
    "HoleCleaningModel": 1,
    "CuttingsMaterial": 1,
    "WSEnd": 0,
    "PointOfInterest": "Stabilizer test by siva",
    "PlugDepth": 0, //(this field will be enabled when we select operation as Injection Annulus, production annulus),
    "DifferentialPressureAtBottom": 1, //(this field will be enabled when we select operation as Drilling

}]