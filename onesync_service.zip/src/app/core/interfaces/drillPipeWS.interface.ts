/**
 * This file helps to create interface for DrillPipeWS.
 */

export interface DrillPipeWS {

    OuterDiameter?: number;
    InnerDiameter?: number;
    Length?: number;
    Mass?: number;
    NW?: number;
    SectionType?: number;
    SectionName?: string;
    Order?: number;
    Material?:number;
}
