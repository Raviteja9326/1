export interface SectionsInterface {
    SnapshotSectionSummaryId: number;
    StartMD: number;
    EndMD: number;
    StartTVD: number;
    EndTVD: number;
    AnnulusTotalPressure: number;
    EquivalentCirculatingDensity: number;
    MinimumCuttingTransportRatio: number;
    MinimumVelocity: number;
    AnnulusVolume: number;
    Warning: string;
    SnapshotConfigurationId: number;
}

