export interface ExpressionMenuItem{
    label: string;
    submenu?: ExpressionMenuItem[];
    menuSelect?: () => string;
  }