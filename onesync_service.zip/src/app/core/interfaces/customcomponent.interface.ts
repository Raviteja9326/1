/**
 * This file helps to create interface for Lithology type.
 */

export interface CustomComponent {
    LithologyId:number;
    Type?: string;
    PoissonsRatio?: number; 
    ModulusOfElasticity?: number; 
    PeakFrictionAngle?: number;
    PeakCohesion?:number;
    ThermalExpansionCoefficient?:number;
    BiotsCoefficient?:number;
    TensileStrength?:number;
    CompressiveStrength?:number;
    CompressionalSlowness? : number,
    ShearSlowness? : number;
    GammaRay? : number ;
    Density? : number;
    SpecificHeatCapacity?:number;
    ThermalConductivity?:number;
    YieldStress?:number;
    AnisotropicFactor?: number;
  }
