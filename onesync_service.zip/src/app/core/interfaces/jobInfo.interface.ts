export class jobInfo{

        Name : string;
        EmployeeNumber: any;
        PersonnelRole: number;
        PersonnelRoleName: string;
        PersonnelTimeSheetId : number;
        DateIn: Date;
        DateOut: Date;
        isNewlyAdded:boolean;
        isDeleted:boolean;
        isUpdated:boolean;
        Order: number;
        uniqueID:number;
        WellId:any

        constructor() {
                this.Name = null;
                this.EmployeeNumber = null;
                this.PersonnelRole = 0;
                this.PersonnelTimeSheetId = 0;
                this.PersonnelRoleName = "";
                this.isNewlyAdded = false;
                this.isDeleted = false;
                this.isUpdated = false;
                this.Order = 2;
                this.uniqueID = 0;
                this.WellId = 0
        }
}




