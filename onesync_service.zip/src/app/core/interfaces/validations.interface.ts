import { AbstractControl, ValidationErrors } from "@angular/forms";

export function measuredepth(control: AbstractControl): ValidationErrors | null {
  const value = control.value;

  // Perform your custom validation logic
  if (value < 0 || value > 50000) {
    return { customRange: true };
  }

  return null; // Validation passed
}

export function length(control: AbstractControl): ValidationErrors | null {
  const value = control.value;

  // Perform your custom validation logic
  if (value < 0 || value > 50) {
    return { customRange2: true };
  }

  return null; // Validation passed
}

export function drainoff(control: AbstractControl): ValidationErrors | null {
  const value = control.value;

  // Perform your custom validation logic
  if (value < 0 || value > 10000) {
    return { customRange3: true };
  }

  return null; // Validation passed
}

export function reservoir(control: AbstractControl): ValidationErrors | null {
  const value = control.value;

  // Perform your custom validation logic
  if (value < 0.2 || value > 4) {
    return { customRange4: true };
  }

  return null; // Validation passed
}