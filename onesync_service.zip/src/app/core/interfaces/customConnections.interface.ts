/**
 * This interface is used in custom-connection component.
 */

export interface customConnections {
    localRecordId: number;
    ConnectionName ?: string;
    ConnectionToolSizeId ?: any;
    ToolSizeId: any;
    NominalWeight ?:number;
    ConnectionNW ?:number;
    Grade ?:number;
    ConnectionType ?:any;
    TempConnectionToolSizeId: any;
    Manufacturer ?:string
    OuterDiameter?:number;
    InnerDiameter ?:number;
    Length ?:number;
    IsSystem ?:any;
    BurstPressure :number;
    CollapsePressure :number;
    YieldTensileStrength :number;
    Compression :number;
    MakeupTorque:number;
    MaterialId:any;
    isNewlyAdded :boolean;
    isDeleted :boolean;
    ConnectionId:number;
    isUpdated:boolean;
    isLimitChecked: boolean;
    Name: any;
} //end of temperature interface class