export interface witsmlDp {
    //  Enable:boolean
     Mnemonic:string,
     Title:string,
     ShortTitle:string,
     UnitType:string,
     Unit:string;

  }