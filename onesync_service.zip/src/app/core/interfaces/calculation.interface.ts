/**
 * This interface is used in calculation component.
 */

export class Calculation {
    
    localRecordId: number;

    CalculationalDataConfigurationId: number;
    Expression: string;
    UnitType: number;
    Unit: number;
    CalculationalDataKey : string;
    CalculationalDataHeaderId : number;
    ApplicationFlowType : number;
    IsBasic : boolean;
    OneClickCategoryId : number;
    LocalizedDisplayName_Xml : string;
    LocalizedDescription_Xml : string;
    OneClickCategoryName : string;
    LocalizedName_Xml: string;


    isNewlyAdded: boolean;
    isUpdated: boolean;
    isDeleted: boolean;

    constructor () {

        this.localRecordId = 0;

        this.CalculationalDataConfigurationId = 0;
        this.Expression = "";
        this.UnitType = 0;
        this.Unit = 0;
        this.CalculationalDataKey  = "";
        this.CalculationalDataHeaderId  = 0;
        this.ApplicationFlowType  = 0;
        this.IsBasic = true;
        this.OneClickCategoryId  = 0;
        this.LocalizedDisplayName_Xml  = "";
        this.LocalizedDescription_Xml  = "";
        this.OneClickCategoryName  = "";

        this.isNewlyAdded= false;
        this.isUpdated= false;
        this.isDeleted = false;
    } //end of constructor
} //end of temperature interface class