export interface MudDial {
    //DialReadingAt600?: string;
    "DialReadingAt600":number,
    "DialReadingAt300":number,
    "DialReadingAt200":number,
    "DialReadingAt100":number,
    //"DialReadingAt60":number,
   // "DialReadingAt30":number,
    "DialReadingAt6":number,
    "DialReadingAt3":number,
    "Gel10s":number,
    "Gel30s":number,
    "Gel10m":number,
    "Gel30m":number,

  
    
    
  
   }