/**
 * This interface is used in custom-connection component.
 */

export interface WitDaqInterface {
    Channel ?:string;
    IpAddress ?:string;
    Port ?:string;
    WitsmlActivityCodeMappingHeaderId:number;
    WitsmlActivityCodeMappingId:number;
    localRecordId: number;
    isUpdated:boolean;
    isDeleted :boolean;
    isNewlyAdded :boolean;
    isAdded:boolean;





    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

