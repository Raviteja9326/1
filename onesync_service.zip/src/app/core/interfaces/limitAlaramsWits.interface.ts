/**
 * This interface is used in Parameters component.
 */

export interface LimitAlaramsWits {
    Enabled?: number;
    ParameterDisplayName?: string;
    Minimum: string;
    MinimumSevere: string;
    MinimumHigh: string;
    MaximumHigh: string;
    MaximumSevere: string;
    Maximum: string;
    Unit?: string;
} //end of Parameters interface class

