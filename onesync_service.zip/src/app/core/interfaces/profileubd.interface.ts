/**
 * This interface is used in custom-connection component.
 */

export interface ProfileubdInterface {

    Tool?: string;
    FlowPath?: string;
    PortState?: string;
    NozzleConfig?: string;
    Tfa?: number;
    Discharge?: number;
    FlowSplit?: number;
    NozPDrop?: number;
    JelVel?: number;
    ImpactForce?: number;
    ImpactPressure?: number;
    Power?: number;
    PowerExpanded?: number;
    IntTemp?: number;
    ExtTemp?: number;
    DifferentPressure?: number;
    MaxPress?: number;
    FlowRate?: number;

    localRecordId: number;
    isUpdated: boolean;
    isDeleted: boolean;
    isNewlyAdded: boolean;
    isAdded: boolean;
    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

