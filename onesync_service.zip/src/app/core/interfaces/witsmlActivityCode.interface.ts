/**
 * This interface is used in custom-connection component.
 */

export interface WitsmlCodeActivityInterface {
    ActivityCode ?:number;
    DisplayName ?:string;
    DisplayColor ?:string;
    WitsmlActivityCodeMappingHeaderId:number;
    WitsmlActivityCodeMappingId:number;
    localRecordId: number;
    isUpdated:boolean;
    isDeleted :boolean;
    isNewlyAdded :boolean;
    isAdded:boolean;





    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

