export interface Parameter {
      Name:string;
      sourceCategory:number;
      sourceParameter:number;
      display:number;
      mappingAction:string;
      value:number;
      unit:number;
      MapId:string
      //isAdded:boolean;
      isUpdated:boolean;
    
  
}