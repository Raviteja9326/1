export interface witsmlOutDepth {
  //  Enable:boolean
    Category:string
    Parameter:string,
    WitsmlChannel:string,

    UnitType:string,
    Unit:number;
   // WitsmlOutHeaderId: number,
    //WitsmlOutConfigurationId:number;
//IsSystem:number
  //   isAdded:boolean;
   //  isUpdated:boolean
   
  

}