/**
 * This file helps to create interface for custom tools type.
 */

export interface Units {
    UnitSystemId?:number;
    UnitSystemName?: string;
    isAdded?: boolean;
    Active?: boolean;
  }
  