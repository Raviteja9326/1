/**
 * This file helps to create interface for kicklossszone data types.
 */
export interface KickLossZone {
  ReservoirZoneName?: string;
  ReservoirZoneType?: number;
  MeasuredDepth?: any;
  Length?: any;
  DrainOffRadius?: any;
  ReservoirFluidType?: number;
  ReservoirFluidDensity?: any;
  ReservoirZoneHeaderId?: number;
  ReservoirZoneId?: number;
  uniqueID?: number;
  projectId: any;
}
