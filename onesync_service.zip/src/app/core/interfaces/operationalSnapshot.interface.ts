export interface OperationalSnapshot {
    id: number,
    depth: number,
    sinBucklingThreshold: number,
    helBucklingThreshold: number,
    tensionThreshold: number,
    compressionLimit: number,
    axialLoadRunningIn: number,
    axialLoadPullingOut: number,
    axialLoadRoffb: number,
    torqueThreshold: number,
    torqueRunningIn: number,
    torquePullingOut: number,
    torqueRoffb: number,
    contactForceRunningIn: number,
    contactForcePullingOut: number,
    contactForceRoffb: number,
    yieldStressThreshold: number,
    vonMissesStressRunningIn: number,
    vonMissesStressPullingOut: number,
    vonMissesStressRoffb: number

}

export const tableData = [
    {
        id: 1, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 2, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 3, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 4, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 5, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 6, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 7, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 8, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 9, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 10, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 11, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 12, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 13, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    }, 
    {
        id: 14, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 15, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 16, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 17, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 18, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
    {
        id: 19, depth: 430.3406, sinBucklingThreshold: -15450.3301, helBucklingThreshold: -24293.7290, tensionThreshold: 1399581.0098,
        compressionLimit: 3478.6543, axialLoadRunningIn: 116962.0022, axialLoadPullingOut: 138865.0040, axialLoadRoffb: 132087.6888,
        torqueThreshold: 86319.8832, torqueRunningIn: 0.0000, torquePullingOut: 0.0000, torqueRoffb: 1493.7316,
        contactForceRunningIn: 204.7514, contactForcePullingOut: 274.6467, contactForceRoffb: 252.9740, yieldStressThreshold: 120.00001,
        vonMissesStressRunningIn: 9.8023, vonMissesStressPullingOut: 11.4814, vonMissesStressRoffb: 10.9618
    },
];