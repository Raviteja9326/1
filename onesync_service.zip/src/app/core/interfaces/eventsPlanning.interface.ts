/**
 * This interface is used in custom-connection component.
 */

export interface EventsPlanning {
    localRecordId: number;
    ApplicationFlowType ?: number;
    OneClickCategoryId ?:number;
    LocalizedName_Xml:string;
    LocalizedDescription_Xml:string;
    DataConditionId ?:number;
    DataConditionResult ?:string;
    EventId:number;
    EventKey:string;
    EventHeaderId:number;
    isNewlyAdded :boolean;
    isDeleted :boolean;
    isUpdated:boolean;
    isAdded:boolean;
    OneClickCategoryName:string;

} //end of temperature interface class