/**
 * This file helps to create interface for Formations type.
 */

export interface Formations {
    LithologyId?:number;
    Lithology:number;
    LithologyName:string;
    FormationName: string;
    Porosity:number;
    Permeability:any;
    MeasuredDepth:number;
    TVD:number;
    PorePressureGradient:any;
    WellBoreStabilityGradient:any;
    FormationIntegrityTest:any;
    FracturePressureGradient:any;
    LeakOffTest:any;
    MinHorizontalStress:any;
    MaxHorizontalStress:any;
    DirectionMinHorizontalStress:any;
    UCS:number;
    MSE: any;
    Order:number;
    Description:string;
    isAdded:boolean;
    isUpdated:boolean;
    LithologyConcentration:any;
    FormationHeaderId?:number;
    FormationId?:number;
    FormationsSourceType: number;
    ProjectId:any;
  }
