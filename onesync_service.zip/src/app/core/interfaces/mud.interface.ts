export interface Mud {
   //FluidId:number,
   //MudType:number,

   Name:string;
      ProjectId?: number,
   isAdded?: boolean;
    isUpdated?: boolean;


    
    
  
   }