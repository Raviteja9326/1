export interface witsmlOut {
    Enable:boolean
   // Category:string;
    Parameter:string;
    WitsmlChannel:string;
    WitsmlLogUId:string;
    WitsmlLogCurve:string;
    UnitType:string;
    Unit:number,
    WitsmlOutHeaderId: number,
    //WitsmlOutConfigurationId:number;
    IsSystem:number
  //   isAdded:boolean;
   //  isUpdated:boolean
   
  

}