/**
 * This interface is used in Parameters component.
 */

export interface Parameters {
    Enable?: number;
    Name?: string;
    Minimum: string;
    MinSevere: string;
    MinHigh: string;
    MaxHigh: string;
    MaxSevere: string;
    Maximum: string;
    Unit?: string;
} //end of Parameters interface class

