
export interface BitOptDataBrowserModel {
    FlowRate: number;
    PumpHHP: number;
    BitHHP: number;
    ParasiticLoss: number;
    MinFlowRate: number;
    MaxFlowRate: number;
    JetImpactForce: number;
}

export interface BitOptSummaryModel {
    MinimumFlowRate: number;
    MaximumFlowRate: number;
    MaxBitHHPOptimumFlowRate: number;
    MaxBitHHPOptimumBitPressureDrop: number;
    MaxBitHHPTotalSystemPressureLoss: number;
    MaxBitHHPBitHHP: number;
    MaxBitHHPBitPowerExpended: number;
    MaxBitHHPBitImpactForce: number;
    MaxBitHHPRecommendedTFA: number;
    MaxBitHHPRecommendedNozzleSize: number;
    MaxJetImpactForceOptimumFlowrate: number;
    MaxJetImpactForceOptimumBitPressDrop: number;
    MaxJetImpactForceTotalSystemPressLoss: number;
    MaxJetImpactForceBitHHP: number;
    MaxJetImpactForceBitPowerExpended: number;
    MaxJetImpactForceBitImpactForce: number;
    MaxJetImpactForceRecommendedTFA: number;
    MaxJetImpactForceRecommendedNozzleSize: number;
}