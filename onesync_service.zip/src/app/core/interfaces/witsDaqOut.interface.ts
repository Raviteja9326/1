/**
 * This interface is used in custom-connection component.
 */

export interface WitDaqOutInterface {
    Object ?:string;
    Parameter ?:string;
    Channel ?:string;
    Category?:string;
    TagId?:string;
    Type?:string;
    Unit?:string;
    isUpdated:boolean;
    isDeleted :boolean;
    isNewlyAdded :boolean;
    isAdded:boolean;





    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

