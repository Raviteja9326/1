export interface HydraulicParametricMinMax {
    id: number;
    rop: number,
    flowRate: number;
    tds: number;
    tool: string;
}

export const minMaxData = [
    { id: 1, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'Bed Height: 1.346 mm' },
    { id: 2, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'Bit HHP: 424.69 kW' },
    { id: 3, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'Bit Press: 14375.78 kPa' },
    { id: 4, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'ECD+Cuttings TD: 1040.38 kg/m^3' },
    { id: 5, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'ECD+Cuttings Shoe: 1042.88 kg/m^3' },
    { id: 6, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'Cuttings: 1.65 %' },
    { id: 7, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'WS Press: 336686.08 kPa' },
    { id: 8, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'Pump HHP: 9743.90 kW' },
    { id: 9, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'SPP: 351232.18 kPa' },
    { id: 10, rop: 15.24, flowRate: 1324.89, tds: 30.00, sbp: 345.67, bitDepth: 88.13, tool: 'ECD+Cuttings DOI: 1048.81 kg/m^3' },
];
