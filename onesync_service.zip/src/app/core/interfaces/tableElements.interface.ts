export interface Element {
    position: number,
    MaterialId: any,
    MaterialName: any,
    Grade: any,
    Density: any,
    SpecificHeatCapacity: any,
    ThermalConductivity: any,
    ModulusOfElasticity: any,
    PoissonRatio: any,
    ThermalExpansionCoefficient: any,
    YieldStress: any,
    AnisotropicFactor: any,
    Usage: any,
    Symbol: any,
    Action: string
}