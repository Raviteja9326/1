/**
 * This file helps to create interface for Underbalanced type.
 */

export interface WitsmlDaq {
    Name?:string,
    Channel?: string,
    URL?: string,
    Username?: string,
    Password?: string,
}
