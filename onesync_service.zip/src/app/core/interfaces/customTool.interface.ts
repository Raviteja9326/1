/**
 * This file helps to create interface for custom tools type.
 */

export interface CustomTool {

    CustomToolCatalogId?: number;
    CustomToolCatalogKey?: string;
    Name?: string;
    isAdded?: boolean;
    isUpdated?: boolean;
  }
  