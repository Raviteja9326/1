/**
 * This interface is used in custom-connection component.
 */

export interface KicklossZonesubdInterface {

    Zone?: string;
    Temperature?: string;
    Pressure?: string;
    Density?: string;
    Flowtrate?: number;
    localRecordId: number;
    isUpdated: boolean;
    isDeleted: boolean;
    isNewlyAdded: boolean;
    isAdded: boolean;
    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

