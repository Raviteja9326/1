/**
 * This file helps to create interface for Well Path type.
 */

export interface WellPath {

  AutoImport?: boolean,
  WitsmlChannelKey?: string,
  TrajectoryUid?: string,
  AutoImportFrequencyInMinutes?: number,
  MdUnit?: number,
  AzimuthUnit?: number,
  InclinationUnit?: number,
  Active?: boolean,
  Key?: string,
  PlanedSurveyCollectionId?: number,
  SurveyCollectionId?: number,
  WellPathCollectionId?: number,
  TieOnPoint?: number,
  Name?: string;
  isAdded?: boolean;
  isUpdated?: boolean;
}


export interface WellData {
  MeasuredDepth: number;
  Azimuth: number;
  Inclination: number;
  NorthSouth: number;
  EastWest: number;
  TrueVerticalDepth: number;
  TVDSS: number;
  LateralDistance: number;
  DogLegSeverity: number;
  BuildRate: number;
  TurnRate: number;
  DDI: number;
  VSec: number;
  HDisp: number;
  Tortuosity: number;
  ABSTortuosity: number;
  CourseLength: number;
  uniqueID?:any;
  ToolFace:number;
  SurveyId?:any;
  SurveyCollectionId?:any;
  SurveyHeaderId?:any;
  Order?:number;
  SurveyTortuosityId?:number;
  isPrecalculatedDeleteRow?:boolean,
  isPrecalculatedRow?:boolean,
  DdiStatus?:any
}

export function getDefaultWellData(): WellData {
  const uniqueIds:any = Date.now();
  return {
    MeasuredDepth: 0,
    Azimuth: 0,
    Inclination: 0,
    NorthSouth: 0,
    EastWest: 0,
    TrueVerticalDepth: 0,
    TVDSS: 0,
    LateralDistance: 0,
    DogLegSeverity: 0,
    BuildRate: 0,
    TurnRate: 0,
    DDI: 0,
    VSec: 0,
    HDisp: 0,
    Tortuosity: 0,
    ABSTortuosity: 0,
    CourseLength: 0,
    uniqueID: uniqueIds,
    ToolFace:0,
    SurveyId: '',
    SurveyCollectionId:0,
    SurveyHeaderId:0,
    Order:0,
    SurveyTortuosityId:0,
    DdiStatus: 0
  };
}



