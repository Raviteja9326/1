/**
 * This interface is used in Parameters component.
 */

export interface Hydraulics {
    Enable?: number;
    Name?: string;
    Minimum: string;
    MinimumId: string;
    MinimumName: string;
    MinSevere: string;
    MinSevereId: string;
    MinSevereName: string;
    MinHigh: string;
    MinHighId: string;
    MinHighName: string;
    MaxHigh: string;
    MaxHighId: string;
    MaxHighName: string;
    MaxSevere: string;
    MaxSevereId: string;
    MaxSevereName: string;
    Maximum: string;
    MaximumId: string;
    MaximumName: string;
    Unit?: string;
} //end of Parameters interface class

