export interface Connection {
   // ConnectionId:number,
    ConnectionName:string,
  //  ConnectionDataId:number,
    tpr:number,
    Drg:number,
    C:number,
    S:number,
    H:number,
    Srs:number,
    Qc:number,
    BBBDia:number,
    Lpc:number,
    p:number,
    f:number,
    Theta:number,
    // ConnectionStandardDimensionId:number,
    // ConnectionDataId1:number,
    // OD:number,
    // ID:number,
    // C1:number,
    // C2:number,
  
    // }

}