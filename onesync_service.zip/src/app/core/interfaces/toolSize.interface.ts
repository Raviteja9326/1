/**
 * This interface is used in the custom connection tool size array.
 */
export class ToolSize { 
    ID: any;
    Name: string;
    NominalOD: any;
    ToolSizeFrom: any;
    ToolSizeId: number;
    ToolSizeOption: any;
    ToolSizeTo: any;
    ToolSizeType: any
}