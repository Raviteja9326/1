export interface SnapShotChartData {
    velocity?: Array<number>;
    ECD?: Array<number>;
    temperature?: Array<number>;
    holeCleaning?: Array<number>;
    pressure?: Array<number>;
    cir?: Array<number>;
    inclination?: Array<number>;
    rheology?: Array<number>;
    differnetialPressure?: Array<number>;
}

export interface ChartDatasetModel {
    datasetMax: number,
    datasetMin: number,
    labels: number[],
    labelMax: number,
    datasets: {
        borderWidth: number;
        data: number[],
        label: string,
        hidden?: boolean,
        backgroundColor: string,
        borderColor: string
    }[]
}

export interface TempChartModel {
    // Snapshot
    velocity?: ChartDatasetModel
    ecd?: ChartDatasetModel
    temperature?: ChartDatasetModel
    holeCleaning?: ChartDatasetModel
    pressure?: ChartDatasetModel
    ctr?: ChartDatasetModel,
    inclination?: ChartDatasetModel,
    rheology?: ChartDatasetModel,
    diffPress?: ChartDatasetModel,

    //Torque & drag
    axialLoad?: ChartDatasetModel,
    torque?: ChartDatasetModel,
    contactForce?: ChartDatasetModel,
    vonMisesStress?: ChartDatasetModel,
    hookLoad?: ChartDatasetModel,
    surfaceTorque?: ChartDatasetModel,
    axialStress?: ChartDatasetModel,
    bendingStress?: ChartDatasetModel,
    shearStress?: ChartDatasetModel,
    hoopStress?: ChartDatasetModel,
    stringPosY?: ChartDatasetModel,
    stringPosZ?: ChartDatasetModel,
    pressureDrillstring?: ChartDatasetModel,
    radialStress?: ChartDatasetModel,
    trueAxialLoad?: ChartDatasetModel,
    torsionalStress?: ChartDatasetModel,

    bendingMoment?: ChartDatasetModel,
    buoyantWeight?: ChartDatasetModel,
    eccentricity?: ChartDatasetModel,
    pressureAnnulus?: ChartDatasetModel,
    radialClearance?: ChartDatasetModel,
    stretchShortening?: ChartDatasetModel,
    twistAngle?: ChartDatasetModel
}

export interface GraphDataApiResponse {
    velocity?: Array<{
        MeasuredDepth: number,
        PipeVelocity: number,
        AnnularVelocity: number
    }>;
    ECD?: Array<{
        MeasuredDepth: number,
        EquivalentCirculatingDensity: number,
        EquivalentStaticDensity: number,
        EquivalentCirculatingDensityPlusCuttings: number
    }>;
    temperature?: Array<{
        MeasuredDepth: number,
        PipeTemperature: number,
        AnnulusTemperature: number,
        FormationTemperature: number,
    }>;
    HoleCleaning?: Array<{
        MeasuredDepth: number,
        Cuttings: number,
        BedHeight: number,
    }>;
    pressure?: Array<{
        MeasuredDepth: number,
        DrillStringPressure: number,
        AnnularPressure: number,
        PPP: number,
        WBS: number,
        FP: number,
    }>;
    CTR?: Array<{
        MeasuredDepth: number,
        CuttingsTransportRatio: number,
    }>;
    inclination?: Array<{
        MeasuredDepth: number,
        Inclination: number
    }>;
    rheology?: Array<{
        MeasuredDepth: number,
        PlasticViscosity: number,
        LowShearYieldPoint: number,
        YieldPoint: number,
    }>;
    differentialPressure?: Array<{
        MeasuredDepth: number,
        Burst: number,
        Collapse: number,
        DifferentialPressure: number,
    }>;
    AxialLoad?: Array<{
        MeasuredDepth: number,
        'Sin. Buckling Threshold': number,
        'Hel. Buckling Threshold': number,
        'Hel. BucklingThresholdRotary': number,
        CompressionLimit: number,
        'Tension Threshold': number,
        RoffB: number
    }>,
    Torque?: Array<{
        MeasuredDepth: number,
        'Torque Threshold': number,
        'Make Up Torque': number,
        RoffB: number,
    }>,
    ContactForce?: Array<{
        MeasuredDepth: number,
        RoffB: number
    }>,
    VoidMisesStress?: Array<{
        MeasuredDepth: number,
        'Yield Stress Threshold': number,
        RoffB: number
    }>,
    HookLoad?: Array<{
        MeasuredDepth: number,
        "Hel Buckling HL Threshold": number,
        "Sin Buckling HL Threshold": number,
        "Tensile Overload HL Threshold": number,
        "Rig Hoisting Capacity": number,
        "Running In": number,
        "Pulling Out": number
    }>,
    SurfaceTorque?: Array<{
        MeasuredDepth: number,
        "Surface Torque Threshold": number,
        "Rig Hoisting Capacity": number,
        "Running In": number,
        "Pulling Out": number
    }>,

    AxialStress?: Array<GraphFields>,
    BendingMoment?: Array<GraphFields>,
    BendingStress?: Array<GraphFields>,
    Buoyantweight?: Array<GraphFields>,
    Eccentricity?: Array<GraphFields>,
    HoopStress?: Array<GraphFields>,
    "Min.WOB"?: Array<{
        "Hel Buckling": number,
        MeasuredDepth: number,
        "Sin Buckling": number
    }>,
    PressureAnnulus?: Array<GraphFields>,
    PressureDrillstring?: Array<GraphFields>,
    RadialClearance?: Array<GraphFields>,
    RadialStress?: Array<GraphFields>,
    SS_StringPosY?: Array<GraphFields>,
    SS_StringPosZ?: Array<GraphFields>,
    ShearStress?: Array<GraphFields>,
    Stretch?: Array<GraphFields>,
    TorsionalStress?: Array<GraphFields>,
    TrueAxialLoad?: Array<GraphFields>,
    TwistAngle?: Array<GraphFields>,
}

export interface GraphFields {
    BackReaming: number,
    CustomDown: number,
    CustomStationary: number,
    CustomUp: number,
    Cutting: number,
    DrillingRotary: number,
    DrillingSliding: number,
    MeasuredDepth: 0,
    PickUp: number,
    PullingOut: number,
    Reaming: number,
    RoffB: number,
    RunningIn: number,
    SlackOff: number,
    Underreaming: number,
    "Yield stress Threshold"?: number,
}

export class HydraulicSnapshotMShearModel {
    public summaries: MShearSummary = new MShearSummary();
    public pressureDrops: Array<MShearPressureDrop> = [];
    public hydraulicsSummaries: Array<MShearHydraulicSummary> = [];
}

export class MShearHydraulicSummary {
    ComponentHydraulicsSummaryId: number;
    NozzlePressureDrop: number;
    FlowSplit: number;
    DifferentialPressure: number;
    SnapshotConfigurationId: number;
}

export class MShearPressureDrop {
    ToolPressureDropId: number;
    DrillstringIndex: number;
    DistributionType: number;
    PressureLoss: number;
    PressureDistribution: number;
    Power: number;
    FlowIn: number;
    SnapshotConfigurationId: number;
}

export class MShearSummary {
    MinimumCuttingsVelocity: number;
    MinimumAnnularVelocity: number;
    HoleCleaningFlowRate: number;
    HoleCleaningTime: number;
    HoleCleaningDOITime: number;
    BottomHoleTemperature: number;
    BitTemperature: number;
    CasingShoeTemperature: number
    CirculationDownTime: number;
    CirculationUpTime: number;
    TotalCirculationTime: number;
    BreakCirculationPumpPressure: number;
    BottomHoleECD: number;
    BitBreakCirculationECD: number;
}

export interface LeftPanelTableModel {
    DrillstringType: string;
    NozzleDischarge: number;
    ToolState: number;
    FlowPath: string;
    PortState: string;
    Description: string;
}
