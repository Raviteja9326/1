/**
 * This interface is used in custom-connection component.
 */

export interface CompareItemInterface {
    Experiment ?:String;
    MinimumCuttingsVelocity ?:number;
    MinimumAnnularVelocity ?:number;
    CriticalFlowRateGalMin ?: number;
    CuttingsToSurfaceTime ?:number;
    WSEndToDoiMin ?: number;
    WSEndToSurfaceMin ?:number;
    OperatingPumpPressurePsi ?:number;
    BottomHoleECD ?: number;
    ShoeECDPpg ?: number;
    WsEndECDPpg ?: number;
    BAPDiffPressurePsi ?: number;
    VolumeToPressureUpMin ?:number;
    VolumeToPressureUpMax ?:number;
    WitsmlActivityCodeMappingHeaderId:number;
    WitsmlActivityCodeMappingId:number;
    localRecordId: number;
    isUpdated:boolean;
    isDeleted :boolean;
    isNewlyAdded :boolean;
    isAdded:boolean;





    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

