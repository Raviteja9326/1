
export interface DrillScheduleModel {
    configId?: number;
    drillScheduleId?: number;
    isAdded?: boolean;
    isUpdated?: boolean;
    
    isChecked: boolean;
    start: number;
    end: number;
    fluid: string;
    drillString: number;
    wob1: number;
    tds: number;
    fr1: number;
    tf1: number;
    df: number;
    tob: number;
    rop1: number;
    wob2: number;
    fr2: number;
    tf2: number;
    rop2: number;
    design: boolean;
    tandd: boolean;
    hyd: boolean;
    sandv: boolean;
    remarks: string;
}