/**
 * This file helps to create interface for Column type.
 */

export interface WellInterval {
  columnDef?: string;
  header?: string;
  cell?: Function;
  editable?: boolean;
  sticky?: boolean
  Name?: string;
  isAdded?: boolean;
  isUpdated?: boolean;
  Active?: boolean;
  Key?: string;
  ManagedByWellActivity?: boolean;
  WellboreSectionHeaderId?: number;
  WellboreSectionId?: number
  dropdown?: boolean
  text?:boolean;
  Type?: any,
  max?:number
}