/**
 * This file helps to create interface for surgeSwab charts.
 */

export interface BhaVibrationChartData {
    horizontalDisplacement?: Array<number>;
    verticalDisplacement?: Array<number>;
    lateralVibrations?: Array<number>;
    contactForce?: Array<number>;
    vonMisesStress?: Array<number>;
}
