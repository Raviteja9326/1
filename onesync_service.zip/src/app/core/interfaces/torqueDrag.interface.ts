export interface TorqueDrag {
    Name: string;
    isAdded?: boolean;
    isUpdated?: boolean;
    PredrillConfigurationId?: number;
}

export interface ActualDataModel {
    PredrillConfigurationId?: number;
    PredrillInputActualDataId?: number;
    MeasuredDepth: number;
    HookLoadTripIn: number;
    HookLoadROB: number;
    HookLoadTrippingOut: number;
    SurfaceTorque: number;
    isAdded?: boolean;
    isUpdated?: boolean;
}

export class TorqueDragMShearModel {
    HookLoad: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    SurfaceTorque: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    VoidMisesStress: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    Buckling: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    ContactForce: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    Stretch: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    WindUp: { max: number, operation: string, MeasuredDepth: number, capacity: number };
    operations: {
        RoffB?: SummaryOperationModel;
        RunningIn?: SummaryOperationModel;
        PullingOut?: SummaryOperationModel;
        DrillingRotary?: SummaryOperationModel;
        DrillingSliding?: SummaryOperationModel;
        Reaming?: SummaryOperationModel;
        BackReaming?: SummaryOperationModel;
        PickUp?: SummaryOperationModel;
        SlackOff?: SummaryOperationModel;
        Underreaming?: SummaryOperationModel;
        Cutting?: SummaryOperationModel;
        CustomUp?: SummaryOperationModel;
        CustomDown?: SummaryOperationModel;
        CustomStationary?: SummaryOperationModel;
    }
}

export interface SummaryOperationModel {
    BitRPM: number;
    BucklingPoints: number;
    Drag: number;
    FrictionTorque: number;
    HelicalBuckling: number;
    LockUp: number;
    OperationKey: string;
    Overpull: number;
    PredrillSummaryWeakPointsContainerId: number;
    PredrillSummaryWeakPointsId: number;
    SOWMargin: number;
    StressPoints: number;
    Stretch: number;
    StringYield: number;
    TOB: number;
    Tensilefailure: number;
    TensionPoints: number;
    TorqueMargin: number;
    TorquePoints: number;
    TwistOff: number;
    WOB: number;
    Windup: number;
}

