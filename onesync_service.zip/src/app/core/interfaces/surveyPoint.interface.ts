/**
 * This file helps to create interface for Survey Point type.
 */

export interface SurveyPoint {
  MeasuredDepth?:number;
  Inclination?: number;
  Azimuth?: number; 
  TrueVerticalDepth?: number; 
  TVDSS?: number;
  NorthSouth?:number;
  EastWest?:number;
  LateralDistance?:number;
  DogLegSeverity?:number;
  BuildRate?:number;
  TurnRate? : number,
  ToolFace? : number;
  VSec? : number ;
  HDisp? : number;
  CourseLength?:number;
  Tortuosity?:number;
  ABSTortuosity?:number;
  DDI?: number;
  Order?:number;
  SurveyCollectionId?:number;
  isAdded:boolean;
  isUpdated:boolean;
  SurveyHeaderId: number;
  }
