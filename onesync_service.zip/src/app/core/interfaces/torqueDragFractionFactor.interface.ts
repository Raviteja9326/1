/**
 * This file helps to create interface for surgeSwab charts.
 */

export interface TorqueDragFrictionFactorData {
    hookLoad?: Array<number>;
    surfaceTorque?: Array<number>;
    hookLoadROB?: Array<number>;
    hookLoadROBA?: Array<number>;
    hookLoadRI10?: Array<number>;
    hookLoadRI20?: Array<number>;
    hookLoadRI30?: Array<number>;
    hookLoadRI40?: Array<number>;
    hookLoadRI50?: Array<number>;
    hookLoadRI60?: Array<number>;
    hookLoadRIA?: Array<number>;
    hookLoadPO10?: Array<number>;
    hookLoadPO20?: Array<number>;
    hookLoadPO30?: Array<number>;
    hookLoadPO40?: Array<number>;
    hookLoadPO50?: Array<number>;
    hookLoadPO60?: Array<number>;
    hookLoadPOA?: Array<number>;
    hookLoadR10?: Array<number>;
    hookLoadR20?: Array<number>;
    hookLoadR30?: Array<number>;
    hookLoadR40?: Array<number>;
    hookLoadR50?: Array<number>;
    hookLoadR60?: Array<number>;
    hookLoadBR10?: Array<number>;
    hookLoadBR20?: Array<number>;
    hookLoadBR30?: Array<number>;
    hookLoadBR40?: Array<number>;
    hookLoadBR50?: Array<number>;
    hookLoadBR60?: Array<number>;
    surfaceTorqueR10?: Array<number>;
    surfaceTorqueR20?: Array<number>;
    surfaceTorqueR30?: Array<number>;
    surfaceTorqueR40?: Array<number>;
    surfaceTorqueR50?: Array<number>;
    surfaceTorqueR60?: Array<number>;
    roBActual?: Array<number>;
    surfaceTorqueReam10?: Array<number>;
    surfaceTorqueReam20?: Array<number>;
    surfaceTorqueReam30?: Array<number>;
    surfaceTorqueReam40?: Array<number>;
    surfaceTorqueReam50?: Array<number>;
    surfaceTorqueReam60?: Array<number>;
    surfaceTorqueBReam10?: Array<number>;
    surfaceTorqueBReam20?: Array<number>;
    surfaceTorqueBReam30?: Array<number>;
    surfaceTorqueBReam40?: Array<number>;
    surfaceTorqueBReam50?: Array<number>;
    surfaceTorqueBReam60?: Array<number>;
}
