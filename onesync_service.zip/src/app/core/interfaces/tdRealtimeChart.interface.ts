export interface TdRealtimeChartData {
    velocity?: Array<number>;
    ECD?: Array<number>;
    temperature?: Array<number>;
    cir?: Array<number>;
    axialLoad?:Array<number>;
    helBuckingThreshold?:Array<number>;
    simBuckingThreshold?:Array<number>;
    tensionThreshold?:Array<number>;
    compressionLimit?:Array<number>;
    trueAxialLoad?:Array<number>;
    torque?:Array<number>;
}

export interface TempChartModel {
    velocity?: {
        MeasuredDepth: number[],
        PipeVelocity: { data: number[], label: string, color: string },
        AnnularVelocity: { data: number[], label: string, color: string }
    };
    ECD?: {
        MeasuredDepth: number[],
        EquivalentCirculatingDensity: { data: number[], label: string, color: string },
        EquivalentStaticDensity: { data: number[], label: string, color: string },
        EquivalentCirculatingDensityPlusCuttings: { data: number[], label: string, color: string }
    };
    temperature?: {
        MeasuredDepth: number[],
        PipeTemperature: { data: number[], label: string, color: string },
        AnnulusTemperature: { data: number[], label: string, color: string },
        FormationTemperature: { data: number[], label: string, color: string },
    };
    HoleCleaning?: {
        MeasuredDepth: number[],
        Cuttings: { data: number[], label: string, color: string },
        BedHeight: { data: number[], label: string, color: string },
    };
    pressure?: {
        MeasuredDepth: number[],
        DrillStringPressure: { data: number[], label: string, color: string },
        AnnularPressure: { data: number[], label: string, color: string },
        PPP: { data: number[], label: string, color: string },
        WBS: { data: number[], label: string, color: string },
        FP: { data: number[], label: string, color: string },
    };
    CTR?: {
        MeasuredDepth: number[],
        CuttingsTransportRatio: { data: number[], label: string, color: string },
    };
}

export interface GraphDataApiResponse {
    velocity?: Array<{
        MeasuredDepth: number,
        PipeVelocity: number,
        AnnularVelocity: number
    }>;
    ECD?: Array<{
        MeasuredDepth: number,
        EquivalentCirculatingDensity: number,
        EquivalentStaticDensity: number,
        EquivalentCirculatingDensityPlusCuttings: number
    }>;
    temperature?: Array<{
        MeasuredDepth: number,
        PipeTemperature: number,
        AnnulusTemperature: number,
        FormationTemperature: number,
    }>;
    HoleCleaning?: Array<{
        MeasuredDepth: number,
        Cuttings: number,
        BedHeight: number,
    }>;
    pressure?: Array<{
        MeasuredDepth: number,
        DrillStringPressure: number,
        AnnularPressure: number,
        PPP: number,
        WBS: number,
        FP: number,
    }>;
    CTR?: Array<{
        MeasuredDepth: number,
        CuttingsTransportRatio: number,
    }>;
}
