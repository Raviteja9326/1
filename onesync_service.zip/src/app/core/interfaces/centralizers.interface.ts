/**
 * This file helps to create interface for Centralizers type.
 */

export interface Centralizers {
    // LithologyId:number;
    Identification?: string;//Identification
    Part?: number; //PartNumber///
    LegacyPartNumber?: string; //LegacyPartNumber////
    CentralizerType?: string;//CentralizerType////
    CrossSectionArea?:number;//CrossSectionArea
    BowThickness?:number;//BowThickness
    BowType?:string;//BowType
    BowWidth?:number;//BowWidth
    NumberOfBows?:number;//NumberOfBows///
    Length? : number,//Length
    EffectiveFlowOD? : number;//EffectiveFlowOD
    NominalID? : number ;//NominalID
    MaxOD? : number;//MaxOD
    RigidOdD?:number;//RigidOdD///
    PipeSize?:number;//PipeSize
    Family?:string;//Family
    StopCollar?: string;//StopCollar
  }
