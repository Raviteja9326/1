/**
 * This interface is used in custom-connection component.
 */

export interface SplitFlowInterface {
    Tool?: string;
    FlowPath?: string;
    PortState?: string;
    NozzleConfig?: string;
    Tfa?: number;
    Discharge?: number;
    FlowSplit?: number;
    NozPDrop?: number;
    JetVel?: number;
    ImpactForce?: number;
    ImpactPress?: number;
    Power?: number;
    PowerExpanded?: number;
    IntTemp?: number;
    ExtTemp?: number;
    DiffPress?: number;
    MaxPress?: number;
    FlowRateAtMaxPress?: number;
    SppAtMaxPress?: number;
    WitsmlActivityCodeMappingHeaderId: number;
    WitsmlActivityCodeMappingId: number;
    localRecordId: number;
    isUpdated: boolean;
    isDeleted: boolean;
    isNewlyAdded: boolean;
    isAdded: boolean;





    // isUpdated:boolean;
} //end of WITSML Activity code  interface class

