export interface Cement {
    "Name":string;
    isAdded?: boolean;
     isUpdated?: boolean;
 
 
     
     
   
    }