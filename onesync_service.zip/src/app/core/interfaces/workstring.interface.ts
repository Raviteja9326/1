/**
 * This file helps to create interface for Project data types.
 */

export interface Workstring {
        Description: string;
        Displacement: number;
        DoglegMaximum: number;
        Compression: number;
        BurstPressure: number;
        HydraulicsDataId: number;
        BitRecordId: number;
        AxialStiffness: number;
        CollapsePressure: number;
        OrificeOptionId: number;
        ServiceClass: number;
        ToolSizeId: number;
        TotalAdjustedWeight: number;
        WirelineRecordId: number;
        group: string; // Not sure about the type here
        centralizers: string; // Not sure about the type here
        actions: string; // Not sure about the type here
}