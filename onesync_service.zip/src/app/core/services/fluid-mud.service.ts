import { Injectable } from '@angular/core';
import {api} from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';


@Injectable({
  providedIn: 'root'
})
export class FluidMudService {
  endPoint: string;
  constructor(private httpMethod:HttpMethodService) { this.endPoint = `${api.serviceEndpoint}`;}



  getSaltTypeList() {

    return this.httpMethod.getMethod(this.endPoint,api.getSaltTypesApi)
  }


  getMudTypeList() {

    return this.httpMethod.getMethod(this.endPoint,api.getMudTypesApi)
  }

  getRheologyModelsList() {

    return this.httpMethod.getMethod(this.endPoint,api.getRheologyModelsApi)
  }

  getRheologyTypesList() {

    return this.httpMethod.getMethod(this.endPoint,api.getRheologyTypesApi)
  }

  getFluidTypesList() {

    return this.httpMethod.getMethod(this.endPoint,api.getFluidTypesApi)
  }

  getMudList(fluidTypeId,projectId) {

    return this.httpMethod.getMethod(this.endPoint,api.getMudListApi+"?FluidTypeId="+fluidTypeId+"&ProjectId="+projectId)
  }

  deleteMudData(deletedIds){
  
    return this.httpMethod.postMethod(this.endPoint,api.deleteMudApi,deletedIds)
  }

  postMudData(addMuds){
    return this.httpMethod.postMethod(this.endPoint,api.postMudDataApi,addMuds)
  }

  cloneMudData(FluidId,payload){

    let cloneMudEndPoint = api.cloneMudDataApi;
    cloneMudEndPoint = cloneMudEndPoint.replace(":FluidId", FluidId);
    return this.httpMethod.postMethod(this.endPoint,cloneMudEndPoint,payload)
  }

  getMudData(FluidId) {

    let getMudDataEndPoint = api.getMudDataApi;
    getMudDataEndPoint = getMudDataEndPoint.replace(":FluidId", FluidId);
    return this.httpMethod.getMethod(this.endPoint,getMudDataEndPoint)
  }


  postRheologyData(payload){
    let fluidType=0;
    return this.httpMethod.postMethod(this.endPoint,api.postRheologyData+"?name=GetRheologyCurveFit&fluidType="+fluidType,payload)
  }


    getConvertedData(payload){
      return this.httpMethod.postMethod(this.endPoint,api.postConversion,payload)

    }


}
