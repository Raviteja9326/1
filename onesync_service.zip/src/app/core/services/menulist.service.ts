import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class MenulistService {

  public menuData = new BehaviorSubject<any>(null);
  constructor(private store:StorageService) {}

  getmenusdata(data) {
   this.store.menu(data);
   return this.menuData.next(data)
  }
}
