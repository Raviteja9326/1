import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { HttpMethodService } from "./httpMethod.service";


@Injectable({
    providedIn: 'root'
})

export class CentralizersService {
    moreInfoRowData : any;
    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService: HttpClient, private httpMethod: HttpMethodService) {

        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Centralizers.
     */
    getCentralizersList() {

        return this.httpMethod.getMethod(this.endPoint, api.getCentralizersApi)
    }//end of getCentralizersList

    
    /**
     *
     * This function will get the list of Centralizers.
     */
    getMoreInfoList(CentralizerTemplateId) {

        return this.httpMethod.getMethod(this.endPoint, api.getCentralizersMoreInfoApi+`${CentralizerTemplateId}`)
    }//end of getCentralizersList

}//end of class