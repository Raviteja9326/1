import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { HttpMethodService } from './httpMethod.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomConnectionsService {

  endPoint: string;
  private customConnctionRecord = new BehaviorSubject<any>({});
  selectedCustomConnection = this.customConnctionRecord.asObservable();
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

     this.endPoint = `${api.serviceEndpoint}`;
  }

//Function to fetch connection list
  getCustomConnectionsList() {

    return this.httpMethod.getMethod(this.endPoint,api.getCustomConnectionsApi)
  }
  
  //function for post the custom connection list
  postCustomConnectionList(data1:any)
  {
    return this.httpMethod.postMethod( this.endPoint,api.postCustomConnection,data1)

  }
  
  //function for put or edit custom connection list
  putCustomConnectionList(data1:any){
    return this.httpMethod.putMethod( this.endPoint,api.putCustomConnection,data1)
  }
  
  //Function for delete list
  deleteCustomConnectionsList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteCustomConnectionsApi, payload);
  }

  /**
   * Below function will set the value of newly added record.
   */
  setCustomConnection(customConnection: any) {

    this.customConnctionRecord.next(customConnection);
  } //end of 'setCustomConnection' function

  getManufacturerList(){
    return this.httpMethod.getMethod(this.endPoint,api.getManufacturerListApi)
  }
} //end of 'CustomConnectionsService'