import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { CustomValidators } from '../constants/regex.constants';
import { ChartDatasetModel, GraphDataApiResponse, GraphFields, TempChartModel } from '../interfaces/snapshotChart.interface';

@Injectable({
    providedIn: 'root'
})
export class OperationalSnapshotService {
    private ConfigName: string = null;
    private ConfigId: number = null;
    private project: { WellId: number, ProjectId: number };

    constructor(
        private httpMethodSvc: HttpMethodService,
    ) { }

    public setProject = (project: { WellId: number, ProjectId: number }) => this.project = project;
    public setConfigId = (id: number) => this.ConfigId = id;
    public setConfigName = (ConfigName: string) => this.ConfigName = ConfigName;

    public getConfigId = () => this.ConfigId;
    public getConfigName = () => this.ConfigName;

    // public postOperationalSnapshot(payload): Observable<{ message: string, result: { ConfigId: number } }> {
    //     return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`,);
    // }

    // public getOperationalSnapshotList(ProjectId: number): Observable<{ message: string, result: { Name: string, ConfigId: number }[] }> {
    //     return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDragList}?ProjectId=${ProjectId}`);
    // }

    // public deleteOperationalSnapshot(payload: any): Observable<{ message: string, result: any }> {
    //     return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/delete`, payload);
    // }

    // public getOperationalSnapshotDetailById(ConfigId: number): Observable<{ message: string, result: TorqueDrag }> {
    //     return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${ConfigId}/details`);
    // }

    // public getSummaryDataById(ConfigId: number): Observable<{ message: string, result: TorqueDragMShearModel }> {
    //     return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${ConfigId}/summary`);
    // }

    public initializeForm() {
        return new FormGroup({
            SurveyIndex: new FormControl("", [Validators.required]),
            WellboreIndex: new FormControl("", [Validators.required]),
            DrillstringIndex: new FormControl("", [Validators.required]),
            FluidIndex: new FormControl("", [Validators.required]),
            FFInterval: new FormControl("", [Validators.required]),
            flowRate: new FormControl("", [Validators.required]),
            bitDepth: new FormControl("", [Validators.required]),
            rotationalEffects: new FormControl(false, [Validators.required]),

            roffb: new FormControl(false),
            roffbSurfaceTorque: new FormControl(""),
            roffbTds: new FormControl(""),

            runningIn: new FormControl(false),
            runningInHookLoad: new FormControl(""),
            runningInRs: new FormControl(""),

            pullingOut: new FormControl(false),
            pullingOutHookLoad: new FormControl(""),
            pullingOutRs: new FormControl(""),

            drillingRotary: new FormControl(false),
            drillingRotaryHookLoad: new FormControl(""),
            drillingRotarySurfaceTorque: new FormControl(""),
            drillingRotaryTds: new FormControl(""),
            drillingRotaryRop: new FormControl(""),

            drillingSliding: new FormControl(false),
            drillingSlidingHookLoad: new FormControl(""),
            drillingSlidingRop: new FormControl(""),

            reaming: new FormControl(false),
            reamingHookLoad: new FormControl(""),
            reamingSurfaceTorque: new FormControl(""),
            reamingTds: new FormControl(""),
            reamingRs: new FormControl(""),

            backReaming: new FormControl(false),
            backReamingHookLoad: new FormControl(""),
            backReamingSurfaceTorque: new FormControl(""),
            backReamingTds: new FormControl(""),
            backReamingRs: new FormControl(""),
        })
    }

    /* map values to post detail api payload from form fields */
    public mapFormValuesToPostPayload(torqueDragForm: FormGroup) {

    }

    /* map values from get detail api response to form fields */
    public mapApiresponseToFormValues(apiResponseResult) {

    }




}
