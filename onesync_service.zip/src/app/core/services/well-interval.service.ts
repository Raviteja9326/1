import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class WellIntervalSimifyService {

  constructor(private httpMethod:HttpMethodService) { }

  getWellintervalList(data) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWellIntervalApi}` + `?ProjectId=${data}`)
  }

  getCasingList(WellboreSectionId: number, type: string) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`${WellboreSectionId}/list?type=${type}`)

  }

  addCasingList(id: number, payload) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`${id}/casing`, payload)
  }

  deleteCasingList(id, payload) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`${id}/delete`, payload);
  }

  deleteOpenHolesList(id, payload) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`${id}/delete`, payload);
  }

  getOpenHolesList(WellboreSectionId: number, type: string) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`${WellboreSectionId}/list?type=${type}`)
  }
 
  addOpenHolesList(id: number, payload) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`${id}/openHole`, payload)
  }

  addWellintervalList(payload) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`, payload)
  }

  activateWellInterval(Id: number, payload) {
    return this.httpMethod.putMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}` + `${Id}/status`, payload);
  }

  updateWellpathsList(payload) {
    return this.httpMethod.putMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`, payload);
  }

  deleteWellIntervalList(payload) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addWellIntervalApi}`+`delete`, payload);
  }

  getMaterialsList(){
    return this.httpMethod.getMethod( `${api.serviceEndpoint}`,`${api.getMaterialsApi}`)
  }

  getAllouterDiameterList(){
    return this.httpMethod.getMethod( `${api.serviceEndpoint}`,`${api.getOuterDiameterApi}`)
  }

  getNWDiameterList(data){
    return this.httpMethod.getMethod( `${api.serviceEndpoint}`,`${api.getNWDiameterApi}/${data}`)
  }

  getCasingTypeColumn(){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getCasingTypeColumn}`)
  }
}
