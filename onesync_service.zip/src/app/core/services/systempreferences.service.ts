import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class SystempreferencesService {

  constructor(private httpMethod:HttpMethodService) { }

  getWellschemeApi(){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getSystemWellSchemesApi}`)
   }

   deleteWellschemeApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.deleteSystemWellSchemesApi}`,data)
   }

   postWellschemeApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addSystemWellSchemesApi}`, data)
   }

   getgraphlineApi(){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getSystemgraphlineApi}`)
   }

   deletegraphlineApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.deleteSystemgraphlineApi}`,data)
   }

   postgraphlineApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addSystemgraphlineApi}`, data)
   }

   getcolorApi(){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getSystemcolorApi}`)
   }

   deletecolorApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.deleteSystemcolorApi}`,data)
   }

   postcolorApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.addSystemcolorApi}`, data)
   }
}
