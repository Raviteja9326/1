import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { HttpMethodService } from './httpMethod.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WitsmlActivityCodeService {

  endPoint: string;
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

     this.endPoint = `${api.serviceEndpoint}`;
  }

//Function to fetch WITSML Activity code list
  getWitsmlActivityCodeList() {

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlActivityCode)
  }
  
  //function for post the custom connection list
  postWitsmlActivityCodeList(data1:any)
  {
    return this.httpMethod.postMethod( this.endPoint,api.postWitsmlActivityCode,data1)

  }

  updateWitsmlActivityCodeList(data1:any)
  {
    return this.httpMethod.postMethod( this.endPoint,api.postWitsmlActivityCode,data1)

  }
  
  //Function for delete list
  deleteWitsmlActivityCodeList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteWitsmlActivityCode, payload);
  }

  /**
   * Below function will set the value of newly added record.
   */
 
} //end of 'CustomConnectionsService'