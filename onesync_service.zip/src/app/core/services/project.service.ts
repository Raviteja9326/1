import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  constructor(private httpMethod:HttpMethodService) {}

   GetprojectApi(){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getProjectApi}`)
   }

   PostprojectApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.getpostproject}`,data)
   }

   deleteprojectApi(data){
    return this.httpMethod.deleteMethod(`${api.serviceEndpoint}`,`${api.deleteProjectsApi}${data}`)
   }
}
