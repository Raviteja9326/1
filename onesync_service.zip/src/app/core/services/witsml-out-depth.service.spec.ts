import { TestBed } from '@angular/core/testing';

import { WitsmlOutDepthService } from './witsml-out-depth.service';

describe('WitsmlOutDepthService', () => {
  let service: WitsmlOutDepthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WitsmlOutDepthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
