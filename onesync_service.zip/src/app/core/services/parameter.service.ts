import { Injectable } from '@angular/core';
import {api} from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class ParameterService {
  endPoint: string;
 
  constructor(private httpMethod:HttpMethodService) { this.endPoint = `${api.serviceEndpoint}`;}


  getWellParameters() {

    return this.httpMethod.getMethod(this.endPoint,api.getWellParametersApi)
  }


  saveParametersData(payload){
    
    return this.httpMethod.putMethod(this.endPoint,api.postWellParameterApi,payload)
  }
}
