import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, map } from 'rxjs';

import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { GraphDataApiResponse, TempChartModel } from '../interfaces/snapshotChart.interface';
import { CustomValidators } from '../constants/regex.constants';

@Injectable({
    providedIn: 'root'
})
export class ParametricService {
    private configName: string = null;
    private ParametricSnapshotConfigurationId: number = null;

    constructor(private httpMethodSvc: HttpMethodService) { }

    public setConfigId = (id: number) => this.ParametricSnapshotConfigurationId = id;
    public setConfigName = (name: string) => this.configName = name;

    public getConfigId = () => this.ParametricSnapshotConfigurationId;
    public getConfigName = () => this.configName;

    public getParametricList(ProjectId: number): Observable<{ message: string, result: { Name: string, ParametricSnapshotConfigurationId: number }[] }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.parametricList}?ProjectId=${ProjectId}`);
    }

    public deleteParametric(payload): Observable<{ message: string, result: any }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.deleteParametric}`, payload);
    }

    public getFullResultDataById(ParametricSnapshotConfigurationId: number): Observable<{ message: string, result: { tableData: any[] } }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.parametric}/${ParametricSnapshotConfigurationId}/tableData`)
    }

    public getSummaryDataById(ParametricSnapshotConfigurationId: number): Observable<{ message: string, result: { minimum: any[], maximum: any[] } }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.parametric}/${ParametricSnapshotConfigurationId}/summary`);
    }

    public getParametricDetailById(ParametricSnapshotConfigurationId: number): Observable<{ message: string, result: any }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.parametric}/${ParametricSnapshotConfigurationId}/details`);
    }

    public postParametric(payload): Observable<{ message: string, result: { ParametricSnapshotConfigurationId: number } }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.parametric}`, payload);
    }

    // public getGraphDataById(parametricConfigurationId: number): Observable<{ message: string, result: GraphDataApiResponse }> {
    //     return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.hydraulicParametric}/${parametricConfigurationId}/graph`)
    // }

    // public mapGraphResponseToTempChartModel(data: GraphDataApiResponse) {

    // }

    public initializeForm(defaultValues) {
        return new FormGroup({
            SurveyIndex: new FormControl("", [Validators.required]),
            WellboreIndex: new FormControl("", [Validators.required]),
            DrillstringIndex: new FormControl([], [Validators.required]),
            FluidIndex: new FormControl([], [Validators.required]),
            Operation: new FormControl(2, [Validators.required]),
            DepthOfIntereset: new FormControl(defaultValues.depthOfInterest.value, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.depthOfInterest.maxRange, false)
            ]),

            isBitDepthSelected: new FormControl(false),
            bitDepthFrom: new FormControl(defaultValues.bitDepth.From, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.bitDepth.maxRange, false)
            ]),
            bitDepthTo: new FormControl(defaultValues.bitDepth.To, [CustomValidators.lessThanMax(defaultValues.bitDepth.maxRange, false)]),

            isFlowRateSelected: new FormControl(true),
            flowRateFrom: new FormControl(defaultValues.flowRate.From, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.flowRate.maxRange, false)
            ]),
            flowRateTo: new FormControl(defaultValues.flowRate.To, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.flowRate.maxRange, false)
            ]),

            isRopSelected: new FormControl(true),
            ropFrom: new FormControl(defaultValues.rop.From, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.rop.maxRange, false)
            ]),
            ropTo: new FormControl(defaultValues.rop.To, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.rop.maxRange, false)
            ]),

            isTdsSelected: new FormControl(true),
            tdsFrom: new FormControl(defaultValues.tds.From, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.tds.maxRange, false)
            ]),
            tdsTo: new FormControl(defaultValues.tds.To, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.tds.maxRange, false)
            ]),

            isSbpSelected: new FormControl(false),
            sbpFrom: new FormControl(defaultValues.sbp.From, [
                Validators.required,
                CustomValidators.lessThanMax(defaultValues.sbp.maxRange, false)
            ]),
            sbpTo: new FormControl(defaultValues.sbp.To, [CustomValidators.lessThanMax(defaultValues.sbp.maxRange, false)]),

            HoleCleaningModel: new FormControl(1, [Validators.required]),
            CuttingsMaterial: new FormControl("", [Validators.required]),
            CuttingsSize: new FormControl(6, [Validators.required]),
            CuttingsDiameter: new FormControl(defaultValues.CuttingsDiameter.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.CuttingsDiameter.From, false),
                CustomValidators.lessThanMax(defaultValues.CuttingsDiameter.To, false)
            ]),
            CuttingsDensity: new FormControl(defaultValues.CuttingsDensity.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.CuttingsDensity.From, false),
                CustomValidators.lessThanMax(defaultValues.CuttingsDensity.To, false)
            ]),
            cuttingEffect: new FormControl(false),

            MudInletTemperature: new FormControl(defaultValues.mudInletTemperature.value, [Validators.required]),
            includeToolJoinEffect: new FormControl(true),

            // independentParam: new FormControl("flowRate", [Validators.required]),
            // dependentParam: new FormControl("bitPress", [Validators.required]),
            // categoryAxis: new FormControl("rop", [Validators.required]),
        })
    }

    /* make create/update API payload from form values */
    public mapFormValuesToPayload(parametricForm: FormGroup) {
        const _experimentRangeParameters = [];
        if (parametricForm.value.Operation == 2) {
            if (parametricForm.value.isRopSelected) {
                _experimentRangeParameters.push({ Name: "ROP", From: parametricForm.value.ropFrom, To: parametricForm.value.ropTo, Step: 5 });
            } else {
                _experimentRangeParameters.push({ Name: "ROP", From: parametricForm.value.ropFrom });
            }
        }
        if (parametricForm.value.isBitDepthSelected) {
            _experimentRangeParameters.push({ Name: "Work String Depth", From: parametricForm.value.bitDepthFrom, To: parametricForm.value.bitDepthTo, Step: 5 });
        } else {
            _experimentRangeParameters.push({ Name: "Work String Depth", From: parametricForm.value.bitDepthFrom });
        }
        if (parametricForm.value.isFlowRateSelected) {
            _experimentRangeParameters.push({ Name: "Flow Rate", From: parametricForm.value.flowRateFrom, To: parametricForm.value.flowRateTo, Step: 5 });
        } else {
            _experimentRangeParameters.push({ Name: "Flow Rate", From: parametricForm.value.flowRateFrom });
        }
        if (parametricForm.value.isTdsSelected) {
            _experimentRangeParameters.push({ Name: "TDS", From: parametricForm.value.tdsFrom, To: parametricForm.value.tdsTo, Step: 5 });
        } else {
            _experimentRangeParameters.push({ Name: "TDS", From: parametricForm.value.tdsFrom });
        }
        if (parametricForm.value.isSbpSelected) {
            _experimentRangeParameters.push({ Name: "SBP", From: parametricForm.value.sbpFrom, To: parametricForm.value.sbpTo, Step: 5 });
        } else {
            _experimentRangeParameters.push({ Name: "SBP", From: parametricForm.value.sbpFrom });
        }
        return {
            SurveyIndex: parametricForm.value.SurveyIndex,
            WellboreIndex: parametricForm.value.WellboreIndex,
            DrillstringIndex: parametricForm.value.DrillstringIndex,
            FluidIndex: parametricForm.value.FluidIndex,
            Operation: parametricForm.value.Operation,
            DepthOfIntereset: parametricForm.value.DepthOfIntereset,
            experimentRangeParameters: _experimentRangeParameters,
            HoleCleaningModel: parametricForm.value.HoleCleaningModel,
            CuttingsMaterial: parametricForm.value.CuttingsMaterial,
            CuttingsDensity: parametricForm.value.CuttingsDensity,
            CuttingsSize: parametricForm.value.CuttingsSize,
            CuttingsDiameter: parametricForm.value.CuttingsDiameter,
            MudInletTemperature: parametricForm.value.MudInletTemperature,
            Name: this.configName,
            BoostFlowRate: 1, // fpr noe send as 1
            FluidReturnPath: 1, // for now send 1
            BedPorosity: 1, // for now send 1
        }
    }

    /* map apiresponse from get API to form values */
    public mapApiresponseToFormValues(apiResponseResult) {
        const _bitDepthItem = apiResponseResult.experimentRangeParameters.find(item => item.Name == "Work String Depth");
        const _ropItem = apiResponseResult.experimentRangeParameters.find(item => item.Name == "ROP");
        const _flowRateItem = apiResponseResult.experimentRangeParameters.find(item => item.Name == "Flow Rate");
        const _tdsItem = apiResponseResult.experimentRangeParameters.find(item => item.Name == "TDS");
        const _sbpItem = apiResponseResult.experimentRangeParameters.find(item => item.Name == "SBP");

        let _isBitDepthSelected = false;
        let _isFlowRateSelected = false;
        let _isTdsSelected = false;
        let _isSbpSelected = false;
        let _isRopSelected = false;
        let _bitDepthFrom = _bitDepthItem.From;
        let _flowRateFrom = _flowRateItem.From;
        let _tdsFrom = _tdsItem.From;
        let _sbpFrom = _sbpItem.From;
        let _ropFrom = "";
        let _bitDepthTo = "";
        let _flowRateTo = "";
        let _tdsTo = "";
        let _sbpTo = "";
        let _ropTo = "";

        if (_bitDepthItem.hasOwnProperty('To') && _bitDepthItem.hasOwnProperty('Step')) {
            _isBitDepthSelected = true;
            _bitDepthTo = _bitDepthItem.To;
        }
        if (_flowRateItem.hasOwnProperty('To') && _flowRateItem.hasOwnProperty('Step')) {
            _isFlowRateSelected = true;
            _flowRateTo = _flowRateItem.To;
        }
        if (_tdsItem.hasOwnProperty('To') && _tdsItem.hasOwnProperty('Step')) {
            _isTdsSelected = true;
            _tdsTo = _tdsItem.To;
        }
        if (_sbpItem.hasOwnProperty('To') && _sbpItem.hasOwnProperty('Step')) {
            _isSbpSelected = true;
            _sbpTo = _sbpItem.To;
        }

        if (apiResponseResult.Operation == 2) {
            _ropFrom = _ropItem.From;
            if (_ropItem.hasOwnProperty('To') && _ropItem.hasOwnProperty('Step')) {
                _isRopSelected = true;
                _ropTo = _ropItem.To;
            }
        }

        return {
            SurveyIndex: apiResponseResult.SurveyIndex,
            WellboreIndex: apiResponseResult.WellboreIndex,
            DrillstringIndex: apiResponseResult.DrillstringIndex,
            FluidIndex: apiResponseResult.FluidIndex,
            Operation: apiResponseResult.Operation,
            DepthOfIntereset: apiResponseResult.DepthOfIntereset,
            HoleCleaningModel: apiResponseResult.HoleCleaningModel,
            CuttingsMaterial: apiResponseResult.CuttingsMaterial,
            CuttingsDensity: apiResponseResult.CuttingsDensity,
            CuttingsSize: apiResponseResult.CuttingsSize,
            CuttingsDiameter: apiResponseResult.CuttingsDiameter,
            MudInletTemperature: apiResponseResult.MudInletTemperature,
            isBitDepthSelected: _isBitDepthSelected,
            bitDepthFrom: _bitDepthFrom,
            bitDepthTo: _bitDepthTo,
            isFlowRateSelected: _isFlowRateSelected,
            flowRateFrom: _flowRateFrom,
            flowRateTo: _flowRateTo,
            isRopSelected: _isRopSelected,
            ropFrom: _ropFrom,
            ropTo: _ropTo,
            isTdsSelected: _isTdsSelected,
            tdsFrom: _tdsFrom,
            tdsTo: _tdsTo,
            isSbpSelected: _isSbpSelected,
            sbpFrom: _sbpFrom,
            sbpTo: _sbpTo,
        }
    }

}





// const samplePayload = {
//     "updateParameters": [
//         {
//             "ParametricSnapshotConfigurationId": 1,
//             "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
//             "DrillstringIndex": "1F5FBFC3-F101-46C6-A498-4F41B1A080DC",
//             "FluidIndex": 60,
//             "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
//             "Operation": 1,
//             "FluidReturnPath": 1,
//             "CuttingsSize": 1,
//             "CuttingsDiameter": 1,
//             "CuttingsDensity": 1,
//             "BedPorosity": 1,
//             "DepthOfIntereset": 1,
//             "BoostFlowRate": 1,
//             "MudInletTemperature": 1,
//             "WellId": 9,
//             "Name": "Parameter 1",
//             "HoleCleaningModel": 1,
//             "CuttingsMaterial": 1,
//             "experimentRangeParameters": [
//                 {
//                     "Name": "TDS",
//                     "From": 20,
//                     "To": 30,
//                     "Step": 10
//                 }
//             ]
//         }
//     ],
//     "addParameters": [
//         {
//             "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
//             "DrillstringIndex": ["1F5FBFC3-F101-46C6-A498-4F41B1A080DC", "1F5FBFC3-F101-46C6-A498-4F41B1A080DC"],
//             "FluidIndex": [60, 50],
//             "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
//             "Operation": 1,
//             "FluidReturnPath": 1, // for now send 1
//             "CuttingsSize": 1,
//             "CuttingsDiameter": 1,
//             "CuttingsDensity": 1,
//             "BedPorosity": 1, // for now send 1
//             "DepthOfIntereset": 1,
//             "BoostFlowRate": 1,
//             "MudInletTemperature": 1,
//             "WellId": 9,
//             "Name": "Parameter 1",
//             "HoleCleaningModel": 1,
//             "CuttingsMaterial": 1,
//             "experimentRangeParameters": [
//                 {
//                     "Name": "TDS",
//                     "From": 20,
//                     "To": 30,
//                     "Step": 10
//                 }
//             ]
//         }
//     ]
// }
