import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OneClickConditionService {
  endPoint: string;
  public rowDataCondition: any;
  errors: any;
  constructor(private httpService: HttpClient, private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends

  /* get planning list */
  getfilterPlanningList() {

    return this.httpMethod.getMethod(this.endPoint, api.getPlanningFilterlistApi)

  }// end of function

  /* get Monitoring Condition List */
  getMonitoringConditionList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.getMonitoringPlanningConditionApi, payload)

  }// end of function

  /* get Planning Condition List */
  getPlanningConditionList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.getMonitoringPlanningConditionApi, payload)

  }// end of function

  /* get Monitoring Category List */
  getMonitoringCategoriesList(AFType: number, removeCategories: number) {
    return this.httpMethod.getMethod(this.endPoint, api.getMonitoringPlanningCategoryApi + `?ApplicationFlowType=${AFType}` + `&removeCategories=${removeCategories}`)

  }// end of function

  /* get Planning Category List */
  getPlanningCategoriesList(AFType: number, removeCategories: number) {
    return this.httpMethod.getMethod(this.endPoint, api.getMonitoringPlanningCategoryApi + `?ApplicationFlowType=${AFType}` + `&removeCategories=${removeCategories}`)

  }// end of function

  /* add condition list for Monitoring and planning */
  addUpdateConditionList(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.addUpdateMonitoringPlanningConditionApi, payload)

  }// end of function

  /* delete Monitoring */
  deleteMonitoringList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deletePlanningConditionApi, payload);
  }// end of function

  /* delete Planning */
  deletePlanningList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deletePlanningConditionApi, payload);
  }// end of function



  /* clone condition list for Monitoring and planning */
  cloneConditionList(id,payload) {
    let cloneDetailsEndpoint = api.cloneMonitoringPlanningConitionapi;
    cloneDetailsEndpoint = cloneDetailsEndpoint.replace(":DataConditionId", id);
    //console.log("cloneDetailsEndpoint-----",cloneDetailsEndpoint);

    return this.httpMethod.postMethod(this.endPoint, cloneDetailsEndpoint, payload)
  }// end of function

  saveExpression (record) {

    let payload = {
      addConditions: [],
      updateConditions: [],
    };

    if (record && record.DataConditionId) {

      payload.updateConditions.push(record);
    } else {
      
      payload.addConditions.push(record);
    } //end of if condition

    return this.httpMethod.postMethod(this.endPoint, api.postConditionsExpression, payload);
  } //end of saveExpression function

}