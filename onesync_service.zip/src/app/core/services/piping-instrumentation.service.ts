import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { HttpMethodService } from "./httpMethod.service";


@Injectable({
    providedIn:'root'
})

export class PipingInstrumentationService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Piping equipments.
     */
    getPipingEquipmentsList(){

        return this.httpMethod.getMethod(this.endPoint,api.getPipingEquipmentsApi)
    }//end of getPipingEquipmentsList

     /**
     *
     * This function will get the details of Piping equipments.
     */
     getPipingEquipmentsDetails(RigComponentId){

        return this.httpMethod.getMethod(this.endPoint,api.getPipingEquipmentsDetailsApi+RigComponentId)
    }//end of getPipingEquipmentsList

     /**
     *
     * This function will update the details of Piping equipments.
     */
     updatePipingEquipmentsDetails(RigComponentId,payload){

        return this.httpMethod.putMethod(this.endPoint,api.updatePipingEquipmentsDetailsApi+RigComponentId,payload)
    }//end of updatePipingEquipmentsList

}//end of class