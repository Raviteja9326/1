import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { Observable, map } from 'rxjs';
import { HydraulicSnapshotListItem } from '../interfaces/hydraulic-snapshot.interface';
import { SectionsInterface } from '../interfaces/sections.interface ';
import { ProfileSnapshotInterface } from '../interfaces/profileSnapshot.interface';
import { SplitFlowInterface } from '../interfaces/splitFlow.interface';
import { CompareItemInterface } from '../interfaces/compareItem.interface';
import { GraphDataApiResponse, LeftPanelTableModel, HydraulicSnapshotMShearModel, TempChartModel } from '../interfaces/snapshotChart.interface';
import { Column } from '../interfaces/column.interface';

@Injectable({
    providedIn: 'root'
})
export class HydraulicsSnapshotService {
    private snapshotConfigName: string = null;
    private snapshotConfigId: number = null;
    private activeUnitLabels: any = {};

    constructor(private httpMethod: HttpMethodService) { }

    public setConfigId = (id: number) => this.snapshotConfigId = id;
    public setConfigName = (name: string) => this.snapshotConfigName = name;
    public setActiveUnitLabels = (activeUnitLabels: any) => this.activeUnitLabels = activeUnitLabels;

    public getConfigId = () => this.snapshotConfigId;
    public getConfigName = () => this.snapshotConfigName;
    public getActiveUnitLabels = () => this.activeUnitLabels;

    public getWellIntervalList(ProjectId: number): Observable<{ message: string, result: any[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWellIntervalApi}?ProjectId=${ProjectId}`)
    }

    public getWellPathList(ProjectId: number): Observable<{ message: string, result: any[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWellPathsApi}?ProjectId=${ProjectId}`)
    }

    public getWorkstringList(ProjectId: number): Observable<{ message: string, result: any[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkstringApi}/${ProjectId}`)
    }

    public getFluidsList(ProjectId: number): Observable<{ message: string, result: any[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getFluidsDetails}?ProjectId=${ProjectId}`)
    }

    public getCasingCalculate(wellboreSectionId: number): Observable<{ message: string, result: { BitDepth: number, DepthOfIntereset: number, cuttingMaterial: { Id: number, Name: string, Density?: number }[] } }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.addWellIntervalApi}${wellboreSectionId}/casing/calculate`);
    }

    public getDrillListHydraulics(drillstringHeaderId: number): Observable<{ message: string, result: { DifferentialPressureAtBottom: number, PointOfInterest: { DrillstringComponentId: number, Name: string }[] } }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkstringApisecondstage}${drillstringHeaderId}/hydraulics`);
    }

    public getHydraulicSnapshotList(ProjectId: number): Observable<{ message: string, result: HydraulicSnapshotListItem[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getHydraulicSnapshotList}?ProjectId=${ProjectId}`);
    }

    public postHydraulicSnapshot(data): Observable<{ message: string, result: { SnapshotConfigurationId: number } }> {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}`, data);
    }

    public deleteHydraulicSnapshots(data) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.deleteHydraulicSnapshots}`, data);
    }

    public getHydraulicSnapshotDetailsById(snapshotConfigurationId: number): Observable<{ message: string, result: HydraulicSnapshotListItem }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/details`);
    }

    public postMShearData(snapshotConfigurationId: number) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/MShearData`, {});
    }

    public getMShearDetailsById(snapshotConfigurationId: number): Observable<{ message: string, result: HydraulicSnapshotMShearModel }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/MShear/details`);
    }

    public getHydraulicSnapshotProfilesById(snapshotConfigurationId: number): Observable<{ message: string, result: ProfileSnapshotInterface[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/profiles`);
    }

    public getHydraulicSnapshotSectionsById(snapshotConfigurationId: number): Observable<{ message: string, result: SectionsInterface[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/sections`);
    }

    public cloneSnapshot(snapshotConfigurationId: number): Observable<{ message: string, result: any }> {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/clone`, {});
    }

    public deleteSnapshot(payload): Observable<{ message: string, result: any }> {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/delete`, payload);
    }

    public getHydraulicSnapshotSplitFlowComponentById(snapshotConfigurationId: number): Observable<{ message: string, result: SplitFlowInterface[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/splitFlowComponets`);
    }

    public getHydraulicSnapshotComparisonList(): Observable<{ message: string, result: CompareItemInterface[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getHydraulicSnapshotComparisonList}`);
    }

    public getHydraulicSnapshotGraphTableDataById(snapshotConfigurationId: number): Observable<{ message: string, result: { tableData: any[] } }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/graphTableView`);
    }

    public getGraphDataById(snapshotConfigurationId: number): Observable<{ message: string, result: GraphDataApiResponse }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/graph`)
    }

    public getAdditionalGraphDataById(snapshotConfigurationId: number, payload: any): Observable<{ message: string, result: GraphDataApiResponse }> {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postHydraulicSnapshotList}/${snapshotConfigurationId}/graph/additionalData`, payload)
    }

    public getSplitflowComponentList(DrillstringIndex: string, Operation: number): Observable<{ message: string, result: LeftPanelTableModel[] }> {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getSplitflowComponentList}?DrillstringIndex=${DrillstringIndex}&Operation=${Operation}`)
    }

    public mapGraphResponseToTempChartModel(data: GraphDataApiResponse) {
        const _tempChartData: TempChartModel = {
            velocity: {
                datasetMax: Math.max(
                    Math.max(...data.velocity.map(x => x.PipeVelocity)),
                    Math.max(...data.velocity.map(x => x.AnnularVelocity))
                ),
                datasetMin: Math.min(
                    Math.min(...data.velocity.map(x => x.PipeVelocity)),
                    Math.min(...data.velocity.map(x => x.AnnularVelocity))
                ),
                datasets: [
                    {
                        data: data.velocity.map(x => x.PipeVelocity),
                        label: "Pipe Velocity, ft.min",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.velocity.map(x => x.AnnularVelocity),
                        label: "Ann Velocity, ft/min",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.velocity.map(x => x.MeasuredDepth)),
                labels: data.velocity.map(x => x.MeasuredDepth)
            },
            ecd: {
                datasetMax: Math.max(
                    Math.max(...data.ECD.map(x => x.EquivalentStaticDensity)),
                    Math.max(...data.ECD.map(x => x.EquivalentCirculatingDensity)),
                    Math.max(...data.ECD.map(x => x.EquivalentCirculatingDensityPlusCuttings))
                ),
                datasetMin: Math.min(
                    Math.min(...data.ECD.map(x => x.EquivalentStaticDensity)),
                    Math.min(...data.ECD.map(x => x.EquivalentCirculatingDensity)),
                    Math.min(...data.ECD.map(x => x.EquivalentCirculatingDensityPlusCuttings))
                ),
                datasets: [
                    {
                        data: data.ECD.map(x => x.EquivalentStaticDensity),
                        label: "ESD, ppg",
                        backgroundColor: "Gray",
                        borderColor: "Gray",
                        borderWidth: 1
                    },
                    {
                        data: data.ECD.map(x => x.EquivalentCirculatingDensity),
                        label: "ECD, ppg",
                        backgroundColor: "#90EE90",
                        borderColor: "#90EE90",
                        borderWidth: 1
                    },
                    {
                        data: data.ECD.map(x => x.EquivalentCirculatingDensityPlusCuttings),
                        label: "ECD+Cuttings, ppg",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.ECD.map(x => x.MeasuredDepth)),
                labels: data.ECD.map(x => x.MeasuredDepth),
            },
            temperature: {
                datasetMax: Math.max(
                    Math.max(...data.temperature.map(x => x.PipeTemperature)),
                    Math.max(...data.temperature.map(x => x.AnnulusTemperature)),
                    Math.max(...data.temperature.map(x => x.FormationTemperature))
                ),
                datasetMin: Math.min(
                    Math.min(...data.temperature.map(x => x.PipeTemperature)),
                    Math.min(...data.temperature.map(x => x.AnnulusTemperature)),
                    Math.min(...data.temperature.map(x => x.FormationTemperature))
                ),
                datasets: [
                    {
                        data: data.temperature.map(x => x.PipeTemperature),
                        label: "Pipe Temperature, °F",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    },
                    {
                        data: data.temperature.map(x => x.AnnulusTemperature),
                        label: "Annulus Temperature, °F",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    },
                    {
                        data: data.temperature.map(x => x.FormationTemperature),
                        label: "Formation Temperature, °F",
                        backgroundColor: "Green",
                        borderColor: "Green",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.temperature.map(x => x.MeasuredDepth)),
                labels: data.temperature.map(x => x.MeasuredDepth),
            },
            holeCleaning: {
                datasetMax: Math.max(
                    Math.max(...data.HoleCleaning.map(x => x.Cuttings)),
                    Math.max(...data.HoleCleaning.map(x => x.BedHeight))
                ),
                datasetMin: Math.min(
                    Math.min(...data.HoleCleaning.map(x => x.Cuttings)),
                    Math.min(...data.HoleCleaning.map(x => x.BedHeight))
                ),
                datasets: [
                    {
                        data: data.HoleCleaning.map(x => x.Cuttings),
                        label: "Cuttings, %",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    },
                    {
                        data: data.HoleCleaning.map(x => x.BedHeight),
                        label: "Bed Height, in",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.HoleCleaning.map(x => x.MeasuredDepth)),
                labels: data.HoleCleaning.map(x => x.MeasuredDepth),
            },
            pressure: {
                datasetMax: Math.max(
                    Math.max(...data.pressure.map(x => x.DrillStringPressure)),
                    Math.max(...data.pressure.map(x => x.AnnularPressure)),
                    Math.max(...data.pressure.map(x => x.PPP)),
                    Math.max(...data.pressure.map(x => x.WBS)),
                    Math.max(...data.pressure.map(x => x.FP))
                ),
                datasetMin: Math.min(
                    Math.min(...data.pressure.map(x => x.DrillStringPressure)),
                    Math.min(...data.pressure.map(x => x.AnnularPressure)),
                    Math.min(...data.pressure.map(x => x.PPP)),
                    Math.min(...data.pressure.map(x => x.WBS)),
                    Math.min(...data.pressure.map(x => x.FP))
                ),
                datasets: [
                    {
                        data: data.pressure.map(x => x.DrillStringPressure),
                        label: "DS Pressure, psi",
                        backgroundColor: "Gray",
                        borderColor: "Gray",
                        borderWidth: 1
                    },
                    {
                        data: data.pressure.map(x => x.AnnularPressure),
                        label: "Ann Pressure, psi",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    },
                    {
                        data: data.pressure.map(x => x.PPP),
                        label: "PPP, psi",
                        backgroundColor: "yellow",
                        borderColor: "yellow",
                        borderWidth: 1
                    },
                    {
                        data: data.pressure.map(x => x.WBS),
                        label: "WBS, psi",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.pressure.map(x => x.FP),
                        label: "FP, psi",
                        backgroundColor: "blue",
                        borderColor: "blue",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.pressure.map(x => x.MeasuredDepth)),
                labels: data.pressure.map(x => x.MeasuredDepth),
            },
            ctr: {
                datasetMax: Math.max(...data.CTR.map(x => x.CuttingsTransportRatio)),
                datasetMin: Math.min(...data.CTR.map(x => x.CuttingsTransportRatio)),
                datasets: [
                    {
                        data: data.CTR.map(x => x.CuttingsTransportRatio),
                        label: "CTR, %",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.CTR.map(x => x.MeasuredDepth)),
                labels: data.CTR.map(x => x.MeasuredDepth),
            }
        }
        return _tempChartData;
    }

    public mapAdditionalGraphResponseToTempChartModel(data: GraphDataApiResponse) {
        const _tempChartData: TempChartModel = {
            inclination: {
                datasetMax: Math.max(...data.inclination.map(x => x.Inclination)),
                datasetMin: Math.min(...data.inclination.map(x => x.Inclination)),
                datasets: [
                    {
                        data: data.inclination.map(x => x.Inclination),
                        label: "Inclination",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.inclination.map(x => x.MeasuredDepth)),
                labels: data.inclination.map(x => x.MeasuredDepth),
            },
            rheology: {
                datasetMax: Math.max(
                    Math.max(...data.rheology.map(x => x.PlasticViscosity)),
                    Math.max(...data.rheology.map(x => x.LowShearYieldPoint)),
                    Math.max(...data.rheology.map(x => x.YieldPoint))
                ),
                datasetMin: Math.min(
                    Math.min(...data.rheology.map(x => x.PlasticViscosity)),
                    Math.min(...data.rheology.map(x => x.LowShearYieldPoint)),
                    Math.min(...data.rheology.map(x => x.YieldPoint))
                ),
                datasets: [
                    {
                        data: data.rheology.map(x => x.PlasticViscosity),
                        label: "Plastic velocity",
                        backgroundColor: "Gray",
                        borderColor: "Gray",
                        borderWidth: 1
                    },
                    {
                        data: data.rheology.map(x => x.LowShearYieldPoint),
                        label: "Low shear yield point",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    },
                    {
                        data: data.rheology.map(x => x.YieldPoint),
                        label: "Yield point",
                        backgroundColor: "yellow",
                        borderColor: "yellow",
                        borderWidth: 1
                    },
                ],
                labelMax: Math.max(...data.rheology.map(x => x.MeasuredDepth)),
                labels: data.rheology.map(x => x.MeasuredDepth),
            },
            diffPress: {
                datasetMax: Math.max(
                    Math.max(...data.differentialPressure.map(x => x.Burst)),
                    Math.max(...data.differentialPressure.map(x => x.Collapse)),
                    Math.max(...data.differentialPressure.map(x => x.DifferentialPressure))
                ),
                datasetMin: Math.min(
                    Math.min(...data.differentialPressure.map(x => x.Burst)),
                    Math.min(...data.differentialPressure.map(x => x.Collapse)),
                    Math.min(...data.differentialPressure.map(x => x.DifferentialPressure))
                ),
                datasets: [
                    {
                        data: data.differentialPressure.map(x => x.Burst),
                        label: "Burst",
                        backgroundColor: "Gray",
                        borderColor: "Gray",
                        borderWidth: 1
                    },
                    {
                        data: data.differentialPressure.map(x => x.Collapse),
                        label: "Collapse",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    },
                    {
                        data: data.differentialPressure.map(x => x.DifferentialPressure),
                        label: "DifferentialPressure",
                        backgroundColor: "yellow",
                        borderColor: "yellow",
                        borderWidth: 1
                    },
                ],
                labelMax: Math.max(...data.differentialPressure.map(x => x.MeasuredDepth)),
                labels: data.differentialPressure.map(x => x.MeasuredDepth),
            }
        }
        return _tempChartData;
    }

    public setTableHeaderActiveUnitLabel(tableColumns: Column[]): Column[] {
        for (const item of tableColumns) {
            if (item.unitType == "length")
                item.header = item.header + ", " + this.activeUnitLabels.lengthLabel;
            if (item.unitType == "velocityFluid")
                item.header = item.header + ", " + this.activeUnitLabels.velocityFluidLabel;
            if (item.unitType == "angle")
                item.header = item.header + ", " + this.activeUnitLabels.angleLabel;
            if (item.unitType == "pressure")
                item.header = item.header + ", " + this.activeUnitLabels.pressureLabel;
            if (item.unitType == "viscosity")
                item.header = item.header + ", " + this.activeUnitLabels.viscosityLabel;
            if (item.unitType == "yieldPoint")
                item.header = item.header + ", " + this.activeUnitLabels.yieldPointLabel;
            if (item.unitType == "density")
                item.header = item.header + ", " + this.activeUnitLabels.densityLabel;
            if (item.unitType == "temperature")
                item.header = item.header + ", " + this.activeUnitLabels.temperatureLabel;
            if (item.unitType == "percentage")
                item.header = item.header + ", " + this.activeUnitLabels.percentageLabel;
            if (item.unitType == "shortLength")
                item.header = item.header + ", " + this.activeUnitLabels.shortLengthLabel;
            if (item.unitType == "nozzleSize")
                item.header = item.header + ", " + this.activeUnitLabels.nozzleSizeLabel;
            if (item.unitType == "force")
                item.header = item.header + ", " + this.activeUnitLabels.forceLabel;
            if (item.unitType == "power")
                item.header = item.header + ", " + this.activeUnitLabels.powerLabel;
            if (item.unitType == "intensity")
                item.header = item.header + ", " + this.activeUnitLabels.intensityLabel;
            if (item.unitType == "flow")
                item.header = item.header + ", " + this.activeUnitLabels.flowLabel;
            if (item.unitType == "volume")
                item.header = item.header + ", " + this.activeUnitLabels.volumeLabel;
            if (item.unitType == "torque")
                item.header = item.header + ", " + this.activeUnitLabels.torqueLabel;
            if (item.unitType == "stress")
                item.header = item.header + ", " + this.activeUnitLabels.stressLabel;
            if (item.unitType == "acceleration")
                item.header = item.header + ", " + this.activeUnitLabels.accelerationLabel;
            if (item.unitType == "time")
                item.header = item.header + ", " + this.activeUnitLabels.timeLabel;
            if (item.unitType == "velocityRunningSpeed")
                item.header = item.header + ", " + this.activeUnitLabels.velocityRunningSpeedLabel;
            if (item.unitType == "penetrationRate")
                item.header = item.header + ", " + this.activeUnitLabels.penetrationRateLabel;
            if (item.unitType == "rotationVelocity")
                item.header = item.header + ", " + this.activeUnitLabels.rotationVelocityLabel;
        }
        return tableColumns;
    }

}

const payload = {

    // "addSnapshots": [{
    //         "Name": "Snapshot 1",
    //         "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
    //         "DrillstringIndex": "1F5FBFC3-F101-46C6-A498-4F41B1A080DC",
    //         "FluidIndex": 58,
    //         "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
    //         "ReservoirZones": 1(for now send always as 1),
    //         "FluidReturnPath": 1,
    //         "BitDepth": 1(refering to work string depth field in UI),
    //         "Operation": 1,
    //         "SurfaceBackPressure": 1(refering to SBP field in UI),
    //         "WSTool" : "Custom"(refering to work string tool dropdown value in UI),
    //         "CuttingsSize": 1,
    //         "CuttingsDiameter": 1,
    //         "CuttingsDensity": 1,
    //         "BedPorosity": 1(always 1),
    //         "DepthOfIntereset": 435.28,
    //         "FlowRate" : 1,
    //         "RotarySpeed": 1(refering to TDS field in UI),
    //         "RateOfPenetration": 1(refering to ROP field in UI),
    //         "MudInletTemperature": 1,
    //         "MudOutletTemperature": 1,
    //         "IncludeToolJointEffect" : 1,
    //         "IncludeEccentricity" : 1,
    //         "BottomHoleTemperature" : 1,
    //         "IsUBD" : 0(always 0),
    //         "WellId": 9,
    //         "SnapshotAnalisysOutputGraphXML": 1,
    //         "HoleCleaningModel" : 1,
    //         "CuttingsMaterial" : 1,
    //         "WSEnd" : 0,
    //         "PointOfInterest": "Stabilizer test by siva",
    //         "PlugDepth" : 0(this field will be enabled when we select operation as Injection Annulus, production annulus),
    //         "DifferentialPressureAtBottom" : 1(this field will be enabled when we select operation as Drilling

    //         }],
    // "updateSnapshots" : [{

    //         }]




    //    Details api
    // "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
    // "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
    // "DrillstringIndex": "1F5FBFC3-F101-46C6-A498-4F41B1A080DC",
    // "FluidIndex": 58,
    // "DepthOfIntereset": 435.28,
    // "BitDepth": 1,
    // "PointOfInterest": "Stabilizer test by siva",
    // "DifferentialPressureAtBottom": null,
    // "CuttingsMaterial": 1,
    // "MudInletTemperature": 1,
    // "MudOutletTemperature": 1,
    // "BottomHoleTemperature": 1,
    // "FlowRate": 1,
    // "RotarySpeed": 1,
    // "SurfaceBackPressure": 1,
    // "CuttingsSize": 1,
    // "RateOfPenetration": 1,
    // "CuttingsDiameter": 1,
    // "CuttingsDensity": 1,
    // "IncludeToolJointEffect": true,
    // "IncludeEccentricity": true,
    // "HoleCleaningModel": 1,
    // "Operation": 1,
    // "WSTool": "Custom",
    // "PlugDepth": 0,



    // "ConfigurationId": null,
    // "PipeSurfacePressure": null,
    // "HoleCleaningDOI": null,
    // "FluidReturnPath": 1,
    // "WSEnd": 0,
    // "WellId": 9,
    // "SnapshotAnalisysOutputGraphXML": {
    //   "type": "Buffer",
    //   "data": [
    //     0,
    //     0,
    //     0,
    //     1
    //   ]
    // },
    // "ExperimentGroup": null,
    // "GasInjectionRate": null,
    // "LiquidInjectionRate": null,
    // "SelectedColorMap": null,
    // "SnapshotConfigurationId": 1,
    // "Name": "Snapshot 1",
    // "PerfDepth": null,
    // "GasFlowRate": null,
    // "BoostFlowRate": null,
    // "WellboreIndexName": null,
    // "SurveyIndexName": null,
    // "DrillstringIndexName": null,
    // "FluidIndexName": "Mineral Oil Base, 23 ppg"
    // "SandMeshSize": null,
    // "SandConcentration": null,

}
