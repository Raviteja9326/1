/*This is well paths service, to write functions for API call of materials catalog
*/
import { Injectable } from '@angular/core';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
@Injectable({
  providedIn: 'root'
})
export class WellPathsService {
  endPoint: string;

  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends


  /* get wellpaths list */
  getWellPathsList(data) {
    return this.httpMethod.getMethod(this.endPoint, api.getWellPathsApi + `?ProjectId=${data}`)
  }// end of function

  /* add wellpaths */
  addWellPathsList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.addWellPathsApi, payload)
  }// end of function

  /* activate wellpaths */
  activateWellpathsList(statusHeaderId: number, payload) {
    return this.httpMethod.putMethod(this.endPoint, api.ActivewellPathsAPi + `${statusHeaderId}/status`, payload);
  }// end of function

  /* update wellpaths */
  updateWellpathsList(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateWellPathsApi, payload);
  }// end of function

  /* delete wellpaths */
  deleteWellpathsList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteWellPathApi, payload);
  }// end of function

  /* calculations wellpaths */
  calculationsWellpathsList(payload, name, method) {
    return this.httpMethod.postMethod(this.endPoint, api.calculationsWellPathApi + '?name=' + `${name}&&methodType=${method}`, payload);
  }// end of function

  /* survey points wellpaths */
  getSurveyPointsList(wellpath, trajectoryPath) {
    return this.httpMethod.getMethod(this.endPoint, api.getSurveyPointsApi + "/" + wellpath + "/" + trajectoryPath);
  }// end of function

  addSurveyPointsList(payload) {
    //console.log(payload)
    return this.httpMethod.postMethod(this.endPoint, api.addSurveyPointApi, payload);
  }

  updateSurveyPointsList(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateSurveyPointApi, payload);
  }

  deleteSurveyPointsList(payload,data) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteSurveyPointApi + `/${data}`, payload);
  }

}