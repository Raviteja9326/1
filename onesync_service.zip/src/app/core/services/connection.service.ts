import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class ConnectionService {

  endPoint: string;

  constructor(private httpMethod:HttpMethodService){

     this.endPoint = `${api.serviceEndpoint}`;
  }

//Function to fetch connection list
  getConnectionList(precision?, type?) {
    if(type)
      return this.httpMethod.getMethod(this.endPoint,`${api.getConnectionsApi}?precision=${precision==false?0:1}&type=${type}`);
    return this.httpMethod.getMethod(this.endPoint,`${api.getConnectionsApi}?precision=${precision==false?0:1}`);
  }

  getConnectionDrillPipeList(ObjConn) {
    return this.httpMethod.getMethod(this.endPoint,`${api.getWSDPConnectionListApi}/${ObjConn.toolSizeId}?&NominalWeight=${ObjConn.NW}&GradeAndUpsetType=${ObjConn.GAU}&ConnectionId=1&Range=${ObjConn.Range}`)
  }

  getConnectionDropdownList() {

    return this.httpMethod.getMethod(this.endPoint,api.getConnectionsDropdown)
  }

  
}
