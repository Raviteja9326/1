import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { retry, timeout } from "rxjs/operators";
import { HttpMethodService } from "./httpMethod.service";

@Injectable({
    providedIn:'root'
})

export class FormationsService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){
        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Formations Source Types.
     */
    getFormationsSourceTypeList(){

        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.getMethod(this.endPoint,api.getFormationsSourceType);
    }//end of getFormationsSourceTypeList
    /**
         *
         * This function will get the list of Formations Source Types.
         */
    getFormationsDefaultRow(ProjectId?) {

        let token = sessionStorage.getItem('token');
        let reqHeader = new HttpHeaders({ 'Authorization': `Bearer ${token}` })
        return this.httpMethod.getMethod(this.endPoint, api.getFormationsDefaultRow+"?ProjectId="+ProjectId);
    }//end of getFormationsSourceTypeList
    /**
     *
     * This function will get the list of Formations.
     */
    getFormationsList(sourceType, ProjectId){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.getMethod(this.endPoint,api.getFormationsApi+"?typeId="+sourceType+"&ProjectId="+ProjectId)
    }//end of getFormationsList

    saveFormationsList(payload){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.postMethod(this.endPoint,api.saveFormationsApi,payload);
    }//end of updateFormationsList

    deleteFormationsList(payload){
        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`});
        return this.httpMethod.postMethod(this.endPoint,api.deleteFormationsApi,payload);
    }//end of deleteFormationsList

    getActiveSurveys(){
        return this.httpMethod.getMethod(this.endPoint,api.getActiveSurveys);
    }
    /**
     * Below code will be removed later. It is just a temporary adjustment
     */

    loginApiCall() {

        return this.httpMethod.getMethod(this.endPoint,"/api/v1/login/verifyUser?email=admin@birlasoft.com&password=Admin123@123");


      }

      CalculateMD(activeSurveys, AirgapAndWaterDepth){
        if (activeSurveys == null || activeSurveys.length < 2)
        return [AirgapAndWaterDepth];

        var result = [];

    let Y1 = 0;
    let Y2 = 0;
    let dMD = 0;
    let h = 0;

    let hit:boolean = false;

    for (let i = 0; i < activeSurveys.length - 1; i++)
    {
        h = activeSurveys[i + 1].MeasuredDepth - activeSurveys[i].MeasuredDepth;
        Y1 = activeSurveys[i].TrueVerticalDepth;
        Y2 = activeSurveys[i + 1].TrueVerticalDepth;

        if (Y1 < Y2 && (Y1 <= AirgapAndWaterDepth) && (Y2 >= AirgapAndWaterDepth))
        {
            dMD = (AirgapAndWaterDepth - Y1) / (Y2 - Y1) * h;
            result.push(activeSurveys[i].MeasuredDepth + dMD);
            hit = true;
        }

        if (Y1 > Y2 && (Y1 >= AirgapAndWaterDepth) && (Y2 <= AirgapAndWaterDepth))
        {
            dMD = (Y1 - AirgapAndWaterDepth) / (Y1 - Y2) * h;
            result.push(activeSurveys[i].MeasuredDepth + dMD);
            hit = true;
        }
    }

    if (Y1 < Y2 && !hit)
    {
        dMD = (AirgapAndWaterDepth - Y1) / (Y2 - Y1) * h;
        result.push(activeSurveys[activeSurveys.length - 2].MeasuredDepth + dMD);
    }

    if (Y1 >= Y2 && !hit)
    {
        dMD = AirgapAndWaterDepth - Y2;
        result.push(activeSurveys[activeSurveys.length - 1].MeasuredDepth + dMD);
    }

    return result;

      }

      CalculateTVD(activeSurveys,AirgapAndWaterDepth){
        let tvd = 0;

            var points = activeSurveys;

            try
            {
                if (activeSurveys.length >= 2)
                {
                    let IsFind:boolean = false;
                    for (let i = 1; i < activeSurveys.length; i++)
                    {
                        if (AirgapAndWaterDepth <= activeSurveys[i].MeasuredDepth)
                        {
                            let ac = AirgapAndWaterDepth - activeSurveys[i - 1].MeasuredDepth;
                            let cb = activeSurveys[i].MeasuredDepth - AirgapAndWaterDepth;
                            let delta = cb == 0 ? 1 : ac / cb;

                            tvd = cb == 0 ? activeSurveys[i].TrueVerticalDepth : (points[i - 1].TrueVerticalDepth + delta * points[i].TrueVerticalDepth) / (1 + delta);
                            IsFind = true;
                            break;
                        }
                    }
                    if (!IsFind && AirgapAndWaterDepth > points[points.length-1].MeasuredDepth)
                {
                        let indexLast = activeSurveys.length - 1;
                        let ac = AirgapAndWaterDepth - points[indexLast - 1].MeasuredDepth;
                        let cb = points[indexLast].MeasuredDepth - AirgapAndWaterDepth;
                        let delta = cb == 0 ? 1 : ac / cb;
                        tvd = (activeSurveys[indexLast - 1].TrueVerticalDepth + delta * points[indexLast].TrueVerticalDepth) / (1 + delta);
                    }
                }
            }
            catch { }

            return Number(tvd);

      }
mdCalculation(){
    return this.httpMethod.getMethod(this.endPoint,api.mdCalculationApi);
}


getapiKicklossZone(dynamiclist, formvalidationlist) {
    let errorEncountered = false;
    let errormsg:string = undefined;
    dynamiclist?.forEach((res, i) => {
      console.log(res);
      if (formvalidationlist?.Porosity <= 0.0) {
        return errormsg = "The porosity of the formation that contains the kick/loss zone "+ (i + 1) + " must be positive.";
       } 
      else if (formvalidationlist?.Permeability <= 0.0) {
        return errormsg = "The permeability of the formation that contains the kick/loss zone " + (i + 1) + " must be positive.";
       } 
      else if (formvalidationlist?.PorePressureGradient <= 0.0) {
         return errormsg = "The pore pressure gradient of the formation that contains the kick/loss zone " + (i + 1) + " must be positive.";
       }
      else if (Number(res.MeasuredDepth) <= 0.0) {
        errorEncountered = true;
       return errormsg = "The depth of the kick/loss zone " + (i + 1) + " must be positive.";
      } else if (Number(res.DrainOffRadius) <= 0.0) {
        errorEncountered = true;
       return errormsg = "The drain off radius of the kick/loss zone " + (i + 1) + " must be positive.";
      } else if (Number(res.Length) <= 0.0) {
        errorEncountered = true;
        return errormsg = "The height of the kick/loss zone " + (i + 1) + " must be positive.";
      } else if (Number(res.ReservoirFluidDensity) <= 0.0) {
        errorEncountered = true;
        return errormsg = "The fluid sg of the kick/loss zone " + (i + 1) + " must be positive.";
      }
    });
    return errormsg;
  }
      
}//end of class