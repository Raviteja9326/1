import { Injectable } from '@angular/core';
import {api} from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class TortuosityService {

  endPoint: string;

  constructor(private httpMethod:HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }


 

postTortuosity(tortuosityData){
   
  return this.httpMethod.postMethod(this.endPoint,api.applyTortuosityApi,tortuosityData)

}

  getTortuosityList(surveyHeaderId) {

    let tortuosityEndpoint = api.getTortuosityApi;
    tortuosityEndpoint = tortuosityEndpoint.replace("{surveyHeaderId}", surveyHeaderId);

    return this.httpMethod.getMethod(this.endPoint,tortuosityEndpoint)
  }

  updateTortuosity(payload){
 
    return this.httpMethod.putMethod(this.endPoint,api.updateTortuosityApi,payload);
  }

  deleteTortuosity (SurveyTortuosityId) {

    let deleteEndpoint = api.deleteTortuosityAPi;
    deleteEndpoint = deleteEndpoint.replace(":SurveyTortuosityId", SurveyTortuosityId);
    return this.httpMethod.deleteMethod(this.endPoint, deleteEndpoint);
} //end of deleteTemperatureRecord function
}
