import { Injectable } from "@angular/core";
import { Observable, map } from 'rxjs';
import { HttpMethodService } from './httpMethod.service';
import { api } from "../constants/api.constants";
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BitOptDataBrowserModel, BitOptSummaryModel } from "../interfaces/bitHydraulicsOpt.interface";
import { CustomValidators } from "../constants/regex.constants";

@Injectable({ providedIn: "root" })
export class BitHydraulicsService {
    private bitOptimizationName: string = null;
    private BitHydraulicsOptimizationConfigurationId: number = null;

    constructor(private httpMethodSvc: HttpMethodService) { }

    public setConfigId = (id: number) => this.BitHydraulicsOptimizationConfigurationId = id;
    public setConfigName = (name: string) => this.bitOptimizationName = name;

    public getConfigId = () => this.BitHydraulicsOptimizationConfigurationId;
    public getConfigName = () => this.bitOptimizationName;

    public postBitOptimization(payload): Observable<{ message: string, result: { BitHydraulicsOptimizationConfigurationId: number } }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.bitOptimization}`, payload);
    }

    public getBitOptimizationList(ProjectId: number): Observable<{ message: string, result: { Name: string, BitHydraulicsOptimizationConfigurationId: number }[] }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.bitOptimizationList}?ProjectId=${ProjectId}`);
    }

    public deleteBitOptimizations(payload: { deletedIds: number[] }): Observable<{ message: string, result: any }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.deleteBitOptimizations}`, payload);
    }

    public getBitOptimizationTableDataById(BitHydraulicsOptimizationConfigurationId: number): Observable<{ message: string, result: { tableData: BitOptDataBrowserModel[] } }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.bitOptimization}/${BitHydraulicsOptimizationConfigurationId}/tableData`);
    }

    public getSummaryDataById(BitHydraulicsOptimizationConfigurationId: number): Observable<{ message: string, result: BitOptSummaryModel[] }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.bitOptimization}/${BitHydraulicsOptimizationConfigurationId}/summary`);
    }

    public getBitOptimizationDetailById(BitHydraulicsOptimizationConfigurationId: number): Observable<{ message: string, result: any }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.bitOptimization}/${BitHydraulicsOptimizationConfigurationId}/details`);
    }

    public initializeForm(defaultValues) {
        return new FormGroup({
            SurveyIndex: new FormControl("", [Validators.required]),
            WellboreIndex: new FormControl("", [Validators.required]),
            DrillstringIndex: new FormControl("", [Validators.required]),
            FluidIndex: new FormControl("", [Validators.required]),
            DesiredPumpPressure: new FormControl(defaultValues.DesiredPumpPressure.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.DesiredPumpPressure.from, false),
                CustomValidators.lessThanMax(defaultValues.DesiredPumpPressure.to, false)
            ]),
            DesiredRateOfPenetration: new FormControl(defaultValues.DesiredRateOfPenetration.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.DesiredRateOfPenetration.from, false),
                CustomValidators.lessThanMax(defaultValues.DesiredRateOfPenetration.to, false)
            ]),
            MinAnnularVelocity: new FormControl("", [Validators.required]),
            MinBitTFA: new FormControl(defaultValues.MinBitTFA.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.MinBitTFA.from, false),
                CustomValidators.lessThanMax(defaultValues.MinBitTFA.to, false)
            ]),
            MaxNumberOfNozzles: new FormControl(6, [
                Validators.required,
                CustomValidators.greaterThanMin(1, false),
                CustomValidators.lessThanMax(16, false)
            ]),
            RotarySpeed: new FormControl(defaultValues.RotarySpeed.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.RotarySpeed.from, false),
                CustomValidators.lessThanMax(defaultValues.RotarySpeed.to, false)
            ]),
            DepthOfIntereset: new FormControl(defaultValues.DepthOfIntereset.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.DepthOfIntereset.from, false),
                CustomValidators.lessThanMax(defaultValues.DepthOfIntereset.to, false)
            ]),
            MudInletTemperature: new FormControl(defaultValues.MudInletTemperature.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.MudInletTemperature.from, false),
                CustomValidators.lessThanMax(defaultValues.MudInletTemperature.to, false)
            ]),
            CuttingsSize: new FormControl(6, [Validators.required]),
            CuttingsMaterial: new FormControl("", [Validators.required]),
            CuttingsDiameter: new FormControl(defaultValues.CuttingsDiameter.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.CuttingsDiameter.from, false),
                CustomValidators.lessThanMax(defaultValues.CuttingsDiameter.to, false)
            ]),
            CuttingsDensity: new FormControl(defaultValues.CuttingsDensity.value, [
                Validators.required,
                CustomValidators.greaterThanMin(defaultValues.CuttingsDensity.from, false),
                CustomValidators.lessThanMax(defaultValues.CuttingsDensity.to, false)
            ]),
        })
    }

    public mapFormValuesToPayload(bitOptimizationForm: FormGroup) {
        return {
            SurveyIndex: bitOptimizationForm.value.SurveyIndex,
            WellboreIndex: bitOptimizationForm.value.WellboreIndex,
            DrillstringIndex: bitOptimizationForm.value.DrillstringIndex,
            FluidIndex: bitOptimizationForm.value.FluidIndex,
            DesiredPumpPressure: bitOptimizationForm.value.DesiredPumpPressure,
            DesiredRateOfPenetration: bitOptimizationForm.value.DesiredRateOfPenetration,
            MinAnnularVelocity: bitOptimizationForm.value.MinAnnularVelocity,
            MinBitTFA: bitOptimizationForm.value.MinBitTFA,
            MaxNumberOfNozzles: bitOptimizationForm.value.MaxNumberOfNozzles,
            RotarySpeed: bitOptimizationForm.value.RotarySpeed,
            DepthOfIntereset: bitOptimizationForm.value.DepthOfIntereset,
            MudInletTemperature: bitOptimizationForm.value.MudInletTemperature,
            CuttingsSize: bitOptimizationForm.value.CuttingsSize,
            CuttingsDiameter: bitOptimizationForm.value.CuttingsDiameter,
            CuttingsDensity: bitOptimizationForm.value.CuttingsDensity,
            CuttingsMaterial: bitOptimizationForm.value.CuttingsMaterial,
            Name: this.bitOptimizationName,
            BedPorosity: 1,  // for now send 1
        }
    }

    public mapApiresponseToFormValues(apiResponseResult) {
        return {
            SurveyIndex: apiResponseResult.SurveyIndex,
            WellboreIndex: apiResponseResult.WellboreIndex,
            DrillstringIndex: apiResponseResult.DrillstringIndex,
            FluidIndex: apiResponseResult.FluidIndex,
            DesiredPumpPressure: apiResponseResult.DesiredPumpPressure,
            DesiredRateOfPenetration: apiResponseResult.DesiredRateOfPenetration,
            MinAnnularVelocity: apiResponseResult.MinAnnularVelocity,
            MinBitTFA: apiResponseResult.MinBitTFA,
            MaxNumberOfNozzles: apiResponseResult.MaxNumberOfNozzles,
            RotarySpeed: apiResponseResult.RotarySpeed,
            DepthOfIntereset: apiResponseResult.DepthOfIntereset,
            MudInletTemperature: apiResponseResult.MudInletTemperature,
            CuttingsSize: apiResponseResult.CuttingsSize,
            CuttingsDiameter: apiResponseResult.CuttingsDiameter,
            CuttingsDensity: apiResponseResult.CuttingsDensity,
            CuttingsMaterial: apiResponseResult.CuttingsMaterial,
        }
    }
}


const samplePayload = {
    "addOptimizations": [
        {
            "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
            "DrillstringIndex": "1F5FBFC3-F101-46C6-A498-4F41B1A080DC",
            "FluidIndex": 58,
            "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
            "DesiredPumpPressure": 1.123456,
            "DesiredRateOfPenetration": 1.123456,
            "MinAnnularVelocity": 1.123456,
            "MinBitTFA": 1.123456,
            "MaxNumberOfNozzles": 2,
            "RotarySpeed": 1.123456,
            "DepthOfIntereset": 1.123456,
            "MudInletTemperature": 1.123456,
            "CuttingsSize": 1.123456,
            "CuttingsDiameter": 1.123456,
            "CuttingsDensity": 1.123456,
            "CuttingsMaterial": 1.123456,


            "BedPorosity": 1,  // for now send as 1
            "ProjectId": 11,
            "WellId": 1,
            "Name": "Test 1",
            // "ConfigurationId": 1,  //  not to be send from front-end
            // "ExperimentGroup": "",  // not to be send from front-end
        }
    ],
    "updateOptimizations": [
        {
            "WellboreIndex": "CFBEBF97-D8AD-47C3-948B-F3ECBE378C5F",
            "DrillstringIndex": "1F5FBFC3-F101-46C6-A498-4F41B1A080DC",
            "FluidIndex": 58,
            "SurveyIndex": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
            "DesiredPumpPressure": 1.12,
            "DesiredRateOfPenetration": 1.12,
            "MinAnnularVelocity": 1.12,
            "MinBitTFA": 1.12,
            "MaxNumberOfNozzles": 2,
            "RotarySpeed": 1.123456,
            "CuttingsSize": 1,
            "CuttingsDiameter": 1.12,
            "CuttingsDensity": 1.12,
            "DepthOfIntereset": 1.12,
            "MudInletTemperature": 1.12,
            "CuttingsMaterial": 1,


            "BedPorosity": 1.123456,
            "ProjectId": 11,
            "WellId": 1,
            "Name": "Test 1",
            "BitHydraulicsOptimizationConfigurationId": 1,

            // "ConfigurationId": 1,  //  not to be send from front-end
            // "ExperimentGroup": "",  // not to be send from front-end
        }
    ]
}