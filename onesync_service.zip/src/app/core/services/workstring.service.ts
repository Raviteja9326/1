import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { Tools } from '../enum/tools.enum';
import { toActive } from '../constants/ToolUnits.constant';
import { BitType } from '../enum/workstrings/bitType.enum';
import { DrillstringSectionTypes } from '../enum/workstrings/drillStringSectionTypes.enum';
import { ToolWeightOption } from '../enum/custom-tools/toolWeightOptions.enum';

@Injectable({
    providedIn: 'root'
})
export class WorkstringService {
    safetyFactor: any = 1.0;
    defaultBladeWidths =
        [
            [4.75, 2],
            [6.25, 2],
            [6.5, 2.5],
            [6.75, 2.5],
            [8, 3],
            [9.5, 4],
            [11.5, 4]
        ];
    defaultBodyLengths = {
        1: 20.4,
        2: 29.4,
        3: 43.4
    };
    constructor(private httpMethod: HttpMethodService) { }

    GetworkstringlistApi(data) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkstringApi}` + `/${data}`)
    }

    PostworkstringApi(data) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postputworkstringApi}`, data)
    }

    PutworkstringApi(data) {
        return this.httpMethod.putMethod(`${api.serviceEndpoint}`, `${api.postputworkstringApi}`, data)
    }

    deletworkstringApi(data) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.deleteworkstringApi}`, data)
    }

    GetworkstringlistApisecondstage(data: any) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkstringApisecondstage}${data}`)
    }

    PostworkstringApisecondstage(data, data2, data3) {
        const obj2 = Object.assign({}, data, data2, data3);
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postworkstringApisecondstage}`, obj2)
    }

    PutworkstringApisecondstage(data) {
        return this.httpMethod.putMethod(`${api.serviceEndpoint}`, `${api.putworkstringApisecondstage}`, data)
    }

    deletworkstringApisecondstage(data) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.deleteworkstringApisecondstage}`, data)
    }

    GetworkstringlistcsingpipeApi() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkstringcasingApi}`)
    }

    GetworkstringlistbittemplatesApi() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkbitstringApi}`)
    }

    GetworkstringbitinfoApi(id, bitsubtype) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.bitinfoworkstringApi}?drillstringComponentId=${id}&bitType=${bitsubtype}`)
    }

    GetworkstringstatusApi(data) {
        return this.httpMethod.putMethod(`${api.serviceEndpoint}`, `${api.statusworkstringApi}${data}`)
    }

    GetworkstringJobinfoApi(id) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getJobInfoWells}` + `${id}`)
    }

    GetBHAdataApi(id) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getBHAdata}` + `${id}`)
    }

    GetStablizersJobinfoApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.getstablizersInfo}`, payload)
    }

    GetMotorInfoApi(id) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getmotorInfo}?drillstringComponentId=${id}`)
    }

    GetRssInfoApi() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getRssInfo}`)
    }

    GetSensorsInfoApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.getsensorsInfo}`, payload)
    }

    addWorkstringToolApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.addWorkstringTool}`, payload);
    }

    updateWorkStringToolApi(id, payload) {
        return this.httpMethod.putMethod(`${api.serviceEndpoint}`, `${api.updateWorkstringTool}` + id, payload);
    }

    addWorkStringbuilderApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.addworkstringBuilder}`, payload);
    }

    addWorkStringcomponentApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.addworkstringComponent}`, payload);
    }

    addWorkStringcasingpipeApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.addworkstringCasing}`, payload);
    }

    addWorkStringdrillstringApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.addworkstringdrillString}`, payload);
    }

    addWorkStringCollectionApi(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.addworkstringCollection}`, payload);
    }

    getWorkstringToolDetailsApi(id) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getDetailWorkstringTool}` + id);
    }

    GetMudInfoApi() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getmudInfo}`)
    }

    GetmudInfoRemainingData() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getMudInfoRemainingData}`)
    }

    Getworkstringcsing() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWorkstringcasingbuilder}`)
    }

    Getworkstringcentrailizer(data) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWorkstringcentrailizerbuilder}/${data}`)
    }

    GetworkstringCasingPipe() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWorkstringCasingPipebuilder}`)
    }

    GetworkstringtubularCasingPipe() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWorkstringCasingPipe}`)
    }

    GetworkstringtubularSectionPipe(data) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWorkstringSectionPipe}` + data)
    }

    GetworkstringtubularCenteralizerPipe(data) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWorkstringCenteralizerPipe}` + data)
    }

    getPSSizesList() {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getpsSize}`);
    }

    getMotorTypeList(pssize) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getMotorType}` + pssize);
    }


    gettublartoolsizeList(data) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.gettubulartoolsizeType}` + data);
    }

    calculationsWellpathsList(payload, name, method) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.calculationsWellPathApi}` + '?name=' + `${name}&&methodType=${method}`, payload);
    }// end of function  

    getAdjustableSettingList(motortype) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getAdjustableSetting}` + motortype);
    }

    getConnectionData(id) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getConnectionData}?DrillstringComponentId=` + id);
    }
    getStiffnessRatio(ds, nextDs, materials) {

        if (this.isSRCalculate(ds) && ds != null && nextDs != null) {

            var material = materials.find((d) => { return d.MaterialId == ds.MaterialId });

            var nextMaterial = materials.find((d) => { return d.MaterialId == nextDs.MaterialId });

            if (material != null && nextMaterial != null) {

                var ei = material.ModulusOfElasticity *

                    (Math.pow(ds?.OuterDiameter, 4) * (1.0 - Math.pow(ds.InnerDiameter / ds?.OuterDiameter, 4)));

                var nextEi = nextMaterial.ModulusOfElasticity *

                    (Math.pow(nextDs?.OuterDiameter, 4) * (1.0 - Math.pow(nextDs.InnerDiameter / nextDs?.OuterDiameter, 4)));

                if (nextEi > ei)

                    return nextEi / ei;

                else

                    return ei / nextEi;

            }

        }

        return null;
    }
    isSRCalculate(ds) {
        if (ds != null && ds.Type == 34 ||
            ds?.Type == 35 ||
            ds?.IsMkRSS || ds?.IsMagnusRSS ||
            ds?.IsDrillingMotor ||
            ds?.Type == 20 ||
            ds?.Type == 7 || ds?.Type == 22 || ds?.Type == 13 || ds?.Type == 9)
            return true;



        return false;
    }

    getBSR(ds, upperDs, connData) {
        if (this.isBSRCalculate(ds)) {

            if (connData != null && connData)
                return this.calculateBSR(connData, ds?.OuterDiameter, upperDs?.InnerDiameter);
        }

        return null;
    }
    calculateBSR(cd, od, id) {
        let dedendum = 0.5 * cd.H - cd.Srs;
        let b = cd.C - ((cd.tpr * (cd.Lpc - 0.625)) / 12.0) + (2.0 * dedendum);
        let R = cd.C - (2.0 * dedendum) - (cd.tpr * (1.0 / 8.0) * (1.0 / 12.0));
        let BSR = ((Math.pow(od, 4.0) - Math.pow(b, 4.0)) / od) / ((Math.pow(R, 4.0) - Math.pow(id, 4.0)) / R);

        return BSR;
    }
    isBSRCalculate(ds) {
        if (ds != null && ds.Type == 32 ||
            ds.Type == 7 || ds.Type == 22 || ds.Type == 13 ||
            ds.Type == 31)
            return true;

        return false;
    }

    saveRemarks(payload) {
        return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.saveRemarks}`, payload);
    }

    // calculate MUT value when it is not null
    calculateMakeUpTorque(connData, OD, ID, Ym, YmJoint, activeUnitSystemData?) {
        let tpr, F, Drg, C, S, H, Srs, QC, BBBDia, Lpc, P, Theta, ODVal, IDVal;
        if (activeUnitSystemData) {
            tpr = connData["tpr"];
            F = connData["F"];
            Drg = ((connData["Drg"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            C = ((connData["C"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            S = ((connData["S"]) / (toActive['pressure'][activeUnitSystemData.pressure.unitName]));
            H = ((connData["H"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Srs = ((connData["Srs"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            QC = ((connData["QC"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            BBBDia = ((connData["BBBDia"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Lpc = ((connData["Lpc"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            P = ((connData["P"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Theta = ((connData["Theta"]) / (toActive['angle'][activeUnitSystemData.angle.unitName]));
            ODVal = Number((OD / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName])));
            IDVal = Number((ID / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName])));

        } else {
            tpr = connData["tpr"];
            F = connData["F"];
            Drg = (connData["Drg"]);
            C = (connData["C"]);
            S = (connData["S"]);
            H = (connData["H"]);
            Srs = (connData["Srs"]);
            QC = (connData["QC"]);
            BBBDia = (connData["BBBDia"]);
            Lpc = (connData["Lpc"]);
            P = (connData["P"]);
            Theta = (connData["Theta"]);
            ODVal = OD;
            IDVal = ID;
        }

        let Ap = this.areaOfPin(C, H, Srs, tpr, IDVal, Drg ?? 0);
        let Ab = this.areaOfBox(ODVal, QC, tpr);

        let maxOD = this.getODMax(ODVal, QC, tpr, C, H, Srs, IDVal);

        let Rs = this.getRs(Math.min(ODVal, maxOD), QC);

        let Rt = this.getRt(C, Lpc, tpr);

        let Smod = YmJoint * 0.6;

        let ApNoGroove = this.areaOfPinWithoutReliefGrooves(C, H, Srs, tpr, IDVal);

        let makeUpArea = Math.min(Ab, ApNoGroove);

        var mut = this.makeUpTorqueForRotaryShoulderedConnections((Smod * this.safetyFactor), P, F, makeUpArea, Theta, Rs, Rt);
        if (activeUnitSystemData) {
            return (mut * (toActive['torque'][activeUnitSystemData.torque.unitName]));
        } else {
            return mut;
        }
    }

    // calculate Max MUT value when it is not null
    calculateTorsionalStrength(connData, OD, ID, Ym, YmJoint, activeUnitSystemData?) {
        let tpr, F, Drg, C, S, H, Srs, QC, BBBDia, Lpc, P, Theta, ODVal, IDVal;
        if (activeUnitSystemData) {
            tpr = connData["tpr"];
            F = connData["F"];
            Drg = ((connData["Drg"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            C = ((connData["C"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            S = ((connData["S"]) / (toActive['pressure'][activeUnitSystemData.pressure.unitName]));
            H = ((connData["H"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Srs = ((connData["Srs"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            QC = ((connData["QC"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            BBBDia = ((connData["BBBDia"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Lpc = ((connData["Lpc"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            P = ((connData["P"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Theta = ((connData["Theta"]) / (toActive['angle'][activeUnitSystemData.angle.unitName]));
            ODVal = (OD / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            IDVal = (ID / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
        }
        else {
            tpr = connData["tpr"];
            F = connData["F"];
            Drg = (connData["Drg"]);
            C = (connData["C"]);
            S = (connData["S"]);
            H = (connData["H"]);
            Srs = (connData["Srs"]);
            QC = (connData["QC"]);
            BBBDia = (connData["BBBDia"]);
            Lpc = (connData["Lpc"]);
            P = (connData["P"]);
            Theta = (connData["Theta"]);
            ODVal = OD;
            IDVal = ID;
        }

        let Ap = this.areaOfPin(C, H, Srs, tpr, IDVal, Drg ?? 0);

        let Ab = this.areaOfBox(ODVal, QC, tpr);

        let A = Math.min(Ap, Ab);

        let maxOD = this.getODMax(ODVal, QC, tpr, C, H, Srs, IDVal);

        let Rs = this.getRs(Math.min(ODVal, maxOD), QC);

        let Rt = this.getRt(C, Lpc, tpr);

        let Smod = YmJoint * 0.6;

        let ApNoGroove = this.areaOfPinWithoutReliefGrooves(C, H, Srs, tpr, IDVal);

        let makeUpArea = Math.min(Ab, ApNoGroove);

        var Ty = this.torqueToYieldRotaryShoulderedConnection(YmJoint, A, P, F, Theta, Rs, Rt);

        if (activeUnitSystemData) {
            return (Ty * (toActive['torque'][activeUnitSystemData.torque.unitName]));
        } else {
            return Ty;
        }

    }
    torqueToYieldRotaryShoulderedConnection(Ym, A, p, f, Theta, Rs, Rt) {
        let dta = Math.PI / 180.0;
        let theta = dta * Theta;
        let Ty = ((Ym * A) / 12.0) * ((p / (2.0 * Math.PI)) + ((Rt * f) / Math.cos(theta)) + Rs * f);

        return Ty;
    }

    areaOfPin(C, H, Srs, tpr, ID, Drg) {
        /*
        **Dont do conversion here for this parameters because this 
        parametres value are alredy in imperial converted format and 
        it is using in calculations
        */
        return Drg > 0.0 ? this.areaOfPinWithReliefGrooves(Drg, ID) : this.areaOfPinWithoutReliefGrooves(C, H, Srs, tpr, ID);
    }

    areaOfPinWithReliefGrooves(Drg, ID) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let Ap = (Math.PI / 4.0) * (Drg * Drg - ID * ID);

        return Ap;
    }

    areaOfPinWithoutReliefGrooves(C, H, Srs, tpr, ID) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let B = 2.0 * (H / 2.0 - Srs) + tpr * (1.0 / 8.0) * (1.0 / 12.0);

        // let Ap = (Math.PI / 4.0) * ((C - B) * (C - B) - ID * ID);
        let Ap = (Math.PI / 4.0) * (((C - B) * (C - B)) - (ID * ID));

        return Ap;
    }

    areaOfBox(OD, QC, tpr) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let E = tpr * (3.0 / 8.0) * (1.0 / 12.0); // The gauge distance tpr, with 1/12 conversion from in. to ft. 

        let Ab = (Math.PI / 4.0) * (OD * OD - (QC - E) * (QC - E));

        return Ab;
    }

    getODMax(OD, QC, tpr, C, H, Srs, ID) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let B = 2.0 * (H / 2.0 - Srs) + tpr * (1.0 / 8.0) * (1.0 / 12.0);

        let E = tpr * (3.0 / 8.0) * (1.0 / 12.0);

        let rootSquare = (QC - E) * (QC - E) + (C - B) * (C - B) - ID * ID;

        let res = rootSquare > 0.0 ? Math.max(OD, Math.sqrt(rootSquare)) : OD;

        return res;
    }

    getRs(OD, QC) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let Rs = (1.0 / 4.0) * (OD + QC);

        return Rs;
    }

    getRt(C, Lpc, tpr) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let Rt = (1.0 / 4.0) * (C + (C - (Lpc - 0.625) * tpr * (1.0 / 12.0)));

        return Rt;
    }
    makeUpTorqueForRotaryShoulderedConnections(S, p, f, A, Theta, Rs, Rt) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let dta = Math.PI / 180.0;

        let theta = dta * Theta;

        let Ta = ((S * A) / 12.0) * ((p / (2.0 * Math.PI)) + ((Rt * f) / Math.cos(theta)) + Rs * f);

        return Ta;
    }

    // calculate Tensile capcity value when it is not null
    calculateTensileStrength(connData, OD, ID, mut, Ym, YmJoint, activeUnitSystemData?) {
        let tpr, F, Drg, C, S, H, Srs, QC, BBBDia, Lpc, P, Theta, ODVal, IDVal, mutVal;
        if (activeUnitSystemData) {
            tpr = connData["tpr"];
            F = connData["F"];
            Drg = ((connData["Drg"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            C = ((connData["C"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            S = ((connData["S"]) / (toActive['pressure'][activeUnitSystemData.pressure.unitName]));
            H = ((connData["H"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Srs = ((connData["Srs"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            QC = ((connData["QC"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            BBBDia = ((connData["BBBDia"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Lpc = ((connData["Lpc"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            P = ((connData["P"]) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            Theta = ((connData["Theta"]) / (toActive['angle'][activeUnitSystemData.angle.unitName]));
            ODVal = Number((OD / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName])));
            IDVal = Number((ID / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName])));
            mutVal = (mut / (toActive['torque'][activeUnitSystemData.torque.unitName]));
        }
        else {
            tpr = connData["tpr"];
            F = connData["F"];
            Drg = (connData["Drg"]);
            C = (connData["C"]);
            S = (connData["S"]);
            H = (connData["H"]);
            Srs = (connData["Srs"]);
            QC = (connData["QC"]);
            BBBDia = (connData["BBBDia"]);
            Lpc = (connData["Lpc"]);
            P = (connData["P"]);
            Theta = (connData["Theta"]);
            ODVal = (OD);
            IDVal = (ID);
            mutVal = mut;
        }

        let Ap = this.areaOfPin(C, H, Srs, tpr, IDVal, Drg ?? 0);

        let Ab = this.areaOfBox(ODVal, QC, tpr);

        let maxOD = this.getODMax(ODVal, QC, tpr, C, H, Srs, IDVal);

        let Rs = this.getRs(Math.min(ODVal, maxOD), QC);

        let Rt = this.getRt(C, Lpc, tpr);

        let pinYield = YmJoint * Ap;

        let T2 = this.torsionalStrengthOfThePin(YmJoint, Ap, P, Theta, F, Rs, Rt);

        let T3 = this.torsionalLoadRequiredToProduceAdditionalMakeup(YmJoint, Ap, P, Theta, F, Rt);

        let T4 = this.pinYieldAndShouldSeperationMakeupTorque(YmJoint, Ap, Ab, P, Theta, F, Rs, Rt);

        let uT = Math.min(T3, T4);

        let lcx = mutVal > uT ? T2 : 0.0;

        let PShoulderatMUT = lcx < uT ? (pinYield * (mutVal / uT)) : (pinYield - pinYield * ((mutVal - uT) / (lcx - uT)));

        let PatMUT = Math.min(T3, T4) < mutVal ? PShoulderatMUT : pinYield;

        if (activeUnitSystemData) {
            return (PatMUT * (toActive['force'][activeUnitSystemData.force.unitName]));
        } else {
            return PatMUT;
        }

    }

    torsionalStrengthOfThePin(Ym, Ap, p, Theta, f, Rs, Rt) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let dta = Math.PI / 180.0;
        let theta = dta * Theta;
        let T2 = (Ym / 12.0) * Ap * ((p / (2.0 * Math.PI)) + ((Rt * f) / Math.cos(theta)) + Rs * f);
        return T2;
    }

    torsionalLoadRequiredToProduceAdditionalMakeup(Ym, Ap, p, Theta, f, Rt) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let dta = Math.PI / 180.0;
        let theta = dta * Theta;
        let T3 = (Ym / 12.0) * Ap * ((p / (2.0 * Math.PI)) + ((Rt * f) / Math.cos(theta)));
        return T3;
    }

    pinYieldAndShouldSeperationMakeupTorque(Ym, Ap, Ab, p, Theta, f, Rs, Rt) {
        /*
      **Dont do conversion here for this parameters because this 
      parametres value are alredy in imperial converted format and 
      it is using in calculations
      */
        let dta = Math.PI / 180.0;
        let theta = dta * Theta;
        let T4 = (Ym / 12.0) * ((Ap * Ab) / (Ap + Ab)) * ((p / (2.0 * Math.PI)) + ((Rt * f) / Math.cos(theta)) + Rs * f);
        return T4;
    }

    // set section mass base if dimensional data Mass sum is <0
    setSectionMassBase(tubular, template, sections, materialsList, activeUnitSystemData?) {
        if (sections.length > 0) {
            for (let i = 0; i < sections.length; i++) {
                var material = materialsList.find((m) => { return m.MaterialId == (sections[i].Material ?? 12) });
                if (material != null && sections[i].OuterDiameter && sections[i].InnerDiameter) {
                    sections[i].NominalWeight = this.calculateLinearMassDensity(sections[i].OuterDiameter, sections[i].InnerDiameter, material.Density,activeUnitSystemData);
                }
                else {
                    sections[i].NominalWeight = 0;
                }
                let mass = (sections[i].NominalWeight) * (sections[i].Length)
                sections[i].Mass = mass;
            }
        }
        return sections;
    }

    // set section mass base if dimensional data Mass sum is >0
    setSectionMass(tubular, template, sections, materialsList, activeUnitSystemData?) {
        if (sections.length > 0) {
            var allSectionsMass = sections.reduce((acc, currentVal) => {
                // if string values convert it to number
                return Number(acc) + Number(currentVal.Mass ? currentVal.Mass : 0);
            }, 0);
           
            tubular["ComponentMass"] = tubular["Length"] * (tubular["TotalAdjustedWeight"] ?? 0);
            // if string values convert it to number
            if (Number(allSectionsMass) > 0 && Number(tubular['ComponentMass'] > 0) && tubular.toolWeightOptions!=parseInt(ToolWeightOption['Calculated'])) {
                var AllSectionsActualMass = sections.reduce((acc, currentVal) => {
                    var material = materialsList.find((m) => { return m.MaterialId == (currentVal.Material ?? 12) });//materialsList[0];
                    return (acc) + this.calculateMass(currentVal.Length, currentVal.OuterDiameter ?? 0, currentVal.InnerDiameter ?? 0, material.Density, activeUnitSystemData);;
                }, 0);
                for (let i = 0; i < sections.length; i++) {
                    var material = materialsList.find((m) => { return m.MaterialId == (sections[i].Material ?? 12) });
                    var sectionActualMass = this.calculateMass(sections[i].Length ?? 0, sections[i].OuterDiameter ?? 0, sections[i].InnerDiameter ?? 0, material.Density, activeUnitSystemData);
                    // if string values convert it to number
                    sections[i].Mass = Number(tubular.ComponentMass ?? 0) * Number(sectionActualMass) / Number(AllSectionsActualMass);
                    sections[i].MassFactor = Number(sections[i].Mass) / Number(sectionActualMass);

                }
            }
            else {
                for (let i = 0; i < sections.length; i++) {
                    var material = materialsList.find((m) => { return m.MaterialId == (sections[i].Material ?? 12) });//materialsList[0];
                    
                    sections[i].MassFactor = 1;
                    // if string values convert it to number
                    sections[i].Mass = this.calculateMass(Number(sections[i].Length ?? 0), Number(sections[i].OuterDiameter ?? 0), Number(sections[i].InnerDiameter ?? 0), Number(sections[i].MassFactor ?? 1) * Number(material.Density), activeUnitSystemData);
                }
            }
        }
        return sections;
    }

    // Calculate linear mass desnity to calculate Mass and NW
    calculateLinearMassDensity(od, id, density, activeUnitSystemData?) {
        if (activeUnitSystemData) {
            // if string values convert it to number
            od = Number(od) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName]; // Convert millimeters to inches
            id = Number(id) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName]; // Convert millimeters to inches
            density = Number(density) / toActive['density'][activeUnitSystemData.density.unitName]; //convert to ppg
            return ((toActive['linearMassDensity'][activeUnitSystemData.linearMassDensity.unitName]) * (Math.PI * density * (od * od - id * id) / 77));
        } else {
            return Math.PI * density * (od * od - id * id) / 77;
        }

    }

    // calculate Mass 
    calculateMass(length, od, id, density, activeUnitSystemData?) {
        if (activeUnitSystemData) {
            length = length / toActive['length'][activeUnitSystemData.length.unitName]; // Convert meters to feet
            od = Number(od) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName]; // Convert millimeters to inches
            id = Number(id) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName]; // Convert millimeters to inches
            density = Number(density) / toActive['density'][activeUnitSystemData.density.unitName]; //convert to ppg
            return toActive['mass'][activeUnitSystemData.mass.unitName] * (Math.PI * length * density * (od * od - id * id) / 77);
        }
        else {
            return (Math.PI * length * density * (od * od - id * id) / 77);
        }
    }
    // get def values for jar tool usinng type and toolsize
    getJarTemplate(jarToolTypeId, toolSizeId='') {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getJarToolDefaultApi}?JarToolType=${jarToolTypeId}&ToolSizeId=${toolSizeId}`);
    }
    
    getTemplate(type, subtype, toolsizeId) {
        if (toolsizeId)
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getTemplateApi}/${subtype}?ToolSizeId=${toolsizeId}`);
        else
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getTemplateApi}/${subtype}`);
    }

    // get drill pipe template default values
    getTemplateDrillP(toolSizeId, NWValue, GradeUpsetValue, ConnectionId, rangeValue) {
        if (toolSizeId)
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getTemplateDrillPipeApi}?ToolSizeId=${toolSizeId}&NominalWeight=${NWValue}&GradeAndUpsetType=${GradeUpsetValue}&ConnectionId=${ConnectionId}&Range=${rangeValue}`);
        else
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getTemplateDrillPipeApi}`);
    }

    // get drill collar template default values
    getTemplateDrillCollar(toolSizeId, type) {
        if (toolSizeId)
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getTemplateDrillCollarApi}?ToolSizeId=${toolSizeId}&Type=${type}`);
        else
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getTemplateDrillCollarApi}`);
    }
    // get drill collar tool size values using type
    getToolSizeDrillCollar(type) {
        if (type)
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getToolSizeDrillCollarApi}?Type=${type}`);
        else
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getToolSizeDrillCollarApi}`);
    }

    // calculate Adjust OD of tooljoint value OD 
    AdjustOD(wallThickness, ID, factors) {
        var adjustODValue = wallThickness * factors.WallThicknessFactor + ID;
        console.log("adjustODValue--", adjustODValue);
        return adjustODValue;
    }

    // get default body length values according Range value we selected.
    GetDefaultBodyLength(range, activeUnitSystemData?) {
        let lengthValue = this.defaultBodyLengths[range];
        console.log("lengthValue--", lengthValue);
        return (lengthValue * toActive['length'][activeUnitSystemData.length.unitName]);
    }
    //Function to fetch NW list
    getNominalWeightList(toolSizeId) {

        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getNominalWeightApi}` + `/${toolSizeId}`)

    }
    //Function to fetch Grade and Upset list
    getGradeUpsetList(toolSizeId, NW) {

        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWSDPGradeUpsetListApi}?ToolSizeId=${toolSizeId}&NominalWeight=${NW}`)

    }
    getStabilizerTemplate(type, subtype, toolsizeId) {
        if (toolsizeId)
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getStabilizerTemplateApi}/${subtype}?ToolSizeId=${toolsizeId}`);
        else
            return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getStabilizerTemplateApi}/${subtype}`);
    }
    GetDefaultBladeWidth(bodyOD,activeUnitSystemData?) {
        bodyOD=Number(Number(bodyOD) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName])
        let defaultList = JSON.parse(JSON.stringify([...this.defaultBladeWidths]));
        let newList = defaultList.map((x) => {
            x.push((Math.abs(x[0] - bodyOD))*(toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
            return x
        });
        let sortedList = newList.sort((a, b) => {
            return a[2] - b[2];
        })
        return (Number(sortedList[0][1])*(toActive['shortLength'][activeUnitSystemData.shortLength.unitName]));
    }
    calculateJSA(tc_param, tubularSections_param, stab_param, wellOD_param, activeUnitSystemData?) {
        let tc, tubularSections, stab, wellOD;
        tc = JSON.parse(JSON.stringify(tc_param));
        tubularSections = JSON.parse(JSON.stringify(tubularSections_param));
        stab = JSON.parse(JSON.stringify(stab_param));
        wellOD = wellOD_param;
        if (activeUnitSystemData) {
            tc.OuterDiameter = Number(tc?.OuterDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName];
            wellOD = Number(wellOD) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName];
            tubularSections = tubularSections.map((d) => {
                return {
                    InnerDiameter: Number(d.InnerDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                    Length: Number(d.Length) / toActive['length'][activeUnitSystemData.length.unitName],
                    Mass: Number(d.Mass) / toActive['mass'][activeUnitSystemData.mass.unitName],
                    MaterialId: d.MaterialId,
                    Order: d.Order,
                    OuterDiameter: Number(d.OuterDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                    SectionName: d.SectionName,
                    SectionType: d.SectionType
                }
            });
            stab = {
                BladeAngle: Number(stab?.BladeAngle) / toActive['angle'][activeUnitSystemData.angle.unitName],
                BladeCount: Number(stab?.BladeCount),
                BladeDistanceFromBottom: Number(stab?.BladeDistanceFromBottom) / toActive['length'][activeUnitSystemData.length.unitName],
                BladeLength: Number(stab?.BladeLength) / toActive['length'][activeUnitSystemData.length.unitName],
                BladeMaximumOuterDiameter: Number(stab?.BladeMaximumOuterDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                BladeMinimumOuterDiameter: Number(stab?.BladeMinimumOuterDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                BladeOuterDiameter: Number(stab?.BladeOuterDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                BladeShape: stab?.BladeShape,
                BladeWidth: Number(stab?.BladeWidth) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                BodyOD: Number(stab?.BodyOD) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                MidBladeOffset: Number(stab?.MidBladeOffset) / toActive['length'][activeUnitSystemData.length.unitName],
                Name: stab?.Name
            }
        }


        console.log("tc", tc);
        console.log("tubularSections", tubularSections);
        console.log("stab", stab);
        console.log("wellOD", wellOD);
        let error;
        var errorMsg = "";

        let simple = false;

        let bodyOD = 0, bladeOD = 0, bladeWidth = 0, alfa = 0, bladeCount = 0;

        let wellArea = Math.PI * ((Number(wellOD) / 2.0) * (Number(wellOD) / 2.0));

        if (Number(stab.BladeCount) == null || Number(stab.BladeCount) < 1) {

            simple = true;

            errorMsg = "Blade Count not specified.";

        }

        else

            bladeCount = Number(stab.BladeCount);

        var section = this.GetSectionAtDistanceFromBottom(tubularSections_param, Number(stab_param.BladeDistanceFromBottom), activeUnitSystemData);

        bodyOD = section == null ? tc.OuterDiameter : (Number(section.OuterDiameter) ?? tc.OuterDiameter);

        bladeOD = Number(stab.BladeOuterDiameter) ?? bodyOD;

        if (Number(stab.BladeWidth) == null) {

            if (!(tc.DrillstringType == Number(Tools['Tubular MWD']) || tc.DrillstringType == Number(Tools['Adjustable Gauge Stabilizer'])))

                errorMsg = "Blade Width not specified.";

            simple = true;

        }

        else

            bladeWidth = Number(stab.BladeWidth);

        if (Number(stab.BladeAngle) == null || Number(stab.BladeAngle) == 0 || Number(stab.BladeAngle) == 90)

            alfa = 30;

        else

            alfa = Number(stab.BladeAngle);

        if (bladeOD > wellOD) {

            errorMsg = "Blade Outer Diameter more then Max Outer Diameter.";

            wellOD = bladeOD;

        }

        if (!simple) {

            let betaTip = 2.0 * this.radToGrad(Math.asin(0.5 * bladeWidth / bladeOD * 2.0));

            let fTip = bladeOD / 2.0 * (1 - Math.cos(this.gradToRad(betaTip / 2.0)));

            let d = (bladeOD / 2.0 + (bladeWidth / 2.0 / Math.tan(this.gradToRad(alfa)) - fTip)) * Math.sin(this.gradToRad(180 - alfa)) / (bodyOD / 2.0);

            if (d > 1)

                d = 1;

            if (d < -1)

                d = -1;

            let betaBase = 2 * (180 - alfa - (180 - this.radToGrad(Math.asin(d))));

            let fBase = bodyOD / 2.0 * (1 - Math.cos(this.gradToRad(betaBase / 2.0)));

            let abBase = bodyOD * Math.sin(this.gradToRad(betaBase / 2.0));

            let areaBase = Math.PI * (bodyOD * bodyOD) / 4.0 * betaBase / 360 - abBase / 2.0 * (bodyOD / 2.0 - fBase);

            let areaTip = Math.PI * (bladeOD * bladeOD) / 4.0 * betaTip / 360 - bladeWidth / 2.0 * (bladeOD / 2.0 - fTip);

            let areaTrapezium = (abBase + bladeWidth) / 2.0 * (bladeOD / 2.0 - fTip - bodyOD / 2.0 + fBase);

            let jsaSmall = Math.PI / 4.0 * ((bladeOD * bladeOD) - (bodyOD * bodyOD)) - (areaTrapezium + areaTip - areaBase) * bladeCount;

            let jsa = wellArea - Math.PI * ((bladeOD / 2.0) * (bladeOD / 2.0)) + jsaSmall;

            error = errorMsg;

            var res = jsa / (wellArea / 100.0);

            return { 0: [res > 100 ? (100 * Math.pow(toActive['shortLength'][activeUnitSystemData.shortLength.unitName], 2)) : (res * Math.pow(toActive['shortLength'][activeUnitSystemData.shortLength.unitName], 2)), (jsa * Math.pow(toActive['shortLength'][activeUnitSystemData.shortLength.unitName], 2))], 1: error };

        }

        error = errorMsg;

        var bladeArea = Math.PI * ((bladeOD / 2.0) * (bladeOD / 2.0));

        var res2 = bladeArea / (wellArea / 100.0);

        return { 0: [res2 > 100 ? (100 * Math.pow(toActive['shortLength'][activeUnitSystemData.shortLength.unitName], 2)) : (res2 * Math.pow(toActive['shortLength'][activeUnitSystemData.shortLength.unitName], 2)), (bladeArea * Math.pow(toActive['shortLength'][activeUnitSystemData.shortLength.unitName], 2))], 1: error };

    }

    GetSectionAtDistanceFromBottom(tubularSections_param, distance_param, activeUnitSystemData?) {
        let tubularSections, distance;
        tubularSections = JSON.parse(JSON.stringify(tubularSections_param));
        distance = distance_param;
        if (activeUnitSystemData) {
            tubularSections = tubularSections.map((d) => {
                return {
                    InnerDiameter: Number(d.InnerDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                    Length: Number(d.Length) / toActive['length'][activeUnitSystemData.length.unitName],
                    Mass: Number(d.Mass) / toActive['mass'][activeUnitSystemData.mass.unitName],
                    MaterialId: d.MaterialId,
                    Order: d.Order,
                    OuterDiameter: Number(d.OuterDiameter) / toActive['shortLength'][activeUnitSystemData.shortLength.unitName],
                    SectionName: d.SectionName,
                    SectionType: d.SectionType
                }
            });
            distance = distance / toActive['length'][activeUnitSystemData.length.unitName]
        }

        try {

            //var tubularSections = tubularSections.map(sc => sc.Length);

            if (tubularSections != null && tubularSections.length > 0) {

                let totalLength = tubularSections.reduce((acc, currVal) => { return acc.Length + currVal.Length });

                let iterativeLength = 0.0;

                if (distance > totalLength || distance < iterativeLength)

                    return null;

                for (let i = 0; i < tubularSections.length; i++) {

                    if (distance >= iterativeLength && distance < iterativeLength + tubularSections[i].Length)
                        return tubularSections[i];

                    iterativeLength += tubularSections[i].Length;

                }

                return null;

            }

            else {

                return null;

            }

        }

        catch (Exception) {

            return null;

        }
    }
    radToGrad(rad) {
        //please note do not make any unit conversions here. This function is used in calculate JSA
        //Provide already coverted values


        return 180.0 / Math.PI * rad;

    }
    gradToRad(grad) {
        //please note do not make any unit conversions here. This function is used in calculate JSA
        //Provide already coverted values


        return grad * Math.PI / 180.0;

    }
    getDrillMotorTemplate(payload) {

        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getDrillMotorDefaultApi}?PSToolSizeId=${payload?.pssize ? payload?.pssize : null}&BSToolSizeId=${payload?.bssize ? payload?.bssize : null}&TemplateId=${payload?.motorType ? payload?.motorType : null}`)
    }
    getStabilizers(toolsizeId, location) {
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getStabilizerTemplate}?Location=${location}&ToolSizeId=${toolsizeId}`)
    }


     // when we change Mass and AW it will calculate Mass and NW in dimensional data
    CalculateSectionMass(tubularValue, material, massVal,gShoeCall?, activeUnitSystemData?) {
        let tubularSectionValue = [...tubularValue]
        var totalMass = 0;
        var mass = (Number(massVal) / (toActive['mass'][activeUnitSystemData.mass.unitName]));
        let cuIn2Gallons = 0.004329004329004329
        if (tubularSectionValue)
            totalMass += tubularSectionValue.reduce((acc, curr) => {
                let ODValue = Number((curr.OuterDiameter ?? 0) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]))
                let IDValue = Number((curr.InnerDiameter ?? 0) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]))
                let LengthValue = Number((curr.Length ?? 0) / (toActive['length'][activeUnitSystemData.length.unitName]))
                
                if(gShoeCall){
                   let materialDensity=material.find((item) => { return item.MaterialId == curr.Material });
                    materialDensity=(Number(materialDensity.Density)/ (toActive['density'][activeUnitSystemData.density.unitName]));
                    return (Number(acc) + ((Number(materialDensity)) * this.CalculateVolume(LengthValue, ODValue, IDValue))); 
                }else{
                    return (Number(acc) + Number(material[0].Density * this.CalculateVolume(LengthValue, ODValue, IDValue)));
                }
                
            }, 0);
        totalMass *= cuIn2Gallons;

        if (tubularSectionValue) {
            for (var section of tubularSectionValue) {
                let ODValue = Number((section.OuterDiameter ?? 0) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]))
                let IDValue = Number((section.InnerDiameter ?? 0) / (toActive['shortLength'][activeUnitSystemData.shortLength.unitName]))
                let LengthValue = Number((section.Length ?? 0) / (toActive['length'][activeUnitSystemData.length.unitName]))
                var volume = this.CalculateVolume(LengthValue, ODValue, IDValue);
                volume *= cuIn2Gallons;
                if(gShoeCall){
                    let materialDensity=material.find((item) => { return item.MaterialId == section.Material });
                    materialDensity=(Number(materialDensity.Density)/ (toActive['density'][activeUnitSystemData.density.unitName]));
                    section.Mass = ((mass * Number(materialDensity) * volume / totalMass) * (toActive['mass'][activeUnitSystemData.mass.unitName]));
                }else{
                section.Mass = ((mass * Number(material[0].Density) * volume / totalMass) * (toActive['mass'][activeUnitSystemData.mass.unitName]));
                }
                section.MassFactor = 1;
            }
        }

        return tubularSectionValue;
    }


    // calculate volume to recaiculate length
    CalculateVolume(length, OD, ID) {
        return 3 * Math.PI * length * (OD * OD - ID * ID);
    }
    getTemplateRSS(payload){
        //to get default template for RSS tool
        payload.type = payload.type?payload.type:null;
        payload.toolSize = payload?.toolSize?payload?.toolSize:null;
        payload.toolConfig = payload?.toolConfig?payload?.toolConfig:null;
        payload.powerSetup =  payload?.powerSetup?payload?.powerSetup:null;
        payload.holeSize =  payload?.holeSize?payload?.holeSize:null;
        return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getRSSDefaultApi}?RSSType=${payload?.type}&ToolSizeId=${payload.toolSize}&ConfigId=${payload.toolConfig}&PowerSetUpId=${payload.powerSetup}&HoleId=${payload.holeSize}`)
    }
}

