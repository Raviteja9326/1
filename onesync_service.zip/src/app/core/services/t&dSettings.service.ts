import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { HttpMethodService } from './httpMethod.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TDSettingsService {

  endPoint: string;
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

     this.endPoint = `${api.serviceEndpoint}`;
  }

//Function to fetch WITSML Activity code list
  getTDList() {

    return this.httpMethod.getMethod(this.endPoint,api.getTDList)
  }
  
  //function for post the custom connection list
  postTDList(data1:any)
  {
    return this.httpMethod.putMethod( this.endPoint,api.postTDList,data1)

  }
 
} //end of 'CustomConnectionsService'