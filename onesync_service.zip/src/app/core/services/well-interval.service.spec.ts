import { TestBed } from '@angular/core/testing';

import { WellIntervalService } from './well-interval.service';

describe('WellIntervalService', () => {
  let service: WellIntervalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WellIntervalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
