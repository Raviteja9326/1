import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError, retry, timeout } from "rxjs/operators";
import { HttpMethodService } from "./httpMethod.service";
import { BehaviorSubject, throwError, Observable } from "rxjs";
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { WellPathsService } from "./wellPaths.service";
import { ToastrService } from 'ngx-toastr';
import { WellIntervalSimifyService } from "./well-interval.service";
import { EquipmentConfigurationService } from "./equipmentConfigService.service";
import { StorageService } from "./storage.service";
import { HydraulicsSnapshotService } from "./hydraulics-snapshot.service";


@Injectable({
    providedIn: 'root'
})

export class TemperatureService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
    private WellTableData: any[] = [];
    private tableData5: any;
    private payloadcalculations: any = {};
    private SurveyHeaderId: number;
    public activeSurveys: any[] = [];
    activeSurveyStatus = new BehaviorSubject({ status: false });
    public unitSystem = "Imperial";

    constructor(
        private httpMethod: HttpMethodService,
        private ngxLoader: NgxUiLoaderService,
        private zone: WellPathsService,
        private toastr: ToastrService,
        private zone2: WellIntervalSimifyService,
        private equipmentConfigService: EquipmentConfigurationService,
        private store: StorageService,
        private hydraulicSnapshotSvc: HydraulicsSnapshotService,
    ) {
        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of Temperatures.
     */
    getTemperatureList(projectId) {

        if (projectId) {

            return this.httpMethod.getMethod(this.endPoint, api.getTemperatureApi + `?ProjectId=${projectId}`)
        } else {

            return this.httpMethod.getMethod(this.endPoint, api.getTemperatureApi)
        }
    }//end of getTemperatureApiList

    /**
    *
    * This function will post the list of Temperatures.
    */
    postTemperatureList(data1: any) {

        return this.httpMethod.postMethod(this.endPoint, api.postTemperatureApi, data1)
    }//end of postTemperatureApiList

    /**
     * Below function will delete record.
     */
    deleteTemperatureRecord(recordId) {

        // let deleteEndpoint = api.deleteTemperatureApi;
        // deleteEndpoint = deleteEndpoint.replace(":id", recordId);
        // return this.httpMethod.deleteMethod(this.endPoint, deleteEndpoint);

        return this.httpMethod.postMethod(this.endPoint, api.deleteTemperatureApi, recordId);

    } //end of deleteTemperatureRecord function

    public postUnitConversion(payload: { surveys?: any[], formations?: any[] }): Observable<{ message: string, result: any[] }> {
        return this.httpMethod.postMethod(this.endPoint, api.formationsAndSurveysUnitConversion, payload)
    }


    public calculateMD(activeSurveys: any[], airGap) {
        if (activeSurveys == null || activeSurveys.length < 2)
            // return [airGap];
            return airGap;

        const result = [];

        let Y1 = 0;
        let Y2 = 0;
        let dMD = 0;
        let h = 0;
        let hit = false;

        for (let i = 0; i < activeSurveys.length - 1; i++) {
            h = activeSurveys[i + 1].MeasuredDepth - activeSurveys[i].MeasuredDepth;
            Y1 = activeSurveys[i].TrueVerticalDepth;
            Y2 = activeSurveys[i + 1].TrueVerticalDepth;

            if (Y1 < Y2 && (Y1 <= airGap) && (Y2 >= airGap)) {
                dMD = (airGap - Y1) / (Y2 - Y1) * h;
                result.push(activeSurveys[i].MeasuredDepth + dMD);
                hit = true;
            }

            if (Y1 > Y2 && (Y1 >= airGap) && (Y2 <= airGap)) {
                dMD = (Y1 - airGap) / (Y1 - Y2) * h;
                result.push(activeSurveys[i].MeasuredDepth + dMD);
                hit = true;
            }
        }

        if (Y1 < Y2 && !hit) {
            dMD = (airGap - Y1) / (Y2 - Y1) * h;
            result.push(activeSurveys[activeSurveys.length - 2].MeasuredDepth + dMD);
        }

        if (Y1 >= Y2 && !hit) {
            dMD = airGap - Y2;
            result.push(activeSurveys[activeSurveys.length - 1].MeasuredDepth + dMD);
        }

        return result.length > 0 ? result[0] : 0;
    }

    public calculateTVD(activeSurveys: any[], md) {
        let tvd = 0;
        const _activeSurveys = activeSurveys;
        try {
            if (_activeSurveys.length >= 2) {
                let IsFind: boolean = false;
                for (let i = 1; i < _activeSurveys.length; i++) {
                    if (md <= _activeSurveys[i].MeasuredDepth) {
                        const ac = md - _activeSurveys[i - 1].MeasuredDepth;
                        const cb = _activeSurveys[i].MeasuredDepth - md;
                        const delta = cb == 0 ? 1 : ac / cb;

                        tvd = cb == 0 ? _activeSurveys[i].TrueVerticalDepth : (_activeSurveys[i - 1].TrueVerticalDepth + delta * _activeSurveys[i].TrueVerticalDepth) / (1 + delta);
                        IsFind = true;
                        break;
                    }
                }
                if (!IsFind && md > _activeSurveys[_activeSurveys.length - 1].MeasuredDepth) {
                    const indexLast = _activeSurveys.length - 1;
                    const ac = md - _activeSurveys[indexLast - 1].MeasuredDepth;
                    const cb = _activeSurveys[indexLast].MeasuredDepth - md;
                    const delta = cb == 0 ? 1 : ac / cb;
                    tvd = (_activeSurveys[indexLast - 1].TrueVerticalDepth + delta * _activeSurveys[indexLast].TrueVerticalDepth) / (1 + delta);
                }
            }
        }
        catch { }

        return tvd;
    }

    // ---------------------- Below are the sequence of API calls required for getting active surveys ----------------------
    public getWellPathList(ProjectId: number) {
        this.ngxLoader.start();
        this.hydraulicSnapshotSvc.getWellPathList(ProjectId).subscribe({
            next: (apiResponse) => {
                this.ngxLoader.stop();
                if (apiResponse && apiResponse.message == "Success" && apiResponse.result.length > 0) {
                    const _activeItem = apiResponse.result.find(item => item.Active == true);
                    if (_activeItem) {
                        this.SurveyHeaderId = _activeItem.SurveyHeaderId;
                        this.getSurveyPointsList(ProjectId);
                    }
                }
                // console.log("wellPathList: ", this.wellPathList);
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Wellpath: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Wellpath data");
            }
        });
    }

    private getSurveyPointsList(ProjectId: number) {
        this.ngxLoader.start();
        this.zone.getSurveyPointsList(this.SurveyHeaderId, 2).pipe().subscribe({
            next: (data) => {
                //////console.log(data)
                this.ngxLoader.stop();
                if (data.result.wellRows.length != 0) {
                    this.WellTableData = data?.result?.wellRows.map((row: any) => {
                        // Iterate through the properties of each row and round numeric values to two decimal places
                        Object.keys(row).forEach(key => {
                            if (typeof row[key] === 'number') {
                                row[key] = parseFloat(row[key].toFixed(2));
                            }
                        });
                        return row;
                    });
                    this.WellTableData.sort((a, b) => a.MeasuredDepth - b.MeasuredDepth);
                    this.getWellintervalList(ProjectId);
                }
                else {
                    this.WellTableData = [];
                    this.getWellintervalList(ProjectId);
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Surveypointlist: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Surveypointlist");
            }
        });
    }

    private getWellintervalList(ProjectId: number) {
        this.ngxLoader.start();
        this.zone2.getWellintervalList(ProjectId).pipe().subscribe({
            next: (data) => {
                this.ngxLoader.stop();
                const hasActiveWell = data?.result.some((res) => res.Active === true);
                if (hasActiveWell) {
                    // At least one object with res.Active === true exists
                    // Perform the action for each active wellbore
                    data?.result.forEach((res) => {
                        if (res.Active === true) {
                            this.getCasingList(res.WellboreSectionId);
                        }
                    });
                } else {
                    // No object with res.Active === true exists
                    // Perform the error action
                    this.toastr.error("No Active Well Interval");
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Wellinterval: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Wellinterval data");
            }
        });
    }

    private getCasingList(id: any) {
        this.ngxLoader.start();
        this.zone2.getCasingList(id, 'open_hole').pipe().subscribe({
            next: (data) => {
                //////////////console.log(data)
                this.ngxLoader.stop();
                if (data?.result.length != 0) {
                    // let measuredDepth_precision = this.activatedUnit?.length?.precision ? this.activatedUnit?.length?.precision : 2;
                    const transformedData: any = {
                        "result": data?.result.map(item => ({ MeasuredDepth: typeof item.MeasuredDepth === 'number' ? parseFloat(item.MeasuredDepth?.toFixed(2)) : 0 }))
                    };
                    this.getEquipmentConfigList(transformedData.result);
                    //   this.Gettragectory = transformedData?.result?.[transformedData.result?.length - 1];
                    ////////////console.log(this.Gettragectory)
                } else {
                    this.toastr.error("No Data Found In Open Hole Interval");
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Openhole: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Openhole data");
            }
        });
    }

    private getEquipmentConfigList(dopenholedata) {
        this.ngxLoader.start();
        const welldataID: any = this.store.getWellName();
        this.equipmentConfigService.getEquipmentConfigListByProjectId(welldataID.ProjectId).pipe().subscribe({
            next: (data) => {
                this.ngxLoader.stop();
                console.log(data)
                this.tableData5 = data?.result[0];
                let waterDepthcalc: any;
                let airGapcalc: any;
                if (this.tableData5?.RigType == 5) {
                    // When we select RigType is Land(5) Then AirGap will be (kellybushing - GroundLevel(ElevationTVD)) and waterDepth should be Zero  
                    waterDepthcalc = 0;
                    airGapcalc = this.tableData5?.KellyBushingTVD?.toFixed(2) - this.tableData5?.ElevationTVD?.toFixed(2);
                }
                else {
                    waterDepthcalc = this.tableData5?.ElevationTVD?.toFixed(2);
                    airGapcalc = this.tableData5?.KellyBushingTVD?.toFixed(2);
                }
                this.payloadcalculations = {
                    "equipmentConfiguration": {
                        "rigAzimuth": Number(this.tableData5.RigAzimuth.toFixed(2)),
                        "formationAzimuth": Number(this.tableData5.FormationAzimuth.toFixed(2)),
                        "rigInclination": Number(this.tableData5.RigInclination.toFixed(2)),
                        "formationInclination": Number(this.tableData5.FormationInclination.toFixed(2))
                    },
                    "airGap": Number(airGapcalc),
                    "waterDepth": Number(waterDepthcalc),
                    "KellyBushing": Number(this.tableData5.KellyBushingTVD.toFixed(2)),
                    "openHoleIntervalsActive": dopenholedata,
                    "ElevationTVD": Number(this.tableData5.ElevationTVD.toFixed(2))
                };
                this.calculationsWellpathsList();
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("EquipmentConfiguration: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching EquipmentConfiguration data");
            }
        });
    }

    private calculationsWellpathsList() {
        this.ngxLoader.start();
        this.zone.calculationsWellpathsList(this.payloadcalculations, 'GetWellPath', 'POST').pipe().subscribe({
            next: (data) => {
                this.ngxLoader.stop();
                const dataCal = data?.result.map((item: any, index) => {
                    const uniqueId = Date.now() + index;
                    const isPrecalculatedRow = (this.payloadcalculations?.airGap === 0 && index === 1) ||
                        (this.payloadcalculations?.airGap !== 0 && index === 2);
                    const mappedItem: any = {
                        MeasuredDepth: parseFloat((item.measuredDepth ?? 0).toFixed(2)),
                        Azimuth: parseFloat((item.azimuth ?? 0).toFixed(2)),
                        Inclination: parseFloat((item.inclination ?? 0).toFixed(2)),
                        NorthSouth: parseFloat((item.northSouth ?? 0).toFixed(2)),
                        EastWest: parseFloat((item.eastWest ?? 0).toFixed(2)),
                        TrueVerticalDepth: parseFloat((item.trueVerticalDepth ?? 0).toFixed(2)),
                        TVDSS: parseFloat((item.tvdss ?? 0).toFixed(2)),
                        LateralDistance: parseFloat((item.lateralDistance ?? 0).toFixed(2)),
                        DogLegSeverity: parseFloat((item.dogLegSeverity ?? 0).toFixed(2)),
                        BuildRate: parseFloat((item.buildRate ?? 0).toFixed(2)),
                        TurnRate: parseFloat((item.turnRate ?? 0).toFixed(2)),
                        DDI: parseFloat((item.ddi ?? 0).toFixed(2)),
                        VSec: parseFloat((item.vSec ?? 0).toFixed(2)),
                        HDisp: parseFloat((item.hDisp ?? 0).toFixed(2)),
                        Tortuosity: parseFloat((item.tortuosity ?? 0).toFixed(2)),
                        ABSTortuosity: parseFloat((item.absTortuosity ?? 0).toFixed(2)),
                        CourseLength: parseFloat((item.courseLength ?? 0).toFixed(2)),
                        ToolFace: parseFloat((item.toolFace ?? 0).toFixed(2)),
                        DdiStatus: parseFloat((item.ddiStatus ?? 0).toFixed(2)),
                        SurveyId: '',
                        uniqueID: uniqueId,
                        isPrecalculatedRow,
                        isPrecalculatedDeleteRow: false,
                        Order: (index + 1),
                        SurveyCollectionId: 2, // for survey->2
                        SurveyHeaderId: this.SurveyHeaderId
                    };
                    return mappedItem;
                });

                //console.log(dataCal)
                this.getConversionResponse(dataCal);
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Calculations: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Calculations data");
            }
        });
    }

    private getConversionResponse(data) {
        try {
            if (this.WellTableData.length !== 0) {
                this.WellTableData.forEach((res => {
                    //console.log(res)
                    if ((res.SurveyId != '' || res.SurveyId != undefined) && res.isPrecalculatedDeleteRow || res.isPrecalculatedRow) {
                        if (this.tableData5?.RigType === 5 && this.payloadcalculations?.airGap === 0) {
                            // Remove element from index 1 if RigType is 5 and airGap is 0
                            data = data?.filter((_, index) => index !== 1);
                        }
                        else if (this.payloadcalculations?.airGap > 0) {
                            // Remove element from index 2 if airGap is greater than 0
                            data = data?.filter((_, index) => index !== 2);
                        }
                    }
                }));
            }
            const wellupdateData = this.WellTableData.filter(item => !item.isPrecalculatedDeleteRow);
            const activeSurveys = [...data, ...wellupdateData];
            this.activeSurveys = activeSurveys?.map((row: any) => {
                // Iterate through the properties of each row and round numeric values to two decimal places
                Object.keys(row).forEach(key => {
                    if (typeof row[key] === 'number') {
                        row[key] = parseFloat(row[key].toFixed(2));
                    }
                });
                return row;
            });
            this.activeSurveys.sort((a, b) => a.MeasuredDepth - b.MeasuredDepth);
            if (this.unitSystem == "Metric") {
                this.getMetricActiveSurveys();
            }
            console.log("activeSurveys:", this.activeSurveys);
            this.activeSurveyStatus.next({ status: true });
        } catch (err) {
            console.log(err)
        }
    }

    public getMetricActiveSurveys() {
        const payload = { surveys: this.activeSurveys }
        this.postUnitConversion(payload).subscribe({
            next: (conversionApiresponse) => {
                this.ngxLoader.stop();
                if (conversionApiresponse.result.length > 0)
                    this.activeSurveys = conversionApiresponse.result
            },
            error: (error) => {
                this.ngxLoader.stop();
                this.toastr.error("An error occurred while surveys unit conversion");
            }
        })
    }


}//end of class




const arr = [
    "Centralizer, Bow Spring 88.84",
    "Centralizer, Bow Spring 88.84",
    "Centralizer, Bow Spring 73.10",
    "centralizer, Bow Spring 659.93",
    "centralizer, Bow Spring 507.64",
    "centralizer, Bow Spring 507.64",
]