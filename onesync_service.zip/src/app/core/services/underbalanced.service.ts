/*This is underbalanced service, to write functions for API call of underbalanced fluids
*/
import { Injectable } from '@angular/core';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
@Injectable({
  providedIn: 'root'
})
export class UnderBalancedService {
  endPoint: string;
  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends

  /* get underbalanced list */
  getUnderbalancedFluids(ProjectId?) {
    if(ProjectId)
      return this.httpMethod.getMethod(this.endPoint, api.getUnderbalancedFluidsApi+"?ProjectId="+ProjectId);
    else
      return this.httpMethod.getMethod(this.endPoint, api.getUnderbalancedFluidsApi);
  }// end of function

  /* update underbalanced fluids */
  updateUnderbalancedFluids(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateUnderbalancedFluidsApi, payload);
  }// end of function

  /* delete underbalanced fluids */
  deleteUnderbalancedFluids(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteUnderbalancedFluidsApi,payload);
  }// end of function

  /* add underbalanced fluids */
  addUnderbalancedFluids(payload){
    return this.httpMethod.postMethod(this.endPoint, api.addUnderbalancedFluidsApi,payload);
  }//end of function

}