import { Injectable } from '@angular/core';
import { api } from "../constants/api.constants";
import { HttpMethodService } from "./httpMethod.service";

@Injectable({
  providedIn: 'root'
})
export class OneClickCalculationService {
  endPoint: string;
  errors: any;
  constructor(private httpMethod:HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
   }


  getCalculationList(payload){

    return this.httpMethod.postMethod(this.endPoint,api.getCalculationListApi,payload)
  }

  getCalculationCategoryList(ApplicationFlowType,category) {

    return this.httpMethod.getMethod(this.endPoint,api.getCalculationCategoryListApi+"?ApplicationFlowType="+ApplicationFlowType +"&removeCategories="+category)
  }

  getUnitTypeList(){
    return this.httpMethod.getMethod(this.endPoint,api.getUnitTypeListApi)
  }

  getUnitList(typeId){
    return this.httpMethod.getMethod(this.endPoint,api.getUnitListApi +`${typeId}/units/list`)
  }

  saveExpression (record) {

    let payload = {
      addCalculations: [],
      updateCalculations: [],
    };

    if (record && record.CalculationalDataConfigurationId) {

      payload.updateCalculations.push(record);
    } else {
      
      payload.addCalculations.push(record);
    } //end of if condition

    return this.httpMethod.postMethod(this.endPoint, api.postCalculationExpression, payload);
  } //end of saveExpression function

  saveMonitoringCalculation(payload) {
    return this.httpMethod.postMethod(this.endPoint,api.postCalculationExpression,payload)
  }

  deleteMonitoringCalculation(payload) {
    return this.httpMethod.postMethod(this.endPoint,api.deletecalculationmonitoring,payload)
  }
  
  cloneMonitoringCalculation(payload, id) {
    return this.httpMethod.postMethod(this.endPoint,api.postCalculationExpression+`${id}/clone`,payload)
  }


  /**
   * Below function will save data.
   */
  saveCalculationRecords (payload) {

    return this.httpMethod.postMethod(this.endPoint, api.postCalculationExpression, payload);
  } //end of saveExpression function
}