import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { HttpMethodService } from './httpMethod.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventsService {

  endPoint: string;
  private customConnctionRecord = new BehaviorSubject<any>({});
  selectedCustomConnection = this.customConnctionRecord.asObservable();
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){

     this.endPoint = `${api.serviceEndpoint}`;
  }

//Function to fetch connection list

  getEventsList(saveRecords) {

    return this.httpMethod.postMethod(this.endPoint,api.getEventApi,saveRecords)
    // return this.httpMethod.getMethod(this.endPoint,api.getEventApi+"?ApplicationFlowType="+sourceType);
  }
  getCategoryList(sourceType)
  {
        return this.httpMethod.getMethod(this.endPoint,api.getCategoryListApi+"?ApplicationFlowType="+sourceType.ApplicationFlowType);

  }

  //function for post the custom connection list
  postEventsList(saveRecords)
  {
    //console.log("saveRecords",)
    return this.httpMethod.postMethod( this.endPoint,api.postEventsApi,saveRecords)

  }
  
  //function for put or edit custom connection list
  putCustomConnectionList(data1:any){
    return this.httpMethod.putMethod( this.endPoint,api.putCustomConnection,data1)
  }
  
  //Function for delete list
  deleteEventsList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteEventsApi, payload);
  }

  /**
   * Below function will set the value of newly added record.
   */
  setCustomConnection(customConnection: any) {

    this.customConnctionRecord.next(customConnection);
  } //end of 'setCustomConnection' function
} //end of 'CustomConnectionsService'