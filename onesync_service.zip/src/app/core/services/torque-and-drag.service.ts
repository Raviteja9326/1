import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { ActualDataModel, TorqueDragMShearModel, TorqueDrag } from '../interfaces/torqueDrag.interface';
import { CustomValidators } from '../constants/regex.constants';
import { ChartDatasetModel, GraphDataApiResponse, GraphFields, TempChartModel } from '../interfaces/snapshotChart.interface';
import { WellIntervalSimifyService } from './well-interval.service';
import { EquipmentConfigurationService } from './equipmentConfigService.service';
import { WellPathsService } from './wellPaths.service';

@Injectable({
    providedIn: 'root'
})
export class TorqueDragService {
    private PredrillconfigName: string = null;
    private PredrillConfigurationId: number = null;
    private project: { WellId: number, ProjectId: number };
    private SurveyHeaderId: number = null;
    private surveyPointWellRows: any[] = [];
    private equipmentConfigResult = null;
    private ActiveSurveys = [];

    constructor(
        private httpMethodSvc: HttpMethodService,
        private wellIntervalSimifySvc: WellIntervalSimifyService,
        private eqipmentConfigSvc: EquipmentConfigurationService,
        private wellPathSvc: WellPathsService,
        private ngxLoader: NgxUiLoaderService,
        private toastr: ToastrService,
    ) { }

    public setProject = (project: { WellId: number, ProjectId: number }) => this.project = project;
    public setPredrillConfigurationId = (id: number) => this.PredrillConfigurationId = id;
    public setPredrillConfigName = (PredrillconfigName: string) => this.PredrillconfigName = PredrillconfigName;

    public getActiveSurveys = () => this.ActiveSurveys;
    public getPredrillConfigurationId = () => this.PredrillConfigurationId;
    public getPredrillConfigName = () => this.PredrillconfigName;

    public postTorqueDrag(payload): Observable<{ message: string, result: { PredrillConfigurationId: number } }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}`, payload);
    }

    public getTorqueDragList(ProjectId: number): Observable<{ message: string, result: { Name: string, PredrillConfigurationId: number }[] }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDragList}?ProjectId=${ProjectId}`);
    }

    public deleteTorqueDrag(payload: any): Observable<{ message: string, result: any }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/delete`, payload);
    }

    public getTorqueDragDetailById(PredrillConfigurationId: number): Observable<{ message: string, result: TorqueDrag }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/details`);
    }

    public getActualDataList(PredrillConfigurationId: number): Observable<{ message: string, result: ActualDataModel[] }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/actualData/list`);
    }

    public addUpdateActualData(PredrillConfigurationId: number, payload: any): Observable<{ message: string }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/actualData`, payload);
    }

    public deleteActualData(PredrillConfigurationId: number, payload: { deletedIds: number[] }): Observable<{ message: string }> {
        return this.httpMethodSvc.postMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/actualData/delete`, payload);
    }

    public getGraphDataById(PredrillConfigurationId: number): Observable<{ message: string, result: GraphDataApiResponse }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/graph`)
    }

    public getAdditionalGraphDataById(PredrillConfigurationId: number): Observable<{ message: string, result: GraphDataApiResponse }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/graph/additionalData`)
    }

    public getGraphDataInTableFormatById(PredrillConfigurationId: number): Observable<{ message: string, result: { tableData: any[] } }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/graphTableView?Operation=5`);
    }

    public getSummaryDataById(PredrillConfigurationId: number): Observable<{ message: string, result: TorqueDragMShearModel }> {
        return this.httpMethodSvc.getMethod(`${api.serviceEndpoint}`, `${api.torqueDrag}/${PredrillConfigurationId}/summary`);
    }

    public initializeForm(defaultValue: { [key: string]: { operationValue?: number, value: number, from: number, to: number } }) {
        return new FormGroup({
            SurveyIndex: new FormControl("", [Validators.required]),
            WellboreIndex: new FormControl("", [Validators.required]),
            DrillstringIndex: new FormControl("", [Validators.required]),
            FluidIndex: new FormControl("", [Validators.required]),
            FlowRate: new FormControl(defaultValue.FlowRate.value, [
                Validators.required, CustomValidators.greaterThanMin(defaultValue.FlowRate.from, false),
                CustomValidators.lessThanMax(defaultValue.FlowRate.to, false)
            ]),
            BitDepth: new FormControl(defaultValue.BitDepth.value, [
                Validators.required, CustomValidators.greaterThanMin(defaultValue.BitDepth.from, false),
                CustomValidators.lessThanMax(defaultValue.BitDepth.to, false)
            ]),
            Solver: new FormControl(1, [Validators.required]),
            BucklingModel: new FormControl(""),
            BucklingForceFactor: new FormControl(""),
            NumberOfJoints: new FormControl(""),
            RotationalEffects: new FormControl(false),
            operation: new FormControl([1, 2, 4, 8, 16], [Validators.required]),

            ROBTDS: new FormControl(defaultValue.ROBTDS.value),
            TrippingInRS: new FormControl(defaultValue.TrippingInRS.value),
            TrippingOutRS: new FormControl(defaultValue.TrippingOutRS.value),

            DrillingRotaryWOB: new FormControl(defaultValue.DrillingRotaryWOB.value),
            DrillingRotaryTOB: new FormControl(defaultValue.DrillingRotaryTOB.value),
            DrillingRotaryTDS: new FormControl(defaultValue.DrillingRotaryTDS.value),
            DrillingRotaryROP: new FormControl(defaultValue.DrillingRotaryROP.value),
            DrillingSlidingWOB: new FormControl(defaultValue.DrillingSlidingWOB.value),
            DrillingSlidingROP: new FormControl(defaultValue.DrillingSlidingROP.value),

            ReamingTDS: new FormControl(defaultValue.ReamingTDS.value),
            ReamingRS: new FormControl(defaultValue.ReamingRS.value),

            BackReamingTDS: new FormControl(defaultValue.BackReamingTDS.value),
            BackReamingRS: new FormControl(defaultValue.BackReamingRS.value),

            PickupRS: new FormControl(defaultValue.PickupRS.value),
            PickupStuckDepth: new FormControl(defaultValue.PickupStuckDepth.value),
            PickupStuckWeight: new FormControl(defaultValue.PickupStuckWeight.value),

            SlackOffRS: new FormControl(defaultValue.SlackOffRS.value),
            SlackOffStuckDepth: new FormControl(defaultValue.SlackOffStuckDepth.value),
            SlackOffStuckWeight: new FormControl(defaultValue.SlackOffStuckWeight.value),

            UnderreamingTDS: new FormControl(defaultValue.UnderreamingTDS.value),
            UnderreamingWOB: new FormControl(defaultValue.UnderreamingWOB.value),
            UnderreamingTOB: new FormControl(defaultValue.UnderreamingTOB.value),
            UnderreamingROP: new FormControl(defaultValue.UnderreamingROP.value),
            UnderreamingStuckDepth: new FormControl(defaultValue.UnderreamingStuckDepth.value),
            UnderreamingStuckWeight: new FormControl(defaultValue.UnderreamingStuckWeight.value),
            UnderreamingStuckTorque: new FormControl(defaultValue.UnderreamingStuckTorque.value),

            CuttingTDS: new FormControl(defaultValue.CuttingTDS.value),
            CuttingStuckDepth: new FormControl(defaultValue.CuttingStuckDepth.value),
            CuttingStuckTorque: new FormControl(defaultValue.CuttingStuckTorque.value),

            CustomUpTDS: new FormControl(defaultValue.CustomUpTDS.value),
            CustomUpRS: new FormControl(defaultValue.CustomUpRS.value),
            CustomUpStuckDepth: new FormControl(defaultValue.CustomUpStuckDepth.value),
            CustomUpStuckWeight: new FormControl(defaultValue.CustomUpStuckWeight.value),
            CustomUpStuckTorque: new FormControl(defaultValue.CustomUpStuckTorque.value),

            CustomDownTDS: new FormControl(defaultValue.CustomDownTDS.value),
            CustomDownWOB: new FormControl(defaultValue.CustomDownWOB.value),
            CustomDownTOB: new FormControl(defaultValue.CustomDownTOB.value),
            CustomDownROP: new FormControl(defaultValue.CustomDownROP.value),
            CustomDownStuckDepth: new FormControl(defaultValue.CustomDownStuckDepth.value),
            CustomDownStuckWeight: new FormControl(defaultValue.CustomDownStuckWeight.value),
            CustomDownStuckTorque: new FormControl(defaultValue.CustomDownStuckTorque.value),

            CustomStationaryTDS: new FormControl(defaultValue.CustomStationaryTDS.value),
            CustomStationaryWOB: new FormControl(defaultValue.CustomStationaryWOB.value),
            CustomStationaryTOB: new FormControl(defaultValue.CustomStationaryTOB.value),
            CustomStationaryStuckDepth: new FormControl(defaultValue.CustomStationaryStuckDepth.value),
            CustomStationaryStuckTorque: new FormControl(defaultValue.CustomStationaryStuckTorque.value),
        })
    }

    /*
    * map values to post detail api payload from form fields
    */
    public mapFormValuesToPostPayload(torqueDragForm: FormGroup) {
        return {
            input: {
                WellboreIndex: torqueDragForm.value.WellboreIndex,
                DrillstringIndex: torqueDragForm.value.DrillstringIndex,
                FluidIndex: torqueDragForm.value.FluidIndex,
                SurveyIndex: torqueDragForm.value.SurveyIndex,
                FlowRate: torqueDragForm.value.FlowRate,
                BitDepth: torqueDragForm.value.BitDepth,
                Solver: torqueDragForm.value.Solver,
                RotationalEffects: torqueDragForm.value.RotationalEffects,
                BucklingForceFactor: torqueDragForm.value.BucklingForceFactor,
                NumberOfJoints: torqueDragForm.value.NumberOfJoints,

                ROBTDS: torqueDragForm.value.operation.includes(1) ? torqueDragForm.value.ROBTDS : "",
                TrippingInRS: torqueDragForm.value.operation.includes(2) ? torqueDragForm.value.TrippingInRS : "",
                TrippingOutRS: torqueDragForm.value.operation.includes(4) ? torqueDragForm.value.TrippingOutRS : "",

                DrillingRotaryWOB: torqueDragForm.value.operation.includes(8) ? torqueDragForm.value.DrillingRotaryWOB : "",
                DrillingRotaryTOB: torqueDragForm.value.operation.includes(8) ? torqueDragForm.value.DrillingRotaryTOB : "",
                DrillingRotaryTDS: torqueDragForm.value.operation.includes(8) ? torqueDragForm.value.DrillingRotaryTDS : "",
                DrillingRotaryROP: torqueDragForm.value.operation.includes(8) ? torqueDragForm.value.DrillingRotaryROP : "",

                DrillingSlidingWOB: torqueDragForm.value.operation.includes(16) ? torqueDragForm.value.DrillingSlidingWOB : "",
                DrillingSlidingROP: torqueDragForm.value.operation.includes(16) ? torqueDragForm.value.DrillingSlidingROP : "",

                ReamingTDS: torqueDragForm.value.operation.includes(32) ? torqueDragForm.value.ReamingTDS : "",
                ReamingRS: torqueDragForm.value.operation.includes(32) ? torqueDragForm.value.ReamingRS : "",

                BackReamingTDS: torqueDragForm.value.operation.includes(64) ? torqueDragForm.value.BackReamingTDS : "",
                BackReamingRS: torqueDragForm.value.operation.includes(64) ? torqueDragForm.value.BackReamingRS : "",

                PickupRS: torqueDragForm.value.operation.includes(128) ? torqueDragForm.value.PickupRS : "",
                PickupStuckDepth: torqueDragForm.value.operation.includes(128) ? torqueDragForm.value.PickupStuckDepth : "",
                PickupStuckWeight: torqueDragForm.value.operation.includes(128) ? torqueDragForm.value.PickupStuckWeight : "",

                SlackOffRS: torqueDragForm.value.operation.includes(256) ? torqueDragForm.value.SlackOffRS : "",
                SlackOffStuckDepth: torqueDragForm.value.operation.includes(256) ? torqueDragForm.value.SlackOffStuckDepth : "",
                SlackOffStuckWeight: torqueDragForm.value.operation.includes(256) ? torqueDragForm.value.SlackOffStuckWeight : "",

                UnderreamingTDS: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingTDS : "",
                UnderreamingWOB: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingWOB : "",
                UnderreamingTOB: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingTOB : "",
                UnderreamingROP: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingROP : "",
                UnderreamingStuckDepth: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingStuckDepth : "",
                UnderreamingStuckWeight: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingStuckWeight : "",
                UnderreamingStuckTorque: torqueDragForm.value.operation.includes(512) ? torqueDragForm.value.UnderreamingStuckTorque : "",

                CuttingTDS: torqueDragForm.value.operation.includes(1024) ? torqueDragForm.value.CuttingTDS : "",
                CuttingStuckDepth: torqueDragForm.value.operation.includes(1024) ? torqueDragForm.value.CuttingStuckDepth : "",
                CuttingStuckTorque: torqueDragForm.value.operation.includes(1024) ? torqueDragForm.value.CuttingStuckTorque : "",

                CustomUpTDS: torqueDragForm.value.operation.includes(2048) ? torqueDragForm.value.CustomUpTDS : "",
                CustomUpRS: torqueDragForm.value.operation.includes(2048) ? torqueDragForm.value.CustomUpRS : "",
                CustomUpStuckDepth: torqueDragForm.value.operation.includes(2048) ? torqueDragForm.value.CustomUpStuckDepth : "",
                CustomUpStuckWeight: torqueDragForm.value.operation.includes(2048) ? torqueDragForm.value.CustomUpStuckWeight : "",
                CustomUpStuckTorque: torqueDragForm.value.operation.includes(2048) ? torqueDragForm.value.CustomUpStuckTorque : "",

                CustomDownTDS: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownTDS : "",
                CustomDownWOB: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownWOB : "",
                CustomDownTOB: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownTOB : "",
                CustomDownROP: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownROP : "",
                CustomDownStuckDepth: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownStuckDepth : "",
                CustomDownStuckWeight: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownStuckWeight : "",
                CustomDownStuckTorque: torqueDragForm.value.operation.includes(4096) ? torqueDragForm.value.CustomDownStuckTorque : "",

                CustomStationaryTDS: torqueDragForm.value.operation.includes(8192) ? torqueDragForm.value.CustomStationaryTDS : "",
                CustomStationaryWOB: torqueDragForm.value.operation.includes(8192) ? torqueDragForm.value.CustomStationaryWOB : "",
                CustomStationaryTOB: torqueDragForm.value.operation.includes(8192) ? torqueDragForm.value.CustomStationaryTOB : "",
                CustomStationaryStuckDepth: torqueDragForm.value.operation.includes(8192) ? torqueDragForm.value.CustomStationaryStuckDepth : "",
                CustomStationaryStuckTorque: torqueDragForm.value.operation.includes(8192) ? torqueDragForm.value.CustomStationaryStuckTorque : "",

                BlockWeight: 0, // 1
                FrictionFactorSensitivityMin: 1,
                FrictionFactorSensitivityMax: 1,
                FrictionFactorSensitivityStep: 1,
                CalculateBHAContactForce: false, // 1,
                Operation: torqueDragForm.value.operation.reduce((a: number, b: number) => a + b),
            },
            WellId: 9,
            Name: this.PredrillconfigName,
            ActiveSurveys: this.ActiveSurveys,
            ROBSelected: torqueDragForm.value.operation.includes(1) || false,
            TrippingInSelected: torqueDragForm.value.operation.includes(2) || false,
            TrippingOutSelected: torqueDragForm.value.operation.includes(4) || false,
            RotaryDrillingSelected: torqueDragForm.value.operation.includes(8) || false,
            SlidingDrillingSelected: torqueDragForm.value.operation.includes(16) || false,
            ReamingSelected: torqueDragForm.value.operation.includes(32) || false,
            BackReamingSelected: torqueDragForm.value.operation.includes(64) || false,
            PickupSelected: torqueDragForm.value.operation.includes(128) || false,
            SlackOffSelected: torqueDragForm.value.operation.includes(256) || false,
            UnderReamingSelected: torqueDragForm.value.operation.includes(512) || false,
            CuttingSelected: torqueDragForm.value.operation.includes(1024) || false,
            CustomUpSelected: torqueDragForm.value.operation.includes(2048) || false,
            CustomDownSelected: torqueDragForm.value.operation.includes(4096) || false,
            CustomStationarySelected: torqueDragForm.value.operation.includes(8192) || false,

            DrillstringAnalisysOutputGraphXML: 1,
            FFSensitivityOutputGraphXML: 1,
            ExperimentGroup: 1,
            FFSensitivitySelection: 1,
            HookLoadActualTrippingInSelected: 1,
            HookLoadActualTrippingOutSelected: 1,
            HookLoadActualROBSelected: 1,
            ActualSurfaceTorqueSelected: 1,
            BucklingThresholdSelected: 1,
            TensileThresholdSelected: 1,
            TorqueThresholdSelected: 1,
            YieldStressThresholdSelected: 1,
            ActualDataSelected: 1,
            RigHoistingCapacitySelected: 1,
            RigTorqueCapacitySelected: 1,
        }
    }

    /*
    * map values from get detail api response to form fields
    */
    public mapApiresponseToFormValues(apiResponseResult) {
        const _operation = [];
        if (apiResponseResult.ROBSelected)
            _operation.push(1);
        if (apiResponseResult.TrippingInSelected)
            _operation.push(2);
        if (apiResponseResult.TrippingOutSelected)
            _operation.push(4);
        if (apiResponseResult.RotaryDrillingSelected)
            _operation.push(8);
        if (apiResponseResult.SlidingDrillingSelected)
            _operation.push(16);
        if (apiResponseResult.ReamingSelected)
            _operation.push(32);
        if (apiResponseResult.BackReamingSelected)
            _operation.push(64);
        if (apiResponseResult.PickupSelected)
            _operation.push(128);
        if (apiResponseResult.SlackOffSelected)
            _operation.push(256);
        if (apiResponseResult.UnderReamingSelected)
            _operation.push(512);
        if (apiResponseResult.CuttingSelected)
            _operation.push(1024);
        if (apiResponseResult.CustomUpSelected)
            _operation.push(2048);
        if (apiResponseResult.CustomDownSelected)
            _operation.push(4096)
        if (apiResponseResult.CustomStationarySelected)
            _operation.push(8192);

        return {
            WellboreIndex: apiResponseResult.input.WellboreIndex,
            DrillstringIndex: apiResponseResult.input.DrillstringIndex,
            FluidIndex: apiResponseResult.input.FluidIndex,
            SurveyIndex: apiResponseResult.input.SurveyIndex,
            FlowRate: apiResponseResult.input.FlowRate,
            BitDepth: apiResponseResult.input.BitDepth,
            Solver: apiResponseResult.input.Solver,
            RotationalEffects: apiResponseResult.input.RotationalEffects || false,
            BucklingForceFactor: apiResponseResult.input.BucklingForceFactor,
            NumberOfJoints: apiResponseResult.input.NumberOfJoints,
            operation: _operation,
            BucklingModel: "",

            ROBTDS: apiResponseResult.ROBSelected ? apiResponseResult.input.ROBTDS : "",
            TrippingInRS: apiResponseResult.TrippingInSelected ? apiResponseResult.input.TrippingInRS : "",
            TrippingOutRS: apiResponseResult.TrippingOutSelected ? apiResponseResult.input.TrippingOutRS : "",

            DrillingRotaryWOB: apiResponseResult.RotaryDrillingSelected ? apiResponseResult.input.DrillingRotaryWOB : "",
            DrillingRotaryTOB: apiResponseResult.RotaryDrillingSelected ? apiResponseResult.input.DrillingRotaryTOB : "",
            DrillingRotaryTDS: apiResponseResult.RotaryDrillingSelected ? apiResponseResult.input.DrillingRotaryTDS : "",
            DrillingRotaryROP: apiResponseResult.RotaryDrillingSelected ? apiResponseResult.input.DrillingRotaryROP : "",

            DrillingSlidingWOB: apiResponseResult.SlidingDrillingSelected ? apiResponseResult.input.DrillingSlidingWOB : "",
            DrillingSlidingROP: apiResponseResult.SlidingDrillingSelected ? apiResponseResult.input.DrillingSlidingROP : "",

            ReamingTDS: apiResponseResult.ReamingSelected ? apiResponseResult.input.ReamingTDS : "",
            ReamingRS: apiResponseResult.ReamingSelected ? apiResponseResult.input.ReamingRS : "",

            BackReamingTDS: apiResponseResult.BackReamingSelected ? apiResponseResult.input.BackReamingTDS : "",
            BackReamingRS: apiResponseResult.BackReamingSelected ? apiResponseResult.input.BackReamingRS : "",

            PickupRS: apiResponseResult.PickupSelected ? apiResponseResult.input.PickupRS : "",
            PickupStuckDepth: apiResponseResult.PickupSelected ? apiResponseResult.input.PickupStuckDepth : "",
            PickupStuckWeight: apiResponseResult.PickupSelected ? apiResponseResult.input.PickupStuckWeight : "",

            SlackOffRS: apiResponseResult.SlackOffSelected ? apiResponseResult.input.SlackOffRS : "",
            SlackOffStuckDepth: apiResponseResult.SlackOffSelected ? apiResponseResult.input.SlackOffStuckDepth : "",
            SlackOffStuckWeight: apiResponseResult.SlackOffSelected ? apiResponseResult.input.SlackOffStuckWeight : "",

            UnderreamingTDS: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingTDS : "",
            UnderreamingWOB: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingWOB : "",
            UnderreamingTOB: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingTOB : "",
            UnderreamingROP: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingROP : "",
            UnderreamingStuckDepth: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingStuckDepth : "",
            UnderreamingStuckWeight: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingStuckWeight : "",
            UnderreamingStuckTorque: apiResponseResult.UnderReamingSelected ? apiResponseResult.input.UnderreamingStuckTorque : "",

            CuttingTDS: apiResponseResult.CuttingSelected ? apiResponseResult.input.CuttingTDS : "",
            CuttingStuckDepth: apiResponseResult.CuttingSelected ? apiResponseResult.input.CuttingStuckDepth : "",
            CuttingStuckTorque: apiResponseResult.CuttingSelected ? apiResponseResult.input.CuttingStuckTorque : "",

            CustomUpTDS: apiResponseResult.CustomUpSelected ? apiResponseResult.input.CustomUpTDS : "",
            CustomUpRS: apiResponseResult.CustomUpSelected ? apiResponseResult.input.CustomUpRS : "",
            CustomUpStuckDepth: apiResponseResult.CustomUpSelected ? apiResponseResult.input.CustomUpStuckDepth : "",
            CustomUpStuckWeight: apiResponseResult.CustomUpSelected ? apiResponseResult.input.CustomUpStuckWeight : "",
            CustomUpStuckTorque: apiResponseResult.CustomUpSelected ? apiResponseResult.input.CustomUpStuckTorque : "",

            CustomDownTDS: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownTDS : "",
            CustomDownWOB: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownWOB : "",
            CustomDownTOB: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownTOB : "",
            CustomDownROP: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownROP : "",
            CustomDownStuckDepth: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownStuckDepth : "",
            CustomDownStuckWeight: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownStuckWeight : "",
            CustomDownStuckTorque: apiResponseResult.CustomDownSelected ? apiResponseResult.input.CustomDownStuckTorque : "",

            CustomStationaryTDS: apiResponseResult.CustomStationarySelected ? apiResponseResult.input.CustomStationaryTDS : "",
            CustomStationaryWOB: apiResponseResult.CustomStationarySelected ? apiResponseResult.input.CustomStationaryWOB : "",
            CustomStationaryTOB: apiResponseResult.CustomStationarySelected ? apiResponseResult.input.CustomStationaryTOB : "",
            CustomStationaryStuckDepth: apiResponseResult.CustomStationarySelected ? apiResponseResult.input.CustomStationaryStuckDepth : "",
            CustomStationaryStuckTorque: apiResponseResult.CustomStationarySelected ? apiResponseResult.input.CustomStationaryStuckTorque : "",
        }
    }

    public mapGraphResponseToTempChartModel(data: GraphDataApiResponse) {
        const _tempChartData: TempChartModel = {
            axialLoad: {
                datasetMax: Math.max(
                    Math.max(...data.AxialLoad.map(x => x['Sin. Buckling Threshold'])),
                    Math.max(...data.AxialLoad.map(x => x['Hel. Buckling Threshold'])),
                    Math.max(...data.AxialLoad.map(x => x['Hel. BucklingThresholdRotary'])),
                    Math.max(...data.AxialLoad.map(x => x['Tension Threshold'])),
                    Math.max(...data.AxialLoad.map(x => x.CompressionLimit)),
                    Math.max(...data.AxialLoad.map(x => x.RoffB))
                ),
                datasetMin: Math.min(
                    Math.min(...data.AxialLoad.map(x => x['Sin. Buckling Threshold'])),
                    Math.min(...data.AxialLoad.map(x => x['Hel. Buckling Threshold'])),
                    Math.min(...data.AxialLoad.map(x => x['Hel. BucklingThresholdRotary'])),
                    Math.min(...data.AxialLoad.map(x => x['Tension Threshold'])),
                    Math.min(...data.AxialLoad.map(x => x.CompressionLimit)),
                    Math.min(...data.AxialLoad.map(x => x.RoffB))
                ),
                datasets: [
                    {
                        data: data.AxialLoad.map(x => x['Sin. Buckling Threshold']),
                        label: "Sin. Buckling Threshold",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.AxialLoad.map(x => x['Hel. Buckling Threshold']),
                        label: "Hel. Buckling Threshold",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    },
                    {
                        data: data.AxialLoad.map(x => x['Hel. BucklingThresholdRotary']),
                        label: "Hel. BucklingThresholdRotary",
                        backgroundColor: "green",
                        borderColor: "green",
                        borderWidth: 1
                    },
                    {
                        data: data.AxialLoad.map(x => x['Tension Threshold']),
                        label: "Tension Threshold",
                        backgroundColor: "yellow",
                        borderColor: "yellow",
                        borderWidth: 1
                    },
                    {
                        data: data.AxialLoad.map(x => x.CompressionLimit),
                        label: "Compression Limit",
                        backgroundColor: "orange",
                        borderColor: "orange",
                        borderWidth: 1
                    },
                    {
                        data: data.AxialLoad.map(x => x.RoffB),
                        label: "RoffB",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.AxialLoad.map(x => x.MeasuredDepth)),
                labels: data.AxialLoad.map(x => x.MeasuredDepth)
            },
            torque: {
                datasetMax: Math.max(
                    Math.max(...data.Torque.map(x => x['Torque Threshold'])),
                    Math.max(...data.Torque.map(x => x['Make Up Torque'])),
                    Math.max(...data.Torque.map(x => x.RoffB))
                ),
                datasetMin: Math.min(
                    Math.min(...data.Torque.map(x => x['Torque Threshold'])),
                    Math.min(...data.Torque.map(x => x['Make Up Torque'])),
                    Math.min(...data.Torque.map(x => x.RoffB))
                ),
                datasets: [
                    {
                        data: data.Torque.map(x => x['Torque Threshold']),
                        label: "Torque Threshold",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.Torque.map(x => x['Make Up Torque']),
                        label: "Make Up Torque",
                        backgroundColor: "Blue",
                        borderColor: "Blue",
                        borderWidth: 1
                    },
                    {
                        data: data.Torque.map(x => x.RoffB),
                        label: "RoffB",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.Torque.map(x => x.MeasuredDepth)),
                labels: data.Torque.map(x => x.MeasuredDepth)
            },
            contactForce: {
                datasetMax: Math.max(...data.ContactForce.map(x => x.RoffB)),
                datasetMin: Math.min(...data.ContactForce.map(x => x.RoffB)),
                datasets: [
                    {
                        data: data.ContactForce.map(x => x.RoffB),
                        label: "RoffB",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.ContactForce.map(x => x.MeasuredDepth)),
                labels: data.ContactForce.map(x => x.MeasuredDepth),
            },
            vonMisesStress: {
                datasetMax: Math.max(
                    Math.max(...data.VoidMisesStress.map(x => x['Yield Stress Threshold'])),
                    Math.max(...data.VoidMisesStress.map(x => x.RoffB))
                ),
                datasetMin: Math.min(
                    Math.min(...data.VoidMisesStress.map(x => x['Yield Stress Threshold'])),
                    Math.min(...data.VoidMisesStress.map(x => x.RoffB))
                ),
                datasets: [
                    {
                        data: data.VoidMisesStress.map(x => x['Yield Stress Threshold']),
                        label: "Yield Stress Threshold",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.VoidMisesStress.map(x => x.RoffB),
                        label: "RoffB",
                        backgroundColor: "blue",
                        borderColor: "blue",
                        borderWidth: 1
                    }
                ],
                labelMax: Math.max(...data.VoidMisesStress.map(x => x.MeasuredDepth)),
                labels: data.VoidMisesStress.map(x => x.MeasuredDepth)
            },
            hookLoad: {
                datasetMax: Math.max(
                    Math.max(...data.HookLoad.map(x => x['Hel Buckling HL Threshold'])),
                    Math.max(...data.HookLoad.map(x => x['Sin Buckling HL Threshold'])),
                    Math.max(...data.HookLoad.map(x => x['Tensile Overload HL Threshold'])),
                    Math.max(...data.HookLoad.map(x => x['Rig Hoisting Capacity'])),
                    Math.max(...data.HookLoad.map(x => x['Running In'])),
                    Math.max(...data.HookLoad.map(x => x['Pulling Out']))
                ),
                datasetMin: Math.min(
                    Math.min(...data.HookLoad.map(x => x['Hel Buckling HL Threshold'])),
                    Math.min(...data.HookLoad.map(x => x['Sin Buckling HL Threshold'])),
                    Math.min(...data.HookLoad.map(x => x['Tensile Overload HL Threshold'])),
                    Math.min(...data.HookLoad.map(x => x['Rig Hoisting Capacity'])),
                    Math.min(...data.HookLoad.map(x => x['Running In'])),
                    Math.min(...data.HookLoad.map(x => x['Pulling Out']))
                ),
                datasets: [
                    {
                        data: data.HookLoad.map(x => x['Hel Buckling HL Threshold']),
                        label: "Hel Buckling HL Threshold",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.HookLoad.map(x => x['Sin Buckling HL Threshold']),
                        label: "Sin Buckling HL Threshold",
                        backgroundColor: "green",
                        borderColor: "green",
                        borderWidth: 1
                    },
                    {
                        data: data.HookLoad.map(x => x['Tensile Overload HL Threshold']),
                        label: "Tensile Overload HL Threshold",
                        backgroundColor: "yellow",
                        borderColor: "yellow",
                        borderWidth: 1
                    },
                    {
                        data: data.HookLoad.map(x => x['Rig Hoisting Capacity']),
                        label: "Rig Hoisting Capacity",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    },
                    {
                        data: data.HookLoad.map(x => x['Running In']),
                        label: "Running In",
                        backgroundColor: "blue",
                        borderColor: "blue",
                        borderWidth: 1
                    },
                    {
                        data: data.HookLoad.map(x => x['Pulling Out']),
                        label: "Pulling Out",
                        backgroundColor: "orange",
                        borderColor: "orange",
                        borderWidth: 1
                    },
                ],
                labelMax: Math.max(...data.HookLoad.map(x => x.MeasuredDepth)),
                labels: data.HookLoad.map(x => x.MeasuredDepth)
            },
            surfaceTorque: {
                datasetMax: Math.max(
                    Math.max(...data.SurfaceTorque.map(x => x['Surface Torque Threshold'])),
                    Math.max(...data.SurfaceTorque.map(x => x['Rig Hoisting Capacity'])),
                    Math.max(...data.SurfaceTorque.map(x => x['Running In'])),
                    Math.max(...data.SurfaceTorque.map(x => x['Pulling Out']))
                ),
                datasetMin: Math.min(
                    Math.min(...data.SurfaceTorque.map(x => x['Surface Torque Threshold'])),
                    Math.min(...data.SurfaceTorque.map(x => x['Rig Hoisting Capacity'])),
                    Math.min(...data.SurfaceTorque.map(x => x['Running In'])),
                    Math.min(...data.SurfaceTorque.map(x => x['Pulling Out']))
                ),
                datasets: [
                    {
                        data: data.SurfaceTorque.map(x => x['Surface Torque Threshold']),
                        label: "Surface Torque Threshold",
                        backgroundColor: "red",
                        borderColor: "red",
                        borderWidth: 1
                    },
                    {
                        data: data.SurfaceTorque.map(x => x['Rig Hoisting Capacity']),
                        label: "Rig Hoisting Capacity",
                        backgroundColor: "green",
                        borderColor: "green",
                        borderWidth: 1
                    },
                    {
                        data: data.SurfaceTorque.map(x => x['Running In']),
                        label: "Running In",
                        backgroundColor: "yellow",
                        borderColor: "blue",
                        borderWidth: 1
                    },
                    {
                        data: data.SurfaceTorque.map(x => x['Pulling Out']),
                        label: "Pulling Out",
                        backgroundColor: "pink",
                        borderColor: "pink",
                        borderWidth: 1
                    },
                ],
                labelMax: Math.max(...data.SurfaceTorque.map(x => x.MeasuredDepth)),
                labels: data.SurfaceTorque.map(x => x.MeasuredDepth)
            },
        }
        return _tempChartData;
    }

    private createDataSet(list: GraphFields[]): ChartDatasetModel {
        const _BackReamings = list.map(x => x.BackReaming);
        const _CustomDowns = list.map(x => x.CustomDown);
        const _CustomStationarys = list.map(x => x.CustomStationary);
        const _CustomUps = list.map(x => x.CustomUp);
        const _Cuttings = list.map(x => x.Cutting);
        const _DrillingRotarys = list.map(x => x.DrillingRotary);
        const _DrillingSlidings = list.map(x => x.DrillingSliding);
        const _PickUps = list.map(x => x.PickUp);
        const _PullingOuts = list.map(x => x.PullingOut);
        const _Reamings = list.map(x => x.Reaming);
        const _RoffBs = list.map(x => x.RoffB);
        const _RunningIns = list.map(x => x.RunningIn);
        const _SlackOffs = list.map(x => x.SlackOff);
        const _Underreamings = list.map(x => x.Underreaming);

        const datasetMax = Math.max(
            Math.max(..._BackReamings), Math.max(..._CustomDowns), Math.max(..._CustomStationarys), Math.max(..._CustomUps),
            Math.max(..._Cuttings), Math.max(..._DrillingRotarys), Math.max(..._DrillingSlidings), Math.max(..._PickUps),
            Math.max(..._PullingOuts), Math.max(..._Reamings), Math.max(..._RoffBs), Math.max(..._RunningIns),
            Math.max(..._SlackOffs), Math.max(..._Underreamings)
        )

        const datasetMin = Math.min(
            Math.min(..._BackReamings), Math.min(..._CustomDowns), Math.min(..._CustomStationarys), Math.min(..._CustomUps),
            Math.min(..._Cuttings), Math.min(..._DrillingRotarys), Math.min(..._DrillingSlidings), Math.min(..._PickUps),
            Math.min(..._PullingOuts), Math.min(..._Reamings), Math.min(..._RoffBs), Math.min(..._RunningIns),
            Math.min(..._SlackOffs), Math.min(..._Underreamings)
        )

        const datasets = [
            { data: _BackReamings, label: "Back Reaming", backgroundColor: "red", borderColor: "red", hidden: true, borderWidth: 1 },
            { data: _CustomDowns, label: "Custom Down", backgroundColor: "green", borderColor: "green", hidden: true, borderWidth: 1 },
            { data: _CustomStationarys, label: "Custom Stationary", backgroundColor: "blue", borderColor: "blue", hidden: true, borderWidth: 1 },
            { data: _CustomUps, label: "Custom Up", backgroundColor: "orange", borderColor: "orange", hidden: true, borderWidth: 1 },
            { data: _Cuttings, label: "Cutting", backgroundColor: "indigo", borderColor: "indigo", hidden: true, borderWidth: 1 },
            { data: _DrillingRotarys, label: "Drilling Rotary", backgroundColor: "yellow", borderColor: "yellow", hidden: true, borderWidth: 1 },
            { data: _DrillingSlidings, label: "Drilling Sliding", backgroundColor: "pink", borderColor: "pink", hidden: true, borderWidth: 1 },
            { data: _PickUps, label: "Pick Up", backgroundColor: "grey", borderColor: "grey", hidden: true, borderWidth: 1 },
            { data: _PullingOuts, label: "Pulling Out", backgroundColor: "red", borderColor: "red", hidden: true, borderWidth: 1 },
            { data: _Reamings, label: "Reaming", backgroundColor: "green", borderColor: "green", hidden: true, borderWidth: 1 },
            { data: _RoffBs, label: "RoffB", backgroundColor: "blue", borderColor: "blue", hidden: false, borderWidth: 1 },
            { data: _RunningIns, label: "Running In", backgroundColor: "orange", borderColor: "orange", hidden: false, borderWidth: 1 },
            { data: _SlackOffs, label: "Slack Off", backgroundColor: "indigo", borderColor: "indigo", hidden: true, borderWidth: 1 },
            { data: _Underreamings, label: "Underreaming", backgroundColor: "yellow", borderColor: "yellow", hidden: true, borderWidth: 1 },
        ]

        const labels = list.map(x => x.MeasuredDepth);
        const labelMax = Math.max(...labels);
        return { datasetMax, datasetMin, datasets, labelMax, labels };

    }

    public mapAdditionalGraphResponseToTempChartModel(data: GraphDataApiResponse) {
        const _tempChartData: TempChartModel = {
            axialStress: this.createDataSet(data.AxialStress),
            bendingStress: this.createDataSet(data.BendingStress),
            shearStress: this.createDataSet(data.ShearStress),
            hoopStress: this.createDataSet(data.HoopStress),
            stringPosY: this.createDataSet(data.SS_StringPosY),
            stringPosZ: this.createDataSet(data.SS_StringPosZ),
            pressureDrillstring: this.createDataSet(data.PressureDrillstring),
            radialStress: this.createDataSet(data.RadialStress),
            trueAxialLoad: this.createDataSet(data.TrueAxialLoad),
            torsionalStress: this.createDataSet(data.TorsionalStress),
            bendingMoment: this.createDataSet(data.BendingMoment),
            buoyantWeight: this.createDataSet(data.Buoyantweight),
            eccentricity: this.createDataSet(data.Eccentricity),
            pressureAnnulus: this.createDataSet(data.PressureAnnulus),
            radialClearance: this.createDataSet(data.RadialClearance),
            stretchShortening: this.createDataSet(data.Stretch),
            twistAngle: this.createDataSet(data.TwistAngle),
            //minwob
        }
        return _tempChartData;
    }

    public performWellpathCalculations(SurveyHeaderId: number) {
        this.SurveyHeaderId = SurveyHeaderId;
        this.getSurveyPointsList();
    }

    private getSurveyPointsList() {
        this.ngxLoader.start();
        this.surveyPointWellRows = [];
        this.wellPathSvc.getSurveyPointsList(this.SurveyHeaderId, 2).subscribe({
            next: (apiResponse) => {
                this.ngxLoader.stop();
                console.log("ffffff------", apiResponse)
                if (apiResponse && apiResponse.message == "Success" && apiResponse.result.wellRows) {
                    if (apiResponse.result.wellRows.length > 0) {
                        this.surveyPointWellRows = apiResponse.result.wellRows.map((row: any) => {
                            // Iterate through the properties of each row and round numeric values to two decimal places
                            Object.keys(row).forEach(key => {
                                if (typeof row[key] === 'number') {
                                    row[key] = Number(row[key].toFixed(2));
                                }
                            });
                            return row;
                        });
                        this.surveyPointWellRows.sort((a, b) => a.MeasuredDepth - b.MeasuredDepth);
                        this.getWellintervalList();
                        console.log("surveyPointWellRows: ", this.surveyPointWellRows)
                    } else {
                        this.surveyPointWellRows = [];
                        this.getWellintervalList();
                    }
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Surveypoint: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Surveypoint data");
            }
        });
    }

    private getWellintervalList() {
        this.ngxLoader.start();
        this.wellIntervalSimifySvc.getWellintervalList(this.project.ProjectId).subscribe({
            next: (apiResponse) => {
                this.ngxLoader.stop();
                console.log("aaaaaaa------", apiResponse);
                if (apiResponse && apiResponse.message == "Success" && apiResponse.result.length > 0) {
                    const _activeItem = apiResponse.result.find(item => item.Active == true);
                    if (_activeItem) {
                        this.getCasingList(_activeItem.WellboreSectionId);
                    } else {
                        this.toastr.error("No active wellinterval for wellpath calculations");
                    }
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Wellinterval: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Wellinterval data");
            }
        });
    }

    private getCasingList(WellboreSectionId: number) {
        this.ngxLoader.start();
        this.wellIntervalSimifySvc.getCasingList(WellboreSectionId, 'open_hole').subscribe({
            next: (apiResponse) => {
                this.ngxLoader.stop();
                console.log("bbbbb------", apiResponse);
                if (apiResponse && apiResponse.message == "Success" && apiResponse.result.length > 0) {
                    const _mappedMD = apiResponse.result.map(item => ({ MeasuredDepth: !Number.isNaN(item.MeasuredDepth) ? Number(item.MeasuredDepth.toFixed(2)) : 0 }));
                    console.log(_mappedMD);
                    this.getEquipmentConfigListByProjectId(_mappedMD);
                } else {
                    this.toastr.error("No openholeinterval for wellpath calculations");
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Casinglist: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Casinglist data");
            }
        });
    }

    private getEquipmentConfigListByProjectId(mappedMD: { MeasuredDepth: number }[]) {
        this.ngxLoader.start();
        this.eqipmentConfigSvc.getEquipmentConfigListByProjectId(this.project.ProjectId).subscribe({
            next: (apiResponse) => {
                this.ngxLoader.stop();
                console.log("ccccccc------", apiResponse);
                if (apiResponse && apiResponse.message == "Success" && apiResponse.result.length > 0) {
                    this.equipmentConfigResult = apiResponse.result[0];
                    let waterDepth: number;
                    let airGap: number;
                    if (this.equipmentConfigResult.RigType == 5) { // for RigType -> Land(5)
                        waterDepth = 0;
                        airGap = Number((this.equipmentConfigResult.KellyBushingTVD - this.equipmentConfigResult.ElevationTVD).toFixed(2));
                    } else {
                        waterDepth = Number(this.equipmentConfigResult.ElevationTVD.toFixed(2));
                        airGap = Number(this.equipmentConfigResult.KellyBushingTVD.toFixed(2));
                    }
                    const _calculationPayload = {
                        "equipmentConfiguration": {
                            "rigAzimuth": Number(this.equipmentConfigResult.RigAzimuth.toFixed(2)),
                            "formationAzimuth": Number(this.equipmentConfigResult.FormationAzimuth.toFixed(2)),
                            "rigInclination": Number(this.equipmentConfigResult.RigInclination.toFixed(2)),
                            "formationInclination": Number(this.equipmentConfigResult.FormationInclination.toFixed(2))
                        },
                        "airGap": airGap,
                        "waterDepth": waterDepth,
                        "openHoleIntervalsActive": mappedMD,
                        "KellyBushing": Number(this.equipmentConfigResult.KellyBushingTVD.toFixed(2)),
                        "ElevationTVD": Number(this.equipmentConfigResult.ElevationTVD.toFixed(2))
                    };
                    console.log("_calculationPayload:", _calculationPayload)
                    this.calculationsWellpathsList(_calculationPayload);
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Equipment configuration: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Equipment configuration data");
            }
        });
    }

    private calculationsWellpathsList(calculationPayload: any) {
        this.ngxLoader.start();
        this.wellPathSvc.calculationsWellpathsList(calculationPayload, 'GetWellPath', 'POST').subscribe({
            next: (apiResponse) => {
                this.ngxLoader.stop();
                console.log("ddddddd------", apiResponse);
                if (apiResponse && apiResponse.message == "Success" && apiResponse.result.length > 0) {
                    const _mappedData = apiResponse.result.map((item: any, index) => {
                        const uniqueId = Date.now() + index;
                        const isPrecalculatedRow = (calculationPayload.airGap === 0 && index === 1) || (calculationPayload.airGap !== 0 && index === 2);
                        const mappedItem: any = {
                            MeasuredDepth: parseFloat((item.measuredDepth ?? 0).toFixed(20)),
                            Azimuth: parseFloat((item.azimuth ?? 0).toFixed(20)),
                            Inclination: parseFloat((item.inclination ?? 0).toFixed(20)),
                            NorthSouth: parseFloat((item.northSouth ?? 0).toFixed(20)),
                            EastWest: parseFloat((item.eastWest ?? 0).toFixed(20)),
                            TrueVerticalDepth: parseFloat((item.trueVerticalDepth ?? 0).toFixed(20)),
                            TVDSS: parseFloat((item.tvdss ?? 0).toFixed(20)),
                            LateralDistance: parseFloat((item.lateralDistance ?? 0).toFixed(20)),
                            DogLegSeverity: parseFloat((item.dogLegSeverity ?? 0).toFixed(20)),
                            BuildRate: parseFloat((item.buildRate ?? 0).toFixed(20)),
                            TurnRate: parseFloat((item.turnRate ?? 0).toFixed(20)),
                            DDI: parseFloat((item.ddi ?? 0).toFixed(20)),
                            VSec: parseFloat((item.vSec ?? 0).toFixed(20)),
                            HDisp: parseFloat((item.hDisp ?? 0).toFixed(20)),
                            Tortuosity: parseFloat((item.tortuosity ?? 0).toFixed(20)),
                            ABSTortuosity: parseFloat((item.absTortuosity ?? 0).toFixed(20)),
                            CourseLength: parseFloat((item.courseLength ?? 0).toFixed(20)),
                            ToolFace: parseFloat((item.toolFace ?? 0).toFixed(20)),
                            DdiStatus: parseFloat((item.ddiStatus ?? 0).toFixed(20)),
                            SurveyId: '',
                            uniqueID: uniqueId,
                            isPrecalculatedRow,
                            isPrecalculatedDeleteRow: false,
                            Order: 265,
                            SurveyCollectionId: 2, // this.selected2
                            SurveyHeaderId: this.SurveyHeaderId // parseInt(this.selected, 10)
                        };
                        return mappedItem;
                    });
                    console.log(_mappedData)
                    this.getConversionResponse(_mappedData, calculationPayload);
                }
            },
            error: (error) => {
                this.ngxLoader.stop();
                if (error.error.message)
                    this.toastr.info("Wellpath calculation: " + error.error.message);
                else
                    this.toastr.error("An error occurred while fetching Wellpath calculation data");
            }
        });
    }

    private getConversionResponse(data, calculationPayload) {
        if (this.surveyPointWellRows.length >= 0) {
            this.surveyPointWellRows.forEach((res => {
                if ((res.SurveyId != '' || res.SurveyId != undefined) && res.isPrecalculatedDeleteRow || res.isPrecalculatedRow) {
                    if (this.equipmentConfigResult?.RigType === 5 && calculationPayload?.airGap === 0) {
                        // Remove element from index 1 if RigType is 5 and airGap is 0
                        data = data?.filter((_, index) => index !== 1);
                    } else if (calculationPayload?.airGap > 0) {
                        // Remove element from index 2 if airGap is greater than 0
                        data = data?.filter((_, index) => index !== 2);
                    }
                }
            }));
        }
        this.ActiveSurveys = data;
        console.log(data)
    }

}
