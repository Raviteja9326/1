import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { HttpMethodService } from "./httpMethod.service";
import { Observable } from "rxjs";
import { GetParameters } from "../interfaces/inspectionChart.interface";

@Injectable({
    providedIn: 'root'
})

export class InspectionChartsService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService: HttpClient, private httpMethod: HttpMethodService) {

        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
         *
         * This function will get the list of Surveys, trajectorie and surveys vs trajectories data.
         */
    getData(apiUrl: string, data: GetParameters): Observable<any> {
        let token = sessionStorage.getItem('token');
        let url = apiUrl + '/'+ data.SurveyHeaderId;
        return this.httpMethod.getMethod(this.endPoint, url);
    }

    /**
         *
         * This function will get the details of respective chart to download in excel
         */

    getExcelData(chartType: string, chartName: string, data: GetParameters): Observable<any> {
        let apiUrl = api.getExcelExportApi + '/'+ data.SurveyHeaderId + '?chartType=' + chartType + '&chartName=' + chartName
        let token = sessionStorage.getItem('token');
        let reqHeader = new HttpHeaders({ 'Authorization': `Bearer ${token}` })
        return this.httpMethod.getMethod(this.endPoint, apiUrl);
    }

}//end of class