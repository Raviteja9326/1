import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { StorageService } from './storage.service';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private store: StorageService, private router: Router, private toast: ToastrService) {}

  canActivate(): boolean {
    if (this.store.getToken()) {
      return true; // User is authenticated
    } else {
      // User is not authenticated, redirect to the login page or another route
      this.toast.error('Your Session was Expired, Please Login');
      this.router.navigate(['/login']);
      return false;
    }
  }
}
