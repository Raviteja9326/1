import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
@Injectable({
  providedIn: 'root'
})
export class EquipmentConfigurationService {

  endPoint: string;
  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends


  /* get getRigTypeList list */
  getRigTypeList() {

    return this.httpMethod.getMethod(this.endPoint, api.getRigTypeApi)
  }// end of function

  /* get getBlowOutPreventerList list */
  getBlowOutPreventerList() {

    return this.httpMethod.getMethod(this.endPoint, api.getBlowOutPreventerApi)
  }// end of function

  /* get getRCDTypeList list */
  getRCDTypeList(rigTypeId, blowOutPId) {
    let getRCDTypeListEndpoint = api.getRCDTypeApi;
    getRCDTypeListEndpoint = getRCDTypeListEndpoint.replace(":rigTypeId", rigTypeId);
    getRCDTypeListEndpoint = getRCDTypeListEndpoint.replace(":blowOutPId", blowOutPId);
    //console.log("getRCDTypeListEndpoint-----",getRCDTypeListEndpoint);
    return this.httpMethod.getMethod(this.endPoint, getRCDTypeListEndpoint)
  }// end of function

  // /* get getEquipmentConfigList list */
  // getEquipmentConfigList() {

  //   return this.httpMethod.getMethod(this.endPoint, api.getEquipmentConfigApi)

  // }// end of function

  /* get getEquipmentConfigList list */
  getEquipmentConfigList(WellId: any) {
    let getEquipmentConfigListEndpoint = api.getEquipmentConfigApi;
    getEquipmentConfigListEndpoint = getEquipmentConfigListEndpoint.replace(":wellId", WellId);
    return this.httpMethod.getMethod(this.endPoint, getEquipmentConfigListEndpoint)

  }// end of function

  getEquipmentConfigListByProjectId(ProjectId) {
    return this.httpMethod.getMethod(this.endPoint, api.getEquipmentConfigListByProjectId + ProjectId);

  }// end of function

  /* add addEquipmentConfigList */
  addEquipmentConfigList(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.addEquipmentConfigApi, payload)

  }// end of function

  /* add addEquipmentConfigList */
  editEquipmentConfigList(payload, ProjectId) {

    // return this.httpMethod.putMethod(this.endPoint, `${api.addEquipmentConfigApi}?ProjectId=${ProjectId}`, payload)
    return this.httpMethod.putMethod(this.endPoint, api.addEquipmentConfigApi + ProjectId, payload)

  }// end of function

}
