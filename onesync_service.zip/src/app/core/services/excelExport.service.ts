import { Injectable } from "@angular/core";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable({
    providedIn: 'root'
})

export class ExcelExportsService {

public exportAsExcelFile(data, excelFileName: string): void {

  console.log(data, excelFileName)

  //const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
  const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
  const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
  // var wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'binary' });
    
  //   var blob = new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' });
  //   //console.log("hi")
  //   FileSaver(blob, 'chart_data.xlsx');
  const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  this.saveAsExcelFile(excelBuffer, excelFileName);

}

s2ab(s: any) {
  //console.log("s---",s)
  var buf = new ArrayBuffer(s.length);
  var view = new Uint8Array(buf);
  for (var i = 0; i < s.length; i++) {
    view[i] = s.charCodeAt(i) & 0xff;
  }
  return buf;
}

private saveAsExcelFile(buffer: any, fileName: string): void {

  const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
  
  const now = new Date(); // Get the current date and time in UTC
  const estOffset = -5 * 60 * 60 * 1000; // Eastern Standard Time (EST) UTC offset in milliseconds (-5 hours)
  const estTime = new Date(now.getTime() + estOffset); // Add the offset to convert to EST

  FileSaver.saveAs(data, fileName + '_export_' + estTime.toISOString() + EXCEL_EXTENSION);

}
}