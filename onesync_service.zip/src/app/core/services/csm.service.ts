import { Injectable } from '@angular/core';
import {api} from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class CsmService {
  endPoint: string;

  constructor(private httpMethod:HttpMethodService) 
  {
    this.endPoint = `${api.serviceEndpoint}`;
  }

   getCSMData() {

    return this.httpMethod.getMethod(this.endPoint,api.getCSMListApi)
  }


  postCSMData(criticalSpeed){
    return this.httpMethod.putMethod(this.endPoint,api.postCSMDataApi,criticalSpeed)
  }
}
