import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { retry, timeout } from "rxjs/operators";
import { HttpMethodService } from "./httpMethod.service";

@Injectable({
    providedIn:'root'
})

export class ParametersService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){
        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     *
     * This function will get the list of getParametersList.
     */
    getParametersList(sourceType){

        let token = sessionStorage.getItem('token');
        let reqHeader =  new HttpHeaders({ 'Authorization': `Bearer ${token}`})
        return this.httpMethod.getMethod(this.endPoint,api.getParametersDetailsApi+"?AlertCategory="+sourceType);
    }//end of getParametersList

    
}//end of class