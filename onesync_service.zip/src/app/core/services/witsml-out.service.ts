import { Injectable } from '@angular/core';
import { api } from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class WitsmlOutService {
  endPoint: string;
  constructor(private httpMethod:HttpMethodService) {this.endPoint = `${api.serviceEndpoint}`; }

  getChannelList() {

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlOutChannelList)
  }

  getWitsmlOutList(){
    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlOutList)
  }


  addWitsmlOutData(payload){
    return this.httpMethod.postMethod(this.endPoint, api.postWitsmlOutData,payload);
  }//end of function

    
  updateWitsmlOutData(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.postWitsmlOutData, payload);
  }// end of function


  deleteWitsmlOutData(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteUnderbalancedFluidsApi,payload);
  }// end of function

  getParameterList(){

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlParameters)
  }


  getCategoryList(){

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlCategoryList)
  }

  getWitsmlOutLogs(channelId){

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlOutLogs+"?witsmlChannelId="+channelId)
  }


  getWitsmlLogcurveList(channelId,logUid){

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlOutCurveList+"?witsmlChannelId="+channelId+"&witsmlLogUid="+logUid)
  }



}
