import { Injectable } from "@angular/core";
import { api } from "../constants/api.constants";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError, retry, timeout } from "rxjs/operators";
import { HttpMethodService } from "./httpMethod.service";
import { throwError } from "rxjs";


@Injectable({
    providedIn:'root'
})

export class ReprtsService {

    endPoint: string;
    requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

    constructor(private httpService:HttpClient,private httpMethod:HttpMethodService){
    
        this.endPoint = `${api.serviceEndpoint}`;
    }//end of constructor

    /**
     * 
     * This function will get the list of Temperatures.
     */
    getTemperatureList(){

        return this.httpMethod.getMethod(this.endPoint,api.getTemperatureApi,this.requestHeader)
    }//end of getTemperatureApiList

     /**
     * 
     * This function will post the list of Temperatures.
     */
    postTemperatureList(data1:any){
        
        return this.httpMethod.postMethod( this.endPoint,api.postTemperatureApi,data1,this.requestHeader)
    }//end of postTemperatureApiList

    /**
     * Below function will delete record.
     */
    deleteTemperatureRecord (recordId) {

        let deleteEndpoint = api.deleteTemperatureApi;
        deleteEndpoint = deleteEndpoint.replace(":id", recordId);
        return this.httpMethod.deleteMethod(this.endPoint, deleteEndpoint);
    } //end of deleteTemperatureRecord function



    // getDashboardList() {
    //   return this.httpMethod.getMethod(this.endPoint,api.getReportList,this.requestHeader);
    // }
    // saveUserDashboard(data: any) {
    //   return this.httpMethod.postMethod(this.endPoint,api.postTemperatureApi,data,this.requestHeader);
    // }
    // getDashbaord() {
    //   return this.http.get(backendApi.getDashbaord);
    // }
  
    // addDashbaord(data: any) {
    //   return this.http.post(backendApi.addUpdateController, data);
    // }
    // updateDashboard(data: any) {
    //   return this.http.post(backendApi.updateDashboard, data);
    // }
}//end of class