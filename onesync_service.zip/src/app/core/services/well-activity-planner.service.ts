import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class WellActivityPlannerService {
  endPoint: string;
  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends

  /* add / update wellInterval Activity */
  saveWellActivity(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.saveWellActivity, payload)

  }// end of function

  /* get wellInterval Activity */
  getWellActivityList() {

    return this.httpMethod.getMethod(this.endPoint, api.getWellActivityList)

  }// end of function

  /* get wellInterval Activity */
  deleteWellActivityList(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.deleteWellActivity, payload)

  }// end of function

  /* get wellInterval Activity */
  getCasingFormDetails(id) {

    return this.httpMethod.getMethod(this.endPoint, api.getCasingFormDetails + '=' + `${id}`)

  }// end of function

  /* get wellInterval Activity */
  getWorkStringDetails() {

    return this.httpMethod.getMethod(this.endPoint, api.getWorkStringDetails)

  }// end of function

   /* get wellInterval Activity */
   getFluidsDetails() {

    return this.httpMethod.getMethod(this.endPoint, api.getFluidsDetails)

  }// end of function
}
