/*This is well paths service, to write functions for API call of materials catalog
*/
import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError } from 'rxjs';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
@Injectable({
  providedIn: 'root'
})
export class WellIntervalService {
  endPoint: string;
  public wellIntervalsData = new BehaviorSubject<any>('0');
  public wellIntervalset = new BehaviorSubject<any>('0');
  public wellintervalComp = new BehaviorSubject<any>('0');
  public intervalData: any;
  constructor( private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends

  setIntervals(value) {
    this.wellintervalComp.next(value)
  }

  getwellIntervalsdata(wellsData) {
    return this.wellIntervalsData.next(wellsData);
  }

  /* get wellpaths list */
  getWellintervalList() {

    return this.httpMethod.getMethod(this.endPoint, api.getWellIntervalApi)

  }// end of function

  /* get casing list */
  getCasingList(WellboreSectionId: number, type: string) {

    return this.httpMethod.getMethod(this.endPoint, api.addWellIntervalApi + `${WellboreSectionId}/list?type=${type}`)

  }// end of function

  /* add wellInterval */
  addCasingList(id: number, payload) {

    return this.httpMethod.postMethod(this.endPoint, api.addWellIntervalApi + `${id}/casing`, payload)

  }// end of function

  /* delete wellInterval */
  deleteCasingList(id, payload) {
    return this.httpMethod.postMethod(this.endPoint, api.addWellIntervalApi + `${id}/delete`, payload);
  }// end of function

  /* delete wellInterval */
  deleteOpenHolesList(id, payload) {
    return this.httpMethod.postMethod(this.endPoint, api.addWellIntervalApi + `${id}/delete`, payload);
  }// end of function

  getOpenHolesList(WellboreSectionId: number, type: string) {
    return this.httpMethod.getMethod(this.endPoint, api.addWellIntervalApi + `${WellboreSectionId}/list?type=${type}`)

  }
  //localhost:3000/api/v1/wellInterval/:WellboreSectionId/openHole

  /* add wellInterval */
  addOpenHolesList(id: number, payload) {

    return this.httpMethod.postMethod(this.endPoint, api.addWellIntervalApi + `${id}/openHole`, payload)

  }// end of function

  /* add wellInterval */
  addWellintervalList(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.addWellIntervalApi, payload)

  }// end of function

  /* activate wellInterval */
  activateWellInterval(Id: number, payload) {
    return this.httpMethod.putMethod(this.endPoint, api.addWellIntervalApi + `${Id}/status`, payload);
  }// end of function

  /* update wellInterval */
  updateWellpathsList(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.addWellIntervalApi, payload);
  }// end of function

  /* delete wellInterval */
  deleteWellIntervalList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.addWellIntervalApi + `delete`, payload);
  }// end of function

  getMaterialsList(){
    return this.httpMethod.getMethod(this.endPoint, api.getMaterialsApi)
  }
  getCasingTypeColumn(){
    return this.httpMethod.getMethod(this.endPoint, api.getCasingTypeColumn)
  }
}