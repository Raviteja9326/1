import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map, filter, concatMap, mergeMap } from 'rxjs/operators';
import { retry, catchError } from 'rxjs/operators';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
import { Acceleration } from 'src/app/core/enum/units/acceleration.enum';
import { Angle } from 'src/app/core/enum/units/angle.enum';
import { Area } from 'src/app/core/enum/units/area.enum';
import { Capacity } from 'src/app/core/enum/units/capacity.enum';
import { Concentration } from 'src/app/core/enum/units/concentration.enum';
import { Conductivity } from 'src/app/core/enum/units/conductivity.enum';
import { Curvature } from 'src/app/core/enum/units/curvature.enum';
import { Density } from 'src/app/core/enum/units/density.enum';
import { DLS } from 'src/app/core/enum/units/dLS.enum'
import { ElectricCurrent } from 'src/app/core/enum/units/electricCurrent.enum';
import { ElectricPotential } from 'src/app/core/enum/units/electricPotential.enum';
import { ElectricResistance } from 'src/app/core/enum/units/electricResistance.enum';
import { ElectricResistivity } from 'src/app/core/enum/units/electricResistivity.enum';
import { Energy } from 'src/app/core/enum/units/energy.enum';
import { Fann } from 'src/app/core/enum/units/fann.enum';
import { Flow } from 'src/app/core/enum/units/flow.enum';
import { FlowMeterKFactor } from 'src/app/core/enum/units/flowMeterKFactor.enum';
import { FluidLoss } from 'src/app/core/enum/units/fluidLoss.enum';
import { Force } from 'src/app/core/enum/units/force.enum';
import { Freight } from 'src/app/core/enum/units/freight.enum';
import { Frequency } from 'src/app/core/enum/units/frequency.enum';
import { GammaRay } from 'src/app/core/enum/units/gammaRay.enum';
import { GasUnit } from 'src/app/core/enum/units/gasUnit.enum';
import { GasVolume } from 'src/app/core/enum/units/gasVolume.enum';
import { HydrocarbonDensity } from 'src/app/core/enum/units/hydrocarbonDensity.enum';
import { Intensity } from 'src/app/core/enum/units/intensity.enum';
import { InverseCapacity } from 'src/app/core/enum/units/inverseCapacity.enum';
import { Length } from 'src/app/core/enum/units/length.enum';
import { LinearMassDensity } from 'src/app/core/enum/units/linearMassDensity.enum';
import { MagneticField } from 'src/app/core/enum/units/magneticField.enum';
import { MagneticFlux } from 'src/app/core/enum/units/magneticFlux.enum';
import { Mass } from 'src/app/core/enum/units/mass.enum';
import { MassFlow } from 'src/app/core/enum/units/massFlow.enum';
import { PenetrationRate } from 'src/app/core/enum/units/penetrationRate.enum';
import { Percentage } from 'src/app/core/enum/units/percentage.enum';
import { Permeability } from 'src/app/core/enum/units/permeability.enum';
import { Power } from 'src/app/core/enum/units/power.enum';
import { Pressure } from 'src/app/core/enum/units/pressure.enum';
import { PressureGradient } from 'src/app/core/enum/units/pressureGradient.enum';
import { PumpOutput } from 'src/app/core/enum/units/pumpOutput.enum';
import { PumpSpeed } from 'src/app/core/enum/units/pumpSpeed.enum';
import { Rate } from 'src/app/core/enum/units/rate.enum';
import { ResistivityPerLength } from 'src/app/core/enum/units/resistivityperlength.enum';
import { ShortLength } from 'src/app/core/enum/units/shortLength.enum';
import { Slowness } from 'src/app/core/enum/units/slowness.enum';
import { SpecificHeatCapacity } from 'src/app/core/enum/units/specificHeatCapacity.enum';
import { Stiffness } from 'src/app/core/enum/units/stiffness.enum';
import { Stress } from 'src/app/core/enum/units/stress.enum';
import { Temperature } from 'src/app/core/enum/units/temperature.enum';
import { ThermalCoefficient } from 'src/app/core/enum/units/thermalCoefficient.enum';
import { ThermalConductivity } from 'src/app/core/enum/units/thermalConductivity.enum';
import { ThermalGradient } from 'src/app/core/enum/units/thermalGradient.enum';
import { Time } from 'src/app/core/enum/units/time.enum';
import { Torque } from 'src/app/core/enum/units/torque.enum';
import { Viscosity } from 'src/app/core/enum/units/viscosity.enum';
import { Volume } from 'src/app/core/enum/units/volume.enum';
import { YieldPoint } from 'src/app/core/enum/units/yieldPoint.enum';
import { DifferentialPressure } from 'src/app/core/enum/units/differentialPressure.enum';
import { FlowConsistencyIndex } from 'src/app/core/enum/units/flowConsistencyIndex.enum';
import { GasFlow } from 'src/app/core/enum/units/gasFlow.enum';
import { GasOilRatio } from 'src/app/core/enum/units/gasOilRatio.enum';
import { NozzleSize } from 'src/app/core/enum/units/nozzleSize.enum';
import { RotationVelocity } from 'src/app/core/enum/units/rotationVelocity.enum';
import { StressCoeff } from 'src/app/core/enum/units/stressCoeff.enum';
import { VelocityFluid } from 'src/app/core/enum/units/velocityFluid.enum';
import { VelocityRunningSpeed } from 'src/app/core/enum/units/velocityRunningSpeed.enum';
import { UnitlessPrecision } from 'src/app/core/enum/units/unitlessPrecision.enum';
import { UnitSystem } from 'src/app/core/enum/units/unitSystem.enum';
import { type } from 'os';
@Injectable({
  providedIn: 'root'
})
export class UnitsService {

  unitlessPrecisionKeys: string[];
  unitlessPrecisionList: object = {};
  unitlessPrecision = UnitlessPrecision;

  unitSystemKeys: string[];
  unitSystemList: object = {};
  unitSystem = UnitSystem;

  accelerationKeys: string[];
  accelerationList: object = {};
  acceleration = Acceleration;

  angleKeys: string[];
  angleList: object = {};
  angle = Angle;

  areaKeys: string[];
  areaList: object = {};
  area = Area;

  capacityKeys: string[];
  capacityList: object = {};
  capacity = Capacity;

  concentrationKeys: string[];
  concentrationList: object = {};
  concentration = Concentration;

  conductivityKeys: string[];
  conductivityList: object = {};
  conductivity = Conductivity;

  curvatureKeys: string[];
  curvatureList: object = {};
  curvature = Curvature;

  densityKeys: string[];
  densityList: object = {};
  density = Density;

  differentialPressureKeys: string[];
  differentialPressureList: object = {};
  differentialPressure = DifferentialPressure;

  dLSKeys: string[];
  dLSList: object = {};
  dLS = DLS;

  electricCurrentKeys: string[];
  electricCurrentList: object = {};
  electricCurrent = ElectricCurrent;

  electricPotentialKeys: string[];
  electricPotentialList: object = {};
  electricPotential = ElectricPotential;

  electricResistanceKeys: string[];
  electricResistanceList: object = {};
  electricResistance = ElectricResistance;

  electricResistivityKeys: string[];
  electricResistivityList: object = {};
  electricResistivity = ElectricResistivity;

  energyKeys: string[];
  energyList: object = {};
  energy = Energy;

  fannKeys: string[];
  fannList: object = {};
  fann = Fann;

  flowKeys: string[];
  flowList: object = {};
  flow = Flow;

  flowConsistencyIndexKeys: string[];
  flowConsistencyIndexList: object = {};
  flowConsistencyIndex = FlowConsistencyIndex;

  flowMeterKFactorKeys: string[];
  flowMeterKFactorList: object = {};
  flowMeterKFactor = FlowMeterKFactor;

  fluidLossKeys: string[];
  fluidLossList: object = {};
  fluidLoss = FluidLoss;

  forceKeys: string[];
  forceList: object = {};
  force = Force;

  freightKeys: string[];
  freightList: object = {};
  freight = Freight;

  frequencyKeys: string[];
  frequencyList: object = {};
  frequency = Frequency;

  gammaRayKeys: string[];
  gammaRayList: object = {};
  gammaRay = GammaRay;

  gasFlowKeys: string[];
  gasFlowList: object = {};
  gasFlow = GasFlow;

  gasOilRatioKeys: string[];
  gasOilRatioList: object = {};
  gasOilRatio = GasOilRatio;

  gasUnitKeys: string[];
  gasUnitList: object = {};
  gasUnit = GasUnit;

  gasVolumeKeys: string[];
  gasVolumeList: object = {};
  gasVolume = GasVolume;

  hydrocarbonDensityKeys: string[];
  hydrocarbonDensityList: object = {};
  hydrocarbonDensity = HydrocarbonDensity;

  intensityKeys: string[];
  intensityList: object = {};
  intensity = Intensity;

  inverseCapacityKeys: string[];
  inverseCapacityList: object = {};
  inverseCapacity = InverseCapacity;

  lengthKeys: string[];
  lengthList: object = {};
  length = Length;

  linearMassDensityKeys: string[];
  linearMassDensityList: object = {};
  linearMassDensity = LinearMassDensity;

  magneticFieldKeys: string[];
  magneticFieldList: object = {};
  magneticField = MagneticField;

  magneticFluxKeys: string[];
  magneticFluxList: object = {};
  magneticFlux = MagneticFlux;

  massKeys: string[];
  massList: object = {};
  mass = Mass;

  massFlowKeys: string[];
  massFlowList: object = {};
  massFlow = MassFlow;

  nozzleSizeKeys: string[];
  nozzleSizeList: object = {};
  nozzleSize = NozzleSize;

  penetrationRateKeys: string[];
  penetrationRateList: object = {};
  penetrationRate = PenetrationRate;

  percentageKeys: string[];
  percentageList: object = {};
  percentage = Percentage;

  permeabilityKeys: string[];
  permeabilityList: object = {};
  permeability = Permeability;

  powerKeys: string[];
  powerList: object = {};
  power = Power;

  pressureKeys: string[];
  pressureList: object = {};
  pressure = Pressure;

  pressureGradientKeys: string[];
  pressureGradientList: object = {};
  pressureGradient = PressureGradient;

  pumpOutputKeys: string[];
  pumpOutputList: object = {};
  pumpOutput = PumpOutput;

  pumpSpeedKeys: string[];
  pumpSpeedList: object = {};
  pumpSpeed = PumpSpeed;

  rateKeys: string[];
  rateList: object = {};
  rate = Rate;

  resistivityPerLengthKeys: string[];
  resistivityPerLengthList: object = {};
  resistivityPerLength = ResistivityPerLength;

  rotationVelocityKeys: string[];
  rotationVelocityList: object = {};
  rotationVelocity = RotationVelocity;

  shortLengthKeys: string[];
  shortLengthList: object = {};
  shortLength = ShortLength;

  slownessKeys: string[];
  slownessList: object = {};
  slowness = Slowness;

  specificHeatCapacityKeys: string[];
  specificHeatCapacityList: object = {};
  specificHeatCapacity = SpecificHeatCapacity;

  stiffnessKeys: string[];
  stiffnessList: object = {};
  stiffness = Stiffness;

  stressKeys: string[];
  stressList: object = {};
  stress = Stress;

  stressCoeffKeys: string[];
  stressCoeffList: object = {};
  stressCoeff = StressCoeff;

  temperatureKeys: string[];
  temperatureList: object = {};
  temperature = Temperature;

  thermalCoefficientKeys: string[];
  thermalCoefficientList: object = {};
  thermalCoefficient = ThermalCoefficient;

  thermalConductivityKeys: string[];
  thermalConductivityList: object = {};
  thermalConductivity = ThermalConductivity;

  thermalGradientKeys: string[];
  thermalGradientList: object = {};
  thermalGradient = ThermalGradient;

  timeKeys: string[];
  timeList: object = {};
  time = Time;

  torqueKeys: string[];
  torqueList: object = {};
  torque = Torque;

  viscosityKeys: string[];
  viscosityList: object = {};
  viscosity = Viscosity;

  volumeKeys: string[];
  volumeList: object = {};
  volume = Volume;

  velocityFluidKeys: string[];
  velocityFluidList: object = {};
  velocityFluid = VelocityFluid;

  velocityRunningSpeedKeys: string[];
  velocityRunningSpeedList: object = {};
  velocityRunningSpeed = VelocityRunningSpeed;

  yieldPointKeys: string[];
  yieldPointList: object = {};
  yieldPoint = YieldPoint;

  endPoint: string;
  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
    this.unitSystemKeys = Object.keys(this.unitSystem)
      .filter((f) =>
        isNaN(Number(f)));
    this.accelerationKeys = Object.keys(this.acceleration).filter((f) => !isNaN(Number(f)));
    this.angleKeys = Object.keys(this.angle).filter((f) => !isNaN(Number(f)));
    this.areaKeys = Object.keys(this.area).filter((f) => !isNaN(Number(f)));
    this.capacityKeys = Object.keys(this.capacity).filter((f) => !isNaN(Number(f)));
    this.concentrationKeys = Object.keys(this.concentration).filter((f) => !isNaN(Number(f)));
    this.conductivityKeys = Object.keys(this.conductivity).filter((f) => !isNaN(Number(f)));
    this.curvatureKeys = Object.keys(this.curvature).filter((f) => !isNaN(Number(f)));
    this.densityKeys = Object.keys(this.density).filter((f) => !isNaN(Number(f)));
    this.differentialPressureKeys = Object.keys(this.differentialPressure).filter((f) => !isNaN(Number(f)));
    this.dLSKeys = Object.keys(this.dLS).filter((f) => !isNaN(Number(f)));
    this.electricCurrentKeys = Object.keys(this.electricCurrent).filter((f) => !isNaN(Number(f)));
    this.electricPotentialKeys = Object.keys(this.electricPotential).filter((f) => !isNaN(Number(f)));
    this.electricResistanceKeys = Object.keys(this.electricResistance).filter((f) => !isNaN(Number(f)));
    this.electricResistivityKeys = Object.keys(this.electricResistivity).filter((f) => !isNaN(Number(f)));
    this.energyKeys = Object.keys(this.energy).filter((f) => !isNaN(Number(f)));
    this.fannKeys = Object.keys(this.fann).filter((f) => !isNaN(Number(f)));
    this.flowKeys = Object.keys(this.flow).filter((f) => !isNaN(Number(f)));
    this.flowConsistencyIndexKeys = Object.keys(this.flowConsistencyIndex).filter((f) => !isNaN(Number(f)));
    this.flowMeterKFactorKeys = Object.keys(this.flowMeterKFactor).filter((f) => !isNaN(Number(f)));
    this.fluidLossKeys = Object.keys(this.fluidLoss).filter((f) => !isNaN(Number(f)));
    this.forceKeys = Object.keys(this.force).filter((f) => !isNaN(Number(f)));
    this.freightKeys = Object.keys(this.freight).filter((f) => !isNaN(Number(f)));
    this.frequencyKeys = Object.keys(this.frequency).filter((f) => !isNaN(Number(f)));
    this.gammaRayKeys = Object.keys(this.gammaRay).filter((f) => !isNaN(Number(f)));
    this.gasFlowKeys = Object.keys(this.gasFlow).filter((f) => !isNaN(Number(f)));
    this.gasOilRatioKeys = Object.keys(this.gasOilRatio).filter((f) => !isNaN(Number(f)));
    this.gasUnitKeys = Object.keys(this.gasUnit).filter((f) => !isNaN(Number(f)));
    this.gasVolumeKeys = Object.keys(this.gasVolume).filter((f) => !isNaN(Number(f)));
    this.hydrocarbonDensityKeys = Object.keys(this.hydrocarbonDensity).filter((f) => !isNaN(Number(f)));
    this.intensityKeys = Object.keys(this.intensity).filter((f) => !isNaN(Number(f)));
    this.inverseCapacityKeys = Object.keys(this.inverseCapacity).filter((f) => !isNaN(Number(f)));
    this.lengthKeys = Object.keys(this.length).filter((f) => !isNaN(Number(f)));
    this.linearMassDensityKeys = Object.keys(this.linearMassDensity).filter((f) => !isNaN(Number(f)));
    this.magneticFieldKeys = Object.keys(this.magneticField).filter((f) => !isNaN(Number(f)));
    this.magneticFluxKeys = Object.keys(this.magneticFlux).filter((f) => !isNaN(Number(f)));
    this.massKeys = Object.keys(this.mass).filter((f) => !isNaN(Number(f)));
    this.massFlowKeys = Object.keys(this.massFlow).filter((f) => !isNaN(Number(f)));
    this.nozzleSizeKeys = Object.keys(this.nozzleSize).filter((f) => !isNaN(Number(f)));
    this.penetrationRateKeys = Object.keys(this.penetrationRate).filter((f) => !isNaN(Number(f)));
    this.percentageKeys = Object.keys(this.percentage).filter((f) => !isNaN(Number(f)));
    this.permeabilityKeys = Object.keys(this.permeability).filter((f) => !isNaN(Number(f)));
    this.powerKeys = Object.keys(this.power).filter((f) => !isNaN(Number(f)));
    this.pressureKeys = Object.keys(this.pressure).filter((f) => !isNaN(Number(f)));
    this.pressureGradientKeys = Object.keys(this.pressureGradient).filter((f) => !isNaN(Number(f)));
    this.pumpOutputKeys = Object.keys(this.pumpOutput).filter((f) => !isNaN(Number(f)));
    this.pumpSpeedKeys = Object.keys(this.pumpSpeed).filter((f) => !isNaN(Number(f)));
    this.rateKeys = Object.keys(this.rate).filter((f) => !isNaN(Number(f)));
    this.resistivityPerLengthKeys = Object.keys(this.resistivityPerLength).filter((f) => !isNaN(Number(f)));
    this.rotationVelocityKeys = Object.keys(this.rotationVelocity).filter((f) => !isNaN(Number(f)));
    this.shortLengthKeys = Object.keys(this.shortLength).filter((f) => !isNaN(Number(f)));
    this.slownessKeys = Object.keys(this.slowness).filter((f) => !isNaN(Number(f)));
    this.specificHeatCapacityKeys = Object.keys(this.specificHeatCapacity).filter((f) => !isNaN(Number(f)));
    this.stiffnessKeys = Object.keys(this.stiffness).filter((f) => !isNaN(Number(f)));
    this.stressKeys = Object.keys(this.stress).filter((f) => !isNaN(Number(f)));
    this.stressCoeffKeys = Object.keys(this.stressCoeff).filter((f) => !isNaN(Number(f)));
    this.temperatureKeys = Object.keys(this.temperature).filter((f) => !isNaN(Number(f)));
    this.thermalCoefficientKeys = Object.keys(this.thermalCoefficient).filter((f) => !isNaN(Number(f)));
    this.thermalConductivityKeys = Object.keys(this.thermalConductivity).filter((f) => !isNaN(Number(f)));
    this.thermalGradientKeys = Object.keys(this.thermalGradient).filter((f) => !isNaN(Number(f)));
    this.timeKeys = Object.keys(this.time).filter((f) => !isNaN(Number(f)));
    this.torqueKeys = Object.keys(this.torque).filter((f) => !isNaN(Number(f)));
    this.viscosityKeys = Object.keys(this.viscosity).filter((f) => !isNaN(Number(f)));
    this.volumeKeys = Object.keys(this.volume).filter((f) => !isNaN(Number(f)));
    this.velocityFluidKeys = Object.keys(this.velocityFluid).filter((f) => !isNaN(Number(f)));
    this.velocityRunningSpeedKeys = Object.keys(this.velocityRunningSpeed).filter((f) => !isNaN(Number(f)));
    this.yieldPointKeys = Object.keys(this.yieldPoint).filter((f) => !isNaN(Number(f)));
    this.unitlessPrecisionKeys = Object.keys(this.unitlessPrecision).filter((f) => !isNaN(Number(f)));
  }// constructor ends



  /* get unitSystem list */
  getUnitSystemList() {

    return this.httpMethod.getMethod(this.endPoint, api.getUnitSystemApi)

  }// end of function

  /* add unitSystem */
  addUnitSystemList(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.saveUnitSystemApi, payload)

  }// end of function

  /* add unitSystem */
  cloneUnitSystemList(unitId, payload: any) {
    let cloneDetailsEndpoint = api.cloneUnitSystemApi;
    cloneDetailsEndpoint = cloneDetailsEndpoint.replace(":UnitSystemId", unitId);
    //console.log("cloneDetailsEndpoint-----", cloneDetailsEndpoint);

    return this.httpMethod.postMethod(this.endPoint, cloneDetailsEndpoint, payload)

  }// end of function

  /* activate unitSystem */
  activateUnitsSystem(statusHeaderId: number, payload) {
    // let activeEndpoint = api.activateUnitSystemApi;
    // activeEndpoint = activeEndpoint.replace(":UnitSystemId", id);
    return this.httpMethod.putMethod(this.endPoint, api.activateUnitSystemApi + `${statusHeaderId}/status`, payload);
  }// end of function

  /* update unitSystem */
  updateUnitsystemList(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateWellPathsApi, payload);
  }// end of function

  /* delete unitSystem */
  deleteUnitSystemList(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteUnitSystemApi, payload);
  }// end of function

  getUnitSystemDetails(unitId) {
    // let getDetailsEndpoint = api.activateUnitSystemApi;
    // getDetailsEndpoint = getDetailsEndpoint.replace(":UnitSystemId", unitId);
    // return this.httpMethod.getMethod(this.endPoint, api.getUnitSystemDataApi)
    return this.httpMethod.getMethod(this.endPoint, api.getUnitSystemDataApi + `${unitId}/details`);
  }

  getActiveUnitSystemDetails(): Observable<any> {
    return this.httpMethod.getMethod(this.endPoint, api.getActiveUnitSystemDataApi).pipe(
      // <-- go ahead only if `result` is defined
      map((res: any) => {
        //console.log("result-----", res);
        let resultData = res.result;
        let objectLength = Object.keys(resultData);
        // //console.log("response type", typeof resultData)
        for (let index = 0; index < (objectLength.length); index++) {

          let unitParameterVal = objectLength[index];
          let unitDropDownVal = resultData[unitParameterVal];
          let unitName = unitDropDownVal.unitName;
          let unitNameString = unitName.toString();
          //console.log("categoryNameVal-", this[unitParameterVal]);
          let categoryNameVal = this[unitParameterVal][unitNameString];
          resultData[unitParameterVal]["unitValue"] = categoryNameVal

        }
        //console.log("resultData---",resultData);
        return resultData;
      }
      ));
  }

  postUnitSystemDetails(unitId, payload) {
    let postDetailsEndpoint = api.postUnitSystemDataApi;
    postDetailsEndpoint = postDetailsEndpoint.replace(":UnitSystemId", unitId);
    //console.log("postDetailsEndpoint-----", postDetailsEndpoint);
    return this.httpMethod.postMethod(this.endPoint, postDetailsEndpoint, payload)
  }

  updateUnitSystemDetails(unitId, payload) {
    let putDetailsEndpoint = api.postUnitSystemDataApi;
    putDetailsEndpoint = putDetailsEndpoint.replace(":UnitSystemId", unitId);
    //console.log("putDetailsEndpoint-----", putDetailsEndpoint);
    return this.httpMethod.putMethod(this.endPoint, putDetailsEndpoint, payload)
  }

  converUnitsApi(payload): Observable<{ message: string, result: { unitName: string, value: number }[] }> {
    return this.httpMethod.postMethod(this.endPoint, api.convertUnitApi, payload)
  }
}
