import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { StorageService } from './storage.service';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class RealTimeDashboardService {

  public menuHeader = new BehaviorSubject<any>(null);
  public menuData = new BehaviorSubject<any>(null);
  public selectedDashboard = new BehaviorSubject<any>(null);
  constructor(private httpMethod:HttpMethodService) { }

  setMenuHeaderData(data) {
    return this.menuHeader.next(data);
   }

  setMenuData(data) {
    return this.menuData.next(data);
  }

  setSelectedDashboard(data) {
    return this.selectedDashboard.next(data);
  }

  getRTdashboard(getRTPayload){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getRTdashboard}?createdBy=${getRTPayload.createdBy}`);
  }

  createRTdashboard(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.createRTdashboard}`,data);
  }

  deleteRTdashboard(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.deleteRTdashboard}`, data);
  }
}
