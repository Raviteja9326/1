import { Injectable } from '@angular/core';
import {api} from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class FluidCementService {

  constructor(private httpMethod:HttpMethodService) {}

   GetFluidcement(projectId){

    if (projectId) {

      return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getfluidcementApi}` + `?ProjectId=${projectId}`)
    } else {

      return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getfluidcementApi}`)
    }
   }

   GetFluidcementbyid(data){
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getfluidcementidApi}${data}`)
   }

   deletefluidApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.deletefluidcementidApi}`,data)
   }

   clonefluidApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.clonefluidcementidApi}${data.FluidId}/clone`, data)
   }

   postfluidApi(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.getfluidcementidApi}`, data)
   }

   calculationsfluidApi(data, name){
    console.log(data, name)
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.calculationsWellPathApi}` + '?name=GetRheologyCurveFit&fluidType=' + `${name}`, data)
   }

   getRheologyModelsList() {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`,`${api.getRheologyModelsApi}`)
  }

  getUnitConverstionValues(data){
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`,`${api.postConversion}`, data)
  }

}
