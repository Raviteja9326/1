import { Injectable } from '@angular/core';
import { webSocket } from 'rxjs/webSocket';
import { WebSocketSubject } from 'rxjs/webSocket';
import { WebSocketInterface } from 'src/app/interfaces/webSocket';



@Injectable({
  providedIn: 'root'
})
export class WebsocketService {

  private socket$
  private wsUrl: string
  constructor() {

   }

  public init(url){
    this.wsUrl = url
    this.socket$ = webSocket(this.wsUrl)
    return this
  }


  streamData (host, url) {

    let ws = new WebSocketInterface(host, url);
    ws.init();
    return ws;
  }


  public sendMessage(message){
    this.socket$.next(message)
  }

  public getMessages(){
    return this.socket$.asObservable()
  }

  public close(){
    this.socket$.complete()
  }
}
