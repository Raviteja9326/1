/*This is well paths service, to write functions for API call of materials catalog
*/
import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { api } from "../constants/api.constants";
import { HttpMethodService } from './httpMethod.service';
@Injectable({
  providedIn: 'root'
})
export class CustomToolService {
  endPoint: string;
  constructor(private httpMethod: HttpMethodService) {
    this.endPoint = `${api.serviceEndpoint}`;
  }// constructor ends


 
  /* get tool workitem list */
  getToolWorkItemList() {

    return this.httpMethod.getMethod(this.endPoint, api.getCustomCatalogsApi)

  }// end of function

 /* get custom tools list */
 getCustomToolList(workitemID) {

  return this.httpMethod.getMethod(this.endPoint, api.getCustomToolsApi+workitemID)

  }// end of function

  /* add wellpaths */
  saveToolWorkItem(payload) {

    return this.httpMethod.postMethod(this.endPoint, api.saveCatalogWorkItem, payload)

  }// end of function

  /* activate wellpaths */
  activateWellpathsList(statusHeaderId: number, payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateWellPathsApi + `${statusHeaderId}/status`, payload);
  }// end of function

  /* update wellpaths */
  updateWellpathsList(payload) {
    return this.httpMethod.putMethod(this.endPoint, api.updateWellPathsApi, payload);
  }// end of function

  /* delete wellpaths */
  deleteCustomWorkItem(payload) {
    return this.httpMethod.postMethod(this.endPoint, api.deleteCustomCatalogApi,payload);
  }// end of function

  cloneCustomWorkItem(payload){
    return this.httpMethod.postMethod(this.endPoint, api.cloneWorkitemApi,payload);
  }

  addCustomTool(payload){
    return this.httpMethod.postMethod(this.endPoint, api.addCustomToolApi,payload);
  }

  updateCustomTool(templateId,payload){
    return this.httpMethod.putMethod(this.endPoint, api.updateCustomToolApi+templateId,payload);
  }

  deleteCustomTool(payload){
    return this.httpMethod.postMethod(this.endPoint, api.deleteCustomToolApi,payload);
  }

  getCustomToolDetails(templateId){
    return this.httpMethod.getMethod(this.endPoint,api.getCustomToolDetailsApi+templateId);
  }

   /* get tool sizes list */
   getToolSizesList() {

    return this.httpMethod.getMethod(this.endPoint, api.getToolSizes)

  }// end of function
}