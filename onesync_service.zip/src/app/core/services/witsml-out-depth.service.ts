import { Injectable } from '@angular/core';
import { api }from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class WitsmlOutDepthService {
  endPoint: string;
  constructor(private httpMethod:HttpMethodService) {this.endPoint = `${api.serviceEndpoint}`; }


  getParameterList(){

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlParameters)
  }


  getCategoryList(){

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlCategoryList)
  }


  getChannelList() {

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlOutChannelList)
  }


  getWitsmlOutDepthList() {

    return this.httpMethod.getMethod(this.endPoint,api.getWitsmlOutChannelList)
  }

}
