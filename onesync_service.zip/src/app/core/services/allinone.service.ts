import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root',
})
export class AllinoneService {

  public reportsData = new BehaviorSubject(undefined);

  public sendatatoexpand = new BehaviorSubject({});

  public sendaimagesdata = new BehaviorSubject(undefined);

  public sendaimagesdata2 = new BehaviorSubject(undefined);

  public savingcleardata = new BehaviorSubject(false);

  public savingsurfaceeqipmentdata = new BehaviorSubject(false);

  public DailreadingDatadata = new BehaviorSubject(false);

  public Excliptdata = new BehaviorSubject(false);

  public pvlpData = new BehaviorSubject<[]>(undefined);
  dataPvlp = this.pvlpData.asObservable();

  public hbdirectData = new BehaviorSubject<[]>(undefined);
  dataHbDirect = this.hbdirectData.asObservable();

  public readingData = new BehaviorSubject<[]>(undefined);
  dataReading = this.readingData.asObservable();

  public formData = new BehaviorSubject<[]>(undefined);
  dataForm = this.formData.asObservable();

  private tableDataSubject: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  tableData$: Observable<any> = this.tableDataSubject.asObservable();

  private tableDataSubject2: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  tableData2$: Observable<any> = this.tableDataSubject2.asObservable();

  private tableDataSubject3: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  tableData3$: Observable<any> = this.tableDataSubject3.asObservable();

  private defaultDetails: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  defaultData$: Observable<any> = this.defaultDetails.asObservable();

  defaultDetailsFormationskickloss: BehaviorSubject<any> = new BehaviorSubject<any>(undefined);

  errormessage: BehaviorSubject<any> = new BehaviorSubject<any>("");

  constructor(private store: StorageService) { }

  getWellData(list) {
    this.store.setWellName(list);
    return this.reportsData.next(list);
  }


  sendHbdirectData(data) {
    this.hbdirectData.next(data);
  }

  sendDataExpand(data) {
    this.sendatatoexpand.next(data);
  }

  sendDataImage(data) {
    this.sendaimagesdata.next(data);
  }

  sendDataImage2(data) {
    this.sendaimagesdata2.next(data);
  }

  sendPvlpData(data) {
    this.pvlpData.next(data);
  }

  sendReadingData(data) {
    this.readingData.next(data);
  }

  sendFormData(data) {
    this.formData.next(data);
  }

  savingMethod(data) {
    this.savingcleardata.next(data);
  }

  savingMethod2(data) {
    console.log(data)
    this.savingsurfaceeqipmentdata.next(data);
  }

  savingMethod3(data) {
    this.DailreadingDatadata.next(data);
  }

  updateTableData(tableData: any): void {
    this.tableDataSubject.next(tableData);
  }

  updateTableData2(tableData: any): void {
    this.tableDataSubject2.next(tableData);
  }

  updateTableData3(tableData: any): void {
    this.tableDataSubject3.next(tableData);
  }

  updateDefaultDetails(tableData: any): void {
    this.defaultDetails.next(tableData);
  }

  kicklossformations(list: any, list2:any): void {
    this.defaultDetailsFormationskickloss.next({ dynaiclist: list, formvalidationlist: list2 });
  }

  errormsg(msg: any): void {
    this.errormessage.next(msg);
  }
}
