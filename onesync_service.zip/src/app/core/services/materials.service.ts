/*This is materials service, to write functions for API call of materials catalog
*/
import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { HttpMethodService } from './httpMethod.service';
import { api } from "../constants/api.constants";
@Injectable({
  providedIn: 'root'
})
export class MaterialsService {
  materialStatus: boolean;
  endPoint: string;
  public reportsData = new BehaviorSubject<any>('0'); // materialsData as observable
  public reportsColumn = new BehaviorSubject<any>('0'); // materialsColumn as observable
  constructor( private httpMethod:HttpMethodService) {

    this.endPoint = `${api.serviceEndpoint}`;
  }

  /*Returns materials Data */
  getMaterialsData(list) {

    return this.reportsData.next(list);

  }
  /*Returns materials Columns */
  getMaterialsColumn(ColumnInfo) {

    return this.reportsColumn.next(ColumnInfo);

  }
  /* get materials list */
  getMaterialsList(precision?) {
      if(precision==false){
        return this.httpMethod.getMethod(this.endPoint,`${api.getMaterialsApi}&precision=0`);
      }
      return this.httpMethod.getMethod(this.endPoint,api.getMaterialsApi)
  }

  /* get materials list for WS Drill pipe where using grade and upset type value */
  getMaterialsListDP(gradeUpsetValue) {
    return this.httpMethod.getMethod(this.endPoint,api.getWSDPMaterialListApi+'/'+gradeUpsetValue);
}

  getToolSizeList(){
      return this.httpMethod.getMethod(this.endPoint,api.getToolSizeApi)

  }

  getToolSizeListForCustomConnection() {

    return this.httpMethod.getMethod(this.endPoint,api.getToolSizeApi + "?pageName=CUSTOM_CONNECTION")
  }

  // loginApiCall() {

  //   return this.http
  //     .get(`/api/v1/login/verifyUser?email=admin@birlasoft.com&password=Admin123@123`)
  //     .pipe(
  //       retry(1),
  //       catchError((err) => {
  //         // this.ngxLoader.stop();
  //         // this.router.navigate(['/dashboard/errors']);
  //         // console.error(err);
  //         return throwError(() => err);
  //       })
  //     );

  // }


}
