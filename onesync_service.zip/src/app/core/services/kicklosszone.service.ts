import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { KickLossZone } from '../interfaces/kicklosszone.interface';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KickLossZoneService {
  constructor(private httpMethod: HttpMethodService) { }

  GetzoneApi(projectId) {

    if (projectId) {

      return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getZoneApi}` + `?ProjectId=${projectId}`)
    } else {

      return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getZoneApi}`)
    }
  }

  GetzonetypesApi() {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getZonetypelistApi}`)
  }

  GetzonefluidtypesApi() {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getZonefluidlistApi}`)
  }

  PostupdatezoneApi(data) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postupdateZoneApi}`, data)
  }

  deltezoneapi(data) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.deletezoneApi}`, data)
  }

  getMinFormation(projectId) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.zoneFormationValidationDetail}?ProjectID=${projectId}`)
  }

  validateData(data: KickLossZone[]) {
    const _item = data.find(obj => (obj.ReservoirZoneName.trim() == "" || obj.ReservoirZoneName.trim().length > 50
      || obj.MeasuredDepth === "" || obj.MeasuredDepth > 50000
      || obj.Length === "" || obj.Length > 50
      || obj.DrainOffRadius === "" || obj.DrainOffRadius > 10000
      || obj.ReservoirFluidDensity === "" || this.validateReservoirFluidDensity(obj)));
    if (_item)
      return false;
    return true;
  }

  validateReservoirFluidDensity(kickLossitem: KickLossZone) {
    if (kickLossitem.ReservoirFluidType == 1 && (kickLossitem.ReservoirFluidDensity < 0.6 || kickLossitem.ReservoirFluidDensity > 2)) {
      return true;
    } else if (kickLossitem.ReservoirFluidType == 2 && (kickLossitem.ReservoirFluidDensity < 0.4 || kickLossitem.ReservoirFluidDensity > 2)) {
      return true;
    } else if (kickLossitem.ReservoirFluidType == 3 && (kickLossitem.ReservoirFluidDensity < 0.6 || kickLossitem.ReservoirFluidDensity > 3)) {
      return true;
    }
  }
}
