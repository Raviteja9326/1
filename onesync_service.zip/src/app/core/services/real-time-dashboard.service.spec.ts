import { TestBed } from '@angular/core/testing';

import { RealTimeDashboardService } from './real-time-dashboard.service';

describe('RealTimeDashboardService', () => {
  let service: RealTimeDashboardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RealTimeDashboardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
