import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { HttpMethodService } from './httpMethod.service';
import { api } from '../constants/api.constants';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class SurgeSwabService {
  tableDataSurge: any;
  expDataSurge: any;
  TripingConfigId: any;
  activeUnitSystem: any;
  constructor(private httpMethod: HttpMethodService) { }

  GetSurgeSwablistApi(ProjectId): Observable<{ message: string, result: { Name: string, isAdded: boolean, WellId: number, TrippingConfigurationId?: number }[] }> {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getSurgeSwabExpList}?ProjectId=${ProjectId}`)
  }

  postSurgeSwabECDValues(payload: { TripType: number, Tolerance: number, FluidIndex: number }): Observable<{ message: string, result: { ReferenceECDForSurge: number, ReferenceECDForSwab: number } }> {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.postSurgeSwabECDValues}`, payload);
  }

  SaveSurgeSwabExpApi(data) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}`, data)
  }

  GetSurgeFormDetailsApi(id) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}` + `${id}/details`)
  }

  deleteSurgeSwabExpApi(payload): Observable<{ message: string, result: any }> {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}/delete`, payload);
  }

  public cloneSurgeSwab(TrippingConfigurationId: number): Observable<{ message: string, result: any }> {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}/${TrippingConfigurationId}/clone`, {});
}

  GetwellPathdropdown(id) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWellPathsApi}` + `?ProjectId=${id}`)
  }

  GetwellIntervaldropdown(projectId) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getWellIntervalApi}` + `?ProjectId=${projectId}`)
  }

  Getworkstringdropdown(projectId) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getworkstringApi}/${projectId}`)
  }

  GetFluidsdropdown(id) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.getFluidsDetails}` + `?ProjectId=${id}`)
  }

  GetGraphSurgeApi(id) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}${id}/graph`)

  }

  calculateSurgeTableData(data) {
    return this.httpMethod.postMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}`, data)
  }

  GetGraphTableApi(id): Observable<{ message: string, result: { tableData: any[] } }> {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}${id}/graphTableView`)
  }

  GetSurgeSwabTableApi(ConfigId, TripId) {

    TripId = TripId ? TripId : 0;
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}${ConfigId}/details` + `?TripType=${TripId}`)
  }

  getMshearData(id) {
    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}${id}/MShearData`)
  }

  getMshearDataWithWell(params) {

    let projectId = params.projectId;
    let wellId = params.wellId;
    let configId = params.configid;

    return this.httpMethod.getMethod(`${api.serviceEndpoint}`, `${api.SaveSurgeSwabExp}${configId}/MShearData` + '?projectId=' + projectId + "&wellId=" + wellId)
  }

  public mapFormValuesToPostPayload(surgeSwabForm: FormGroup, isShowCustomAcceleration: boolean, isMaxSpeedBol: boolean) {
    const Acceleration = isShowCustomAcceleration ? surgeSwabForm.value['CustomAccelerationTime'] : surgeSwabForm.value['AccelerationTimeOptions'];
    const AllowableSpeed = isMaxSpeedBol ? surgeSwabForm.value['MaxAllowableSpeed'] : surgeSwabForm.value['RunningSpeed'];
    return {
      "SurveyIndex": surgeSwabForm.value['WellPath'],
      "WellboreIndex": surgeSwabForm.value['WellInterval'],
      "DrillstringIndex": surgeSwabForm.value['WorkString'],
      "FluidIndex": surgeSwabForm.value['Fluid'],
      "TripType": surgeSwabForm.value['RunDirection'],
      "TrippingOption": surgeSwabForm.value['PipeEnd'],
      "OptimizationOption": surgeSwabForm.value['AnalysisType'],
      "PumpFlowRate": surgeSwabForm.value['PumpFlowRate'] || "",
      "Tolerance": surgeSwabForm.value['ToleranceMethod'],
      "ReferenceDepth": surgeSwabForm.value['ReferenceDepth'] || "",
      "ReferenceECDForSurge": surgeSwabForm.value['ECDReferenceDepth'] || "",
      "ReferenceECDForSwab": surgeSwabForm.value['ReferenceECDForSwab'] || "",
      "MaxPipeVelocity": AllowableSpeed,
      "MinPipevelocity": AllowableSpeed,
      "AccelerationTime": Acceleration,
      "StandLength": surgeSwabForm.value['StandLength'],
      "ConnectionTime": surgeSwabForm.value['ConnectionTime'],
      "SurfaceBackPressure": surgeSwabForm.value['SurfaceBackPressure'],
    }
  }
}
