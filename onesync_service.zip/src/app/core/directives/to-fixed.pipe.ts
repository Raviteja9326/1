import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'toFixed'
})

export class ToFixedPipe implements PipeTransform {
  transform(value: number | string, precision: number = 2): string {
    // Convert value to a number if it's a string
    const numValue: number = typeof value === 'string' ? parseFloat(value) : value;
    
    // Check if the conversion is successful
    if (!isNaN(numValue)) {
      return numValue.toFixed(precision);
    } else {
      // If value is not a valid number, return 0 or an empty string
      return precision === 0 ? '0' : '';
    }
  }
}