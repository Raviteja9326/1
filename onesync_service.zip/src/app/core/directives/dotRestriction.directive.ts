import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appDotRestriction]'
})
export class DotRestrictionDirective {

  constructor() { }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (event.key === '.') {
      event.preventDefault();
    }
  }
}
