import { Directive, ElementRef, HostListener, Input, OnChanges, OnInit } from '@angular/core';
import { FormControlName, NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[appDecimalFormatter]'
})
export class DecimalFormatterDirective implements OnInit,OnChanges {

  @Input() decimalPlaces: number = 2;
  private valueChangesSubscription: Subscription;
  isRecalculating: boolean;
  constructor(private el: ElementRef, private controlName: NgControl) { }

  ngOnChanges() {
        if (this.controlName.value !== null) {
          const originalValue = this.controlName.value;
          const formattedValue = parseFloat(originalValue).toFixed(this.decimalPlaces+1);
          setTimeout(()=>{this.el.nativeElement.value = Number(formattedValue).toFixed(this.decimalPlaces);})
          //this.controlName.control.setValue(originalValue, { emitEvent: false });
        }
        if (this.controlName['model'] !== null) {
            setTimeout(()=>{this.formatValue()});
            //this.controlName.control.setValue(originalValue, { emitEvent: false });
          }
      
    // Register the control with the directive
   // this.registerControl();
  }

  ngOnInit() {
    this.subscribeToValueChanges();
  }

  ngOnDestroy() {
    this.unsubscribeFromValueChanges();
  }

  private subscribeToValueChanges() {
    this.valueChangesSubscription = this.controlName.valueChanges.subscribe(() => {
      if (!this.isRecalculating) {
        this.formatValue();
      }
    });
  }

  private unsubscribeFromValueChanges() {
    if (this.valueChangesSubscription) {
      this.valueChangesSubscription.unsubscribe();
    }
  }
  @HostListener('focus')
  onFocus() {
    // Set flag to indicate recalculation is in progress
    this.isRecalculating = true;
  }
  @HostListener('input')
  onInput() {
    // Set flag to indicate user interaction
   
  }
  @HostListener("keydown")
  onKeyDown() {
   // Set flag to indicate user interaction
   this.isRecalculating = true;
  }
  @HostListener('change')
  onChange() {
    // Set flag to indicate user interaction
    this.isRecalculating = true;
  }
  @HostListener('blur')
  onBlur() {
    // Set flag to indicate recalculation is complete
    this.isRecalculating = false;
    // Format the value when the input loses focus
    this.formatValue();
  }

  private registerControl() {
    if (this.controlName) {
      // Get the form control associated with the control name
      const control = this.controlName.control;

      // Subscribe to value changes of the control
      control.valueChanges.subscribe(() => {
        this.formatValue();
      });
    }
  }

  private formatValue() {
    const value = this.el.nativeElement.value;

    // Parse the input value as a floating point number
    const parsedValue = parseFloat(value);

    // Check if the parsed value is a valid number
    if (!isNaN(parsedValue)) {
      // Round the number to the specified decimal places
      const roundedValue = parsedValue.toFixed(this.decimalPlaces+1);

      // Update the input element's value with the formatted value
      this.el.nativeElement.value = Number(roundedValue).toFixed(this.decimalPlaces);
    }
  }

}
