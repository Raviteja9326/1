import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CalculatorsComponent } from './calculators.component'


const routes: Routes = [{
  path: '', component: CalculatorsComponent,
  children: [
    { path: "calculators", data: { preload: false }, loadChildren: () => import("./calculators/calculators.module").then(m => m.CalculatorsModule) },
    { path: 'bit', data: { preload: false }, loadChildren: () => import('./bit/bit.module').then(m => m.BitModule) },
    { path: "unit-converter", data: { preload: false }, loadChildren: () => import("./unit-converter/unit-converter.module").then(m => m.UnitConverterModule) },


  ]
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CalculatorsRoutingModule { }
