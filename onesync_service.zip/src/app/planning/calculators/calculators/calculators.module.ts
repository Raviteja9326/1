import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CalculatorsRoutingModule } from './calculators-routing.module';
import { CalculatorsComponent } from './calculators.component';
import { AllModule } from 'src/app/shared/all_modules';

@NgModule({
  declarations: [
    CalculatorsComponent,
  ],
  imports: [
    CommonModule,
    CalculatorsRoutingModule,
    AllModule
  ]
})
export class CalculatorsModule { }
