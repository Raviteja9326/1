import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UnitsService } from 'src/app/core/services/units.service';

interface calculatorVal {
  value: string;
  viewValue: string;
}

interface CalculatorGroup {
  fieldName: string;
  calculatorName: calculatorVal[];
}

@Component({
  selector: 'app-calculators',
  templateUrl: './calculators.component.html',
  styleUrls: ['./calculators.component.scss']
})



export class CalculatorsComponent implements OnInit {
  
  calculatorForm: FormGroup;
  shortLengthUnit: string = "";//mm
  capacityUnit: string = "";//bbl/ft
  inverseCapacityUnit:string="";//ft/bbl
  activeUnitSystemData;
  calculatorGroupVal: CalculatorGroup[]
  constructor(private _fb: FormBuilder,private unitsService: UnitsService,) { }

  ngOnInit(): void {
    this.calculatorForm = this._fb.group({
      calculator: ["", [Validators.required]],
      casingID: ["", [Validators.required]],
      pipeOD: ["", [Validators.required]],
      annularCapacity: ["", [Validators.required]],
      inverseAnnularCapacity: ["", [Validators.required]],
    });
    this.getActiveUnitSystemData();
    this.calculatorGroupVal= [
      {
        fieldName: 'Drilling',
        calculatorName: [
          {value: 'annularCapacity', viewValue: 'Annular Capacity'},
          {value: 'annularVelocity', viewValue: 'Annular Velocity'},
          {value: 'buoyancyFactor', viewValue: 'Buoyancy Factor'},
        ],
      },
      {
        fieldName: 'Ton-Miles',
        calculatorName: [
          {value: 'roundTrip', viewValue: 'Round Trip'},
          {value: 'drillingOrConnection', viewValue: 'Drilling or Connection'},
          {value: 'coring', viewValue: 'Coring'},
        ],
      },
      {
        fieldName: 'Pump',
        calculatorName: [
          {value: 'pumpOutput', viewValue: 'Pump Output'},
          {value: 'pumpRelation', viewValue: 'Pump Relation'},
         
        ],
      },
      {
        fieldName: 'Miscellaneous',
        calculatorName: [
          {value: 'volumeDistribution', viewValue: 'volumeDistribution'},
        ],
      },
    ];
  }

   /**
         * call OnsectionChange function changing the calculator Value
         */
   onSelectionChange(event) {

   }

  /**
       * call omit_number function allowed only numbers in pricison and not allowed special character Value
       */
  omit_number(event) {

    var key;
    key = event.charCode;  //         key = event.keyCode;  (Both can be used)
    //console.log("key code---", key)
    return ((key > 47 && key < 58) || key == 46);
  }

   /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          //console.log("res in equipment configration---", res);
          this.activeUnitSystemData = res;
          this.shortLengthUnit = this.activeUnitSystemData.shortLength.unitValue;
          this.capacityUnit = this.activeUnitSystemData.capacity.unitValue;
          this.inverseCapacityUnit = this.activeUnitSystemData.inverseCapacity.unitValue;
        } else {

          // if()
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);



        // this.toastr.error("Something Went Wrong");
      }
    })
  }

    /**
      * API call getCalcultorsDetails function for get details.
      */
  getCalcultorsDetails(){

  }


}
