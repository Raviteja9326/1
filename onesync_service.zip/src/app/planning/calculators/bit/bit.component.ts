import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CalculatorBit } from 'src/app/core/interfaces/calculatorBit.interface';
import { Column } from 'src/app/core/interfaces/column.interface';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-bit',
  templateUrl: './bit.component.html',
  styleUrls: ['./bit.component.scss']
})
export class BitComponent implements OnInit {

  bitForm: FormGroup;
  flowLabel: string = "";//l/min
  densityLabel: string = "";//ppg
  pressureLabel:string="";//kPa
  powerLabel:string="";//kW
  nozzleSizeLabel:string="";//x 1/32"
  velocityFluidLabel:string="";//ft/min
  activeUnitSystemData;
  flowRateError:string="";
  mudWeightError:string="";
  tableData: CalculatorBit[] = [];
  deleteList: any = [];
  currentData: any = [];
  isChanged: boolean;
  originalData: any;
  deletedIds : any = [];

  tableColumns: Column[] = [
    { columnDef: "Nozzle", header: "Nozzle", sticky: true, cell: (element: Record<number, any>) => `${element['Nozzle']}`, editable: true, inputType: 'number' },
    { columnDef: "Size", header: "Size", sticky: true, cell: (element: Record<string, any>) => `${element['Size']}`, editable: true, inputType: 'dropdown' },
    { columnDef: "FlowArea", header: "Flow Area", sticky: true, cell: (element: Record<string, any>) => `${element['FlowArea']}`, editable: true, inputType: 'number' },
    { columnDef: "FlowRate", header: "Flow Rate", sticky: true, cell: (element: Record<string, any>) => `${element['FlowRate']}`, editable: true, inputType: 'number' },
    { columnDef: "JetVelocity", header: "Jet Velocity", sticky: true, cell: (element: Record<string, any>) => `${element['JetVelocity']}`, editable: true, inputType: 'number' },
  ]

  constructor(private _fb: FormBuilder,private unitsService: UnitsService,) { }

  ngOnInit(): void {
    this.bitForm = this._fb.group({
      flowRate: ["", [Validators.required,Validators.min(0), Validators.max(100)]],
      mudWeight: ["", [Validators.required,Validators.min(0), Validators.max(100)]],
      tFA: ["", [Validators.required]],
      bitPressureDrop: ["", [Validators.required]],
      power: ["", [Validators.required]],
    });

    this.tableData=[{
      Nozzle: 1,
      Size: "1",
      FlowArea: 1,
      FlowRate: 1,
      JetVelocity: 1,
    },
    {
      Nozzle: 2,
      Size: "1",
      FlowArea: 1.87,
      FlowRate: 1,
      JetVelocity: 1.12,
    },
    {
      Nozzle: 3,
      Size: "1",
      FlowArea: 126.68,
      FlowRate: -14.29,
      JetVelocity: -112.77,
    },
    {
      Nozzle: 4,
      Size: "1",
      FlowArea: 10,
      FlowRate: 41,
      JetVelocity: 91,
    }


    ]
    this.getActiveUnitSystemData();
    this.bitForm.get('flowRate').valueChanges
    .subscribe(value => {
      
      if (this.flowLabel == 'l/min') {
        this.bitForm.get('flowRate').setValidators([Validators.required, Validators.min(94.64), Validators.max(5678.12)])
        this.flowRateError = "Value for Flow Rate must be between 94.64 and 5678.12 (l/min)";
      }
      else if (this.flowLabel == 'gal/min') {
        this.bitForm.get('flowRate').setValidators([Validators.required, Validators.min(25.00), Validators.max(1500.00)])
        this.flowRateError = "Value for Flow Rate must be between 25.00 and 1500.00 (gal/min)";
      }
      
      //  },1000); 
    });

    this.bitForm.get('mudWeight').valueChanges
    .subscribe(value => {
      console.log("value of mudweight-",value)
      if (this.densityLabel == 'kg/m³') {
        this.bitForm.get('mudWeight').setValidators([Validators.required, Validators.min(718.96), Validators.max(2995.66)])
        this.mudWeightError = "Value for Mud Weight must be between 718.96 and 2995.66 (kg/m³)";
      }
      else if (this.densityLabel == 'ppg') {
        this.bitForm.get('mudWeight').setValidators([Validators.required, Validators.min(6.00), Validators.max(25.00)])
        this.mudWeightError = "Value for Mud Weight must be between 6.00 and 25.00 (ppg)";
      }
      
      //  },1000); 
    });
  }

  getTableData(event) {

    /**
     * emitter event call to check updated data in table
     */
    //console.log(event)
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function

  checkChanges(data) {

    /**
     * this function compares original data and changes made in
     * table
     */
    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    //console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });

    return isDataChanged;
  }//end of function

    /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          //console.log("res in equipment configration---", res);
          this.activeUnitSystemData = res;
          this.flowLabel = this.activeUnitSystemData.flow.unitValue;
          this.densityLabel = this.activeUnitSystemData.density.unitValue;
          this.pressureLabel = this.activeUnitSystemData.pressure.unitValue;
          this.powerLabel = this.activeUnitSystemData.power.unitValue;
          this.nozzleSizeLabel=this.activeUnitSystemData.nozzleSize.unitValue;
          this.velocityFluidLabel=this.activeUnitSystemData.velocityFluid.unitValue;
          this.tableColumns[1].header = "Size, " + this.nozzleSizeLabel + "";
          // this.tableColumns[2].header = "Flow Area, " + this.shortLength + "";
          this.tableColumns[3].header = "Flow Rate, " + this.flowLabel + "";
          this.tableColumns[4].header = "Jet Velocity, " + this.velocityFluidLabel + "";
        } else {

          // if()
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);



        // this.toastr.error("Something Went Wrong");
      }
    })
  }

}
