import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BitRoutingModule } from './bit-routing.module';
import { BitComponent } from './bit.component';
import { AllModule } from 'src/app/shared/all_modules';

@NgModule({
  declarations: [
    BitComponent,
    
  ],
  imports: [
    CommonModule,
    BitRoutingModule,
    AllModule
  ]
})
export class BitModule { }
