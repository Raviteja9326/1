import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BitComponent } from './bit.component';

const routes: Routes = [{ path: '', component: BitComponent },
// { path: 'bit', component: BitDetailsComponent },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BitRoutingModule { }
