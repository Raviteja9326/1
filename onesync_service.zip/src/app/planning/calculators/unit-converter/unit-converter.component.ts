import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-unit-converter',
  templateUrl: './unit-converter.component.html',
  styleUrls: ['./unit-converter.component.scss']
})
export class UnitConverterComponent implements OnInit {
  unitConverterForm: FormGroup;
  shortLengthUnit: string = "";//mm
  capacityUnit: string = "";//bbl/ft
  inverseCapacityUnit:string="";//ft/bbl
  activeUnitSystemData;
  unitConverterVal: Array<any>=[];
  constructor(private _fb: FormBuilder,private unitsService: UnitsService,) { }

  ngOnInit(): void {
    this.unitConverterForm = this._fb.group({
      unitType: ["", [Validators.required]],
      unitFrom: ["", [Validators.required]],
      unitTo: ["", [Validators.required]],
      unitFromValue: ["", [Validators.required]],
      unitToValue: ["", [Validators.required]],
    });
    this.unitConverterVal= [
      {
        unitName:"Acceleration",
        unitId:1
      }
    ];
  }

  onUnitTypeChange(event){
    
  }

  onUnitChange(event){

  }

   /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          //console.log("res in equipment configration---", res);
          this.activeUnitSystemData = res;
          this.shortLengthUnit = this.activeUnitSystemData.shortLength.unitValue;
          this.capacityUnit = this.activeUnitSystemData.capacity.unitValue;
          this.inverseCapacityUnit = this.activeUnitSystemData.inverseCapacity.unitValue;
        } else {

          // if()
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);



        // this.toastr.error("Something Went Wrong");
      }
    })
  }
}
