import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UnitConverterRoutingModule } from './unit-converter-routing.module';
import { UnitConverterComponent } from './unit-converter.component';
import { AllModule } from 'src/app/shared/all_modules';

@NgModule({
  declarations: [
    UnitConverterComponent,
    
  ],
  imports: [
    CommonModule,
    UnitConverterRoutingModule,
    AllModule
  ]
})
export class UnitConverterModule { }
