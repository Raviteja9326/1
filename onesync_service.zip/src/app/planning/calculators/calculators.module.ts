import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllModule } from '../../shared/all_modules';
import { CalculatorsRoutingModule } from './calculators-routing.module';
import { CalculatorsComponent } from './calculators.component';

@NgModule({
  declarations: [
    CalculatorsComponent,
   
    
  ],
  imports: [
    CommonModule,
    AllModule,
    CalculatorsRoutingModule
  ]
})
export class CalculatorsModule { }
