import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-calculators',
  templateUrl: './calculators.component.html',
  styleUrls: ['./calculators.component.scss']
})
export class CalculatorsComponent implements OnInit {
  isLinear: boolean = false;
  constructor(private route :Router, ) { }

  ngOnInit(): void {
   
    const url = this.route.url;
    this.route.navigate([url])
    this.onStepClick({ selectedIndex: 0 })
  }
   


  onStepClick(event) {
    if (event.selectedIndex == 0) {
      this.route.navigate(['/dashboard/calculators/calculators']);
    }
    else if (event.selectedIndex == 1) {
     this.route.navigate(['/dashboard/calculators/bit']);
    }
    else if (event.selectedIndex == 2) {
     this.route.navigate(['/dashboard/calculators/unit-converter']);
    } 
  }

  
}
