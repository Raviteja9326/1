import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CatalogsRoutingModule } from './catalogs-routing.module';
import { CatalogsComponent } from './catalogs.component';
import { MaterialsComponent } from './materials/materials.component';
// import { CustomConnectionsComponent } from './custom-connections/custom-connections.component';
// import { CentralizersComponent } from './centralizers/centralizers.component';
import { CustomConnectionsComponent } from './custom-connections/custom-connections.component';
import { CustomToolsComponent } from './custom-tools/custom-tools.component';
import { AllModule } from 'src/app/shared/all_modules';
import { ConnectionsComponent } from './connections/connections.component';
import { CustomConnectionsDetailsComponent } from './custom-connections/custom-connections-details/custom-connections-details.component';
import { CustomConnectionsDeleteComponent } from './custom-connections/custom-connections-delete/custom-connections-delete.component';
import { CustomComponentComponent } from './custom-tools/custom-component/custom-component.component';
import { CustomToolAddComponent } from './custom-tools/custom-tool-add/custom-tool-add.component';
import { BitFormComponent } from './custom-tools/custom-tool-add/bit-form/bit-form.component';
import { CasingPipeFormComponent } from './custom-tools/custom-tool-add/casing-pipe-form/casing-pipe-form.component';
import { CustomToolWarningDialogComponent } from './custom-tools/custom-tools-warning/custom-tools-warning.component';
import { CasingCentralizerFormComponent } from './custom-tools/custom-tool-add/casing-centralizer-form/casing-centralizer-form.component';
import { DCVFormComponent } from './custom-tools/custom-tool-add/dcv-form/dcv-form.component';
import { FishingFormComponent } from './custom-tools/custom-tool-add/fishing-form/fishing-form.component';
import { DrillPipeFormComponent } from './custom-tools/custom-tool-add/drill-pipe-form/drill-pipe-form.component';
import { DrillCollarFormComponent } from './custom-tools/custom-tool-add/drill-collar-form/drill-collar-form.component';
import { FloatCollarFormComponent } from './custom-tools/custom-tool-add/float-collar-form/float-collar-form.component';
import { DrillMotorFormComponent } from './custom-tools/custom-tool-add/drill-motor-form/drill-motor-form.component';
import { CustomToolViewComponent } from './custom-tools/custom-tool-view/custom-tool-view.component';
import { CustomToolSketchComponent } from './custom-tools/custom-tool-sketch/custom-tool-sketch.component';
import { FloatShoeFormComponent } from './custom-tools/custom-tool-add/float-shoe-form/float-shoe-form.component';
import { GuideShoeFormComponent } from './custom-tools/custom-tool-add/guide-shoe-form/guide-shoe-form.component';
import { JarFormComponent } from './custom-tools/custom-tool-add/jar-form/jar-form.component';
import { HWDPFormComponent } from './custom-tools/custom-tool-add/hwdp-form/hwdp-form.component';
import { RSSFormComponent } from './custom-tools/custom-tool-add/rss-form/rss-form.component';
import { RSSSFormComponent } from './custom-tools/custom-tool-add/rsss-form/rsss-form.component';
import { PackerFormComponent } from './custom-tools/custom-tool-add/packer-form/packer-form.component';
import { PostFormComponent } from './custom-tools/custom-tool-add/post-form/post-form.component';
import { ReEntryFormComponent } from './custom-tools/custom-tool-add/re-entry-form/re-entry-form.component';
import { MillFormComponent } from './custom-tools/custom-tool-add/mill-form/mill-form.component';
import { SpecialToolFormComponent } from './custom-tools/custom-tool-add/special-tool-form/special-tool-form.component';
import { SpecialToolViewComponent } from './custom-tools/custom-tool-add/special-tool-view/special-tool-view.component';

@NgModule({
  declarations: [
    CatalogsComponent,
    MaterialsComponent,
    ConnectionsComponent,
    // CentralizersComponent,
    CustomConnectionsComponent,
    CustomToolsComponent,
    CustomConnectionsDetailsComponent,
    CustomConnectionsDeleteComponent,
    CustomComponentComponent,
    CustomToolAddComponent,
    BitFormComponent,
    CasingPipeFormComponent,
    CasingCentralizerFormComponent,
    DCVFormComponent,
    CustomToolWarningDialogComponent,
    FishingFormComponent,
    DrillPipeFormComponent,
    DrillCollarFormComponent,
    FloatCollarFormComponent,
    DrillMotorFormComponent,
    CustomToolViewComponent,
    CustomToolSketchComponent,
    FloatShoeFormComponent,
    GuideShoeFormComponent,
    JarFormComponent,
    HWDPFormComponent,
    RSSFormComponent,
    RSSSFormComponent,
    PackerFormComponent,
    PostFormComponent,
    ReEntryFormComponent,
    MillFormComponent,
    SpecialToolFormComponent,
    SpecialToolViewComponent
  ],
  imports: [
    CommonModule,
    AllModule,
    CatalogsRoutingModule,
  
  ]
})
export class CatalogsModule { }
