import { Component, OnInit} from '@angular/core';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Connection } from 'src/app/core/interfaces/connectionElements.interface';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.scss']
})
export class ConnectionsComponent implements OnInit {
  tableColumns:  Array<Column>;
  tableData: Connection[] = [];
  angleLabel:string="";//(°)
  pressureLabel:string=""//(kPa/psi)
  shortLengthLabel:string="";//(mm/in)
  private activeUnitSystem: { [key: string]: { precision: number, unitName: number, unitValue: string } };

  constructor(private connectionService:ConnectionService,private unitsService: UnitsService,) { }

  ngOnInit(): void {

   this.tableColumns=[
      { columnDef: 'ConnectionName', header: 'Connection', cell: (element: Record<string, any>) => `${element['ConnectionName']}` },
      { columnDef: 'tpr', header: 'Taper (inches/ft)', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['tpr']}`},
      { columnDef: 'Drg', header: 'Relief Groove Ø,in', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['Drg']}` },
      { columnDef: 'C', header: 'Pitch Ø At Gauge Point, in', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['C']}` },
      { columnDef: 'S', header: 'Recommended Make Up Stress,psi', unitType: "pressure", cell: (element: Record<string, any>) => `${element['S']}` },
      { columnDef: 'H', header: 'Thread Height', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['H']}` },
      { columnDef: 'Srs', header: 'Root Truncation', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['Srs']}` },
      { columnDef: 'QC', header: 'Nominal CounterBore', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['QC']}` },
      { columnDef: 'BBBDia', header: 'Box Bore Back Ø', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['BBBDia']}` },
      { columnDef: 'Lpc', header: 'Length Of The Pin', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['Lpc']}` },
      { columnDef: 'P', header: 'Lead Of Thread', unitType: "shortLength", cell: (element: Record<string, any>) => `${element['P']}` },
      { columnDef: 'F', header: 'Mating Surfaces friction coeff.', cell: (element: Record<string, any>) => `${element['F']}` },
      { columnDef: 'Theta', header: '1/2 included Angle of Thread', unitType: "angle", cell: (element: Record<string, any>) => `${element['Theta']}` },

  ]
  this.getActiveUnitSystemData();

    this.connectionService.getConnectionList().subscribe({

        next: (data) => {
         this.tableData = data.result;
         for (const obj of data.result) {
          for (const column of this.tableColumns) {
            if (obj[column.columnDef] == null || obj[column.columnDef] == undefined) {
              obj[column.columnDef] = "";
            } else {
              if(['tpr','Drg', 'C','S', 'H', 'Srs', 'QC', 'BBBDia', 'Lpc', 'P', 'Theta'].includes(column.columnDef)){
                const _precision = this.activeUnitSystem[column.unitType].precision;
                obj[column.columnDef] = obj[column.columnDef].toFixed(_precision);
              }
            }
          }
        }
        },
        error: (error) => {
          //console.log("coonn error",error.error.result);
          this.tableData = error.error.result;
        }
      
      });
  }

  /*
** get active unit from active unit system and integration with labels, placeholders and headers
*/
getActiveUnitSystemData() {

  // this.unitSystemData = {};
  this.unitsService.getActiveUnitSystemDetails().subscribe({
    next: (res) => {
      if (res) {
        //console.log("res in lithologies---", res);
        let activeUnitSystemData = res;
        this.activeUnitSystem = res
        this.angleLabel = activeUnitSystemData.angle.unitValue;
        this.pressureLabel = activeUnitSystemData.pressure.unitValue;
        this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
        // this.tableColumns[2].header = "Young's Modulus, " + this.youngsModulusLabel + '';
        this.tableColumns[2].header = 'Relief Groove Ø, ' + this.shortLengthLabel;
        this.tableColumns[3].header = 'Pitch Ø At Gauge Point, ' + this.shortLengthLabel;
        this.tableColumns[4].header = 'Recommended Make Up Stress, ' + this.pressureLabel;
        this.tableColumns[5].header = 'Thread Height, ' + this.shortLengthLabel;
        this.tableColumns[6].header = 'Root Truncation, ' + this.shortLengthLabel;
        this.tableColumns[7].header = 'Nominal CounterBore, ' + this.shortLengthLabel;
        this.tableColumns[8].header = 'Box Bore Back Ø, ' + this.shortLengthLabel + '';
        this.tableColumns[9].header = 'Length Of The Pin, ' + this.shortLengthLabel;
        this.tableColumns[10].header = 'Lead Of Thread, ' + this.shortLengthLabel;
        this.tableColumns[12].header = '1/2 included Angle of Thread, ' + this.angleLabel;
        
        // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

      } else {
        //console.log('error');
      }
    },
    error: (error) => {
      //console.log("Unit", error.error.result);
    }
  })
}

}
