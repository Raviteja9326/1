import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CatalogsComponent } from './catalogs.component';
import { ConnectionsComponent } from './connections/connections.component';
import { CustomConnectionsComponent } from './custom-connections/custom-connections.component';
import { CustomToolsComponent } from './custom-tools/custom-tools.component';
import { CustomComponentComponent } from './custom-tools/custom-component/custom-component.component';


const routes: Routes = [
  {
    path: '', component: CatalogsComponent, children: [
      { path: 'materials', data: { preload: false }, loadChildren: () => import("./materials/materials.module").then(m => m.MaterialsModule) },
      { path: 'lithologies', data: { preload: false }, loadChildren: () => import("./lithologies/lithologies.module").then(m => m.LithologiesModule)},
      { path: 'connections', data: { preload: false }, component: ConnectionsComponent },
      { path: 'customconnections', data: { preload: false }, component: CustomConnectionsComponent },
      { path: 'centralizers', data: { preload: false }, loadChildren: () => import("./centralizers/centralizers.module").then(m => m.CentralizersModule)},
      { path: 'customtools', data: { preload: false }, component: CustomToolsComponent },
      { path: 'custom-component', data:{ preload:false }, component:CustomComponentComponent }
    ]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CatalogsRoutingModule { }
