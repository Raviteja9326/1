import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-catalogs',
  templateUrl: './catalogs.component.html',
  styleUrls: ['./catalogs.component.scss']
})
export class CatalogsComponent implements OnInit {

  isLinear:boolean = false;
  constructor(private route: Router) { }// constructor ends

  ngOnInit(): void {
    const url = this.route.url;
    this.route.navigate([url])
    this.onStepClick({selectedIndex:0});
  }

  onStepClick(event) {
    //console.log(event)
    if(event.selectedIndex == 0){
      this.route.navigate(['/dashboard/catalogs/materials']);
    }
    else if(event.selectedIndex == 1){
      this.route.navigate(['/dashboard/catalogs/lithologies']);
    }
    else if(event.selectedIndex == 2){
      this.route.navigate(['/dashboard/catalogs/connections']);
    }
    else if(event.selectedIndex == 3){
      this.route.navigate(['/dashboard/catalogs/customconnections']);
    }
    else if(event.selectedIndex == 4){
      this.route.navigate(['/dashboard/catalogs/centralizers']);
    }
    else if(event.selectedIndex == 5){
      this.route.navigate(['/dashboard/catalogs/customtools']);
    }
  }

}
