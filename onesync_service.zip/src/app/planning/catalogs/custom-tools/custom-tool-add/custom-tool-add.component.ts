import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { DCVFormComponent } from './dcv-form/dcv-form.component';
import { BitFormComponent } from './bit-form/bit-form.component';
import { CasingPipeFormComponent } from './casing-pipe-form/casing-pipe-form.component';
import { CasingCentralizerFormComponent } from './casing-centralizer-form/casing-centralizer-form.component';
import { View } from 'backbone';
import { FishingFormComponent } from './fishing-form/fishing-form.component';
import { DrillPipeFormComponent } from './drill-pipe-form/drill-pipe-form.component';
import { DrillCollarFormComponent } from './drill-collar-form/drill-collar-form.component';
import { ReplaySubject } from 'rxjs';
import { ToolStyles } from 'src/app/core/constants/toolObjects.constants';
import { DrillMotorFormComponent } from './drill-motor-form/drill-motor-form.component';
import { FloatCollarFormComponent } from './float-collar-form/float-collar-form.component';
import { FloatShoeFormComponent } from './float-shoe-form/float-shoe-form.component';
import { GuideShoeFormComponent } from './guide-shoe-form/guide-shoe-form.component';
import { JarFormComponent } from './jar-form/jar-form.component';
import { HWDPFormComponent } from './hwdp-form/hwdp-form.component';
import { RSSFormComponent } from './rss-form/rss-form.component';
import { RSSSFormComponent } from './rsss-form/rsss-form.component';
import { UnitsService } from 'src/app/core/services/units.service';
import { PackerFormComponent } from './packer-form/packer-form.component';
import { PostFormComponent } from './post-form/post-form.component';
import { Tools } from 'src/app/core/enum/tools.enum';
import { ReEntryFormComponent } from './re-entry-form/re-entry-form.component';
import { MillFormComponent } from './mill-form/mill-form.component';
import { SpecialToolFormComponent } from './special-tool-form/special-tool-form.component';

@Component({
  selector: 'app-custom-tool-add',
  templateUrl: './custom-tool-add.component.html',
  styleUrls:['./custom-tool-add.component.scss']
})
export class CustomToolAddComponent implements OnInit{
    Tool: any;
    toolOptions:any = [
      // {label:"Bit",value:1},
      // {label:"Casing Pipe",value:2},
      // {label:"Casing Centralizer",value:3},
      // {label:"Downhole Control Valves",value:4},
      // {label:"Fishing",value:5},
      // {label:"Drill Pipe",value:6},
      // {label:"Drill Collar",value:7},
      // {label:"Float Collar", value:8},
      // {label:"Drilling Motor", value:9},
      // {label:"Float Shoe", value:10},
      // {label:"Guide Shoe", value:11},
      // {label:"HWDP", value:12},
      // {label:"Jar", value:13},
      // {label:"POST", value:15},
      // {label:"RSS", value:16},
      // {label:"Packer", value:17}
    ];
    toolSizeOptions:any;
    formData: any;
    filterControl: FormControl = new FormControl();
    filteredToolOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    threedStyles:any ={
      material:{
        color: 0x0000ff, 
        wireframe: false,
        roughness: 0.2,  
        metalness: 0.1,
      },
      path:"assets/3d-objects/objects/PDCBit3_3.obj",
      cameraFactor:300,
      marginFromTop:-100,
      scaleFactor:50
  };
  modelWidth: any;
  modelHeight: any;
  show3d: any = false;
  gridSize: any = "col-lg-12";
    @ViewChild(BitFormComponent) BitFormComponent!: BitFormComponent;
    @ViewChild(CasingPipeFormComponent) CasingPipeFormComponent!: CasingPipeFormComponent;
    @ViewChild(CasingCentralizerFormComponent) CasingCentralizerFormComponent!: CasingCentralizerFormComponent;
    @ViewChild(DCVFormComponent) DCVFormComponent!: DCVFormComponent;
    @ViewChild(FishingFormComponent) FishingFormomponent!: FishingFormComponent;
    @ViewChild(DrillPipeFormComponent) DrillPipeFormComponent!: DrillPipeFormComponent;
    @ViewChild(DrillCollarFormComponent) DrillCollarFormComponent!: DrillCollarFormComponent;
    @ViewChild(DrillMotorFormComponent) DrillMotorFormComponent!: DrillMotorFormComponent;
    @ViewChild(FloatCollarFormComponent) FloatCollarFormComponent!: FloatCollarFormComponent;
    @ViewChild(FloatShoeFormComponent) FloatShoeFormComponent!: FloatShoeFormComponent;
    @ViewChild(GuideShoeFormComponent) GuideShoeFormComponent!: GuideShoeFormComponent;
    @ViewChild(JarFormComponent) JarFormComponent!: JarFormComponent;
    @ViewChild(HWDPFormComponent) HWDPFormComponent!: HWDPFormComponent;
    @ViewChild(RSSFormComponent) RSSFormComponent!: RSSFormComponent;
    @ViewChild(PackerFormComponent)PackerFormComponent!:PackerFormComponent;
    @ViewChild(ReEntryFormComponent)ReEntryFormComponent!:ReEntryFormComponent;
    @ViewChild(MillFormComponent)MillFormComponent!:MillFormComponent;
    @ViewChild(PostFormComponent)PostFormComponent!:PostFormComponent;
    @ViewChild('threeDSceneContainer') threeDSceneContainer: any;
    @ViewChild(SpecialToolFormComponent) SpecialToolFormComponent!: SpecialToolFormComponent;
  objType: any = 2;
  dimensionLength: any;
  dimensionToolSize: any;
  sketchToolType:any;
  toolConf: any;
  shortLengthLabel: string = "";//(in or mm)
  lengthLabel: string = "";//(ft or m)

    constructor(
        public dialogRef: MatDialogRef<CustomToolAddComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private customToolService: CustomToolService,
        private unitsService: UnitsService,
      ) {
      
  for(const toolKey of Object.keys(Tools)){
    this.toolOptions.push({label:toolKey,value:parseInt(Tools[toolKey])});
  }
      }
    ngOnInit(): void {
      
      this.getActiveUnitSystemData();
      this.filteredToolOptions.next(this.toolOptions);
      // check for update
      if(this.data.payload){
        //console.log("data received for update",this.data);
        this.Tool = this.data.payload.ToolSizeId;
        this.customToolService.getCustomToolDetails(this.data.payload.TemplateId).subscribe({
          next:(data)=>{
            //console.log("details",data.result.detaiils);
            this.formData = {...data.result.detaiils};
          },
          error: (error)=>{

          }
        });
      }
      else{
        this.Tool = 1;
      }
      
      this.filterControl
      .valueChanges
      .subscribe({
        next: () => {
          let filter = this.filterControl.value.toLowerCase();
          let filteredList = this.toolOptions.filter(
            option => option.label.toLowerCase().indexOf(filter) >= 0
          );
          this.filteredToolOptions.next(filteredList);
        }
      }); 

     
     
    }

      onButtonClick(action: string): void {
        /**
         * This function is called on Closing the dialog
         */
        // Pass data to the parent component based on the button clicked
        if(action=="success" || action=="cancel")
        this.dialogRef.close({
          action: action,
        });
      }

      onSubmit(){
        /**
         * This function will be called on save
         */
        if(this.Tool==6){
          this.BitFormComponent.save();
        }
        else if(this.Tool==26){
          this.CasingPipeFormComponent.save();
        }
        else if(this.Tool==29){
          this.CasingCentralizerFormComponent.save();
        }
        else if(this.Tool==31){
          this.DCVFormComponent.save();
        }
        else if(this.Tool==35){
          this.FishingFormomponent.save();
        }
        else if(this.Tool==1){
          this.DrillPipeFormComponent.save();
        }
        else if(this.Tool==3){
          this.DrillCollarFormComponent.save();
        }
        else if(this.Tool==40){
          this.FloatCollarFormComponent.save();
        }
        else if(this.Tool==10){
          this.DrillMotorFormComponent.save();
        }
        else if(this.Tool==34){
          this.FloatShoeFormComponent.save();
        }
        else if(this.Tool==25){
          this.GuideShoeFormComponent.save();
        }
        else if(this.Tool==2){
          this.HWDPFormComponent.save();
        }
        else if(this.Tool==4){
          this.JarFormComponent.save();
        }
        else if(this.Tool==41){
          this.PostFormComponent.save();
        }
        else if(this.Tool==21){
          this.RSSFormComponent.save();
        }
        else if(this.Tool==38){
          this.PackerFormComponent.save();
        }
        else if(this.Tool==36){
          this.ReEntryFormComponent.save();
        }
        else if(this.Tool==37){
          this.MillFormComponent.save();
        }
        
      }

      openSidePane(){
        /**
         * This function will be called on clicking the side panel button
         */
        this.gridSize = "col-lg-7"
        this.show3d = true;
        this.threedStyles = {...ToolStyles[this.Tool],LengthDimension:this.dimensionLength,ToolSizeDimension:this.dimensionToolSize,
          ToolType:this.sketchToolType,
          ToolConf:this.toolConf,
          Sketch:{
            tool:this.Tool,
            dimensionText:{
              length: {text:this.dimensionLength},
              toolsize:{text:this.dimensionToolSize},
            },
            templateId:this.data.payload?.TemplateId?this.data.payload?.TemplateId:""
          }};
        //console.log("Styles",ToolStyles[this.Tool]);

        setTimeout(() => {
          try{
          if(!this.modelWidth && !this.modelHeight){
          const parentDiv = this.threeDSceneContainer.nativeElement;
          if(this.objType==1){
            this.modelWidth = parentDiv.clientWidth-20;
          this.modelHeight = 415;
          }
          else{
          this.modelWidth = parentDiv.clientWidth-20;
          this.modelHeight = 415;
        }
        }}
          catch(e){
            //console.log("3D container hidden",e);
          }
        }, 1000
        )
      }

      closeSidePane(){
        /**
         * This function will be called on closing the side pane
         */
        this.gridSize = "col-lg-12"
        this.show3d = false;
      }

      changeType(type){
        /**
         * This function is called when 3d Visualization type selected is changed
         */
        this.objType = type;
        const parentDiv = this.threeDSceneContainer.nativeElement;
        if(this.objType==1){
          this.modelWidth = parentDiv.clientWidth-20;
        this.modelHeight = 415;
        }
        else{
        this.modelWidth = parentDiv.clientWidth-20;
        this.modelHeight = 420;
      }
      }

      changeDimension(event){
        /**
         * This event is called when dimensions is changed in any form
         */
        this.dimensionLength = event.length+" "+this.lengthLabel;
        this.dimensionToolSize = event.toolSize+" "+this.shortLengthLabel;
        this.sketchToolType = event.toolType;
        this.toolConf = event.toolConf;
        this.threedStyles = {
          ...ToolStyles[this.Tool],
          LengthDimension:this.dimensionLength,
          ToolSizeDimension:this.dimensionToolSize,
          ToolType:this.sketchToolType,
          ToolConf:this.toolConf,
          Sketch:{
            tool:this.Tool,
            dimensionText:{
              length: {text:this.dimensionLength},
              toolsize:{text:this.dimensionToolSize},
            },
            templateId:this.data.payload?.TemplateId?this.data.payload?.TemplateId:""
          }
        };
        //console.log("Styles",ToolStyles[this.Tool]);
      }
      
         /*
    ** get active unit from active unit system and integration with labels, placeholders and headers
    */
    getActiveUnitSystemData() {
  
      // this.unitSystemData = {};
      this.unitsService.getActiveUnitSystemDetails().subscribe({
          next: (res) => {
              if (res) {
                  //console.log("res in 3D case---", res);
                  let activeUnitSystemData = res;
                  this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                  this.lengthLabel = activeUnitSystemData.length.unitValue;
                  //console.log("res in 3D case shortLengthLabel---", this.shortLengthLabel);
                  //console.log("res in 3D case lengthLabel---", this.lengthLabel);
                  // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
  
              } else {
                  //console.log('error');
              }
          },
          error: (error) => {
              //console.log("Unit", error.error.result);
          }
      })
  }
}
