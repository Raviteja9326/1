import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { V } from 'jointjs';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-float-collar-form',
  templateUrl: './float-collar-form.component.html'
})
export class FloatCollarFormComponent implements OnInit,OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [];
    toolWeightOptions:any = [];
    threadTypeOptions: any = [];
    materialOptions:any = [];
    shortLengthLabel:string="";//(in or mm)
    lengthLabel:string="";//(ft or m)
    massLabel:string="";// (lbm or Kg)
    linearMassDensityLabel:string="";// (kg/m)
    torqueLabel:string="";// N-m
    connconfOptions: any = [
    ];
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredBottomThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlBottomThreadType: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControlconn: FormControl = new FormControl();
    fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService:ConnectionService,
        private unitsService: UnitsService, 
        private toastR: ToastrService
      ) {
       
        
      }
    ngOnInit(): void {
        
    }
    ngOnChanges(){
        this.getActiveUnitSystemData();
        this.connconfOptions = [];
        for(const conconfKey of Object.keys(ConnectionConfiguration)){
            this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
        }
        this.toolWeightOptions = [];
        for(const toolweightKey of Object.keys(ToolWeightOption)){
            this.toolWeightOptions.push({label:toolweightKey,value:parseInt(ToolWeightOption[toolweightKey])});
        }
        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 

        this.fileteredconnconfOptions.next(this.connconfOptions);
        this.filterControlconn
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlconn.value.toLowerCase();
            let filteredList = this.connconfOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredconnconfOptions.next(filteredList);
          }
        }); 
        this.toolForm = this.formBuilder.group({
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces]],
            Length:[0.00, [Validators.required]],
            ToolWeightOption:['',[Validators.required]],
            Mass:['',[Validators.min(0)]],
            AdjustedWeight:['',[Validators.min(0)]],
            NW:['',[CustomValidators.greaterThanMin(0)]],
            Material:['',[Validators.required]],
            TFA:['',[CustomValidators.greaterThanMin(0)]],
            ConnectionConfiguration:['',[Validators.required]],
            TopThreadType:['',[Validators.required]],
            TopMUT:['',[Validators.required]],
            BottomThreadType:['',[Validators.required]],
            BottomMUT:['',[Validators.required]],       
            BodyOD:['',[CustomValidators.greaterThanMin(0)]],
            BodyID:['',[CustomValidators.greaterThanMin(0)]],
            BodyLength:['',[Validators.required,Validators.min(0),Validators.max(30.48)]]
          });
        
          this.toolForm.get('BodyOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            this.toolForm.get('BodyID').setValidators([Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            this.toolForm.get('BodyID').updateValueAndValidity();
          });
          this.toolForm.get('ConnectionConfiguration').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            if(value==2 || value==5){
            this.toolForm.get('BottomThreadType').setValidators([]);
            this.toolForm.get('BottomMUT').setValidators([]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
        else{
            this.toolForm.get('BottomThreadType').setValidators([Validators.required]);
            this.toolForm.get('BottomMUT').setValidators([Validators.required]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
          });
          this.toolForm.get('Length')?.disable();
       
          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return this.getConnectionsDropdown();
          })
          .then((data)=>{
            this.threadTypeOptions = [...data.result];
            this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlTopThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlTopThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredTopThreadTypeOptions.next(filteredList);
              }
            }); 

            this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlBottomThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlBottomThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredBottomThreadTypeOptions.next(filteredList);
              }
            });
            //get materials
            return this.getMaterialsDropdown();
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in bit form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                    this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, m']} )?.value);
                let toolweightoption = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool weight option']} )?.value;
                this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                if(this.toolForm.get('ToolWeightOption').value == 0){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value == 1){
                    this.toolForm.get('AdjustedWeight').enable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value==2){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').enable();
                }
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, kg']} )?.value);
                this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Adjusted kg/m']} )?.value);
                this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['NW kg/m']} )?.value);
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
                this.toolForm.get('TFA').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['TFA']} )?.value);
                let connConfId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Connection configuration']} )?.value;
                if(connConfId)
                    this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(connConfId));
                let connectionId1 = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
                if(connectionId1)  
                    this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId1));
                this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
               

                if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
                    let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
                    if(bottomconnectionId)  
                        this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
                    this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
                }
                this.toolForm.get('BodyOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body OD mm']} )?.value);
                this.toolForm.get('BodyID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body ID mm']} )?.value);
                this.toolForm.get('BodyLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body length m']} )?.value);

                
             
            }
            else{
           
            this.toolForm.get('Mass')?.patchValue(0);
            this.toolForm.get('AdjustedWeight')?.patchValue(0);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
        this.emitData();
          });
    }

    async getMaterialsDropdown(){

         let data;
         try{
            data = await lastValueFrom(this.materialService.getMaterialsList());
         }
         catch(e){
            this.toastR.error("Something went wrong while fetching materials");
         }
         return data;
    }//end of functions

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions

    async getConnectionsDropdown(){

        let data;
        try{
            data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
        }
        catch(e){
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight(){
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if(this.toolForm.get('ToolWeightOption').value == 0){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            if(this.toolForm.get('Length').value)
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            else
            this.toolForm.get('AdjustedWeight').patchValue(0);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value == 1){
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value==2){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            if(this.toolForm.get('Length').value)
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            else
            this.toolForm.get('AdjustedWeight').patchValue(0);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight(){
        if(this.toolForm.get('Length').value)
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value!=0?this.toolForm.get('Mass').value/this.toolForm.get('Length').value:0);
        else
        this.toolForm.get('AdjustedWeight').patchValue(0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass(){
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
    }

    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
   
          }
      
        
        //console.log(this.toolForm.valid);
        
        //console.log("validity flags",this.toolForm.valid);
        //call api below if all the flags are true

        if(this.toolForm.valid){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Custom Tool added successfully");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    this.toastR.error("Something went wrong");
                }
            });}
            
        }
    }

    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){


        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem")
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, m'],
                    "ColumnName": "Length, m",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool weight option'],
                    "ColumnName": "Tool weight option",
                    "value": this.toolForm.get("ToolWeightOption").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Mass, kg'],
                    "ColumnName": "Mass, kg",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['Adjusted kg/m'],
                    "ColumnName": "Adjusted kg/m",
                    "value": this.toolForm.get('AdjustedWeight').value
                },
                {
                    "Id": toolColumns['NW kg/m'],
                    "ColumnName": "NW kg/m",
                    "value": this.toolForm.get('NW').value
                },
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
                {
                    "Id": toolColumns['Connection configuration'],
                    "ColumnName": "Connection configuration",
                    "value": this.toolForm.get('ConnectionConfiguration').value

                },
                {
                    "Id": toolColumns['TFA'],
                    "ColumnName": "TFA",
                    "value": this.toolForm.get('TFA').value?this.toolForm.get('TFA').value:0
                },
               
                {
                    "Id": toolColumns['Thread type'],
                    "ColumnName": "Thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['Top MUT n-m'],
                    "ColumnName": "Top MUT n-m",
                    "value": this.toolForm.get('TopMUT').value
                },
               
                {
                    "Id": toolColumns['Bottom thread type'],
                    "ColumnName": "Bottom thread type",
                    "value": this.toolForm.get('BottomThreadType').value
                },
                {
                    "Id": toolColumns['Bottom MUT n-m'],
                    "ColumnName": "Bottom MUT n-m",
                    "value": this.toolForm.get('BottomMUT').value
                },
               
                {
                    "Id": toolColumns['Body OD mm'],
                    "ColumnName": "Body OD mm",
                    "value": this.toolForm.get('BodyOD').value
                },
                {
                    "Id": toolColumns['Body ID mm'],
                    "ColumnName": "Body ID mm",
                    "value": this.toolForm.get('BodyID').value
                },
                {
                    "Id": toolColumns['Body length m'],
                    "ColumnName": "Body length m",
                    "value": this.toolForm.get('BodyLength').value
                }
                
                ],
           
           
        
            }
        
        }

        return payload;
    }

    resetThreadtype(){
        if(this.updateData){
        let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
        if(connectionId)  
            this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
        this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
        if(bottomconnectionId)  
            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
       
    }
    else{
        this.toolForm.get('TopThreadType').patchValue('');
        this.toolForm.get('TopMUT').patchValue('');
        this.toolForm.get('BottomThreadType').patchValue('');
        this.toolForm.get('BottomMUT').patchValue('');
    

    }
    }

    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value
        });
    }
    
/*
    ** get active unit from active unit system and integration with labels, placeholders and headers
    */
    getActiveUnitSystemData() {
  
      // this.unitSystemData = {};
      this.unitsService.getActiveUnitSystemDetails().subscribe({
        next: (res) => {
          if (res) {
            //console.log("res in casing---", res);
            let activeUnitSystemData = res;
            this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
            this.lengthLabel = activeUnitSystemData.length.unitValue;
            this.massLabel = activeUnitSystemData.mass.unitValue;
            this.linearMassDensityLabel=activeUnitSystemData.linearMassDensity.unitValue;
            this.torqueLabel=activeUnitSystemData.torque.unitValue;
            
  
  
            // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
           
          } else {
            //console.log('error');
          }
        },
        error: (error) => {
          //console.log("Unit", error.error.result);
        }
      })
    }
}
