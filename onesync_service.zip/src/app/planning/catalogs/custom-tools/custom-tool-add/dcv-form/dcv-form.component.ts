import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { DCVType } from 'src/app/core/enum/custom-tools/dcvType.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-dcv-form',
  templateUrl: './dcv-form.component.html'
})
export class DCVFormComponent implements OnInit,OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [];
    toolWeightOptions:any = [];
    threadTypeOptions: any = [];
    materialOptions:any = [];
    nozzleArrayList:any = [];
    nozzleArrayListError: any[] = []; 
    isNozzleChecked: boolean = false;
    typeOptions: any = [
    ];
    connconfOptions: any = [
    ];
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredBottomThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlBottomThreadType: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControltype: FormControl = new FormControl();
    fileteredtypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

    filterControlconn: FormControl = new FormControl();
    fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    shortLengthLabel: string = "";//(in or mm)
    lengthLabel: string = "";//(ft or m)
    massLabel: string = "";// (lbm or Kg)
    linearMassDensityLabel: string = "";// (lb/ft or kg/m)
    torqueLabel: string = "";// (lbf-ft or N-m)
    percentageLabel: string = "";//%
    forceLabel: string = "";//lbf or N
    stressLabel: string = "";//ksi or MPa
    nozzleSizeLabel: string = "";//x 1/32" or mm
    rotationVelocityLabel: string = "";//rpm
    pressureLabel: string = "";//(kPa or psi)
    flowLabel: string = "";//l/min or gal/min
    angleLabel: string = "";//°

    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService:ConnectionService,
        private toastR: ToastrService,
        private unitsService: UnitsService,
      ) {
       
        
      }
    ngOnInit(): void {
        
    }
    ngOnChanges(){
       
        this.getActiveUnitSystemData();
        this.toolWeightOptions = [];
        for(const toolweightKey of Object.keys(ToolWeightOption)){
            this.toolWeightOptions.push({label:toolweightKey,value:parseInt(ToolWeightOption[toolweightKey])});
        }
        this.connconfOptions = [];
        for(const conconfKey of Object.keys(ConnectionConfiguration)){
            this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
        }

        this.typeOptions = [];
        for(const dcvtypeKey of Object.keys(DCVType)){
            this.typeOptions.push({label:dcvtypeKey,value:parseInt(DCVType[dcvtypeKey])});
        }

        this.fileteredtypeOptions.next(this.typeOptions);
        this.filterControltype
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControltype.value.toLowerCase();
            let filteredList = this.typeOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtypeOptions.next(filteredList);
          }
        }); 


        this.fileteredconnconfOptions.next(this.connconfOptions);
        this.filterControlconn
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlconn.value.toLowerCase();
            let filteredList = this.connconfOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredconnconfOptions.next(filteredList);
          }
        }); 


        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 

        this.toolForm = this.formBuilder.group({
            Type:  ['', [Validators.required]],
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required,CustomValidators.noContinuousSpaces]],
            Length:[''],
            ToolWeightOption:['',[Validators.required]],
            Drift:['',[]],
            Mass:['',[]],
            AdjustedWeight:['',[]],
            NW:['',[]],
            Material:['',[Validators.required]],
            Burst:['',[]],
            Collapse:['',[]],
            Tension:['',[]],
            Compression:['',[]],
            ConnectionConfiguration:['',[Validators.required]],
            TopThreadType:['',[Validators.required]],
            TopMUT:['',[Validators.required]],
            BottomThreadType:['',[Validators.required]],
            BottomMUT:['',[Validators.required]],
            TFA:['',[Validators.min(1)]],
            Efficiency:['',[Validators.min(0),Validators.max(100)]],
            Nozzles:['',[Validators.min(0),Validators.max(1000)]],
            BodyOD:['',[Validators.required,CustomValidators.greaterThanMin(0)]],
            BodyID:['',[Validators.required,CustomValidators.greaterThanMin(0)]],
            BodyLength:['',[Validators.required,Validators.min(0),Validators.max(100)]]
          });
          
          this.toolForm.get('BodyOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            this.toolForm.get('BodyID').setValidators([Validators.required,CustomValidators.greaterThanMin(0), CustomValidators.lessThanMax(maxLimit)]);
            this.toolForm.get('BodyID').updateValueAndValidity();
          });

          this.toolForm.get('ConnectionConfiguration').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            if(value==2 || value==5){
            this.toolForm.get('BottomThreadType').setValidators([]);
            this.toolForm.get('BottomMUT').setValidators([]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
        else{
            this.toolForm.get('BottomThreadType').setValidators([Validators.required]);
            this.toolForm.get('BottomMUT').setValidators([Validators.required]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
          });
          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return  this.getConnectionsDropdown()
          })
          .then((data)=>{
            this.threadTypeOptions = [...data.result];
            this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlTopThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlTopThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredTopThreadTypeOptions.next(filteredList);
              }
            }); 

            this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlBottomThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlBottomThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredBottomThreadTypeOptions.next(filteredList);
              }
            }); 
            //get materials
            return this.getMaterialsDropdown();
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in bit form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                    this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                let typeId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['DCV type']} )?.value;
                if(typeId)
                    this.toolForm.get('Type').patchValue(parseInt(typeId));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, ft']} )?.value);
                let toolweightoption = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool weight option']} )?.value;
                this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                if(this.toolForm.get('ToolWeightOption').value == 0){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value == 1){
                    this.toolForm.get('AdjustedWeight').enable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value==2){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').enable();
                }
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, lbm']} )?.value);
                this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Adjusted weigth, lb/ft']} )?.value);
                this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['NW lb/ft']} )?.value);
                this.toolForm.get('Drift').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Drift, in']} )?.value);
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value;
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
                this.toolForm.get('Burst').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Burst, psi']} )?.value);
                this.toolForm.get('Collapse').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Collapsi, psi']} )?.value);
                this.toolForm.get('Tension').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tension, ibf']} )?.value);
                this.toolForm.get('Compression').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Compression, ibf']} )?.value);
                
                let connConfId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Connection configuration']} )?.value;
                if(connConfId)
                    this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(connConfId));
                
                this.toolForm.get('Nozzles').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Nozzles']} )?.value);
                //nozzle section
                this.nozzleArrayList = this.updateData.nozzleSections.map((item)=>{
                    return item.value;
                });
                this.nozzleArrayListError = Array.from({ length: this.nozzleArrayList.length }, (_, index) => "");
                if(this.nozzleArrayList.length>0){
                    this.isNozzleChecked = true;
                    this.toolForm.get('TFA').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['TFA']} )?.value);
                    this.toolForm.get('Efficiency').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Efficiency']} )?.value);
                }
                let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Connection configuration']} )?.value
                if(connectionId)  
                    this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
                this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['MUT']} )?.value);
                if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
                        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
                        if(bottomconnectionId)  
                            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
                        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT']} )?.value);
                }
                this.toolForm.get('BodyOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body OD']} )?.value);
                this.toolForm.get('BodyID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body ID']} )?.value);
                this.toolForm.get('BodyLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body length']} )?.value);
               
            }
            else{
            this.toolForm.get('Length')?.patchValue(1);
            this.toolForm.get('Mass')?.patchValue(0);
            this.toolForm.get('AdjustedWeight')?.patchValue(0);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
        this.emitData();
          });
    }

    async getMaterialsDropdown(){

         let data;
         try{
            data = await lastValueFrom(this.materialService.getMaterialsList());
         }
         catch(e){
            this.toastR.error("Something went wrong while fetching materials");
         }
         return data;
    }//end of functions

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions

    async getConnectionsDropdown(){

        let data;
        try{
            data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
        }
        catch(e){
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight(){
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if(this.toolForm.get('ToolWeightOption').value == 0){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value == 1){
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value==2){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight(){
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value!=0?this.toolForm.get('Mass').value/this.toolForm.get('Length').value:0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass(){
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
    }

    createNozzleInput(numOfNozzles){
        this.nozzleArrayList = Array.from({ length: numOfNozzles }, (_, index) => "");
        this.nozzleArrayListError = Array.from({ length: numOfNozzles }, (_, index) => "");
    }

   

    validateNozzleDiameter(value,i){
        if(value){
            if(value<0){
                this.nozzleArrayListError[i] = "Nozzle Diameter Must be Greater Than 0";
            }
            else{
                this.nozzleArrayListError[i] = "";
            }
        }
        else{
            this.nozzleArrayListError[i] = "Nozzle Diameter Must be Greater Than 0";
        }
    }

   
    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
   
          }
        this.nozzleArrayList.forEach((element,i) => {
            this.validateNozzleDiameter(element,i)
        });
     
        let nozzleFlag = true,sectionFlag = true;
        this.nozzleArrayListError.forEach((item)=>{
            if(item){
                nozzleFlag = false
            }
        });
     

        //console.log("validity flags",this.toolForm.valid,nozzleFlag,sectionFlag);
        //call api below if all the flags are true

        if(this.toolForm.valid && nozzleFlag && sectionFlag){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
          
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Custom Tool added successfully");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    this.toastR.error("Something went wrong");
                }
            });}
            
        }
    }

    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){


        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem"),
                    "ToolType": this.toolForm.get('Type').value
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, ft'],
                    "ColumnName": "Length, ft",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool weight option'],
                    "ColumnName": "Tool weight option",
                    "value": this.toolForm.get("ToolWeightOption").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Mass, lbm'],
                    "ColumnName": "Mass, lbm",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['DCV type'],
                    "ColumnName": "DCV type",
                    "value": this.toolForm.get('Type').value
                },
                {
                    "Id": toolColumns['Adjusted weigth, lb/ft'],
                    "ColumnName": "Adjusted weigth, lb/ft",
                    "value": this.toolForm.get('AdjustedWeight').value
                },
                {
                    "Id": toolColumns['NW lb/ft'],
                    "ColumnName": "NW lb/ft",
                    "value": this.toolForm.get('NW').value
                },
                {
                    "Id": toolColumns['Drift, in'],
                    "ColumnName": "Drift, in",
                    "value": this.toolForm.get("Drift").value?this.toolForm.get("Drift").value:""
                },
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
                {
                    "Id": toolColumns['Burst, psi'],
                    "ColumnName": "Burst, psi",
                    "value": this.toolForm.get('Burst').value?this.toolForm.get('Burst').value:""
                },
                {
                    "Id": toolColumns['Collapsi, psi'],
                    "ColumnName": "Collapsi, psi",
                    "value": this.toolForm.get('Collapse').value?this.toolForm.get('Collapse').value:""
                },
                {
                    "Id": toolColumns['Tension, ibf'],
                    "ColumnName": "Tension, ibf",
                    "value": this.toolForm.get('Tension').value?this.toolForm.get('Tension').value:""
                },
                {
                    "Id": toolColumns['Compression, ibf'],
                    "ColumnName": "Compression, ibf",
                    "value": this.toolForm.get('Compression').value?this.toolForm.get('Compression').value:""
                },
                {
                    "Id": toolColumns['Connection configuration'],
                    "ColumnName": "Connection configuration",
                    "value": this.toolForm.get('ConnectionConfiguration').value

                },
                {
                    "Id": toolColumns['TFA'],
                    "ColumnName": "TFA",
                    "value": this.toolForm.get('TFA').value?this.toolForm.get('TFA').value:0
                },
                {
                    "Id": toolColumns['Efficiency'],
                    "ColumnName": "Efficiency",
                    "value": this.toolForm.get('Efficiency').value?this.toolForm.get('Efficiency').value:""
                },
                {
                    "Id": toolColumns['Nozzles'],
                    "ColumnName": "Nozzles",
                    "value": this.toolForm.get('Nozzles').value
                },
                {
                    "Id": toolColumns['Thread type'],
                    "ColumnName": "Thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['MUT'],
                    "ColumnName": "MUT",
                    "value": this.toolForm.get('TopMUT').value
                },
                {
                    "Id": toolColumns['Bottom thread type'],
                    "ColumnName": "Bottom thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['Bottom MUT'],
                    "ColumnName": "Bottom MUT",
                    "value": this.toolForm.get('TopMUT').value
                },
                {
                    "Id": toolColumns['Body OD'],
                    "ColumnName": "Body OD",
                    "value": this.toolForm.get('BodyOD').value
                },
                {
                    "Id": toolColumns['Body ID'],
                    "ColumnName": "Body ID",
                    "value": this.toolForm.get('BodyID').value
                },
                {
                    "Id": toolColumns['Body length'],
                    "ColumnName": "Body length",
                    "value": this.toolForm.get('BodyLength').value
                }
                ]
          
           ,
            "nozzleSections": this.nozzleArrayList.map((item)=>{
                return  {
                    "Id": toolColumns['Nozzle Diameter, x 1/32'],
                    "ColumnName": "Nozzle Diameter, x 1/32",
                    "value": item
                }
            })
        
            }
        
        }

        return payload;
    }

    nozzleCheckboxChanged(event){
 // Do something with the event or checkbox state
    if (event) {
        //console.log("Checkbox is checked");
        this.toolForm.get('TFA').setValidators([Validators.required,Validators.min(1)]);
        this.toolForm.get('TFA').updateValueAndValidity();
    } else {
        //console.log("Checkbox is unchecked");
        this.toolForm.get('TFA').setValidators([Validators.min(1)]);
        this.toolForm.get('TFA').updateValueAndValidity();
    }
    this.toolForm.get('TFA').patchValue('');
    this.toolForm.get('Efficiency').patchValue('');
    this.toolForm.get('Nozzles').patchValue('');
    this.nozzleArrayList = [];
    this.nozzleArrayListError = [];
    }

    resetThreadtype(){
        if(this.updateData){
        let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
        if(connectionId)  
            this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
        this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['MUT']} )?.value);
        if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
        if(bottomconnectionId)  
            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT']} )?.value);
        this.toolForm.get('BodyOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body OD']} )?.value);
        this.toolForm.get('BodyID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body ID']} )?.value);
        this.toolForm.get('BodyLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body length']} )?.value);
    }
    }
    else{
        this.toolForm.get('TopThreadType').patchValue('');
        this.toolForm.get('TopMUT').patchValue('');
        this.toolForm.get('BottomThreadType').patchValue('');
        this.toolForm.get('BottomMUT').patchValue('');
        this.toolForm.get('BodyOD').patchValue('');
        this.toolForm.get('BodyID').patchValue('');
        this.toolForm.get('BodyLength').patchValue('');

    }
    }

    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value,
            toolType: this.toolForm.get("Type").value
        });
    }

     /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
        next: (res) => {
            if (res) {
                //console.log("res in casing---", res);
                let activeUnitSystemData = res;
                this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                this.lengthLabel = activeUnitSystemData.length.unitValue;
                this.massLabel = activeUnitSystemData.mass.unitValue;
                this.linearMassDensityLabel = activeUnitSystemData.linearMassDensity.unitValue;
                this.torqueLabel = activeUnitSystemData.torque.unitValue;
                this.percentageLabel = activeUnitSystemData.percentage.unitValue;
                this.forceLabel = activeUnitSystemData.force.unitValue;
                this.stressLabel = activeUnitSystemData.stress.unitValue;
                this.nozzleSizeLabel = activeUnitSystemData.nozzleSize.unitValue;
                this.rotationVelocityLabel = activeUnitSystemData.rotationVelocity.unitValue;
                this.angleLabel = activeUnitSystemData.angle.unitValue;
                this.pressureLabel=activeUnitSystemData.pressure.unitValue;
                this.flowLabel=activeUnitSystemData.flow.unitValue;
                // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

            } else {
                //console.log('error');
            }
        },
        error: (error) => {
            //console.log("Unit", error.error.result);
        }
    })
}
}
