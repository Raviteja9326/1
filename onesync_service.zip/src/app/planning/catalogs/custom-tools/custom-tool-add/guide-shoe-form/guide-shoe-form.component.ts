import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { toActive } from 'src/app/core/constants/ToolUnits.constant';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { DrillstringSectionTypes } from 'src/app/core/enum/workstrings/drillStringSectionTypes.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';
import { WorkstringService } from 'src/app/core/services/workstring.service';

@Component({
    selector: 'app-guide-shoe-form',
    templateUrl: './guide-shoe-form.component.html'
})
export class GuideShoeFormComponent implements OnInit, OnChanges {
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata;
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions: any = [];
    toolSizeList: any = [];
    toolWeightOptions: any = [];
    threadTypeOptions: any = [];
    materialOptions: any = [];
    sectionArrayList: any[] = [];
    sectionArrayErrorList: any[] = [];
    filteredToolSizeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredMaterialOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    sectionArrayMaterialDropdownControl: any[] = [];
    sectionArrayFilteredMaterialOptions: any = [];
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControlconn: FormControl = new FormControl();
    fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    connconfOptions: any = [
    ];
    shortLengthLabel: string = "";//(in or mm)
    lengthLabel: string = "";//(ft or m)
    massLabel: string = "";// (lbm or Kg)
    linearMassDensityLabel: string = "";// (lb/ft or kg/m)
    torqueLabel: string = "";// (lbf-ft or N-m)
    percentageLabel: string = "";//%
    forceLabel: string = "";//lbf or N
    stressLabel: string = "";//ksi or MPa
    activeUnitSystemData;
    originalTubularSections: any = [];
    MaxMUTTop: number;
    MUTTopVal: number;
    TensileStrengthVal: number;
    lengthError: string = "";
    mutError: string = "";
    TopThreadTypeChanged: boolean = false;
    mutValue;
    isMutCall: boolean = false;
    templateObj: any;
    tubularSections: any = [];
    forceUnitConvert={
        1:1000,
        2:4448.2216,

    }
    lengthPrecision: any;
    shortLengthPrecision:any
    massPrecision:any 
    linearMassDensityPrecision:any 
    torquePrecision:any 
    percentagePrecision:any 
    forcePrecision:any 
    stressPrecision:any 
        

    
    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService: ConnectionService,
        private toastR: ToastrService,
        private unitsService: UnitsService,
        private workStringService: WorkstringService,
    ) {


    }
    ngOnInit(): void {

    }
    ngOnChanges() {

        this.toolWeightOptions = [];
        for (const toolweightKey of Object.keys(ToolWeightOption)) {
            this.toolWeightOptions.push({ label: toolweightKey, value: parseInt(ToolWeightOption[toolweightKey]) });
        }
        this.connconfOptions = [];
        // for(const conconfKey of Object.keys(ConnectionConfiguration)){
        //     if(parseInt(ConnectionConfiguration[conconfKey])==6 || parseInt(ConnectionConfiguration[conconfKey])==5)
        //     this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
        // }
        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
            .valueChanges
            .subscribe({
                next: () => {
                    let filter = this.filterControl.value.toLowerCase();
                    let filteredList = this.toolWeightOptions.filter(
                        option => option.label.toLowerCase().indexOf(filter) >= 0
                    );
                    this.fileteredtoolWeightOptions.next(filteredList);
                }
            });

        this.fileteredconnconfOptions.next(this.connconfOptions);
        this.filterControlconn
            .valueChanges
            .subscribe({
                next: () => {
                    let filter = this.filterControlconn.value.toLowerCase();
                    let filteredList = this.connconfOptions.filter(
                        option => option.label.toLowerCase().indexOf(filter) >= 0
                    );
                    this.fileteredconnconfOptions.next(filteredList);
                }
            });




        this.toolForm = this.formBuilder.group({
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces,Validators.maxLength(99)]],
            Length: [''],
            ToolWeightOption: [0, [Validators.required]],
            Mass: ['', []],
            AdjustedWeight: ['', []],
            NW: ['', [Validators.required, Validators.min(0)]],
            Material: ['', [Validators.required]],
            // ConnectionConfiguration:['',[Validators.required]],
            TopThreadType: ['', [Validators.required]],
            TopMUT: ['', [Validators.required]],
            TopTensileCapacity: ['', [Validators.required]],
            TFA: [0, [Validators.required, CustomValidators.greaterThanZero]],
            Efficiency: [95, [Validators.min(0), Validators.max(100)]],
            Sections: [1, [Validators.required, Validators.min(1), Validators.max(2147483647)]]
        });

        this.toolForm.get("Description").patchValue('');
        this.toolForm.get("Description").updateValueAndValidity();
        this.toolForm.get('AdjustedWeight').disable();
        this.toolForm.get('Mass').disable();
        this.getActiveUnitSystemData()
            .then((res) => {
                if (res) {
                    //console.log("res in casing---", res);
                    this.activeUnitSystemData = res;
                    this.shortLengthLabel = this.activeUnitSystemData.shortLength.unitValue;
                    this.lengthLabel = this.activeUnitSystemData.length.unitValue;
                    this.massLabel = this.activeUnitSystemData.mass.unitValue;
                    this.linearMassDensityLabel = this.activeUnitSystemData.linearMassDensity.unitValue;
                    this.torqueLabel = this.activeUnitSystemData.torque.unitValue;
                    this.percentageLabel = this.activeUnitSystemData.percentage.unitValue;
                    this.forceLabel = this.activeUnitSystemData.force.unitValue;
                    this.stressLabel = this.activeUnitSystemData.stress.unitValue;

                    // dynamic precision
                    this.shortLengthPrecision = this.activeUnitSystemData.shortLength.precision;
                    this.lengthPrecision = this.activeUnitSystemData.length.precision;
                    this.massPrecision = this.activeUnitSystemData.mass.precision;
                    this.linearMassDensityPrecision = this.activeUnitSystemData.linearMassDensity.precision;
                    this.torquePrecision = this.activeUnitSystemData.torque.precision;
                    this.percentagePrecision = this.activeUnitSystemData.percentage.precision;
                    this.forcePrecision = this.activeUnitSystemData.force.precision;
                    this.stressPrecision = this.activeUnitSystemData.stress.precision;
                    // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

                }

                return this.getToolSizeDropdown()

            })
            .then((data) => {
                console.log("tool sizes", data.result);
                this.toolSizeOptions = [];
                this.toolSizeList = data.result;
                this.toolSizeList.map(item => {
                    this.toolSizeOptions.push({
                        label: item.NominalOD, value: item.ToolSizeId
                    });
                })

                this.filteredToolSizeOptions.next(this.toolSizeOptions);
                this.filterControltoolSize
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControltoolSize.value.toString().toLowerCase();
                            let filteredList = this.toolSizeOptions.filter(
                                option => option.toString().toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredToolSizeOptions.next(filteredList);
                        }
                    });
                var toolSizeIndex = this.toolSizeOptions.find(e => e.value == 4);
                this.toolForm.get("ToolSize").patchValue(toolSizeIndex.value)

                return this.getConnectionsDropdown();
            })
            .then((data) => {
                this.threadTypeOptions = [...data.result];
                this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
                this.filterControlTopThreadType
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControlTopThreadType.value.toLowerCase();
                            let filteredList = this.threadTypeOptions.filter(
                                option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredTopThreadTypeOptions.next(filteredList);
                        }
                    });
                    let threadTypeValue=this.threadTypeOptions.find(t=>t.ConnectionId==16);
                    this.toolForm.get("TopThreadType").patchValue(threadTypeValue.ConnectionId)
                //get materials
                return this.getMaterialsDropdown();
            })
            .then((data) => {
                this.materialOptions = [...data.result];
                this.filteredMaterialOptions.next(this.materialOptions);
                this.filterControlMaterials
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControlMaterials.value.toLowerCase();
                            let filteredList = this.materialOptions.filter(
                                option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredMaterialOptions.next(filteredList);
                        }
                    });

                this.toolForm.get("Material").patchValue(12);
                this.createSections(1);
                this.calculateMUT(this.toolForm.get("TopThreadType").value);
                this.getTensileStrength(this.toolForm.get("TopThreadType").value,this.toolForm.get("TopMUT").value);


                return new Promise((resolve) => { resolve("success") });

            })
            .then((data) => {
                //console.log("received data in bit form",this.updateData);
                if (this.updateData) {
                    //set values in form
                    let toolsize = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool Size, in'] })?.value;
                    if (toolsize)
                        this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                    this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                    this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Length, ft'] })?.value);
                    let toolweightoption = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool weight option'] })?.value;
                    this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));

                    if (this.toolForm.get('ToolWeightOption').value == 0) {
                        this.toolForm.get('AdjustedWeight').disable();
                        this.toolForm.get('Mass').disable();
                    }
                    else if (this.toolForm.get('ToolWeightOption').value == 1) {
                        this.toolForm.get('AdjustedWeight').enable();
                        this.toolForm.get('Mass').disable();
                    }
                    else if (this.toolForm.get('ToolWeightOption').value == 2) {
                        this.toolForm.get('AdjustedWeight').disable();
                        this.toolForm.get('Mass').enable();
                    }


                    this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Mass, lbm'] })?.value);
                    this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Adjusted weigth, lb/ft'] })?.value);
                    this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['NW lb/ft'] })?.value);
                    let materialId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Material'] })?.value
                    if (materialId)
                        this.toolForm.get('Material').patchValue(parseInt(materialId));

                    let connConfId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Connection configuration'] })?.value;
                    // if(connConfId)
                    //     this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(connConfId));
                    this.toolForm.get('TFA').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['TFA'] })?.value);
                    this.toolForm.get('Efficiency').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Efficiency'] })?.value);

                    let connectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Thread type'] })?.value
                    if (connectionId)
                        this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
                    this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['MUT'] })?.value);
                    this.toolForm.get('TopTensileCapacity').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tensible capacity'] })?.value);
                    this.toolForm.get('Sections').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Sections'] })?.value);
                    //section array
                    this.sectionArrayMaterialDropdownControl = Array.from({ length: this.updateData?.toolSections?.length }, (_, index) => {
                        return new FormControl();
                    });

                    this.sectionArrayFilteredMaterialOptions = Array.from({ length: this.updateData?.toolSections?.length }, (_, index) => {
                        return new ReplaySubject<any[]>(1);
                    });

                    this.sectionArrayFilteredMaterialOptions.forEach((element, i) => {
                        this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
                        this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                            next: () => {
                                this.loadSectionMaterialOptions(i)
                            }
                        });
                    });

                    this.sectionArrayFilteredMaterialOptions.forEach((element, i) => {
                        this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
                        this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                            next: () => {
                                this.loadSectionMaterialOptions(i)
                            }
                        });
                    });
                    this.sectionArrayList = this.updateData.toolSections.map((item, index) => {
                        return {
                            'OuterDiameter': item.find((col) => { return col.Id === toolColumns['OD, in'] })?.value,
                            'InnerDiameter': item.find((col) => { return col.Id === toolColumns['ID, in'] })?.value,
                            'Length': item.find((col) => { return col.Id === toolColumns['section length, ft'] })?.value,
                            'Material': item.find((col) => { return col.Id === toolColumns['Section material'] })?.value,
                            'Caption': item.find((col) => { return col.Id === toolColumns['Caption'] })?.value,
                            'NW': item.find((col) => { return col.Id === toolColumns['NW, lb/ft'] })?.value,
                            'MaxContactForce': item.find((col) => { return col.Id === toolColumns['Max contact force'] })?.value,
                            'MaxVonMisesStress': item.find((col) => { return col.Id === toolColumns['max von misses stress'] })?.value
                        }
                    });
                    this.sectionArrayErrorList = Array.from({ length: this.sectionArrayList.length }, (_, index) => {
                        return {
                            'OuterDiameter': '', 'InnerDiameter': '',
                            'Length': '', 'Material': '',
                            'Caption': '', 'NW': '',
                            'MaxContactForce': '',
                            'MaxVonMisesStress': ''
                        }
                    });

                }
                else {
                    // this.onchangeToolWeight();

                }
                this.emitData();
            });
    }

    async getMaterialsDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.materialService.getMaterialsList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching materials");
        }
        return data;
    }//end of functions

    /*
   ** get active unit from active unit system and integration with labels, placeholders and headers
   */
    async getActiveUnitSystemData() {

        // this.unitSystemData = {};
        let data;

        data = await lastValueFrom(this.unitsService.getActiveUnitSystemDetails());
        return data;
    }

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions

    async getConnectionsDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.connectionService.getConnectionList(false,'workString'));
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight() {
        let resultLength = this.sectionArrayErrorList.reduce((acc, curr) => {
            return Number(acc) + Number(curr.Length);
        }, 0);
        if (this.toolForm.get('ToolWeightOption').value == 0) {
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            this.CalculateSectionMass();

        }
        else if (this.toolForm.get('ToolWeightOption').value == 1) {
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
        }
        else if (this.toolForm.get('ToolWeightOption').value == 2) {
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
        }
    }
    recalculateTotalLength() {
        let result = this.GetToolLengthBySections(this.originalTubularSections);
        this.toolForm.get("Length").patchValue(result);
        if (this.toolForm.get("ToolWeightOption").value == parseInt(ToolWeightOption['Calculated'])) {
            this.reCalculateFields()
        }
        else if (this.toolForm.get("ToolWeightOption").value == parseInt(ToolWeightOption['User Defined Adjusted Weight'])) {
            this.calculateMass();
        }
        else if (this.toolForm.get("ToolWeightOption").value == parseInt(ToolWeightOption['User Defined Mass'])) {
            this.RecalculateTotalAdjustedWeight(this.toolForm.get("Mass").value,result);
        }
    }

    // to set Mass only when we select User defined mass in tool weight option
    calculateMass(userDefined?) {
        let lengthResult = this.originalTubularSections.reduce((acc, curr) => {
            return Number(acc) + Number(curr.Length);
          }, 0);
        let massResult=0;
        if (Number(this.toolForm.get('AdjustedWeight').value) > 0 && Number(this.toolForm.get('Length').value) > 0) {
        let adjustedWeightVal=Number(this.toolForm.get('AdjustedWeight').value)/toActive['linearMassDensity'][this.activeUnitSystemData.linearMassDensity.unitName];
          let length = Number(lengthResult)/toActive['length'][this.activeUnitSystemData.length.unitName];
            massResult = (Number(adjustedWeightVal*Number(length.toFixed(Number(this.lengthPrecision))))*toActive['mass'][this.activeUnitSystemData.mass.unitName]);
            this.toolForm.get("Mass").patchValue(massResult);
        }
        if(userDefined){
            this.CalculateSectionMass(Number(massResult));
        }
    }


    //create sections  
    createSections(numOfSections) {
        this.tubularSections = [];
        this.tubularSections.push({
            SectionType: DrillstringSectionTypes["Body"],
            Caption: 'Body',
            Order: 1,
            Location: 1,
            OuterDiameter: this.toolSizeOptions.find(item => item.value == this.toolForm.get("ToolSize").value)?.label,
            InnerDiameter: ((Number(this.toolSizeOptions.find(item => item.value == this.toolForm.get("ToolSize").value)?.label)/(toActive['shortLength'][this.activeUnitSystemData.shortLength.unitName])) - 1)*(toActive['shortLength'][this.activeUnitSystemData.shortLength.unitName]),
            Material: this.toolForm.get("Material").value,
            MaxContactForce: (2*(this.forceUnitConvert[this.activeUnitSystemData.force.unitName])),
            MaxVonMisesStress: Number(16*(toActive['stress'][this.activeUnitSystemData.stress.unitName])),
            Length: (1*(toActive['length'][this.activeUnitSystemData.length.unitName])),
           
        });
        if(numOfSections>1){
            this.tubularSections[0].Length="";
        }
        if (numOfSections > this.sectionArrayList.length) {
            for (var i = 0; i <= (numOfSections - this.sectionArrayList.length); i++) {
                this.tubularSections[0].Order=(this.sectionArrayList.length+1)
                let mass=this.SetSectionsMass(this.tubularSections);
                this.SetSectionsNW(this.tubularSections);
                this.sectionArrayList.push({...this.tubularSections[0]});
                
                console.log("sectionArrayList[j]['OD']---",this.sectionArrayList[i]['OuterDiameter']);
            }
        }
        else if (numOfSections < this.sectionArrayList.length) {
            for (var i = 0; i <= (this.sectionArrayList.length - numOfSections); i++) {
                this.sectionArrayList.pop();
            }
        }
        else if (numOfSections == this.sectionArrayList) {

        }
        this.sectionArrayList.sort((d1, d2) => {
            return d2.Order - d1.Order;
        })
        this.originalTubularSections=JSON.parse(JSON.stringify(this.sectionArrayList));
        this.setSectionArray();
        this.SetDSComponentProperties(this.originalTubularSections);
        let ComponentMass = this.GetToolMassBySections(this.originalTubularSections);
        this.RecalculateTotalAdjustedWeight(ComponentMass,this.GetToolLengthBySections(this.originalTubularSections));
        

            this.sectionArrayErrorList = Array.from({ length: this.sectionArrayList.length }, (_, index) => {
                return {
                    'OuterDiameter': '', 'InnerDiameter': '',
                    'Length': '', 'Material': '',
                    'Caption': '', 'NW': '',
                    'MaxContactForce': '',
                    'MaxVonMisesStress': ''
                }
            });
            
        this.sectionArrayMaterialDropdownControl = Array.from({ length: numOfSections }, (_, index) => {
            return new FormControl();
        });

        this.sectionArrayFilteredMaterialOptions = Array.from({ length: numOfSections }, (_, index) => {
            return new ReplaySubject<any[]>(1);
        });

        this.sectionArrayFilteredMaterialOptions.forEach((element, i) => {
            this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
            this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                next: () => {
                    this.loadSectionMaterialOptions(i)
                }
            });
        });
    }

    loadSectionMaterialOptions(index: number) {

        // Load options into the filteredOptions array for the selected dropdown

        let filter = this.sectionArrayMaterialDropdownControl[index].value.toLowerCase();
        let filteredList = this.materialOptions.filter(
            option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
        );
        this.sectionArrayFilteredMaterialOptions[index].next(filteredList);
    }
    resetThreadtype() {
        if (this.updateData) {
            let connectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Thread type'] })?.value
            if (connectionId)
                this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
            this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['MUT'] })?.value);

        }
        else {
            // when we reset thread type it will reset a default value and it is calculate MUT and tensile capacity again
            this.toolForm.get('TopThreadType').patchValue(16);
            this.calculateMUT(this.toolForm.get('TopThreadType').value);
            this.getTensileStrength(this.toolForm.get("TopThreadType").value,this.toolForm.get("TopMUT").value);

        }
    }



    validateSectionsID(value, i) {

        if (Number(value) || Number(value) == 0) {
            if (Number(value) <= 0 || Number(value) >= Number(this.sectionArrayList[i]['OuterDiameter'])) {
                this.sectionArrayErrorList[i]['InnerDiameter'] = "Inner Diameter Must be Less Than Outer Diameter";
            }
            else {
                this.sectionArrayErrorList[i]['InnerDiameter'] = "";
            }
        }
        else {
            this.sectionArrayErrorList[i]['InnerDiameter'] = "Inner Diameter Must be Less Than Outer Diameter";
        }
        this.originalTubularSections[i]['InnerDiameter']=value; 
    }

    validateSectionsOD(value, i) {

        if (Number(value) || Number(value) == 0) {
            if (Number(value) <= 0) {
                this.sectionArrayErrorList[i]['OuterDiameter'] = "Outer Diameter Must be Greater Than 0";
            }
            else {
                this.sectionArrayErrorList[i]['OuterDiameter'] = "";
            }
        }
        else {
            this.sectionArrayErrorList[i]['OuterDiameter'] = "Outer Diameter is Required!";
        }
        this.validateSectionsID(this.sectionArrayList[i]['InnerDiameter'], i);
        

    }

    // userdefined when we change OD
    onChangeSectionOD(value,i){
        this.originalTubularSections[i]['OuterDiameter']=value;
        this.sectionArrayList[i]['OuterDiameter']=value;
        if(this.toolForm.get("ToolWeightOption").value==parseInt(ToolWeightOption['Calculated'])){
            this.reCalculateFields();
        }
    }

    // userdefined when we change ID
    onChangeSectionID(value,i){
        this.originalTubularSections[i]['InnerDiameter']=value;
        this.sectionArrayList[i]['InnerDiameter']=value;
        if(this.toolForm.get("ToolWeightOption").value==parseInt(ToolWeightOption['Calculated'])){
            this.reCalculateFields();
        }
    }

    validateSectionsLength(value, i) {
        
        if (value!=0 && (value=="" || value==undefined || value==null || isNaN(value))) {
            this.sectionArrayErrorList[i]['Length'] = "Length is Required!";
        }
        else {
            this.sectionArrayErrorList[i]['Length'] = "";
        }
        this.originalTubularSections[i]['Length']=value;
        this.sectionArrayList[i]['Length']=value
        
       
       
    }

    onChangeSectionLength(value,i){
            var lengthVal=this.GetToolLengthBySections(this.originalTubularSections)
            this.toolForm.get("Length").patchValue(lengthVal);
            this.recalculateTotalLength();

    }

    validateSectionsCaption(value, i) {
        if (value) {
            this.sectionArrayErrorList[i]['Caption'] = "";
        }
        else {
            this.sectionArrayErrorList[i]['Caption'] = "Caption is Required!";
        }
        this.originalTubularSections[i]['Caption']=value;
    }
    validateSectionsMaterial(value, i,userDefined?) {

        if (value) {
            this.sectionArrayErrorList[i]['Material'] = "";
        }
        else {
            this.sectionArrayErrorList[i]['Material'] = "Material is Required!";
        }
        this.originalTubularSections[i]['Material']=value;
        if(userDefined){
            this.reCalculateFields();
        }
    }
    validateSectionsForce(value, i) {
        if (value || value == 0) {
            this.sectionArrayErrorList[i]['MaxContactForce'] = "";
        }
        else {
            this.sectionArrayErrorList[i]['MaxContactForce'] = "Max Contact Force is Required!";
        }
        this.originalTubularSections[i]['MaxContactForce']=value;
    }
    validateSectionsStress(value, i) {
        if (value || value == 0) {
            this.sectionArrayErrorList[i]['MaxVonMisesStress'] = "";
        }
        else {
            this.sectionArrayErrorList[i]['MaxVonMisesStress'] = "Max Von Mises Stress is Required!";
        }
        this.originalTubularSections[i]['MaxVonMisesStress']=value;
    }

    save() {
        
        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());

        }

        this.sectionArrayList.forEach((element, i) => {
            this.validateSectionsOD(element.OuterDiameter, i);
            this.validateSectionsID(element.InnerDiameter, i);
            this.validateSectionsCaption(element.Caption, i);
            this.validateSectionsLength(element.Length, i);
            this.validateSectionsMaterial(element.Material, i);
            this.validateSectionsForce(element.MaxContactForce, i);
            this.validateSectionsStress(element.MaxVonMisesStress, i);
        });
        //console.log(this.toolForm.valid,this.sectionArrayErrorList);
        let sectionFlag = true;

        this.sectionArrayErrorList.forEach((item) => {
            if (item.OuterDiameter || item.InnerDiameter || item.Caption || item.Length || item.Material || item.MaxContactForce || item.MaxVonMisesStress) {
                sectionFlag = false;
            }
        });

        //console.log("validity flags",this.toolForm.valid);
        //call api below if all the flags are true

        if (this.toolForm.valid && sectionFlag) {
            let payload = this.createPayload();
            if (this.updateData) {
                this.customToolService.updateCustomTool(this.templateId, payload).subscribe({
                    next: (data) => {
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error: (error) => {
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else {
                this.customToolService.addCustomTool(payload).subscribe({
                    next: (data) => {
                        //console.log(data);
                        this.toastR.success("Custom Tool added successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error: (error) => {
                        this.toastR.error("Something went wrong");
                    }
                });
            }

        }
    }

    onChangeSectionNWInputs(rowIndex) {
        let density;
        //console.log("density",density);

        density = this.getDensity(this.sectionArrayList[rowIndex]['Material']);
        this.sectionArrayList[rowIndex]['NW'] = this.calculateNominalWeight(density, this.sectionArrayList[rowIndex]['OuterDiameter'],
        this.sectionArrayList[rowIndex]['InnerDiameter'], this.sectionArrayList[rowIndex]['Length']);
        this.SetDSComponentProperties(this.originalTubularSections);

    }

    calculateNominalWeight(density, OD, ID, length) {
        if (density && OD && ID && length) {
            var mass = Math.PI * density * (OD * OD - ID * ID) / 77;
            let result;
            if (length > 0) {
                result = mass / length;
            }
            else {
                result = 0;
            }
            return parseFloat(result.toFixed(2));
        }
        return 0;
    }

    getDensity(id) {
        let density = this.materialOptions.find((item) => { return item.MaterialId == id })?.Density;
        return density;
    }

    cancel() {
        this.formSubmitEvent.emit("cancel");
    }

    createPayload() {

        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.toolForm.get('ToolSize').value,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem"),
                    "toolId": Number(this.Tool),
                },
                "toolValues": [
                    {
                        "Id": toolColumns['Length, ft'],
                        "ColumnName": "Length, ft",
                        "value": this.toolForm.get("Length").value
                    },
                    {
                        "Id": toolColumns['Tool weight option'],
                        "ColumnName": "Tool weight option",
                        "value": this.toolForm.get("ToolWeightOption").value
                    },
                    {
                        "Id": toolColumns['Tool Size, in'],
                        "ColumnName": "Tool Size, in",
                        "value": this.toolForm.get("ToolSize").value
                    },
                    {
                        "Id": toolColumns['Mass, lbm'],
                        "ColumnName": "Mass, lbm",
                        "value": this.toolForm.get('Mass').value
                    },
                    {
                        "Id": toolColumns['Adjusted weigth, lb/ft'],
                        "ColumnName": "Adjusted weigth, lb/ft",
                        "value": this.toolForm.get('AdjustedWeight').value
                    },
                    {
                        "Id": toolColumns['NW lb/ft'],
                        "ColumnName": "NW lb/ft",
                        "value": this.toolForm.get('NW').value
                    },
                    {
                        "Id": toolColumns['Material'],
                        "ColumnName": "Material",
                        "value": this.toolForm.get('Material').value
                    },
                    {
                        "Id": toolColumns['TFA'],
                        "ColumnName": "TFA",
                        "value": this.toolForm.get('TFA').value ? this.toolForm.get('TFA').value : 0
                    },
                    {
                        "Id": toolColumns['Efficiency'],
                        "ColumnName": "Efficiency",
                        "value": this.toolForm.get('Efficiency').value ? this.toolForm.get('Efficiency').value : ""
                    },
                    // {
                    //     "Id": toolColumns['Connection configuration'],
                    //     "ColumnName": "Connection configuration",
                    //     "value": this.toolForm.get('ConnectionConfiguration').value

                    // },
                    {
                        "Id": toolColumns['Thread type'],
                        "ColumnName": "Thread type",
                        "value": this.toolForm.get('TopThreadType').value
                    },
                    {
                        "Id": toolColumns['MUT'],
                        "ColumnName": "MUT",
                        "value": this.toolForm.get('TopMUT').value
                    },
                    {
                        "Id": toolColumns['Tensible capacity'],
                        "ColumnName": "Tensible capacity",
                        "value": this.toolForm.get('TopTensileCapacity').value
                    },
                    {
                        "Id": toolColumns['Sections'],
                        "ColumnName": "Sections",
                        "value": this.toolForm.get('Sections').value
                    }
                ],
                "toolSections": this.sectionArrayList.map((item, index) => {
                    return {
                        [index]: [
                            {
                                "Id": toolColumns['OD, in'],
                                "ColumnName": "OD, in",
                                "value": item['OuterDiameter']
                            },
                            {
                                "Id": toolColumns['ID, in'],
                                "ColumnName": "ID, in",
                                "value": item['InnerDiameter']
                            },
                            {
                                "Id": toolColumns['section length, ft'],
                                "ColumnName": "section length, ft",
                                "value": item['Length']
                            },
                            {
                                "Id": toolColumns['Section material'],
                                "ColumnName": "Section material",
                                "value": item['Material']
                            },
                            {
                                "Id": toolColumns['Caption'],
                                "ColumnName": "Caption",
                                "value": item['Caption']
                            },
                            {
                                "Id": toolColumns['NW, lb/ft'],
                                "ColumnName": "NW, lb/ft",
                                "value": item['NW']
                            },
                            {
                                "Id": toolColumns['Max contact force'],
                                "ColumnName": "Max contact force",
                                "value": item['MaxContactForce']
                            },
                            {
                                "Id": toolColumns['max von misses stress'],
                                "ColumnName": "max von misses stress",
                                "value": item['MaxVonMisesStress']
                            },
                        ]
                    }
                })


            }

        }

        return payload;
    }

    emitData() {
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value
        });
    }



    /*
  ** get length field calculated by section length sum
  */
    GetToolLengthBySections(tubular) {
        let length;
        if (tubular != null && tubular)
            length = tubular.reduce((acc, currentVal) => {
                return Number(acc) + Number(currentVal.Length);
            }, 0)
        return length;

    }


    // to calculate Dimensional data Mass value
    SetSectionsMass(tubular) {
        if (tubular != null && tubular) {
            tubular.map((section) => {
                
                let materialValue = (this.getDensity(Number(section.Material)));
                
                if (materialValue != null && Number(section.OuterDiameter) && Number(section.InnerDiameter)) {
                    section.NW = this.workStringService.calculateLinearMassDensity(Number(section.OuterDiameter), Number(section.InnerDiameter), materialValue, this.activeUnitSystemData);
                } else {
                    section.NW = 0;
                }
                // section.Mass = (section.NominalWeight/this.sectionMassUnit[this.activeUnitSystemData.linearMassDensity.unitName]) * section.Length;
                section.Mass = Number(section.NW) * Number(section.Length);
            })

        }
    }

    //set NW in Directional data
    SetSectionsNW(tubular) {
        var NWSectionValue = tubular;
        if (tubular != null && tubular) {
            NWSectionValue.map((section) => {
                if ((Number(section.Length)) <= 0) {
                    section.NW = 0;
                } else {
                    var mass = Number(section.Mass);
                    var stabilizer = this.GetStabilizerAtLocation(tubular, section);
                    if (stabilizer != null)
                        mass += (stabilizer.Mass ?? 0);


                    section.NW = Number(mass) / Number(section.Length);
                }
            })
        }
        (console.log("NWSectionValue----", NWSectionValue, this.originalTubularSections))

    }

    //stablizer function to check location in NW
    GetStabilizerAtLocation(tubular, location) {
        // var stabilizer = null as TubularStabilizer;
        var stabilizer = null;
        // if (tubular.Stabilizers != null)
        //     stabilizer = tubular.Stabilizers.FirstOrDefault(s => s.Location == location);

        return stabilizer;
    }

    // Sum of  mass of all tubular sections to get Total mass
    GetToolMassBySections(tubular) {
        let mass = 0;
        // Sum of  mass of all tubular sections to get Total mass
        mass = tubular.reduce((acc, currentVal) => {
            return (Number(acc) + Number(currentVal.Mass));
        }, 0)
        return mass;
    }

    // Sum of  ID of all tubular sections to get Total ID
    GetToolIDBySections(tubular) {
        let ID = 0;
        if (tubular)
            // ID = tubular.Where(s => s.InnerDiameter).Min(s => s.InnerDiameter.Value);
            ID = Math.min(...this.tubularSections.map(item => Number(item.InnerDiameter))); // to be send it from front end

        return ID;
    }

    // calculate Adjusted weight value
    RecalculateTotalAdjustedWeight(mass, length?,userDefined?) {
        // mass = this.setPrevMass();
        if(Number(this.toolForm.get('Mass').value)>0){
            if(!length && !userDefined)
                length=this.GetToolLengthBySections(this.originalTubularSections);
            else
                length = this.toolForm.get('Length').value;
            if (Number(mass) > 0) {
                mass = Number(mass)/toActive['mass'][this.activeUnitSystemData.mass.unitName]; //unit conversion 
                length = (Number(length)/toActive['length'][this.activeUnitSystemData.length.unitName]).toFixed(this.lengthPrecision); //unit conversion
                let calculateAWVal = (Number(length) != 0 ? ((Number(mass) / Number(length))) : 0.00);
                calculateAWVal = toActive['linearMassDensity'][this.activeUnitSystemData.linearMassDensity.unitName]*Number(calculateAWVal)
                this.toolForm.get('AdjustedWeight').patchValue(calculateAWVal);
            }
        }
        if(userDefined){
            this.CalculateSectionMass();
        }
    
    }

    //---------------------------------------------------------------NW--------------------------------------------------------
    /*Nominal Weight is calculated as per logic
                    tubular.NominalWeight = tubular.Length == 0 ? 0 : tubular.ComponentMass.Value / tubular.Length;
    */
    SetDSComponentProperties(tubular) {
        let Length = this.GetToolLengthBySections(tubular);
        this.toolForm.get("Length").patchValue(Length);
        let InnerDiameter = this.GetToolIDBySections(tubular);
        let ComponentMass = this.GetToolMassBySections(tubular);
        this.toolForm.get("Mass").patchValue(ComponentMass);
        if (Length>0 && ComponentMass>0){
            ComponentMass = Number(ComponentMass)/toActive['mass'][this.activeUnitSystemData.mass.unitName]; //unit conversion 
            Length = (Number(Length)/toActive['length'][this.activeUnitSystemData.length.unitName]).toFixed(this.lengthPrecision); //unit conversion
            let NominalWeight = Number(Length) == 0 ? 0 : Number(ComponentMass) / Number(Length);
            NominalWeight=Number(NominalWeight)*toActive['linearMassDensity'][this.activeUnitSystemData.linearMassDensity.unitName];
            this.toolForm.get("NW").patchValue(NominalWeight);
        }
           
        this.SetOuterDiameter();
    }

    // to calculate outer diameter
    SetOuterDiameter() {
        let OuterDiameter = 0;
        let MaxOuterDiameter=0;
        var toolSize = this.toolForm.get("ToolSize").value;
        let toolSizeValue=this.toolSizeList.find(t=>t.ToolSizeId=Number(toolSize))
        if (toolSizeValue != null) {
            switch (toolSizeValue.ToolSizeType) {
                case 1:
                    OuterDiameter = toolSizeValue.ToolSizeTo;
                    break;
                default:
                    OuterDiameter = toolSizeValue.NominalOD;
                    break;
            }
        }
        if (OuterDiameter == 0)
            OuterDiameter = MaxOuterDiameter ?? 0;
        // this.toolForm.get("")

    }

    // to set the precision to value
    setPrecision(num, precision) {
        return Number(num ?? 0).toFixed(precision);
    }

    // To calculate MUT of Top thread type
    calculateMUT(connId) {
        let connData = this.threadTypeOptions.find((d) => { return d.ConnectionId == connId });

        console.log("threadTypeOptions", connData);
        if (connData.isConnectionData) {
            var Ym = 120000.1269343;
            var YmJoint = 120000.1269343;
            this.mutValue = this.toolForm.get("TopMUT").value;

            this.mutValue = this.workStringService.calculateMakeUpTorque(connData, Number(this.originalTubularSections.find(d => d.Order == 1)?.OuterDiameter), Number(this.originalTubularSections.find(d => d.Order == 1)?.InnerDiameter), Ym, YmJoint, this.activeUnitSystemData);


            console.log("mut value after calculate:", this.mutValue);
            this.MaxMUTTop = this.workStringService.calculateTorsionalStrength(connData, Number(this.originalTubularSections.find(d => d.Order == 1)?.OuterDiameter), Number(this.originalTubularSections.find(d => d.Order == 1)?.InnerDiameter), Ym, YmJoint, this.activeUnitSystemData);

            // if(this.MaxMUTTop<0)
            //     this.toolForm.get("TopMUT").setValidators([Validators.required, Validators.min(0)]);
            // else if(this.MaxMUTTop>=0){
            this.toolForm.get("TopMUT").setValidators([Validators.required, Validators.min(0), Validators.max(Number(this.MaxMUTTop.toFixed(this.torquePrecision)))]);
            this.toolForm.get("TopMUT").updateValueAndValidity();
            // }

            // MUT range error message
            this.mutError = "Value For MUT Must be Between 0 And " + this.MaxMUTTop.toFixed(this.torquePrecision) + " " + this.torqueLabel + ".";
           
                this.toolForm.get("TopMUT").patchValue(this.mutValue);
        }
        else {
            this.toolForm.get("TopMUT").patchValue(this.templateObj.Makeuptorque);

            if (this.TopThreadTypeChanged) {
                this.toolForm.get("TopMUT").patchValue("");
                this.toolForm.get("TopMUT").setValidators([Validators.min(0), Validators.max(0)]);
            }
            else {
                this.toolForm.get("TopMUT").setValidators([Validators.required, Validators.min(0), Validators.max(0)]);
            }
            this.MaxMUTTop = 0;

            this.toolForm.get("TopMUT").updateValueAndValidity();
        }
        return
    }

    // get tensile capacity using MUT first
    getTensileStrength(connId, mutVal) {

        let mut = this.toolForm.get("TopMUT").value;
        if (mut == null)
            this.toolForm.get("TopTensileCapacity").patchValue("");

        var connData = this.threadTypeOptions.find((d) => { return d.ConnectionId == connId });

        if (connData != null && connData.isConnectionData) {

            var Ym = 120000.1269343;
            var YmJoint = 120000.1269343;
            if (!mutVal) {
                mut = this.mutValue;
            }

            // var ts = this.workStringService.calculateTensileStrength(connData, Number(this.originalTubularSections.find(d=>d.Order==1)?.OuterDiameter), Number(this.originalTubularSections.find(d=>d.Order==1)?.InnerDiameter), mut, Ym, YmJoint);
            var ts = this.workStringService.calculateTensileStrength(connData, Number(this.originalTubularSections.find(d => d.Order == 1)?.OuterDiameter), Number(this.originalTubularSections.find(d => d.Order == 1)?.InnerDiameter), mut, Ym, YmJoint, this.activeUnitSystemData);
            console.log("TopTensileCapacity", ts);
            this.toolForm.get("TopTensileCapacity").patchValue(ts);
            this.toolForm.get("TopTensileCapacity").addValidators(Validators.required);
            //}
        }
        else {
            this.toolForm.get("TopTensileCapacity").patchValue("");
            this.toolForm.get("TopTensileCapacity").removeValidators(Validators.required);
            this.toolForm.get("TopTensileCapacity").updateValueAndValidity();
        }
    }

    //to calculate MUT and tesile strength when we change top connection type
    onChangeTopThreadType(event) {
        this.TopThreadTypeChanged = true;
        this.MaxMUTTop = 0;
        this.MUTTopVal = 0;
        this.toolForm.get("TopMUT").patchValue(this.MUTTopVal);
        this.TensileStrengthVal = 0;
        if (this.MUTTopVal == null || this.MUTTopVal == 0) {
            this.calculateMUT(event.value);
        }
        if (this.TensileStrengthVal == null || this.TensileStrengthVal == 0) {
            this.isMutCall = false;
            this.getTensileStrength(event.value, this.isMutCall);
        }
    }

    //When changing MUT calculate Tensile capacity
    onChangeMUT() {
        let connValue = this.toolForm.get("TopThreadType").value;
        this.isMutCall = true;
        if (connValue) {
            this.getTensileStrength(connValue, this.isMutCall);
        }
    }

    //When changing Tool Size the Mass, Adjusted weight and section OD is changed
    onToolSizeDataChange(event){
        // set OD in sections
        this.originalTubularSections.map((e, i) => {
            e.OuterDiameter = this.toolSizeOptions.find(item => item.value == this.toolForm.get("ToolSize").value)?.label
            let mass=this.SetSectionsMass(this.originalTubularSections);
            this.SetSectionsNW(this.originalTubularSections);
        })
        //  when we change tool size it will change tool weight option to calculated
        this.toolForm.get('ToolWeightOption').patchValue(0);
        this.toolForm.get('AdjustedWeight').disable();
        this.toolForm.get('Mass').disable();
        // Calculate Mass of sections
        this.SetDSComponentProperties(this.originalTubularSections);
        // calculate componant mass
        let ComponentMass = this.GetToolMassBySections(this.originalTubularSections);
        // recalculateing Adjusted weight using Mass and length
        this.RecalculateTotalAdjustedWeight(ComponentMass,this.GetToolLengthBySections(this.originalTubularSections));
        // this.originalTubularSections=JSON.parse(JSON.stringify(this.sectionArrayList));
        this.setSectionArray();
    }


    // when we change Mass and AW it will calculate Mass and NW in dimensional data
    CalculateSectionMass(mass?)
    {
        var massValue=mass;
        if(!mass){
            massValue=Number(this.toolForm.get("Mass").value);
        }
        
        var adjustedWvalue=Number(this.toolForm.get("AdjustedWeight").value);
        let massResult;
        if(massValue<=0&&adjustedWvalue<=0){
            this.SetSectionsMass(this.originalTubularSections);
            this.SetSectionsNW(this.originalTubularSections);
        }else{
            let tubularSectionValue=this.workStringService.CalculateSectionMass([...this.originalTubularSections],this.materialOptions, Number(this.toolForm.get("Mass").value),true,this.activeUnitSystemData)       
            this.SetSectionsNW(tubularSectionValue);
            this.originalTubularSections=JSON.parse(JSON.stringify(tubularSectionValue));
        }
        this.SetDSComponentProperties(this.originalTubularSections);
        this.setSectionArray();
    }


    // to recalculate multiple fields when we change length, mass, adjusted weight values it will change section mass, and section nw
    reCalculateFields(){
        this.SetSectionsMass(this.originalTubularSections);
        this.SetSectionsNW(this.originalTubularSections);
        this.SetDSComponentProperties(this.originalTubularSections);
        let ComponentMass = this.GetToolMassBySections(this.originalTubularSections);
        this.RecalculateTotalAdjustedWeight(ComponentMass);
        this.setSectionArray();
    }

    setSectionArray(){
        this.sectionArrayList.map((e, i) => {
            e.OuterDiameter = this.originalTubularSections[i].OuterDiameter
            e.InnerDiameter = this.originalTubularSections[i].InnerDiameter
            e.Length = this.originalTubularSections[i].Length
            e.Mass =this.originalTubularSections[i].Mass
            e.Material=this.originalTubularSections[i].Material
            e.NW =this.originalTubularSections[i].NW
            e.MaxContactForce=this.originalTubularSections[i].MaxContactForce
            e.MaxVonMisesStress=this.originalTubularSections[i].MaxVonMisesStress
          })
    }

    // when we change material in of top side it will change material of all sections
    onChangeMaterial(event){
        // let materialValue=this.materialOptions.find((item) => { return item.MaterialId == Number(event) });
        this.originalTubularSections.map(e=>{
            e.Material=Number(event)
        })
        this.reCalculateFields();

    }
}
