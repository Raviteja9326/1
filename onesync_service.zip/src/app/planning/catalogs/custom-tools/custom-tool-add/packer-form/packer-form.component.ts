import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import * as _ from 'lodash';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { errorMessages } from 'src/app/core/constants/errorMessages.constant';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { DCVType } from 'src/app/core/enum/custom-tools/dcvType.enum';
import { FishingType } from 'src/app/core/enum/custom-tools/fishingType.enum';
import { PackerToolConfiguration } from 'src/app/core/enum/custom-tools/packerConf';
import { PackerType } from 'src/app/core/enum/custom-tools/packerType';
import { SettingType } from 'src/app/core/enum/custom-tools/settingType';
import { ToolConfiguration } from 'src/app/core/enum/custom-tools/toolConfigurations.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-packer-form',
  templateUrl: './packer-form.component.html'
})
export class PackerFormComponent implements OnInit,OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [];
    toolWeightOptions:any = [];
    threadTypeOptions: any = [];
    materialOptions:any = [];
 
    typeOptions: any = [
    ];
    connconfOptions: any = [
    ];
    settingtypeOptions: any = [];
    toolConfOptions: any = [];
    isNozzleDisabled:boolean = true;
    show: any = {
        Body:false,
        BasketGauge:false,
        GaugeBody:false,
        Gauge:false,
        StopSub:false,
        BottomSub:false,
        Grapple:false,
        Fishneck:false,
        Spear:false
    };
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredBottomThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlBottomThreadType: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControltype: FormControl = new FormControl();
    fileteredtypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolConf: FormControl = new FormControl();
    fileteredtoolConfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlconn: FormControl = new FormControl();
    fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlSettingType: FormControl = new FormControl();
    filteredSettingTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    shortLengthLabel: string = "";//(in or mm)
    lengthLabel: string = "";//(ft or m)
    massLabel: string = "";// (lbm or Kg)
    linearMassDensityLabel: string = "";// (lb/ft or kg/m)
    torqueLabel: string = "";// (lbf-ft or N-m)
    percentageLabel: string = "";//%
    forceLabel: string = "";//lbf or N
    stressLabel: string = "";//ksi or MPa
    nozzleSizeLabel: string = "";//x 1/32" or mm
    rotationVelocityLabel: string = "";//rpm
    pressureLabel: string = "";//(kPa or psi)
    flowLabel: string = "";//l/min or gal/min
    angleLabel: string = "";//°
    tableColumns = [   
        { columnDef: "DifferentialPressure", header: "Diff Pressure", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['DifferentialPressure']}`,validity:(element: Record<string, any>)=>{return (element['DifferentialPressure']<-2147483648 || element['DifferentialPressure']>2147483648)}  },
        { columnDef: "AxialForce", header: "Axial Force", editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['AxialForce']}`,validity:(element: Record<string, any>)=>{return (element['AxialForce']<-2147483648 || element['DifferentialPressure']>2147483648)}},    
      ];
    tableData: any[] = [
        {DifferentialPressure:'',AxialForce:''}
    ];
    currentData: any=[];
    errors: { [key: number]: any } = {};
    errorMessages: any = errorMessages;
    currentErrors: any;
    originalData: any;
    isChanged: boolean;
    chartData: any[]=null;
    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService:ConnectionService,
        private toastR: ToastrService,
        private unitsService: UnitsService,
      ) {
       
        
      }
    ngOnInit(): void {
        
    }
    ngOnChanges(){
        this.getActiveUnitSystemData();
        this.toolWeightOptions = [];
        for(const toolweightKey of Object.keys(ToolWeightOption)){
            this.toolWeightOptions.push({label:toolweightKey,value:parseInt(ToolWeightOption[toolweightKey])});
        }
        this.connconfOptions = [];
        for(const conconfKey of Object.keys(ConnectionConfiguration)){
            this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
        }

        this.typeOptions = [];
        for(const packertypeKey of Object.keys(PackerType)){
            this.typeOptions.push({label:packertypeKey,value:parseInt(PackerType[packertypeKey])});
        }

        this.settingtypeOptions = [];
        for(const settingtypeKey of Object.keys(SettingType)){
            this.settingtypeOptions.push({label:settingtypeKey,value:parseInt(SettingType[settingtypeKey])});
        }

        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 

        this.fileteredtypeOptions.next(this.typeOptions);
        this.filterControltype
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControltype.value.toLowerCase();
            let filteredList = this.typeOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtypeOptions.next(filteredList);
          }
        }); 

        this.filteredSettingTypeOptions.next(this.settingtypeOptions);
        this.filterControlSettingType
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlSettingType.value.toLowerCase();
            let filteredList = this.settingtypeOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.filteredSettingTypeOptions.next(filteredList);
          }
        }); 

        this.fileteredconnconfOptions.next(this.connconfOptions);
        this.filterControlconn
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlconn.value.toLowerCase();
            let filteredList = this.connconfOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredconnconfOptions.next(filteredList);
          }
        }); 
        
        //console.log("Tool conf options", this.toolConfOptions);
        this.toolForm = this.formBuilder.group({
            Type:  ['', [Validators.required]],
            ToolConfiguration:['', [Validators.required]],
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces]],
            Length:[0.00, [Validators.required]],
            ToolWeightOption:['',[Validators.required]],
            Drift:['',[Validators.required,Validators.min(-2147483648),Validators.max(2147483648)]],
            Mass:['',[]],
            AdjustedWeight:['',[]],
            NW:['',[Validators.min(0)]],
            Material:['',[Validators.required]],
            Burst:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            Collapse:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            Tension:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            Compression:['',[]],
            SettingType:['',[]],
            SettingPressure:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            TopMandrelOD:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            TopMandrelID:['',[]],
            TopMandrelLength:['',[Validators.min(0),Validators.max(30.48)]],
            BottomMandrelOD:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            BottomMandrelID:['',[]],
            BottomMandrelLength:['',[Validators.min(0),Validators.max(30.48)]],
            PackingElementOD:['',[Validators.min(-2147483648),Validators.max(2147483648)]],
            PackingElementID:['',[]],
            PackingElementLength:['',[Validators.min(0),Validators.max(30.48)]],
            ConnectionConfiguration:['',[Validators.required]],
            TopThreadType:['',[Validators.required]],
            TopMUT:['',[Validators.required, Validators.min(0), Validators.max(5211.6)]],
            BottomThreadType:['',[Validators.required]],
            BottomMUT:['',[Validators.required, Validators.min(0), Validators.max(5211.6)]],
            
           
          });
          
          this.toolForm.get('Length')?.disable();
          this.toolForm.get('Type').valueChanges.subscribe((value) => {
           

                this.toolConfOptions = PackerToolConfiguration[value];
                this.fileteredtoolConfOptions.next(this.toolConfOptions);
                this.filterControltoolConf
                .valueChanges
                .subscribe({
                next: () => {
                    let filter = this.filterControltoolConf.value.toLowerCase();
                    let filteredList = this.toolConfOptions.filter(
                    option => option.label.toLowerCase().indexOf(filter) >= 0
                    );
                    this.fileteredtoolConfOptions.next(filteredList);
                }
                }); 
            
          });

          this.toolForm.get('PackingElementOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('PackingElementID').setValidators([Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('PackingElementID').setValidators([]);
            }
            this.toolForm.get('PackingElementID').updateValueAndValidity();
          });

          this.toolForm.get('TopMandrelOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('TopMandrelID').setValidators([Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('TopMandrelID').setValidators([]);
            }
            this.toolForm.get('TopMandrelID').updateValueAndValidity();
          });

          this.toolForm.get('BottomMandrelOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('BottomMandrelID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('BottomMandrelID').setValidators([]);
            }
            this.toolForm.get('BottomMandrelID').updateValueAndValidity();
          });

          this.toolForm.get('ConnectionConfiguration').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            if(value==2 || value==5){
            this.toolForm.get('BottomThreadType').setValidators([]);
            this.toolForm.get('BottomMUT').setValidators([]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
        else{
            this.toolForm.get('BottomThreadType').setValidators([Validators.required]);
            this.toolForm.get('BottomMUT').setValidators([Validators.required, Validators.min(0), Validators.max(5211.6)]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
          });

          
          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return this.getConnectionsDropdown();
          })
          .then((data)=>{
            this.threadTypeOptions = [...data.result];
            this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlTopThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlTopThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredTopThreadTypeOptions.next(filteredList);
              }
            }); 

            this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlBottomThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlBottomThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredBottomThreadTypeOptions.next(filteredList);
              }
            }); 
            //get materials
            return this.getMaterialsDropdown();
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in bit form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                    this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                let typeId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Type']} )?.value;
                if(typeId)
                    this.toolForm.get('Type').patchValue(parseInt(typeId));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, ft']} )?.value);
                let toolweightoption = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool weight option']} )?.value;
                this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                if(this.toolForm.get('ToolWeightOption').value == 0){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value == 1){
                    this.toolForm.get('AdjustedWeight').enable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value==2){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').enable();
                }
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, lbm']} )?.value);
                this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Adjusted kg/m']} )?.value);
                this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['NW lb/ft']} )?.value);
                let toolconfId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool configuration']} )?.value
                if(toolconfId)
                    this.toolForm.get('ToolConfiguration').patchValue(parseInt(toolconfId));
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value;
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
               
                    this.toolForm.get('Drift').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Drift, in']} )?.value);
                    this.toolForm.get('Burst').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Burst, psi']} )?.value);
                    this.toolForm.get('Collapse').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Collapsi, psi']} )?.value);
                    this.toolForm.get('Tension').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tension, ibf']} )?.value);
                    this.toolForm.get('Compression').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Compression, ibf']} )?.value);
                    this.toolForm.get('SettingType').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Setting type']} )?.value);
                    this.toolForm.get('SettingPressure').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Setting pressure']} )?.value);

                    //Set the table &chart
                    this.tableData = this.updateData.toolSections.map((item,index)=>{
                        return {
                         'DifferentialPressure':item.find((col)=>{return col.Id===toolColumns['Differential Pressure']})?.value,
                         'AxialForce':item.find((col)=>{return col.Id===toolColumns['Axial Force']})?.value,
                        }
                     });
                     this.chartData = [...this.tableData];
                let connConfId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Connection configuration']} )?.value;
                if(connConfId)
                    this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(connConfId));
                
               
                let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
                if(connectionId)  
                    this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
                this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
                if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
                        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
                        if(bottomconnectionId)  
                            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
                        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
                }
                this.toolForm.get('TopMandrelOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top mandrel OD in']} )?.value);
                this.toolForm.get('TopMandrelID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top mandrel ID in']} )?.value);
                this.toolForm.get('TopMandrelLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top mandrel length']} )?.value);

                this.toolForm.get('BottomMandrelOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom mandrel OD in']} )?.value);
                this.toolForm.get('BottomMandrelID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom mandrel ID in']} )?.value);
                this.toolForm.get('BottomMandrelLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom mandrel length']} )?.value);

                this.toolForm.get('PackingElementOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Packing element OD running in']} )?.value);
                this.toolForm.get('PackingElementID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Packing element ID in']} )?.value);
                this.toolForm.get('PackingElementLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Packing element length']} )?.value);
 }
            else{
            
            this.toolForm.get('Mass')?.patchValue(0);
            this.toolForm.get('AdjustedWeight')?.patchValue(0);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }

        this.emitData();
          });
    }

    async getMaterialsDropdown(){

         let data;
         try{
            data = await lastValueFrom(this.materialService.getMaterialsList());
         }
         catch(e){
            this.toastR.error("Something went wrong while fetching materials");
         }
         return data;
    }//end of functions

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions

    async getConnectionsDropdown(){

        let data;
        try{
            data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
        }
        catch(e){
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight(){
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if(this.toolForm.get('ToolWeightOption').value == 0){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            if(this.toolForm.get('Length').value)
                this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            else
            this.toolForm.get('AdjustedWeight').patchValue(0);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value == 1){
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value==2){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight(){
        if(this.toolForm.get('Length').value)
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value!=0?this.toolForm.get('Mass').value/this.toolForm.get('Length').value:0);
        else
        this.toolForm.get('AdjustedWeight').patchValue(0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass(){
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
    }

   

   

   
    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
   
          }
      
        //call api below if all the flags are true

        if(this.toolForm.valid && !this.checkForErrors(this.currentErrors)){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool Updated Successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
          
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Custom Tool Added Successfully");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    this.toastR.error("Something went wrong");
                }
            });}
            
        }
    }
    checkForErrors(errors){

        let invalid = false;
        Object.keys(errors).forEach(element => {
          if(Object.keys(errors[element]).length>0){
            invalid = true;
          }
        });
        return invalid;
      }
    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){


        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem"),
                    "ToolType": this.toolForm.get('Type').value,
                    "ToolConfiguration":this.toolForm.get("ToolConfiguration").value
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, ft'],
                    "ColumnName": "Length, ft",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool configuration'],
                    "ColumnName": "Tool configuration",
                    "value": this.toolForm.get("ToolConfiguration").value
                },
                {
                    "Id": toolColumns['Tool weight option'],
                    "ColumnName": "Tool weight option",
                    "value": this.toolForm.get("ToolWeightOption").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Mass, lbm'],
                    "ColumnName": "Mass, lbm",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['Type'],
                    "ColumnName": "Type",
                    "value": this.toolForm.get('Type').value
                },
                {
                    "Id": toolColumns['Adjusted kg/m'],
                    "ColumnName": "Adjusted kg/m",
                    "value": this.toolForm.get('AdjustedWeight').value
                },
                {
                    "Id": toolColumns['NW lb/ft'],
                    "ColumnName": "NW lb/ft",
                    "value": this.toolForm.get('NW').value
                },
                {
                    "Id": toolColumns['Drift, in'],
                    "ColumnName": "Drift, in",
                    "value": this.toolForm.get('Drift').value
                },
                
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
                {
                    "Id": toolColumns['Setting type'],
                    "ColumnName": "Setting type",
                    "value": this.toolForm.get('SettingType').value
                },
                {
                    "Id": toolColumns['Setting pressure'],
                    "ColumnName": "Setting pressure",
                    "value": this.toolForm.get('SettingPressure').value
                },
                {
                    "Id": toolColumns['Burst, psi'],
                    "ColumnName": "Burst, psi",
                    "value": this.toolForm.get('Burst').value
                },
                {
                    "Id": toolColumns['Collapsi, psi'],
                    "ColumnName": "Collapsi, psi",
                    "value": this.toolForm.get('Collapse').value
                },
                {
                    "Id": toolColumns['Tension, ibf'],
                    "ColumnName": "Tension, ibf",
                    "value": this.toolForm.get('Tension').value
                },
                {
                    "Id": toolColumns['Compression, ibf'],
                    "ColumnName": "Compression, ibf",
                    "value": this.toolForm.get('Compression').value
                },
                {
                    "Id": toolColumns['Connection configuration'],
                    "ColumnName": "Connection configuration",
                    "value": this.toolForm.get('ConnectionConfiguration').value

                },
                {
                    "Id": toolColumns['Thread type'],
                    "ColumnName": "Thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['Top MUT n-m'],
                    "ColumnName": "Top MUT n-m",
                    "value": this.toolForm.get('TopMUT').value
                },
                {
                    "Id": toolColumns['Bottom thread type'],
                    "ColumnName": "Bottom thread type",
                    "value": this.toolForm.get('BottomThreadType').value
                },
                {
                    "Id": toolColumns['Bottom MUT n-m'],
                    "ColumnName": "Bottom MUT n-m",
                    "value": this.toolForm.get('BottomMUT').value
                },
                {
                    "Id": toolColumns['Top mandrel OD in'],
                    "ColumnName": "Top mandrel OD in",
                    "value": this.toolForm.get('TopMandrelOD').value?this.toolForm.get('TopMandrelOD').value:""
                },
                {
                    "Id": toolColumns['Top mandrel ID in'],
                    "ColumnName": "Top mandrel ID in",
                    "value": this.toolForm.get('TopMandrelID').value?this.toolForm.get('TopMandrelID').value:""
                },
                {
                    "Id": toolColumns['Top mandrel length'],
                    "ColumnName": "Top mandrel length",
                    "value": this.toolForm.get('TopMandrelLength').value?this.toolForm.get('TopMandrelLength').value:""
                },
                {
                    "Id": toolColumns['Bottom mandrel OD in'],
                    "ColumnName": "Bottom mandrel OD in",
                    "value": this.toolForm.get('BottomMandrelOD').value?this.toolForm.get('BottomMandrelOD').value:""
                },
                {
                    "Id": toolColumns['Bottom mandrel ID in'],
                    "ColumnName": "Bottom mandrel ID in",
                    "value": this.toolForm.get('BottomMandrelID').value?this.toolForm.get('BottomMandrelID').value:""
                },
                {
                    "Id": toolColumns['Bottom mandrel length'],
                    "ColumnName": "Bottom mandrel length",
                    "value": this.toolForm.get('BottomMandrelLength').value?this.toolForm.get('BottomMandrelLength').value:""
                },
                {
                    "Id": toolColumns['Packing element OD running in'],
                    "ColumnName": 'Packing element OD running in',
                    "value": this.toolForm.get('PackingElementOD').value?this.toolForm.get('PackingElementOD').value:""
                },
                {
                    "Id": toolColumns['Packing element ID in'],
                    "ColumnName": "Packing element ID in",
                    "value": this.toolForm.get('PackingElementID').value?this.toolForm.get('PackingElementID').value:""
                },
                {
                    "Id": toolColumns['Packing element length'],
                    "ColumnName": "Packing element length",
                    "value": this.toolForm.get('PackingElementLength').value?this.toolForm.get('PackingElementLength').value:""
                },
               
                ],
                "toolSections": this.currentData.map((item,index)=>{
                    return {
                        [index]: [
                            {
                                "Id": toolColumns['Differential Pressure'],
                                "ColumnName": "Differential Pressure",
                                "value": item['DifferentialPressure']
                            },
                            {
                                "Id": toolColumns['Axial Force'],
                                "ColumnName": "Axial Force",
                                "value": item['AxialForce']
                            }
                        ]
                    }
                })
        
            }
        
        }

        return payload;
    }

 

    resetThreadtype(){
        if(this.updateData){
        let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
        if(connectionId)  
            this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
        this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
        if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
        if(bottomconnectionId)  
            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
        }
        
    }
    else{
        this.toolForm.get('TopThreadType').patchValue('');
        this.toolForm.get('TopMUT').patchValue('');
        this.toolForm.get('BottomThreadType').patchValue('');
        this.toolForm.get('BottomMUT').patchValue('');

    }
    }

    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value,
            toolType: this.toolForm.get("Type").value,
            toolConf: this.toolForm.get("ToolConfiguration").value,
        });
    }

      /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
        next: (res) => {
            if (res) {
                //console.log("res in casing---", res);
                let activeUnitSystemData = res;
                this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                this.lengthLabel = activeUnitSystemData.length.unitValue;
                this.massLabel = activeUnitSystemData.mass.unitValue;
                this.linearMassDensityLabel = activeUnitSystemData.linearMassDensity.unitValue;
                this.torqueLabel = activeUnitSystemData.torque.unitValue;
                this.percentageLabel = activeUnitSystemData.percentage.unitValue;
                this.forceLabel = activeUnitSystemData.force.unitValue;
                this.stressLabel = activeUnitSystemData.stress.unitValue;
                this.nozzleSizeLabel = activeUnitSystemData.nozzleSize.unitValue;
                this.rotationVelocityLabel = activeUnitSystemData.rotationVelocity.unitValue;
                this.angleLabel = activeUnitSystemData.angle.unitValue;
                this.pressureLabel=activeUnitSystemData.pressure.unitValue;
                this.flowLabel=activeUnitSystemData.flow.unitValue;
                // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

                let updatedColumns = [   
                    { columnDef: "DifferentialPressure", header: "Diff Pressure, "+this.stressLabel, editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['DifferentialPressure']}`,validity:(element: Record<string, any>)=>{return (element['DifferentialPressure']<-2147483648 || element['DifferentialPressure']>2147483648)}  },
                    { columnDef: "AxialForce", header: "Axial Force, "+this.forceLabel, editable:true,  inputType:'number', cell: (element: Record<string, any>) => `${element['AxialForce']}`,validity:(element: Record<string, any>)=>{return (element['AxialForce']<-2147483648 || element['DifferentialPressure']>2147483648)}},    
                  ];
                  this.tableColumns[0].header = "Diff Pressure, "+this.pressureLabel;
                  this.tableColumns[1].header = "Axial Force, "+this.forceLabel;
        
            } else {
                //console.log('error');
            }
        },
        error: (error) => {
            //console.log("Unit", error.error.result);
        }
    })
}
getTableData(event){

    /**
     * emitter event call to check updated data in table
     */
    //console.log(event);
    this.currentErrors = event.errors;
    this.currentData = event.data;
    //console.log("currentData", this.currentData);
    //console.log("currentErrors", this.currentErrors);
    this.chartData = [...this.currentData];
    let isChanged = this.checkChanges(event.data);
    return isChanged;
  }//end of function
  checkChanges(data){

    /**
     * this function compares original data and changes made in
     * table
     */
    data = _.map(data, (item) => {
      // Use _.omit to remove the unwanted keys from each object
      return _.omit(item, ['isAdded','isUpdated']);
    });

    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    //console.log("isDataChangedsss",isDataChanged, data);
    // this.currentData = data;
    
    setTimeout(()=>{
      this.isChanged = isDataChanged;
    });

    return isDataChanged;
  }//end of function

}
