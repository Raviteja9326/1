import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { RangeType } from 'src/app/core/enum/custom-tools/toolRangeType.enum';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ToolAPIType } from 'src/app/core/enum/custom-tools/toolApi.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-casing-pipe-form',
  templateUrl: './casing-pipe-form.component.html'
})
export class CasingPipeFormComponent implements OnInit, OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [4.52,1.22,3.78,5.77];
    toolWeightOptions:any = [];
    rangeOptions:any = [];
    apiOptions:any = []
    materialOptions:any = [];
    sectionArrayList: any[] = [];
    sectionArrayErrorList: { OD: string; ID: string; Length: string; Material: string; Caption: string; NW: any; }[] = [];
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    sectionArrayMaterialDropdownControl: any[]=[];
    sectionArrayFilteredMaterialOptions:any = [];
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControlRange: FormControl = new FormControl();
    fileteredrangeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlapiOptions: FormControl = new FormControl();
    fileteredapiOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    shortLengthLabel: string = "";//(in or mm)
    lengthLabel: string = "";//(ft or .m)
    massLabel: string = "";// (lbm or Kg)
    linearMassDensityLabel: string = "";// (lb/ft or kg/m)
    torqueLabel: string = "";// (lbf-ft or N-m)
    percentageLabel: string = "";//%
    forceLabel: string = "";//lbf or N
    stressLabel: string = "";//ksi or MPa
    nozzleSizeLabel: string = "";//x 1/32" or mm
    capacityLabel:string="";//bbl/ft or l/m
    pressureLabel: string = "";//(kPa or psi)
    

    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private toastR: ToastrService,
        private unitsService: UnitsService,
      ) {
       
      }
    
    ngOnChanges(){
        
        this.getActiveUnitSystemData();
        this.rangeOptions = [];
        for(const rangetypeKey of Object.keys(RangeType)){
            this.rangeOptions.push({label:rangetypeKey,value:parseInt(RangeType[rangetypeKey])});
          }
        this.apiOptions = [];
        for(const apitypeKey of Object.keys(ToolAPIType)){
            this.apiOptions.push({label:apitypeKey,value:parseInt(ToolAPIType[apitypeKey])});
        }
        this.toolWeightOptions = [];
        for(const toolweightKey of Object.keys(ToolWeightOption)){
            this.toolWeightOptions.push({label:toolweightKey,value:parseInt(ToolWeightOption[toolweightKey])});
        }
       
        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 

        this.fileteredrangeOptions.next(this.rangeOptions);
        this.filterControlRange
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlRange.value.toLowerCase();
            let filteredList = this.rangeOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredrangeOptions.next(filteredList);
          }
        }); 


        this.fileteredapiOptions.next(this.apiOptions);
        this.filterControlapiOptions
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlapiOptions.value.toLowerCase();
            let filteredList = this.apiOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredapiOptions.next(filteredList);
          }
        }); 

        

        this.toolForm = this.formBuilder.group({
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces]],
            Length:['',[Validators.required]],
            ToolWeightOption:['',[Validators.required]],
            Drift:['',[Validators.required]],
            Mass:['',[Validators.required,Validators.min(0)]],
            AdjustedWeight:['',[Validators.required,Validators.min(0)]],
            NW:['',[Validators.required,Validators.min(0)]],
            Material:['',[Validators.required]],
            Range:['',[Validators.required]],
            API:['',[Validators.required]],
            Connection:['',[Validators.required,CustomValidators.noContinuousSpaces]],
            SpecialDrift:[0.00,[Validators.required]],
            Torque:[0.00,[Validators.required]],
            WallThickness:[0.000,[Validators.required]],
            Burst:['',[Validators.required]],
            Collapse:['',[Validators.required]],
            Tension:['',[Validators.required]],
            InternalVolume:['',[Validators.required]],
            BurstEfficiency:[0.00,[Validators.required,Validators.min(0),Validators.max(100)]],
            CollapseEfficiency:[0.00,[Validators.required,Validators.min(0),Validators.max(100)]],
            TensileEfficiency:[0.00,[Validators.required,Validators.min(0),Validators.max(100)]],
            CompressionEfficiency:[0.00,[Validators.required,Validators.min(0),Validators.max(100)]],
            Sections:['',[Validators.required,Validators.min(1),Validators.max(2147483647)]]
          });
          
          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return this.getMaterialsDropdown()
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in case form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                    this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, ft']} )?.value);
                let toolweightoption = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool weight option']} )?.value;
                this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                if(this.toolForm.get('ToolWeightOption').value == 0){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value == 1){
                    this.toolForm.get('AdjustedWeight').enable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value==2){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').enable();
                }
                this.toolForm.get('Drift').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Drift, in']} )?.value);
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, lbm']} )?.value);
                this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Adjusted weigth, lb/ft']} )?.value);
                this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['NW lb/ft']} )?.value);
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
                let rangeId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Range']} )?.value
                if(rangeId)
                    this.toolForm.get('Range').patchValue(parseInt(rangeId));
                let apiId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Standard API/non API']} )?.value;
                if(apiId)
                    this.toolForm.get('API').patchValue(parseInt(apiId));
                this.toolForm.get('Connection').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Connection']} )?.value);
                this.toolForm.get('SpecialDrift').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Special drift']} )?.value);
                this.toolForm.get('Torque').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Torque']} )?.value);
                this.toolForm.get('WallThickness').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Wall thickness, in']} )?.value);
                this.toolForm.get('Burst').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Burst, psi']} )?.value);
                this.toolForm.get('Collapse').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Collapsi, psi']} )?.value);
                this.toolForm.get('Tension').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tension, ibf']} )?.value);
                this.toolForm.get('InternalVolume').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Internal valume, bbl/ft']} )?.value);
                this.toolForm.get('BurstEfficiency').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Burst efficiency']} )?.value);
                this.toolForm.get('CollapseEfficiency').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Collapse efficiency']} )?.value);
                this.toolForm.get('TensileEfficiency').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tensible efficiency']} )?.value);
                this.toolForm.get('CompressionEfficiency').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Compression efficiency']} )?.value);
                this.toolForm.get('Sections').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Sections']} )?.value);
                //section array
                this.sectionArrayMaterialDropdownControl = Array.from({ length: this.updateData?.toolSections?.length }, (_, index) => { 
                    return new FormControl();
                });
               
                this.sectionArrayFilteredMaterialOptions = Array.from({ length: this.updateData?.toolSections?.length }, (_, index) => { 
                    return new ReplaySubject<any[]>(1);
                });
        
                this.sectionArrayFilteredMaterialOptions.forEach((element,i)=>{
                    this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
                    this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                        next: ()=>{
                        this.loadSectionMaterialOptions(i)
                    }});
                });
                
        
                this.sectionArrayList = this.updateData.toolSections.map((item,index)=>{
                   return {
                    'OD':item.find((col)=>{return col.Id===toolColumns['OD, in']})?.value,
                    'ID':item.find((col)=>{return col.Id===toolColumns['ID, in']})?.value,
                    'Length':item.find((col)=>{return col.Id===toolColumns['section length, ft']})?.value,
                    'Material':item.find((col)=>{return col.Id===toolColumns['Section material']})?.value,
                    'Caption':item.find((col)=>{return col.Id===toolColumns['Caption']})?.value,
                    'NW':item.find((col)=>{return col.Id===toolColumns['NW, lb/ft']})?.value,
                   }
                });
                this.sectionArrayErrorList = Array.from({ length: this.sectionArrayList.length }, (_, index) => { 
                    return {'OD':'','ID':'',
                    'Length':'','Material':'',
                    'Caption':'','NW':''}
                });
               
            }
            else{
                this.toolForm.get('Length')?.patchValue(1);
                this.toolForm.get('Mass')?.patchValue(0);
                this.toolForm.get('AdjustedWeight')?.patchValue(0);
                this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
        this.emitData();
          });
         
      }
    ngOnInit(): void {
        
    }

    async getMaterialsDropdown(){
        let data = await lastValueFrom(this.materialService.getMaterialsList());
        return data;
   }
   async getToolSizeDropdown() {

    let data;
    try {
        data = await lastValueFrom(this.customToolService.getToolSizesList());
    }
    catch (e) {
        this.toastR.error("Something went wrong while fetching tool sizes");
    }
    return data;
}//end of functions
    onchangeToolWeight(){
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if(this.toolForm.get('ToolWeightOption').value == 0){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value == 1){
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value==2){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight(){
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value!=0?this.toolForm.get('Mass').value/this.toolForm.get('Length').value:0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass(){
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
    }


    createSections(numOfSections){
        this.sectionArrayList = Array.from({ length: numOfSections }, (_, index) => { 
            return {'OD':'','ID':'',
            'Length':'','Material':'',
            'Caption':'Body','NW':22.72
        }
        });
        this.sectionArrayErrorList = Array.from({ length: numOfSections }, (_, index) => { 
            return {'OD':'','ID':'',
            'Length':'','Material':'',
            'Caption':'','NW':''}
        });
        this.sectionArrayMaterialDropdownControl = Array.from({ length: numOfSections }, (_, index) => { 
            return new FormControl();
        });
       
        this.sectionArrayFilteredMaterialOptions = Array.from({ length: numOfSections }, (_, index) => { 
            return new ReplaySubject<any[]>(1);
        });

        this.sectionArrayFilteredMaterialOptions.forEach((element,i)=>{
            this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
            this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                next: ()=>{
                this.loadSectionMaterialOptions(i)
            }});
        });
    }

    loadSectionMaterialOptions(index: number){

        // Load options into the filteredOptions array for the selected dropdown

      let filter = this.sectionArrayMaterialDropdownControl[index].value.toLowerCase();
      let filteredList = this.materialOptions.filter(
        option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
      );
      this.sectionArrayFilteredMaterialOptions[index].next(filteredList);
    }

    validateSectionsID(value, i){

        if(value){
            if(value<=0 || value>=this.sectionArrayList[i]['OD']){
                this.sectionArrayErrorList[i]['ID'] = "Inner Diameter Must be Greater Than 0 and Less Than Outer Diameter";
            }
            else{
                this.sectionArrayErrorList[i]['ID'] = "";
            }
        }
        else{
            this.sectionArrayErrorList[i]['ID'] = "Inner Diameter Must be Greater Than 0 and Less Than Outer Diameter";
        }
    }

    validateSectionsOD(value, i){

        if(value){
            if(value<=0){
                this.sectionArrayErrorList[i]['OD'] = "Outer Diameter Must be Greater Than 0";
            }
            else{
                this.sectionArrayErrorList[i]['OD'] = "";
            }
        }
        else{
            this.sectionArrayErrorList[i]['OD'] = "Outer Diameter Must be Greater Than 0";
        }
        this.validateSectionsID(this.sectionArrayList[i]['ID'],i);
    }

    validateSectionsLength(value, i){

        if(value){
            if(value<=0 || value>100){
                this.sectionArrayErrorList[i]['Length'] = "Length Must be Between 0 And 100";
            }
            else{
                this.sectionArrayErrorList[i]['Length'] = "";
            }
        }
        else{
            this.sectionArrayErrorList[i]['Length'] = "Length Must be Between 0 And 100";
        }
    }
    validateSectionsCaption(value, i){
        if(value){
            this.sectionArrayErrorList[i]['Caption'] = "";
        }
        else{
            this.sectionArrayErrorList[i]['Caption'] = "Caption is Required!";
        }
    }
    validateSectionsMaterial(value, i){

        if(value){
            this.sectionArrayErrorList[i]['Material'] = "";
        }
        else{
            this.sectionArrayErrorList[i]['Material'] = "Material is Required!";
        }
    }
  


    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
    
          }
       
       
        this.sectionArrayList.forEach((element,i)=>{
            this.validateSectionsOD(element.OD,i);
            this.validateSectionsID(element.ID,i);
            this.validateSectionsCaption(element.Caption,i);
            this.validateSectionsLength(element.Length,i);
            this.validateSectionsMaterial(element.Material,i);
         
        });
        //console.log(this.toolForm.valid,this.sectionArrayErrorList);
        let sectionFlag = true;
       
        this.sectionArrayErrorList.forEach((item)=>{
            if(item.OD || item.ID || item.Caption || item.Length || item.Material){
                sectionFlag = false;
            }
        });

        //console.log("validity flags",this.toolForm.valid,sectionFlag);
        //call api below if all the flags are true
        if(this.toolForm.valid  && sectionFlag){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Tool added successfully.");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    //console.log(error);
                    this.toastR.error("Something went wrong!");
                }
            });
           }
        }
    }

    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){

        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem")
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, ft'],
                    "ColumnName": "Length, ft",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool weight option'],
                    "ColumnName": "Tool weight option",
                    "value": this.toolForm.get("ToolWeightOption").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Drift, in'],
                    "ColumnName": "Drift, in",
                    "value": this.toolForm.get("Drift").value
                },
                {
                    "Id": toolColumns['Mass, lbm'],
                    "ColumnName": "Mass, lbm",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['Adjusted weigth, lb/ft'],
                    "ColumnName": "Adjusted weigth, lb/ft",
                    "value": this.toolForm.get('AdjustedWeight').value
                },
                {
                    "Id": toolColumns['NW lb/ft'],
                    "ColumnName": "NW lb/ft",
                    "value": this.toolForm.get('NW').value
                },
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
                {
                    "Id": toolColumns['Range'],
                    "ColumnName": "Range",
                    "value": this.toolForm.get('Range').value
                },
                {
                    "Id": toolColumns['Standard API/non API'],
                    "ColumnName": "Standard API/non API",
                    "value": this.toolForm.get('API').value
                },
                {
                    "Id": toolColumns['Connection'],
                    "ColumnName": "Connection",
                    "value": this.toolForm.get('Connection').value
                },
                {
                    "Id": toolColumns['Torque'],
                    "ColumnName": "Torque",
                    "value": this.toolForm.get('Torque').value
                },
                {
                    "Id": toolColumns['Special drift'],
                    "ColumnName": "Special drift",
                    "value": this.toolForm.get('SpecialDrift').value
                },
                {
                    "Id": toolColumns['Wall thickness, in'],
                    "ColumnName": "Wall thickness, in",
                    "value": this.toolForm.get('WallThickness').value
                },
                {
                    "Id": toolColumns['Burst, psi'],
                    "ColumnName": "Burst, psi",
                    "value": this.toolForm.get('Burst').value
                },
                {
                    "Id": toolColumns['Collapsi, psi'],
                    "ColumnName": "Collapsi, psi",
                    "value": this.toolForm.get('Collapse').value
                },
                {
                    "Id": toolColumns['Tension, ibf'],
                    "ColumnName": "Tension, ibf",
                    "value": this.toolForm.get('Tension').value
                },
                {
                    "Id": toolColumns['Internal valume, bbl/ft'],
                    "ColumnName": "Internal valume, bbl/ft",
                    "value": this.toolForm.get('InternalVolume').value
                },
                {
                    "Id": toolColumns['Burst efficiency'],
                    "ColumnName": "Burst efficiency",
                    "value": this.toolForm.get('BurstEfficiency').value
                },
                {
                    "Id": toolColumns['Collapse efficiency'],
                    "ColumnName": "Collapse efficiency",
                    "value": this.toolForm.get('CollapseEfficiency').value
                },
                {
                    "Id": toolColumns['Tensible efficiency'],
                    "ColumnName": "Tensible efficiency",
                    "value": this.toolForm.get('TensileEfficiency').value
                },
                {
                    "Id": toolColumns['Compression efficiency'],
                    "ColumnName": "Compression efficiency",
                    "value": this.toolForm.get('CompressionEfficiency').value
                },
                {
                    "Id": toolColumns['Sections'],
                    "ColumnName": "Sections",
                    "value": this.toolForm.get('Sections').value
                }
                ],
            "toolSections": this.sectionArrayList.map((item,index)=>{
                return {
                    [index]: [
                        {
                            "Id": toolColumns['OD, in'],
                            "ColumnName": "OD, in",
                            "value": item['OD']
                        },
                        {
                            "Id": toolColumns['ID, in'],
                            "ColumnName": "ID, in",
                            "value": item['ID']
                        },
                        {
                            "Id": toolColumns['section length, ft'],
                            "ColumnName": "section length, ft",
                            "value": item['Length']
                        },
                        {
                            "Id": toolColumns['Section material'],
                            "ColumnName": "Section material",
                            "value": item['Material']
                        },
                        {
                            "Id": toolColumns['Caption'],
                            "ColumnName": "Caption",
                            "value": item['Caption']
                        },
                        {
                            "Id": toolColumns['NW, lb/ft'],
                            "ColumnName": "NW, lb/ft",
                            "value": item['NW']
                        }
                    ]
                }
            })
           
        
            }
        
        }

        return payload;
    }

    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value
        });
    }

     /*
    ** get active unit from active unit system and integration with labels, placeholders and headers
    */
    getActiveUnitSystemData() {
  
      // this.unitSystemData = {};
      this.unitsService.getActiveUnitSystemDetails().subscribe({
          next: (res) => {
              if (res) {
                  //console.log("res in casing---", res);
                  let activeUnitSystemData = res;
                  this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                  this.lengthLabel = activeUnitSystemData.length.unitValue;
                  this.massLabel = activeUnitSystemData.mass.unitValue;
                  this.linearMassDensityLabel = activeUnitSystemData.linearMassDensity.unitValue;
                  this.torqueLabel = activeUnitSystemData.torque.unitValue;
                  this.percentageLabel = activeUnitSystemData.percentage.unitValue;
                  this.forceLabel = activeUnitSystemData.force.unitValue;
                  this.pressureLabel=activeUnitSystemData.pressure.unitValue;
                  this.capacityLabel=activeUnitSystemData.capacity.unitValue;
                  // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
  
              } else {
                  //console.log('error');
              }
          },
          error: (error) => {
              //console.log("Unit", error.error.result);
          }
      })
  }
}

