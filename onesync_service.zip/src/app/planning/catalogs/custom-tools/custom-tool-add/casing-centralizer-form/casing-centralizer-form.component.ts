import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { RangeType } from 'src/app/core/enum/custom-tools/toolRangeType.enum';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ToolAPIType } from 'src/app/core/enum/custom-tools/toolApi.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { CentralizerType } from 'src/app/core/enum/custom-tools/centralizerType.enum';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-casing-centralizer-form',
  templateUrl: './casing-centralizer-form.component.html'
})
export class CasingCentralizerFormComponent implements OnInit, OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [];
    materialOptions:any = [];
    centralizerTypeOptions:any = [
    ];
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    shortLengthLabel:string="";
    lengthLabel:string="";
    massLabel:string="";
    forceLabel:string="";
    filterControlcentralizer: FormControl = new FormControl();
    fileteredcentralizerTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
   constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private toastR: ToastrService,
        private unitsService: UnitsService, 
      ) {
       
      }
    
    ngOnChanges(){
        this.getActiveUnitSystemData();
        this.centralizerTypeOptions = [];
        for(const centralizertypeKey of Object.keys(CentralizerType)){
            this.centralizerTypeOptions.push({label:centralizertypeKey,value:parseInt(CentralizerType[centralizertypeKey])});
        }
        this.toolForm = this.formBuilder.group({
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces]],
            Material:['',[Validators.required]],          
            CasingSize:['',[Validators.required,CustomValidators.greaterThanZero]],
            HoleSize:['',[CustomValidators.greaterThanZero]],
            CentralizerType:['',[]],
            BowType:['',[]],
            Length:[1.00,[Validators.required,CustomValidators.greaterThanZero]],
            Mass:['',[Validators.required,CustomValidators.greaterThanZero]],          
            OuterDiameter:['',[Validators.required,CustomValidators.greaterThanMin(0)]],
            RigidOuterDiameter:['',[Validators.required,CustomValidators.greaterThanMin(0)]],
            InnerDiameter:['',[Validators.required,CustomValidators.greaterThanMin(0)]],
            StartingForce:['',[]],
            RunningForce:['',[]],
            RestoringForce:['',[]],
            
          });
          
          this.toolForm.get('OuterDiameter').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            this.toolForm.get('InnerDiameter').setValidators([Validators.required, CustomValidators.greaterThanMin(0),CustomValidators.lessThanMax(maxLimit)]);
            this.toolForm.get('InnerDiameter').updateValueAndValidity();
          });

          this.fileteredcentralizerTypeOptions.next(this.centralizerTypeOptions);
        this.filterControlcentralizer
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlcentralizer.value.toLowerCase();
            let filteredList = this.centralizerTypeOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredcentralizerTypeOptions.next(filteredList);
          }
        }); 

          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return this.getMaterialsDropdown()
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in case form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, ft']} )?.value);
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, lbm']} )?.value);
                
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
             
                let centralizerTypeId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Centralizer Type']} )?.value
                if(centralizerTypeId)
                    this.toolForm.get('CentralizerType').patchValue(parseInt(centralizerTypeId));
                this.toolForm.get('CasingSize').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Casing Size, in']} )?.value);
                this.toolForm.get('HoleSize').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Hole Size, in']} )?.value);
                
                this.toolForm.get('BowType').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Blow Type']} )?.value);
                this.toolForm.get('OuterDiameter').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Outer Diameter, in']} )?.value);
                this.toolForm.get('RigidOuterDiameter').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Rigid Outer Diameter, in']} )?.value);
                this.toolForm.get('InnerDiameter').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Inner Diameter, in']} )?.value);
                this.toolForm.get('StartingForce').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Starting Force, lbf']} )?.value);
                this.toolForm.get('RunningForce').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Running Force, lbf']} )?.value);
                this.toolForm.get('RestoringForce').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Restoring Force, lbf']} )?.value);
                
               
            }
            else{
                this.toolForm.get('Length')?.patchValue(1);
               
              
        }
        this.emitData();
          });
         
      }
    ngOnInit(): void {
        this.getActiveUnitSystemData()
    }

    async getMaterialsDropdown(){
        let data = await lastValueFrom(this.materialService.getMaterialsList());
        return data;
   }
  
   async getToolSizeDropdown() {

    let data;
    try {
        data = await lastValueFrom(this.customToolService.getToolSizesList());
    }
    catch (e) {
        this.toastR.error("Something went wrong while fetching tool sizes");
    }
    return data;
}//end of functions

    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
    
          }
       
       
     
      

        //console.log("validity flags",this.toolForm.valid);
        //call api below if all the flags are true
        if(this.toolForm.valid  ){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Tool added successfully.");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    //console.log(error);
                    this.toastR.error("Something went wrong!");
                }
            });
           }
        }
    }

    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){

        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem")
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, ft'],
                    "ColumnName": "Length, ft",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Casing Size, in'],
                    "ColumnName": "Casing Size, in",
                    "value": this.toolForm.get("CasingSize").value
                },
               
                {
                    "Id": toolColumns['Hole Size, in'],
                    "ColumnName": "Hole Size, in",
                    "value": this.toolForm.get('HoleSize').value
                },
                {
                    "Id": toolColumns['Mass, lbm'],
                    "ColumnName": "Mass, lbm",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['Centralizer Type'],
                    "ColumnName": "Centralizer Type",
                    "value": this.toolForm.get('CentralizerType').value
                },
                {
                    "Id": toolColumns['Blow Type'],
                    "ColumnName": "Blow Type",
                    "value": this.toolForm.get('BowType').value
                },
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
                {
                    "Id": toolColumns['Outer Diameter, in'],
                    "ColumnName": "Outer Diameter, in",
                    "value": this.toolForm.get('OuterDiameter').value
                },
                {
                    "Id": toolColumns['Rigid Outer Diameter, in'],
                    "ColumnName": "Rigid Outer Diameter, in",
                    "value": this.toolForm.get('RigidOuterDiameter').value
                },
                {
                    "Id": toolColumns['Inner Diameter, in'],
                    "ColumnName": "Inner Diameter, in",
                    "value": this.toolForm.get('InnerDiameter').value
                },
                {
                    "Id": toolColumns['Starting Force, lbf'],
                    "ColumnName": "Starting Force, lbf",
                    "value": this.toolForm.get('StartingForce').value
                },
                {
                    "Id": toolColumns['Running Force, lbf'],
                    "ColumnName": "Running Force, lbf",
                    "value": this.toolForm.get('RunningForce').value
                },
                {
                    "Id": toolColumns['Restoring Force, lbf'],
                    "ColumnName": "Restoring Force, lbf",
                    "value": this.toolForm.get('RestoringForce').value
                }
                ],
           
           
        
            }
        
        }

        return payload;
    }
    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value
        });
    }

        /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          //console.log("res in casing---", res);
          let activeUnitSystemData = res;
          this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
          this.lengthLabel = activeUnitSystemData.length.unitValue;
          this.massLabel = activeUnitSystemData.mass.unitValue;
          this.forceLabel=activeUnitSystemData.force.unitValue;
          


          // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
         
        } else {
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);
      }
    })
  }
}
