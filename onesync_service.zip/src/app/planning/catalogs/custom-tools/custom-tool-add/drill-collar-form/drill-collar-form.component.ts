import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { V } from 'jointjs';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-drill-collar-form',
  templateUrl: './drill-collar-form.component.html'
})
export class DrillCollarFormComponent implements OnInit,OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [];
    toolWeightOptions:any = [];
    threadTypeOptions: any = [];
    materialOptions:any = [];
    nozzleArrayList:any = [];
    sectionArrayList: any[] = [];
    nozzleArrayListError: any[] = [];
    sectionArrayErrorList: any[] = [];
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredBottomThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlBottomThreadType: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    sectionArrayMaterialDropdownControl: any[]=[];
    sectionArrayFilteredMaterialOptions:any = [];
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    shortLengthLabel:string="";//(in or mm)
    lengthLabel:string="";//(ft or m)
    massLabel:string="";// (lbm or Kg)
    linearMassDensityLabel:string="";// (lb/ft or kg/m)
    torqueLabel:string="";// (lbf-ft or N-m)
    percentageLabel:string="";//%
    forceLabel:string="";//lbf or N
    stressLabel:string="";//ksi or MPa
    nozzleSizeLabel:string="";//x 1/32" or mm
    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService:ConnectionService,
        private toastR: ToastrService,
        private unitsService: UnitsService, 
      ) {
       
        
      }
    ngOnInit(): void {
        
    }
    ngOnChanges(){
        
        this.getActiveUnitSystemData();
        this.toolWeightOptions = [];
        for(const toolweightKey of Object.keys(ToolWeightOption)){
            this.toolWeightOptions.push({label:toolweightKey,value:parseInt(ToolWeightOption[toolweightKey])});
        }
        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 
        this.toolForm = this.formBuilder.group({
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required,CustomValidators.noContinuousSpaces]],
            Length:[9.14, [Validators.required]],
            ToolWeightOption:['',[Validators.required]],
            Mass:['',[Validators.min(0)]],
            AdjustedWeight:['',[Validators.min(0)]],
            NW:['',[Validators.min(0)]],
            Material:['',[Validators.required]],
            TopThreadType:['',[Validators.required]],
            TopMUT:['',[Validators.required]],
            TopTensileCapacity:['',[Validators.required, CustomValidators.greaterThanMin(0)]],
            BottomThreadType:['',[Validators.required]],
            BottomMUT:['',[Validators.required]],
            BottomTensileCapacity:['',[Validators.required, CustomValidators.greaterThanMin(0)]],
            Sections:['',[Validators.required,Validators.min(1),Validators.max(2147483647)]],
          });
        
          this.toolForm.get('Length')?.disable();
          
          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return   this.getConnectionsDropdown()
          })
          .then((data)=>{
            this.threadTypeOptions = [...data.result];
            this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlTopThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlTopThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredTopThreadTypeOptions.next(filteredList);
              }
            }); 

            this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlBottomThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlBottomThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredBottomThreadTypeOptions.next(filteredList);
              }
            }); 
            //get materials
            return this.getMaterialsDropdown();
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in bit form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                    this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, m']} )?.value);
                let toolweightoption = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool weight option']} )?.value;
                this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                if(this.toolForm.get('ToolWeightOption').value == 0){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value == 1){
                    this.toolForm.get('AdjustedWeight').enable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value==2){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').enable();
                }
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, kg']} )?.value);
                this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Adjusted kg/m']} )?.value);
                this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['NW kg/m']} )?.value);
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
                let connectionId1 = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
                if(connectionId1)  
                    this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId1));
                this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
                this.toolForm.get('TopTensileCapacity').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tensible capacity']} )?.value);

                let connectionId2 = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
                if(connectionId2)  
                    this.toolForm.get('BottomThreadType').patchValue(parseInt(connectionId2));
                this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
                this.toolForm.get('BottomTensileCapacity').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom tensible capacity']} )?.value);
                this.toolForm.get('Sections').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Sections']} )?.value);

                
                //section array
                this.sectionArrayMaterialDropdownControl = Array.from({ length: this.updateData?.toolSections?.length }, (_, index) => { 
                    return new FormControl();
                });
               
                this.sectionArrayFilteredMaterialOptions = Array.from({ length: this.updateData?.toolSections?.length }, (_, index) => { 
                    return new ReplaySubject<any[]>(1);
                });
        
                this.sectionArrayFilteredMaterialOptions.forEach((element,i)=>{
                    this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
                    this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                        next: ()=>{
                        this.loadSectionMaterialOptions(i)
                    }});
                });
                
                this.sectionArrayList = this.updateData.toolSections.map((item,index)=>{
                   return {
                    'OD':item.find((col)=>{return col.Id===toolColumns['OD, in']})?.value,
                    'ID':item.find((col)=>{return col.Id===toolColumns['ID, in']})?.value,
                    'Length':item.find((col)=>{return col.Id===toolColumns['section length, ft']})?.value,
                    'Material':item.find((col)=>{return col.Id===toolColumns['Section material']})?.value,
                    'Caption':item.find((col)=>{return col.Id===toolColumns['Caption']})?.value,
                    'NW':item.find((col)=>{return col.Id===toolColumns['NW, lb/ft']})?.value,
                    'MaxContactForce':item.find((col)=>{return col.Id===toolColumns['Max contact force']})?.value,
                    'MaxVonMisesStress':item.find((col)=>{return col.Id===toolColumns['max von misses stress']})?.value
                   }
                });
                this.sectionArrayErrorList = Array.from({ length: this.sectionArrayList.length }, (_, index) => { 
                    return {'OD':'','ID':'',
                    'Length':'','Material':'',
                    'Caption':'','NW':'',
                    'MaxContactForce':'',
                    'MaxVonMisesStress':''}
                });
            }
            else{
           
            this.toolForm.get('Mass')?.patchValue(0);
            this.toolForm.get('AdjustedWeight')?.patchValue(0);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
        this.emitData();
          });
    }

    async getMaterialsDropdown(){

         let data;
         try{
            data = await lastValueFrom(this.materialService.getMaterialsList());
         }
         catch(e){
            this.toastR.error("Something went wrong while fetching materials");
         }
         return data;
    }//end of functions

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions

    async getConnectionsDropdown(){

        let data;
        try{
            data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
        }
        catch(e){
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight(){
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if(this.toolForm.get('ToolWeightOption').value == 0){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            if(this.toolForm.get('Length').value)
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            else
            this.toolForm.get('AdjustedWeight').patchValue(0);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value == 1){
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value==2){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight(){
        if(this.toolForm.get('Length').value)
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
        else
        this.toolForm.get('AdjustedWeight').patchValue(0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass(){
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
    }

   

    createSections(numOfSections){
        this.sectionArrayList = Array.from({ length: numOfSections }, (_, index) => { 
            return {'OD':'','ID':'',
            'Length':'','Material':'',
            'Caption':'','NW':'',
            'MaxContactForce':8896.44,
            'MaxVonMisesStress':110.32
        }
        });
        this.sectionArrayErrorList = Array.from({ length: numOfSections }, (_, index) => { 
            return {'OD':'','ID':'',
            'Length':'','Material':'',
            'Caption':'','NW':'',
            'MaxContactForce':'',
            'MaxVonMisesStress':''}
        });

        this.sectionArrayMaterialDropdownControl = Array.from({ length: numOfSections }, (_, index) => { 
            return new FormControl();
        });
       
        this.sectionArrayFilteredMaterialOptions = Array.from({ length: numOfSections }, (_, index) => { 
            return new ReplaySubject<any[]>(1);
        });

        this.sectionArrayFilteredMaterialOptions.forEach((element,i)=>{
            this.sectionArrayFilteredMaterialOptions[i].next(this.materialOptions);
            this.sectionArrayMaterialDropdownControl[i].valueChanges.subscribe({
                next: ()=>{
                this.loadSectionMaterialOptions(i)
            }});
        });

    }

 

    validateSectionsID(value, i){

        if(value){
            if(value<=0 || value>=this.sectionArrayList[i]['OD']){
                this.sectionArrayErrorList[i]['ID'] = "Inner Diameter Must be Greater Than 0 And Less Than Outer Diameter";
            }
            else{
                this.sectionArrayErrorList[i]['ID'] = "";
            }
        }
        else{
            this.sectionArrayErrorList[i]['ID'] = "Inner Diameter Must be Greater Than 0 And Less Than Outer Diameter";
        }
    }

    validateSectionsOD(value, i){

        if(value){
            if(value<=0){
                this.sectionArrayErrorList[i]['OD'] = "Outer Diameter Must be Greater Than 0";
            }
            else{
                this.sectionArrayErrorList[i]['OD'] = "";
            }
        }
        else{
            this.sectionArrayErrorList[i]['OD'] = "Outer Diameter Must be Greater Than 0";
        }
        this.validateSectionsID(this.sectionArrayList[i]['ID'],i);
    }

    validateSectionsLength(value, i){

        if(value){
            if(value<=0 || value>100){
                this.sectionArrayErrorList[i]['Length'] = "Length Must be Between 0 And 100";
            }
            else{
                this.sectionArrayErrorList[i]['Length'] = "";
            }
        }
        else{
            this.sectionArrayErrorList[i]['Length'] = "Length Must be Between 0 And 100";
        }
    }
    validateSectionsCaption(value, i){
        if(value){
            this.sectionArrayErrorList[i]['Caption'] = "";
        }
        else{
            this.sectionArrayErrorList[i]['Caption'] = "Caption is Required!";
        }
    }
    validateSectionsMaterial(value, i){

        if(value){
            this.sectionArrayErrorList[i]['Material'] = "";
        }
        else{
            this.sectionArrayErrorList[i]['Material'] = "Material is Required!";
        }
    }
    validateSectionsForce(value, i){
        if(value){
            this.sectionArrayErrorList[i]['MaxContactForce'] = "";
        }
        else{
            this.sectionArrayErrorList[i]['MaxContactForce'] = "Max Contact Force is Required!";
        }
    }
    validateSectionsStress(value, i){
        if(value){
            this.sectionArrayErrorList[i]['MaxVonMisesStress'] = "";
        }
        else{
            this.sectionArrayErrorList[i]['MaxVonMisesStress'] = "Max Von Mises Stress is Required!";
        }
    }

    loadSectionMaterialOptions(index: number){

        // Load options into the filteredOptions array for the selected dropdown

      let filter = this.sectionArrayMaterialDropdownControl[index].value.toLowerCase();
      let filteredList = this.materialOptions.filter(
        option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
      );
      this.sectionArrayFilteredMaterialOptions[index].next(filteredList);
    }

    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
   
          }
      
        this.sectionArrayList.forEach((element,i)=>{
            this.validateSectionsOD(element.OD,i);
            this.validateSectionsID(element.ID,i);
            this.validateSectionsCaption(element.Caption,i);
            this.validateSectionsLength(element.Length,i);
            this.validateSectionsMaterial(element.Material,i);
            this.validateSectionsForce(element.MaxContactForce,i);
            this.validateSectionsStress(element.MaxVonMisesStress,i);
        });
        //console.log(this.toolForm.valid,this.nozzleArrayListError,this.sectionArrayErrorList);
         let sectionFlag = true;
        
        this.sectionArrayErrorList.forEach((item)=>{
            if(item.OD || item.ID || item.Caption || item.Length || item.Material || item.MaxContactForce || item.MaxVonMisesStress){
                sectionFlag = false;
            }
        });

        //console.log("validity flags",this.toolForm.valid,sectionFlag);
        //call api below if all the flags are true

        if(this.toolForm.valid &&  sectionFlag){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Custom Tool added successfully");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    this.toastR.error("Something went wrong");
                }
            });}
            
        }
    }

    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){


        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem")
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, m'],
                    "ColumnName": "Length, m",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool weight option'],
                    "ColumnName": "Tool weight option",
                    "value": this.toolForm.get("ToolWeightOption").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Mass, kg'],
                    "ColumnName": "Mass, kg",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['Adjusted kg/m'],
                    "ColumnName": "Adjusted kg/m",
                    "value": this.toolForm.get('AdjustedWeight').value
                },
                {
                    "Id": toolColumns['NW kg/m'],
                    "ColumnName": "NW kg/m",
                    "value": this.toolForm.get('NW').value
                },
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
               
                {
                    "Id": toolColumns['Thread type'],
                    "ColumnName": "Thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['Top MUT n-m'],
                    "ColumnName": "Top MUT n-m",
                    "value": this.toolForm.get('TopMUT').value
                },
                {
                    "Id": toolColumns['Tensible capacity'],
                    "ColumnName": "Tensible capacity",
                    "value": this.toolForm.get('TopTensileCapacity').value
                },
                {
                    "Id": toolColumns['Bottom thread type'],
                    "ColumnName": "Bottom thread type",
                    "value": this.toolForm.get('BottomThreadType').value
                },
                {
                    "Id": toolColumns['Bottom MUT n-m'],
                    "ColumnName": "Bottom MUT n-m",
                    "value": this.toolForm.get('BottomMUT').value
                },
                {
                    "Id": toolColumns['Bottom tensible capacity'],
                    "ColumnName": "Bottom tensible capacity",
                    "value": this.toolForm.get('BottomTensileCapacity').value
                },
                {
                    "Id": toolColumns['Sections'],
                    "ColumnName": "Sections",
                    "value": this.toolForm.get('Sections').value
                },
                
                ],
            "toolSections": this.sectionArrayList.map((item,index)=>{
                return {
                    [index]: [
                        {
                            "Id": toolColumns['OD, in'],
                            "ColumnName": "OD, in",
                            "value": item['OD']
                        },
                        {
                            "Id": toolColumns['ID, in'],
                            "ColumnName": "ID, in",
                            "value": item['ID']
                        },
                        {
                            "Id": toolColumns['section length, ft'],
                            "ColumnName": "section length, ft",
                            "value": item['Length']
                        },
                        {
                            "Id": toolColumns['Section material'],
                            "ColumnName": "Section material",
                            "value": item['Material']
                        },
                        {
                            "Id": toolColumns['Caption'],
                            "ColumnName": "Caption",
                            "value": item['Caption']
                        },
                        {
                            "Id": toolColumns['NW, lb/ft'],
                            "ColumnName": "NW, lb/ft",
                            "value": item['NW']
                        },
                        {
                            "Id": toolColumns['Max contact force'],
                            "ColumnName": "Max contact force",
                            "value": item['MaxContactForce']
                        },
                        {
                            "Id": toolColumns['max von misses stress'],
                            "ColumnName": "max von misses stress",
                            "value": item['MaxVonMisesStress']
                        },
                    ]
                }
            })
           
        
            }
        
        }

        return payload;
    }

    resetThreadtype(){
        if(this.updateData){
        let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
        if(connectionId)  
            this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
        this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
        if(bottomconnectionId)  
            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
       
    }
    else{
        this.toolForm.get('TopThreadType').patchValue('');
        this.toolForm.get('TopMUT').patchValue('');
        this.toolForm.get('BottomThreadType').patchValue('');
        this.toolForm.get('BottomMUT').patchValue('');
    

    }
    }

    onChangeSectionNWInputs(rowIndex){
        let density;
        //console.log("density",density);
        
        density = this.getDensity(this.sectionArrayList[rowIndex]['Material']);
        this.sectionArrayList[rowIndex]['NW'] = this.calculateNominalWeight(density,this.sectionArrayList[rowIndex]['OD'],
        this.sectionArrayList[rowIndex]['ID'],this.sectionArrayList[rowIndex]['Length']); 
        
    }

    getDensity(id){
        let density = this.materialOptions.find((item)=>{return item.MaterialId==id})?.Density;
        return density;
     }
     
     calculateNominalWeight(density,OD,ID,length){
        if(density && OD && ID && length){
        var mass = Math.PI*density*(OD*OD-ID*ID)/77;
        let result;
        if(length>0){
            result = mass/length;
        }
        else{
            result = 0;
        }
        return parseFloat(result.toFixed(2));
    }
    return 0;
    }

    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value
        });
    }

    
    /*
    ** get active unit from active unit system and integration with labels, placeholders and headers
    */
    getActiveUnitSystemData() {
  
        // this.unitSystemData = {};
        this.unitsService.getActiveUnitSystemDetails().subscribe({
          next: (res) => {
            if (res) {
              //console.log("res in casing---", res);
              let activeUnitSystemData = res;
              this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
              this.lengthLabel = activeUnitSystemData.length.unitValue;
              this.massLabel = activeUnitSystemData.mass.unitValue;
              this.linearMassDensityLabel=activeUnitSystemData.linearMassDensity.unitValue;
              this.torqueLabel=activeUnitSystemData.torque.unitValue;
               this.percentageLabel=activeUnitSystemData.percentage.unitValue;
               this.forceLabel=activeUnitSystemData.force.unitValue;
               this.stressLabel=activeUnitSystemData.stress.unitValue;
    this.nozzleSizeLabel=activeUnitSystemData.nozzleSize.unitValue;
    
              // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
             
            } else {
              //console.log('error');
            }
          },
          error: (error) => {
            //console.log("Unit", error.error.result);
          }
        })
      }
}
