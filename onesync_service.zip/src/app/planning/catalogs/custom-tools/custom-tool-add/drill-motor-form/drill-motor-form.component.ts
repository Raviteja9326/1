import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { AdjustableSettings } from 'src/app/core/enum/custom-tools/adjustableSetting';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { DCVType } from 'src/app/core/enum/custom-tools/dcvType.enum';
import { FishingType } from 'src/app/core/enum/custom-tools/fishingType.enum';
import { HydModelType } from 'src/app/core/enum/custom-tools/hydModelType.enum';
import { LobeConfiguration } from 'src/app/core/enum/custom-tools/lobeConfiguration.enum';
import { ToolConfiguration } from 'src/app/core/enum/custom-tools/toolConfigurations.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
    selector: 'app-drill-motor-form',
    templateUrl: './drill-motor-form.component.html'
})
export class DrillMotorFormComponent implements OnInit, OnChanges {
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions: any = [];
    toolWeightOptions: any = [];
    threadTypeOptions: any = [];
    materialOptions: any = [];
    nozzleArrayList: any = [];
    nozzleArrayListError: any[] = [];
    isNozzleChecked: boolean = false;
    isTopStabilizerChecked: boolean = false;
    isPowerSectionStabilizerChecked: boolean = false;
    isCentralizerChecked: boolean = false;
    isKickPadChecked: boolean = false;
    isHousingTabChecked: boolean = false;
    isSRSChecked: boolean = false;
    connconfOptions: any = [
    ];
    toolConfOptions: any = [];

    filteredToolSizeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredBottomThreadTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlBottomThreadType: FormControl = new FormControl();
    filteredMaterialOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    filterControlAdjustableSetting: FormControl = new FormControl();
    filteredAdjustableSettingOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlPowerSectionLobeConfig: FormControl = new FormControl();
    filteredPowerSectionLobeConfigOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    adjustableSettingsOptions: any = [];
    hydModelOptions: any = [];
    lobeConfigurationOptions: any = [];
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControlhydModel: FormControl = new FormControl();
    fileteredhydModelOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlconn: FormControl = new FormControl();
    fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    shortLengthLabel: string = "";//(in or mm)
    lengthLabel: string = "";//(ft or m)
    massLabel: string = "";// (lbm or Kg)
    linearMassDensityLabel: string = "";// (lb/ft or kg/m)
    torqueLabel: string = "";// (lbf-ft or N-m)
    percentageLabel: string = "";//%
    forceLabel: string = "";//lbf or N
    stressLabel: string = "";//ksi or MPa
    nozzleSizeLabel: string = "";//x 1/32" or mm
    rotationVelocityLabel: string = "";//rpm
    pressureLabel: string = "";//(kPa or psi)
    flowLabel: string = "";//l/min or gal/min
    angleLabel: string = "";//°


    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService: ConnectionService,
        private toastR: ToastrService,
        private unitsService: UnitsService,
    ) {


    }
    ngOnInit(): void {

    }
    ngOnChanges() {
        this.getActiveUnitSystemData();
        this.lobeConfigurationOptions = [];
        for (const lobeConfKey of Object.keys(LobeConfiguration)) {
            this.lobeConfigurationOptions.push({ label: lobeConfKey, value: parseInt(LobeConfiguration[lobeConfKey]) });
        }

   
        this.toolWeightOptions = [];
        for (const toolweightKey of Object.keys(ToolWeightOption)) {
            this.toolWeightOptions.push({ label: toolweightKey, value: parseInt(ToolWeightOption[toolweightKey]) });
        }
        this.connconfOptions = [];
        for (const conconfKey of Object.keys(ConnectionConfiguration)) {
            if (parseInt(ConnectionConfiguration[conconfKey]) != 6 && parseInt(ConnectionConfiguration[conconfKey]) != 5)
                this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
        }


        this.hydModelOptions = [];
        for (const hydModeltypeKey of Object.keys(HydModelType)) {
            this.hydModelOptions.push({ label: hydModeltypeKey, value: parseInt(HydModelType[hydModeltypeKey]) });
        }

        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 
        
        this.filteredPowerSectionLobeConfigOptions.next(this.lobeConfigurationOptions);
        this.filterControlPowerSectionLobeConfig
            .valueChanges
            .subscribe({
                next: () => {
                    let filter = this.filterControlPowerSectionLobeConfig.value.toLowerCase();
                    let filteredList = this.lobeConfigurationOptions.filter(
                        option => option.label.toLowerCase().indexOf(filter) >= 0
                    );
                    this.filteredPowerSectionLobeConfigOptions.next(filteredList);
                }
            });


        this.fileteredhydModelOptions.next(this.hydModelOptions);
        this.filterControlhydModel
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlhydModel.value.toLowerCase();
            let filteredList = this.hydModelOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredhydModelOptions.next(filteredList);
          }
        }); 
        this.fileteredconnconfOptions.next(this.connconfOptions);
        this.filterControlconn
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlconn.value.toLowerCase();
            let filteredList = this.connconfOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredconnconfOptions.next(filteredList);
          }
        }); 

        // this.toolSizeOptions = [];
        // let initial = 0.750;
        // this.toolSizeOptions.push(initial);
        // for(let i=1;i<1000;i++){
        //     if(initial<=48){
        //     this.toolSizeOptions.push(parseFloat((initial+0.063).toFixed(3)));
        //     initial = initial+0.062;
        // }
        // else{
        //     break;
        // }
        // }

        this.adjustableSettingsOptions = AdjustableSettings;
        this.filteredAdjustableSettingOptions.next(this.adjustableSettingsOptions);
        this.filterControlAdjustableSetting
            .valueChanges
            .subscribe({
                next: () => {
                    let filter = this.filterControlAdjustableSetting.value.toString().toLowerCase();
                    let filteredList = this.adjustableSettingsOptions.filter(
                        option => option.toString().toLowerCase().indexOf(filter) >= 0
                    );
                    this.filteredAdjustableSettingOptions.next(filteredList);
                }
            });

        //console.log("Tool conf options", this.toolConfOptions);
        this.toolForm = this.formBuilder.group({
            ToolSize: ['', [Validators.required]],//48.000
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces]],
            Length: [0.00, [Validators.required]],
            ToolWeightOption: ['', [Validators.required]],
            Mass: ['', []],
            AdjustedWeight: ['', []],
            NW: ['', [Validators.required, CustomValidators.greaterThanZero]],
            Material: ['', [Validators.required]],
            AdjustableSettings: ['', [Validators.required]],
            OperatingDifferentialPressure: ['', [Validators.required, CustomValidators.greaterThanZero]],
            SpeedRatio: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TorqueRatio: ['', [Validators.required, CustomValidators.greaterThanZero]],
            HydModel: ['', [Validators.required]],
            PressureDrop: ['', [CustomValidators.greaterThanZero]],
            FlowRate: ['', [CustomValidators.greaterThanZero]],
            CoefficientA: ['', [Validators.min(0), Validators.max(3)]],
            CoefficientB: ['', [CustomValidators.greaterThanZero]],
            CoefficientC: ['', [Validators.min(1), Validators.max(2)]],
            NominalOD: ['', [Validators.required, CustomValidators.greaterThanZero]],
            BearingPackLength: ['', [Validators.required, CustomValidators.greaterThanZero]],
            BitToBendLength: ['', [Validators.required, CustomValidators.greaterThanZero]],
            BearingPackMaxContactForce: ['', [Validators.required, CustomValidators.greaterThanZero]],
            BearingPackMaxVonMisesStress: ['', [Validators.required, CustomValidators.greaterThanZero]],
            ConnectionConfiguration: ['', [Validators.required]],
            TopThreadType: ['', [Validators.required]],
            TopMUT: ['', [Validators.required]],
            TopTensileCapacity: ['', [Validators.required, CustomValidators.greaterThanZero]],
            BottomThreadType: ['', [Validators.required]],
            BottomMUT: ['', [Validators.required]],
            BottomTensileCapacity: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TFA: ['', [CustomValidators.greaterThanZero]],
            Efficiency: ['', [Validators.min(0), Validators.max(100)]],
            Nozzles: ['', [Validators.min(0), Validators.max(1000)]],
            PowerSectionOD: ['', [Validators.required, CustomValidators.greaterThanZero]],
            PowerSectionLength: ['', [Validators.required, CustomValidators.greaterThanZero]],
            PowerSectionLobeConfig: ['', [Validators.required]],
            PowerSectionStages: ['', [Validators.required, CustomValidators.greaterThanZero]],
            PowerSectionMinFlowRate: ['', [Validators.required, CustomValidators.greaterThanZero]],
            PowerSectionMaxFlowRate: ['', [Validators.required, CustomValidators.greaterThanZero]],
            PowerSectionMaxDiffPressure: ['', [Validators.required, CustomValidators.greaterThanZero]],
            PowerSectionMaxTorque: ['', [Validators.required, CustomValidators.greaterThanZero]],
            RotorMass: ['', [Validators.required]],
            RotorEccentricity: ['', [Validators.required]],
            RotorMaxContactForce: ['', [Validators.required, CustomValidators.greaterThanZero]],
            RotorMaxVonMisesStress: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TopSubNominalOD: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TopSubLength: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TopSubMaxContactForce: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TopSubMaxVonMisesStress: ['', [Validators.required, CustomValidators.greaterThanZero]],
            TopStabilizerBladeOD: ['', [CustomValidators.greaterThanZero]],
            TopStabilizerBodyOD: ['', []],
            TopStabilizerBladeCount: ['', [Validators.min(-1000000000), Validators.max(1000000000)]],
            TopStabilizerBladeWidth: ['', []],
            TopStabilizerBladeLength: ['', []],
            TopStabilizerBladeAngle: ['', []],
            PowerSecStabilizerBladeOD: ['', [CustomValidators.greaterThanZero]],
            PowerSecStabilizerBodyOD: ['', [Validators.required]],
            PowerSecStabilizerBladeCount: ['', [Validators.min(-1000000000), Validators.max(1000000000)]],
            PowerSecStabilizerBladeWidth: ['', []],
            PowerSecStabilizerBladeLength: ['', []],
            PowerSecStabilizerBladeAngle: ['', []],
            CentralizerBladeOD: ['', [, CustomValidators.greaterThanZero]],
            CentralizerBodyOD: ['', []],
            CentralizerBladeCount: ['', [Validators.min(-1000000000), Validators.max(1000000000)]],
            CentralizerBladeWidth: ['', []],
            CentralizerBladeLength: ['', []],
            CentralizerBladeAngle: ['', []],
            KickPadBladeOD: ['', [CustomValidators.greaterThanZero]],
            HousingTabBladeOD: ['', [CustomValidators.greaterThanZero]],
            HousingTabBodyOD: ['', []],
            HousingTabBladeCount: ['', [Validators.min(-1000000000), Validators.max(1000000000)]],
            HousingTabBladeWidth: ['', []],
            HousingTabBladeLength: ['', []],
            HousingTabBladeAngle: ['', []],
            SRSBladeOD: ['', [CustomValidators.greaterThanZero]],
            SRSBodyOD: ['', [Validators.required]],
            SRSBladeCount: ['', [Validators.min(-1000000000), Validators.max(1000000000)]],
            SRSBladeWidth: ['', []],
            SRSBladeLength: ['', []],
            SRSBladeAngle: ['', []],
        });

        this.toolForm.get('Length')?.disable();

        this.toolForm.get('TopStabilizerBodyOD')?.disable();
        this.toolForm.get('PowerSecStabilizerBodyOD')?.disable();
        this.toolForm.get('CentralizerBodyOD')?.disable();
        this.toolForm.get('HousingTabBodyOD')?.disable();
        this.toolForm.get('SRSBodyOD')?.disable();

        this.toolForm.get('TopStabilizerBodyOD').patchValue(4.750);
        this.toolForm.get('PowerSecStabilizerBodyOD').patchValue(4.750);
        this.toolForm.get('CentralizerBodyOD').patchValue(4.750);
        this.toolForm.get('HousingTabBodyOD').patchValue(4.750);
        this.toolForm.get('SRSBodyOD')?.patchValue(4.750);

        this.toolForm.get('PowerSectionMaxTorque')?.disable();

        this.toolForm.get('PowerSectionMaxDiffPressure').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            // Change this logic as needed
            if (value) {
                this.toolForm.get('PowerSectionMaxTorque').patchValue(value * this.toolForm.get('TorqueRatio').value);
            }
            else {
                this.toolForm.get('PowerSectionMaxTorque').patchValue('');
            }
            this.toolForm.get('PowerSectionMaxTorque').updateValueAndValidity();
        });
        this.toolForm.get('TorqueRatio').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            // Change this logic as needed
            if (value) {
                this.toolForm.get('PowerSectionMaxTorque').patchValue(value * this.toolForm.get('PowerSectionMaxDiffPressure').value);
            }
            else {
                this.toolForm.get('PowerSectionMaxTorque').patchValue('');
            }
            this.toolForm.get('PowerSectionMaxTorque').updateValueAndValidity();
        });

        this.toolForm.get('BitToBendLength').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const minLimit = value; // Change this logic as needed
            if (value) {
                this.toolForm.get('BearingPackLength').setValidators([Validators.required, CustomValidators.greaterThanMin(minLimit)]);
            }
            else {
                this.toolForm.get('BearingPackLength').setValidators([Validators.required, CustomValidators.greaterThanZero]);
            }
            this.toolForm.get('BearingPackLength').updateValueAndValidity();
        });

        this.toolForm.get('PowerSectionMinFlowRate').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const minLimit = value; // Change this logic as needed
            if (value) {
                this.toolForm.get('PowerSectionMaxFlowRate').setValidators([Validators.required, Validators.min(minLimit + 1)]);
            }
            else {
                this.toolForm.get('PowerSectionMaxFlowRate').setValidators([Validators.required, CustomValidators.greaterThanZero]);
            }
            this.toolForm.get('PowerSectionMaxFlowRate').updateValueAndValidity();
        });

        this.toolForm.get('TopSubNominalOD').valueChanges.subscribe((value) => {
            // Adjust the min value dynamically based on inputA value
            const minLimit = value; // Change this logic as needed
            if (value) {
                if (this.isTopStabilizerChecked)
                    this.toolForm.get('TopStabilizerBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                else
                    this.toolForm.get('TopStabilizerBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                if (this.isPowerSectionStabilizerChecked)
                    this.toolForm.get('PowerSecStabilizerBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                else
                    this.toolForm.get('PowerSecStabilizerBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                if (this.isCentralizerChecked)
                    this.toolForm.get('CentralizerBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                else
                    this.toolForm.get('CentralizerBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                if (this.isKickPadChecked)
                    this.toolForm.get('KickPadBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                else
                    this.toolForm.get('KickPadBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                if (this.isHousingTabChecked)
                    this.toolForm.get('HousingTabBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                else
                    this.toolForm.get('HousingTabBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                if (this.isSRSChecked)
                    this.toolForm.get('SRSBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
                else
                    this.toolForm.get('SRSBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(minLimit)]);
            }
            else {
                this.toolForm.get('TopStabilizerBladeOD').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('PowerSecStabilizerBladeOD').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('CentralizerBladeOD').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('KickPadBladeOD').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('HousingTabBladeOD').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('SRSBladeOD').setValidators([CustomValidators.greaterThanZero]);
            }
            this.toolForm.get('TopStabilizerBladeOD').updateValueAndValidity();
            this.toolForm.get('PowerSecStabilizerBladeOD').updateValueAndValidity();
            this.toolForm.get('CentralizerBladeOD').updateValueAndValidity();
            this.toolForm.get('KickPadBladeOD').updateValueAndValidity();
            this.toolForm.get('HousingTabBladeOD').updateValueAndValidity();
            this.toolForm.get('SRSBladeOD').updateValueAndValidity();
        });
        this.toolForm.get('HydModel').valueChanges.subscribe((value) => {
            if (value == 1) {
                this.toolForm.get('PressureDrop').setValidators([Validators.required, CustomValidators.greaterThanZero]);
                this.toolForm.get('FlowRate').setValidators([Validators.required, CustomValidators.greaterThanZero]);

                this.toolForm.get('CoefficientA').setValidators([Validators.min(0), Validators.max(3)]);
                this.toolForm.get('CoefficientB').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('CoefficientC').setValidators([Validators.min(1), Validators.max(2)]);
            }
            else {
                this.toolForm.get('CoefficientA').setValidators([Validators.required, Validators.min(0), Validators.max(3)]);
                this.toolForm.get('CoefficientB').setValidators([Validators.required, CustomValidators.greaterThanZero]);
                this.toolForm.get('CoefficientC').setValidators([Validators.required, Validators.min(1), Validators.max(2)]);

                this.toolForm.get('PressureDrop').setValidators([CustomValidators.greaterThanZero]);
                this.toolForm.get('FlowRate').setValidators([CustomValidators.greaterThanZero]);
            }
            this.toolForm.get('PressureDrop').updateValueAndValidity();
            this.toolForm.get('FlowRate').updateValueAndValidity();
            this.toolForm.get('CoefficientA').updateValueAndValidity();
            this.toolForm.get('CoefficientB').updateValueAndValidity();
            this.toolForm.get('CoefficientC').updateValueAndValidity();

            this.toolForm.get('PressureDrop').patchValue('');
            this.toolForm.get('FlowRate').patchValue('');
            this.toolForm.get('CoefficientA').patchValue('');
            this.toolForm.get('CoefficientB').patchValue('');
            this.toolForm.get('CoefficientC').patchValue('');
        });
        this.getToolSizeDropdown()
            .then((data) => {
                //console.log("tool sizes", data.result);
                this.toolSizeOptions = [];
                this.toolSizeOptions = data.result.map(item => item.NominalOD);
                this.filteredToolSizeOptions.next(this.toolSizeOptions);
                this.filterControltoolSize
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControltoolSize.value.toString().toLowerCase();
                            let filteredList = this.toolSizeOptions.filter(
                                option => option.toString().toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredToolSizeOptions.next(filteredList);
                        }
                    });

                return this.getConnectionsDropdown();
            })
            .then((data) => {
                this.threadTypeOptions = [...data.result];
                this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
                this.filterControlTopThreadType
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControlTopThreadType.value.toLowerCase();
                            let filteredList = this.threadTypeOptions.filter(
                                option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredTopThreadTypeOptions.next(filteredList);
                        }
                    });

                this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
                this.filterControlBottomThreadType
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControlBottomThreadType.value.toLowerCase();
                            let filteredList = this.threadTypeOptions.filter(
                                option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredBottomThreadTypeOptions.next(filteredList);
                        }
                    });
                //get materials
                return this.getMaterialsDropdown();
            })
            .then((data) => {
                this.materialOptions = [...data.result];
                this.filteredMaterialOptions.next(this.materialOptions);
                this.filterControlMaterials
                    .valueChanges
                    .subscribe({
                        next: () => {
                            let filter = this.filterControlMaterials.value.toLowerCase();
                            let filteredList = this.materialOptions.filter(
                                option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                            );
                            this.filteredMaterialOptions.next(filteredList);
                        }
                    });
                return new Promise((resolve) => { resolve("success") });
            })
            .then((data) => {
                //console.log("received data in bit form", this.updateData);
                if (this.updateData) {
                    //set values in form
                    let toolsize = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool Size, in'] })?.value;
                    if (toolsize)
                        this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));

                    this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                    this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Length, m'] })?.value);
                    let toolweightoption = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool weight option'] })?.value;
                    this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                    if (this.toolForm.get('ToolWeightOption').value == 0) {
                        this.toolForm.get('AdjustedWeight').disable();
                        this.toolForm.get('Mass').disable();
                    }
                    else if (this.toolForm.get('ToolWeightOption').value == 1) {
                        this.toolForm.get('AdjustedWeight').enable();
                        this.toolForm.get('Mass').disable();
                    }
                    else if (this.toolForm.get('ToolWeightOption').value == 2) {
                        this.toolForm.get('AdjustedWeight').disable();
                        this.toolForm.get('Mass').enable();
                    }
                    this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Mass, kg'] })?.value);
                    this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Adjusted kg/m'] })?.value);
                    this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['NW kg/m'] })?.value);

                    let materialId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Material'] })?.value;
                    if (materialId)
                        this.toolForm.get('Material').patchValue(parseInt(materialId));

                    let adjustableSetting = parseFloat(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Adjustable setting'] })?.value)
                    this.toolForm.get('AdjustableSettings').patchValue(adjustableSetting);

                    this.toolForm.get('OperatingDifferentialPressure').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Operating differential pressure'] })?.value);
                    this.toolForm.get('SpeedRatio').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Speed ratio, rpm/lpm'] })?.value);
                    this.toolForm.get('TorqueRatio').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Torque ratio, N-m/pa'] })?.value);
                    this.toolForm.get('HydModel').patchValue(parseInt(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Hyd model'] })?.value));
                    this.toolForm.get('PressureDrop').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Pressure drop, kPa'] })?.value);
                    this.toolForm.get('FlowRate').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Flow rate, l/min'] })?.value);
                    this.toolForm.get('CoefficientA').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Coefficient A'] })?.value);
                    this.toolForm.get('CoefficientB').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Coefficient B'] })?.value);
                    this.toolForm.get('CoefficientC').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Coefficient C'] })?.value);
                    this.toolForm.get('NominalOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bearing pack Nominal OD, mm'] })?.value);
                    this.toolForm.get('BearingPackLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bearing pack length, m'] })?.value);
                    this.toolForm.get('BitToBendLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bit to bend length, m'] })?.value);
                    this.toolForm.get('BearingPackMaxContactForce').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bearing pack Max contact force, N'] })?.value);
                    this.toolForm.get('BearingPackMaxVonMisesStress').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bearing pack max von misses stress, MPa'] })?.value);
                    this.toolForm.get('PowerSectionOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Outer diameter, mm'] })?.value);
                    this.toolForm.get('PowerSectionLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Power section length, m'] })?.value);
                    this.toolForm.get('PowerSectionLobeConfig').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Lobe configuration'] })?.value);
                    this.toolForm.get('PowerSectionStages').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Stages'] })?.value);
                    this.toolForm.get('PowerSectionMinFlowRate').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Min flow rate, l/min'] })?.value);
                    this.toolForm.get('PowerSectionMaxFlowRate').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Max flow rate, l/min'] })?.value);
                    this.toolForm.get('PowerSectionMaxDiffPressure').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Max different pressure, kPa'] })?.value);
                    this.toolForm.get('PowerSectionMaxTorque').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Max torque, N-m'] })?.value);

                    this.toolForm.get('RotorMass').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Rotor mass, kg'] })?.value);
                    this.toolForm.get('RotorEccentricity').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Rotor eccentracityv'] })?.value);
                    this.toolForm.get('RotorMaxContactForce').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Rotor Max contact force, N'] })?.value);
                    this.toolForm.get('RotorMaxVonMisesStress').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Rotor max von misses stress, MPa'] })?.value);

                    this.toolForm.get('TopSubNominalOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top sub Nominal OD, mm'] })?.value);
                    this.toolForm.get('TopSubLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top sub length, m'] })?.value);
                    this.toolForm.get('TopSubMaxContactForce').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top sub Max contact force, N'] })?.value);
                    this.toolForm.get('TopSubMaxVonMisesStress').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top sub max von misses stress, MPa'] })?.value);

                    this.toolForm.get('TopStabilizerBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade OD'] })?.value);
                    this.toolForm.get('TopStabilizerBodyOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Body OD'] })?.value);
                    this.toolForm.get('TopStabilizerBladeCount').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Count'] })?.value);
                    this.toolForm.get('TopStabilizerBladeWidth').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Width'] })?.value);
                    this.toolForm.get('TopStabilizerBladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Length'] })?.value);
                    this.toolForm.get('TopStabilizerBladeAngle').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Angle'] })?.value);
                    if (this.toolForm.get('TopStabilizerBladeOD').value) {
                        this.isTopStabilizerChecked = true;
                    }

                    this.toolForm.get('PowerSecStabilizerBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Powe section centralizer Blade OD'] })?.value);
                    this.toolForm.get('PowerSecStabilizerBodyOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Powe section centralizer Body OD'] })?.value);
                    this.toolForm.get('PowerSecStabilizerBladeCount').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Powe section centralizer Blade Count'] })?.value);
                    this.toolForm.get('PowerSecStabilizerBladeWidth').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Powe section centralizer Blade Width'] })?.value);
                    this.toolForm.get('PowerSecStabilizerBladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Powe section centralizer Blade Length'] })?.value);
                    this.toolForm.get('PowerSecStabilizerBladeAngle').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Powe section centralizer Blade Angle'] })?.value);
                    if (this.toolForm.get('PowerSecStabilizerBladeOD').value) {
                        this.isPowerSectionStabilizerChecked = true;
                    }

                    this.toolForm.get('CentralizerBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['IBS stator Blade OD'] })?.value);
                    this.toolForm.get('CentralizerBodyOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['IBS stator Body OD'] })?.value);
                    this.toolForm.get('CentralizerBladeCount').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['IBS stator Blade Count'] })?.value);
                    this.toolForm.get('CentralizerBladeWidth').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['IBS stator Blade Width'] })?.value);
                    this.toolForm.get('CentralizerBladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['IBS stator Blade Length'] })?.value);
                    this.toolForm.get('CentralizerBladeAngle').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['IBS stator Blade Angle'] })?.value);
                    if (this.toolForm.get('CentralizerBladeOD').value) {
                        this.isCentralizerChecked = true;
                    }

                    this.toolForm.get('KickPadBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Kick Pad Blade OD'] })?.value);
                    if (this.toolForm.get('KickPadBladeOD').value) {
                        this.isKickPadChecked = true;
                    }

                    this.toolForm.get('HousingTabBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Screw-on Blade OD'] })?.value);
                    this.toolForm.get('HousingTabBodyOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Screw-on Body OD'] })?.value);
                    this.toolForm.get('HousingTabBladeCount').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Screw-on Blade Count'] })?.value);
                    this.toolForm.get('HousingTabBladeWidth').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Screw-on Blade Width'] })?.value);
                    this.toolForm.get('HousingTabBladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Screw-on Blade Length'] })?.value);
                    this.toolForm.get('HousingTabBladeAngle').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Screw-on Blade Angle'] })?.value);
                    if (this.toolForm.get('HousingTabBladeOD').value) {
                        this.isHousingTabChecked = true;
                    }

                    this.toolForm.get('SRSBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['SRS Blade OD'] })?.value);
                    this.toolForm.get('SRSBodyOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['SRS Body OD'] })?.value);
                    this.toolForm.get('SRSBladeCount').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['SRS Blade Count'] })?.value);
                    this.toolForm.get('SRSBladeWidth').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['SRS Blade Width'] })?.value);
                    this.toolForm.get('SRSBladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['SRS Blade Length'] })?.value);
                    this.toolForm.get('SRSBladeAngle').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['SRS Blade Angle'] })?.value);
                    if (this.toolForm.get('SRSBladeOD').value) {
                        this.isSRSChecked = true;
                    }

                    this.toolForm.get('Nozzles').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Nozzles'] })?.value);
                    //nozzle section
                    this.nozzleArrayList = this.updateData.nozzleSections.map((item) => {
                        return item.value;
                    });
                    this.nozzleArrayListError = Array.from({ length: this.nozzleArrayList.length }, (_, index) => "");
                    if (this.nozzleArrayList.length > 0) {
                        this.isNozzleChecked = true;
                        this.toolForm.get('TFA').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['TFA'] })?.value);
                        this.toolForm.get('Efficiency').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Efficiency'] })?.value);
                    }

                    this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Connection configuration'] })?.value));
                    this.toolForm.get('TopThreadType').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Thread type'] })?.value);
                    this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top MUT n-m'] })?.value);
                    this.toolForm.get('TopTensileCapacity').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tensible capacity'] })?.value);
                    this.toolForm.get('BottomThreadType').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom thread type'] })?.value);
                    this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom MUT n-m'] })?.value);
                    this.toolForm.get('BottomTensileCapacity').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom tensible capacity'] })?.value);
                }
                else {

                    this.toolForm.get('Mass')?.patchValue(0.000);
                    this.toolForm.get('AdjustedWeight')?.patchValue(0.000);
                    this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
                }
                this.emitData();
            });

    }

    async getMaterialsDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.materialService.getMaterialsList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching materials");
        }
        return data;
    }//end of functions

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions


    async getConnectionsDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight() {
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if (this.toolForm.get('ToolWeightOption').value == 0) {
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            if (this.toolForm.get('Length').value)
                this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value / this.toolForm.get('Length').value);
            else
                this.toolForm.get('AdjustedWeight').patchValue(0);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value * this.toolForm.get('Length').value);
        }
        else if (this.toolForm.get('ToolWeightOption').value == 1) {
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value * this.toolForm.get('Length').value);
        }
        else if (this.toolForm.get('ToolWeightOption').value == 2) {
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value / this.toolForm.get('Length').value);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight() {
        if (this.toolForm.get('Length').value)
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value != 0 ? this.toolForm.get('Mass').value / this.toolForm.get('Length').value : 0);
        else
            this.toolForm.get('AdjustedWeight').patchValue(0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass() {
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value * this.toolForm.get('Length').value);
    }

    createNozzleInput(numOfNozzles) {
        this.nozzleArrayList = Array.from({ length: numOfNozzles }, (_, index) => "");
        this.nozzleArrayListError = Array.from({ length: numOfNozzles }, (_, index) => "");
    }



    validateNozzleDiameter(value, i) {
        if (value) {
            if (value < 0) {
                this.nozzleArrayListError[i] = "Nozzle Diameter should be greater than 0";
            }
            else {
                this.nozzleArrayListError[i] = "";
            }
        }
        else {
            this.nozzleArrayListError[i] = "Nozzle Diameter should be greater than 0";
        }
    }


    save() {

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());

        }
        this.nozzleArrayList.forEach((element, i) => {
            this.validateNozzleDiameter(element, i)
        });

        let nozzleFlag = true, sectionFlag = true;
        this.nozzleArrayListError.forEach((item) => {
            if (item) {
                nozzleFlag = false
            }
        });


        //console.log("validity flags", this.toolForm.valid, nozzleFlag);
        //call api below if all the flags are true
        if (this.toolForm.valid && nozzleFlag) {
            let payload = this.createPayload();
            //console.log(payload);
            if (this.updateData) {
                this.customToolService.updateCustomTool(this.templateId, payload).subscribe({
                    next: (data) => {
                        //console.log(data);
                        this.toastR.success("Custom Tool updated successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error: (error) => {
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else {

                this.customToolService.addCustomTool(payload).subscribe({
                    next: (data) => {
                        //console.log(data);
                        this.toastR.success("Custom Tool added successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error: (error) => {
                        this.toastR.error("Something went wrong");
                    }
                });
            }

        }
    }

    cancel() {
        this.formSubmitEvent.emit("cancel");
    }

    createPayload() {


        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem")
                },
                "toolValues": [
                    {
                        "Id": toolColumns['Length, m'],
                        "ColumnName": "Length, m",
                        "value": this.toolForm.get("Length").value
                    },

                    {
                        "Id": toolColumns['Tool weight option'],
                        "ColumnName": "Tool weight option",
                        "value": this.toolForm.get("ToolWeightOption").value
                    },
                    {
                        "Id": toolColumns['Tool Size, in'],
                        "ColumnName": "Tool Size, in",
                        "value": this.toolForm.get("ToolSize").value
                    },
                    {
                        "Id": toolColumns['Mass, kg'],
                        "ColumnName": "Mass, kg",
                        "value": this.toolForm.get('Mass').value
                    },

                    {
                        "Id": toolColumns['Adjusted kg/m'],
                        "ColumnName": "Adjusted kg/m",
                        "value": this.toolForm.get('AdjustedWeight').value
                    },
                    {
                        "Id": toolColumns['NW kg/m'],
                        "ColumnName": "NW kg/m",
                        "value": this.toolForm.get('NW').value
                    },

                    {
                        "Id": toolColumns['Material'],
                        "ColumnName": "Material",
                        "value": this.toolForm.get('Material').value
                    },
                    {
                        "Id": toolColumns['Adjustable setting'],
                        "ColumnName": "Adjustable setting",
                        "value": this.toolForm.get('AdjustableSettings').value
                    },
                    {
                        "Id": toolColumns['Operating differential pressure'],
                        "ColumnName": "Operating differential pressure",
                        "value": this.toolForm.get('OperatingDifferentialPressure').value
                    },

                    {
                        "Id": toolColumns['Speed ratio, rpm/lpm'],
                        "ColumnName": "Speed ratio, rpm/lpm",
                        "value": this.toolForm.get('SpeedRatio').value
                    },
                    {
                        "Id": toolColumns['Torque ratio, N-m/pa'],
                        "ColumnName": "Torque ratio, N-m/pa",
                        "value": this.toolForm.get('TorqueRatio').value
                    },
                    {
                        "Id": toolColumns['Hyd model'],
                        "ColumnName": "Hyd model",
                        "value": this.toolForm.get('HydModel').value
                    },
                    {
                        "Id": toolColumns['Pressure drop, kPa'],
                        "ColumnName": "Pressure drop, kPa",
                        "value": this.toolForm.get('PressureDrop').value
                    },
                    {
                        "Id": toolColumns['Flow rate, l/min'],
                        "ColumnName": "Flow rate, l/min",
                        "value": this.toolForm.get('FlowRate').value
                    },
                    {
                        "Id": toolColumns['Coefficient A'],
                        "ColumnName": "Coefficient A",
                        "value": this.toolForm.get('CoefficientA').value
                    },
                    {
                        "Id": toolColumns['Coefficient B'],
                        "ColumnName": "Coefficient B",
                        "value": this.toolForm.get('CoefficientB').value
                    },
                    {
                        "Id": toolColumns['Coefficient C'],
                        "ColumnName": "Coefficient C",
                        "value": this.toolForm.get('CoefficientC').value
                    },
                    {
                        "Id": toolColumns['Bearing pack Nominal OD, mm'],
                        "ColumnName": "Bearing pack Nominal OD, mm",
                        "value": this.toolForm.get('NominalOD').value
                    },
                    {
                        "Id": toolColumns['Bearing pack length, m'],
                        "ColumnName": "Bearing pack length, m",
                        "value": this.toolForm.get('BearingPackLength').value
                    },
                    {
                        "Id": toolColumns['Bit to bend length, m'],
                        "ColumnName": "Bit to bend length, m",
                        "value": this.toolForm.get('BitToBendLength').value
                    },
                    {
                        "Id": toolColumns['Bearing pack Max contact force, N'],
                        "ColumnName": "Bearing pack Max contact force, N",
                        "value": this.toolForm.get('BearingPackMaxContactForce').value
                    },
                    {
                        "Id": toolColumns['Bearing pack max von misses stress, MPa'],
                        "ColumnName": "Bearing pack max von misses stress, MPa",
                        "value": this.toolForm.get('BearingPackMaxVonMisesStress').value
                    },
                    {
                        "Id": toolColumns['Outer diameter, mm'],
                        "ColumnName": "Outer diameter, mm",
                        "value": this.toolForm.get('PowerSectionOD').value
                    },
                    {
                        "Id": toolColumns['Power section length, m'],
                        "ColumnName": "Power section length, m",
                        "value": this.toolForm.get('PowerSectionLength').value
                    },
                    {
                        "Id": toolColumns['Lobe configuration'],
                        "ColumnName": "Lobe configuration",
                        "value": this.toolForm.get('PowerSectionLobeConfig').value
                    },
                    {
                        "Id": toolColumns['Stages'],
                        "ColumnName": "Stages",
                        "value": this.toolForm.get('PowerSectionStages').value
                    },
                    {
                        "Id": toolColumns['Min flow rate, l/min'],
                        "ColumnName": "Min flow rate, l/min",
                        "value": this.toolForm.get('PowerSectionMinFlowRate').value
                    },
                    {
                        "Id": toolColumns['Max flow rate, l/min'],
                        "ColumnName": "Max flow rate, l/min",
                        "value": this.toolForm.get('PowerSectionMaxFlowRate').value
                    },
                    {
                        "Id": toolColumns['Max different pressure, kPa'],
                        "ColumnName": "Max different pressure, kPa",
                        "value": this.toolForm.get('PowerSectionMaxDiffPressure').value
                    },
                    {
                        "Id": toolColumns['Max torque, N-m'],
                        "ColumnName": "Max torque, N-m",
                        "value": this.toolForm.get('PowerSectionMaxTorque').value
                    },
                    {
                        "Id": toolColumns['Rotor mass, kg'],
                        "ColumnName": "Rotor mass, kg",
                        "value": this.toolForm.get('RotorMass').value
                    },
                    {
                        "Id": toolColumns['Rotor eccentracityv'],
                        "ColumnName": "Rotor eccentracityv",
                        "value": this.toolForm.get('RotorEccentricity').value
                    },
                    {
                        "Id": toolColumns['Rotor Max contact force, N'],
                        "ColumnName": "Rotor Max contact force, N",
                        "value": this.toolForm.get('RotorMaxContactForce').value
                    },
                    {
                        "Id": toolColumns['Rotor max von misses stress, MPa'],
                        "ColumnName": "Rotor max von misses stress, MPa",
                        "value": this.toolForm.get('RotorMaxVonMisesStress').value
                    },
                    {
                        "Id": toolColumns['Top sub Nominal OD, mm'],
                        "ColumnName": "Top sub Nominal OD, mm",
                        "value": this.toolForm.get('TopSubNominalOD').value
                    },
                    {
                        "Id": toolColumns['Top sub length, m'],
                        "ColumnName": "Top sub length, m",
                        "value": this.toolForm.get('TopSubLength').value
                    },
                    {
                        "Id": toolColumns['Top sub Max contact force, N'],
                        "ColumnName": "Top sub Max contact force, N",
                        "value": this.toolForm.get('TopSubMaxContactForce').value
                    },
                    {
                        "Id": toolColumns['Top sub max von misses stress, MPa'],
                        "ColumnName": "Top sub max von misses stress, MPa",
                        "value": this.toolForm.get('TopSubMaxVonMisesStress').value
                    },
                    {
                        "Id": toolColumns['Top stabilizer Blade OD'],
                        "ColumnName": "Top stabilizer Blade OD",
                        "value": this.toolForm.get('TopStabilizerBladeOD').value ? this.toolForm.get('TopStabilizerBladeOD').value : ""
                    },
                    {
                        "Id": toolColumns['Top stabilizer Body OD'],
                        "ColumnName": "Top stabilizer Body OD",
                        "value": this.toolForm.get('TopStabilizerBodyOD').value ? this.toolForm.get('TopStabilizerBodyOD').value : ""
                    },
                    {
                        "Id": toolColumns['Top stabilizer Blade Count'],
                        "ColumnName": "Top stabilizer Blade Count",
                        "value": this.toolForm.get('TopStabilizerBladeCount').value ? this.toolForm.get('TopStabilizerBladeCount').value : ""
                    },
                    {
                        "Id": toolColumns['Top stabilizer Blade Width'],
                        "ColumnName": "Top stabilizer Blade Width",
                        "value": this.toolForm.get('TopStabilizerBladeWidth').value ? this.toolForm.get('TopStabilizerBladeWidth').value : ""
                    },
                    {
                        "Id": toolColumns['Top stabilizer Blade Length'],
                        "ColumnName": "Top stabilizer Blade Length",
                        "value": this.toolForm.get('TopStabilizerBladeLength').value ? this.toolForm.get('TopStabilizerBladeLength').value : ""
                    },
                    {
                        "Id": toolColumns['Top stabilizer Blade Angle'],
                        "ColumnName": "Top stabilizer Blade Angle",
                        "value": this.toolForm.get('TopStabilizerBladeAngle').value ? this.toolForm.get('TopStabilizerBladeAngle').value : ""
                    },
                    {
                        "Id": toolColumns['Powe section centralizer Blade OD'],
                        "ColumnName": "Powe section centralizer Blade OD",
                        "value": this.toolForm.get('PowerSecStabilizerBladeOD').value ? this.toolForm.get('PowerSecStabilizerBladeOD').value : ""
                    },
                    {
                        "Id": toolColumns['Powe section centralizer Body OD'],
                        "ColumnName": "Powe section centralizer Body OD",
                        "value": this.toolForm.get('PowerSecStabilizerBodyOD').value ? this.toolForm.get('PowerSecStabilizerBodyOD').value : ""
                    },
                    {
                        "Id": toolColumns['Powe section centralizer Blade Count'],
                        "ColumnName": "Powe section centralizer Blade Count",
                        "value": this.toolForm.get('PowerSecStabilizerBladeCount').value ? this.toolForm.get('PowerSecStabilizerBladeCount').value : ""
                    },
                    {
                        "Id": toolColumns['Powe section centralizer Blade Width'],
                        "ColumnName": "Powe section centralizer Blade Width",
                        "value": this.toolForm.get('PowerSecStabilizerBladeWidth').value ? this.toolForm.get('PowerSecStabilizerBladeWidth').value : ""
                    },
                    {
                        "Id": toolColumns['Powe section centralizer Blade Length'],
                        "ColumnName": "Powe section centralizer Blade Length",
                        "value": this.toolForm.get('PowerSecStabilizerBladeLength').value ? this.toolForm.get('PowerSecStabilizerBladeLength').value : ""
                    },
                    {
                        "Id": toolColumns['Powe section centralizer Blade Angle'],
                        "ColumnName": "Powe section centralizer Blade Angle",
                        "value": this.toolForm.get('PowerSecStabilizerBladeAngle').value ? this.toolForm.get('PowerSecStabilizerBladeAngle').value : ""
                    },
                    {
                        "Id": toolColumns['IBS stator Blade OD'],
                        "ColumnName": "IBS stator Blade OD",
                        "value": this.toolForm.get('CentralizerBladeOD').value ? this.toolForm.get('CentralizerBladeOD').value : ""
                    },
                    {
                        "Id": toolColumns['IBS stator Body OD'],
                        "ColumnName": "IBS stator Body OD",
                        "value": this.toolForm.get('CentralizerBodyOD').value ? this.toolForm.get('CentralizerBodyOD').value : ""
                    },
                    {
                        "Id": toolColumns['IBS stator Blade Count'],
                        "ColumnName": "IBS stator Blade Count",
                        "value": this.toolForm.get('CentralizerBladeCount').value ? this.toolForm.get('CentralizerBladeCount').value : ""
                    },
                    {
                        "Id": toolColumns['IBS stator Blade Width'],
                        "ColumnName": "IBS stator Blade Width",
                        "value": this.toolForm.get('CentralizerBladeWidth').value ? this.toolForm.get('CentralizerBladeWidth').value : ""
                    },
                    {
                        "Id": toolColumns['IBS stator Blade Length'],
                        "ColumnName": "IBS stator Blade Length",
                        "value": this.toolForm.get('CentralizerBladeLength').value ? this.toolForm.get('CentralizerBladeLength').value : ""
                    },
                    {
                        "Id": toolColumns['IBS stator Blade Angle'],
                        "ColumnName": "IBS stator Blade Angle",
                        "value": this.toolForm.get('CentralizerBladeAngle').value ? this.toolForm.get('CentralizerBladeAngle').value : ""
                    },

                    {
                        "Id": toolColumns['Kick Pad Blade OD'],
                        "ColumnName": "Kick Pad Blade OD",
                        "value": this.toolForm.get('KickPadBladeOD').value ? this.toolForm.get('KickPadBladeOD').value : ""
                    },

                    {
                        "Id": toolColumns['Screw-on Blade OD'],
                        "ColumnName": "Screw-on Blade OD",
                        "value": this.toolForm.get('HousingTabBladeOD').value ? this.toolForm.get('HousingTabBladeOD').value : ""
                    },
                    {
                        "Id": toolColumns['Screw-on Body OD'],
                        "ColumnName": "Screw-on Body OD",
                        "value": this.toolForm.get('HousingTabBodyOD').value ? this.toolForm.get('HousingTabBodyOD').value : ""
                    },
                    {
                        "Id": toolColumns['Screw-on Blade Count'],
                        "ColumnName": "Screw-on Blade Count",
                        "value": this.toolForm.get('HousingTabBladeCount').value ? this.toolForm.get('HousingTabBladeCount').value : ""
                    },
                    {
                        "Id": toolColumns['Screw-on Blade Width'],
                        "ColumnName": "Screw-on Blade Width",
                        "value": this.toolForm.get('HousingTabBladeWidth').value ? this.toolForm.get('HousingTabBladeWidth').value : ""
                    },
                    {
                        "Id": toolColumns['Screw-on Blade Length'],
                        "ColumnName": "Screw-on Blade Length",
                        "value": this.toolForm.get('HousingTabBladeLength').value ? this.toolForm.get('HousingTabBladeLength').value : ""
                    },
                    {
                        "Id": toolColumns['Screw-on Blade Angle'],
                        "ColumnName": "Screw-on Blade Angle",
                        "value": this.toolForm.get('HousingTabBladeAngle').value ? this.toolForm.get('HousingTabBladeAngle').value : ""
                    },

                    {
                        "Id": toolColumns['SRS Blade OD'],
                        "ColumnName": "SRS Blade OD",
                        "value": this.toolForm.get('SRSBladeOD').value ? this.toolForm.get('SRSBladeOD').value : ""
                    },
                    {
                        "Id": toolColumns['SRS Body OD'],
                        "ColumnName": "SRS Body OD",
                        "value": this.toolForm.get('SRSBodyOD').value ? this.toolForm.get('SRSBodyOD').value : ""
                    },
                    {
                        "Id": toolColumns['SRS Blade Count'],
                        "ColumnName": "SRS Blade Count",
                        "value": this.toolForm.get('SRSBladeCount').value ? this.toolForm.get('SRSBladeCount').value : ""
                    },
                    {
                        "Id": toolColumns['SRS Blade Width'],
                        "ColumnName": "SRS Blade Width",
                        "value": this.toolForm.get('SRSBladeWidth').value ? this.toolForm.get('SRSBladeWidth').value : ""
                    },
                    {
                        "Id": toolColumns['SRS Blade Length'],
                        "ColumnName": "SRS Blade Length",
                        "value": this.toolForm.get('SRSBladeLength').value ? this.toolForm.get('SRSBladeLength').value : ""
                    },
                    {
                        "Id": toolColumns['SRS Blade Angle'],
                        "ColumnName": "SRS Blade Angle",
                        "value": this.toolForm.get('SRSBladeAngle').value ? this.toolForm.get('SRSBladeAngle').value : ""
                    },

                    {
                        "Id": toolColumns['Connection configuration'],
                        "ColumnName": "Connection configuration",
                        "value": this.toolForm.get('ConnectionConfiguration').value

                    },
                    {
                        "Id": toolColumns['TFA'],
                        "ColumnName": "TFA",
                        "value": this.toolForm.get('TFA').value ? this.toolForm.get('TFA').value : ""
                    },
                    {
                        "Id": toolColumns['Efficiency'],
                        "ColumnName": "Efficiency",
                        "value": this.toolForm.get('Efficiency').value ? this.toolForm.get('Efficiency').value : ""
                    },
                    {
                        "Id": toolColumns['Nozzles'],
                        "ColumnName": "Nozzles",
                        "value": this.toolForm.get('Nozzles').value
                    },
                    {
                        "Id": toolColumns['Thread type'],
                        "ColumnName": "Thread type",
                        "value": this.toolForm.get('TopThreadType').value
                    },
                    {
                        "Id": toolColumns['Top MUT n-m'],
                        "ColumnName": "Top MUT n-m",
                        "value": this.toolForm.get('TopMUT').value
                    },
                    {
                        "Id": toolColumns['Tensible capacity'],
                        "ColumnName": "Tensible capacity",
                        "value": this.toolForm.get('TopTensileCapacity').value
                    },
                    {
                        "Id": toolColumns['Bottom thread type'],
                        "ColumnName": "Bottom thread type",
                        "value": this.toolForm.get('TopThreadType').value
                    },
                    {
                        "Id": toolColumns['Bottom MUT n-m'],
                        "ColumnName": "Bottom MUT n-m",
                        "value": this.toolForm.get('TopMUT').value
                    },
                    {
                        "Id": toolColumns['Bottom tensible capacity'],
                        "ColumnName": "Bottom tensible capacity",
                        "value": this.toolForm.get('BottomTensileCapacity').value
                    },
                ]

                ,
                "nozzleSections": this.nozzleArrayList.map((item) => {
                    return {
                        "Id": toolColumns['Nozzle Diameter, x 1/32'],
                        "ColumnName": "Nozzle Diameter, x 1/32",
                        "value": item
                    }
                })

            }

        }

        return payload;
    }

    nozzleCheckboxChanged(event) {
        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('TFA').setValidators([Validators.required, Validators.min(1)]);
            this.toolForm.get('Efficiency').setValidators([Validators.required, Validators.max(100), Validators.min(0)]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('TFA').setValidators([Validators.min(1)]);
            this.toolForm.get('Efficiency').setValidators([Validators.max(100), Validators.min(0)]);

        }
        this.toolForm.get('Efficiency').updateValueAndValidity();
        this.toolForm.get('TFA').updateValueAndValidity();
        this.toolForm.get('TFA').patchValue('');
        this.toolForm.get('Efficiency').patchValue('');
        this.toolForm.get('Nozzles').patchValue('');
        this.nozzleArrayList = [];
        this.nozzleArrayListError = [];
    }

    topStabilizerCheckboxChanged(event) {
        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('TopStabilizerBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('TopStabilizerBodyOD').setValidators([]);
            this.toolForm.get('TopStabilizerBladeCount').setValidators([Validators.required, Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('TopStabilizerBladeWidth').setValidators([Validators.required]);
            this.toolForm.get('TopStabilizerBladeLength').setValidators([Validators.required]);
            this.toolForm.get('TopStabilizerBladeAngle').setValidators([Validators.required]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('TopStabilizerBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('TopStabilizerBodyOD').setValidators([]);
            this.toolForm.get('TopStabilizerBladeCount').setValidators([Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('TopStabilizerBladeWidth').setValidators([]);
            this.toolForm.get('TopStabilizerBladeLength').setValidators([]);
            this.toolForm.get('TopStabilizerBladeAngle').setValidators([]);

        }
        this.toolForm.get('TopStabilizerBladeOD').updateValueAndValidity();
        this.toolForm.get('TopStabilizerBodyOD').updateValueAndValidity();
        this.toolForm.get('TopStabilizerBladeCount').updateValueAndValidity();
        this.toolForm.get('TopStabilizerBladeWidth').updateValueAndValidity();
        this.toolForm.get('TopStabilizerBladeLength').updateValueAndValidity();
        this.toolForm.get('TopStabilizerBladeAngle').updateValueAndValidity();

        this.toolForm.get('TopStabilizerBladeOD').patchValue('');
        this.toolForm.get('TopStabilizerBodyOD').patchValue(4.750);
        this.toolForm.get('TopStabilizerBladeCount').patchValue('');
        this.toolForm.get('TopStabilizerBladeWidth').patchValue('');
        this.toolForm.get('TopStabilizerBladeLength').patchValue('');
        this.toolForm.get('TopStabilizerBladeAngle').patchValue('');
    }

    powerSectionStabilizerCheckboxChanged(event) {
        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('PowerSecStabilizerBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('PowerSecStabilizerBodyOD').setValidators([]);
            this.toolForm.get('PowerSecStabilizerBladeCount').setValidators([Validators.required, Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('PowerSecStabilizerBladeWidth').setValidators([Validators.required]);
            this.toolForm.get('PowerSecStabilizerBladeLength').setValidators([Validators.required]);
            this.toolForm.get('PowerSecStabilizerBladeAngle').setValidators([Validators.required]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('PowerSecStabilizerBladeOD').setValidators([CustomValidators.greaterThanZero, Validators.min(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('PowerSecStabilizerBodyOD').setValidators([]);
            this.toolForm.get('PowerSecStabilizerBladeCount').setValidators([Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('PowerSecStabilizerBladeWidth').setValidators([]);
            this.toolForm.get('PowerSecStabilizerBladeLength').setValidators([]);
            this.toolForm.get('PowerSecStabilizerBladeAngle').setValidators([]);

        }
        this.toolForm.get('PowerSecStabilizerBladeOD').updateValueAndValidity();
        this.toolForm.get('PowerSecStabilizerBodyOD').updateValueAndValidity();
        this.toolForm.get('PowerSecStabilizerBladeCount').updateValueAndValidity();
        this.toolForm.get('PowerSecStabilizerBladeWidth').updateValueAndValidity();
        this.toolForm.get('PowerSecStabilizerBladeLength').updateValueAndValidity();
        this.toolForm.get('PowerSecStabilizerBladeAngle').updateValueAndValidity();

        this.toolForm.get('PowerSecStabilizerBladeOD').patchValue('');
        this.toolForm.get('PowerSecStabilizerBodyOD').patchValue(4.750);
        this.toolForm.get('PowerSecStabilizerBladeCount').patchValue('');
        this.toolForm.get('PowerSecStabilizerBladeWidth').patchValue('');
        this.toolForm.get('PowerSecStabilizerBladeLength').patchValue('');
        this.toolForm.get('PowerSecStabilizerBladeAngle').patchValue('');
    }

    centralizerCheckboxChanged(event) {
        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('CentralizerBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('CentralizerBodyOD').setValidators([]);
            this.toolForm.get('CentralizerBladeCount').setValidators([Validators.required, Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('CentralizerBladeWidth').setValidators([Validators.required]);
            this.toolForm.get('CentralizerBladeLength').setValidators([Validators.required]);
            this.toolForm.get('CentralizerBladeAngle').setValidators([Validators.required]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('CentralizerBladeOD').setValidators([CustomValidators.greaterThanZero, Validators.min(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('CentralizerBodyOD').setValidators([]);
            this.toolForm.get('CentralizerBladeCount').setValidators([Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('CentralizerBladeWidth').setValidators([]);
            this.toolForm.get('CentralizerBladeLength').setValidators([]);
            this.toolForm.get('CentralizerBladeAngle').setValidators([]);

        }
        this.toolForm.get('CentralizerBladeOD').updateValueAndValidity();
        this.toolForm.get('CentralizerBodyOD').updateValueAndValidity();
        this.toolForm.get('CentralizerBladeCount').updateValueAndValidity();
        this.toolForm.get('CentralizerBladeWidth').updateValueAndValidity();
        this.toolForm.get('CentralizerBladeLength').updateValueAndValidity();
        this.toolForm.get('CentralizerBladeAngle').updateValueAndValidity();

        this.toolForm.get('CentralizerBladeOD').patchValue('');
        this.toolForm.get('CentralizerBodyOD').patchValue(4.750);
        this.toolForm.get('CentralizerBladeCount').patchValue('');
        this.toolForm.get('CentralizerBladeWidth').patchValue('');
        this.toolForm.get('CentralizerBladeLength').patchValue('');
        this.toolForm.get('CentralizerBladeAngle').patchValue('');
    }

    kickPadCheckboxChanged(event) {

        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('KickPadBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('KickPadBladeOD').setValidators([CustomValidators.greaterThanZero, Validators.min(this.toolForm.get('TopSubNominalOD').value)]);
        }
        this.toolForm.get('KickPadBladeOD').updateValueAndValidity();

        this.toolForm.get('KickPadBladeOD').patchValue('');

    }


    housingTabCheckboxChanged(event) {
        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('HousingTabBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('HousingTabBodyOD').setValidators([]);
            this.toolForm.get('HousingTabBladeCount').setValidators([Validators.required, Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('HousingTabBladeWidth').setValidators([Validators.required]);
            this.toolForm.get('HousingTabBladeLength').setValidators([Validators.required]);
            this.toolForm.get('HousingTabBladeAngle').setValidators([Validators.required]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('HousingTabBladeOD').setValidators([CustomValidators.greaterThanZero, Validators.min(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('HousingTabBodyOD').setValidators([]);
            this.toolForm.get('HousingTabBladeCount').setValidators([Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('HousingTabBladeWidth').setValidators([]);
            this.toolForm.get('HousingTabBladeLength').setValidators([]);
            this.toolForm.get('HousingTabBladeAngle').setValidators([]);

        }
        this.toolForm.get('HousingTabBladeOD').updateValueAndValidity();
        this.toolForm.get('HousingTabBodyOD').updateValueAndValidity();
        this.toolForm.get('HousingTabBladeCount').updateValueAndValidity();
        this.toolForm.get('HousingTabBladeWidth').updateValueAndValidity();
        this.toolForm.get('HousingTabBladeLength').updateValueAndValidity();
        this.toolForm.get('HousingTabBladeAngle').updateValueAndValidity();

        this.toolForm.get('HousingTabBladeOD').patchValue('');
        this.toolForm.get('HousingTabBodyOD').patchValue(4.750);
        this.toolForm.get('HousingTabBladeCount').patchValue('');
        this.toolForm.get('HousingTabBladeWidth').patchValue('');
        this.toolForm.get('HousingTabBladeLength').patchValue('');
        this.toolForm.get('HousingTabBladeAngle').patchValue('');
    }

    SRSCheckboxChanged(event) {
        // Do something with the event or checkbox state
        if (event) {
            //console.log("Checkbox is checked");
            this.toolForm.get('SRSBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('SRSBodyOD').setValidators([]);
            this.toolForm.get('SRSBladeCount').setValidators([Validators.required, Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('SRSBladeWidth').setValidators([Validators.required]);
            this.toolForm.get('SRSBladeLength').setValidators([Validators.required]);
            this.toolForm.get('SRSBladeAngle').setValidators([Validators.required]);

        } else {
            //console.log("Checkbox is unchecked");
            this.toolForm.get('SRSBladeOD').setValidators([CustomValidators.greaterThanZero, Validators.min(this.toolForm.get('TopSubNominalOD').value)]);
            this.toolForm.get('SRSBodyOD').setValidators([]);
            this.toolForm.get('SRSBladeCount').setValidators([Validators.max(1000000000), Validators.min(-1000000000)]);
            this.toolForm.get('SRSBladeWidth').setValidators([]);
            this.toolForm.get('SRSBladeLength').setValidators([]);
            this.toolForm.get('SRSBladeAngle').setValidators([]);

        }
        this.toolForm.get('SRSBladeOD').updateValueAndValidity();
        this.toolForm.get('SRSBodyOD').updateValueAndValidity();
        this.toolForm.get('SRSBladeCount').updateValueAndValidity();
        this.toolForm.get('SRSBladeWidth').updateValueAndValidity();
        this.toolForm.get('SRSBladeLength').updateValueAndValidity();
        this.toolForm.get('SRSBladeAngle').updateValueAndValidity();

        this.toolForm.get('SRSBladeOD').patchValue('');
        this.toolForm.get('SRSBodyOD').patchValue(4.750);
        this.toolForm.get('SRSBladeCount').patchValue('');
        this.toolForm.get('SRSBladeWidth').patchValue('');
        this.toolForm.get('SRSBladeLength').patchValue('');
        this.toolForm.get('SRSBladeAngle').patchValue('');
    }
    resetThreadtype() {
        if (this.updateData) {
            let connectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Thread type'] })?.value
            if (connectionId)
                this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
            this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top MUT n-m'] })?.value);
            if (this.toolForm.get('ConnectionConfiguration').value != 6 && this.toolForm.get('ConnectionConfiguration').value != 5) {
                let bottomconnectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom thread type'] })?.value
                if (bottomconnectionId)
                    this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
                this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom MUT n-m'] })?.value);
            }

        }
        else {
            this.toolForm.get('TopThreadType').patchValue('');
            this.toolForm.get('TopMUT').patchValue('');
            this.toolForm.get('BottomThreadType').patchValue('');
            this.toolForm.get('BottomMUT').patchValue('');

        }
    }

    emitData() {
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value
        });
    }

    /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
    getActiveUnitSystemData() {

        // this.unitSystemData = {};
        this.unitsService.getActiveUnitSystemDetails().subscribe({
            next: (res) => {
                if (res) {
                    //console.log("res in casing---", res);
                    let activeUnitSystemData = res;
                    this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                    this.lengthLabel = activeUnitSystemData.length.unitValue;
                    this.massLabel = activeUnitSystemData.mass.unitValue;
                    this.linearMassDensityLabel = activeUnitSystemData.linearMassDensity.unitValue;
                    this.torqueLabel = activeUnitSystemData.torque.unitValue;
                    this.percentageLabel = activeUnitSystemData.percentage.unitValue;
                    this.forceLabel = activeUnitSystemData.force.unitValue;
                    this.stressLabel = activeUnitSystemData.stress.unitValue;
                    this.nozzleSizeLabel = activeUnitSystemData.nozzleSize.unitValue;
                    this.rotationVelocityLabel = activeUnitSystemData.rotationVelocity.unitValue;
                    this.angleLabel = activeUnitSystemData.angle.unitValue;
                    this.pressureLabel=activeUnitSystemData.pressure.unitValue;
                    this.flowLabel=activeUnitSystemData.flow.unitValue;
                    // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

                } else {
                    //console.log('error');
                }
            },
            error: (error) => {
                //console.log("Unit", error.error.result);
            }
        })
    }
}
