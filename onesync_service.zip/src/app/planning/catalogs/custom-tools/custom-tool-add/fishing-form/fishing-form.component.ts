import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { DCVType } from 'src/app/core/enum/custom-tools/dcvType.enum';
import { FishingType } from 'src/app/core/enum/custom-tools/fishingType.enum';
import { ToolConfiguration } from 'src/app/core/enum/custom-tools/toolConfigurations.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-fishing-form',
  templateUrl: './fishing-form.component.html'
})
export class FishingFormComponent implements OnInit,OnChanges{
    @Input() Tool: any;
    @Input() updateData: any;
    @Input() templateId: any;
    @Output()
    formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
    @Output()
    threeDParams = new EventEmitter<any>();
    toolForm: FormGroup;
    toolSizeOptions:any = [];
    toolWeightOptions:any = [];
    threadTypeOptions: any = [];
    materialOptions:any = [];
    nozzleArrayList:any = [];
    nozzleArrayListError: any[] = []; 
    isNozzleChecked: boolean = false;
    typeOptions: any = [
    ];
    connconfOptions: any = [
    ];
    toolConfOptions: any = [];
    isNozzleDisabled:boolean = true;
    show: any = {
        Body:false,
        BasketGauge:false,
        GaugeBody:false,
        Gauge:false,
        StopSub:false,
        BottomSub:false,
        Grapple:false,
        Fishneck:false,
        Spear:false
    };
    filteredToolSizeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolSize: FormControl = new FormControl();
    filteredTopThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlTopThreadType: FormControl = new FormControl();
    filteredBottomThreadTypeOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlBottomThreadType: FormControl = new FormControl();
    filteredMaterialOptions : ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlMaterials: FormControl = new FormControl();
    fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControl: FormControl = new FormControl();
    filterControltype: FormControl = new FormControl();
    fileteredtypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControltoolConf: FormControl = new FormControl();
    fileteredtoolConfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    filterControlconn: FormControl = new FormControl();
    fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    shortLengthLabel: string = "";//(in or mm)
    lengthLabel: string = "";//(ft or m)
    massLabel: string = "";// (lbm or Kg)
    linearMassDensityLabel: string = "";// (lb/ft or kg/m)
    torqueLabel: string = "";// (lbf-ft or N-m)
    percentageLabel: string = "";//%
    forceLabel: string = "";//lbf or N
    stressLabel: string = "";//ksi or MPa
    nozzleSizeLabel: string = "";//x 1/32" or mm
    rotationVelocityLabel: string = "";//rpm
    pressureLabel: string = "";//(kPa or psi)
    flowLabel: string = "";//l/min or gal/min
    angleLabel: string = "";//°

    constructor(
        private formBuilder: FormBuilder,
        private materialService: MaterialsService,
        private customToolService: CustomToolService,
        private connectionService:ConnectionService,
        private toastR: ToastrService,
        private unitsService: UnitsService,
      ) {
       
        
      }
    ngOnInit(): void {
        
    }
    ngOnChanges(){
       this.getActiveUnitSystemData();
        this.toolWeightOptions = [];
        for(const toolweightKey of Object.keys(ToolWeightOption)){
            this.toolWeightOptions.push({label:toolweightKey,value:parseInt(ToolWeightOption[toolweightKey])});
        }
        this.connconfOptions = [];
        for(const conconfKey of Object.keys(ConnectionConfiguration)){
            this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
        }

        this.typeOptions = [];
        for(const fishingtypeKey of Object.keys(FishingType)){
            this.typeOptions.push({label:fishingtypeKey,value:parseInt(FishingType[fishingtypeKey])});
        }


        this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
        this.filterControl
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.toolWeightOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolWeightOptions.next(filteredList);
          }
        }); 

        this.fileteredtypeOptions.next(this.typeOptions);
        this.filterControltype
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControltype.value.toLowerCase();
            let filteredList = this.typeOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtypeOptions.next(filteredList);
          }
        }); 

      

        this.fileteredconnconfOptions.next(this.connconfOptions);
        this.filterControlconn
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControlconn.value.toLowerCase();
            let filteredList = this.connconfOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredconnconfOptions.next(filteredList);
          }
        }); 
        
        //console.log("Tool conf options", this.toolConfOptions);
        this.toolForm = this.formBuilder.group({
            Type:  ['', [Validators.required]],
            ToolConfiguration:['', [Validators.required]],
            ToolSize: ['', [Validators.required]],
            Description: ['', [Validators.required, CustomValidators.noContinuousSpaces]],
            Length:[0.00, [Validators.required]],
            ToolWeightOption:['',[Validators.required]],
            Mass:['',[]],
            AdjustedWeight:['',[]],
            NW:['',[]],
            Material:['',[Validators.required]],
            ConnectionConfiguration:['',[Validators.required]],
            TopThreadType:['',[Validators.required]],
            TopMUT:['',[Validators.required]],
            BottomThreadType:['',[Validators.required]],
            BottomMUT:['',[Validators.required]],
            TFA:['',[CustomValidators.greaterThanMin(0)]],
            Efficiency:['',[Validators.min(0),Validators.max(100)]],
            Nozzles:['',[Validators.min(0),Validators.max(1000)]],
            BodyOD:['',[CustomValidators.greaterThanMin(0)]],
            BodyID:['',[CustomValidators.greaterThanMin(0)]],
            BodyLength:['',[Validators.min(0),Validators.max(30.48)]],
            FishneckOD:['',[CustomValidators.greaterThanMin(0)]],
            FishneckID:['',[CustomValidators.greaterThanMin(0)]],
            FishneckLength:['',[Validators.min(0),Validators.max(30.48)]],
            BasketGaugeOD:['',[CustomValidators.greaterThanMin(0)]],
            BasketGaugeID:['',[CustomValidators.greaterThanMin(0)]],
            BasketGaugeLength:['',[Validators.min(0),Validators.max(30.48)]],
            GaugeOD:['',[CustomValidators.greaterThanMin(0)]],
            GaugeID:['',[CustomValidators.greaterThanMin(0)]],
            GaugeLength:['',[Validators.min(0),Validators.max(30.48)]],
            GaugeBodyOD:['',[CustomValidators.greaterThanMin(0)]],
            GaugeBodyID:['',[CustomValidators.greaterThanMin(0)]],
            GaugeBodyLength:['',[Validators.min(0),Validators.max(30.48)]],
            StopSubOD:['',[CustomValidators.greaterThanMin(0)]],
            StopSubID:['',[CustomValidators.greaterThanMin(0)]],
            StopSubLength:['',[Validators.min(0),Validators.max(30.48)]],
            BottomSubOD:['',[CustomValidators.greaterThanMin(0)]],
            BottomSubID:['',[CustomValidators.greaterThanMin(0)]],
            BottomSubLength:['',[Validators.min(0),Validators.max(30.48)]],
            GrappleOD:['',[CustomValidators.greaterThanMin(0)]],
            GrappleID:['',[CustomValidators.greaterThanMin(0)]],
            GrappleLength:['',[Validators.min(0),Validators.max(30.48)]],
            SpearOD:['',[CustomValidators.greaterThanMin(0)]],
            SpearID:['',[CustomValidators.greaterThanMin(0)]],
            SpearLength:['',[Validators.min(0),Validators.max(30.48)]],
          });
          
          this.toolForm.get('Length')?.disable();
          this.toolForm.get('Type').valueChanges.subscribe((value) => {
            if(!this.updateData){
                this.toolForm.get('BodyOD').patchValue('');
                this.toolForm.get('BodyID').patchValue('');
                this.toolForm.get('BodyLength').patchValue('');
                this.toolForm.get('BasketGaugeOD').patchValue('');
                this.toolForm.get('BasketGaugeID').patchValue('');
                this.toolForm.get('BasketGaugeLength').patchValue('');
                this.toolForm.get('GaugeBodyOD').patchValue('');
                this.toolForm.get('GaugeBodyID').patchValue('');
                this.toolForm.get('GaugeBodyLength').patchValue('');
                this.toolForm.get('GaugeOD').patchValue('');
                this.toolForm.get('GaugeID').patchValue('');
                this.toolForm.get('GaugeLength').patchValue('');
                this.toolForm.get('StopSubOD').patchValue('');
                this.toolForm.get('StopSubID').patchValue('');
                this.toolForm.get('StopSubLength').patchValue('');
                this.toolForm.get('BottomSubOD').patchValue('');
                this.toolForm.get('BottomSubID').patchValue('');
                this.toolForm.get('BottomSubLength').patchValue('');
                this.toolForm.get('GrappleOD').patchValue('');
                this.toolForm.get('GrappleID').patchValue('');
                this.toolForm.get('GrappleLength').patchValue('');
                this.toolForm.get('FishneckOD').patchValue('');
                this.toolForm.get('FishneckID').patchValue('');
                this.toolForm.get('FishneckLength').patchValue('');
                this.toolForm.get('SpearOD').patchValue('');
                this.toolForm.get('SpearID').patchValue('');
                this.toolForm.get('SpearLength').patchValue('');
                this.toolForm.get('ConnectionConfiguration').patchValue('');
            }

                this.toolConfOptions = ToolConfiguration[value];
                this.fileteredtoolConfOptions.next(this.toolConfOptions);
                this.filterControltoolConf
                .valueChanges
                .subscribe({
                  next: () => {
                    let filter = this.filterControltoolConf.value.toLowerCase();
                    let filteredList = this.toolConfOptions.filter(
                      option => option.label.toLowerCase().indexOf(filter) >= 0
                    );
                    this.fileteredtoolConfOptions.next(filteredList);
                  }
                });                                                                      
            //Basket
            if(value==1){
                this.isNozzleDisabled = false;
                this.connconfOptions = [];
                this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:true,
                    BasketGauge:true,
                    GaugeBody:false,
                    Gauge:false,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:true,
                    Spear:false
                }
                
            }
            //Casing Repair
            else if(value==2){
                this.isNozzleDisabled = true;
                this.isNozzleChecked = false;
                this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                this.connconfOptions = [];
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    //console.log(parseInt(ConnectionConfiguration[conconfKey]));
                    if(parseInt(ConnectionConfiguration[conconfKey])==6 || parseInt(ConnectionConfiguration[conconfKey])==5){
                        this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                    }
                }
                this.show = {
                    Body:false,
                    BasketGauge:false,
                    GaugeBody:true,
                    Gauge:false,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:true,
                    Spear:false
                }
            }
            //Clean Out
            else if(value==3){
                this.isNozzleDisabled = false;
                this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                this.connconfOptions = [];
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:true,
                    BasketGauge:false,
                    GaugeBody:false,
                    Gauge:true,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:true,
                    Spear:false
                }
            }
            //Cutter
            else if(value==4){
                this.isNozzleDisabled = false;
                this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                this.connconfOptions = [];
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:true,
                    BasketGauge:false,
                    GaugeBody:false,
                    Gauge:false,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:true,
                    Spear:false
                }
            }
            //External Catch
            else if(value==5){
                this.isNozzleDisabled = true;
                this.isNozzleChecked = false;
                this.toolForm.get('ToolConfiguration').setValidators([]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                this.connconfOptions = [];
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    if(parseInt(ConnectionConfiguration[conconfKey])==6 || parseInt(ConnectionConfiguration[conconfKey])==5)
                        this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:true,
                    BasketGauge:false,
                    GaugeBody:false,
                    Gauge:false,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:true,
                    Spear:false
                }
            }
            //Internal Catch
            else if(value==6){
                this.isNozzleDisabled = true;
                this.isNozzleChecked = false;
                this.connconfOptions = [];
                this.toolForm.get('ToolConfiguration').setValidators([]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:false,
                    BasketGauge:false,
                    GaugeBody:false,
                    Gauge:false,
                    StopSub:true,
                    BottomSub:true,
                    Grapple:true,
                    Fishneck:true,
                    Spear:false
                }
            }
            //Rope Spear
            else if(value==7){
                this.isNozzleDisabled = true;
                this.isNozzleChecked = false;
                this.toolForm.get('ToolConfiguration').setValidators([]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                this.connconfOptions = [];
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    if(parseInt(ConnectionConfiguration[conconfKey])==6 || parseInt(ConnectionConfiguration[conconfKey])==5)
                        this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:true,
                    BasketGauge:false,
                    GaugeBody:false,
                    Gauge:false,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:true,
                    Spear:true
                }
            }
            //Washover
            else if(value==8){
                this.isNozzleDisabled = true;
                this.isNozzleChecked = false;
                this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
                this.toolForm.get('ToolConfiguration').patchValue('');
                this.toolForm.get('ToolConfiguration').updateValueAndValidity();
                this.connconfOptions = [];
                for(const conconfKey of Object.keys(ConnectionConfiguration)){
                    this.connconfOptions.push({label:conconfKey,value:parseInt(ConnectionConfiguration[conconfKey])});
                }
                this.show = {
                    Body:true,
                    BasketGauge:false,
                    GaugeBody:false,
                    Gauge:false,
                    StopSub:false,
                    BottomSub:false,
                    Grapple:false,
                    Fishneck:false,
                    Spear:false
                }
            }
            
          });

          this.toolForm.get('BodyOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('BodyID').setValidators([Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('BodyID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('BodyID').updateValueAndValidity();
          });

          this.toolForm.get('FishneckOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('FishneckID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('FishneckID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('FishneckID').updateValueAndValidity();
          });

          this.toolForm.get('BasketGaugeOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('BasketGaugeID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('BasketGaugeID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('BasketGaugeID').updateValueAndValidity();
          });

          this.toolForm.get('GaugeOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('GaugeID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('GaugeID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('GaugeID').updateValueAndValidity();
          });

          this.toolForm.get('GaugeBodyOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('GaugeBodyID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('GaugeBodyID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('GaugeBodyID').updateValueAndValidity();
          });

          this.toolForm.get('StopSubOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('StopSubID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
           }
            else{
                this.toolForm.get('StopSubID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('StopSubID').updateValueAndValidity();
          });

          this.toolForm.get('BottomSubOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('BottomSubID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('BottomSubID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('BottomSubID').updateValueAndValidity();
          });

          this.toolForm.get('GrappleOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('GrappleID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
           }
            else{
                this.toolForm.get('GrappleID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('GrappleID').updateValueAndValidity();
          });

          this.toolForm.get('SpearOD').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            const maxLimit = value; // Change this logic as needed
            if(value){
            this.toolForm.get('SpearID').setValidators([CustomValidators.greaterThanMin(0),Validators.required, CustomValidators.lessThanMax(maxLimit)]);
            }
            else{
                this.toolForm.get('SpearID').setValidators([CustomValidators.greaterThanMin(0)]);
            }
            this.toolForm.get('SpearID').updateValueAndValidity();
          });
          this.toolForm.get('ConnectionConfiguration').valueChanges.subscribe((value) => {
            // Adjust the max value dynamically based on inputA value
            if(value==2 || value==5){
            this.toolForm.get('BottomThreadType').setValidators([]);
            this.toolForm.get('BottomMUT').setValidators([]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
        else{
            this.toolForm.get('BottomThreadType').setValidators([Validators.required]);
            this.toolForm.get('BottomMUT').setValidators([Validators.required]);
            this.toolForm.get('BottomThreadType').updateValueAndValidity();
            this.toolForm.get('BottomMUT').updateValueAndValidity();
        }
          });

          
          this.getToolSizeDropdown()
          .then((data)=>{
              //console.log("tool sizes", data.result);
              this.toolSizeOptions = [];
              this.toolSizeOptions = data.result.map(item=>item.NominalOD);
              this.filteredToolSizeOptions.next(this.toolSizeOptions);
              this.filterControltoolSize
                  .valueChanges
                  .subscribe({
                      next: () => {
                          let filter = this.filterControltoolSize.value.toString().toLowerCase();
                          let filteredList = this.toolSizeOptions.filter(
                              option => option.toString().toLowerCase().indexOf(filter) >= 0
                          );
                          this.filteredToolSizeOptions.next(filteredList);
                      }
                  });
      
              return this.getConnectionsDropdown();
          })
          .then((data)=>{
            this.threadTypeOptions = [...data.result];
            this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlTopThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlTopThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredTopThreadTypeOptions.next(filteredList);
              }
            }); 

            this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
            this.filterControlBottomThreadType
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlBottomThreadType.value.toLowerCase();
                let filteredList = this.threadTypeOptions.filter(
                  option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredBottomThreadTypeOptions.next(filteredList);
              }
            }); 
            //get materials
            return this.getMaterialsDropdown();
          })
          .then((data)=>{
            this.materialOptions = [...data.result];
            this.filteredMaterialOptions.next(this.materialOptions);
            this.filterControlMaterials
            .valueChanges
            .subscribe({
              next: () => {
                let filter = this.filterControlMaterials.value.toLowerCase();
                let filteredList = this.materialOptions.filter(
                  option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
                );
                this.filteredMaterialOptions.next(filteredList);
              }
            }); 
            return new Promise((resolve)=>{resolve("success")});
          })
          .then((data)=>{
            //console.log("received data in bit form",this.updateData);
            if(this.updateData){
                //set values in form
                let toolsize = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool Size, in']} )?.value;
                if(toolsize)
                    this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
                let typeId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Fishing type']} )?.value;
                if(typeId)
                    this.toolForm.get('Type').patchValue(parseInt(typeId));
                this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
                this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Length, m']} )?.value);
                let toolweightoption = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool weight option']} )?.value;
                this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
                if(this.toolForm.get('ToolWeightOption').value == 0){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value == 1){
                    this.toolForm.get('AdjustedWeight').enable();
                    this.toolForm.get('Mass').disable();
                }
                else if(this.toolForm.get('ToolWeightOption').value==2){
                    this.toolForm.get('AdjustedWeight').disable();
                    this.toolForm.get('Mass').enable();
                }
                this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Mass, kg']} )?.value);
                this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Adjusted kg/m']} )?.value);
                this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['NW kg/m']} )?.value);
                let toolconfId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Tool configuration']} )?.value
                if(toolconfId)
                    this.toolForm.get('ToolConfiguration').patchValue(parseInt(toolconfId));
                let materialId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Material']} )?.value;
                if(materialId)
                    this.toolForm.get('Material').patchValue(parseInt(materialId));
               
                
                let connConfId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Connection configuration']} )?.value;
                if(connConfId)
                    this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(connConfId));
                
                this.toolForm.get('Nozzles').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Nozzles']} )?.value);
                //nozzle section
                this.nozzleArrayList = this.updateData.nozzleSections.map((item)=>{
                    return item.value;
                });
                this.nozzleArrayListError = Array.from({ length: this.nozzleArrayList.length }, (_, index) => "");
                if(this.nozzleArrayList.length>0){
                    this.isNozzleChecked = true;
                    this.toolForm.get('TFA').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['TFA']} )?.value);
                    this.toolForm.get('Efficiency').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Efficiency']} )?.value);
                }
                let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
                if(connectionId)  
                    this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
                this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
                if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
                        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
                        if(bottomconnectionId)  
                            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
                        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT']} )?.value);
                }
                this.toolForm.get('BodyOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body OD']} )?.value);
                this.toolForm.get('BodyID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body ID']} )?.value);
                this.toolForm.get('BodyLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Body length']} )?.value);

                this.toolForm.get('FishneckOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Fishneck OD mm']} )?.value);
                this.toolForm.get('FishneckID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Fishneck ID mm']} )?.value);
                this.toolForm.get('FishneckLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Fishneck length m']} )?.value);

                this.toolForm.get('BasketGaugeOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Basket/Gauge OD mm']} )?.value);
                this.toolForm.get('BasketGaugeID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Basket/Gauge ID mm']} )?.value);
                this.toolForm.get('BasketGaugeLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Basket/Gauge length m']} )?.value);

                this.toolForm.get('GaugeOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Gauge OD, mm']} )?.value);
                this.toolForm.get('GaugeID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Gauge ID, mm']} )?.value);
                this.toolForm.get('GaugeLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Gauge Length, m']} )?.value);

                this.toolForm.get('GaugeBodyOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Gauge/Body OD, mm']} )?.value);
                this.toolForm.get('GaugeBodyID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Gauge/Body ID, mm']} )?.value);
                this.toolForm.get('GaugeBodyLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Gauge/Body Length, m']} )?.value);

                this.toolForm.get('StopSubOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Stop Sub OD, mm']} )?.value);
                this.toolForm.get('StopSubID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Stop Sub ID, mm']} )?.value);
                this.toolForm.get('StopSubLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Stop Sub Length, m']} )?.value);

                this.toolForm.get('BottomSubOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom Sub OD, mm']} )?.value);
                this.toolForm.get('BottomSubID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom Sub ID, mm']} )?.value);
                this.toolForm.get('BottomSubLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom Sub Length, m']} )?.value);
               
                this.toolForm.get('SpearOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Spear OD, mm']} )?.value);
                this.toolForm.get('SpearID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Spear ID, mm']} )?.value);
                this.toolForm.get('SpearLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Spear Length, m']} )?.value);

                this.toolForm.get('GrappleOD').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Grapple OD, mm']} )?.value);
                this.toolForm.get('GrappleID').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Grapple ID, mm']} )?.value);
                this.toolForm.get('GrappleLength').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Grapple Length, m']} )?.value);
            }
            else{
            
            this.toolForm.get('Mass')?.patchValue(0);
            this.toolForm.get('AdjustedWeight')?.patchValue(0);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }

        this.emitData();
          });
    }

    async getMaterialsDropdown(){

         let data;
         try{
            data = await lastValueFrom(this.materialService.getMaterialsList());
         }
         catch(e){
            this.toastR.error("Something went wrong while fetching materials");
         }
         return data;
    }//end of functions

    async getToolSizeDropdown() {

        let data;
        try {
            data = await lastValueFrom(this.customToolService.getToolSizesList());
        }
        catch (e) {
            this.toastR.error("Something went wrong while fetching tool sizes");
        }
        return data;
    }//end of functions

    async getConnectionsDropdown(){

        let data;
        try{
            data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
        }
        catch(e){
            this.toastR.error("Something went wrong while fetching connections");
        }
        return data;
    }//end of function

    onchangeToolWeight(){
        this.toolForm.get('Mass')?.patchValue(0);
        this.toolForm.get('AdjustedWeight')?.patchValue(0);
        if(this.toolForm.get('ToolWeightOption').value == 0){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
            if(this.toolForm.get('Length').value)
                this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            else
            this.toolForm.get('AdjustedWeight').patchValue(0);
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value == 1){
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
            this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
        }
        else if(this.toolForm.get('ToolWeightOption').value==2){
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
            this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value/this.toolForm.get('Length').value);
            this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }
    }

    calculateAdjustedWeight(){
        if(this.toolForm.get('Length').value)
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value!=0?this.toolForm.get('Mass').value/this.toolForm.get('Length').value:0);
        else
        this.toolForm.get('AdjustedWeight').patchValue(0);
        this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }

    calculateMass(){
        this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value*this.toolForm.get('Length').value);
    }

    createNozzleInput(numOfNozzles){
        this.nozzleArrayList = Array.from({ length: numOfNozzles }, (_, index) => "");
        this.nozzleArrayListError = Array.from({ length: numOfNozzles }, (_, index) => "");
    }

   

    validateNozzleDiameter(value,i){
        if(value){
            if(value<0){
                this.nozzleArrayListError[i] = "Nozzle Diameter Must be Greater Than 0";
            }
            else{
                this.nozzleArrayListError[i] = "";
            }
        }
        else{
            this.nozzleArrayListError[i] = "Nozzle Diameter Must be Greater Than 0";
        }
    }

   
    save(){

        if (this.toolForm.invalid) {
            // Mark all form controls as touched to show errors
            Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());
   
          }
        this.nozzleArrayList.forEach((element,i) => {
            this.validateNozzleDiameter(element,i)
        });
     
        let nozzleFlag = true,sectionFlag = true;
        this.nozzleArrayListError.forEach((item)=>{
            if(item){
                nozzleFlag = false
            }
        });
     

        //console.log("validity flags",this.toolForm.valid,nozzleFlag);
        //call api below if all the flags are true

        if(this.toolForm.valid && nozzleFlag){
            let payload = this.createPayload();
            if(this.updateData){
                this.customToolService.updateCustomTool(this.templateId,payload).subscribe({
                    next:(data)=>{
                        //console.log(data);
                        this.toastR.success("Custom Tool Updated Successfully");
                        this.formSubmitEvent.emit("success");
                    },
                    error:(error)=>{
                        this.toastR.error("Something went wrong");
                    }
                });
            }
            else{
          
            this.customToolService.addCustomTool(payload).subscribe({
                next:(data)=>{
                    //console.log(data);
                    this.toastR.success("Custom Tool Added Successfully");
                    this.formSubmitEvent.emit("success");
                },
                error:(error)=>{
                    this.toastR.error("Something went wrong");
                }
            });}
            
        }
    }

    cancel(){
        this.formSubmitEvent.emit("cancel");
    }

    createPayload(){


        let payload = {
            "details": {
                "toolDetails": {
                    "ToolSizeId": this.Tool,
                    "Description": this.toolForm.get("Description").value,
                    "CustomToolCatalogId": sessionStorage.getItem("workitem"),
                    "ToolType": this.toolForm.get('Type').value,
                    "ToolConfiguration":this.toolForm.get("ToolConfiguration").value
                },
            "toolValues": [
                {
                    "Id": toolColumns['Length, m'],
                    "ColumnName": "Length, m",
                    "value": this.toolForm.get("Length").value
                },
                {
                    "Id": toolColumns['Tool configuration'],
                    "ColumnName": "Tool configuration",
                    "value": this.toolForm.get("ToolConfiguration").value
                },
                {
                    "Id": toolColumns['Tool weight option'],
                    "ColumnName": "Tool weight option",
                    "value": this.toolForm.get("ToolWeightOption").value
                },
                {
                    "Id": toolColumns['Tool Size, in'],
                    "ColumnName": "Tool Size, in",
                    "value": this.toolForm.get("ToolSize").value
                },
                {
                    "Id": toolColumns['Mass, kg'],
                    "ColumnName": "Mass, kg",
                    "value": this.toolForm.get('Mass').value
                },
                {
                    "Id": toolColumns['Fishing type'],
                    "ColumnName": "Fishing type",
                    "value": this.toolForm.get('Type').value
                },
                {
                    "Id": toolColumns['Adjusted kg/m'],
                    "ColumnName": "Adjusted kg/m",
                    "value": this.toolForm.get('AdjustedWeight').value
                },
                {
                    "Id": toolColumns['NW kg/m'],
                    "ColumnName": "NW kg/m",
                    "value": this.toolForm.get('NW').value
                },
                
                {
                    "Id": toolColumns['Material'],
                    "ColumnName": "Material",
                    "value": this.toolForm.get('Material').value
                },
               
                {
                    "Id": toolColumns['Connection configuration'],
                    "ColumnName": "Connection configuration",
                    "value": this.toolForm.get('ConnectionConfiguration').value

                },
                {
                    "Id": toolColumns['TFA'],
                    "ColumnName": "TFA",
                    "value": this.toolForm.get('TFA').value?this.toolForm.get('TFA').value:0
                },
                {
                    "Id": toolColumns['Efficiency'],
                    "ColumnName": "Efficiency",
                    "value": this.toolForm.get('Efficiency').value?this.toolForm.get('Efficiency').value:""
                },
                {
                    "Id": toolColumns['Nozzles'],
                    "ColumnName": "Nozzles",
                    "value": this.toolForm.get('Nozzles').value
                },
                {
                    "Id": toolColumns['Thread type'],
                    "ColumnName": "Thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['Top MUT n-m'],
                    "ColumnName": "Top MUT n-m",
                    "value": this.toolForm.get('TopMUT').value
                },
                {
                    "Id": toolColumns['Bottom thread type'],
                    "ColumnName": "Bottom thread type",
                    "value": this.toolForm.get('TopThreadType').value
                },
                {
                    "Id": toolColumns['Bottom MUT'],
                    "ColumnName": "Bottom MUT",
                    "value": this.toolForm.get('TopMUT').value
                },
                {
                    "Id": toolColumns['Body OD'],
                    "ColumnName": "Body OD",
                    "value": this.toolForm.get('BodyOD').value?this.toolForm.get('BodyOD').value:""
                },
                {
                    "Id": toolColumns['Body ID'],
                    "ColumnName": "Body ID",
                    "value": this.toolForm.get('BodyID').value?this.toolForm.get('BodyID').value:""
                },
                {
                    "Id": toolColumns['Body length'],
                    "ColumnName": "Body length",
                    "value": this.toolForm.get('BodyLength').value?this.toolForm.get('BodyLength').value:""
                },
                {
                    "Id": toolColumns['Basket/Gauge OD mm'],
                    "ColumnName": 'Basket/Gauge OD mm',
                    "value": this.toolForm.get('BasketGaugeOD').value?this.toolForm.get('BasketGaugeOD').value:""
                },
                {
                    "Id": toolColumns['Basket/Gauge ID mm'],
                    "ColumnName": "Basket/Gauge ID mm",
                    "value": this.toolForm.get('BasketGaugeID').value?this.toolForm.get('BasketGaugeID').value:""
                },
                {
                    "Id": toolColumns['Basket/Gauge length m'],
                    "ColumnName": "Basket/Gauge length m",
                    "value": this.toolForm.get('BasketGaugeLength').value?this.toolForm.get('BasketGaugeLength').value:""
                },
                {
                    "Id": toolColumns['Gauge OD, mm'],
                    "ColumnName": 'Gauge OD, mm',
                    "value": this.toolForm.get('GaugeOD').value?this.toolForm.get('GaugeOD').value:""
                },
                {
                    "Id": toolColumns['Gauge ID, mm'],
                    "ColumnName": "Gauge ID, mm",
                    "value": this.toolForm.get('GaugeID').value?this.toolForm.get('GaugeID').value:""
                },
                {
                    "Id": toolColumns['Gauge Length, m'],
                    "ColumnName": "Gauge Length, m",
                    "value": this.toolForm.get('GaugeLength').value?this.toolForm.get('GaugeLength').value:""
                },
                {
                    "Id": toolColumns['Gauge/Body OD, mm'],
                    "ColumnName": 'Gauge/Body OD, mm',
                    "value": this.toolForm.get('GaugeBodyOD').value?this.toolForm.get('GaugeBodyOD').value:""
                },
                {
                    "Id": toolColumns['Gauge/Body ID, mm'],
                    "ColumnName": "Gauge/Body ID, mm",
                    "value": this.toolForm.get('GaugeBodyID').value? this.toolForm.get('GaugeBodyID').value:""
                },
                {
                    "Id": toolColumns['Gauge/Body Length, m'],
                    "ColumnName": "Gauge/Body Length, m",
                    "value": this.toolForm.get('GaugeBodyLength').value?this.toolForm.get('GaugeBodyLength').value:""
                },
                {
                    "Id": toolColumns['Fishneck OD mm'],
                    "ColumnName": 'Fishneck OD mm',
                    "value": this.toolForm.get('FishneckOD').value?this.toolForm.get('FishneckOD').value:""
                },
                {
                    "Id": toolColumns['Fishneck ID mm'],
                    "ColumnName": "Fishneck ID mm",
                    "value": this.toolForm.get('FishneckID').value?this.toolForm.get('FishneckID').value:""
                },
                {
                    "Id": toolColumns['Fishneck length m'],
                    "ColumnName": "Fishneck length m",
                    "value": this.toolForm.get('FishneckLength').value?this.toolForm.get('FishneckLength').value:""
                },
                {
                    "Id": toolColumns['Grapple OD, mm'],
                    "ColumnName": 'Grapple OD, mm',
                    "value": this.toolForm.get('GrappleOD').value?this.toolForm.get('GrappleOD').value:""
                },
                {
                    "Id": toolColumns['Grapple ID, mm'],
                    "ColumnName": "Grapple ID, mm",
                    "value": this.toolForm.get('GrappleID').value?this.toolForm.get('GrappleID').value:""
                },
                {
                    "Id": toolColumns['Grapple Length, m'],
                    "ColumnName": "Grapple Length, m",
                    "value": this.toolForm.get('GrappleLength').value?this.toolForm.get('GrappleLength').value:""
                },
                {
                    "Id": toolColumns['Spear OD, mm'],
                    "ColumnName": 'Spear OD, mm',
                    "value": this.toolForm.get('SpearOD').value?this.toolForm.get('SpearOD').value:""
                },
                {
                    "Id": toolColumns['Spear ID, mm'],
                    "ColumnName": "Spear ID, mm",
                    "value": this.toolForm.get('SpearID').value?this.toolForm.get('SpearID').value:""
                },
                {
                    "Id": toolColumns['Spear Length, m'],
                    "ColumnName": 'Spear Length, m',
                    "value": this.toolForm.get('SpearLength').value?this.toolForm.get('SpearLength').value:""
                },
                {
                    "Id": toolColumns['Bottom Sub OD, mm'],
                    "ColumnName": 'Bottom Sub OD, mm',
                    "value": this.toolForm.get('BottomSubOD').value?this.toolForm.get('BottomSubOD').value:""
                },
                {
                    "Id": toolColumns['Bottom Sub ID, mm'],
                    "ColumnName": "Bottom Sub ID, mm",
                    "value": this.toolForm.get('BottomSubID').value?this.toolForm.get('BottomSubID').value:""
                },
                {
                    "Id": toolColumns['Bottom Sub Length, m'],
                    "ColumnName": 'Bottom Sub Length, m',
                    "value": this.toolForm.get('BottomSubLength').value?this.toolForm.get('BottomSubLength').value:""
                },
                {
                    "Id": toolColumns['Stop Sub OD, mm'],
                    "ColumnName": 'Stop Sub OD, mm',
                    "value": this.toolForm.get('StopSubOD').value?this.toolForm.get('StopSubOD').value:""
                },
                {
                    "Id": toolColumns['Stop Sub ID, mm'],
                    "ColumnName": "Stop Sub ID, mm",
                    "value": this.toolForm.get('StopSubID').value?this.toolForm.get('StopSubID').value:""
                },
                {
                    "Id": toolColumns['Stop Sub Length, m'],
                    "ColumnName": 'Stop Sub Length, m',
                    "value": this.toolForm.get('StopSubLength').value?this.toolForm.get('StopSubLength').value:""
                }
                ]
          
           ,
            "nozzleSections": this.nozzleArrayList.map((item)=>{
                return  {
                    "Id": toolColumns['Nozzle Diameter, x 1/32'],
                    "ColumnName": "Nozzle Diameter, x 1/32",
                    "value": item
                }
            })
        
            }
        
        }

        return payload;
    }

    nozzleCheckboxChanged(event){
 // Do something with the event or checkbox state
    if (event) {
        //console.log("Checkbox is checked");
        this.toolForm.get('TFA').setValidators([Validators.required,Validators.min(1)]);
        this.toolForm.get('TFA').updateValueAndValidity();
    } else {
        //console.log("Checkbox is unchecked");
        this.toolForm.get('TFA').setValidators([Validators.min(1)]);
        this.toolForm.get('TFA').updateValueAndValidity();
    }
    this.toolForm.get('TFA').patchValue('');
    this.toolForm.get('Efficiency').patchValue('');
    this.toolForm.get('Nozzles').patchValue('');
    this.nozzleArrayList = [];
    this.nozzleArrayListError = [];
    }

    resetThreadtype(){
        if(this.updateData){
        let connectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Thread type']} )?.value
        if(connectionId)  
            this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
        this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Top MUT n-m']} )?.value);
        if(this.toolForm.get('ConnectionConfiguration').value!=6 && this.toolForm.get('ConnectionConfiguration').value!=5){
        let bottomconnectionId = this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom thread type']} )?.value
        if(bottomconnectionId)  
            this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item)=>{return item.Id===toolColumns['Bottom MUT n-m']} )?.value);
        }
        
    }
    else{
        this.toolForm.get('TopThreadType').patchValue('');
        this.toolForm.get('TopMUT').patchValue('');
        this.toolForm.get('BottomThreadType').patchValue('');
        this.toolForm.get('BottomMUT').patchValue('');

    }
    }

    emitData(){
        this.threeDParams.emit({
            length: this.toolForm.get("Length").value,
            toolSize: this.toolForm.get("ToolSize").value,
            toolType: this.toolForm.get("Type").value,
            toolConf: this.toolForm.get("ToolConfiguration").value,
        });
    }

      /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
        next: (res) => {
            if (res) {
                //console.log("res in casing---", res);
                let activeUnitSystemData = res;
                this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                this.lengthLabel = activeUnitSystemData.length.unitValue;
                this.massLabel = activeUnitSystemData.mass.unitValue;
                this.linearMassDensityLabel = activeUnitSystemData.linearMassDensity.unitValue;
                this.torqueLabel = activeUnitSystemData.torque.unitValue;
                this.percentageLabel = activeUnitSystemData.percentage.unitValue;
                this.forceLabel = activeUnitSystemData.force.unitValue;
                this.stressLabel = activeUnitSystemData.stress.unitValue;
                this.nozzleSizeLabel = activeUnitSystemData.nozzleSize.unitValue;
                this.rotationVelocityLabel = activeUnitSystemData.rotationVelocity.unitValue;
                this.angleLabel = activeUnitSystemData.angle.unitValue;
                this.pressureLabel=activeUnitSystemData.pressure.unitValue;
                this.flowLabel=activeUnitSystemData.flow.unitValue;
                // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

            } else {
                //console.log('error');
            }
        },
        error: (error) => {
            //console.log("Unit", error.error.result);
        }
    })
}
}
