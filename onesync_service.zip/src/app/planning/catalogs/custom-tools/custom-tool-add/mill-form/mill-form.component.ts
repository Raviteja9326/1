import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { ReplaySubject, lastValueFrom } from 'rxjs';
import { CustomValidators } from 'src/app/core/constants/regex.constants';
import { toolColumns } from 'src/app/core/constants/toolColumns.constant';
import { ConnectionConfiguration } from 'src/app/core/enum/custom-tools/connectionConf.enum';
import { DCVType } from 'src/app/core/enum/custom-tools/dcvType.enum';
import { MillType } from 'src/app/core/enum/custom-tools/millType.enum';
import { MillToolConfiguration } from 'src/app/core/enum/custom-tools/millToolConfigurations.enum';
import { ToolWeightOption } from 'src/app/core/enum/custom-tools/toolWeightOptions.enum';
import { ConnectionService } from 'src/app/core/services/connection.service';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { UnitsService } from 'src/app/core/services/units.service';
import { valueOrDefault } from 'chart.js/dist/helpers/helpers.core';

@Component({
  selector: 'app-mill-form',
  templateUrl: './mill-form.component.html',

})
export class MillFormComponent implements OnInit {

  @Input() Tool: any;
  @Input() updateData: any;
  @Input() templateId: any;
  @Output()
  formSubmitEvent = new EventEmitter<any>();//event emitter for sending formdata
  @Output()
  threeDParams = new EventEmitter<any>();
  toolForm: FormGroup;
  toolSizeOptions: any = [];
  toolWeightOptions: any = [];
  threadTypeOptions: any = [];
  materialOptions: any = [];
  nozzleArrayList: any = [];
  nozzleArrayListError: any[] = [];
  isNozzleChecked: boolean = false;
  isStabilizerFishneckChecked: boolean = false;
  typeOptions: any = [
  ];
  connconfOptions: any = [
  ];
  toolConfOptions: any = [];
  isNozzleDisabled: boolean = true;
  show: any = {
    Body: false,
    Face: true,
    Blade: false
  };
  filteredToolSizeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControltoolSize: FormControl = new FormControl();
  filteredTopThreadTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControlTopThreadType: FormControl = new FormControl();
  filteredBottomThreadTypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControlBottomThreadType: FormControl = new FormControl();
  filteredMaterialOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControlMaterials: FormControl = new FormControl();
  fileteredtoolWeightOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControl: FormControl = new FormControl();
  filterControltype: FormControl = new FormControl();
  fileteredtypeOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControltoolConf: FormControl = new FormControl();
  fileteredtoolConfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  filterControlconn: FormControl = new FormControl();
  fileteredconnconfOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  shortLengthLabel: string = "";//(in or mm)
  lengthLabel: string = "";//(ft or m)
  massLabel: string = "";// (lbm or Kg)
  linearMassDensityLabel: string = "";// (lb/ft or kg/m)
  torqueLabel: string = "";// (lbf-ft or N-m)
  percentageLabel: string = "";//%
  forceLabel: string = "";//lbf or N
  stressLabel: string = "";//ksi or MPa
  nozzleSizeLabel: string = "";//x 1/32" or mm
  rotationVelocityLabel: string = "";//rpm
  pressureLabel: string = "";//(kPa or psi)
  flowLabel: string = "";//l/min or gal/min
  angleLabel: string = "";//°
  lengthError: string = "";
  topMUTError: string = "";
  BottomMUTError: string = "";
  ConcaveMaxODError: string = "";
  ConcaveMinEquivalentODError: string = "";
  ConcaveLengthError: string = "";
  AnchorIDError: string = "";
  AnchorODError: string = "";
  AnchorLengthError: string = "";
  FishneckIDError: string = "";
  FishneckODError: string = "";
  FishneckLengthError: string = "";
  BladeODError: string = "";
  BladeIDError: string = "";
  BladeLengthError: string = "";
  GaugeODError: string = "";
  GaugeIDError: string = "";
  GaugeLengthError: string = "";
  BodyODError: string = "";
  BodyIDError: string = "";
  BodyLengthError: string = "";
  FaceODError: string = "";
  FaceIDError: string = "";
  FaceLengthError: string = "";
  constructor(
    private formBuilder: FormBuilder,
    private materialService: MaterialsService,
    private customToolService: CustomToolService,
    private connectionService: ConnectionService,
    private toastR: ToastrService,
    private unitsService: UnitsService,
  ) {


  }
  ngOnInit(): void {

  }
  ngOnChanges() {

    this.getActiveUnitSystemData();

    //console.log("Tool conf options", this.toolConfOptions);
    this.toolForm = this.formBuilder.group({
      Type: [1, [Validators.required]],
      ToolConfiguration: [1, [Validators.required]],
      ToolSize: ['', [Validators.required]],
      Description: ['', [Validators.required, CustomValidators.noContinuousSpaces, Validators.maxLength(99)]],
      Length: [0.00, [Validators.required, Validators.min(0), Validators.max(30.48)]],
      ToolWeightOption: [0, [Validators.required]],
      Mass: [0.00, []],
      AdjustedWeight: [0.00, []],
      NW: [0.00, [Validators.required, Validators.min(0)]],
      Material: ['', [Validators.required]],
      ConnectionConfiguration: ['', [Validators.required]],
      TopThreadType: ['', [Validators.required]],
      TopMUT: [2306.3, [Validators.required, Validators.min(0), Validators.max(3843.88)]],
      BottomThreadType: ['', [Validators.required]],
      BottomMUT: [2306.33, [Validators.required, Validators.min(0), Validators.max(3843.88)]],
      TFA: [0, [Validators.min(0)]],
      Efficiency: [95, [Validators.min(0), Validators.max(100)]],
      Nozzles: ['', [Validators.min(0), Validators.max(1000)]],
      StabilizerFishneckBladeOD: ['', [Validators.min(0)]],
      StabilizerFishneckBladeCount: ['', [Validators.min(-1000000000), Validators.max(1000000000)]],
      StabilizerFishneckBladeWidth: ['', []],
      StabilizerFishneckBladeLength: ['', []],
      StabilizerFishneckBladeAngle: ['', []],
      BodyOD: [4.75, [Validators.required, Validators.min(0)]],
      BodyID: [3.75, [Validators.required, Validators.min(0)]],
      BodyLength: ['', [Validators.min(0), Validators.max(30.48)]],
      FishneckOD: [4.75, [Validators.required, Validators.min(0)]],
      FishneckID: [3.75, [Validators.required, Validators.min(0)]],
      FishneckLength: ['', [Validators.required,Validators.min(0), Validators.max(30.48)]],
      GaugeOD: [4.75, [Validators.required, Validators.min(0)]],
      GaugeID: [3.75, [Validators.required, Validators.min(0)]],
      GaugeLength: ['', [Validators.required,Validators.min(0), Validators.max(30.48)]],
      FaceOD: [4.75, [Validators.required, Validators.min(0)]],
      FaceID: [3.75, [Validators.required, Validators.min(0)]],
      FaceLength: ['', [Validators.required,Validators.min(0), Validators.max(30.48)]],
      BladeOD: [4.75, [Validators.required, Validators.min(0)]],
      BladeID: [0.000, [Validators.required, Validators.min(0)]],
      BladeLength: ['', [Validators.min(0), Validators.max(30.48)]],
    });

    this.toolConfOptions = MillToolConfiguration[1];
    this.fileteredtoolConfOptions.next(this.toolConfOptions);
    this.filterControltoolConf
      .valueChanges
      .subscribe({
        next: () => {
          let filter = this.filterControltoolConf.value.toLowerCase();
          let filteredList = this.toolConfOptions.filter(
            option => option.label.toLowerCase().indexOf(filter) >= 0
          );
          this.fileteredtoolConfOptions.next(filteredList);
        }
      });


    this.toolWeightOptions = [];
    for (const toolweightKey of Object.keys(ToolWeightOption)) {
      this.toolWeightOptions.push({ label: toolweightKey, value: parseInt(ToolWeightOption[toolweightKey]) });
    }
    this.connconfOptions = [];
    let typeValue = parseInt(this.toolForm.get('Type').value);
    for (const conconfKey of Object.keys(ConnectionConfiguration)) {

      if (typeValue == 1) {
        if ((parseInt(ConnectionConfiguration[conconfKey]) == parseInt(ConnectionConfiguration['Box'])) || (parseInt(ConnectionConfiguration[conconfKey]) == parseInt(ConnectionConfiguration['Pin']))) {
          this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
        }
      } else {
        this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
      }


    }
    if (typeValue == 1) {
      this.toolForm.get("ConnectionConfiguration").patchValue(5);
    } else {
      this.toolForm.get("ConnectionConfiguration").patchValue(3);
    }


    this.typeOptions = [];
    for (const MillTypeKey of Object.keys(MillType)) {

      this.typeOptions.push({ label: MillTypeKey, value: parseInt(MillType[MillTypeKey]) });
    }


    this.fileteredtoolWeightOptions.next(this.toolWeightOptions);
    this.filterControl
      .valueChanges
      .subscribe({
        next: () => {
          let filter = this.filterControl.value.toLowerCase();
          let filteredList = this.toolWeightOptions.filter(
            option => option.label.toLowerCase().indexOf(filter) >= 0
          );
          this.fileteredtoolWeightOptions.next(filteredList);
        }
      });

    this.fileteredtypeOptions.next(this.typeOptions);
    this.filterControltype
      .valueChanges
      .subscribe({
        next: () => {
          let filter = this.filterControltype.value.toLowerCase();
          let filteredList = this.typeOptions.filter(
            option => option.label.toLowerCase().indexOf(filter) >= 0
          );
          this.fileteredtypeOptions.next(filteredList);
        }
      });



    this.fileteredconnconfOptions.next(this.connconfOptions);
    this.filterControlconn
      .valueChanges
      .subscribe({
        next: () => {
          let filter = this.filterControlconn.value.toLowerCase();
          let filteredList = this.connconfOptions.filter(
            option => option.label.toLowerCase().indexOf(filter) >= 0
          );
          this.fileteredconnconfOptions.next(filteredList);
        }
      });



    this.toolForm.get('Length')?.disable();
    this.toolForm.get('Mass')?.disable();
    this.toolForm.get('AdjustedWeight')?.disable();
    this.toolForm.get('AnchorID')?.disable();



    this.toolForm.get('Type').valueChanges.subscribe((value) => {
      if (!this.updateData) {
        this.toolForm.get('BodyOD').patchValue(4.75);
        this.toolForm.get('BodyID').patchValue(3.75);
        this.toolForm.get('BodyLength').patchValue('');
        this.toolForm.get('FaceOD').patchValue(4.75);
        this.toolForm.get('FaceID').patchValue(3.75);
        this.toolForm.get('FaceLength').patchValue('');
        this.toolForm.get('GaugeOD').patchValue(4.75);
        this.toolForm.get('GaugeID').patchValue(3.75);
        this.toolForm.get('GaugeLength').patchValue('');
        this.toolForm.get('FishneckOD').patchValue(4.75);
        this.toolForm.get('FishneckID').patchValue(3.75);
        this.toolForm.get('FishneckLength').patchValue('');
        this.toolForm.get('BladeOD').patchValue(4.75);
        this.toolForm.get('BladeID').patchValue(0);
        this.toolForm.get('BladeLength').patchValue('');
        this.toolForm.get('ConnectionConfiguration').patchValue('');
      }

      this.toolConfOptions = MillToolConfiguration[value];
      this.fileteredtoolConfOptions.next(this.toolConfOptions);
      this.filterControltoolConf
        .valueChanges
        .subscribe({
          next: () => {
            let filter = this.filterControltoolConf.value.toLowerCase();
            let filteredList = this.toolConfOptions.filter(
              option => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredtoolConfOptions.next(filteredList);
          }
        });
      //Bottom Mill
      if (value == 1) {
        this.connconfOptions = [];
        this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
        this.toolForm.get('ToolConfiguration').patchValue(1);
        this.toolForm.get('ToolConfiguration').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BodyOD').setValidators([]);
        this.toolForm.get('BodyOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BodyID').setValidators([]);
        this.toolForm.get('BodyID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BodyLength').setValidators([]);
        this.toolForm.get('BodyLength').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BladeOD').setValidators([]);
        this.toolForm.get('BladeOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BladeID').setValidators([]);
        this.toolForm.get('BladeID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BladeLength').setValidators([]);
        this.toolForm.get('BladeLength').updateValueAndValidity({ emitEvent: false });
        for (const conconfKey of Object.keys(ConnectionConfiguration)) {
          if ((parseInt(ConnectionConfiguration[conconfKey]) == parseInt(ConnectionConfiguration['Box'])) || (parseInt(ConnectionConfiguration[conconfKey]) == parseInt(ConnectionConfiguration['Pin']))) {
            this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
          }
        }
        this.toolForm.get("ConnectionConfiguration").patchValue(3)
        this.show = {
          Body: false,
          Face: true,
          Blade: false
        }


      }
      //Packer Mill
      else if (value == 2) {
        this.isNozzleDisabled = true;
        this.isNozzleChecked = true;
        this.toolForm.get('ToolConfiguration').setValidators([]);
        this.toolForm.get('ToolConfiguration').patchValue('');
        this.toolForm.get('ToolConfiguration').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceOD').setValidators([]);
        this.toolForm.get('FaceOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceID').setValidators([]);
        this.toolForm.get('FaceID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceLength').setValidators([]);
        this.toolForm.get('FaceLength').updateValueAndValidity({ emitEvent: false });

        this.connconfOptions = [];
        for (const conconfKey of Object.keys(ConnectionConfiguration)) {
            this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
          this.toolForm.get("ConnectionConfiguration").patchValue(5)
        }
        this.show = {
          Body: true,
          Face: false,
          Blade: true
        }


      }
      //Pilot Mill
      else if (value == 3) {
        this.isNozzleDisabled = true;
        this.isNozzleChecked = true;
        this.toolForm.get('ToolConfiguration').setValidators([]);
        this.toolForm.get('ToolConfiguration').patchValue('');
        this.toolForm.get('ToolConfiguration').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceOD').setValidators([]);
        this.toolForm.get('FaceOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceID').setValidators([]);
        this.toolForm.get('FaceID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceLength').setValidators([]);
        this.toolForm.get('FaceLength').updateValueAndValidity({ emitEvent: false });
        this.connconfOptions = [];
        for (const conconfKey of Object.keys(ConnectionConfiguration)) {
          this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
        }
        this.toolForm.get("ConnectionConfiguration").patchValue(3)
        this.show = {
          Body: true,
          Face: false,
          Blade: true
        }

      }
      //Section Mill
      else if (value == 4) {
        this.isNozzleDisabled = false;
        this.isNozzleChecked = false;
        this.toolForm.get('ToolConfiguration').setValidators([]);
        this.toolForm.get('ToolConfiguration').patchValue('');
        this.toolForm.get('ToolConfiguration').updateValueAndValidity({ emitEvent: false });

        this.toolForm.get('FaceOD').setValidators([]);
        this.toolForm.get('FaceOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceID').setValidators([]);
        this.toolForm.get('FaceID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceLength').setValidators([]);
        this.toolForm.get('FaceLength').updateValueAndValidity({ emitEvent: false });
        this.connconfOptions = [];
        for (const conconfKey of Object.keys(ConnectionConfiguration)) {
            this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
        }
        this.toolForm.get("ConnectionConfiguration").patchValue(5)
        this.show = {
          Body: true,
          Face: false,
          Blade: true
        }
      }
      //String Mill
      else if (value == 5) {
        this.isNozzleDisabled = false;
        this.isNozzleChecked = false;
        this.toolForm.get('ToolConfiguration').setValidators([Validators.required]);
        this.toolForm.get('ToolConfiguration').patchValue(2);
        this.toolForm.get('ToolConfiguration').updateValueAndValidity({ emitEvent: false });

        this.toolForm.get('FaceOD').setValidators([]);
        this.toolForm.get('FaceOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceID').setValidators([]);
        this.toolForm.get('FaceID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('FaceLength').setValidators([]);
        this.toolForm.get('FaceLength').updateValueAndValidity({ emitEvent: false });

        this.toolForm.get('BladeOD').setValidators([]);
        this.toolForm.get('BladeOD').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BladeID').setValidators([]);
        this.toolForm.get('BladeID').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BladeLength').setValidators([]);
        this.toolForm.get('BladeLength').updateValueAndValidity({ emitEvent: false });
        this.connconfOptions = [];
        for (const conconfKey of Object.keys(ConnectionConfiguration)) {
            this.connconfOptions.push({ label: conconfKey, value: parseInt(ConnectionConfiguration[conconfKey]) });
        }
        this.toolForm.get("ConnectionConfiguration").patchValue(5)
        this.show = {
          Body: true,
          Face: false,
          Blade: false
        }
      }


    });

    this.toolForm.get('Length').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value

      if (this.lengthLabel == "ft") {
        this.toolForm.get('Length').setValidators([Validators.required, Validators.min(0.00), Validators.max(100.00)]);
        this.lengthError = "Value for length must be between 0.00 and 100.00 (ft)"
      }
      else if (this.lengthLabel == "m") {
        this.toolForm.get('Length').setValidators([Validators.required, Validators.min(0.00), Validators.max(30.48)]);
        this.lengthError = "Value for length must be between 0.00 and 30.48 (m)"
      }
      this.toolForm.get('Length').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('TopMUT').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value

      if (this.torqueLabel == "lbf-ft") {
        this.toolForm.get('TopMUT').setValidators([Validators.required, Validators.min(0.00), Validators.max(3843.88)]);
        this.topMUTError = "Value for MUT must be between 0.00 and 3843.88 (lbf-ft)."
      }
      else if (this.torqueLabel == "N-m") {
        this.toolForm.get('TopMUT').setValidators([Validators.required, Validators.min(0.00), Validators.max(5211.6)]);
        this.topMUTError = "Value for MUT must be between 0.00 and 5211.6 (N-m)."
      }
      this.toolForm.get('TopMUT').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('NW').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value

      if (this.torqueLabel == "lb/ft") {
        this.toolForm.get('NW').setValidators([Validators.required, Validators.min(0.00)]);
      }
      else if (this.torqueLabel == "kg/m") {
        this.toolForm.get('NW').setValidators([Validators.required, Validators.min(0.00)]);
      }
      this.toolForm.get('NW').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('BottomMUT').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value) {
        if (this.torqueLabel == "lbf-ft") {
          this.toolForm.get('BottomMUT').setValidators([Validators.min(0), Validators.required, Validators.max(3843.88)]);
          this.BottomMUTError = "Value for MUT must be between 0 and 3843.88 (lbf-ft)"
        }
        else if (this.torqueLabel == "N-m") {
          this.toolForm.get('BottomMUT').setValidators([Validators.min(0), Validators.required, Validators.max(5211.6)]);
          this.BottomMUTError = "Value for MUT must be between 0 and 5211.6 (N-m)"
        }
      }
      else {
        this.toolForm.get('BottomMUT').setValidators([Validators.min(0)]);
      }


      this.toolForm.get('BottomMUT').updateValueAndValidity({ emitEvent: false });
    });


    this.toolForm.get('FishneckOD').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value;
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('FishneckOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.FishneckODError = "Value for OD must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('FishneckOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.FishneckODError = "Value for OD must be more than 0.000 (mm)"
        }
        let IDValue = parseFloat(this.toolForm.get('FishneckID').value);
        if (IDValue > value) {
          this.toolForm.get('FishneckID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.FishneckIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('FishneckID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.FishneckIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
        this.toolForm.get('FishneckID').updateValueAndValidity({ emitEvent: false });
      } else {
        this.toolForm.get('FishneckID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('FishneckOD').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('FishneckID').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('FishneckID').setValidators([Validators.required, Validators.min(0.00)]);
          this.FishneckIDError = "Value for ID must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('FishneckID').setValidators([Validators.required, Validators.min(0.00)]);
          this.FishneckIDError = "Value for ID must be more than 0.000 (mm)"
        }
        let ODValue = parseFloat(this.toolForm.get('FishneckOD').value);
        if (value > ODValue) {
          this.toolForm.get('FishneckID').setValidators([Validators.required, Validators.min(0.00), Validators.max(ODValue)]);
          this.FishneckIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('FishneckID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.FishneckIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
      } else {
        this.toolForm.get('FishneckID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('FishneckID').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('FishneckLength').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value) {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('FishneckLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(100.00)]);
          this.FishneckLengthError = "Value for length must be between 0.00 and 100.00 (ft)"
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('FishneckLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(30.48)]);
          this.FishneckLengthError = "Value for length must be between 0.00 and 30.48 (m)"
        }
      } else {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('FishneckLength').setValidators([Validators.min(0.00), Validators.max(100)]);
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('FishneckLength').setValidators([Validators.min(0.00), Validators.max(30.48)]);

        }
      }
      this.toolForm.get('FishneckLength').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('GaugeOD').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('GaugeOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.GaugeODError = "Value for OD must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('GaugeOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.GaugeODError = "Value for OD must be more than 0.000 (mm)"
        }
        let IDValue = parseFloat(this.toolForm.get('GaugeID').value);
        if (IDValue > value) {
          this.toolForm.get('GaugeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.GaugeIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('GaugeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.GaugeIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
        this.toolForm.get('GaugeID').updateValueAndValidity({ emitEvent: false });
      } else {
        this.toolForm.get('GaugeID').setValidators([Validators.min(0.00)]);
      }

      this.toolForm.get('GaugeOD').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('GaugeID').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('GaugeID').setValidators([Validators.required, Validators.min(0.00)]);
          this.GaugeIDError = "Value for ID must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('GaugeID').setValidators([Validators.required, Validators.min(0.00)]);
          this.GaugeIDError = "Value for ID must be more than 0.000 (mm)"
        }
        let ODValue = parseFloat(this.toolForm.get('GaugeOD').value);
        if (value > ODValue) {
          this.toolForm.get('GaugeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(ODValue)]);
          this.GaugeIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('GaugeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.GaugeIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
      } else {
        this.toolForm.get('GaugeID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('GaugeID').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('GaugeLength').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value) {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('GaugeLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(100.00)]);
          this.GaugeLengthError = "Value for length must be between 0.00 and 100.00 (ft)"
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('GaugeLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(30.48)]);
          this.GaugeLengthError = "Value for length must be between 0.00 and 30.48 (m)"
        }
      } else {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('GaugeLength').setValidators([Validators.min(0.00), Validators.max(100)]);
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('GaugeLength').setValidators([Validators.min(0.00), Validators.max(30.48)]);

        }
      }
      this.toolForm.get('GaugeLength').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('FaceOD').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('FaceOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.FaceODError = "Value for OD must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('FaceOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.FaceODError = "Value for OD must be more than 0.000 (mm)"
        }
        let IDValue = parseFloat(this.toolForm.get('FaceID').value);
        if (IDValue > value) {
          this.toolForm.get('FaceID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.FaceIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('FaceID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.FaceIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
        this.toolForm.get('FaceID').updateValueAndValidity({ emitEvent: false });
      } else {
        this.toolForm.get('FaceID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('FaceOD').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('FaceID').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('FaceID').setValidators([Validators.required, Validators.min(0.00)]);
          this.FaceIDError = "Value for ID must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('FaceID').setValidators([Validators.required, Validators.min(0.00)]);
          this.FaceIDError = "Value for ID must be more than 0.000 (mm)"
        }
        let ODValue = parseFloat(this.toolForm.get('FaceOD').value);
        if (value > ODValue) {
          this.toolForm.get('FaceID').setValidators([Validators.required, Validators.min(0.00), Validators.max(ODValue)]);
          this.FaceIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('FaceID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.FaceIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
      } else {
        this.toolForm.get('FaceID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('FaceID').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('FaceLength').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value) {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('FaceLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(100.00)]);
          this.FaceLengthError = "Value for length must be between 0.00 and 100.00 (ft)"
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('FaceLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(30.48)]);
          this.FaceLengthError = "Value for length must be between 0.00 and 30.48 (m)"
        }
      } else {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('FaceLength').setValidators([Validators.min(0.00), Validators.max(100)]);
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('FaceLength').setValidators([Validators.min(0.00), Validators.max(30.48)]);

        }
      }
      this.toolForm.get('FaceLength').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('BladeOD').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('BladeOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.BladeODError = "Value for OD must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('BladeOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.BladeODError = "Value for OD must be more than 0.000 (mm)"
        }
        let IDValue = parseFloat(this.toolForm.get('BladeID').value);
        if (IDValue > value) {
          this.toolForm.get('BladeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.BladeIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('BladeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.BladeIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
        this.toolForm.get('BladeID').updateValueAndValidity({ emitEvent: false });
      } else {
        this.toolForm.get('BladeID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('BladeOD').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('BladeID').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('BladeID').setValidators([Validators.required, Validators.min(0.00)]);
          this.BladeIDError = "Value for ID must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('BladeID').setValidators([Validators.required, Validators.min(0.00)]);
          this.BladeIDError = "Value for ID must be more than 0.000 (mm)"
        }

        let ODValue = parseFloat(this.toolForm.get('BladeOD').value);
        if (value > ODValue) {
          this.toolForm.get('BladeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(ODValue)]);
          this.BladeIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('BladeID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.BladeIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
      } else {
        this.toolForm.get('BladeID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('BladeID').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('BladeLength').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value) {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('BladeLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(100.00)]);
          this.BladeLengthError = "Value for length must be between 0.00 and 100.00 (ft)"
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('BladeLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(30.48)]);
          this.BladeLengthError = "Value for length must be between 0.00 and 30.48 (m)"
        }
      } else {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('BladeLength').setValidators([Validators.min(0.00), Validators.max(100)]);
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('BladeLength').setValidators([Validators.min(0.00), Validators.max(30.48)]);

        }
      }
      this.toolForm.get('BladeLength').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('BodyOD').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('BodyOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.BodyODError = "Value for OD must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('BodyOD').setValidators([Validators.required, Validators.min(0.00)]);
          this.BodyODError = "Value for OD must be more than 0.000 (mm)"
        }
        let IDValue = parseFloat(this.toolForm.get('BodyID').value);
        if (IDValue > value) {
          this.toolForm.get('BodyID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.BodyIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('BodyID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.BodyIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
        this.toolForm.get('BodyID').updateValueAndValidity({ emitEvent: false });
      } else {
        this.toolForm.get('BodyID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('BodyOD').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('BodyID').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.shortLengthLabel == "in") {
          this.toolForm.get('BodyID').setValidators([Validators.required, Validators.min(0.00)]);
          this.BodyIDError = "Value for ID must be more than 0.000 (in)"
        }
        else if (this.shortLengthLabel == "mm") {
          this.toolForm.get('BodyID').setValidators([Validators.required, Validators.min(0.00)]);
          this.BodyIDError = "Value for ID must be more than 0.000 (mm)"
        }

        let ODValue = parseFloat(this.toolForm.get('BodyOD').value);
        if (value > ODValue) {
          this.toolForm.get('BodyID').setValidators([Validators.required, Validators.min(0.00), Validators.max(ODValue)]);
          this.BodyIDError = "Section outer diameter must be greater than inner diameter";
        }
        else {
          this.toolForm.get('BodyID').setValidators([Validators.required, Validators.min(0.00), Validators.max(value)]);
          this.BodyIDError = "Value for ID must be more than 0.000 (" + this.shortLengthLabel + ")";
        }
      } else {
        this.toolForm.get('BodyID').setValidators([Validators.min(0.00)]);
      }
      this.toolForm.get('BodyID').updateValueAndValidity({ emitEvent: false });
    });
    this.toolForm.get('BodyLength').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      const maxLimit = value; // Change this logic as needed
      if (value) {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('BodyLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(100.00)]);
          this.BodyLengthError = "Value for length must be between 0.00 and 100.00 (ft)"
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('BodyLength').setValidators([Validators.required, Validators.min(0.00), Validators.max(30.48)]);
          this.BodyLengthError = "Value for length must be between 0.00 and 30.48 (m)"
        }
      } else {
        if (this.lengthLabel == "ft") {
          this.toolForm.get('BodyLength').setValidators([Validators.min(0.00), Validators.max(100)]);
        }
        else if (this.lengthLabel == "m") {
          this.toolForm.get('BodyLength').setValidators([Validators.min(0.00), Validators.max(30.48)]);

        }
      }
      this.toolForm.get('BodyLength').updateValueAndValidity({ emitEvent: false });
    });

    this.toolForm.get('ConnectionConfiguration').valueChanges.subscribe((value) => {
      // Adjust the max value dynamically based on inputA value
      if (value == 2 || value == 5) {
        this.toolForm.get('BottomThreadType').setValidators([]);
        this.toolForm.get('BottomMUT').setValidators([]);
        this.toolForm.get('BottomThreadType').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BottomMUT').updateValueAndValidity({ emitEvent: false });
      }
      else {
        this.toolForm.get('BottomThreadType').setValidators([Validators.required]);
        this.toolForm.get('BottomMUT').setValidators([Validators.required]);
        this.toolForm.get('BottomThreadType').updateValueAndValidity({ emitEvent: false });
        this.toolForm.get('BottomMUT').updateValueAndValidity({ emitEvent: false });
      }
    });


    this.getToolSizeDropdown()
      .then((data) => {
        //console.log("tool sizes", data.result);
        this.toolSizeOptions = [];
        this.toolSizeOptions = data.result.map(item => item.NominalOD);
        this.filteredToolSizeOptions.next(this.toolSizeOptions);
        this.filterControltoolSize
          .valueChanges
          .subscribe({
            next: () => {
              let filter = this.filterControltoolSize.value.toString().toLowerCase();
              let filteredList = this.toolSizeOptions.filter(
                option => option.toString().toLowerCase().indexOf(filter) >= 0
              );
              this.filteredToolSizeOptions.next(filteredList);
            }
          });
        this.toolForm.get('ToolSize').patchValue(4.75);

        return this.getConnectionsDropdown();
      })
      .then((data) => {
        this.threadTypeOptions = [...data.result];
        this.filteredTopThreadTypeOptions.next(this.threadTypeOptions);
        this.filterControlTopThreadType
          .valueChanges
          .subscribe({
            next: () => {
              let filter = this.filterControlTopThreadType.value.toLowerCase();
              let filteredList = this.threadTypeOptions.filter(
                option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
              );
              this.filteredTopThreadTypeOptions.next(filteredList);
            }
          });
        let topThreadTypeIdVal = this.threadTypeOptions.findIndex((item) => item.ConnectionName === "NC44");
        if (topThreadTypeIdVal)
          this.toolForm.get('TopThreadType').patchValue(parseInt(this.threadTypeOptions[topThreadTypeIdVal].ConnectionId));

        this.filteredBottomThreadTypeOptions.next(this.threadTypeOptions);
        this.filterControlBottomThreadType
          .valueChanges
          .subscribe({
            next: () => {
              let filter = this.filterControlBottomThreadType.value.toLowerCase();
              let filteredList = this.threadTypeOptions.filter(
                option => option.ConnectionName.toLowerCase().indexOf(filter) >= 0
              );
              this.filteredBottomThreadTypeOptions.next(filteredList);
            }
          });
        this.toolForm.get('BottomThreadType').patchValue(parseInt(this.threadTypeOptions[topThreadTypeIdVal].ConnectionId));
        //get materials
        return this.getMaterialsDropdown();
      })
      .then((data) => {
        this.materialOptions = [...data.result];
        this.filteredMaterialOptions.next(this.materialOptions);
        this.filterControlMaterials
          .valueChanges
          .subscribe({
            next: () => {
              let filter = this.filterControlMaterials.value.toLowerCase();
              let filteredList = this.materialOptions.filter(
                option => option.MaterialName.toLowerCase().indexOf(filter) >= 0
              );
              this.filteredMaterialOptions.next(filteredList);
            }
          });
        let materialIdVal = this.materialOptions.findIndex((item) => item.MaterialName === "Carbon Steel");
        if (materialIdVal)
          this.toolForm.get('Material').patchValue(parseInt(this.materialOptions[materialIdVal].MaterialId));

        return new Promise((resolve) => { resolve("success") });
      })
      .then((data) => {
        //console.log("received data in bit form",this.updateData);
        if (this.updateData) {
          //set values in form
          let toolsize = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool Size, in'] })?.value;
          if (toolsize)
            this.toolForm.get('ToolSize').patchValue(parseFloat(toolsize));
          let typeId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Fishing type'] })?.value;
          if (typeId)
            this.toolForm.get('Type').patchValue(parseInt(typeId));
          this.toolForm.get('Description').patchValue(this.updateData.toolDetails.Description);
          this.toolForm.get('Length').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Length, m'] })?.value);
          let toolweightoption = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool weight option'] })?.value;
          this.toolForm.get('ToolWeightOption').patchValue(parseInt(toolweightoption));
          if (this.toolForm.get('ToolWeightOption').value == 0) {
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').disable();
          }
          else if (this.toolForm.get('ToolWeightOption').value == 1) {
            this.toolForm.get('AdjustedWeight').enable();
            this.toolForm.get('Mass').disable();
          }
          else if (this.toolForm.get('ToolWeightOption').value == 2) {
            this.toolForm.get('AdjustedWeight').disable();
            this.toolForm.get('Mass').enable();
          }
          this.toolForm.get('Mass').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Mass, kg'] })?.value);
          this.toolForm.get('AdjustedWeight').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Adjusted kg/m'] })?.value);
          this.toolForm.get('NW').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['NW kg/m'] })?.value);
          let toolconfId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Tool configuration'] })?.value
          if (toolconfId)
            this.toolForm.get('ToolConfiguration').patchValue(parseInt(toolconfId));
          let materialId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Material'] })?.value;
          if (materialId)
            this.toolForm.get('Material').patchValue(parseInt(materialId));


          let connConfId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Connection configuration'] })?.value;
          if (connConfId)
            this.toolForm.get('ConnectionConfiguration').patchValue(parseInt(connConfId));

          this.toolForm.get('Nozzles').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Nozzles'] })?.value);
          //nozzle section
          this.nozzleArrayList = this.updateData.nozzleSections.map((item) => {
            return item.value;
          });
          this.nozzleArrayListError = Array.from({ length: this.nozzleArrayList.length }, (_, index) => "");
          if (this.nozzleArrayList.length > 0) {
            this.isNozzleChecked = true;
            this.toolForm.get('TFA').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['TFA'] })?.value);
            this.toolForm.get('Efficiency').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Efficiency'] })?.value);
          }
          let connectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Thread type'] })?.value
          if (connectionId)
            this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
          this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top MUT n-m'] })?.value);
          if (this.toolForm.get('ConnectionConfiguration').value != 6 && this.toolForm.get('ConnectionConfiguration').value != 5) {
            let bottomconnectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom thread type'] })?.value
            if (bottomconnectionId)
              this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
            this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom MUT'] })?.value);
          }
          this.toolForm.get('BodyOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Body OD'] })?.value);
          this.toolForm.get('BodyID').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Body ID'] })?.value);
          this.toolForm.get('BodyLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Body length'] })?.value);

          this.toolForm.get('FishneckOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Fishneck OD mm'] })?.value);
          this.toolForm.get('FishneckID').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Fishneck ID mm'] })?.value);
          this.toolForm.get('FishneckLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Fishneck length m'] })?.value);

          this.toolForm.get('GaugeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Gauge OD, mm'] })?.value);
          this.toolForm.get('GaugeID').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Gauge ID, mm'] })?.value);
          this.toolForm.get('GaugeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Gauge Length, m'] })?.value);

          this.toolForm.get('FaceOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Face OD'] })?.value);
          this.toolForm.get('FaceID').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Face ID'] })?.value);
          this.toolForm.get('FaceLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Face Length'] })?.value);

          this.toolForm.get('BladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Blade OD, mm'] })?.value);
          this.toolForm.get('BladeID').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Blade ID, mm'] })?.value);
          this.toolForm.get('BladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Blade Length, m'] })?.value);

          this.toolForm.get('StabilizerFishneckBladeOD').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade OD'] })?.value);
          this.toolForm.get('StabilizerFishneckBladeCount').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Count'] })?.value);
          this.toolForm.get('StabilizerFishneckBladeWidth').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Width'] })?.value);
          this.toolForm.get('StabilizerFishneckBladeLength').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Length'] })?.value);
          this.toolForm.get('StabilizerFishneckBladeAngle').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top stabilizer Blade Angle'] })?.value);
          if (this.toolForm.get('StabilizerFishneckBladeOD').value) {
            this.isStabilizerFishneckChecked = true;
          }

        }
        else {

          this.toolForm.get('Mass')?.patchValue(0);
          this.toolForm.get('AdjustedWeight')?.patchValue(0);
          this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
        }

        this.emitData();
      });
  }

  async getMaterialsDropdown() {

    let data;
    try {
      data = await lastValueFrom(this.materialService.getMaterialsList());
    }
    catch (e) {
      this.toastR.error("Something went wrong while fetching materials");
    }
    return data;
  }//end of functions

  async getToolSizeDropdown() {

    let data;
    try {
      data = await lastValueFrom(this.customToolService.getToolSizesList());
    }
    catch (e) {
      this.toastR.error("Something went wrong while fetching tool sizes");
    }
    return data;
  }//end of functions

  async getConnectionsDropdown() {

    let data;
    try {
      data = await lastValueFrom(this.connectionService.getConnectionDropdownList());
    }
    catch (e) {
      this.toastR.error("Something went wrong while fetching connections");
    }
    return data;
  }//end of function

  onchangeToolWeight() {
    this.toolForm.get('Mass')?.patchValue(0);
    this.toolForm.get('AdjustedWeight')?.patchValue(0);
    if (this.toolForm.get('ToolWeightOption').value == 0) {
      this.toolForm.get('AdjustedWeight').disable();
      this.toolForm.get('Mass').disable();
      if (this.toolForm.get('Length').value)
        this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value / this.toolForm.get('Length').value);
      else
        this.toolForm.get('AdjustedWeight').patchValue(0);
      this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value * this.toolForm.get('Length').value);
    }
    else if (this.toolForm.get('ToolWeightOption').value == 1) {
      this.toolForm.get('AdjustedWeight').enable();
      this.toolForm.get('Mass').disable();
      this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value * this.toolForm.get('Length').value);
    }
    else if (this.toolForm.get('ToolWeightOption').value == 2) {
      this.toolForm.get('AdjustedWeight').disable();
      this.toolForm.get('Mass').enable();
      this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Mass').value / this.toolForm.get('Length').value);
      this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
    }
  }

  calculateAdjustedWeight() {
    if (this.toolForm.get('Length').value)
      this.toolForm.get('AdjustedWeight').patchValue(this.toolForm.get('Length').value != 0 ? this.toolForm.get('Mass').value / this.toolForm.get('Length').value : 0);
    else
      this.toolForm.get('AdjustedWeight').patchValue(0);
    this.toolForm.get('NW').patchValue(this.toolForm.get('AdjustedWeight').value);
  }

  calculateMass() {
    this.toolForm.get('Mass').patchValue(this.toolForm.get('AdjustedWeight').value * this.toolForm.get('Length').value);
  }

  createNozzleInput(numOfNozzles) {
    this.nozzleArrayList = Array.from({ length: numOfNozzles }, (_, index) => "");
    this.nozzleArrayListError = Array.from({ length: numOfNozzles }, (_, index) => "");
  }



  validateNozzleDiameter(value, i) {
    if (value) {
      if (value < 0) {
        this.nozzleArrayListError[i] = "Nozzle Diameter Must be Greater Than 0";
      }
      else {
        this.nozzleArrayListError[i] = "";
      }
    }
    else {
      this.nozzleArrayListError[i] = "Nozzle Diameter Must be Greater Than 0";
    }
  }


  save() {

    if (this.toolForm.invalid) {
      // Mark all form controls as touched to show errors
      Object.values(this.toolForm.controls).forEach(control => control.markAsTouched());

    }
    this.nozzleArrayList.forEach((element, i) => {
      this.validateNozzleDiameter(element, i)
    });

    let nozzleFlag = true, sectionFlag = true;
    this.nozzleArrayListError.forEach((item) => {
      if (item) {
        nozzleFlag = false
      }
    });


    //console.log("validity flags",this.toolForm.valid,nozzleFlag);
    //call api below if all the flags are true

    if (this.toolForm.valid && nozzleFlag) {
      let payload = this.createPayload();
      if (this.updateData) {
        this.customToolService.updateCustomTool(this.templateId, payload).subscribe({
          next: (data) => {
            //console.log(data);
            this.toastR.success("Custom Tool Updated Successfully");
            this.formSubmitEvent.emit("success");
          },
          error: (error) => {
            this.toastR.error("Something went wrong");
          }
        });
      }
      else {

        this.customToolService.addCustomTool(payload).subscribe({
          next: (data) => {
            //console.log(data);
            this.toastR.success("Custom Tool Added Successfully");
            this.formSubmitEvent.emit("success");
          },
          error: (error) => {
            this.toastR.error("Something went wrong");
          }
        });
      }

    }
  }

  cancel() {
    this.formSubmitEvent.emit("cancel");
  }

  createPayload() {


    let payload = {
      "details": {
        "toolDetails": {
          "ToolSizeId": this.Tool,
          "Description": this.toolForm.get("Description").value,
          "CustomToolCatalogId": sessionStorage.getItem("workitem"),
          "ToolType": this.toolForm.get('Type').value,
          "ToolConfiguration": this.toolForm.get("ToolConfiguration").value
        },
        "toolValues": [
          {
            "Id": toolColumns['Length, m'],
            "ColumnName": "Length, m",
            "value": this.toolForm.get("Length").value
          },
          {
            "Id": toolColumns['Tool configuration'],
            "ColumnName": "Tool configuration",
            "value": this.toolForm.get("ToolConfiguration").value
          },
          {
            "Id": toolColumns['Tool weight option'],
            "ColumnName": "Tool weight option",
            "value": this.toolForm.get("ToolWeightOption").value
          },
          {
            "Id": toolColumns['Tool Size, in'],
            "ColumnName": "Tool Size, in",
            "value": this.toolForm.get("ToolSize").value
          },
          {
            "Id": toolColumns['Mass, kg'],
            "ColumnName": "Mass, kg",
            "value": this.toolForm.get('Mass').value
          },
          {
            "Id": toolColumns['Type'],
            "ColumnName": "Type",
            "value": this.toolForm.get('Type').value
          },
          {
            "Id": toolColumns['Adjusted kg/m'],
            "ColumnName": "Adjusted kg/m",
            "value": this.toolForm.get('AdjustedWeight').value
          },
          {
            "Id": toolColumns['NW kg/m'],
            "ColumnName": "NW kg/m",
            "value": this.toolForm.get('NW').value
          },

          {
            "Id": toolColumns['Material'],
            "ColumnName": "Material",
            "value": this.toolForm.get('Material').value
          },

          {
            "Id": toolColumns['Connection configuration'],
            "ColumnName": "Connection configuration",
            "value": this.toolForm.get('ConnectionConfiguration').value

          },
          {
            "Id": toolColumns['TFA'],
            "ColumnName": "TFA",
            "value": this.toolForm.get('TFA').value ? this.toolForm.get('TFA').value : 0
          },
          {
            "Id": toolColumns['Efficiency'],
            "ColumnName": "Efficiency",
            "value": this.toolForm.get('Efficiency').value ? this.toolForm.get('Efficiency').value : ""
          },
          {
            "Id": toolColumns['Nozzles'],
            "ColumnName": "Nozzles",
            "value": this.toolForm.get('Nozzles').value
          },
          {
            "Id": toolColumns['Top stabilizer Blade OD'],
            "ColumnName": "Top stabilizer Blade OD",
            "value": this.toolForm.get('StabilizerFishneckBladeOD').value ? this.toolForm.get('StabilizerFishneckBladeOD').value : ""
          },
          {
            "Id": toolColumns['Top stabilizer Blade Count'],
            "ColumnName": "Top stabilizer Blade Count",
            "value": this.toolForm.get('StabilizerFishneckBladeCount').value ? this.toolForm.get('StabilizerFishneckBladeCount').value : ""
          },
          {
            "Id": toolColumns['Top stabilizer Blade Width'],
            "ColumnName": "Top stabilizer Blade Width",
            "value": this.toolForm.get('StabilizerFishneckBladeWidth').value ? this.toolForm.get('StabilizerFishneckBladeWidth').value : ""
          },
          {
            "Id": toolColumns['Top stabilizer Blade Length'],
            "ColumnName": "Top stabilizer Blade Length",
            "value": this.toolForm.get('StabilizerFishneckBladeLength').value ? this.toolForm.get('StabilizerFishneckBladeLength').value : ""
          },
          {
            "Id": toolColumns['Top stabilizer Blade Angle'],
            "ColumnName": "Top stabilizer Blade Angle",
            "value": this.toolForm.get('StabilizerFishneckBladeAngle').value ? this.toolForm.get('StabilizerFishneckBladeAngle').value : ""
          },
          {
            "Id": toolColumns['Thread type'],
            "ColumnName": "Thread type",
            "value": this.toolForm.get('TopThreadType').value
          },
          {
            "Id": toolColumns['Top MUT n-m'],
            "ColumnName": "Top MUT n-m",
            "value": this.toolForm.get('TopMUT').value
          },
          {
            "Id": toolColumns['Bottom thread type'],
            "ColumnName": "Bottom thread type",
            "value": this.toolForm.get('TopThreadType').value
          },
          {
            "Id": toolColumns['Bottom MUT'],
            "ColumnName": "Bottom MUT",
            "value": this.toolForm.get('TopMUT').value
          },
          {
            "Id": toolColumns['Body OD'],
            "ColumnName": "Body OD",
            "value": this.toolForm.get('BodyOD').value ? this.toolForm.get('BodyOD').value : ""
          },
          {
            "Id": toolColumns['Body ID'],
            "ColumnName": "Body ID",
            "value": this.toolForm.get('BodyID').value ? this.toolForm.get('BodyID').value : ""
          },
          {
            "Id": toolColumns['Body length'],
            "ColumnName": "Body length",
            "value": this.toolForm.get('BodyLength').value ? this.toolForm.get('BodyLength').value : ""
          },
          {
            "Id": toolColumns['Gauge OD, mm'],
            "ColumnName": 'Gauge OD, mm',
            "value": this.toolForm.get('GaugeOD').value ? this.toolForm.get('GaugeOD').value : ""
          },
          {
            "Id": toolColumns['Gauge ID, mm'],
            "ColumnName": "Gauge ID, mm",
            "value": this.toolForm.get('GaugeID').value ? this.toolForm.get('GaugeID').value : ""
          },
          {
            "Id": toolColumns['Gauge Length, m'],
            "ColumnName": "Gauge Length, m",
            "value": this.toolForm.get('GaugeLength').value ? this.toolForm.get('GaugeLength').value : ""
          },
          {
            "Id": toolColumns['Face OD, mm'],
            "ColumnName": 'Face OD, mm',
            "value": this.toolForm.get('FaceOD').value ? this.toolForm.get('FaceOD').value : ""
          },
          {
            "Id": toolColumns['Face ID, mm'],
            "ColumnName": "Face ID, mm",
            "value": this.toolForm.get('FaceID').value ? this.toolForm.get('FaceID').value : ""
          },
          {
            "Id": toolColumns['Face Length, m'],
            "ColumnName": "Face Length, m",
            "value": this.toolForm.get('FaceLength').value ? this.toolForm.get('FaceLength').value : ""
          },
          {
            "Id": toolColumns['Fishneck OD mm'],
            "ColumnName": 'Fishneck OD mm',
            "value": this.toolForm.get('FishneckOD').value ? this.toolForm.get('FishneckOD').value : ""
          },
          {
            "Id": toolColumns['Fishneck ID mm'],
            "ColumnName": "Fishneck ID mm",
            "value": this.toolForm.get('FishneckID').value ? this.toolForm.get('FishneckID').value : ""
          },
          {
            "Id": toolColumns['Fishneck length m'],
            "ColumnName": "Fishneck length m",
            "value": this.toolForm.get('FishneckLength').value ? this.toolForm.get('FishneckLength').value : ""
          },
          {
            "Id": toolColumns['Blade OD, mm'],
            "ColumnName": 'Blade OD, mm',
            "value": this.toolForm.get('BladeOD').value ? this.toolForm.get('BladeOD').value : ""
          },
          {
            "Id": toolColumns['Blade ID, mm'],
            "ColumnName": "Blade ID, mm",
            "value": this.toolForm.get('BladeID').value ? this.toolForm.get('BladeID').value : ""
          },
          {
            "Id": toolColumns['Blade Length, m'],
            "ColumnName": 'Blade Length, m',
            "value": this.toolForm.get('BladeLength').value ? this.toolForm.get('BladeLength').value : ""
          },
        ]

        ,
        "nozzleSections": this.nozzleArrayList.map((item) => {
          return {
            "Id": toolColumns['Nozzle Diameter, x 1/32'],
            "ColumnName": "Nozzle Diameter, x 1/32",
            "value": item
          }
        })

      }

    }

    return payload;
  }

  nozzleCheckboxChanged(event) {
    // Do something with the event or checkbox state
    if (event) {
      //console.log("Checkbox is checked");
      this.toolForm.get('TFA').setValidators([Validators.required, Validators.min(1)]);
      this.toolForm.get('TFA').updateValueAndValidity({ emitEvent: false });
    } else {
      //console.log("Checkbox is unchecked");
      this.toolForm.get('TFA').setValidators([Validators.min(1)]);
      this.toolForm.get('TFA').updateValueAndValidity({ emitEvent: false });
    }
    this.toolForm.get('TFA').patchValue(0);
    this.toolForm.get('Efficiency').patchValue(95);
    this.toolForm.get('Nozzles').patchValue('');
    this.nozzleArrayList = [];
    this.nozzleArrayListError = [];
  }


  // Stablizers check box checked
  stabilizerFishneckCheckboxChanged(event) {
    // Do something with the event or checkbox state
    if (event) {
      //console.log("Checkbox is checked");
      this.toolForm.get('StabilizerFishneckBladeOD').setValidators([Validators.required, CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
      this.toolForm.get('StabilizerFishneckBladeCount').setValidators([Validators.required, Validators.max(1000000000), Validators.min(-1000000000)]);
      this.toolForm.get('StabilizerFishneckBladeWidth').setValidators([Validators.required]);
      this.toolForm.get('StabilizerFishneckBladeLength').setValidators([Validators.required]);
      this.toolForm.get('StabilizerFishneckBladeAngle').setValidators([Validators.required]);

    } else {
      //console.log("Checkbox is unchecked");
      this.toolForm.get('StabilizerFishneckBladeOD').setValidators([CustomValidators.greaterThanZero, CustomValidators.greaterThanMin(this.toolForm.get('TopSubNominalOD').value)]);
      this.toolForm.get('StabilizerFishneckBladeCount').setValidators([Validators.max(1000000000), Validators.min(-1000000000)]);
      this.toolForm.get('StabilizerFishneckBladeWidth').setValidators([]);
      this.toolForm.get('StabilizerFishneckBladeLength').setValidators([]);
      this.toolForm.get('StabilizerFishneckBladeAngle').setValidators([]);

    }
    this.toolForm.get('StabilizerFishneckBladeOD').updateValueAndValidity();
    this.toolForm.get('StabilizerFishneckBladeCount').updateValueAndValidity();
    this.toolForm.get('StabilizerFishneckBladeWidth').updateValueAndValidity();
    this.toolForm.get('StabilizerFishneckBladeLength').updateValueAndValidity();
    this.toolForm.get('StabilizerFishneckBladeAngle').updateValueAndValidity();

    this.toolForm.get('StabilizerFishneckBladeOD').patchValue('');
    this.toolForm.get('StabilizerFishneckBladeCount').patchValue('');
    this.toolForm.get('StabilizerFishneckBladeWidth').patchValue('');
    this.toolForm.get('StabilizerFishneckBladeLength').patchValue('');
    this.toolForm.get('StabilizerFishneckBladeAngle').patchValue('');
  }

  resetThreadtype() {
    if (this.updateData) {
      let connectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Thread type'] })?.value
      if (connectionId)
        this.toolForm.get('TopThreadType').patchValue(parseInt(connectionId));
      this.toolForm.get('TopMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Top MUT n-m'] })?.value);
      if (this.toolForm.get('ConnectionConfiguration').value != 6 && this.toolForm.get('ConnectionConfiguration').value != 5) {
        let bottomconnectionId = this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom thread type'] })?.value
        if (bottomconnectionId)
          this.toolForm.get('BottomThreadType').patchValue(parseInt(bottomconnectionId));
        this.toolForm.get('BottomMUT').patchValue(this.updateData.toolValues.find((item) => { return item.Id === toolColumns['Bottom MUT n-m'] })?.value);
      }

    }
    else {
      this.toolForm.get('TopThreadType').patchValue('');
      this.toolForm.get('TopMUT').patchValue('');
      this.toolForm.get('BottomThreadType').patchValue('');
      this.toolForm.get('BottomMUT').patchValue('');

    }
  }

  emitData() {
    this.threeDParams.emit({
      length: this.toolForm.get("Length").value,
      toolSize: this.toolForm.get("ToolSize").value,
      toolType: this.toolForm.get("Type").value,
      toolConf: this.toolForm.get("ToolConfiguration").value,
    });
  }

  /*
  ** get active unit from active unit system and integration with labels, placeholders and headers
  */
  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          console.log("res in casing---", res);
          let activeUnitSystemData = res;
          this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
          this.lengthLabel = activeUnitSystemData.length.unitValue;
          this.massLabel = activeUnitSystemData.mass.unitValue;
          this.linearMassDensityLabel = activeUnitSystemData.linearMassDensity.unitValue;
          this.torqueLabel = activeUnitSystemData.torque.unitValue;
          this.percentageLabel = activeUnitSystemData.percentage.unitValue;
          this.forceLabel = activeUnitSystemData.force.unitValue;
          this.stressLabel = activeUnitSystemData.stress.unitValue;
          this.nozzleSizeLabel = activeUnitSystemData.nozzleSize.unitValue;
          this.rotationVelocityLabel = activeUnitSystemData.rotationVelocity.unitValue;
          this.angleLabel = activeUnitSystemData.angle.unitValue;
          this.pressureLabel = activeUnitSystemData.pressure.unitValue;
          this.flowLabel = activeUnitSystemData.flow.unitValue;
          // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);

        } else {
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);
      }
    })
  }
}
