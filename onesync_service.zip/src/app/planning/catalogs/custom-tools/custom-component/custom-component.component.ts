import { Component, OnInit, ViewChild } from '@angular/core';
import { lastValueFrom } from 'rxjs/internal/lastValueFrom';
import * as _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { Column } from 'src/app/core/interfaces/column.interface';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { CustomToolService } from 'src/app/core/services/customTool.service';
import { CustomComponent } from 'src/app/core/interfaces/customcomponent.interface';
import { LithilogiesService } from 'src/app/core/services/lithilogies.service';
import { CustomToolAddComponent } from '../custom-tool-add/custom-tool-add.component';
import { ToolStyles } from 'src/app/core/constants/toolObjects.constants';
import { UnitsService } from 'src/app/core/services/units.service';

@Component({
  selector: 'app-custom-component',
  templateUrl: './custom-component.component.html',
  styleUrls: ['./custom-component.component.scss']
})
export class CustomComponentComponent implements OnInit {
    tableColumns:  Array<Column>;
    tableData: CustomComponent[] = [];
    gridSize:any = 'col-lg-12';
    show3D:any = false;
    modelWidth: any;
    modelHeight: any;
    objType:any=2;
    shortLengthLabel: string = "";//(in or mm)
  lengthLabel: string = "";//(ft or m)
  linearMassDensityLabel:string="";// (lb/ft or kg/m)
  massLabel:string="";// (lbm or Kg)
    @ViewChild('threeDSceneContainer') threeDSceneContainer: any;
    threedStyles:any;
    constructor(private customToolService: CustomToolService,
      private unitsService: UnitsService,private dialog: MatDialog, private toastR: ToastrService){

    }
  ngOnInit(): void {

    this.getActiveUnitSystemData();

    this.tableColumns = [
        {columnDef:"Name",header:"Tool",cell: (element: Record<string, any>) => `${element['Name']}`},
        {columnDef:"toolSize",header:"Tool Size, in",cell: (element: Record<string, any>) => `${element['toolSize']}`},
        {columnDef:"Description",header:"Description",cell: (element: Record<string, any>) => `${element['Description']}`},
        {columnDef:"lengthFt",header:"Length, ft",cell: (element: Record<string, any>) => `${element['lengthFt']}`},
        {columnDef:"massLbm",header:"Mass, lbm",cell: (element: Record<string, any>) => `${element['massLbm']}`},
        {columnDef:"nwLbFt",header:"NW, lb/ft",cell: (element: Record<string, any>) => `${element['nwLbFt']}`},
        ];

      /**
     * Service call to get tools list
     */
      let workitemId = sessionStorage.getItem("workitem")
        this.getToolsList(workitemId);
     //end of service call

     
  }
  
  addRow(){
    const dialogRef = this.dialog.open(CustomToolAddComponent, {
      height: "calc(100% -30px)",
      width: "calc(100% - 30px)",
      maxWidth: "100%",
      maxHeight: "100%",
        data: {
          title: "Add Tool",
        },
        panelClass:"overflow-x-hidden",
        position:{right:'10px', top: '40px'} 
      });
  
      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          if (result.action === 'success') {
            //console.log('User clicked the save button.');
          let workitem = sessionStorage.getItem("workitem");
           this.getToolsList(workitem);
          }
          else if (result.action === 'cancel') {
            //console.log('User clicked the Cancel button.');
          }
        }
        else {
          //console.log('Dialog was closed without any action.');
          let workitem = sessionStorage.getItem("workitem");
           this.getToolsList(workitem);
        }
      });
  }
  
  getToolsList(workitemId){
    this.customToolService.getCustomToolList(workitemId).subscribe({

      next: (data) => {
        //console.log("tools",data.result);
        this.tableData = [...data.result];
      },
      error: (error) => {
        //console.log("tools",error.error.result);
        this.tableData = error.error.result;
      }

    });
  }

  reset(){
    let workitemId = sessionStorage.getItem("workitem")
        this.getToolsList(workitemId);
  }
  update(event){
    //console.log("update event", event);
    const dialogRef = this.dialog.open(CustomToolAddComponent, {
      height: "calc(100% -30px)",
      width: "calc(100% - 30px)",
      maxWidth: "100%",
      maxHeight: "100%",
      data: {
        title: "Update Tool",
        payload: event
      },
      panelClass:"overflow-x-hidden",
      position:{right:'10px', top: '40px'} 
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.action === 'success') {
          //console.log('User clicked the save button.');
          let workitem = sessionStorage.getItem("workitem");
           this.getToolsList(workitem);
         
        }
        else if (result.action === 'cancel') {
          //console.log('User clicked the Cancel button.');
        }
      }
      else {
        //console.log('Dialog was closed without any action.');
        let workitem = sessionStorage.getItem("workitem");
           this.getToolsList(workitem);
      }
    });
  }

  deleteRow(event){
    let deletePayload = {
      "TemplateId" : event.TemplateId
    }
    this.customToolService.deleteCustomTool(deletePayload).subscribe({
      next:(data)=>{
        this.toastR.success("Custom Tool deleted successfully");
        let workitem = sessionStorage.getItem('workitem');
        this.getToolsList(workitem);
      },
      error:(error)=>{
        this.toastR.error("Something went wrong!");
      }
    });
  }

  select(event){
    //console.log("selected custom tool", event);
    

    this.threedStyles = {...ToolStyles[event.ToolSizeId],
      LengthDimension:parseFloat(event.lengthFt)+" "+this.lengthLabel,
      ToolSizeDimension:parseFloat(event.ToolSizeIn)+" "+this.shortLengthLabel,
      Sketch:{
        tool:event.ToolSizeId,
        dimensionText:{
          length: {text:event.lengthFt+" "+this.lengthLabel},
          toolsize:{text:event.ToolSizeIn+" "+this.shortLengthLabel},
        },
        templateId:event.TemplateId,
      },
      ToolType:event.ToolType,
      ToolConf:event.ToolConfiguration
    };
    //console.log("Styles",this.threedStyles);
    
  }
  close3D(){
    this.gridSize = "col-lg-12";
    this.show3D = false;
  }

  changeType(type){
    this.objType = type;
  }

  open3D(){
    this.gridSize = "col-lg-8";
    this.show3D = true;
    setTimeout(() => {
      try{
      if(!this.modelWidth && !this.modelHeight){
      const parentDiv = this.threeDSceneContainer.nativeElement;
      this.modelWidth = parentDiv.clientWidth;
      this.modelHeight = parentDiv.clientHeight<300?400:parentDiv.clientHeight;
    }}
      catch(e){
        //console.log("3D container hidden",e);
      }
    }, 1000
    )
  }

          /*
    ** get active unit from active unit system and integration with labels, placeholders and headers
    */
    getActiveUnitSystemData() {
  
      // this.unitSystemData = {};
      this.unitsService.getActiveUnitSystemDetails().subscribe({
          next: (res) => {
              if (res) {
                  //console.log("res in casing---", res);
                  let activeUnitSystemData = res;
                  this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
                  this.lengthLabel = activeUnitSystemData.length.unitValue;
                  this.linearMassDensityLabel=activeUnitSystemData.linearMassDensity.unitValue;
                  this.massLabel = activeUnitSystemData.mass.unitValue;
                  this.tableColumns[1].header="Tool Size, "+this.shortLengthLabel+"";
                  this.tableColumns[3].header="Length, "+this.lengthLabel+"";
                  this.tableColumns[4].header="Mass, "+this.massLabel+"";
                  this.tableColumns[5].header="NW, "+this.linearMassDensityLabel+"";
                  //console.log("res in 3D case component shortLengthLabel---", this.shortLengthLabel);
                  //console.log("res in 3D case component lengthLabel---", this.lengthLabel);
                  // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
  
              } else {
                  //console.log('error');
              }
          },
          error: (error) => {
              //console.log("Unit", error.error.result);
          }
      })
  }
}
