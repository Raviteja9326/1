import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, UntypedFormArray, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-centralizers-details',
  templateUrl: './centralizers-details.component.html',
  styleUrls: ['./centralizers-details.component.scss']
})
export class CentralizersDetailsComponent implements OnInit {
  
  centralizersForm=this.fb.group({
    Inclination:["",[Validators.required]],
    Part:["",[Validators.required]],
    LegacyPart:["",[Validators.required]],
    Type:["",[Validators.required]],
    CrossSectionalArea:["",[Validators.required]],
    BowThickness:["",[Validators.required]],
    BowType:["",[Validators.required]],
    BowWidth:["",[Validators.required]],
    OfBows:["",[Validators.required]],
    Length:["",[Validators.required]],
    EffectiveFlowOD:["",[Validators.required]],
    NominalID:["",[Validators.required]],
    MaxOD:["",[Validators.required]],
    RigidOD:["",[Validators.required]],
    PipeSize:["",[Validators.required]],
    Family:["",[Validators.required]],
    StopCollar:["",[Validators.required]],
  });
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef < CentralizersDetailsComponent>
    ) { } // constructor ends

  ngOnInit(): void {
   
  }


  close() {

     /*To close add centralizers dialog */
    this.dialogRef.close();
  }

  centralizersSubmit(){

  }

}
