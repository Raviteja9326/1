import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CentralizersService } from 'src/app/core/services/centralizers.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-centralizers-moreinfo',
  templateUrl: './centralizers-moreinfo.component.html',
  styleUrls: ['./centralizers-moreinfo.component.scss']
})
export class CentralizersMoreinfoComponent implements OnInit {
  tableColumns: Array<any>;
  tableData: any[] = [];
  rowData: {} = {}
  constructor(private CentralizersService: CentralizersService, private route: Router) { }

  ngOnInit(): void {
    this.tableColumns = [
      { columnDef: "CentraWeight", header: "Weight, lbf", cell: (element: Record<string, any>) => `${element['CentraWeight']}` },
      { columnDef: "PipeSize", header: "Pipe Size, in", cell: (element: Record<string, any>) => `${element['PipeSize']}` },
      { columnDef: "HoleSize", header: "Hole Size, in", cell: (element: Record<string, any>) => `${element['HoleSize']}` },
      { columnDef: "FlexedOuterDiameter", header: "Flexed OD, in", cell: (element: Record<string, any>) => `${element['FlexedOuterDiameter']}` },
      { columnDef: "OuterDiameterBeforeTest", header: "OD Before Test, in", cell: (element: Record<string, any>) => `${element['OuterDiameterBeforeTest']}` },
      { columnDef: "OuterDiameterAfterTest", header: "OD After Test, in", cell: (element: Record<string, any>) => `${element['OuterDiameterAfterTest']}` },
      { columnDef: "RunningForce", header: "Running Force, lbf", cell: (element: Record<string, any>) => `${element['RunningForce']}` },
      { columnDef: "RestoringForce", header: "Restoring Force, lbf", cell: (element: Record<string, any>) => `${element['RestoringForce']}` },
      { columnDef: "StartingForce", header: "Starting Force, lbf", cell: (element: Record<string, any>) => `${element['StartingForce']}` },
      { columnDef: "Restriction", header: "Restriction, in", cell: (element: Record<string, any>) => `${element['Restriction']}` },
      { columnDef: "Standoff", header: "StandOff, %", cell: (element: Record<string, any>) => `${element['Standoff']}` },
      { columnDef: "Equation", header: "Equation", cell: (element: Record<string, any>) => `${element['Equation']}` },
      { columnDef: "CentralizerDisplacementForces", header: "Displacement Forces", cell: (element: Record<string, any>) => `${element['CentralizerDisplacementForces']}` }

    ];
    this.getRowData();
    this.getCentralizersMoreInfoList();
  }

  getRowData() {
    this.rowData = this.CentralizersService.moreInfoRowData
    //console.log(this.rowData)
  }

  getCentralizersMoreInfoList() {
    let id = this.rowData?.['CentralizerType']
    let templateID = sessionStorage.getItem("centralizerTemplateKey");
    console.log("ID_AT_MOREINFO: " + templateID);
    if (id !== undefined) {
      this.CentralizersService.getMoreInfoList(templateID).subscribe({
        next: (data) => {
          //console.log("CentralizersMoreInfo", data);
          this.tableData = [...data.result];
        },
        error: (error) => {
          //console.log("CentralizersMoreInfo", error.error.result);
          this.tableData = [];
        }

      });
    }
  }

  goback() {
    // Swal.fire({
    //   title: `Are you sure, you want to go back? <br/> You have some unsaved changes.`,
    //   showDenyButton: true,
    //   showCancelButton: false,
    //   allowOutsideClick: false,
    //   confirmButtonText: `Yes`,
    //   denyButtonText: `No`,
    // }).then((result) => {
    //   if (result.isConfirmed) {
    this.route.navigate(['dashboard/catalogs/centralizers'])
    this.CentralizersService.moreInfoRowData = {};
    //   }
    // })

  }
}
