import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CentralizersRoutingModule } from './centralizers-routing.module';

import { HttpClientModule } from '@angular/common/http';
import { AllModule } from 'src/app/shared/all_modules';
import { CentralizersComponent } from './centralizers.component';
import { CentralizersDetailsComponent } from './centralizers-details/centralizers-details.component';
import { CentralizersDeleteComponent } from './centralizers-delete/centralizers-delete.component';
import { CentralizersMoreinfoComponent } from './centralizers-moreinfo/centralizers-moreinfo.component';
@NgModule({
  declarations: [
   CentralizersComponent,CentralizersDetailsComponent,CentralizersDeleteComponent, CentralizersMoreinfoComponent,
  ],
  imports: [
    CommonModule,
    CentralizersRoutingModule,
    AllModule,
    HttpClientModule
  ],
 
})

export class CentralizersModule { }