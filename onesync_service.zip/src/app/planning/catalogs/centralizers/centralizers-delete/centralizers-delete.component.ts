import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-centralizers-delete',
  templateUrl: './centralizers-delete.component.html',
  styleUrls: ['./centralizers-delete.component.scss'],
})
export class CentralizersDeleteComponent implements OnInit {
  
  constructor(
    public dialogRef: MatDialogRef<CentralizersDeleteComponent>,
  ) { }

  ngOnInit(): void {
    // //console.log(this.data);
  }
  close(): void {
    this.dialogRef.close();
  }
}
