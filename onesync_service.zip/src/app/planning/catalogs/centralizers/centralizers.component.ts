import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Centralizers } from 'src/app/core/interfaces/centralizers.interface';
import { Column } from 'src/app/core/interfaces/column.interface';
import { CentralizersDetailsComponent } from './centralizers-details/centralizers-details.component';
import { CentralizersService } from 'src/app/core/services/centralizers.service';
import { Router } from '@angular/router';
import { UnitsService } from 'src/app/core/services/units.service';
@Component({
  selector: 'app-centralizers',
  templateUrl: './centralizers.component.html',
  styleUrls: ['./centralizers.component.scss']
})
export class CentralizersComponent implements OnInit {

  tableColumns: Array<Column>;
  tableData: Centralizers[] = [];
  rowData: {} = {}
  shortLengthLabel:string;//mm or in
  youngsModulusLabel: string;// (kPa/psi)
  peakFrictionAngleLabel:string; //°
  lengthLabel:string// ft or m
  thermalExpCoeffLabel:string; //(/°C)
  tensileStrengthLabel:string; //(kPa)
  uCSLabel:string; //(kPa)
  densityLabel:string; //((kg / m³)-- - (ppg))--- Density
  vPLabel:string; //(m / s)
  vSLabel:string; //(m / s)
  // GR(API)
  specificHeatCapacityLabel:string; //(J / (kg -°C) = (Btu / (Ib -°F)))
  thermalConductivityLabel:string; //(W / (m -°C))
  yieldStressLabel:string; //(kPa)
  private activeUnitSystem: { [key: string]: { precision: number, unitName: number, unitValue: string } };

  constructor(private dialog: MatDialog,
    private CentralizersService: CentralizersService,
    private route: Router, private unitsService: UnitsService,
  ) { }

  ngOnInit(): void {
    this.CentralizersService.moreInfoRowData = {};
    this.tableColumns = [
      { columnDef: "Identification", header: "Identification", cell: (element: Record<string, any>) => `${element['Identification']}` },
      { columnDef: "PartNumber", header: "Part #", cell: (element: Record<string, any>) => `${element['PartNumber']}` },
      { columnDef: "LegacyPartNumber", header: "Legacy Part #", cell: (element: Record<string, any>) => `${element['LegacyPartNumber']}` },
      { columnDef: "CentralizerType", header: "Type", cell: (element: Record<string, any>) => `${element['CentralizerType']}` },
      { columnDef: "CrossSectionArea", header: "Cross Sectional Area, in²", cell: (element: Record<string, any>) => `${element['CrossSectionArea']}` },
      { columnDef: "BowThickness", header: "Bow Thickness", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['BowThickness']}` },
      { columnDef: "BowType", header: "Bow Type", cell: (element: Record<string, any>) => `${element['BowType']}` },
      { columnDef: "BowWidth", header: "Bow Width", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['BowWidth']}` },
      { columnDef: "NumberOfBows", header: "# of Bows", cell: (element: Record<string, any>) => `${element['NumberOfBows']}` },
      { columnDef: "Length", header: "Length", unitType: "length", cell: (element: Record<string, any>) => `${element['Length']}` },
      { columnDef: "EffectiveFlowOD", header: "Effective Flow OD", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['EffectiveFlowOD']}` },
      { columnDef: "NominalID", header: "Nominal ID", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['NominalID']}` },
      { columnDef: "MaxOD", header: "Max OD", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['MaxOD']}` },
      { columnDef: "RigidOD", header: "Rigid OD", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['RigidOD']}` },
      { columnDef: "PipeSize", header: "Pipe Size", unitType: "shortLength", cell: (element: Record<string, any>) => `${element['PipeSize']}` },
      { columnDef: "Family", header: "Family", cell: (element: Record<string, any>) => `${element['Family']}` },
      { columnDef: "StopCollar", header: "Stop Collar", cell: (element: Record<string, any>) => `${element['StopCollar']}` },
    ];
    this.getActiveUnitSystemData()
    this.getCentralizersDetails();
  }

  /**
     * call to get Centralizers list
     */
  getCentralizersDetails() {

    this.CentralizersService.getCentralizersList().subscribe({

      next: (data) => {
        //console.log("Centralizers", data);
        this.tableData = [...data.result];
        for (const obj of data.result) {
          for (const column of this.tableColumns) {
            if (obj[column.columnDef] == null || obj[column.columnDef] == undefined) {
              obj[column.columnDef] = "";
            } else {
              if(['BowThickness', 'BowWidth','Length', 'EffectiveFlowOD', 'NominalID', 'MaxOD', 'RigidOD', 'PipeSize'].includes(column.columnDef)){
                const _precision = this.activeUnitSystem[column.unitType].precision;
                obj[column.columnDef] = obj[column.columnDef].toFixed(_precision);
              }
            }
          }
        }
      },
      error: (error) => {
        //console.log("Centralizers", error.error.result);
        this.tableData = error.error.result;
      }

    });
    //end of service call
  }

  /**
   * To refresh the centralizers table
   */
  reset() {
    this.CentralizersService.moreInfoRowData = {};
    this.getCentralizersDetails();
  }//end of function

  getMoreInfoCentralizers() {
    let len = Object.keys(this.CentralizersService.moreInfoRowData ? this.CentralizersService.moreInfoRowData : {}).length

    if (len > 0) {

      let templatekey = this.CentralizersService.moreInfoRowData.TemplateId;
      console.log("templatekey: " + templatekey);
      sessionStorage.setItem("centralizerTemplateKey", templatekey);

      this.route.navigateByUrl('dashboard/catalogs/centralizers/moreInfo');
    }

  }

  rowDataEmitted(rowData) {
    //console.log(rowData)
    this.CentralizersService.moreInfoRowData = rowData
  }

  getActiveUnitSystemData() {

    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          //console.log("res in lithologies---", res);
          let activeUnitSystemData = res;
          this.activeUnitSystem = res;
          this.peakFrictionAngleLabel = activeUnitSystemData.angle.unitValue;
          this.densityLabel = activeUnitSystemData.density.unitValue;
          this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
          this.lengthLabel = activeUnitSystemData.length.unitValue;
          this.tableColumns[5].header = "Bow Thickness, " + this.shortLengthLabel + '';
          this.tableColumns[7].header = 'Bow Width, ' + this.shortLengthLabel;
          this.tableColumns[9].header = 'Length, ' + this.lengthLabel;
          this.tableColumns[10].header = 'Effective Flow OD, ' + this.shortLengthLabel;
          this.tableColumns[11].header = 'Nominal ID, ' + this.shortLengthLabel;
          this.tableColumns[12].header = 'Max OD, ' + this.shortLengthLabel;
          this.tableColumns[13].header = 'Rigid OD, ' + this.shortLengthLabel + '';
          this.tableColumns[14].header = 'Pipe Size, ' + this.shortLengthLabel;
  
        } else {
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);
      }
    })
  }
  // addCentralizers(){
  //   const dialogRef = this.dialog.open(CentralizersDetailsComponent, {
  //     width: 'auto',
  //     data: '', 
  //     disableClose: false,
  //     autoFocus: false,
  //     panelClass:"dialogue-box",
  //     position: {
  //       top: '10px'
  //     }
  //   });

  //   dialogRef.afterClosed().subscribe((result:any) => {
  //     this.getCentralizersDetails();
  //   });
  // }

  // updateCentralizers(){
  //   const dialogRef = this.dialog.open(CentralizersDetailsComponent, {
  //     width: 'auto',
  //     data: '1', 
  //     disableClose: false,
  //     autoFocus: false,
  //     panelClass:"dialogue-box",
  //     position: {
  //       top: '10px'
  //     }
  //   });

  //   dialogRef.afterClosed().subscribe((result:any) => {
  //     this.getCentralizersDetails();
  //   });
  // }
}
