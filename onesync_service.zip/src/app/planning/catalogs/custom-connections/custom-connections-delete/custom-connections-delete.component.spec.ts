import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomConnectionsDeleteComponent } from './custom-connections-delete.component';

describe('CustomConnectionsDeleteComponent', () => {
  let component: CustomConnectionsDeleteComponent;
  let fixture: ComponentFixture<CustomConnectionsDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomConnectionsDeleteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomConnectionsDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
