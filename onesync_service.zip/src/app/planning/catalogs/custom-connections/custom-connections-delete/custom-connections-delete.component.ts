import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-connections-delete',
  templateUrl: './custom-connections-delete.component.html',
  styleUrls: ['./custom-connections-delete.component.scss']
})
export class CustomConnectionsDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
