import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AllModule } from 'src/app/shared/all_modules';
import { CustomConnectionsRoutingModule } from './custom-connections-routing.module';



@NgModule({
  declarations: [
  
  ],
  imports: [
    CommonModule,
    AllModule,
    CustomConnectionsRoutingModule,
  ]
})
export class CustomConnectionsModule { }
