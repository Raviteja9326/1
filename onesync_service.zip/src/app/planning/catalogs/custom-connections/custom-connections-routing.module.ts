import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomConnectionsComponent } from './custom-connections.component';

const routes: Routes = [
    {
       path: '', 
       component: CustomConnectionsComponent
    }
 ];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomConnectionsRoutingModule { }
