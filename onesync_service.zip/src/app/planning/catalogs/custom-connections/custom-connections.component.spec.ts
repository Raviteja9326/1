import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomConnectionsComponent } from './custom-connections.component';

describe('CustomConnectionsComponent', () => {
  let component: CustomConnectionsComponent;
  let fixture: ComponentFixture<CustomConnectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomConnectionsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomConnectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
