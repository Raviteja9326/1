import { Component, Input, OnInit, Output } from '@angular/core';
import { Column } from 'src/app/core/interfaces/column.interface';
import { customConnections } from 'src/app/core/interfaces/customConnections.interface'
import { TableComponent } from 'src/app/shared/table/table.component';
import { MatDialog } from '@angular/material/dialog';
import { data } from 'jquery';
import { MaterialsService } from 'src/app/core/services/materials.service';
import { ToastrService } from 'ngx-toastr';
import { CustomConnectionsService } from 'src/app/core/services/customConnections.service';
import { slice } from 'lodash';
import { lastValueFrom } from 'rxjs';
import { CustomConnectionsDetailsComponent } from './custom-connections-details/custom-connections-details.component';
import { UnitsService } from 'src/app/core/services/units.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';



@Component({
  selector: 'app-custom-connections',
  templateUrl: './custom-connections.component.html',
  styleUrls: ['./custom-connections.component.scss']
})
export class CustomConnectionsComponent implements OnInit {

  tableData: customConnections[] = [];
  deletedRecords: customConnections[] = [];
  updateData:any;
  clonePayload: object;
  deletePayload: object;
  clonePermitted: boolean = false;
  deleteList: any = [];
  deletePermitted: boolean = false;
  deletedIds : any = [];
  toolSizeListOptions: any = [];
  materialListOptions: any = [];
  shortLengthLabel: string = "";//(in or mm)
  linearMassDensityLabel:string="";// (lb/ft or kg/m)
  lengthLabel: string = "";//(ft or m)
  pressureLabel: string = "";//(kPa or psi)
  torqueLabel: string = "";// (lbf-ft or N-m)
  forceLabel: string = "";// (lbf-ft or N-m)
  originalData: any;
  isChanged: boolean;
  currentData: any = [];
  
  tableColumns:Column[]= [
    {columnDef:"ConnectionToolSizeId",header:"Tool Size,in",cell: (element: Record<string, any>) => `${element['ConnectionToolSizeId']}`},
    {columnDef:"NominalWeight",header:"NW, lb/ft",cell: (element: Record<string, any>) => `${element['NominalWeight']}`,inputType:'number'},
    {columnDef:"Grade",header:"Grade",cell: (element: Record<string, any>) => `${element['Grade']}`},
    {columnDef:"ConnectionName",header:"Name",cell: (element: Record<string, any>) => `${element['ConnectionName']}`},
    {columnDef:"IsSystem",header:"Standard API/Non API",cell: (element: Record<string, any>) => `${((element['IsSystem'] == '0' 
            || element['IsSystem'] == 'false' || element['IsSystem'] == false) ? 'Non API' : 'API')}`},
    {columnDef:"Manufacturer",header:"Manufacturer",cell: (element: Record<string, any>) => `${element['Manufacturer']}`},
    {columnDef:"OuterDiameter",header:"OD, in",cell: (element: Record<string, any>) => `${element['OuterDiameter']}`,inputType:'number'},
    {columnDef:"InnerDiameter",header:"ID, in",cell: (element: Record<string, any>) => `${element['InnerDiameter']}`,inputType:'number'},
    {columnDef:"Length",header:"Length, ft",cell: (element: Record<string, any>) => `${element['Length']}`,inputType:'number'},
    {columnDef:"ConnectionNW",header:"Connection NW, ",cell: (element: Record<string, any>) => `${element['ConnectionNW']}`,inputType:'number'},
    {columnDef:"BurstPressure",header:"Burst Pressure, kPa",cell: (element: Record<string, any>) => `${element['BurstPressure']}`,inputType:'number'},
    {columnDef:"CollapsePressure",header:"Collapse Pressure, kPa",cell: (element: Record<string, any>) => `${element['CollapsePressure']}`,inputType:'number'},
    {columnDef:"YieldTensileStrength",header:"Tension, N",cell: (element: Record<string, any>) => `${element['YieldTensileStrength']}`,inputType:'number'},
    {columnDef:"Compression",header:"Compression, N",cell: (element: Record<string, any>) => `${element['Compression']}`,inputType:'number'},
    {columnDef:"MakeupTorque",header:"Make up Torque, N-m",cell: (element: Record<string, any>) => `${element['MakeupTorque']}`,inputType:'number'},

  ];


  constructor(public dialog: MatDialog,
    private materialsService:MaterialsService,
    private toastr: ToastrService,
    private customConnections:CustomConnectionsService,
    private unitsService: UnitsService,
    private ngxLoader: NgxUiLoaderService) { 

  }

  ngOnInit(): void {
   
    this.originalData = JSON.parse(JSON.stringify(this.tableData));
    
    this.getToolSizeDropdown().then((data) => {

      console.log("getToolSizedropdownAPi", data)
      this.toolSizeListOptions = data.result;
    });

    this.getActiveUnitSystemData();
    this.getCustomConnectionsList();
    
    this.customConnections.selectedCustomConnection.subscribe((value) => {

      /**
       * If localRecordId is available then it will be concluded as the record is for update.
       * Else it will be considered as a new record.
       */
      if (!value.localRecordId) {

        console.log("IN IF CONDITION OF ADDING RECORD");

        value.localRecordId = this.tableData.length + 1;
        value.isNewlyAdded = true;
        value.isUpdated = false;

        this.toolSizeListOptions.forEach((obj) => {

          if (obj.ToolSizeId == value.TempConnectionToolSizeId) {

            value.ConnectionToolSizeId = obj.NominalOD;
            this.tableData.push(value);
            this.tableData = [...this.tableData];
            console.log("NEWLY_ADDED_RECORD AT INIT: " + JSON.stringify(value));
          } //end of if...else condition checking for ToolSizeId
        }); //end of forEach loop iterating on 'this.toolSizeListOptions'
      } else {

        console.log("IN IF CONDITION OF UPDATE RECORD");

        if (!value.isNewlyAdded)
          value.isUpdated = true;

        this.toolSizeListOptions.forEach((obj) => {

          if (obj.ToolSizeId == value.TempConnectionToolSizeId) {

            value.ConnectionToolSizeId = obj.NominalOD;
            this.tableData[value.localRecordId - 1] = value;
            this.tableData = [...this.tableData];
          } //end of if...else condition checking for ToolSizeId
        }); //end of forEach loop iterating on 'this.toolSizeListOptions'
      } //end of if...else condition
    }); //end of subscription
  } //end of 'ngOnInit'

  

  /**
   * emitter event call to check updated data in table
   */
  getTableData(event) {

    let isChanged = this.checkChanges(event.data);
    return isChanged;

  }//end of function

  /**
   * this function compares original data and changes made in
   * table
   */
  checkChanges(data) {

    const isDataChanged = JSON.stringify(data) !== JSON.stringify(this.originalData);
    //console.log("isDataChanged", isDataChanged, data);
    this.currentData = data;
    setTimeout(() => {
      this.isChanged = isDataChanged;
    });
    return isDataChanged;

  }//end of function


  /**
   * Below function for get data
   */
  getCustomConnectionsList() {

    //console.log("getCustomConnectionsList")
    this.ngxLoader.start();

    this.customConnections.getCustomConnectionsList().subscribe({
      next: (response) => {

        this.ngxLoader.stop();

        if (response) {

          //console.log("GET RESULT: ", response)
          this.tableData = response.result;
          //To map the data and To display the data in the format of MaterialName + Grade
          let tableData1 = response.result.map(item=>{
           
            return {...item, Grade:item.Symbol+"-"+item.Grade,ConnectionToolSizeId:item.NominalOD, NominalOD: item.NominalOD.toFixed(3)}
          });
          this.tableData = [...tableData1];
          this.tableData.forEach((record, index) => {

            this.tableData[index].localRecordId = index + 1;
            this.tableData[index].isUpdated = false;
            this.tableData[index].isNewlyAdded = false;
            this.tableData[index].isDeleted = false;
            // this.tableData[index].Grade=this.tableData[index].Grade+"-"+this.tableData[index].MaterialName;
            // this.tableData[index].Grade= this.tableData[index].MaterialName.slice(0,2).toUpperCase() +"-"+this.tableData[index].Grade;

            //console.log("GRADE VALUEEE........",this.tableData[index].Grade)

          }); //end of forEach
          this.originalData = JSON.parse(JSON.stringify(this.tableData));
          this.deleteList = [];
        } else {

          //console.log('error')
        }
        },
        error: (error) => {
          //console.log("CustomConnections", error.error.result);
  
          this.ngxLoader.stop();
        }  
    })
  }//end of getCustomConnectionsList


  /**
   * Below function for add dialogBox
   */
  addCustomConnections(){

    //console.log("Add custom ")

    sessionStorage.setItem("CUSTOM_CONNECTION_MODE", "ADD");

    const dialogRef = this.dialog.open(CustomConnectionsDetailsComponent, {
      width: 'auto',
      data: {},
      hasBackdrop:true,
      disableClose: false,
      autoFocus: false,
      panelClass:"dialogue-box",
      position: {
        top: '175px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      
      console.log("NEWLY_ADDED_RECORDS: " + JSON.stringify(result));
    });
  }//end of the addCustomConnections


  /**
   * Below function for showing updated dialogBox
   */
  updateCustomConnections(){

    console.log("this.updateData: " + JSON.stringify(this.updateData));

    sessionStorage.setItem("CUSTOM_CONNECTION_MODE", "UPDATE");

    const dialogRef = this.dialog.open(CustomConnectionsDetailsComponent, {
      width: 'auto',
      data: this.updateData, 
      disableClose: false,
      autoFocus: false,
      // panelClass:"dialogue-box",
      position: {
        top: '10px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      //console.log("UPDATE DIALOG BOX CLOSED: " + JSON.stringify(result));
      // this.getCustomConnectionsList();
    });
  }//end of the updateCustomConnections


  findNewlyAddedData () {

    let newData: customConnections [] = [];

    this.tableData.forEach((record) => {

      if (record.isNewlyAdded == true) {

        record.IsSystem = (record.IsSystem ? 1 : 0);
        // record.MaterialId = 19;
        newData.push(record);
      } //end of if condition checking it the record is newly added or not
    }); //end of forEach loop iterating on customConnectionsData

    return newData;
  } //end of 'saveNewlyAddedData' function


  saveNewRecords () {

    let newData = this.findNewlyAddedData();

    //console.log("\n\nNEWLY ADDED RECORDS: " + JSON.stringify(newData));

    if (newData.length == 0) {

      return;
    }

    let addRecords = [];

    newData.forEach((record) => {

      console.log("NEW RECORD: " + JSON.stringify(record));

      //below code will find the toolSizeId according to the name
      // record.ConnectionToolSizeId = record.TempConnectionToolSizeId ? record.TempConnectionToolSizeId : 1;

      let newObject = {
        "ConnectionName": record.ConnectionName,
        "ConnectionToolSizeId":record.TempConnectionToolSizeId ? record.TempConnectionToolSizeId : record.ConnectionToolSizeId,
        "TempConnectionToolSizeId": record.TempConnectionToolSizeId,
        "NominalWeight":record.NominalWeight,
        "ConnectionNW":record.ConnectionNW,
        "ConnectionType":record.ConnectionType,
        "Manufacturer":record.Manufacturer,
        "OuterDiameter":record.OuterDiameter,
        "InnerDiameter":record.InnerDiameter,
        "Length":record.Length,
        "IsSystem":record.IsSystem,
        "BurstPressure":record.BurstPressure,
        "CollapsePressure":record.CollapsePressure,
        "YieldTensileStrength":record.YieldTensileStrength,
        "Compression":record.Compression,
        "MakeupTorque":record.MakeupTorque,
        "MaterialId":record.MaterialId.length > 0 ? record.MaterialId[0] : record.MaterialId
      };

      console.log("this.fileteredtoolSizeMenus length: " + this.toolSizeListOptions.length);
      console.log("this.data.ConnectionToolSizeId: " + record.ConnectionToolSizeId);

      addRecords.push(newObject);

      record.isNewlyAdded = false;
    }); //end of forEach loop
    //console.log("add records...." , addRecords)
    //console.log("newData: " + JSON.stringify(newData));

    let saveRecords = {
      "customConnection" : addRecords,
    }

     this.customConnections.postCustomConnectionList(saveRecords).subscribe({

      next: (data) => {

        this.getCustomConnectionsList();
      }, error: (error) => {

        this.toastr.error("Something went wrong. Please try again later.");
      }
    }); //end of service call
  } //end of 'saveNewRecords' function


  /**
   * Below function will update record.
   */
  findUpdatedData () {

    let newUpdatedData: customConnections [] = [];

    this.tableData.forEach((record) => {

      if (record.isUpdated)
        newUpdatedData.push(record);
    }); 

    return newUpdatedData;
  } //end of 'findUpdatedData' 


  updateRecords()
  {
    let newUpdatedData = this.findUpdatedData();

    //console.log("newUpdatedData: " + JSON.stringify(newUpdatedData));

    let updateRecords: customConnections[] = [];

    //If nothing is available for update then it should not go ahead
    if (newUpdatedData.length == 0) {

      return;
    } //end of if condition checking for the data availability for update

    newUpdatedData.forEach((record) => {

      delete record.isDeleted;
      delete record.isNewlyAdded;
      delete record.isUpdated;
      record.MaterialId = record.MaterialId.length > 0 ? record.MaterialId[0] : record.MaterialId;
      delete record.localRecordId;
      record.ConnectionToolSizeId = record.TempConnectionToolSizeId;
      delete record.TempConnectionToolSizeId;
      delete record.Name;

      updateRecords.push(record);  
    }); //end of forEach loop

    //console.log("Updated records...." , updateRecords);
    //console.log("updateData: " + JSON.stringify(newUpdatedData));

    let saveRecords = {
      "connectionRows" : updateRecords
    } //end of 'saveRecords'

    this.customConnections.putCustomConnectionList(saveRecords).subscribe({

      next: (data) => {

        //console.log("Custom Connections",data);
        // this.toastr.success("Custom Connections Updated Successfully");
        this.getCustomConnectionsList();
      },
      error: (error) => {
        //console.log("Custom Connections",error);
        // this.toastr.error("Something went wrong during update.");
      }
    }); //end of service call
  }

  /**
   * Below function will save details in the database.
   * It will go with below sequence:
   * 1. Add
   * 2. Update
   * 3. Delete
   */
  save() {

    //console.log("\n\nTOTAL DATA AT SAVE: " + JSON.stringify(this.tableData));
    this.saveNewRecords();
    this.updateRecords();

    if (this.deletedIds.length > 0)
      this.deleteRecords();

    this.toastr.success("Custom Connections Saved Successfully");
  } //end of 'save' function


  /**
   * Below function will add the ID in the delete array.
   */
  deleteRecord(event) {

    //console.log("event " , event.ConnectionId)
    if (!event.isNewlyAdded)
      this.deletedIds.push(event.ConnectionId)    

    let updatedArray = [];

    this.tableData.forEach((record, index) => {

      if (record.localRecordId != event.localRecordId) {

        updatedArray.push(record);
      } //end of if condition
    }); //end of forEach loop

    this.tableData = [...updatedArray];
  } //end of deleteRecord

  
   /**
    * Below function is for  delete API
    */
  deleteRecords() {

    //console.log("DELETE RECORD FUNCTION: " + JSON.stringify(this.deletedIds)); 
    if (this.deletedIds.length > 0) {

      let data={"customConnection":this.deletedIds}
      this.customConnections.deleteCustomConnectionsList(data).subscribe({

        next: (data) => {

          //console.log("Custom connection",data);
          this.toastr.success("Custom Connections Deleted Successfully");
          this.deletedIds = [];
          this.getCustomConnectionsList();
        }, error: (error) => {
        
          //console.log("custom connection",error);
          // this.toastr.error("Something went wrong");
        }
      }); //end of service call
    }
  } //end of 'deleteRecords' function


  /**
   * Below function is for refresh the custom connections
   */
  reset() {

      this.getCustomConnectionsList();
  } //end of reset function


  /**
  * Below function is for data filled automatically when we will click on the edit button 
  */
  openUpdateDialog(event)
  {
    this.updateData = event ;
    // console.log("Event received: " + JSON.stringify(event));
    this.updateCustomConnections();
  } //end of the openUpdateDialog

  /**
   * Below function clone the data
   */
  cloneData (event) {

      console.log("Clone Event Received: " + JSON.stringify(event));

      let name = event.ConnectionName;
      console.log("NAME: " + name);
      console.log("Name value: " + name.split("Copy")[1]);
      name = name.indexOf("Copy") > -1 
          ? name.split("Copy")[0] + "Copy" + (parseInt(name.split("Copy")[1].replace(")", "")) + 1) + ")"
          : name + " (Copy1)";

      let isFound = false;

      this.tableData.forEach((obj, index) => {

        if (obj.ConnectionName == name) {

          this.toastr.info("It seems like there is already one record with \'" + name + "\' name.");
          isFound = true;
        } else {

          if (index == this.tableData.length - 1 && !isFound) {

            let newRecord: customConnections = {
              localRecordId: this.tableData.length + 1,
              ConnectionName: name,
              ConnectionToolSizeId: event.ConnectionToolSizeId,
              TempConnectionToolSizeId: event.ToolSizeId,
              Name: event.Name,
              NominalWeight: event.NominalWeight,
              ConnectionNW: event.ConnectionNW,
              Grade: event.Grade,
              ConnectionType: event.ConnectionType,
              Manufacturer: event.Manufacturer,
              OuterDiameter: event.OuterDiameter,
              InnerDiameter: event.InnerDiameter,
              Length: event.Length,
              IsSystem: event.IsSystem,
              BurstPressure: event.BurstPressure,
              CollapsePressure: event.CollapsePressure,
              YieldTensileStrength: event.YieldTensileStrength,
              Compression: event.Compression,
              MakeupTorque: event.MakeupTorque,
              MaterialId: event.MaterialId,
              ToolSizeId: event.ToolSizeId,
              // MaterialName:event.MaterialName,
              isNewlyAdded: true,
              isDeleted: event.isDeleted,
              ConnectionId: event.ConnectionId,
              isUpdated: event.isUpdated,
              isLimitChecked: event.isCheckboxChecked
            } //end of 'newRecord'
      
            this.tableData.push(newRecord);
            this.tableData = [...this.tableData];
            this.clonePermitted = true;
            //console.log("Newly added record: " + JSON.stringify(this.tableData[this.tableData.length - 1]));
            //console.log("TOTAL DATA: " + JSON.stringify(this.tableData));
          }
        }
      })
  } //end of 'cloneData'

  async getMaterialsDropdown(){

    let data;

    try{

       data = await lastValueFrom(this.materialsService.getMaterialsList());

    }

    catch(e){

       this.toastr.error("Something went wrong while fetching materials");

    }

    return data;

}//end of functions


async getToolSizeDropdown() {

  let data;

  try {

    data = await lastValueFrom(this.materialsService.getToolSizeListForCustomConnection());
  } catch (e) {

    this.toastr.error("Something went wrong while fetching materials");
  } //end of 'try...catch' block

  return data;
}//end of function


getActiveUnitSystemData() {

  // this.unitSystemData = {};
  this.unitsService.getActiveUnitSystemDetails().subscribe({
    next: (res) => {
      if (res) {
        console.log("res in casing---", res);
        let activeUnitSystemData = res;
        this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
        this.linearMassDensityLabel=activeUnitSystemData.linearMassDensity.unitValue;
        this.lengthLabel = activeUnitSystemData.length.unitValue;
        this.pressureLabel=activeUnitSystemData.pressure.unitValue;
        this.torqueLabel = activeUnitSystemData.torque.unitValue;
        this.forceLabel = activeUnitSystemData.force.unitValue;
        
        this.tableColumns[0].header="Tool Size, "+this.shortLengthLabel+"";
        this.tableColumns[1].header="NW, "+this.linearMassDensityLabel+"";
        this.tableColumns[8].header="Length, "+this.lengthLabel+"";
        this.tableColumns[10].header="Burst Pressure, "+this.pressureLabel+"";
        this.tableColumns[11].header="Collapse Pressure, "+this.pressureLabel+"";
        this.tableColumns[14].header="Make up Torque, "+this.torqueLabel+"";
        this.tableColumns[6].header="OD, "+this.shortLengthLabel+"";
        this.tableColumns[7].header="ID, "+this.shortLengthLabel+"";
        this.tableColumns[12].header="Tension, "+this.forceLabel+"";
        this.tableColumns[13].header="Compression, "+this.forceLabel+"";
        this.tableColumns[9].header="Connection NW, "+this.linearMassDensityLabel+"";



        

        // //console.log("densityDialReadingLabel----",this.densityDialReadingLabel);
       
      } else {
        //console.log('error');
      }
    },
    error: (error) => {
      //console.log("Unit", error.error.result);
    }
  })
}
}