import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomConnectionsDetailsComponent } from './custom-connections-details.component';

describe('CustomConnectionsDetailsComponent', () => {
  let component: CustomConnectionsDetailsComponent;
  let fixture: ComponentFixture<CustomConnectionsDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomConnectionsDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomConnectionsDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
