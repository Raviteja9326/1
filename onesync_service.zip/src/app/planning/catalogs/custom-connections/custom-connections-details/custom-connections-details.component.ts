import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import { MaterialsService } from "src/app/core/services/materials.service";
import { ToastrService } from "ngx-toastr";
import { customConnections } from "src/app/core/interfaces/customConnections.interface";
import { CustomConnectionsService } from "src/app/core/services/customConnections.service";
import { ReplaySubject, lastValueFrom } from "rxjs";
import { min } from "lodash";
import { UnitsService } from "src/app/core/services/units.service";
import { isAbsolute } from "path";
import { event } from "jquery";
import { ToolSize } from "src/app/core/interfaces/toolSize.interface";
import { NgxUiLoaderService } from "ngx-ui-loader";
import Swal from "sweetalert2";

@Component({
  selector: "app-custom-connections-details",
  templateUrl: "./custom-connections-details.component.html",
  styleUrls: ["./custom-connections-details.component.scss"],
})
export class CustomConnectionsDetailsComponent implements OnInit {
  materialListOptions: any = [];
  materialListOptionsforcalculations: any = [];
  toolSizeListOptions: any = [];
  updatedRecords: customConnections[] = [];
  percentage: string = "";
  selectedCriteria: any;
  selectedStandard: any;
  selectedMaterial: any;
  popupName: string = "";
  readonly: boolean = true;
  readonlyInput: boolean = true;
  sectionArrayList: any[] = [];
  isFirstLoad: boolean = true;
  action: boolean = false;
  userInput: number = 0;
  sectionArrayErrorList: {
    OD: string;
    ID: string;
    Length: string;
    Material: string;
    Caption: string;
    NW: any;
  }[] = [];
  filterControlToolSize: FormControl = new FormControl();
  filterControl: FormControl = new FormControl();
  filteredMaterialList: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  fileteredtoolSizeMenus: ReplaySubject<ToolSize[]> = new ReplaySubject<
    ToolSize[]
  >(1);
  fileteredisStandardAPIMenus: ReplaySubject<any[]> = new ReplaySubject<any[]>(
    1
  );
  fileteredmanufacturerOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(
    1
  );
  inputValue: number | undefined;
  IsDefaultCal: boolean;
  IsAbsoluteCal: boolean;
  IsAbsolute: boolean;
  IsEditing: boolean;
  shortLengthLabel: string = ""; //(in or mm)
  linearMassDensityLabel: string = ""; // (lb/ft or kg/m)
  lengthLabel: string = ""; //(ft or m)
  pressureLabel: string = ""; //(kPa or psi)
  torqueLabel: string = ""; // (lbf-ft or N-m)
  forceLabel: string = ""; // (lbf-ft or N-m)

  shortLengthPrecision: any;
  linearMassDensityPrecision: any;
  lengthPrecision: any;
  pressurePrecision: any;
  torquePrecision: any;
  forcePrecision: any;

  BurstEfficiency: any;
  CollapseEfficiency: any;
  CompressionEfficiency: any;
  TensileEfficiency: any;
  operationMode: string = 'ADD';

  actualBurstEfficiency: any;
  actualCollapseEfficiency: any;
  actualCompressionEfficiency: any;
  actualTensileEfficiency: any;

  calculatedBurstEfficiency: any;
  calculatedCollapseEfficiency: any;
  calculatedCompressionEfficiency: any;
  calculatedTensileEfficiency: any;

  Length: boolean = false;
  manufactuterBol: boolean = false;
  manufactuterOtherBol: boolean = false;
  ManufacturerName: string = "";
  ConnectionNameBol: boolean = false;
  manufacturerListOptions: any = [];

  isStandardAPIMenus = [
    {
      label: "API",
      value: true,
    },
    {
      label: "Non API",
      value: false,
    },
  ];

  toolSizeMenus = [
    {
      label: "4.52",
      value: 1,
    },
    {
      label: "1.22",
      value: 2,
    },
    {
      label: "3.78",
      value: 3,
    },
    {
      label: "5.77",
      Value: 4,
    },
  ];

  isCheckboxChecked: boolean;
  customConnectionForm: FormGroup;
  activatedUnit: any;
  initialFormValue: any;

  @Input()
  tableData1: any = [];
  @Output()
  change: EventEmitter<number> = new EventEmitter<number>();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any = {},
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<CustomConnectionsDetailsComponent>,
    private materialsService: MaterialsService,
    private toastr: ToastrService,
    private customConnectionsService: CustomConnectionsService,
    private unitsService: UnitsService,
    private ngxLoader: NgxUiLoaderService
  ) {
    console.log("DATA_IN_CONSTRUCTOR: " + JSON.stringify(this.data));
    this.data.Name = "" + this.data.Name;

    this.operationMode = sessionStorage.getItem("CUSTOM_CONNECTION_MODE");

    this.popupName =
      this.data && this.data.BurstPressure
        ? "Update Custom Connection Details"
        : "Add Custom Connection Details";
    this.readonly = this.data && this.data.BurstPressure ? true : false;
  }

  ngOnInit(): void {
    this.standardChange(event);
    this.manufacturerList();
    this.setCustomConnection();

    this.ngxLoader.start();

    let self = this;
    setTimeout(function () {
      self.isFirstLoad = false;
    }, 2000);

    this.fileteredtoolSizeMenus.next(this.toolSizeListOptions);
    this.filterControlToolSize.valueChanges.subscribe({
      next: () => {
        let searchValue = this.filterControlToolSize.value.toString();
        console.log("this.filterControlToolSize.value: " + searchValue);

        let filteredList = this.toolSizeListOptions.filter(
          (obj) => obj.NominalOD.toString().indexOf(searchValue) > -1
        );
        this.ngxLoader.stop();
        this.fileteredtoolSizeMenus.next(filteredList);
      },
    });

    this.fileteredisStandardAPIMenus.next(this.isStandardAPIMenus);
    this.filterControl.valueChanges.subscribe({
      next: () => {
        let filter = this.filterControl.value.toLowerCase();
        let filteredList = this.isStandardAPIMenus.filter(
          (option) => option.label.toLowerCase().indexOf(filter) >= 0
        );
        this.fileteredisStandardAPIMenus.next(filteredList);
      },
    });

    this.ngxLoader.stop();

    //For calculating values at init
    //This will be used for showing percentage at init
    this.calculateResultForInit();

    console.log("DATA AFTER RENDER: " + JSON.stringify(this.data));

    this.customConnectionForm = this.fb.group({
      ConnectionToolSizeId: ["4 3/4", [Validators.required]], //4 3/4
      NominalWeight: [0, [Validators.required, Validators.min(0.0001)]], //4.750
      ConnectionNW: [0, [Validators.required]],
      Grade: ["12", [Validators.required]],
      ConnectionName: ["", [Validators.required]],
      IsSystem: [false, [Validators.required]],
      Manufacturer: ["", [Validators.required]],
      ManufacturerName: ["", [Validators.required]],
      OuterDiameter: [0, [Validators.required, Validators.min(0.1)]],
      InnerDiameter: [0, [Validators.required, Validators.min(0.1)]],
      Length: [0, [Validators.required]],
      BurstPressure: [0, [Validators.required]],
      CollapsePressure: [0],
      YieldTensileStrength: [0],
      Compression: [0],
      MakeupTorque: [0],
      checkbox: [false],
    });

    this.customConnectionForm
      .get("OuterDiameter")
      .valueChanges.subscribe((value) => {
        if (!this.isFirstLoad)
          this.calculateResult(this.IsAbsoluteCal, this.IsDefaultCal);
      });

    this.customConnectionForm
      .get("InnerDiameter")
      .valueChanges.subscribe((value) => {
        if (!this.isFirstLoad)
          this.calculateResult(this.IsAbsoluteCal, this.IsDefaultCal);
      });

    this.customConnectionForm
      .get("checkbox")
      .valueChanges.subscribe((value) => {
        // Adjust the max value dynamically based on inputA value
        this.setValidationsUsingCheckbox(value);
      });

    this.getActiveUnitSystemData();

    this.initialFormValue = this.customConnectionForm?.value;
  } //end of 'ngOnInit' function

  onFormValueChange() {
    return Object.entries(this.initialFormValue).some(
      ([field, value]) => value !== this.customConnectionForm.value[field]
    );
  }

  /**
   * Below function will be executed at the begenning.
   */
  async calculateResultForInit() {
    if (this.data.OuterDiameter && this.data.InnerDiameter) {
      let TotalBurst = 0;
      let TotalCollapse = 0;
      let TotalTension = 0;
      let TotalCompression = 0;

      let pipeOD = this.data.OuterDiameter;
      let pipeID = this.data.InnerDiameter;

      if (this.shortLengthLabel == "mm") {
        pipeOD = pipeOD / 25.4;
        pipeID = pipeID / 25.4;
      }

      let updatedBurstPressure;
      let updatedCollapsePressure;
      let updatedYieldTensileStrength;
      let updatedCompression;

      let wellThickness = (pipeOD - pipeID) / 2.0;

      let selectedMaterialId = parseInt(
        this.customConnectionForm.get("Grade").value
      );
      let yeildStrength = this.materialListOptionsforcalculations.find(
        (o) => o.MaterialId === selectedMaterialId
      )?.YieldStress;
      TotalTension =
        (yeildStrength *
          (Math.PI * Math.pow(pipeOD / 2, 2) -
            Math.PI * Math.pow(pipeID / 2, 2)) *
          (100 / 100)) /
        1000;
      TotalBurst =
        0.875 *
        ((2 * yeildStrength * wellThickness) / parseFloat(pipeOD)) *
        (100 / 100);
      TotalCollapse = 0; //CalculateCollapsePresure(YeildStrength, PipeOD, WallThickness, collapsePressure);
      TotalCompression = TotalTension * 0.6;

      TotalTension = TotalTension * 0.999999827;
      TotalCompression = TotalCompression * 0.999999827;

      console.log(
        "this.customConnectionForm.get('checkbox').value",
        this.customConnectionForm.get("checkbox").value
      );

      if (this.shortLengthLabel == "mm") {
        this.calculatedBurstEfficiency = TotalBurst;
        this.calculatedTensileEfficiency = TotalTension / 1000;
        updatedCompression = TotalCompression / 1000;
        this.calculatedTensileEfficiency =
          updatedYieldTensileStrength * 92903.03996633828 * 6.944444362364988;
        this.calculatedCompressionEfficiency =
          updatedCompression * 92903.03996633828 * 6.944444362363988;
      } else {
        this.calculatedBurstEfficiency = TotalBurst;
        this.calculatedCollapseEfficiency = TotalCollapse;
        this.calculatedTensileEfficiency = TotalTension * 1000;
        this.calculatedCompressionEfficiency = TotalCompression * 1000;
      }
    }
  } //end of 'calculateResultForInit' function

  /**
   * Below function will set validations on the basis of checkbox value change.
   */
  setValidationsUsingCheckbox(value) {
    if (value) {
      this.customConnectionForm
        .get("BurstPressure")
        .setValidators([
          Validators.required,
          Validators.min(0),
          Validators.max(100),
        ]);
      this.customConnectionForm.get("BurstPressure").updateValueAndValidity();
      this.customConnectionForm
        .get("CollapsePressure")
        .setValidators([
          Validators.required,
          Validators.min(0),
          Validators.max(100),
        ]);
      this.customConnectionForm
        .get("CollapsePressure")
        .updateValueAndValidity();
      this.customConnectionForm
        .get("YieldTensileStrength")
        .setValidators([
          Validators.required,
          Validators.min(0),
          Validators.max(100),
        ]);
      this.customConnectionForm
        .get("YieldTensileStrength")
        .updateValueAndValidity();
      this.customConnectionForm
        .get("Compression")
        .setValidators([
          Validators.required,
          Validators.min(0),
          Validators.max(100),
        ]);
      this.customConnectionForm.get("Compression").updateValueAndValidity();
      // this.customConnectionForm.get('MakeupTorque').setValidators([Validators.required, Validators.min(0), Validators.max(100)]);
      // this.customConnectionForm.get('MakeupTorque').updateValueAndValidity();
    } else {
      this.customConnectionForm.get("BurstPressure").setValidators([]);
      this.customConnectionForm.get("BurstPressure").updateValueAndValidity();
      this.customConnectionForm.get("CollapsePressure").setValidators([]);
      this.customConnectionForm
        .get("CollapsePressure")
        .updateValueAndValidity();
      this.customConnectionForm.get("YieldTensileStrength").setValidators([]);
      this.customConnectionForm
        .get("YieldTensileStrength")
        .updateValueAndValidity();
      this.customConnectionForm.get("Compression").setValidators([]);
      this.customConnectionForm.get("Compression").updateValueAndValidity();
      this.customConnectionForm.get("MakeupTorque").setValidators([]);
      this.customConnectionForm.get("MakeupTorque").updateValueAndValidity();
    } //end of if...else condition checking for the value
  } //end of 'setValidationsUsingCheckbox' function

  maxValueValidator(control: AbstractControl) {
    const value = control.value;

    if (value > 100 && this.isCheckboxChecked) {
      return { maxValue: true };
    } else {
      return null;
    } //end of if...else condition
  } //end of 'maxValueValidator' function

  maxNameValueValidator(control: AbstractControl) {
    const value = control.value;

    if (value > 100 && this.isCheckboxChecked) {
      return { maxValue: true };
    } else {
      return null;
    } //end of if...else condition
  } //end of 'maxNameValueValidator' function

  percentageValueValidator() {
    if (this.isCheckboxChecked) {
      //console.log("Burstpressure value", this.data.BurstPressure)
    }
  }

  /**
   * Below function will change the actual value of burst pressure in case of the change in percentage.
   */
  onBurstPressureValueChanged() {
    if (this.isCheckboxChecked) {
      this.calculatedBurstEfficiency =
        (this.actualBurstEfficiency / 100) *
        this.customConnectionForm.value.BurstPressure;
    } else {
      this.actualBurstEfficiency =
        this.customConnectionForm.value.BurstPressure;
      this.calculatedBurstEfficiency =
        this.customConnectionForm.value.BurstPressure;
    } //end of if condition checking if the checkbox is checked
  } //end of 'onBurstPressureValueChanged' function

  /**
   * Below function will change the actual value of burst pressure in case of the change in percentage.
   */
  onCollapsePressureValueChanged() {
    if (this.isCheckboxChecked) {
      this.calculatedCollapseEfficiency =
        (this.actualCollapseEfficiency / 100) *
        this.customConnectionForm.value.CollapsePressure;
    } else {
      this.actualCollapseEfficiency =
        this.customConnectionForm.value.CollapsePressure;
      this.calculatedCollapseEfficiency =
        this.customConnectionForm.value.CollapsePressure;
    } //end of if condition checking if the checkbox is checked
  } //end of 'onCollapsePressureValueChanged' function

  /**
   * Below function will change the actual value of burst pressure in case of the change in percentage.
   */
  onTensileValueChanged() {
    if (this.isCheckboxChecked) {
      this.calculatedTensileEfficiency =
        (this.actualTensileEfficiency / 100) *
        this.customConnectionForm.value.YieldTensileStrength;
    } else {
      this.actualTensileEfficiency =
        this.customConnectionForm.value.YieldTensileStrength;
      this.calculatedTensileEfficiency =
        this.customConnectionForm.value.YieldTensileStrength;
    } //end of if condition checking if the checkbox is checked
  } //end of 'onCollapsePressureValueChanged' function

  /**
   * Below function will change the actual value of burst pressure in case of the change in percentage.
   */
  onCompressionValueChanged() {
    if (this.isCheckboxChecked) {
      this.calculatedCompressionEfficiency =
        (this.actualCompressionEfficiency / 100) *
        this.customConnectionForm.value.Compression;
    } else {
      this.actualCompressionEfficiency =
        this.customConnectionForm.value.Compression;
      this.calculatedCompressionEfficiency =
        this.customConnectionForm.value.Compression;
    } //end of if condition checking if the checkbox is checked
  } //end of 'onCollapsePressureValueChanged' function

  /**
   * Below function will set the percentage values.
   * It will check if the actual value is the same as calculated one.
   * If yes then it will set it as 100.
   * Else it will set it as per the percentage.
   * If the percentage is changed manually by user then it will call above 4 functions and calculate values.
   */
  togglePercentage(isCheckboxChecked) {
    console.log("TOGGLE_PERCENTAGE_FUNCTION_CALLED");

    console.log(
      "this.calculatedBurstEfficiency: " + this.calculatedBurstEfficiency
    );
    console.log(
      "this.calculatedCollapseEfficiency: " + this.calculatedCollapseEfficiency
    );
    console.log(
      "this.calculatedCompressionEfficiency: " +
        this.calculatedCompressionEfficiency
    );
    console.log(
      "this.calculatedTensileEfficiency: " + this.calculatedTensileEfficiency
    );
    console.log("this.actualBurstEfficiency: " + this.actualBurstEfficiency);
    console.log(
      "this.actualCollapseEfficiency: " + this.actualCollapseEfficiency
    );
    console.log(
      "this.actualCompressionEfficiency: " + this.actualCompressionEfficiency
    );
    console.log(
      "this.actualTensileEfficiency: " + this.actualTensileEfficiency
    );

    this.isCheckboxChecked = !isCheckboxChecked;

    if (this.isCheckboxChecked) {

      this.data.BurstPressure =
        this.calculatedBurstEfficiency == this.actualBurstEfficiency
          ? 100
          : (this.calculatedBurstEfficiency / this.actualBurstEfficiency) * 100;
      this.data.CollapsePressure =
        this.calculatedCollapseEfficiency == this.actualCollapseEfficiency
          ? this.calculatedCollapseEfficiency > 0
            ? 100
            : 0
          : (this.calculatedCollapseEfficiency /
              this.actualCollapseEfficiency) *
            100;
      this.data.Compression =
        this.calculatedCompressionEfficiency == this.actualCompressionEfficiency
          ? 100
          : (this.calculatedCompressionEfficiency /
              this.actualCompressionEfficiency) *
            100;
      this.data.YieldTensileStrength =
        this.calculatedTensileEfficiency == this.actualTensileEfficiency
          ? 100
          : (this.calculatedTensileEfficiency / this.actualTensileEfficiency) *
            100;

      let pipeOD = this.customConnectionForm.get("OuterDiameter").value;
      let pipeID = this.customConnectionForm.get("InnerDiameter").value;

      if (pipeOD && pipeID) {
        this.customConnectionForm
          .get("BurstPressure")
          .patchValue(this.data.BurstPressure);
        this.customConnectionForm
          .get("CollapsePressure")
          .patchValue(this.data.CollapsePressure);
        this.customConnectionForm
          .get("YieldTensileStrength")
          .patchValue(this.data.YieldTensileStrength);
        this.customConnectionForm
          .get("Compression")
          .patchValue(this.data.Compression);
      } else {
        this.customConnectionForm.get("BurstPressure").patchValue("");
        this.customConnectionForm.get("CollapsePressure").patchValue("");
        this.customConnectionForm.get("YieldTensileStrength").patchValue("");
        this.customConnectionForm.get("Compression").patchValue("");
      }

      this.percentage = "%";
      this.IsAbsolute = true;
    } else {
      console.log("INSIDE_ELSE_CONDITION");
      this.calculatedBurstEfficiency =
        this.calculatedBurstEfficiency == this.actualBurstEfficiency
          ? this.actualBurstEfficiency
          : this.calculatedBurstEfficiency;
      this.calculatedCollapseEfficiency =
        this.calculatedCollapseEfficiency == this.actualCollapseEfficiency
          ? this.actualCollapseEfficiency
          : this.calculatedCollapseEfficiency;
      this.calculatedCompressionEfficiency =
        this.calculatedCompressionEfficiency == this.actualCompressionEfficiency
          ? this.actualCompressionEfficiency
          : this.calculatedCompressionEfficiency;
      this.calculatedTensileEfficiency =
        this.calculatedTensileEfficiency == this.actualTensileEfficiency
          ? this.actualTensileEfficiency
          : this.calculatedTensileEfficiency;

      this.data.BurstPressure = this.calculatedBurstEfficiency;
      this.data.CollapsePressure = this.calculatedCollapseEfficiency;
      this.data.YieldTensileStrength = this.calculatedTensileEfficiency;
      this.data.Compression = this.calculatedCompressionEfficiency;

      let pipeOD = this.customConnectionForm.get("OuterDiameter").value;
      let pipeID = this.customConnectionForm.get("InnerDiameter").value;

      if (pipeOD && pipeID) {
        this.customConnectionForm
          .get("BurstPressure")
          .patchValue(this.data.BurstPressure);
        this.customConnectionForm
          .get("CollapsePressure")
          .patchValue(this.data.CollapsePressure);
        this.customConnectionForm
          .get("YieldTensileStrength")
          .patchValue(this.data.YieldTensileStrength);
        this.customConnectionForm
          .get("Compression")
          .patchValue(this.data.Compression);
      } else {
        this.customConnectionForm.get("BurstPressure").patchValue(0);
        this.customConnectionForm.get("CollapsePressure").patchValue(0);
        this.customConnectionForm.get("YieldTensileStrength").patchValue(0);
        this.customConnectionForm.get("Compression").patchValue(0);
      }

      this.percentage = "";
      this.IsAbsolute = false;
    } //end of if...else condition checking if the checkbox is checked or not
  } //end of 'togglePercentage' function

  /**
   *  Below function will close the dialog box.
   */
  close() {
    this.dialogRef.close();
  } //end of 'close' function

  standardChange(event) {
    console.log("event Standard change", event.value);
    if (event.value) {
      this.manufactuterBol = false;
      this.manufactuterOtherBol = false;
      this.customConnectionForm.get("Manufacturer").patchValue("");
      this.customConnectionForm.get("ManufacturerName").patchValue("");
    } else {
      this.manufactuterBol = true;
    }
  }

  ManufacturerChange(event) {
    console.log(event);
    if (event.value !== "Other") {
      this.ManufacturerName = event.source.value;
      this.manufactuterOtherBol = false;
    }
    if (event.value == "Other") {
      this.manufactuterOtherBol = true;
      this.customConnectionForm
        .get("ManufacturerName")
        .patchValue(this.ManufacturerName);
    }
  }

  maxLengthName() {
    let ConnectionName = this.customConnectionForm.get("ConnectionName").value;

    if (ConnectionName.length <= 99) {
      this.customConnectionForm.get("ConnectionName").setErrors(null);
    }

    if (ConnectionName.length == 0) {
      this.customConnectionForm
        .get("ConnectionName")
        .setErrors({ required: true });
    }

    if (ConnectionName.length > 99) {
      this.customConnectionForm
        .get("ConnectionName")
        .setErrors({ maxLength: true });
    }
  } //end of 'maxLengthName' function

  /**
   * Below function will set the form according to the values provided in the main form.
   */
  setCustomConnection() {
    this.selectedCriteria = this.data.Name;

    this.getToolSizeDropdown().then((data) => {
      console.log("getToolSizedropdownAPi", data);
      this.toolSizeListOptions = data.result;
      console.log("this.toolSizeListOptions", this.toolSizeListOptions);

      this.fileteredtoolSizeMenus.next(this.toolSizeListOptions);
      this.filterControl.valueChanges.subscribe({
        // next: () => {
        //   let filter = this.filterControl.value;
        //   let filteredList = this.toolSizeListOptions.filter(
        //     option => option.Name.toLowerCase().indexOf(filter) >= 0
        //   );
        //   this.fileteredtoolSizeMenus.next(filteredList);
        // }
      });
    });

    this.getMaterialsDropdown()
      .then((data) => {
        this.materialListOptions = data.result.map((item) => {
          this.materialListOptionsforcalculations.push(item);
          //Below code for to show the label in dropdown in the MaterialName-Grade format
          return {
            label: item.Symbol + "-" + item.Grade,
            value: item.MaterialId,
          }; //value:item.MaterialId
        });
        this.filteredMaterialList.next(this.materialListOptions);
        this.filterControl.valueChanges.subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.materialListOptions.filter(
              (option) => option.label.toLowerCase().indexOf(filter) >= 0
            );
            this.filteredMaterialList.next(filteredList);
          },
        });
        return new Promise((resolve) => {
          resolve("success");
        });
      })
      .then((data) => {
        let newMaterialId = this.data.MaterialId[0];
        const str = String(newMaterialId);
        let manufacturerName;

        if (this.data.Manufacturer !== "Other") {
          manufacturerName = this.data.Manufacturer;
        }

        if (this.data.Manufacturer == "Other") {
          this.customConnectionForm
            .get("ManufacturerName")
            .patchValue(this.data.Manufacturer);
        }

        if (!this.data.IsSystem) {
          this.manufactuterBol = true;
        } else {
          this.manufactuterBol = false;
        }

        this.customConnectionForm
          .get("NominalWeight")
          .patchValue(this.data.NominalWeight);
        this.customConnectionForm
          .get("ConnectionToolSizeId")
          .patchValue("" + this.data.Name);
        this.customConnectionForm.get("Grade").patchValue(str);
        this.customConnectionForm
          .get("ConnectionName")
          .patchValue(this.data.ConnectionName);
        this.customConnectionForm
          .get("IsSystem")
          .patchValue(this.data.IsSystem);
        this.customConnectionForm
          .get("Manufacturer")
          .patchValue(this.data.Manufacturer);
        this.customConnectionForm
          .get("ManufacturerName")
          .patchValue(manufacturerName);
        this.customConnectionForm
          .get("OuterDiameter")
          .patchValue(this.data.OuterDiameter);
        this.customConnectionForm
          .get("InnerDiameter")
          .patchValue(this.data.InnerDiameter);
        this.customConnectionForm.get("Length").patchValue(this.data.Length);
        console.log("this.data.BurstPressure: " + this.data.BurstPressure);

        this.customConnectionForm
          .get("BurstPressure")
          .patchValue(this.data.BurstPressure);
        this.customConnectionForm
          .get("CollapsePressure")
          .patchValue(this.data.CollapsePressure);
        this.customConnectionForm
          .get("YieldTensileStrength")
          .patchValue(this.data.YieldTensileStrength);
        this.customConnectionForm
          .get("Compression")
          .patchValue(this.data.Compression);
        this.customConnectionForm
          .get("MakeupTorque")
          .patchValue(this.data.MakeupTorque);
        this.customConnectionForm
          .get("ConnectionNW")
          .patchValue(this.data.ConnectionNW);
        // this.isCheckboxChecked = this.data.isLimitChecked;
        this.readonly = true;
        this.isFirstLoad = false;

        this.actualBurstEfficiency = this.actualBurstEfficiency
          ? this.actualBurstEfficiency
          : this.data.BurstPressure;
        this.actualCollapseEfficiency = this.actualCollapseEfficiency
          ? this.actualCollapseEfficiency
          : this.data.CollapsePressure;
        this.actualCompressionEfficiency = this.actualCompressionEfficiency
          ? this.actualCompressionEfficiency
          : this.data.Compression;
        this.actualTensileEfficiency = this.actualTensileEfficiency
          ? this.actualTensileEfficiency
          : this.data.YieldTensileStrength;

        this.calculatedBurstEfficiency = this.calculatedBurstEfficiency
          ? this.calculatedBurstEfficiency
          : this.data.BurstPressure;
        this.calculatedCollapseEfficiency = this.calculatedCollapseEfficiency
          ? this.calculatedCollapseEfficiency
          : this.data.CollapsePressure;
        this.calculatedCompressionEfficiency = this
          .calculatedCompressionEfficiency
          ? this.calculatedCompressionEfficiency
          : this.data.Compression;
        this.calculatedTensileEfficiency = this.calculatedTensileEfficiency
          ? this.calculatedTensileEfficiency
          : this.data.YieldTensileStrength;

        this.initialFormValue = this.customConnectionForm.value;
      });
  } //end of 'setCustomConnection' function

  getMaterials() {
    this.materialsService.getMaterialsList().subscribe({
      next: (res) => {
        if (res) {
          this.materialListOptions = res.result.map((item) => {
            return {
              label: item.MaterialName + "-" + item.Grade,
              value: item.MaterialId,
            };
          });
        }
      },
      error: (error) => {
        this.toastr.error("Something Went Wrong");
      }, //end of service call
    });
  }

  async getMaterialsDropdown() {
    let data;

    try {
      data = await lastValueFrom(this.materialsService.getMaterialsList());
    } catch (e) {
      this.toastr.error("Something went wrong while fetching materials");
    } //end of 'try...catch' block

    return data;
  } //end of functions

  async getToolSizeDropdown() {
    let data;

    try {
      data = await lastValueFrom(this.materialsService.getToolSizeList());
    } catch (e) {
      this.toastr.error("Something went wrong while fetching materials");
    } //end of 'try...catch' block

    return data;
  } //end of functions

  findNewlyAddedData() {
    let newData: customConnections[] = [];

    this.tableData1.forEach((record) => {
      if (record.isNewlyAdded == true) {
        newData.push(record);
      } //end of if condition checking it the record is newly added or not
    }); //end of forEach loop iterating on temperatureData

    return newData;
  } //end of 'saveNewlyAddedData' function

  onCancel() {
    console.log("this.actualBurstEfficiency: " + this.actualBurstEfficiency);
    console.log(
      "this.calculatedBurseEfficienty: " + this.calculatedBurstEfficiency
    );

    this.data.BurstPressure = this.actualBurstEfficiency;
    this.data.CollapsePressure = this.actualCollapseEfficiency;
    this.data.YieldTensileStrength = this.actualTensileEfficiency;
    this.data.Compression = this.actualCompressionEfficiency;

    if (this.onFormValueChange()) {
      Swal.fire({
        title: `Are you sure, you want to close without saving the changes?`,
        showCancelButton: false,
        allowOutsideClick: false,
        showDenyButton: true,
        confirmButtonText: `Yes`,
        denyButtonText: `No`,
      }).then((result) => {
        if (result.isConfirmed) {
          this.dialogRef.close();
        }
      });
    } else {
      this.dialogRef.close();
    }
  }

  saveData(): void {
    let APiValue = this.customConnectionForm.get("IsSystem").value;
    let manufacturerName = this.customConnectionForm.get("Manufacturer").value;
    let manufacturerNameOther =
      this.customConnectionForm.get("ManufacturerName").value;

    if (APiValue) {
      this.customConnectionForm.get("Manufacturer").setErrors(null);
      this.customConnectionForm.get("ManufacturerName").setErrors(null);
    }

    if (manufacturerName !== "Other") {
      if (
        manufacturerNameOther !== "" ||
        manufacturerNameOther !== null ||
        manufacturerNameOther !== undefined
      ) {
        this.customConnectionForm.get("ManufacturerName").setErrors(null);
      }
    } else if (manufacturerName == "Other") {
      this.customConnectionForm
        .get("Manufacturer")
        .patchValue(manufacturerNameOther);
    }

    if (this.customConnectionForm.invalid) {
      // Mark all form controls as touched to show errors
      Object.values(this.customConnectionForm.controls).forEach((control) =>
        control.markAsTouched()
      );
    }

    this.sectionArrayList.forEach((element, i) => {
      this.validateSectionsOD(element.OD, i);
      this.validateSectionsID(element.ID, i);
      this.validateSectionsLength(element.Length, i);
      this.validateSectionsMaterial(element.Material, i);
    });

    let sectionFlag = true;

    this.sectionArrayErrorList.forEach((item) => {
      if (item.OD || item.ID || item.Length || item.Material) {
        sectionFlag = false;
      }
    });

    if (this.customConnectionForm.valid && sectionFlag) {
      let gradeVal = parseFloat(this.customConnectionForm.get("Grade").value);
      let gradeIndex = this.materialListOptions.find(
        (o) => o.value === gradeVal
      );

      //below code will find the toolSizeId according to the name
      let toolSizeId = 1;

      console.log(
        "this.fileteredtoolSizeMenus length: " + this.toolSizeListOptions.length
      );
      console.log(
        "this.data.ConnectionToolSizeId: " +
          this.customConnectionForm.get("ConnectionToolSizeId").value
      );
      this.toolSizeListOptions.forEach((toolSizeObj) => {
        console.log("toolSizeObj: " + JSON.stringify(toolSizeObj));

        if (
          toolSizeObj.Name ==
          this.customConnectionForm.get("ConnectionToolSizeId").value
        )
          toolSizeId = toolSizeObj.ToolSizeId;
      });

      let data: customConnections = {
        localRecordId: this.data.localRecordId ? this.data.localRecordId : 0,
        ConnectionName: this.customConnectionForm.get("ConnectionName").value,
        ConnectionToolSizeId: this.customConnectionForm.get(
          "ConnectionToolSizeId"
        ).value,
        Name: this.customConnectionForm.get("ConnectionToolSizeId").value,
        TempConnectionToolSizeId: toolSizeId,
        ToolSizeId: toolSizeId,
        NominalWeight: parseFloat(
          this.customConnectionForm.get("NominalWeight").value
        ),
        ConnectionNW: parseFloat(
          this.customConnectionForm.get("ConnectionNW").value
        ),
        Grade: gradeIndex.label,
        ConnectionType:
          this.customConnectionForm.get("IsSystem").value == "true" ||
          this.customConnectionForm.get("IsSystem").value == "1"
            ? "API"
            : "Non API",
        Manufacturer: this.customConnectionForm.get("Manufacturer").value,
        OuterDiameter: parseFloat(
          this.customConnectionForm.get("OuterDiameter").value
        ),
        InnerDiameter: parseFloat(
          this.customConnectionForm.get("InnerDiameter").value
        ),
        Length: parseFloat(this.customConnectionForm.get("Length").value),
        IsSystem:
          this.customConnectionForm.get("IsSystem").value == "true" ||
          this.customConnectionForm.get("IsSystem").value == "1"
            ? true
            : false,
        BurstPressure: parseFloat(this.calculatedBurstEfficiency),
        CollapsePressure: parseFloat(this.calculatedCollapseEfficiency),
        YieldTensileStrength: parseFloat(this.calculatedTensileEfficiency),
        Compression: parseFloat(this.calculatedCompressionEfficiency),
        MakeupTorque: parseFloat(
          this.customConnectionForm.get("MakeupTorque").value
        ),
        MaterialId: [
          parseInt(this.customConnectionForm.get("Grade").value),
          parseInt(this.customConnectionForm.get("Grade").value),
        ],
        isLimitChecked: this.isCheckboxChecked,
        isNewlyAdded: false,
        isDeleted: false,
        ConnectionId:
          this.data.ConnectionId && this.data.ConnectionId > 0
            ? this.data.ConnectionId
            : 0,
        isUpdated: false,
      };

      this.customConnectionsService.setCustomConnection(data);
      this.action = false;
      this.dialogRef.close();
    }
  } //end of 'saveData' function

  validateSectionsID(value, i) {
    if (value) {
      if (value <= 0 || value > this.sectionArrayList[i]["OD"]) {
        this.sectionArrayErrorList[i]["ID"] =
          "Inner Diameter should be greater than 0 and less than OD";
      } else {
        this.sectionArrayErrorList[i]["ID"] = "";
      }
    } else {
      this.sectionArrayErrorList[i]["ID"] =
        "Inner Diameter should be greater than 0 and less than OD";
    }
  }

  validateSectionsOD(value, i) {
    if (value) {
      if (value <= 0) {
        this.sectionArrayErrorList[i]["OD"] =
          "Outer Diameter should be greater than 0";
      } else {
        this.sectionArrayErrorList[i]["OD"] = "";
      }
    } else {
      this.sectionArrayErrorList[i]["OD"] =
        "Outer Diameter should be greater than 0";
    }
    this.validateSectionsID(this.sectionArrayList[i]["ID"], i);
  }
  validateSectionsLength(value, i) {
    if (value) {
      if (value <= 0 || value > 100) {
        this.sectionArrayErrorList[i]["Length"] =
          "Length should be between 0 to 100";
      } else {
        this.sectionArrayErrorList[i]["Length"] = "";
      }
    } else {
      this.sectionArrayErrorList[i]["Length"] =
        "Length should be between 0 to 100";
    }
  }
  validateSectionsMaterial(value, i) {
    if (value) {
      this.sectionArrayErrorList[i]["Material"] = "";
    } else {
      this.sectionArrayErrorList[i]["Material"] = "This field is mandatory";
    }
  }
  onInputBlur() {
    //console.log('Input lost focus');
    this.customConnectionForm.get("BurstPressure").markAsTouched();

    console.log(this.customConnectionForm.value.BurstPressure);
    if (this.customConnectionForm.value.BurstPressure !== "") {
      let toFixed_value = this.activatedUnit?.pressure?.precision
        ? this.activatedUnit?.pressure?.precision
        : 2;
      this.customConnectionForm
        .get("BurstPressure")
        .patchValue(
          Number(this.customConnectionForm.value.BurstPressure).toFixed(
            toFixed_value
          )
        );
    }
  }

  formatInputValue() {
    if (this.inputValue !== undefined) {
      this.inputValue = parseFloat(this.inputValue.toFixed(2));
    }
  }

  onOdBlur() {
    console.log(this.customConnectionForm.value.OuterDiameter);
    if (this.customConnectionForm.value.OuterDiameter !== "") {
      let toFixed_value = this.activatedUnit?.shortLength?.precision
        ? this.activatedUnit?.shortLength?.precision
        : 2;
      this.customConnectionForm
        .get("OuterDiameter")
        .patchValue(
          Number(this.customConnectionForm.value.OuterDiameter).toFixed(
            toFixed_value
          )
        );
    }

    if (!this.customConnectionForm.value.OuterDiameter) {
      this.customConnectionForm.get("BurstPressure").patchValue("");
      this.customConnectionForm.get("CollapsePressure").patchValue("");
      this.customConnectionForm.get("YieldTensileStrength").patchValue("");
      this.customConnectionForm.get("Compression").patchValue("");
      this.customConnectionForm.get("MakeupTorque").patchValue("");
    }
  }

  onIdBlur() {
    console.log(this.customConnectionForm.value.InnerDiameter);
    if (this.customConnectionForm.value.InnerDiameter !== "") {
      let toFixed_value = this.activatedUnit?.shortLength?.precision
        ? this.activatedUnit?.shortLength?.precision
        : 2;
      this.customConnectionForm
        .get("InnerDiameter")
        .patchValue(
          Number(this.customConnectionForm.value.InnerDiameter).toFixed(
            toFixed_value
          )
        );
    }

    if (!this.customConnectionForm.value.InnerDiameter) {
      this.customConnectionForm.get("BurstPressure").patchValue("");
      this.customConnectionForm.get("CollapsePressure").patchValue("");
      this.customConnectionForm.get("YieldTensileStrength").patchValue("");
      this.customConnectionForm.get("Compression").patchValue("");
      this.customConnectionForm.get("MakeupTorque").patchValue("");
    }
  }

  onConnectionNWBlur() {
    console.log(this.customConnectionForm.value.ConnectionNW);
    if (this.customConnectionForm.value.ConnectionNW !== "") {
      let toFixed_value = this.activatedUnit?.linearMassDensity?.precision
        ? this.activatedUnit?.linearMassDensity?.precision
        : 2;
      this.customConnectionForm
        .get("ConnectionNW")
        .patchValue(
          Number(this.customConnectionForm.value.ConnectionNW).toFixed(
            toFixed_value
          )
        );
    }
  }

  onNominalweight() {
    console.log(this.customConnectionForm.value.NominalWeight);
    if (this.customConnectionForm.value.NominalWeight !== "") {
      let toFixed_value = this.activatedUnit?.linearMassDensity?.precision
        ? this.activatedUnit?.linearMassDensity?.precision
        : 2;
      this.customConnectionForm
        .get("NominalWeight")
        .patchValue(
          Number(this.customConnectionForm.value.NominalWeight).toFixed(
            toFixed_value
          )
        );
    }
  }

  onCollapsePressure() {
    console.log(this.customConnectionForm.value.CollapsePressure);
    if (this.customConnectionForm.value.CollapsePressure !== "") {
      let toFixed_value = this.activatedUnit?.pressure?.precision
        ? this.activatedUnit?.pressure?.precision
        : 2;
      this.customConnectionForm
        .get("CollapsePressure")
        .patchValue(
          Number(this.customConnectionForm.value.CollapsePressure).toFixed(
            toFixed_value
          )
        );
    }
  }

  onYeildStergth() {
    console.log(this.customConnectionForm.value.YieldTensileStrength);
    if (this.customConnectionForm.value.YieldTensileStrength !== "") {
      let toFixed_value = this.activatedUnit?.force?.precision
        ? this.activatedUnit?.force?.precision
        : 2;
      this.customConnectionForm
        .get("YieldTensileStrength")
        .patchValue(
          Number(this.customConnectionForm.value.YieldTensileStrength).toFixed(
            toFixed_value
          )
        );
    }
  }

  onCompression() {
    console.log(this.customConnectionForm.value.Compression);
    if (this.customConnectionForm.value.Compression !== "") {
      let toFixed_value = this.activatedUnit?.force?.precision
        ? this.activatedUnit?.force?.precision
        : 2;
      this.customConnectionForm
        .get("Compression")
        .patchValue(
          Number(this.customConnectionForm.value.Compression).toFixed(
            toFixed_value
          )
        );
    }
  }

  onMakeupTorque() {
    console.log(this.customConnectionForm.value.MakeupTorque);
    if (this.customConnectionForm.value.MakeupTorque !== "") {
      let toFixed_value = this.activatedUnit?.torque?.precision
        ? this.activatedUnit?.torque?.precision
        : 2;
      this.customConnectionForm
        .get("MakeupTorque")
        .patchValue(
          Number(this.customConnectionForm.value.MakeupTorque).toFixed(
            toFixed_value
          )
        );
    }
  }

  getActiveUnitSystemData() {
    // this.unitSystemData = {};
    this.unitsService.getActiveUnitSystemDetails().subscribe({
      next: (res) => {
        if (res) {
          console.log("res in casing---", res);
          let activeUnitSystemData = res;
          this.activatedUnit = res;
          this.shortLengthLabel = activeUnitSystemData.shortLength.unitValue;
          this.linearMassDensityLabel =
            activeUnitSystemData.linearMassDensity.unitValue;
          this.lengthLabel = activeUnitSystemData.length.unitValue;
          this.pressureLabel = activeUnitSystemData.pressure.unitValue;
          this.torqueLabel = activeUnitSystemData.torque.unitValue;
          this.forceLabel = activeUnitSystemData.force.unitValue;

          this.shortLengthPrecision = this.activatedUnit?.shortLength?.precision
            ? this.activatedUnit.shortLength.precision
            : 2;
          this.linearMassDensityPrecision = this.activatedUnit
            ?.linearMassDensity?.precision
            ? this.activatedUnit.linearMassDensity.precision
            : 2;
          this.lengthPrecision = this.activatedUnit?.length?.precision
            ? this.activatedUnit.length.precision
            : 2;
          this.pressurePrecision = this.activatedUnit?.pressure?.precision
            ? this.activatedUnit.pressure.precision
            : 2;
          this.torquePrecision = this.activatedUnit?.torque?.precision
            ? this.activatedUnit.torque.precision
            : 2;
          this.forcePrecision = this.activatedUnit?.force?.precision
            ? this.activatedUnit.force.precision
            : 2;
        } else {
          //console.log('error');
        }
      },
      error: (error) => {
        //console.log("Unit", error.error.result);
      },
    });
  }

  IsCheckLimits() {
    let chkLimitAs = this.customConnectionForm.get("checkbox").value;
    if (chkLimitAs == false) {
      this.IsAbsolute = true;
      this.calculateResult(false, true);
    } else {
      this.IsAbsolute = false;
      this.calculateResult(true, false);
    }
  }

  getIDAndOd() {
    this.customConnectionForm.get("OuterDiameter").value;
    this.customConnectionForm.get("InnerDiameter").value;
    this.IsEditing = true;
    this.calculateResult(true, true);
  }

  get innerDiameter(): number {
    return this.customConnectionForm.get("OuterDiameter").value;
  }

  set innerDiameter(value: number) {
    this.customConnectionForm.get("OuterDiameter").setValue(value);
    this.IsEditing = true;
    this.calculateResult(true, true);
  }

  async calculateResult(IsAbsoluteCal = true, IsDefaultCal = true) {
    console.log("Unit --", this.shortLengthLabel);

    // if(this.shortLengthLabel == "in"){

    if (
      this.customConnectionForm.get("OuterDiameter").value &&
      this.customConnectionForm.get("InnerDiameter").value
    ) {
      console.log("If loop---");

      let TotalBurst = 0;
      let TotalCollapse = 0;
      let TotalTension = 0;
      let TotalCompression = 0;
      let collapsePressure = 0;

      let pipeOD = this.customConnectionForm.get("OuterDiameter").value;
      let pipeID = this.customConnectionForm.get("InnerDiameter").value;

      if (this.shortLengthLabel == "mm") {
        pipeOD = pipeOD / 25.4;
        pipeID = pipeID / 25.4;
      }

      let updatedBurstPressure;
      let updatedCollapsePressure;
      let updatedYieldTensileStrength;
      let updatedCompression;

      let BurstPressure = this.actualBurstEfficiency;
      let CollapsePressure = this.actualCollapseEfficiency;
      let YieldTensileStrength = this.actualTensileEfficiency;
      let Compression = this.actualCompressionEfficiency;

      console.log("Innerdiameter", pipeID + "Outerdiameter", pipeOD);

      let wellThickness = (pipeOD - pipeID) / 2.0;

      console.log(
        "this.customConnectionForm.get('Grade').value",
        parseInt(this.customConnectionForm.get("Grade").value)
      );

      let selectedMaterialId = parseInt(
        this.customConnectionForm.get("Grade").value
      );
      console.log(
        "materialListOptionsforcalculations",
        this.materialListOptionsforcalculations
      );
      let yeildStrength = this.materialListOptionsforcalculations.find(
        (o) => o.MaterialId === selectedMaterialId
      )?.YieldStress;
      TotalTension =
        (yeildStrength *
          (Math.PI * Math.pow(pipeOD / 2, 2) -
            Math.PI * Math.pow(pipeID / 2, 2)) *
          (100 / 100)) /
        1000;
      console.log("TotalTension", TotalTension);
      TotalBurst =
        0.875 *
        ((2 * yeildStrength * wellThickness) / parseFloat(pipeOD)) *
        (100 / 100);
      TotalCollapse = 0; //CalculateCollapsePresure(YeildStrength, PipeOD, WallThickness, collapsePressure);
      TotalCompression = TotalTension * 0.6;

      TotalTension = TotalTension * 0.999999827;
      TotalCompression = TotalCompression * 0.999999827;

      console.log(
        "this.customConnectionForm.get('checkbox').value",
        this.customConnectionForm.get("checkbox").value
      );

      let chkLimitAs = this.customConnectionForm.get("checkbox").value;
      console.log("chkLimitAs", chkLimitAs);
      if (IsAbsoluteCal && chkLimitAs == false) {
        if (this.shortLengthLabel == "mm") {
          updatedBurstPressure = TotalBurst;
          updatedYieldTensileStrength = TotalTension / 1000;
          updatedCompression = TotalCompression / 1000;
          updatedYieldTensileStrength =
            updatedYieldTensileStrength * 92903.03996633828 * 6.944444362364988;
          updatedCompression =
            updatedCompression * 92903.03996633828 * 6.944444362363988;
        } else {
          updatedBurstPressure = TotalBurst;
          updatedCollapsePressure = TotalCollapse;
          updatedYieldTensileStrength = TotalTension * 1000;
          updatedCompression = TotalCompression * 1000;
        }

        let toFixed_pressure = this.activatedUnit?.pressure?.precision
          ? this.activatedUnit?.pressure?.precision
          : 2;
        let toFixed_Force = this.activatedUnit?.force?.precision
          ? this.activatedUnit?.force?.precision
          : 2;

        this.data.BurstPressure =
          updatedBurstPressure.toFixed(toFixed_pressure);
        this.data.CollapsePressure = updatedCollapsePressure
          ? updatedCollapsePressure
          : 0;
        this.data.YieldTensileStrength =
          updatedYieldTensileStrength.toFixed(toFixed_Force);
        this.data.Compression = updatedCompression.toFixed(toFixed_Force);

        this.actualBurstEfficiency = this.data.BurstPressure;
        this.actualCollapseEfficiency = this.data.CollapsePressure;
        this.actualCompressionEfficiency = this.data.Compression;
        this.actualTensileEfficiency = this.data.YieldTensileStrength;

        this.calculatedBurstEfficiency = this.data.BurstPressure;
        this.calculatedCollapseEfficiency = this.data.CollapsePressure;
        this.calculatedCompressionEfficiency = this.data.Compression;
        this.calculatedTensileEfficiency = this.data.YieldTensileStrength;

        this.customConnectionForm
          .get("BurstPressure")
          .setValue(updatedBurstPressure.toFixed(toFixed_pressure));
        this.customConnectionForm
          .get("CollapsePressure")
          .setValue(updatedCollapsePressure ? updatedCollapsePressure : 0);
        this.customConnectionForm
          .get("YieldTensileStrength")
          .setValue(updatedYieldTensileStrength.toFixed(toFixed_Force));
        this.customConnectionForm
          .get("Compression")
          .setValue(updatedCompression.toFixed(toFixed_Force));
      } else {
        if (
          chkLimitAs == true &&
          this.customConnectionForm.get("OuterDiameter").value &&
          this.customConnectionForm.get("InnerDiameter").value
        ) {
          if (this.IsEditing == false) {
            if (TotalBurst > 0 && BurstPressure != null) {
              updatedBurstPressure = (BurstPressure * 100) / TotalBurst;
              this.customConnectionForm
                .get("BurstPressure")
                .setValue(updatedBurstPressure);
            } else {
              updatedBurstPressure = 0;
              this.customConnectionForm
                .get("BurstPressure")
                .setValue(updatedBurstPressure);
            }

            if (TotalCollapse > 0 && CollapsePressure != null) {
              updatedCollapsePressure =
                (CollapsePressure * 100) / TotalCollapse;
              this.customConnectionForm
                .get("CollapsePressure")
                .setValue(updatedCollapsePressure);
            } else {
              updatedCollapsePressure = 0;
              this.customConnectionForm
                .get("CollapsePressure")
                .setValue(updatedCollapsePressure);
            }

            if (TotalTension > 0 && YieldTensileStrength != null) {
              updatedYieldTensileStrength =
                (YieldTensileStrength * 100) / TotalCollapse;
              this.customConnectionForm
                .get("YieldTensileStrength")
                .setValue(updatedYieldTensileStrength);
            } else {
              updatedYieldTensileStrength = 0;
              this.customConnectionForm
                .get("YieldTensileStrength")
                .setValue(updatedYieldTensileStrength);
            }

            if (TotalCompression > 0 && Compression != null) {
              updatedCompression = (Compression * 100) / TotalCollapse;
              this.customConnectionForm
                .get("Compression")
                .setValue(updatedCompression);
            } else {
              updatedCompression = 0;
              this.customConnectionForm
                .get("Compression")
                .setValue(updatedCompression);
            }
          } else {
            this.BurstEfficiency =
              this.actualBurstEfficiency == this.calculatedBurstEfficiency
                ? this.actualBurstEfficiency
                : this.calculatedBurstEfficiency;
            this.CollapseEfficiency =
              this.actualCollapseEfficiency == this.calculatedCollapseEfficiency
                ? this.actualCollapseEfficiency
                : this.calculatedCollapseEfficiency;
            this.CompressionEfficiency =
              this.actualCompressionEfficiency ==
              this.calculatedCompressionEfficiency
                ? this.actualCompressionEfficiency
                : this.calculatedCompressionEfficiency;
            this.TensileEfficiency =
              this.actualTensileEfficiency == this.calculatedTensileEfficiency
                ? this.actualTensileEfficiency
                : this.calculatedTensileEfficiency;
          }

          this.IsEditing = false;
          this.IsAbsolute = false;

          this.actualBurstEfficiency = this.BurstEfficiency;
          this.actualCollapseEfficiency = this.CollapseEfficiency;
          this.actualCompressionEfficiency = this.CompressionEfficiency;
          this.actualTensileEfficiency = this.TensileEfficiency;

          this.calculatedBurstEfficiency = this.BurstEfficiency;
          this.calculatedCollapseEfficiency = this.CollapseEfficiency;
          this.calculatedCompressionEfficiency = this.CompressionEfficiency;
          this.calculatedTensileEfficiency = this.TensileEfficiency;

          this.data.BurstPressure = this.BurstEfficiency;
          this.data.CollapsePressure = this.CollapseEfficiency;
          this.data.YieldTensileStrength = this.TensileEfficiency;
          this.data.Compression = this.CompressionEfficiency;

          this.customConnectionForm
            .get("BurstPressure")
            .setValue(this.BurstEfficiency);
          this.customConnectionForm
            .get("CollapsePressure")
            .setValue(this.CollapseEfficiency);
          this.customConnectionForm
            .get("YieldTensileStrength")
            .setValue(this.TensileEfficiency);
          this.customConnectionForm
            .get("Compression")
            .setValue(this.CompressionEfficiency);
        } else {
          this.IsAbsolute = true;
          chkLimitAs = false;
          this.customConnectionForm.get("checkbox").setValue(chkLimitAs);
          //else part not understand
        }
      }
    }
  }

  manufacturerList() {
    this.customConnectionsService.getManufacturerList().subscribe({
      next: (res) => {
        if (res) {
          res.result.forEach((ele) => {
            if (ele !== "") {
              this.manufacturerListOptions.push(ele);
            }
          });
        }
        this.fileteredmanufacturerOptions.next(this.manufacturerListOptions);
        this.filterControl.valueChanges.subscribe({
          next: () => {
            let filter = this.filterControl.value.toLowerCase();
            let filteredList = this.manufacturerListOptions.filter(
              (option) => option.toLowerCase().indexOf(filter) >= 0
            );
            this.fileteredmanufacturerOptions.next(filteredList);
          },
        });
      },
      error: (error) => {
        this.toastr.error("Something Went Wrong");
      }, //end of service call
    });
  }

  LengthValidation() {
    if (this.lengthLabel == "m") {
      this.Length = true;
      this.customConnectionForm
        .get("Length")
        .setValidators([
          Validators.required,
          Validators.min(0),
          Validators.max(30.48),
        ]);
      this.customConnectionForm.get("Length").updateValueAndValidity();
    } else {
      this.Length = false;
      this.customConnectionForm
        .get("Length")
        .setValidators([
          Validators.required,
          Validators.min(0),
          Validators.max(100),
        ]);
      this.customConnectionForm.get("Length").updateValueAndValidity();
    }
  }
}
