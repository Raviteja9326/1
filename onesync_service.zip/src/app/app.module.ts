import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

//For adding interceptor class
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { GlobalInterceptor } from './core/services/httpInterceptor.service';
import { ToastrModule } from 'ngx-toastr';
import { NgxUiLoaderConfig, NgxUiLoaderModule, NgxUiLoaderRouterModule} from 'ngx-ui-loader';
import { ngxUiLoaderConfig } from './shared/ui-loader';
import { DatePipe } from '@angular/common';

const ngxUiLoaderConfigs: NgxUiLoaderConfig = ngxUiLoaderConfig

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    NgxUiLoaderRouterModule,
    HttpClientModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfigs),
    ToastrModule.forRoot({
      maxOpened: 1,
      preventDuplicates: true,
      timeOut: 3000,
      positionClass: "toast-top-right",
      closeButton: false,
      newestOnTop: true,
      extendedTimeOut: 1000
    }),
  ],
  exports: [],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: GlobalInterceptor, multi: true }, DatePipe],
  bootstrap: [AppComponent]
})

export class AppModule { }