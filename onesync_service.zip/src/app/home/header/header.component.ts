import { Component, OnInit } from '@angular/core';
import { filelist, planslist, realtimelist, reportslist, setuplist, realtimedashboardlist } from 'src/app/core/interfaces/menulist.interface';
import { AllinoneService } from 'src/app/core/services/allinone.service';
import { MenulistService } from 'src/app/core/services/menulist.service';
import { StorageService } from 'src/app/core/services/storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnInit {

  selectedNavItem: any = 'file';
  well: any;
  filesmenu: any = filelist;
  setupmenu: any = setuplist;
  planmenu: any = planslist;
  report: any = reportslist;
  realtimemenu:any = realtimelist;
  realtimedashboardmenu:any = realtimedashboardlist;

  constructor(private resuable: AllinoneService, private menulist: MenulistService, private store: StorageService) {
    this.getMenutolocal();
  }

  ngOnInit(): void {
    this.menulist?.menuData.subscribe(res => {
      this.selectedNavItem = res.Name
    })
    this.resuable.reportsData.subscribe(res => {
     if(res != undefined){
      this.well = res;
     }
     else if(res == undefined){
      this.well = this.store?.getWellName()
     }
    })
  }


  getMenutolocal() {
    if (this.store.getmenu() != null) {
      //console.log('1')
      this.selectedNavItem = this.store.getmenu();
      this.onNavItemClicked(this.selectedNavItem.Name)
    }
    else {
      //console.log('2')
      this.onNavItemClicked(this.selectedNavItem);
    }
  }

  onNavItemClicked(item: string) {
    //console.log('3',item);
    this.selectedNavItem = item.toLowerCase();
    this.sendMenutosidebar()
  }

  sendMenutosidebar() {
    //console.log('4')
    if ( this.selectedNavItem.toLowerCase() === "file") {
      this.menulist.getmenusdata(this.filesmenu);
    }
   else if ( this.selectedNavItem.toLowerCase() === "setup") {
      this.menulist.getmenusdata(this.setupmenu);
    }
    else if ( this.selectedNavItem.toLowerCase() === "plans") {
      this.menulist.getmenusdata(this.planmenu);
    }
    // else if ( this.selectedNavItem.toLowerCase() ==='realtime') {
    //   this.menulist.getmenusdata(this.realtimemenu);
    //   }
    else if ( this.selectedNavItem.toLowerCase() ==='realtimedashboard') {
      this.menulist.getmenusdata(this.realtimedashboardmenu);
    }
  }
}
