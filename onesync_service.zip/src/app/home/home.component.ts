import { Component, OnInit, ElementRef } from '@angular/core';
import { MenulistService } from '../core/services/menulist.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  constructor(private elementRef: ElementRef) {
    this.jqureymethods();
  }
  ngOnInit(): void {}
  jqureymethods() {
    /**
 * Below Functionality Is For Navabar, sidebar and mobile responsiveness
 */
    var s1 = document.createElement('script');
    s1.type = 'text/javascript';
    s1.src = '../../assets/js/sidebarmenu.js';
    this.elementRef.nativeElement.appendChild(s1);
    var s2 = document.createElement('script');
    s2.type = 'text/javascript';
    s2.src = '../../assets/js/custom.min.js';
    this.elementRef.nativeElement.appendChild(s2);
  }
}
