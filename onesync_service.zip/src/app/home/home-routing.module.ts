import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';


const routes: Routes = [
{path:'',component:HomeComponent, children:[
{path:'wells', data: {preload: false}, loadChildren:()=> import('../planning/wells/wells.module').then(m=>m.WellsModule)},
{path:'catalogs', data: {preload: false}, loadChildren:()=> import('../planning/catalogs/catalogs.module').then(m=>m.CatalogsModule)},
{path:'jobinfo', data: {preload: false}, loadChildren:()=> import('../planning/job-info/job-info.module').then(m=>m.JobInfoModule)},
{path:'projects', data: {preload: false}, loadChildren:()=> import('../planning/project/project.module').then(m=>m.ProjectModule)},
{path:'survey',data: {preload: false},loadChildren: () => import("../real-time/survey/survey.module").then(m => m.SurveyModule) },
{path:'flowchart',data: {preload: false},loadChildren: () => import("../real-time/flow-chart/flow-chart.module").then(m => m.FlowChartModule) },
{path:'realtime',data: {preload: false},loadChildren: () => import("../real-time/survey/survey.module").then(m => m.SurveyModule) },
{path:'workstring', data: {preload: false}, loadChildren:()=> import('../planning/workstring/workstring.module').then(m=>m.WorkstringModule)},
{path:'units', data: {preload: false}, loadChildren:()=> import('../planning/units/units.module').then(m=>m.UnitsModule)},
{path:'fluids', data: {preload: false}, loadChildren:()=> import('../planning/fluids/fluids.module').then(m=>m.FluidsModule)},
{path:'mappings', data: {preload: false}, loadChildren:()=> import('../planning/mappings/mappings.module').then(m=>m.MappingsModule)},
{path:'surface-equipment', data: {preload: false}, loadChildren:()=> import('../planning/surface-equipment/surface-equipment.module').then(m=>m.SurfaceEquipmentModule)},
{path:'limits-alarms', data: {preload: false}, loadChildren:()=> import('../planning/limit-alarms/limits-alarms.module').then(m=>m.LimitAlarmsModule)},
{path:'gridstack', data: {preload: false}, loadChildren:()=> import('../real-time/gridstack/gridstack.module').then(m=>m.GridstackModule)},
{path:'oneclick-settings', data: {preload: false}, loadChildren:()=> import('../planning/one-click-settings/one-click-settings.module').then(m=>m.OneClickSettingsModule)},
{path:'mva-settings', data: {preload: false}, loadChildren:()=> import('../planning/mva-settings/mva-settings.module').then(m=>m.MVASettingsModule)},
{path:'daq', data: {preload: false}, loadChildren:()=> import('../planning/daq/daq.module').then(m=>m.DaqModule)},
{path: 'mechanics',data: {preload: false}, loadChildren: () => import('../planning/mechanics/mechanics.module').then(m => m.MechanicsModule) },
{path:'hydraulics-Plan', data: {preload: false}, loadChildren:()=> import('../planning/hydraulics/hydraulics.module').then(m=>m.HydraulicsPlanModule)},
{path:'calculators', data: {preload: false}, loadChildren:()=> import('../planning/calculators/calculators.module').then(m=>m.CalculatorsModule)},
{path:'oneclick', data: {preload: false}, loadChildren:()=> import('../planning/plan-oneclick/plan-oneclick.module').then(m=>m.PlanoneclickModule)},
{path:'real-time-dashboard', data: {preload: false}, loadChildren:()=> import('../real-time-dashboard/real-time-dashboard.module').then(m=>m.RealTimeDashboardModule)},
{path:'systemperferences', data: {preload: false}, loadChildren:()=> import('../planning/systemperferences/systemperferences.module').then(m=>m.SystemperferencesModule)},

]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
