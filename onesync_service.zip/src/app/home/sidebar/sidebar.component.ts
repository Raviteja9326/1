import { Component, HostListener, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MenulistService } from 'src/app/core/services/menulist.service';
import { StorageService } from 'src/app/core/services/storage.service';
import { RealTimeDashboardService } from 'src/app/core/services/real-time-dashboard.service';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  filesmenu:any;
  createdBy = 1;  //default '1' as user management hasn't implemented yet
  rtDashoardMenus: any;
  headerName: '-';
  constructor(
    private menu:MenulistService, private router: Router,
    private realTimeDashboardService: RealTimeDashboardService,
    private toaster: ToastrService,
    private ngxLoader: NgxUiLoaderService) {}

  ngOnInit(): void {
    this.getsubcribemenus();
  }

  getsubcribemenus(){
    this.menu?.menuData.subscribe(res=>{
      console.log(res)
      if(res != null || undefined){
        this.filesmenu = res;
        if (this.filesmenu.file.length > 0) {
          const firstMenuItem = this.filesmenu.file[0];
          if (firstMenuItem.menuPath) {
            if(this.filesmenu.Name == 'realtimedashboard'){
              this.getRTdashboardMenus();
            }
            this.router.navigate([firstMenuItem.menuPath]);
          }
        }
      }
    })
  }

  onMenuChanges(firstMenuItem){
    this.realTimeDashboardService.setMenuHeaderData(firstMenuItem.RealTimeDashboardName)
    this.rtDashoardMenus?.forEach( dash=> {
      if( dash.RealTimeDashboardId == firstMenuItem.RealTimeDashboardId){
        dash['isSelected'] = true
      } else {
        dash['isSelected'] = false
      }
    })
    this.realTimeDashboardService.setSelectedDashboard(firstMenuItem)
  }

  getRTdashboardMenus() {
    let getRTPayload = {
      createdBy: this.createdBy
    }
    this.realTimeDashboardService.getRTdashboard(getRTPayload).subscribe({
      next: (apiResponse) => {
        this.ngxLoader.stop();
        
        if (apiResponse && apiResponse.message  == "Success" && apiResponse.result) {
          let rtResult = apiResponse.result;
          this.rtDashoardMenus = [ ...rtResult['dynamic_realTimeDashboardData'], ...rtResult['static_realTimeDashboardData']];
          this.rtDashoardMenus.sort((a,b)=> a.RealTimeDashboardPosition - b.RealTimeDashboardPosition);
        }
        // console.log("realtimedashboard: ", this.rtDashoardMenus, this.rtDashoardMenus[0]?.RealTimeDashboardName );
        this.headerName = this.rtDashoardMenus[0]?.RealTimeDashboardName? this.rtDashoardMenus[0].RealTimeDashboardName : '-' ;
        let selectedDashboard = this.rtDashoardMenus[0]? this.rtDashoardMenus[0] : [] ;
        this.rtDashoardMenus[0]['isSelected'] = true;
        this.realTimeDashboardService.setMenuHeaderData(this.headerName)
        this.realTimeDashboardService.setMenuData(this.rtDashoardMenus);
       
        this.realTimeDashboardService.setSelectedDashboard(selectedDashboard)

      },
      error: (error) => {
        this.ngxLoader.stop();
        if (!error)
          this.toaster.info("GET getRTdashboardMenus api error: " + error.status + error.message);
        else
          this.toaster.error("GET getRTdashboardMenus api error: " + error);
      }
    });
  }

}
