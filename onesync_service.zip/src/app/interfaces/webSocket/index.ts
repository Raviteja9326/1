import { environment } from "../../../environments/environment"
import { webSocket } from "rxjs/webSocket"


export class WebSocketInterface {
    private socket$
    private wsUrl: string
    private baseUrl: string
    constructor(host, url) {
        this.wsUrl = url
        // this.baseUrl = host + '/' + environment.apiUrl
        this.baseUrl = host + '/api/v1'
    }

    public init() {
        //console.log(location)
        this.socket$ = webSocket(this.baseUrl + this.wsUrl)
    }

    public sendMessage(message) {
        this.socket$.next(message)
    }

    public getMessages() {
        return this.socket$.asObservable()
    }

    public close() {
        this.socket$.complete()
    }
}