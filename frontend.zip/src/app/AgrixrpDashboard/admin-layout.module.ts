import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AdminLayoutRoutingModule } from "./admin-layout-routing.module";
import { FooterComponent } from "./maincomponents/footer/footer.component";
import { NavbarComponent } from "./maincomponents/navbar/navbar.component";
import { SidebarComponent } from "./maincomponents/sidebar/sidebar.component";
import { AdminLayoutComponent } from "./admin-layout.component";
import { SweetAlert2Module } from "@toverux/ngsweetalert2";
import { TranslateModule } from "@ngx-translate/core";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { NgxMatSelectSearchModule } from "./maincomponents/mat-select-search/ngx-mat-select-search.module";
import { MatTableExporterModule } from "mat-table-exporter";
import { ErrorComponent } from './maincomponents/error/error.component';
import { NgOtpInputModule } from 'ng-otp-input';
import { CountdownModule } from 'ngx-countdown';
import { ToastrModule, ToastrService } from "ngx-toastr";
import { DatePipe } from "@angular/common";
import { MAT_DATE_LOCALE } from "@angular/material";
import { RxReactiveFormsModule } from "@rxweb/reactive-form-validators";
import { LoginComponent } from './login/login.component';
import { MaterialModule } from './material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { DialogBoxComponent } from './onBoarding/SoilData/dialog-box/dialog-box.component';
@NgModule({
  declarations: [
    DialogBoxComponent,
    ErrorComponent,
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    DashboardComponent,
    AdminLayoutComponent,
    LoginComponent,
  ],
  imports: [
    NgbModule,
    MaterialModule,
    MaterialFileInputModule,
    RxReactiveFormsModule,
    CountdownModule,
    NgOtpInputModule,
    CommonModule,
    RouterModule,
    AdminLayoutRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    NgxMatSelectSearchModule,
    MatTableExporterModule,
    SweetAlert2Module.forRoot(),
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: "toast-top-right",
      preventDuplicates: true,
      closeButton: false,
      newestOnTop: true,
      extendedTimeOut: 1000
    })
  ],
  providers: [ToastrService, { provide: MAT_DATE_LOCALE, useValue: "en-GB" }, DatePipe]
})
export class AdminLayoutModule { }
