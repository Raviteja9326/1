import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PrerequisitesRoutingModule } from './prerequisites-routing.module';
import { NgxMatSelectSearchModule } from 'app/AgrixrpDashboard/maincomponents/mat-select-search/ngx-mat-select-search.module';
import { PrerequisitesDataComponent } from './prerequisites.component';
import { CorrectionsfollowupComponent } from './correction followup/correctionsfollowup/correctionsfollowup.component';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';


// tslint:disable-next-line:max-line-length
const components = [PrerequisitesDataComponent, CorrectionsfollowupComponent];

@NgModule({
	// tslint:disable-next-line:max-line-length
	imports: [
		PrerequisitesRoutingModule,
		CommonModule,
		RouterModule,
		FormsModule,
		ReactiveFormsModule,
		HttpClientModule,
		MaterialModule,
		NgxMatSelectSearchModule
	],
	declarations: [...components]
})
export class PrerequisitesdataModule { }
