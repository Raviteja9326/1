import { Component } from '@angular/core';

@Component({
	selector: 'app-Prerequisitesdata',
	template: `<router-outlet></router-outlet>`
})
export class PrerequisitesDataComponent {}
