import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrerequisitesDataComponent } from './prerequisites.component';
import { CorrectionsfollowupComponent } from './correction followup/correctionsfollowup/correctionsfollowup.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
const routes: Routes = [
	{
		path: '',
		component: PrerequisitesDataComponent,
		children: [
			{
				path: 'Corrections Follow Up',
				component: CorrectionsfollowupComponent, canActivate: [AuthGuardService]
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class PrerequisitesRoutingModule { }
