import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorrectionsfollowupComponent } from './correctionsfollowup.component';

describe('CorrectionsfollowupComponent', () => {
  let component: CorrectionsfollowupComponent;
  let fixture: ComponentFixture<CorrectionsfollowupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorrectionsfollowupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorrectionsfollowupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
