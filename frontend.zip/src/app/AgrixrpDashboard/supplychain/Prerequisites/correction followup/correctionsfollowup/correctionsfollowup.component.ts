import { Component, OnInit, ViewChild } from '@angular/core';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { supplychain } from 'app/services/supplychain';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';

export interface FollowUp {
	CorrectionType?: any;
	_When?: any;
	FollowType?: any;
	Status?: any;
	Note?: any;
	created_by?: number;
	modified_by?: number;
}

@Component({
	selector: 'app-correctionsfollowup',
	templateUrl: './correctionsfollowup.component.html',
	styleUrls: ['./correctionsfollowup.component.scss']
})
export class CorrectionsfollowupComponent implements OnInit {
	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'CorrectionType', 'Actions'];

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;
	getalldata: any;
	Vditcorrectionfollowup: any;

	constructor(private formBuilder: FormBuilder, private ls: supplychain, private dp: DatePipe) { }

	Correctionfollowup = 'CorrectiveActions';
	edittype = 'add_circle';
	editcorrectionfollowup = true;
	displayddl: string;
	updatecorrectionfollowup = false;
	viewcorrectionfollowup = false;
	Editcorrectionfollowup: any;
	displayNoRecords = false;
	secretKey: string;

	correctionTypes: any[] = ['Soil', 'Water', 'Report Disease', 'Pest Control', 'Fertilizers', 'Deworming'];

	correctionfollowup = this.formBuilder.group({
		CorrectionType: ['', [Validators.required]],
		_When: [''],
		FollowType: [''],
		Status: [''],
		Note: [''],
		created_by: [],
		modified_by: []
	});

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	toggleUpdatecorrectionfollowup(getcorrectionfollowupDataObj) {
		this.Editcorrectionfollowup = getcorrectionfollowupDataObj;
		//console.log('datatobeupdate', this.Editcorrectionfollowup);
		this.updatecorrectionfollowup = !this.updatecorrectionfollowup;
		this.displayddl = !this.editcorrectionfollowup ? 'inline' : 'none';
		this.correctionfollowup.controls.modified_by.patchValue(1);
		this.Editcorrectionfollowup._When = this.dp.transform(this.Editcorrectionfollowup._When, 'yyyy-MM-dd');
		this.correctionfollowup.setValue({
			CorrectionType: this.Editcorrectionfollowup.CorrectionType,
			_When: this.Editcorrectionfollowup._When,
			FollowType: this.Editcorrectionfollowup.FollowType,
			Status: this.Editcorrectionfollowup.Status,
			Note: this.Editcorrectionfollowup.Note,
			created_by: this.Editcorrectionfollowup.created_by,
			modified_by: this.Editcorrectionfollowup.modified_by
		});
	}

	toggleUpdatecorrectionfollowup1() {
		this.updatecorrectionfollowup = false;
		this.displayddl = this.editcorrectionfollowup ? 'inline' : 'block';
	}

	updateCorrectionFollowUp() {
		//console.log('updated data', this.correctionfollowup.value);
		if (!this.correctionfollowup.valid) {
			Object.keys(this.correctionfollowup.controls).forEach((field) => {
				const control = this.correctionfollowup.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
		} else {
			this.correctionfollowup.controls.created_by.patchValue(1);
			this.correctionfollowup.value._When = this.dp.transform(this.correctionfollowup.value._When, 'yyyy-MM-dd');
			this.ls
				.updateCorrectionFollowUpById(this.Editcorrectionfollowup.ID, this.correctionfollowup.value)
				.subscribe(
					(res) => {
						//console.log(res);
						if (
							this.Editcorrectionfollowup.CorrectionType ===
							this.correctionfollowup.controls.CorrectionType.value &&
							this.Editcorrectionfollowup._When === this.correctionfollowup.controls._When.value &&
							this.Editcorrectionfollowup.FollowType ===
							this.correctionfollowup.controls.FollowType.value &&
							this.Editcorrectionfollowup.Status === this.correctionfollowup.controls.Status.value &&
							this.Editcorrectionfollowup.Note === this.correctionfollowup.controls.Note.value
						) {
							//console.log('no update');
							Swal.fire({
								position: 'center',
								type: 'info',
								title: 'No update Found',
								showConfirmButton: false,
								timer: 1500
							});
							this.barButtonOptions.active = false;
							this.barButtonOptions.text = 'SUBMIT';
						} else if (res['data'] === 'Success') {
							//console.log('update');
							Swal.fire({
								position: 'center',
								type: 'success',
								title: 'Sucessfully Edited',
								showConfirmButton: false,
								timer: 1500
							});
							this.barButtonOptions.active = false;
							this.barButtonOptions.text = 'SUBMIT';
							this.getAllCorrectionFollowup();
							this.toggleUpdatecorrectionfollowup1();
						}
					},
					(err) => console.log(err)
				);
		}
	}

	resetForm() {
		this.correctionfollowup.reset();
	}

	ngOnInit() {
		this.getAllCorrectionFollowup();
	}

	getAllCorrectionFollowup() {
		this.ls.getAllCorrectionFollowupData().subscribe((res) => {
			//console.log(res);
			this.getalldata = res;
			this.listData = new MatTableDataSource(this.getalldata);
			if (this.getalldata.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			/* config filter */
			this.listData.filterPredicate = (data: FollowUp, filter: string) =>
				data.CorrectionType.toLowerCase().indexOf(filter) !== -1;
			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	Addcorrectionfollowup() {
		this.Correctionfollowup =
			this.Correctionfollowup === 'CorrectiveActions' ? 'Add CorrectiveActions' : 'CorrectiveActions';
		this.edittype = this.edittype === 'add_circle' ? 'cancel' : 'add_circle';
		this.getAllCorrectionFollowup();
		this.correctionfollowup.reset();
		this.editcorrectionfollowup = !this.editcorrectionfollowup;
		this.displayddl = this.editcorrectionfollowup ? 'inline' : 'none';
	}

	Createcorrectionfollowup() {
		//console.log('this is submitted data', this.correctionfollowup.value);
		if (!this.correctionfollowup.valid) {
			Object.keys(this.correctionfollowup.controls).forEach((field) => {
				const control = this.correctionfollowup.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
		} else {
			this.correctionfollowup.controls.created_by.patchValue(1);
			this.correctionfollowup.value._When = this.dp.transform(this.correctionfollowup.value._When, 'yyyy-MM-dd');
			this.ls.saveCorrectionFollowUpData(this.correctionfollowup.value).subscribe(
				(res) => {
					if (res['data'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added the CorrectionFollowUpData',
							showConfirmButton: false,
							timer: 1500
						});
						this.getAllCorrectionFollowup();
						this.Addcorrectionfollowup();
						this.correctionfollowup.reset();
					} else if ((res['data'] = 'CorrectionFollowUpData already exists!')) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The CorrectionFollowUpData',
							showConfirmButton: false,
							timer: 1500
						});
					}
				},
				(err) => console.error(err)
			);
		}
	}

	deletecorrectionfollowup(id: string) {
		//console.log(id);
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteCorrectionfollowUpDataById(id).subscribe((res) => {
					if ((res['data'] = 'Success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.getAllCorrectionFollowup();
					}
				});
			}
		});
	}

	toggleViewcorrectionfollowup(getcorrectionfollowupDataObj) {
		this.Vditcorrectionfollowup = getcorrectionfollowupDataObj;
		this.viewcorrectionfollowup = !this.viewcorrectionfollowup;
		this.displayddl = !this.editcorrectionfollowup ? 'inline' : 'none';
	}

	toggleViewcorrectionfollowup1() {
		this.viewcorrectionfollowup = false;
		this.displayddl = this.editcorrectionfollowup ? 'inline' : 'block';
	}
}
