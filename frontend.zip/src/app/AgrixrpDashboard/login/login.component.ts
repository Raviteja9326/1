import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from "@angular/router";
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { CASService } from 'app/services/cas.service';
import Swal from 'sweetalert2';
import { ErrorStateMatcher } from '@angular/material';
import { slideInOutAnimation } from '../maincomponents/animations';
import { UserActy } from 'app/services/auth/user';
import { MatProgressButtonOptions } from 'mat-progress-buttons';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, ): boolean {
    const invalidCtrl = !!(control && control.invalid && control.parent.dirty);
    const invalidParent = !!(control && control.parent && control.parent.invalid && control.parent.dirty);

    return invalidCtrl || invalidParent;
  }
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [slideInOutAnimation],
  host: { '[@slideInOutAnimation]': '' }
})

export class LoginComponent implements OnInit {
  otp: string;
  showOtpComponent = true;
  @ViewChild('ngOtpInput') ngOtpInput: any;
  config = {
    allowNumbersOnly: false,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: false,
    placeholder: '',
    inputStyles: {
      'width': '40px',
      'height': '40px'
    }
  };
  property: any[];
  OTPdata: any;
  otpenterform: boolean;
  userlogin: boolean;
  resetpassword: boolean;
  changepasswordform: boolean;
  roles: any;
  activities: any;
  acty: any;

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success'
  };

  onOtpChange(otp) {
    this.otp = otp;
  }

  setVal(val) {
    this.ngOtpInput.setValue(val);
  }

  onConfigChange() {
    this.showOtpComponent = false;
    this.otp = null;
    setTimeout(() => {
      this.showOtpComponent = true;
    }, 0);
  }

  loginDetails: any;
  editvillagesarpanch = true;
  editvillagesarpanchContent = "add_circle";
  villagesarpanchNames = "Password Assistance";
  uservillagesarpanchData: any = [];
  EditvillagesarpanchData: any = [];
  updatevillagesarpanch = false;
  updatepassword = false;
  displayddl: string;
  userDetails(ID: number, Email: string, UserName: string, Location: string) {
    let data = {
      ID: ID,
      Email: Email,
      UserName: UserName,
      Location: Location
    };
    return data;
  }

  constructor(private toastr: ToastrService, private readonly casService: CASService,
    private formBuilder: FormBuilder,
    private router: Router, private readonly serr: UserActy) { }

  LoginForm = this.formBuilder.group({
    Email: ['', [Validators.required, Validators.email]],
    Password: ['', [Validators.required]]
  });

  MobileForm = this.formBuilder.group({
    PhoneNo: ['', [
      Validators.required,
    ]]
  });

  OTPForm = this.formBuilder.group({
    OTPno: ['', [Validators.required]]
  });

  matcher = new MyErrorStateMatcher();

  PASWForm = this.formBuilder.group(
    {
      ID: [''],
      Password: ['', [Validators.required, Validators.pattern('^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^!&*+=]).*$')]],
      confirmPassword: ['']
    },
    { validator: this.checkPasswords }
  );

  checkPasswords(group: FormGroup) {
    // here we have the 'passwords' group
    let pass = group.controls.Password.value;
    let confirmPass = group.controls.confirmPassword.value;
    return pass === confirmPass ? null : { notSame: true };
  }

  ngOnInit() {
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  toggleEditvillagesarpanch() {
    this.LoginForm.reset();
    this.MobileForm.reset();
    this.villagesarpanchNames =
      this.villagesarpanchNames === "Password Assistance" ? "Password Assistance" : "Password Assistance";
    this.editvillagesarpanch = !this.editvillagesarpanch;
    this.displayddl = this.editvillagesarpanch ? "block" : "none";
  }


  toggleUpdatevillagesarpanch() {
    if (!this.MobileForm.valid) {
      Object.keys(this.MobileForm.controls).forEach(field => {
        const control = this.MobileForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.toastr.error('Please enter your phone number');
    }

    else {
      Swal.fire({
        title: 'Are you sure?',
        html: `${this.MobileForm.value.PhoneNo} <br/><br/> Is this ok,or would you like to edit the number`,
        position: 'center',
        width: 400,
        padding: '0.1em',
        confirmButtonText: 'ok',
        focusConfirm: false,
        showCancelButton: true,
        confirmButtonClass: 'btn btn-success',
        cancelButtonClass: 'btn btn-warning',
        cancelButtonText: 'Edit',
        cancelButtonAriaLabel: 'Edit'
      }).then((result) => {
        if (result.value) {
          this.casService.sendMobileNo(this.MobileForm.value).subscribe(
            (res) => {
              if (result.value) {
                if (res['message'] === 'Mobile Number Not Registered') {
                  this.toastr.error('Mobile Number Not Registered');
                }
                else if (res['message'] === 'Otp Sent SuccessFully') {
                  this.property = res;
                  this.OTPdata = this.property['data'];
                  this.editvillagesarpanch = !this.editvillagesarpanch;
                  this.updatevillagesarpanch = !this.updatevillagesarpanch;
                  this.displayddl = !this.editvillagesarpanch ? "inline" : "none";
                  this.OTPForm.reset();
                }
              }
            }

          )
        }
      })
    }
  }


  toggleUpdatevillagesarpanch2() {
    this.editvillagesarpanch = !this.editvillagesarpanch;
    this.updatevillagesarpanch = !this.updatevillagesarpanch;
    this.displayddl = this.editvillagesarpanch ? "inline" : "none";
  }

  successmsg() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.casService.login(this.LoginForm.value).subscribe((response) => {
      if (response['status'] === true) {
        this.loginDetails = response['data'];
        //console.log(this.userDetails(this.loginDetails.ID, this.loginDetails.Email, this.loginDetails.UserName, this.loginDetails.Location));
        this.roles = this.loginDetails.roles.map((ele: { ActivityMaster: { ActiyMasterName: any }[] }) => {
          return ele.ActivityMaster.map((elee: { ActiyMasterName: any }) => {
            return elee.ActiyMasterName;
          });
        });

        this.activities = this.loginDetails.roles.map(
          (ele: { ActivityMaster: { Activities: { ActiyName: any }[] }[] }) => {
            return ele.ActivityMaster.map((elee: { Activities: { ActiyName: any }[] }) => {
              return elee.Activities.map((elle: { ActiyName: any }) => {
                return elle.ActiyName;
              });
            });
          }
        );
        var corona = [].concat(...this.activities);
        var covid = [].concat(...corona);
        this.acty = this.activities[0];
        this.serr.getdata(this.loginDetails.roles, covid, this.roles, this.loginDetails.token, this.userDetails(this.loginDetails.ID, this.loginDetails.Email, this.loginDetails.UserName, this.loginDetails.Location));

        this.router.navigate(['/Agrixrp/dashboard']);
        this.toastr.success('Welcome To AgriXrp', 'Sucessfully logged In');
        this.barButtonOptions.active = false;
        this.barButtonOptions.text = 'Sign In';
      }
      else {
        this.toastr.error('Invalid Credentials');
        this.barButtonOptions.active = false;
        this.barButtonOptions.text = 'Sign In';
      }
    });


  }

  submitOTPNo() {
    if (this.OTPForm.value.OTPno === this.OTPdata[0].otp) {
      this.updatevillagesarpanch = !this.updatevillagesarpanch;
      this.updatepassword = !this.updatepassword;
      this.PASWForm.reset()
    } else {
      this.toastr.error('Invalid OTP Number ');
    }
  }

  submitPassword() {
    if (!this.PASWForm.valid) {
      Object.keys(this.PASWForm.controls).forEach(field => {
        const control = this.PASWForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.toastr.error('Please Set New Password');
    }
    else {
      this.PASWForm.controls.ID.patchValue(this.OTPdata[0].ID);
      this.casService.changePasswordRequest(this.PASWForm.value, this.PASWForm.value.ID).subscribe((res) => {
        if (res['message'] === 'Success') {
          this.updatepassword = !this.updatepassword
          this.displayddl = this.editvillagesarpanch ? "inline" : "block";
          this.toastr.success('Password Changed Succesfully');
        }
      });
    }
  }
}
