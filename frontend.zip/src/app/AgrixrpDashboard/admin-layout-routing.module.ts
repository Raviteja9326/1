import { Routes, RouterModule } from "@angular/router";
import { AdminLayoutComponent } from "./admin-layout.component";
import { HttpModule } from "@angular/http";
import { NgModule } from "@angular/core";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
import { ErrorComponent } from './maincomponents/error/error.component';
import { LoginComponent } from './login/login.component';
import { DialogBoxComponent } from './onBoarding/SoilData/dialog-box/dialog-box.component';

const routes: Routes = [
  { path: "", redirectTo: "Login", pathMatch: "full" },
  { path: "Login", component: LoginComponent },
  {
    path: "Agrixrp",
    component: AdminLayoutComponent,
    children: [
      { path: "dashboard", component: DashboardComponent },
      {
        path: "Masters",
        loadChildren: () =>
          import("./onBoarding/Masters/masters.module").then(
            m => m.MastersModule
          )
      },

      // tslint:disable-next-line:max-line-length
      {
        path: "Miscellaneous",
        loadChildren: () =>
          import("./onBoarding/Miscellaneous/miscllaneous.module").then(
            m => m.MiscellaneousModule
          )
      },
      {
        path: "Crop",
        loadChildren: () =>
          import("./onBoarding/CropData/crop.module").then(
            m => m.CropModule
          )
      },
      {
        path: "Diseases",
        loadChildren: () =>
          import("./onBoarding/DiseasData/disease.module").then(
            m => m.DiseaseModule
          )
      },
      {
        path: "CAS",
        loadChildren: () =>
          import("./cas/CAS.module").then(
            m => m.CASDataModule
          )
      },
      {
        path: "Farmer",
        loadChildren: () =>
          import("./onBoarding/FarmerData/farmerdata.module").then(
            m => m.FarmerDataModule
          )
      },
      {
        path: "Soil",
        loadChildren: () =>
          import("./onBoarding/SoilData/soildata.module").then(
            m => m.SoildataModule
          )
      },
      {
        path: "Fertilizers & PestControl",
        loadChildren: () =>
          import("./onBoarding/FarmData/Farmdata.module").then(
            m => m.FarmdataModule
          )
      },
      {
        path: "RawMaterials",
        loadChildren: () =>
          import("./onBoarding/Raw Material/rawmaterials.module").then(
            m => m.RawmaterialModule
          )
      },
      {
        path: "Water",
        loadChildren: () =>
          import("./onBoarding/WaterTestData/Waterdata.module").then(
            m => m.WaterdataModule
          )
      },
      // tslint:disable-next-line: max-line-length
      {
        path: "Asset Management",
        loadChildren: () =>
          import("./onBoarding/AssetManagement/assetmanagement.module").then(
            m => m.AssetmanagementModule
          )
      },
      {
        path: "Reports",
        loadChildren: () =>
          import("./onBoarding/reports/reports.module").then(
            m => m.ReportsModule
          )
      },
      {
        path: 'PreRequisites',
        loadChildren: () =>
          import('./supplychain/Prerequisites/prerequisites.module').then(
            (m) => m.PrerequisitesdataModule
          )
      }, {
        path: 'Animal',
        loadChildren: () =>
          import('./onBoarding/AnimalData/animal.module').then(
            (m) => m.AnimalModule
          )
      },
      { path: 'error', component: ErrorComponent, canActivate: [AuthGuardService] },
      { path: 'dialogbox', component: DialogBoxComponent, canActivate: [AuthGuardService] }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes), HttpModule],
  exports: [RouterModule],
})
export class AdminLayoutRoutingModule { }
