import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TwoDigitDecimaNumberDirective } from './directives/TwoDigitDecimaNumber.directive';
import { DragDropDirective } from './directives/drag-drop.directive';



@NgModule({
  declarations: [TwoDigitDecimaNumberDirective, DragDropDirective],
  imports: [
    CommonModule
  ],
  exports: [TwoDigitDecimaNumberDirective, DragDropDirective]
})
export class SharedModule { }
