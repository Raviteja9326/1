import { Component, OnInit } from "@angular/core";
import * as $ from "jquery";
import PerfectScrollbar from "perfect-scrollbar";
import { UserActy } from 'app/services/auth/user';
import { API_URl } from 'app/services/masters.service';
declare interface ROUTES {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const ROUTES = [
  //onboarding
  //Masters
  { path: "/Agrixrp/Masters/Country", title: " Country" },
  { path: "/Agrixrp/Masters/Currency", title: "Currency" },
  { path: "/Agrixrp/Masters/States", title: "States" },
  { path: "/Agrixrp/Masters/Districts", title: "Districts" },
  { path: "/Agrixrp/Masters/Mandals", title: "Mandal" },
  { path: "/Agrixrp/Masters/Revenue", title: "Revenue Division" },
  { path: "/Agrixrp/Masters/villages", title: "Villages" },
  { path: "/Agrixrp/Masters/villagesarpanch", title: "Village Sarpanch" },
  { path: "/Agrixrp/Masters/C3office", title: "C3 Office" },
  //farmerdata
  { path: "/Agrixrp/Farmer/information", title: "Farmer's information" },
  { path: "/Agrixrp/Farmer/LabourInformation", title: "LabourData" },
  //loandata
  { path: "/Agrixrp/Loan/emi", title: "LoanEmi" },
  { path: "/Agrixrp/Loan/history", title: "LoanData" },
  //landdata
  { path: "/Agrixrp/Land/layout", title: "Land Layout's" },
  { path: "/Agrixrp/Land/plotting", title: "Land Plotting" },
  { path: "/Agrixrp/Land/croplanes", title: "Land Croplanes" },
  //cropdata
  { path: "/Agrixrp/Crop/Crop%20Category", title: "Crop Category" },
  { path: "/Agrixrp/Crop/Crop%20Master", title: "Crop Master" },
  { path: "/Agrixrp/Crop/Crop%20Cycle", title: "Crop Cycle" },
  { path: "/Agrixrp/Crop/Crop%20Calander%20Of%20Operations", title: "Crop Calander Of Operations" },
  //Waterdata
  { path: "/Agrixrp/Water/Water%20Master", title: "Water Master" },
  { path: "/Agrixrp/Water/Water%20Category", title: "Water Category" },
  { path: "/Agrixrp/Water/Water%20Test%20Data", title: "Water Test Data" },
  { path: "/Agrixrp/Water/Water%20Test%20Corrections", title: "Water Test Corrections" },
  //Soildata
  { path: "/Agrixrp/Soil/Soil%20Type", title: "Soil Type" },
  { path: "/Agrixrp/Soil/Soil%20Category", title: "Soil Category" },
  { path: "/Agrixrp/Soil/Soil%20Nutrients", title: "Soil Nutrients" },
  { path: "/Agrixrp/Soil/Soil%20Test%20Data", title: "Soil Test Data" },
  { path: "/Agrixrp/Soil/Soil%20Test%20Corrections", title: "Soil Test Corrections" },
  //AnimalData
  { path: "/Agrixrp/Animal/Animal%20Cycle", title: "AnimalHistory" },
  { path: "/Agrixrp/Animal/Animal%20Category", title: "AnimalCategory" },
  { path: "/Agrixrp/Animal/Animal%20Master", title: "AnimalMaster" },
  { path: "/Agrixrp/Animal/Animal%20Breed", title: "AnimalBreed" },
  { path: "/Agrixrp/Animal/Animal%20Vaccination", title: "Vaccination" },
  { path: "/Agrixrp/Animal/Animal%20Calander%20Of%20Operations", title: "Animal Calander Of Operations" },
  //disease
  { path: "/Agrixrp/Diseases/AnimalManagement", title: "Animal Management" },
  { path: "/Agrixrp/Diseases/AnimalReport", title: "Animal Report" },
  { path: "/Agrixrp/Diseases/CropManagement", title: "Crop Management" },
  { path: "/Agrixrp/Diseases/CropReport", title: "Crop Report" },
  { path: "/Agrixrp/Diseases/DiseaseType", title: "Disease Type" },
  //Consultant 
  { path: "/Agrixrp/Consultation/ConsultExpert", title: "consult Expert" },
  //AssetManagement
  { path: "/Agrixrp/AssetManagement/VermiCompostCOPMaster", title: "Vermicompost Calender Of Operations" },
  { path: "/Agrixrp/AssetManagement/VermiCompostCycle", title: "Vermicompost Cycle" },
  { path: "/Agrixrp/AssetManagement/Shed", title: "Shed" },
  { path: "/Agrixrp/AssetManagement/VermiCompostMaster", title: "Vermicompost PIT" },
  { path: "/Agrixrp/AssetManagement/Irrigation", title: "Irrigation" },
  //FarmData
  { path: "/Agrixrp/Fertilizers%20&%20PestControl/Company%20Master", title: "Company Master" },
  { path: "/Agrixrp/Fertilizers%20&%20PestControl/Fertilizers", title: "Fertilizers" },
  { path: "/Agrixrp/Fertilizers%20&%20PestControl/Pest%20Control", title: "Pest Control" },
  //RawMaterials
  { path: "/Agrixrp/RawMaterials/Dealers", title: "dealers Information" },
  { path: "/Agrixrp/RawMaterials/RawMaterialData", title: "RawMaterialStock" },
  { path: "/Agrixrp/RawMaterials/Inventory", title: "Inventory" },
  { path: "/Agrixrp/RawMaterials/BillOfMaterials", title: "billofmaterial" },
  //cas
  { path: "/Agrixrp/CAS/Roles", title: "Roles" },
  { path: "/Agrixrp/CAS/ActivityMaster", title: "ActivityMaster" },
  { path: "/Agrixrp/CAS/RoleActivity", title: "RoleActivity" },
  { path: "/Agrixrp/CAS/UserManagement", title: "UserManagement" },

  //Miscellaneous
  { path: "/Agrixrp/Miscellaneous/Expenses", title: "Expenses Information" },
  { path: "/Agrixrp/Miscellaneous/LabourHours", title: "LabourHours" },
  //supply chain
  //Prerequisites
  { path: "/Agrixrp/PreRequisites/CorrectionsFollowUp", title: "Corrections Followup" },

];

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.scss"]
})
export class SidebarComponent implements OnInit {
  menuItems: any[];
  editCivil = false;
  editOnboard = true;
  editSupply = false;
  fullData: any;
  userlsdata: any;
  url: any;

  constructor(private readonly serrr: UserActy) { }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  }


  toggleCivilForce() {
    this.editCivil = true;
    this.editOnboard = false;
    this.editSupply = false;
  }

  toggleOnBoarding() {
    this.editOnboard = true;
    this.editCivil = false;
    this.editSupply = false;
  }

  toggleOnSupply() {
    this.editSupply = true;
    this.editCivil = false;
    this.editOnboard = false;
  }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
    this.userlsdata = this.serrr.getuserdetails();
    this.fullData = this.serrr.getFullData();
    this.url = API_URl
  }

  updatePS(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && !this.isMac()) {
      const elemSidebar = <HTMLElement>document.querySelector('.sidebar .sidebar-wrapper');
      let ps = new PerfectScrollbar(elemSidebar, { wheelSpeed: 2, suppressScrollX: true });
    }
  }
  isMac(): boolean {
    let bool = false;
    if (navigator.platform.toUpperCase().indexOf('MAC') >= 0 || navigator.platform.toUpperCase().indexOf('IPAD') >= 0) {
      bool = true;
    }
    return bool;
  }


  logout() {
    this.serrr.logout();
  }
}
