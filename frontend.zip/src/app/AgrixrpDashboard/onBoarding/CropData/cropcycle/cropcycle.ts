export interface CropCycle {
    ID:number,
    LandInAcres?:any,
    CropMaturityDays?:any,
    CropStartDate?:any,
    CropEndDate?:any,
    CropOutputQuantity?:any,
    TblLand_ID?:any,
    TblCropCOP_ID?:any,
    TblPloting_ID?:any,
    TblCropLane_ID?:any,
    TblCropMaster_ID?:any,
    created_by?:any,
    modified_by?:any
}
export interface land {
    LandName?:any
}