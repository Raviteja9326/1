import { Component, OnInit, ViewChild } from "@angular/core";
import { Validators, FormBuilder, FormControl } from "@angular/forms";
import { MastersService } from "app/services/masters.service";
import Swal from "sweetalert2";
import { DatePipe } from "@angular/common";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MatTableDataSource, MatPaginator, MatSort } from "@angular/material";
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Farmer } from '../../FarmerData/farmerinfo/farmerinfo';
import { CropMaster } from '../cropmast/cropmaster';

@Component({
  selector: "app-cropcycle",
  templateUrl: "./cropcycle.component.html",
  styleUrls: ["./cropcycle.component.scss"]
})
export class CropcycleComponent implements OnInit {
  public FarmerFilterCtrl: FormControl = new FormControl();
  public filteredFarmer: ReplaySubject<Farmer[]> = new ReplaySubject<Farmer[]>(1);
  listData: MatTableDataSource<any>;
  listData1: MatTableDataSource<any>;
  protected _onDestroy = new Subject<void>();
  // tslint:disable-next-line: max-line-length
  displayedColumns1: string[] = ['S.No', 'Activity', 'Duration', 'Date'];
  displayedColumns: string[] = [
    "S.No",
    "CropVarietyName",
    "PlotingName",
    "CropMaturityDays",
    "CropStartDate",
    "CropEndDate",
    "CropOutputQuantity",
    "TblCropCOP_ID",
    "Actions"
  ];
  editCropCycle = true;
  editCropCycleContent = "add_circle";
  CropCycleNames = "CropCycle List";
  displayddl: string;
  updateCropCycle = false;
  viewCropCycle = false;
  userCropCycledata: any[];
  Editcoun: any = [];
  EditCropCycleData: any = [];
  EditOldData: any = [];
  usercropmasterdata: any[];
  usercroplanedata: any[];
  userplotdata: any[];
  usercropdata: any[];
  userlanddata: any[];
  usercopdata: any[];
  plotByLand: any[];
  userfarmerdata: Farmer[] = [];
  mainactivities: any;
  cropByplot: any[];
  Editcoc: any = [];
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;
  date: Date;

  CropCycleForm = this.formBuilder.group({
    LandInAcres: ["", [Validators.required]],
    CropMaturityDays: ["", [Validators.required]],
    CropStartDate: [""],
    CropEndDate: [""],
    CropOutputQuantity: [""],
    Tbl_FarrmerID: ["", [Validators.required]],
    TblLand_ID: ["", [Validators.required]],
    TblCropCOP_ID: ["", [Validators.required]],
    TblPloting_ID: ["", [Validators.required]],
    TblCropLane_ID: ["", [Validators.required]],
    TblCropMaster_ID: ["", [Validators.required]],
    modified_by: [""],
    created_by: [""]
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder,
    private dp: DatePipe
  ) { }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    this.resetdrop(event);
    if (this.CropCycleForm.valid) {
      ////console.log("Form Submited");
      this.CropCycleForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    this.displaycropcycle();

    this.ls.getcropmasterdata().subscribe(cdata => {
      this.usercropmasterdata = cdata;
    });
    this.ls.getlandlayoutData().subscribe(cdata => {
      this.userlanddata = cdata;
    });
    this.ls.getCropcopdata().subscribe(cdata => {
      this.usercopdata = cdata;
    });
    //farmer
    this.ls.getFarmerdata().subscribe(res => {
      //console.log(res)
      this.userfarmerdata = res;
    })

    /*animal end */
    //for farmer
    this.FarmerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFarmerName();
      });
  }
  //for farmer
  protected filterFarmerName() {
    //console.log('shed', this.userfarmerdata)
    if (!this.userfarmerdata) {
      return;
    }
    // get the search keyword
    let search = this.FarmerFilterCtrl.value;
    //console.log(this.FarmerFilterCtrl.value);

    if (!search) {
      this.filteredFarmer.next(this.userfarmerdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredFarmer.next(
      this.userfarmerdata.filter(bank => bank.FarmerName.toLowerCase().indexOf(search) > -1)
    );
  }
  resetdrop(event) {
    this.plotByLand = [];
    this.cropByplot = [];
  }

  onChangeLand(ID: string) {
    if (ID) {
      this.ls.getplottingDataByLand(ID).subscribe(res => {
        if (res["data"] === "NO plotting Available with this Land ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "NO plotting Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.plotByLand = [];
          this.cropByplot = [];
          this.resetdrop(event);
          this.CropCycleForm.controls.TblPloting_ID.patchValue("");
          this.CropCycleForm.controls.TblCropLane_ID.patchValue("");
        } else {

          this.CropCycleForm.controls.TblPloting_ID.patchValue("");
          this.plotByLand = res;
          this.cropByplot = [];
          ////console.log("result", this.plotByLand);
        }
      });
    }
  }

  onChangeplot(ID: string) {
    if (ID) {
      this.ls.getcroplaneDataByplotting(ID).subscribe(res => {
        if (
          res["data"] ===
          "NO plotting Available with this Land ID and Plotting ID"
        ) {
          Swal.fire({
            position: "center",
            type: "info",
            title: "No Croplanes Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.cropByplot = [];
          this.CropCycleForm.controls.TblCropLane_ID.patchValue("");
        } else {
          this.CropCycleForm.controls.TblCropLane_ID.patchValue("");
          this.cropByplot = res;
          ////console.log("result", this.cropByplot);
        }
      });
    }
  }

  displaycropcycle() {
    this.ls.getCropcycle().subscribe(
      list => {
        this.isLoading = false;
        this.userCropCycledata = list;
        ////console.log(this.userCropCycledata);
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userCropCycledata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: CropMaster, filter: any) =>
          data.CropVarietyName.toLowerCase().indexOf(filter) !== -1;
        //
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  CreateCropCycle() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The MandetoryFields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ls.saveCropcycledata(this.CropCycleForm.value).subscribe(
        cropdata => {
          ////console.log(cropdata);
          if (cropdata["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the cropcycle",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.CropCycleForm.reset();
            this.displaycropcycle();
            this.toggleEditCropCycle();
          }
        },
        err => console.error(err)
      );
    }
  }

  UpdateCropCycle(cropdata) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.Editcoc = cropdata;
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.CropCycleForm.controls.modified_by.patchValue(1);
      this.ls
        .updateCropcycleByID(this.Editcoc.ID, this.CropCycleForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displaycropcycle();
              this.toggleUpdateCropCycle2();
            }
          },

        );
    }
  }
  deleteCropCycle(id: any) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteCropcycleByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displaycropcycle();
          }
        });
      }
    });
  }

  toggleEditCropCycle() {
    this.resetdrop(event);
    this.displaycropcycle();
    this.CropCycleForm.reset();
    this.CropCycleNames =
      this.CropCycleNames === "Add CropCycle" ? "CropCycle" : "Add CropCycle";
    this.editCropCycle = !this.editCropCycle;
    this.editCropCycleContent =
      this.editCropCycleContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editCropCycle ? "inline" : "none";
  }

  toggleUpdateCropCycle(getCropCycleDataObj) {
    this.Editcoc = getCropCycleDataObj;
    this.updateCropCycle = !this.updateCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
    this.Editcoc.CropStartDate = this.dp.transform(
      this.Editcoc.CropStartDate,
      "yyyy-MM-dd"
    );
    this.Editcoc.CropEndDate = this.dp.transform(
      this.Editcoc.CropEndDate,
      "yyyy-MM-dd"
    );
    this.ls.getplottingDataByLand(this.Editcoc.TblLand_ID).subscribe(res => {
      this.plotByLand = res;
    });
    this.ls
      .getcroplaneDataByplotting(this.Editcoc.TblPloting_ID)
      .subscribe(res => {
        this.cropByplot = res;
      });
    this.CropCycleForm.controls.modified_by.patchValue(1);
    this.CropCycleForm.setValue({
      LandInAcres: this.Editcoc.LandInAcres,
      CropMaturityDays: this.Editcoc.CropMaturityDays,
      CropStartDate: this.Editcoc.CropStartDate,
      CropEndDate: this.Editcoc.CropEndDate,
      CropOutputQuantity: this.Editcoc.CropOutputQuantity,
      TblLand_ID: this.Editcoc.TblLand_ID,
      TblCropCOP_ID: this.Editcoc.TblCropCOP_ID,
      TblPloting_ID: this.Editcoc.TblPloting_ID,
      TblCropLane_ID: this.Editcoc.TblCropLane_ID,
      TblCropMaster_ID: this.Editcoc.TblCropMaster_ID,
      modified_by: this.Editcoc.modified_by,
      created_by: this.Editcoc.created_by
    });
  }

  toggleUpdateCropCycle2() {
    this.updateCropCycle = false;
    this.displayddl = this.editCropCycle ? "inline" : "block";
  }

  toggleViewCropCycle(id: string) {
    //console.log(id);
    this.ls.getCropcycleByID(id).subscribe(res => {
      //console.log(res)
      this.Editcoun = res;
      this.mainactivities = this.Editcoun.object.result;
      //console.log(this.mainactivities)
      if (this.Editcoun.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }

      //console.log('mainact', this.mainactivities)
      this.date = new Date(this.Editcoun.object.CropStartDate);
      //console.log('date after 1 day', this.date)
      //this.date.setDate(this.date.getDate()+10);

      //console.log('date after 7 day', this.date)
      let DurationArray = [];
      for (let i = 0; i < this.mainactivities.length; i++) {
        DurationArray.push({
          Activity: this.mainactivities[i].Activity,
          Duration: this.mainactivities[i].Duration,
          Date: this.date.setDate(this.date.getDate() + parseInt(this.mainactivities[i].Duration))
        });
        //console.log(DurationArray)

      }
      this.listData1 = new MatTableDataSource(DurationArray);
      //console.log(this.listData1)

      //console.log(this.Editcoun.object.CropStartDate)


    });
    this.viewCropCycle = !this.viewCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
  }

  toggleViewCropCycle2() {
    this.displayNoRecords = false;
    this.viewCropCycle = false;
    this.Editcoun = [];
    this.displayddl = !this.editCropCycle ? "inline" : "block";
  }
}
