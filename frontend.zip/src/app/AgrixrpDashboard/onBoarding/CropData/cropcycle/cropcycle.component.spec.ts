import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropcycleComponent } from './cropcycle.component';

describe('CropcycleComponent', () => {
  let component: CropcycleComponent;
  let fixture: ComponentFixture<CropcycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropcycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropcycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
