import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropcatComponent } from './cropcat.component';

describe('CropcatComponent', () => {
  let component: CropcatComponent;
  let fixture: ComponentFixture<CropcatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropcatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropcatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
