export interface Cropcategory {
    ID:number;
    CropCatName?: string;
    created_by?:any;
   modified_by?:any;
}
