import { Component } from '@angular/core';

@Component({
  selector: 'app-crop',
  template: `<router-outlet></router-outlet>`,
})

export class CropComponent {
}
