export interface CropCopRawmaterial {
    ID: 0,
    TblMaterials_ID?: any;
    Quantity?: any;
    UnitID?: any;
}