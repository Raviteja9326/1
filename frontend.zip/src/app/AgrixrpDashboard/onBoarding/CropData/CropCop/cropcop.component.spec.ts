import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropcopComponent } from './cropcop.component';

describe('CropcopComponent', () => {
  let component: CropcopComponent;
  let fixture: ComponentFixture<CropcopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropcopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropcopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
