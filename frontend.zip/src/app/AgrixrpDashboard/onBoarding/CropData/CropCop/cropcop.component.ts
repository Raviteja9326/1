
import {
  Component,
  OnInit,
  ViewChild,
} from "@angular/core";
import { MastersService } from "app/services/masters.service";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { ReplaySubject, Subject } from "rxjs";
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
//import { Material, CropMaster } from '../../FarmData/Plant Data/cropmast/cropmaster';
import Swal from 'sweetalert2';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { takeUntil } from 'rxjs/operators';
import { CropMaster, Material } from "../cropmast/cropmaster";
@Component({
  selector: 'app-cropcop',
  templateUrl: './cropcop.component.html',
  styleUrls: ['./cropcop.component.scss']
})
export class CropcopComponent implements OnInit {
  protected _onDestroy = new Subject<void>();
  /** control for the MatSelect filter keyword */
  public MatNameFilterCtrl: FormControl = new FormControl();


  /** list of banks filtered by search keyword */
  public MatNameCoun: ReplaySubject<Material[]> = new ReplaySubject<
    Material[]
  >(1);

  userCropCopData: any = [];
  value1 = '';
  value2 = '';
  value3 = '';

  listData: MatTableDataSource<any>;

  listData1 = new MatTableDataSource(this.userCropCopData);
  // tslint:disable-next-line: max-line-length
  displayedColumns1: string[] = ["S.No", "MatName", "Quantity", "Units", "Actions"];
  displayedColumns: string[] = [
    "S.No",
    "CropVarietyName",
    "COPNO",
    "Actions"
  ];
  CropCopRawmaterial = "CropCopRawmaterial";
  editCropCopRawmaterialcontent = "add_circle";
  editCropCopRawmaterial = true;
  editCropCycle = true;
  editCropCycleContent = "add_circle";
  CropCycleNames = "CropCop List";
  displayddl: string;
  displayddl1: string;
  updateCropCycle = false;
  viewCropCycle = false;
  userCropCycledata: any[];
  userplotdata: any[];
  getRawmaterialData: Material[] = [];
  Editcoun: any = [];
  EditCropCycleData: any = [];
  EditOldData: any = [];
  usercropmasterdata: any[];
  usercroplanedata: any[];
  cropByplot: any[];
  usercopdata: any[];
  Editcoc: any = [];
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;
  landSelect = ["Yes", "No"];



  CropCycleForm = this.formBuilder.group({
    COPNO: ["", [Validators.required]],
    Activity: ["", [Validators.required]],
    CropMilestoneID: [""],
    CriticalActivity: [""],
    Dependency: ["", [Validators.required]],
    Duration: ["", [Validators.required]],
    Season: ["", [Validators.required]],
    TblCropMaster_ID: ["", [Validators.required]],
    Rawmaterialdata: [''],
    modified_by: [""],
    created_by: [""]
  });
  CropCycleForm1 = this.formBuilder.group({
    COPNO: ["", [Validators.required]],
    Activity: ["", [Validators.required]],
    CropMilestoneID: [""],
    CriticalActivity: [""],
    Dependency: ["", [Validators.required]],
    Duration: ["", [Validators.required]],
    Season: ["", [Validators.required]],
    TblCropMaster_ID: ["", [Validators.required]],
    modified_by: [""],
    created_by: [""]
  });
  CropCopRawmaterialForm = this.formBuilder.group({
    TblMaterials_ID: [""],
    Quantity: [
      "",
      [Validators.required, Validators.pattern("^-?[0-9]\\d*(\\,\\d{1,10})?$")]
    ],
    UnitID: [""],
    userCropCopData: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder
  ) { }
  //tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    // eslint-disable-next-line no-restricted-globals
    this.resetdrop();
    if (this.CropCycleForm.valid) {
      ////console.log("Form Submited");
      this.CropCycleForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }
  ngOnInit() {
    // this.displayRawmaterial();

    this.ls.getMaterialType().subscribe(res => {
      //console.log(res)
      this.getRawmaterialData = res;
    });
    this.displaycropcycle();
    this.ls.getcropmasterdata().subscribe(res => {
      this.userplotdata = res
    })


    //listen for search field value changes
    this.MatNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterExpenses();
      });


  }
  protected filterExpenses() {
    if (!this.getRawmaterialData) {
      return;
    }
    // get the search keyword
    let search = this.MatNameFilterCtrl.value;
    if (!search) {
      this.MatNameCoun.next(this.getRawmaterialData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.MatNameCoun.next(
      this.getRawmaterialData.filter(
        bank => bank.MatName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  resetdrop() {

  }


  addRawMaterial() {
    this.userCropCopData.push({ MatName: this.value1, Quantity: this.value2, Units: this.value3 })
    this.listData1 = new MatTableDataSource(this.userCropCopData);
    //console.log('fgfgfgh', this.userCropCopData);
    this.CropCycleForm.controls.Rawmaterialdata.patchValue(this.userCropCopData);
    this.value1 = '';
    this.value2 = '';
    this.value3 = '';
  }


  AddCropCopRawmaterial() {

    this.CropCopRawmaterialForm.reset();
    // this.displayRawmaterial();
    this.CropCopRawmaterial =
      this.CropCopRawmaterial === "CropCopRawmaterial"
        ? "Add CropCopRawmaterial"
        : "CropCopRawmaterial";
    this.MatNameCoun.next(this.getRawmaterialData.slice());
    this.editCropCopRawmaterial = !this.editCropCopRawmaterial;
    this.editCropCopRawmaterialcontent =
      this.editCropCopRawmaterialcontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl1 = this.editCropCopRawmaterial ? "inline" : "none";

  }


  displaycropcycle() {
    this.ls.getCropcopdata().subscribe(
      list => {
        this.isLoading = false;
        this.userCropCycledata = list;
        ////console.log(this.userCropCycledata);
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userCropCycledata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: CropMaster, filter: any) =>
          data.CropVarietyName.toLowerCase().indexOf(filter) !== -1;

        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  CreateCropCycle() {
    //console.log('submit data', this.CropCycleForm.value);

    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Saving Data...";
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The MandetoryFields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      //console.log(this.CropCycleForm.value)
      this.CropCycleForm.controls.created_by.patchValue(1);
      this.ls.saveCropcopdata(this.CropCycleForm.value).subscribe(
        cropdata => {
          //console.log(cropdata);
          if (cropdata["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the cropcop",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.CropCycleForm.reset();
            this.displaycropcycle();
            this.toggleEditCropCycle();
          }
        },
        err => console.error(err)
      );
    }
  }

  CreateCropCopRawmaterial() {
    if (!this.CropCopRawmaterialForm.valid) {
      Object.keys(this.CropCopRawmaterialForm.controls).forEach(field => {
        const control = this.CropCopRawmaterialForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.CropCopRawmaterialForm.controls.created_by.patchValue(1);
      this.ls.saveCropCopRawmaterial(this.CropCopRawmaterialForm.value).subscribe(
        res => {
          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropcopRawmaterial",
              showConfirmButton: false,
              timer: 1500
            });
            this.CropCopRawmaterialForm.reset();
            // this.displayRawmaterial();
            this.AddCropCopRawmaterial();
          }
        },
        err => console.error(err)
      );
    }
  }
  UpdateCropCycle(Editcoc) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Saving Data...";
    this.Editcoc = Editcoc;
    if (!this.CropCycleForm1.valid) {
      Object.keys(this.CropCycleForm1.controls).forEach(field => {
        const control = this.CropCycleForm1.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.CropCycleForm1.controls.modified_by.patchValue(1);
      this.ls
        .updateCropcopByID(this.Editcoc.ID, this.CropCycleForm1.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displaycropcycle();
              this.toggleUpdateCropCycle2();
            }
          },

        );
    }
  }
  deleteCropCycle(id: any) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteCropcopByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displaycropcycle();
          }
        });
      }
    });
  }

  toggleEditCropCycle() {
    // eslint-disable-next-line no-restricted-globals
    this.resetdrop();
    this.displaycropcycle();
    this.CropCycleForm1.reset();
    this.CropCycleNames =
      this.CropCycleNames === "Add CropCop" ? "CropCop" : "Add CropCop";
    this.editCropCycle = !this.editCropCycle;
    this.editCropCycleContent =
      this.editCropCycleContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editCropCycle ? "inline" : "none";
  }

  toggleUpdateCropCycle(getCropCycleDataObj) {
    this.Editcoc = getCropCycleDataObj;
    this.updateCropCycle = !this.updateCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
    this.CropCycleForm1.controls.modified_by.patchValue(1);
    this.CropCycleForm1.setValue({
      TblCropMaster_ID: this.Editcoc.TblCropMaster_ID,
      COPNO: this.Editcoc.COPNO,
      Activity: this.Editcoc.Activity,
      CropMilestoneID: this.Editcoc.CropMilestoneID,
      CriticalActivity: this.Editcoc.CriticalActivity,
      Dependency: this.Editcoc.Dependency,
      Duration: this.Editcoc.Duration,
      Season: this.Editcoc.Season,
      modified_by: this.Editcoc.modified_by,
      created_by: this.Editcoc.created_by
    });
  }

  toggleUpdateCropCycle2() {
    this.updateCropCycle = false;
    this.displayddl = this.editCropCycle ? "inline" : "block";
  }

  toggleViewCropCycle(getCropCycleDataObj) {
    this.Editcoun = getCropCycleDataObj;
    this.viewCropCycle = !this.viewCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
  }

  toggleViewCropCycle2() {
    this.viewCropCycle = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }

}




