import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CropComponent } from './crop.component';
import { CropcatComponent } from './cropcat/cropcat.component';
import { CropcopComponent } from './CropCop/cropcop.component';
import { CropcycleComponent } from './cropcycle/cropcycle.component';
import { CropmastComponent } from './cropmast/cropmast.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';

const routes: Routes = [{
    path: '',
    component: CropComponent,
    children: [{
        path: 'Crop Category',
        component: CropcatComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Crop Calander Of Operations',
        component: CropcopComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Crop Cycle',
        component: CropcycleComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Crop Master',
        component: CropmastComponent, canActivate: [AuthGuardService]
    }],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class CropRoutingModule { }
