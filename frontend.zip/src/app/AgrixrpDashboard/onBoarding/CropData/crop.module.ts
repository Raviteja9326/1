import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CropRoutingModule } from './crop-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { MatTableExporterModule } from 'mat-table-exporter';
import { CropComponent } from './crop.component';
import { CropcatComponent } from './cropcat/cropcat.component';
import { CropcopComponent } from './CropCop/cropcop.component';
import { CropcycleComponent } from './cropcycle/cropcycle.component';
import { CropmastComponent } from './cropmast/cropmast.component';

// tslint:disable-next-line:max-line-length
const components = [CropComponent, CropcatComponent, CropcopComponent, CropcycleComponent, CropmastComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [CropRoutingModule, CommonModule, MatTableExporterModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class CropModule { }
