export interface CropMaster {
    ID: 0,
    CropVarietyName?: string;
    Maturitydays?: number;
    AgronomicFeatures?: string;
    BiologicalName?: string;
    VarietyDescription?: string;
    ParentDescription?: string;
    AverageYield?: string;
    created_by?: number;
    modified_by?: number;
    TblCropCategory_ID?: number;
}
export interface CropCopRawmaterial {
    ID: 0,
    TblMaterials_ID?: any;
    Quantity?: any;
    UnitID?: any;
}
export interface Material {
    MatName?: any
}
export interface CropCop {
    ID: number;
    COPNO: any;
    Activity: any;
    CropMilestoneID: number;
    CriticalActivity: any;
    Dependency: number;
    Duration: any;
    Season: any;
    TblCropMaster_ID: number;
    created_by: any;
    modified_by: any;
}