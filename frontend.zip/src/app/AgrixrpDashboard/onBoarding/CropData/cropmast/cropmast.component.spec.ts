import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropmastComponent } from './cropmast.component';

describe('CropmastComponent', () => {
  let component: CropmastComponent;
  let fixture: ComponentFixture<CropmastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropmastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropmastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
