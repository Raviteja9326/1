import { Component, OnInit, ViewChild } from "@angular/core";
import Swal from "sweetalert2";
import { CropMaster } from "./cropmaster";
import { Validators, FormBuilder } from "@angular/forms";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";

@Component({
  selector: "app-cropmast",
  templateUrl: "./cropmast.component.html",
  styleUrls: ["./cropmast.component.scss"]
})
export class CropmastComponent implements OnInit {
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "CropVarietyName",
    "Maturitydays",
    "AgronomicFeatures",
    "BiologicalName",
    "VarietyDescription",
    "ParentDescription",
    "AverageYield",
    "TblCropCategory_ID",
    "Actions"
  ];
  editCropCycle = true;
  editCropCycleContent = "add_circle";
  CropCycleNames = "CropMaster List";
  displayddl: string;
  updateCropCycle = false;
  viewCropCycle = false;
  userCropCycledata: any[];
  Editcoun: any = [];
  EditCropCycleData: any = [];
  EditOldData: any = [];
  usercropmasterdata: any[];
  usercroplanedata: any[];
  userplotdata: any[];
  usercropdata: any[];
  userlanddata: any[];
  usercopdata: any[];
  plotByLand: any[];
  cropByplot: any[];
  Editcoc: any = [];
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;

  CropCycleForm = this.formBuilder.group({
    CropVarietyName: [""],
    Maturitydays: [""],
    AgronomicFeatures: [""],
    BiologicalName: [""],
    VarietyDescription: [""],
    ParentDescription: [""],
    AverageYield: [""],
    TblCropCategory_ID: ["", [Validators.required]],
    modified_by: [""],
    created_by: [""]
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder,
  ) { }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    if (this.CropCycleForm.valid) {
      ////console.log("Form Submited");
      this.CropCycleForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    this.displaycropcycle();
    this.ls.getcropcategorydata().subscribe(list => {
      this.userlanddata = list;
    });
  }

  displaycropcycle() {
    this.ls.getcropmasterdata().subscribe(
      list => {
        this.isLoading = false;
        this.userCropCycledata = list;
        ////console.log(this.userCropCycledata);
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userCropCycledata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: CropMaster, filter: any) =>
          data.CropVarietyName.toLowerCase().indexOf(filter) !== -1;
        //
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  CreateCropCycle() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The MandetoryFields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.CropCycleForm.controls.created_by.patchValue(1);
      this.ls.savecropmasterdata(this.CropCycleForm.value).subscribe(
        cropdata => {
          ////console.log(cropdata);
          if (cropdata["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the cropcycle",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.CropCycleForm.reset();
            this.displaycropcycle();
            this.toggleEditCropCycle();
          } else if ((cropdata["data"] = "serverErrorCropMasterExistence")) {
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The CropMaster",
              showConfirmButton: false,
              timer: 1500
            });
          }
        },
        err => console.error(err)
      );
    }
  }

  UpdateCropCycle(cropdata) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.Editcoc = cropdata;
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ls
        .updatecropmasterByID(this.Editcoc.ID, this.CropCycleForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displaycropcycle();
              this.toggleUpdateCropCycle2();
            }
          },

        );
    }
  }
  deleteCropCycle(id: any) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deletecropmasterByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displaycropcycle();
          }
        });
      }
    });
  }

  toggleEditCropCycle() {
    this.displaycropcycle();
    this.CropCycleForm.reset();
    this.CropCycleNames =
      this.CropCycleNames === "Add CropMaster"
        ? "CropMaster List"
        : "Add CropMaster";
    this.editCropCycle = !this.editCropCycle;
    this.editCropCycleContent =
      this.editCropCycleContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editCropCycle ? "inline" : "none";
  }

  toggleUpdateCropCycle(getCropCycleDataObj) {
    // ////console.log(getFarmersDataObj)
    this.Editcoc = getCropCycleDataObj;
    this.updateCropCycle = !this.updateCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
    this.CropCycleForm.controls.modified_by.patchValue(1);
    this.CropCycleForm.setValue({
      TblCropCategory_ID: this.Editcoc.TblCropCategory_ID,
      CropVarietyName: this.Editcoc.CropVarietyName,
      Maturitydays: this.Editcoc.Maturitydays,
      AgronomicFeatures: this.Editcoc.AgronomicFeatures,
      BiologicalName: this.Editcoc.BiologicalName,
      VarietyDescription: this.Editcoc.VarietyDescription,
      ParentDescription: this.Editcoc.ParentDescription,
      AverageYield: this.Editcoc.AverageYield,
      modified_by: this.Editcoc.modified_by,
      created_by: this.Editcoc.created_by
    });
  }

  toggleUpdateCropCycle2() {
    this.updateCropCycle = false;
    this.displayddl = this.editCropCycle ? "inline" : "block";
  }

  toggleViewCropCycle(getCropCycleDataObj) {
    ////console.log("user signle data", getCropCycleDataObj);
    this.Editcoun = getCropCycleDataObj;
    this.viewCropCycle = !this.viewCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
  }

  toggleViewCropCycle2() {
    this.viewCropCycle = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }
}
