import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VermincompostPitMasterComponent } from './vermincompost-pit-master.component';

describe('VermincompostPitMasterComponent', () => {
  let component: VermincompostPitMasterComponent;
  let fixture: ComponentFixture<VermincompostPitMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VermincompostPitMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VermincompostPitMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
