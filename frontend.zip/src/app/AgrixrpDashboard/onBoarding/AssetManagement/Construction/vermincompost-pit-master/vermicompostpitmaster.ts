export interface VermicompostPITMaster {
    ID?: number;
    TotalArea?: any;
    ConstructionType?: any;
    CostPurchaseYear?: any;
    AgeinYears?: any;
    RemainingLife?: any;
    Cost?: any;
    PresentValue?: any;
    Width?: any;
    Height?: any;
    NoOfTanks?: any;
    TblPloting_ID?: number;
    created_by: string;
    modified_by: string;
}
