import { Component, OnInit, ViewChild } from "@angular/core";
import { VermicompostPITMaster } from "./vermicompostpitmaster";
import {
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import {
  takeUntil
} from "rxjs/operators";
import { Observable, ReplaySubject, Subject } from "rxjs";
import Swal from "sweetalert2";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { PlottingName } from "app/services/Dataservices";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";

@Component({
  selector: "app-vermincompost-pit-master",
  templateUrl: "./vermincompost-pit-master.component.html",
  styleUrls: ["./vermincompost-pit-master.component.scss"]
})
export class VermincompostPitMasterComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "ConstructionType", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public PlottingNameFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredPlottingName: ReplaySubject<
    PlottingName[]
  > = new ReplaySubject<PlottingName[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  displayddl: string;
  Pitmastertypes = "Vermicompost PIT";
  edittype = "add_circle";
  editpitmastertype = true;
  updatePITmastertype = false;
  viewVermicompostPIT = false;
  userpitmasterTypeData: any = [];
  EditVermicompostPITMaster: any = [];
  plottingData: PlottingName[] = [];
  getPlotingData: Observable<any[]>;
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  VerminCompostPITMaster = this.formBuilder.group({
    TotalArea: ["", [Validators.pattern("^[0-9]+$")]],
    ConstructionType: ["", [Validators.required]],
    CostPurchaseYear: [
      "",
      Validators.compose([
        Validators.pattern("^[0-9]+$"),
        Validators.minLength(4),
        Validators.maxLength(4)
      ])
    ],
    AgeinYears: ["", [Validators.pattern("^[0-9]+$")]],
    RemainingLife: ["", [Validators.pattern("^[0-9]+$")]],
    Cost: ["", [Validators.pattern("^[0-9]+$")]],
    PresentValue: ["", [Validators.pattern("^[0-9]+$")]],
    Width: ["", [Validators.pattern("^[0-9]+$")]],
    Height: ["", [Validators.pattern("^[0-9]+$")]],
    NoOfTanks: ["", [Validators.pattern("^[0-9]+$")]],
    TblPloting_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.displayVermicompostPIT();

    this.ls.getplottingData().subscribe(res => {
      this.plottingData = res;
    });
    this.PlottingNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterPlottingName();
      });
  }
  /*plotting data*/
  protected filterPlottingName() {
    if (!this.plottingData) {
      return;
    }
    // get the search keyword
    let search = this.PlottingNameFilterCtrl.value;

    if (!search) {
      this.filteredPlottingName.next(this.plottingData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredPlottingName.next(
      this.plottingData.filter(
        bank => bank.PlotingName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*plotting data ends*/

  displayVermicompostPIT() {
    this.ls.getVermicompostPITData().subscribe(list => {
      this.isLoading = false;
      this.userpitmasterTypeData = list;
      if (this.userpitmasterTypeData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userpitmasterTypeData);
      /* config filter */
      this.listData.filterPredicate = (
        data: VermicompostPITMaster,
        filter: string
      ) => data.ConstructionType.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.VerminCompostPITMaster.valid) {
      this.VerminCompostPITMaster.reset();
    }
  }

  AddPIT() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredPlottingName.next(this.plottingData.slice());
    this.VerminCompostPITMaster.reset();
    this.Pitmastertypes =
      this.Pitmastertypes === "Vermicompost PIT"
        ? "Add Vermicompost PIT"
        : "Vermicompost PIT";
    this.editpitmastertype = !this.editpitmastertype;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editpitmastertype ? "inline" : "none";
  }

  CreateVermincompostPIT() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.VerminCompostPITMaster.valid) {
      Object.keys(this.VerminCompostPITMaster.controls).forEach(field => {
        const control = this.VerminCompostPITMaster.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.VerminCompostPITMaster.controls.created_by.patchValue(0);
      this.ls
        .savevermincompostPITdata(this.VerminCompostPITMaster.value)
        .subscribe(
          res => {
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully added the VerminCompostPITMaster",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.resetForm();
              this.displayVermicompostPIT();
              this.AddPIT();
            } else if (
              (res["data"] = "VerminCompostPITMaster already exists!")
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "Already Exists The VerminCompostPITMaster",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            }
          },
          err => console.error(err)
        );
    }
  }

  toggleUpdatePITmaster(getpitmasterDataObj) {
    ////console.log(getpitmasterDataObj);
    this.updatePITmastertype = !this.updatePITmastertype;
    this.EditVermicompostPITMaster = getpitmasterDataObj;
    ////console.log(this.EditVermicompostPITMaster);
    this.displayddl = !this.editpitmastertype ? "inline" : "none";
    this.VerminCompostPITMaster.controls.modified_by.patchValue(0);
    this.VerminCompostPITMaster.setValue({
      TotalArea: this.EditVermicompostPITMaster.TotalArea,
      ConstructionType: this.EditVermicompostPITMaster.ConstructionType,
      CostPurchaseYear: this.EditVermicompostPITMaster.CostPurchaseYear,
      AgeinYears: this.EditVermicompostPITMaster.AgeinYears,
      RemainingLife: this.EditVermicompostPITMaster.RemainingLife,
      Cost: this.EditVermicompostPITMaster.Cost,
      PresentValue: this.EditVermicompostPITMaster.PresentValue,
      Width: this.EditVermicompostPITMaster.Width,
      Height: this.EditVermicompostPITMaster.Height,
      NoOfTanks: this.EditVermicompostPITMaster.NoOfTanks,
      TblPloting_ID: this.EditVermicompostPITMaster.TblPloting_ID,
      created_by: this.EditVermicompostPITMaster.created_by,
      modified_by: this.EditVermicompostPITMaster.modified_by
    });
  }
  toggleUpdateVermincompostPITmaster2() {
    this.updatePITmastertype = false;
    this.displayddl = this.editpitmastertype ? "inline" : "block";
  }

  UpdateVermincompostPIT(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    ////console.log(data);
    this.EditVermicompostPITMaster = data;
    ////console.log(this.EditVermicompostPITMaster);
    if (!this.VerminCompostPITMaster.valid) {
      Object.keys(this.VerminCompostPITMaster.controls).forEach(field => {
        const control = this.VerminCompostPITMaster.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.VerminCompostPITMaster.controls.modified_by.patchValue(0);
      this.ls
        .updateVermiCompostPITMasterById(
          this.EditVermicompostPITMaster.ID,
          this.VerminCompostPITMaster.value
        )
        .subscribe(
          res => {
            if (
              this.EditVermicompostPITMaster.TotalArea ===
              this.VerminCompostPITMaster.controls.TotalArea.value &&
              this.EditVermicompostPITMaster.ConstructionType ===
              this.VerminCompostPITMaster.controls.ConstructionType.value &&
              this.EditVermicompostPITMaster.CostPurchaseYear ===
              this.VerminCompostPITMaster.controls.CostPurchaseYear.value &&
              this.EditVermicompostPITMaster.AgeinYears ===
              this.VerminCompostPITMaster.controls.AgeinYears.value &&
              this.EditVermicompostPITMaster.RemainingLife ===
              this.VerminCompostPITMaster.controls.RemainingLife.value &&
              this.EditVermicompostPITMaster.Cost ===
              this.VerminCompostPITMaster.controls.Cost.value &&
              this.EditVermicompostPITMaster.PresentValue ===
              this.VerminCompostPITMaster.controls.PresentValue.value &&
              this.EditVermicompostPITMaster.Width ===
              this.VerminCompostPITMaster.controls.Width.value &&
              this.EditVermicompostPITMaster.Height ===
              this.VerminCompostPITMaster.controls.Height.value &&
              this.EditVermicompostPITMaster.NoOfTanks ===
              this.VerminCompostPITMaster.controls.NoOfTanks.value &&
              this.EditVermicompostPITMaster.TblPloting_ID ===
              this.VerminCompostPITMaster.controls.TblPloting_ID.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Success") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayVermicompostPIT();
              this.toggleUpdateVermincompostPITmaster2();
            }
          },

        );
    }
  }

  toggleViewPITmastertype(getpitmasterDataObj) {
    ////console.log(getpitmasterDataObj);
    this.viewVermicompostPIT = !this.viewVermicompostPIT;
    this.EditVermicompostPITMaster = getpitmasterDataObj;
    this.displayddl = !this.EditVermicompostPITMaster ? "inline" : "none";
  }

  toggleviewVermicompostPIT1() {
    this.viewVermicompostPIT = false;
    this.displayddl = !this.EditVermicompostPITMaster ? "inline" : "block";
  }

  deletePITmaster(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteVermicompostPITMasterById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayVermicompostPIT();
          }
        });
      }
    });
  }
}
