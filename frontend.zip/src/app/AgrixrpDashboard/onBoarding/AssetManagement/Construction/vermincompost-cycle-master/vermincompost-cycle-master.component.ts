import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import Swal from "sweetalert2";
import {
  takeUntil
} from "rxjs/operators";
import { MastersService } from "app/services/masters.service";
import { ReplaySubject, Subject } from "rxjs";
import { DatePipe } from "@angular/common";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { VermincompostCOP } from "../vermincompost-cop-master/vermincompostcop";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { VermicompostPITMaster } from "../vermincompost-pit-master/vermicompostpitmaster";
@Component({
  selector: "app-vermincompost-cycle-master",
  templateUrl: "./vermincompost-cycle-master.component.html",
  styleUrls: ["./vermincompost-cycle-master.component.scss"]
})
export class VermincompostCycleMasterComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "Process", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public COPmasterFilterCtrl: FormControl = new FormControl();
  public PITmasterFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCOPmaster: ReplaySubject<
    VermincompostCOP[]
  > = new ReplaySubject<VermincompostCOP[]>(1);
  public filteredPITmaster: ReplaySubject<
    VermicompostPITMaster[]
  > = new ReplaySubject<VermicompostPITMaster[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  editvermicompostcycle = true;
  displayddl: String;
  updatevermicompostcyls = false;
  vermicompostcyls = "Vermicompost Cycle";
  edittype = "add_circle";
  uservermicompostcycleData: any = [];
  Editvermicompostcyls: any = [];
  viewvermicompostcyls = false;
  submitted = false;
  EditOldData: any = [];
  vermicompostcopdata: VermincompostCOP[] = [];
  vermicompostpitdata: VermicompostPITMaster[] = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  vermicompostcyle = this.formBuilder.group(
    {
      StartDate: ["", [Validators.required]],
      EndTime: ["", [Validators.required]],
      TankNo: ["", [Validators.required, Validators.pattern("^[0-9]+$")]],
      TblVermicompostCOP_ID: ["", [Validators.required]],
      TblVERMICOMPOSTPIT_ID: ["", [Validators.required]],
      created_by: [],
      modified_by: []
    },
    { validator: this.dateLessThan("StartDate", "EndTime") }
  );

  dateLessThan(from: string, to: string) {
    return (group: FormGroup): { [key: string]: any } => {
      const f = group.controls[from];
      const t = group.controls[to];
      if (f.value > t.value) {
        return {
          dates: "EndDate should be greater than StartDate"
        };
      } else if (f.value === t.value && f.value !== null) {
        return {
          dates: "EndDate should be greater than StartDate"
        };
      }
      return {};
    };
  }

  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder,
    private dp: DatePipe
  ) { }

  ngOnInit() {
    this.displayvermicompostcyle();
    /*COP data  */
    this.ls.getVermicompostCOPData().subscribe(res => {
      this.vermicompostcopdata = res;
    });
    this.COPmasterFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCOPmaster();
      });
    /*COP end */

    /*PIT data */
    this.ls.getVermicompostPITData().subscribe(res => {
      this.vermicompostpitdata = res;
    });
    this.PITmasterFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterPITmaster();
      });
    /*PIT ends */
  }

  /*COP data*/
  protected filterCOPmaster() {
    if (!this.vermicompostcopdata) {
      return;
    }
    // get the search keyword
    let search = this.COPmasterFilterCtrl.value;


    if (!search) {
      this.filteredCOPmaster.next(this.vermicompostcopdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCOPmaster.next(
      this.vermicompostcopdata.filter(
        bank => bank.Process.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*COP data ends*/

  /*PIT data*/
  protected filterPITmaster() {
    if (!this.vermicompostpitdata) {
      return;
    }
    // get the search keyword
    let search = this.PITmasterFilterCtrl.value;

    if (!search) {
      this.filteredPITmaster.next(this.vermicompostpitdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredPITmaster.next(
      this.vermicompostpitdata.filter(
        bank => bank.ConstructionType.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*PIT data ends*/

  displayvermicompostcyle() {
    this.ls.getVermicompostcycleData().subscribe(list => {
      this.isLoading = false;
      this.uservermicompostcycleData = list;
      if (this.uservermicompostcycleData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.uservermicompostcycleData);
      /* config filter */
      this.listData.filterPredicate = (
        data: VermincompostCOP,
        filter: string
      ) => data.Process.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.vermicompostcyle.valid) {
      this.vermicompostcyle.reset();
    }
  }
  Addvermicompostcycle() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredCOPmaster.next(this.vermicompostcopdata.slice());
    this.filteredPITmaster.next(this.vermicompostpitdata.slice());
    this.vermicompostcyle.reset();
    this.vermicompostcyls =
      this.vermicompostcyls === "Vermicompost Cycle"
        ? "Add Vermicompost Cycle"
        : "Vermicompost Cycle";
    this.editvermicompostcycle = !this.editvermicompostcycle;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editvermicompostcycle ? "inline" : "none";
    this.displayvermicompostcyle();
  }

  CreateVermicompostcycle() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.submitted = true;
    if (!this.vermicompostcyle.valid) {
      Object.keys(this.vermicompostcyle.controls).forEach(field => {
        const control = this.vermicompostcyle.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.vermicompostcyle.controls.created_by.patchValue(0);
      this.ls.savevermincompostcycledata(this.vermicompostcyle.value).subscribe(
        res => {
          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the vermicompostcyle",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.vermicompostcyle.reset();
            this.displayvermicompostcyle();
            this.Addvermicompostcycle();
          } else if ((res["data"] = "serverErrorCurrencyExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The vermicompostcyle",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdatevermicompostcycle(getvermicompostcycleDataObj) {
    this.Editvermicompostcyls = getvermicompostcycleDataObj;
    this.Editvermicompostcyls.StartDate = this.dp.transform(
      this.Editvermicompostcyls.StartDate,
      "yyyy-MM-dd"
    );
    this.Editvermicompostcyls.EndTime = this.dp.transform(
      this.Editvermicompostcyls.EndTime,
      "yyyy-MM-dd"
    );
    this.updatevermicompostcyls = !this.updatevermicompostcyls;
    this.displayddl = !this.Editvermicompostcyls ? "inline" : "none";
    this.vermicompostcyle.controls.modified_by.patchValue(0);
    this.vermicompostcyle.setValue({
      StartDate: this.Editvermicompostcyls.StartDate,
      EndTime: this.Editvermicompostcyls.EndTime,
      TankNo: this.Editvermicompostcyls.TankNo,
      TblVermicompostCOP_ID: this.Editvermicompostcyls.TblVermicompostCOP_ID,
      TblVERMICOMPOSTPIT_ID: this.Editvermicompostcyls.TblVERMICOMPOSTPIT_ID,
      created_by: this.Editvermicompostcyls.created_by,
      modified_by: this.Editvermicompostcyls.modified_by
    });
  }

  UpdateVermincompostCycle(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.Editvermicompostcyls = data;
    if (!this.vermicompostcyle.valid) {
      Object.keys(this.vermicompostcyle.controls).forEach(field => {
        const control = this.vermicompostcyle.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.vermicompostcyle.controls.modified_by.patchValue(0);
      this.ls
        .updateVermiCompostCycleById(
          this.Editvermicompostcyls.ID,
          this.vermicompostcyle.value
        )
        .subscribe(
          res => {
            if (
              this.Editvermicompostcyls.StartDate ===
              this.vermicompostcyle.controls.StartDate.value &&
              this.Editvermicompostcyls.EndTime ===
              this.vermicompostcyle.controls.EndTime.value &&
              this.Editvermicompostcyls.TankNo ===
              this.vermicompostcyle.controls.TankNo.value &&
              this.Editvermicompostcyls.TblVermicompostCOP_ID ===
              this.vermicompostcyle.controls.TblVermicompostCOP_ID.value &&
              this.Editvermicompostcyls.TblVERMICOMPOSTPIT_ID ===
              this.vermicompostcyle.controls.TblVERMICOMPOSTPIT_ID.value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayvermicompostcyle();
              this.toggleUpdateVermincompostCycle2();
            }
          },

        );
    }
  }

  toggleUpdateVermincompostCycle2() {
    this.updatevermicompostcyls = false;
    this.displayddl = this.editvermicompostcycle ? "inline" : "block";
  }
  toggleViewVermicompostcycletype(getpitmasterDataObj) {
    this.viewvermicompostcyls = !this.viewvermicompostcyls;
    this.Editvermicompostcyls = getpitmasterDataObj;
    this.displayddl = !this.Editvermicompostcyls ? "inline" : "none";
  }

  toggleUpdateVermincompostCycle1() {
    this.viewvermicompostcyls = false;
    this.displayddl = !this.Editvermicompostcyls ? "inline" : "block";
  }

  deleteVermicompostCycle(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteVermicompostCycleById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayvermicompostcyle();
          }
        });
      }
    });
  }
}
