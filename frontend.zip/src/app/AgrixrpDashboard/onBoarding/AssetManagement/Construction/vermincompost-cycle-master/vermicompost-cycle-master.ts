export interface VermicompostCycle {
    ID?: number;
    StartDate?: any;
    EndTime?: any;
    TankNo?: any;
    TblVermicompostCOP_ID?: number;
    TblVERMICOMPOSTPIT_ID?: number;
    created_by: string;
    modified_by: string;
}
