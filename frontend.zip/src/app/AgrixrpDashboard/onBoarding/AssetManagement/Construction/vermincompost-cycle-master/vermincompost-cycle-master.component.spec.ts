import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VermincompostCycleMasterComponent } from './vermincompost-cycle-master.component';

describe('VermincompostCycleMasterComponent', () => {
  let component: VermincompostCycleMasterComponent;
  let fixture: ComponentFixture<VermincompostCycleMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VermincompostCycleMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VermincompostCycleMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
