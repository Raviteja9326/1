export interface VermincompostCOP {
    ID?: number;
    Process?: any;
    Period?: any;
    TankNo?: any;
    created_by: string;
    modified_by: string;
}
