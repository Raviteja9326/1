import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VermincompostCopMasterComponent } from './vermincompost-cop-master.component';

describe('VermincompostCopMasterComponent', () => {
  let component: VermincompostCopMasterComponent;
  let fixture: ComponentFixture<VermincompostCopMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VermincompostCopMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VermincompostCopMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
