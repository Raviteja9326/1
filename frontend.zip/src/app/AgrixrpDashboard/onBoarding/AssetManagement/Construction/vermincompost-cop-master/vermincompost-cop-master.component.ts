import { Component, OnInit, ViewChild } from "@angular/core";
import { VermincompostCOP } from "./vermincompostcop";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import { MastersService } from "app/services/masters.service";
import Swal from "sweetalert2";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";

@Component({
  selector: "app-vermincompost-cop-master",
  templateUrl: "./vermincompost-cop-master.component.html",
  styleUrls: ["./vermincompost-cop-master.component.scss"]
})
export class VermincompostCopMasterComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "Process", "Actions"];

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  Coptypes = "Vermicompost Calender Of Operations";
  edittype = "add_circle";
  editCOPmastertype = true;
  updateCOPmastertype = false;
  viewVermicompostCOP = false;
  displayddl: string;
  usercopmasterTypeData: any = [];
  EditVermicompostCOPMaster: any = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  VermincompostCOPmaster = this.formBuilder.group({
    Process: ["", [Validators.required]],
    Period: ["", [Validators.pattern("^[0-9]+$")]],
    TankNo: ["", [Validators.pattern("^[0-9]+$")]],
    created_by: [],
    modified_by: []
  });

  constructor(private formBuilder: FormBuilder, private ls: MastersService) { }

  ngOnInit() {
    this.displayVermicompostCOP();
  }

  displayVermicompostCOP() {
    this.ls.getVermicompostCOPData().subscribe(list => {
      this.isLoading = false;
      this.usercopmasterTypeData = list;
      if (this.usercopmasterTypeData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.usercopmasterTypeData);
      /* config filter */
      this.listData.filterPredicate = (
        data: VermincompostCOP,
        filter: string
      ) => data.Process.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.VermincompostCOPmaster.valid) {
      this.VermincompostCOPmaster.reset();
    }
  }

  AddCOP() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.VermincompostCOPmaster.reset();
    this.displayVermicompostCOP();
    this.Coptypes =
      this.Coptypes === "Vermicompost Calender Of Operations"
        ? "Add Vermicompost Calender Of Operations"
        : "Vermicompost Calender Of Operations";
    this.editCOPmastertype = !this.editCOPmastertype;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editCOPmastertype ? "inline" : "none";
  }

  CreateVermincompostCOP() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";


    if (!this.VermincompostCOPmaster.valid) {
      Object.keys(this.VermincompostCOPmaster.controls).forEach(field => {
        const control = this.VermincompostCOPmaster.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.VermincompostCOPmaster.controls.created_by.patchValue(0);
      this.ls
        .savevermincompostCOPdata(this.VermincompostCOPmaster.value)
        .subscribe(
          res => {
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully added the Vermicompost COP",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.resetForm();
              this.displayVermicompostCOP();
              this.AddCOP();
            } else if ((res["data"] = "Vermicompost COP already exists!")) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "Already Exists The Vermicompost COP",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            }
          },
          err => console.error(err)
        );
    }
  }

  toggleUpdatecopmaster(getcopmasterDataObj) {
    this.updateCOPmastertype = !this.updateCOPmastertype;
    this.EditVermicompostCOPMaster = getcopmasterDataObj;
    this.displayddl = !this.editCOPmastertype ? "inline" : "none";
    this.VermincompostCOPmaster.controls.modified_by.patchValue(0);
    this.VermincompostCOPmaster.setValue({
      Process: this.EditVermicompostCOPMaster.Process,
      Period: this.EditVermicompostCOPMaster.Period,
      TankNo: this.EditVermicompostCOPMaster.TankNo,
      created_by: this.EditVermicompostCOPMaster.created_by,
      modified_by: this.EditVermicompostCOPMaster.modified_by
    });
  }

  toggleUpdateVermincompostCOPmaster2() {
    this.updateCOPmastertype = false;
    this.displayddl = this.editCOPmastertype ? "inline" : "block";
  }

  UpdateVermincompostCOP(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.EditVermicompostCOPMaster = data;
    if (!this.VermincompostCOPmaster.valid) {
      Object.keys(this.VermincompostCOPmaster.controls).forEach(field => {
        const control = this.VermincompostCOPmaster.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.VermincompostCOPmaster.controls.modified_by.patchValue(0);
      this.ls
        .updateVermiCompostCOPMasterById(
          this.EditVermicompostCOPMaster.ID,
          this.VermincompostCOPmaster.value
        )
        .subscribe(
          res => {
            if (
              this.EditVermicompostCOPMaster.Process ===
              this.VermincompostCOPmaster.controls.Process.value &&
              this.EditVermicompostCOPMaster.Period ===
              this.VermincompostCOPmaster.controls.Period.value &&
              this.EditVermicompostCOPMaster.TankNo ===
              this.VermincompostCOPmaster.controls.TankNo.value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayVermicompostCOP();
              this.toggleUpdateVermincompostCOPmaster2();
            }
          },

        );
    }
  }

  deletecopmaster(id: string) {


    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteVermicompostCOPMasterById(id).subscribe(res => {
          if ((res["data"] = "success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayVermicompostCOP();
          }
        });
      }
    });
  }

  toggleViewCOPmastertype(getcopmasterDataObj) {
    this.viewVermicompostCOP = !this.viewVermicompostCOP;
    this.EditVermicompostCOPMaster = getcopmasterDataObj;
    this.displayddl = !this.EditVermicompostCOPMaster ? "inline" : "none";
  }
  toggleviewVermicompostCOP1() {
    this.viewVermicompostCOP = false;
    this.displayddl = !this.EditVermicompostCOPMaster ? "inline" : "block";
  }
}
