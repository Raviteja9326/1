export interface Shed {
    ID:number,
    Name?:string,
    BuiltType?: string,
    Material?: string,
    UsePurpose?: string,
    Flooring?: string,
    Capacity?: number,
    SunLight?: string,
    ProtectionfromWind?: string,
    Drinage?: string,
    Electricity?: string,
    Cost?: any,
    Width?: any,
    Lenght?: any,
    WallTye?: string,
    TblPloting_TblplotID?: number,
    TblPloting_TblLand_ID?: number
}


