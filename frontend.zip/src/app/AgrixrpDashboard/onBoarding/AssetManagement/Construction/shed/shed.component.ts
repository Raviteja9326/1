import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { Validators, FormBuilder } from "@angular/forms";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { Shed } from "app/services/Dataservices";
import Swal from "sweetalert2";
import { MastersService } from "app/services/masters.service";

@Component({
  selector: "app-shed",
  templateUrl: "./shed.component.html",
  styleUrls: ["./shed.component.scss"]
})
export class ShedComponent implements OnInit {
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "TblPloting_TblLand_ID",
    "TblPloting_TblplotID",
    "Name",
    "BuiltType",
    "Material",
    "UsePurpose",
    "Flooring",
    "Capacity",
    "SunLight",
    "ProtectionfromWind",
    "Drinage",
    "Electricity",
    "Cost",
    "Width",
    "WallTye",
    "Actions"
  ];
  editLand = true;
  editLandContent = "add_circle";
  LandNames = "Shed List";
  userLandData: any = [];
  displayddl: string;
  updateLand = false;
  viewLand = false;
  editfarm: any = [];
  userSoilTypeData: any = [];
  EditLandlay: any = [];
  EditOldLand: any = [];
  editViewLand: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  landSelect = ["Yes", "No"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  LandForm = this.formBuilder.group({
    TblPloting_TblLand_ID: ["", [Validators.required]],
    TblPloting_TblplotID: ["", [Validators.required]],
    Name: ["", [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
    BuiltType: ["", [Validators.pattern("^[a-zA-Z]+$")]],
    Material: ["", [Validators.pattern("^[a-zA-Z]+$")]],
    UsePurpose: ["", [Validators.pattern("^[a-zA-Z]+$")]],
    Flooring: [""],
    Capacity: [""],
    SunLight: [""],
    ProtectionfromWind: [""],
    Drinage: [""],
    Electricity: [""],
    Cost: [""],
    Lenght: [""],
    Width: [""],
    WallTye: ["", [Validators.pattern("^[a-zA-Z]+$")]]
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  plotByLand: any[];
  cropByplot: any[];
  constructor(
    private formBuilder: FormBuilder,
    private ds: MastersService
  ) { }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }

  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.LandForm.valid) {
      this.LandForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    this.displayLand();
    this.ds.getlandlayoutData().subscribe(res => {
      this.editfarm = res;
    });
  }

  displayLand() {
    this.ds.getShedData().subscribe(
      list => {
        this.isLoading = false;
        this.userLandData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userLandData);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Shed, filter: string) =>
          data.Name.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  toggleEditLand() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.displayLand();
    this.LandForm.reset();
    this.LandNames = this.LandNames === "Add Shed" ? "Shed List" : "Add Shed";
    this.editLandContent =
      this.editLandContent === "cancel" ? "add_circle" : "cancel";
    this.editLand = !this.editLand;
    this.displayddl = this.editLand ? "inline" : "none";
  }

  toggleUpdateLand(getLandDataObj) {
    this.EditLandlay = getLandDataObj;
    this.updateLand = !this.updateLand;
    this.displayddl = !this.editLand ? "inline" : "none";
    this.LandForm.setValue({
      Name: this.EditLandlay.Name,
      BuiltType: this.EditLandlay.BuiltType,
      Material: this.EditLandlay.Material,
      UsePurpose: this.EditLandlay.UsePurpose,
      Flooring: this.EditLandlay.Flooring,
      Capacity: this.EditLandlay.Capacity,
      SunLight: this.EditLandlay.SunLight,
      ProtectionfromWind: this.EditLandlay.ProtectionfromWind,
      Drinage: this.EditLandlay.Drinage,
      Electricity: this.EditLandlay.Electricity,
      Cost: this.EditLandlay.Cost,
      Width: this.EditLandlay.Width,
      Lenght: this.EditLandlay.Lenght,
      WallTye: this.EditLandlay.WallTye,
      TblPloting_TblplotID: this.EditLandlay.TblPloting_TblplotID,
      TblPloting_TblLand_ID: this.EditLandlay.TblPloting_TblLand_ID
    });
  }

  toggleUpdateLand2() {
    this.updateLand = false;
    this.displayddl = this.editLand ? "inline" : "block";
  }

  toggleViewLand(getLandDataObj) {
    this.editViewLand = getLandDataObj;
    this.viewLand = !this.viewLand;
    this.displayddl = !this.editLand ? "inline" : "none";
  }

  toggleViewLand2() {
    this.viewLand = false;
    this.displayddl = !this.editLand ? "inline" : "block";
  }

  resetdrop() {
    this.plotByLand = [];
  }
  onChangeLand(ID: string) {
    if (ID) {
      this.ds.getplottingDataByLand(ID).subscribe(res => {
        if (res["data"] === "NO plotting Available with this Land ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "NO plotting Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.plotByLand = [];
          this.resetdrop();
          this.LandForm.controls.TblPloting_TblplotID.patchValue("");
        } else {
          Swal.fire({
            position: "center",
            type: "info",
            title: "Please Select The plotting",
            showConfirmButton: false,
            timer: 1000
          });
          this.LandForm.controls.TblPloting_TblplotID.patchValue("");
          this.plotByLand = res;
          this.cropByplot = [];
        }
      });
    }
  }

  createLand() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.LandForm.valid) {
      Object.keys(this.LandForm.controls).forEach(field => {
        const control = this.LandForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ds.saveShedData(this.LandForm.value).subscribe(
        res => {
          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Loan",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayLand();
            this.toggleEditLand();
          }
        },
        err => console.error(err)
      );
    }
  }

  deleteLand(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ds.deleteshedById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayLand();
          }
        });
      }
    });
  }

  updateLandLayout(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.EditLandlay = data;
    if (!this.LandForm.valid) {
      Object.keys(this.LandForm.controls).forEach(field => {
        const control = this.LandForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ds
        .updateShedDataById(this.EditLandlay.ID, this.LandForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayLand();
              this.toggleUpdateLand2();
            }
          },

        );
    }
  }
}
