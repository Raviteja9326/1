import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssetmanagementComponent } from './assetmanagement.component';
import { VermincompostCopMasterComponent } from './Construction/vermincompost-cop-master/vermincompost-cop-master.component';
import { VermincompostCycleMasterComponent } from './Construction/vermincompost-cycle-master/vermincompost-cycle-master.component';
import { VermincompostPitMasterComponent } from './Construction/vermincompost-pit-master/vermincompost-pit-master.component';
import { ShedComponent } from './Construction/shed/shed.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
const routes: Routes = [{
    path: '',
    component: AssetmanagementComponent,
    children: [{
        path: 'VermiCompost COP Master',
        component: VermincompostCopMasterComponent, canActivate: [AuthGuardService]
    }, {
        path: 'VermiCompost Cycle',
        component: VermincompostCycleMasterComponent, canActivate: [AuthGuardService]
    }, {
        path: 'VermiCompost Master',
        component: VermincompostPitMasterComponent, canActivate: [AuthGuardService]

    }, {
        path: 'Shed',
        component: ShedComponent, canActivate: [AuthGuardService]
    }],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AssetmanagementRoutingModule { }
