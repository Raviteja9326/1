import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NgxMatSelectSearchModule } from "../../maincomponents/mat-select-search/ngx-mat-select-search.module";
import { AssetmanagementRoutingModule } from "./assetmanagement-routing.module";
import { AssetmanagementComponent } from "./assetmanagement.component";
import { VermincompostCopMasterComponent } from "./Construction/vermincompost-cop-master/vermincompost-cop-master.component";
import { VermincompostCycleMasterComponent } from "./Construction/vermincompost-cycle-master/vermincompost-cycle-master.component";
import { VermincompostPitMasterComponent } from "./Construction/vermincompost-pit-master/vermincompost-pit-master.component";
import { ShedComponent } from "./Construction/shed/shed.component";
import { SharedModule } from 'app/AgrixrpDashboard/maincomponents/shared.module';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
// tslint:disable-next-line:max-line-length
const components = [
  AssetmanagementComponent,
  VermincompostCopMasterComponent,
  VermincompostCycleMasterComponent,
  VermincompostPitMasterComponent,
  ShedComponent
];

@NgModule({
  // tslint:disable-next-line:max-line-length
  imports: [
    SharedModule,
    AssetmanagementRoutingModule,
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MaterialModule,
    NgxMatSelectSearchModule
  ],
  declarations: [...components]
})
export class AssetmanagementModule { }
