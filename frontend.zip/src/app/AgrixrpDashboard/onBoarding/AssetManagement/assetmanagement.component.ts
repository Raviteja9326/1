import { Component } from '@angular/core';

@Component({
  selector: 'app-Assetmanagement',
  template: `<router-outlet></router-outlet>`,
})

export class AssetmanagementComponent {
}