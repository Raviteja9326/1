import { Component } from '@angular/core';

@Component({
  selector: 'app-soildata',
  template: `<router-outlet></router-outlet>`,
})

export class SoildataComponent {
}
