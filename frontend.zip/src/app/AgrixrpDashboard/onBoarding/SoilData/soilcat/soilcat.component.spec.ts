import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoilcatComponent } from './soilcat.component';

describe('SoilcatComponent', () => {
  let component: SoilcatComponent;
  let fixture: ComponentFixture<SoilcatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoilcatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoilcatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
