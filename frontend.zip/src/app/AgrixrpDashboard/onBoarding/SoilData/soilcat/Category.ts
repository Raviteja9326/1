export interface Category {
    ID?: number;
    SoilCatType?: string;
    SoilCatSource?: string;
    created_by: string;
    modified_by: string;

}