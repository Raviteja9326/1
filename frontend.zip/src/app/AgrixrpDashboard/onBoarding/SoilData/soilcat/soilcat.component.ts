import { Component, OnInit, ViewChild } from '@angular/core';
import Swal from 'sweetalert2';
import { Category } from './Category';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort, MatSelect } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
@Component({
  selector: 'app-soilcat',
  templateUrl: './soilcat.component.html',
  styleUrls: ['./soilcat.component.scss']
})
export class SoilcatComponent implements OnInit {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['ID', 'SoilCatType', 'Actions'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;





  editSoilCat = true;
  soilcategory: any[];
  editSoilCategory = "add_circle";
  soilCategorytype = "Soil Category";
  displayddl: string;
  updateSoilCat = false;
  EditCat: any = [];
  viewSoilCat = false;
  userSoilCatData: any = [];
  EditOldData: any = [];
  getsoilData: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }


  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  SoilCatvalidation = this.formBuilder.group({
    SoilCatType: ['', [Validators.required]],
    SoilCatSource: ['', [Validators.required]],
    created_by: [],
    modified_by: []
  })

  ngOnInit() {
    this.dispalySoilCat();
    this.ls.getSoilTypeData().subscribe(res => {
      this.getsoilData = res;
    })
  }
  dispalySoilCat() {
    this.ls.getSoilCatData().subscribe(
      list => {
        this.isLoading = false;
        this.userSoilCatData = list;
        if (this.userSoilCatData.length == 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userSoilCatData);
        /* config filter */
        this.listData.filterPredicate =
          (data: Category, filter: string) => data.SoilCatType.toLowerCase().indexOf(filter) != -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
    );

  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length == 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  Addcategory() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.SoilCatvalidation.reset();
    this.editSoilCategory =
      this.editSoilCategory === "cancel" ? "add_circle" : "cancel";
    this.editSoilCat = !this.editSoilCat;
    this.soilCategorytype =
      this.soilCategorytype === "Soil Category" ? "Add Soil Category" : "Soil Category";
    this.displayddl = this.editSoilCat ? "inline" : "none";
    this.dispalySoilCat();
  }

  resetForm() {
    if (this.SoilCatvalidation.valid) {
      this.SoilCatvalidation.reset();
    }
  }


  CreateSoilCat(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.SoilCatvalidation.valid) {
      Object.keys(this.SoilCatvalidation.controls).forEach(field => {
        const control = this.SoilCatvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
    else {
      this.SoilCatvalidation.controls.created_by.patchValue(0);
      this.ls.saveSoilCatType(this.SoilCatvalidation.value).subscribe(
        res => {

          if (res['data'] == "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Soil Category',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.resetForm();
            this.dispalySoilCat();
            this.Addcategory();
          }
          else if (res['data'] = "serverErrorStateExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The SoilCategory Name',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }
  }

  toggleUpdateSoilCat(getSoilCatDataObj) {
    this.EditCat = getSoilCatDataObj;
    this.updateSoilCat = !this.updateSoilCat;
    this.displayddl = !this.editSoilCat ? "inline" : "none";
    this.SoilCatvalidation.controls.modified_by.patchValue(0);
    this.SoilCatvalidation.setValue({
      SoilCatType: this.EditCat.SoilCatType,
      SoilCatSource: this.EditCat.SoilCatSource,
      created_by: this.EditCat.created_by,
      modified_by: this.EditCat.modified_by
    });
  }

  toggleUpdateSoilCat2() {
    this.updateSoilCat = false;
    this.displayddl = this.editSoilCat ? "inline" : "block";
  }

  updateSoilCategory(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.SoilCatvalidation.valid) {
      Object.keys(this.SoilCatvalidation.controls).forEach(field => {
        const control = this.SoilCatvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
    else {
      this.SoilCatvalidation.controls.modified_by.patchValue(0);
      this.ls.updateSoilCatById(this.EditCat.ID, this.SoilCatvalidation.value).subscribe(res => {
        if (this.EditCat.SoilCatType == this.SoilCatvalidation.controls.SoilCatType.value &&
          this.EditCat.SoilCatSource == this.SoilCatvalidation.controls.SoilCatSource.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        }

        else if (res['data'] == "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.dispalySoilCat();
          this.toggleUpdateSoilCat2();
        }

      },

      )
    }
  }

  toggleViewSoilCat(getSoilCatDataObj) {
    this.EditCat = getSoilCatDataObj;
    this.viewSoilCat = !this.viewSoilCat;
    this.displayddl = !this.editSoilCat ? "inline" : "none";

  }

  toggleViewSoilcat1() {
    this.viewSoilCat = false;
    this.displayddl = this.editSoilCat ? "inline" : "block";
  }

  deleteSoilCategory(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {
        this.ls.deleteSoilCatById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.dispalySoilCat();
            }
          }
        )
      }
    })
  }

}
