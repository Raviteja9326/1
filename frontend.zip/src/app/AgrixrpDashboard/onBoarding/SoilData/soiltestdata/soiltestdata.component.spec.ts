import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoiltestdataComponent } from './soiltestdata.component';

describe('SoiltestdataComponent', () => {
  let component: SoiltestdataComponent;
  let fixture: ComponentFixture<SoiltestdataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoiltestdataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoiltestdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
