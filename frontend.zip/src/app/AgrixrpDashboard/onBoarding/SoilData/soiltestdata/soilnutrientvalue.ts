export interface Nutrientvalue {
	ID?: number;
	count?: any;
	TblSoilTestData_ID?: any;
	TblSoilNutrient_ID?: any;
	created_by: any;
	modified_by: any;
}
