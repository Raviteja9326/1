import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator, MatStepper } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { Validators, FormBuilder, FormGroup, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { ReplaySubject, Subject } from 'rxjs';
import { Farmer } from 'app/AgrixrpDashboard/onBoarding/FarmerData/farmerinfo/farmerinfo';
import { takeUntil } from 'rxjs/operators';
import { MastersService } from 'app/services/masters.service';
import { supplychain } from 'app/services/supplychain';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import { Landlayout } from '../../FarmerData/landlayout/landlayout';

export interface Nutrientvalue {
	ID?: number;
	count?: any;
	TblSoilTestData_ID?: any;
	TblSoilNutrient_ID?: any;
}

export interface Soiltestinfo {
	ID?: number;
	TestAgentID?: any;
	SampleNumber?: any;
	SampleReceivedDate?: any;
	TestCompletedDate?: any;
	SampleQuantity?: any;
	SamplePackaging?: any;
	VerifiedBy?: any;
	Nutrientlists?: any;
	Remarks?: any;
	TblFarmer_ID?: number;
	TblPloting_TblLand_ID?: number;
	created_by: any;
	modified_by: any;
}

@Component({
	selector: 'app-soiltestdata',
	templateUrl: './soiltestdata.component.html',
	styleUrls: ['./soiltestdata.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class SoiltestdataComponent implements OnInit {
	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['ID', 'FarmerName', 'LandName', 'Actions'];

	/*for nutrient list data */
	NutrientlistData: MatTableDataSource<any>;
	displayedColumns1: string[] = ['S.No', 'Nutrient', 'count'];

	/*for nutrient list data */
	NutrientlistData1: MatTableDataSource<any>;
	displayedColumns3: string[] = ['S.No', 'Nutrient', 'count'];

	/*for nutrient view data */
	NutrientData: MatTableDataSource<any>;
	displayedColumns2: string[] = ['NutrientList', 'count1'];

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;

	/** control for the MatSelect filter keyword */
	public FarmerFilterCtrl: FormControl = new FormControl();
	public LandFilterCtrl: FormControl = new FormControl();

	/** list of banks filtered by search keyword */
	public filteredFarmer: ReplaySubject<Farmer[]> = new ReplaySubject<Farmer[]>(1);
	public filteredland: ReplaySubject<Landlayout[]> = new ReplaySubject<Landlayout[]>(1);

	protected _onDestroy = new Subject<void>();

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	soiltestdata = 'SoilTest Data';
	edittype = 'add_circle';
	displayddl: string;
	editSoiltestdata = true;
	updateSoiltestdata = false;
	isLoading = true;
	displayNoRecords = false;
	FarmerData: Farmer[] = [];
	LandData: Landlayout[] = [];
	userNutrientData: any;
	Nutrientlists: FormArray;
	isLinear = false;
	usertestdata: any[];
	secretKey: string;
	Editsoiltestdata: any = [];
	viewSoiltestdata = false;
	listofnutrients: any;
	updatenutrinets: AbstractControl;
	empty = [];

	get formArray(): AbstractControl | null {
		return this.SoilTestData.get('formArray');
	}

	SoilTestData = this._formBuilder.group({
		TestAgentID: ['', [Validators.required]],
		SampleNumber: ['', [Validators.pattern('^[0-9]+$')]],
		SampleReceivedDate: [''],
		TestCompletedDate: [''],
		SampleQuantity: ['', [Validators.pattern('^[0-9]+$')]],
		SamplePackaging: [''],
		VerifiedBy: [''],
		TblFarmer_ID: ['', [Validators.required]],
		TblPloting_TblLand_ID: ['', [Validators.required]],
		Remarks: [''],
		Nutrientlists: this._formBuilder.array([this.getNutrientlists()]),
		created_by: [],
		modified_by: []
	});

	constructor(
		private _formBuilder: FormBuilder,
		private fs: MastersService,
		private ls: supplychain,
		private dp: DatePipe
	) { }

	AddSoilTestData() {
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
		this.filteredFarmer.next(this.FarmerData.slice());
		this.filteredland.next(this.LandData.slice());
		this.SoilTestData.reset();
		this.soiltestdata = this.soiltestdata === 'SoilTestData List' ? 'Add SoilTestData' : 'SoilTestData List';
		this.editSoiltestdata = !this.editSoiltestdata;
		this.getSoilTestDataDetails();
		this.edittype = this.edittype === 'cancel' ? 'add_circle' : 'cancel';
		this.displayddl = this.editSoiltestdata ? 'inline' : 'none';
	}
	ngOnInit() {
		this.getSoilTestDataDetails();
		// for farmer
		this.fs.getFarmerdata().subscribe((res) => {
			this.FarmerData = res;
			//console.log(this.FarmerData);
		});

		// this.dispalyNutrientData();

		// listen for search field value changes
		this.FarmerFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterFarmer();
		});
		// farmer end

		// for land
		this.fs.getlandlayoutData().subscribe((res) => {
			this.LandData = res;
			//console.log(this.LandData);
		});

		// listen for search field value changes
		this.LandFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterLand();
		});
		// land end
	}

	/*farmer data */
	protected filterFarmer() {
		//console.log('farmer', this.FarmerData);
		if (!this.FarmerData) {
			return;
		}
		// get the search keyword
		let search = this.FarmerFilterCtrl.value;
		//console.log(this.FarmerFilterCtrl.value);
		if (!search) {
			this.filteredFarmer.next(this.FarmerData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredFarmer.next(this.FarmerData.filter((bank) => bank.FarmerName.toLowerCase().indexOf(search) > -1));
	}
	/*farmer data ends*/

	/*land data */
	protected filterLand() {
		//console.log('land', this.LandData);
		if (!this.LandData) {
			return;
		}
		// get the search keyword
		let search = this.LandFilterCtrl.value;
		//console.log(this.LandFilterCtrl.value);
		if (!search) {
			this.filteredland.next(this.LandData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredland.next(this.LandData.filter((bank) => bank.LandName.toLowerCase().indexOf(search) > -1));
	}
	/*land data ends*/

	private getNutrientlists(): FormGroup {
		return this._formBuilder.group({
			TblSoilNutrient_ID: [''],
			SoilNutrientName: [''],
			SoilNutrientChemicalsymbol: [''],
			count: ['']
		});
	}

	getSoilTestDataDetails() {
		this.ls.getSoilTestData().subscribe((res) => {
			this.isLoading = false;
			this.usertestdata = res;
			//console.log(this.usertestdata);
			this.listData = new MatTableDataSource(this.usertestdata);
			/* config filter */
			this.listData.filterPredicate = (data: Farmer, filter: string) =>
				data.FarmerName.toLowerCase().indexOf(filter) !== -1 ||
				data.SurName.toLowerCase().indexOf(filter) !== -1;
			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	resetForm() {
		if (this.SoilTestData.valid) {
			//console.log('Form Submitted');
			this.SoilTestData.reset();
		}
	}

	nutrients(stepper: MatStepper) {
		if (!this.SoilTestData.valid) {
			Object.keys(this.SoilTestData.controls).forEach((field) => {
				const control = this.SoilTestData.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
		} else {
			this.dispalyNutrientData();
			stepper.next();
		}
	}

	dispalyNutrientData() {
		this.ls.getSoilNutData().subscribe((list) => {
			this.userNutrientData = list;
			//console.log(this.userNutrientData, 'disp;ay data');
			let SoilTestDataArray = [];
			for (let i = 0; i < this.userNutrientData.length; i++) {
				SoilTestDataArray.push({
					TblSoilNutrient_ID: this.userNutrientData[i].ID,
					SoilNutrientName: this.userNutrientData[i].SoilNutrientName,
					SoilNutrientChemicalsymbol: this.userNutrientData[i].SoilNutrientChemicalsymbol,
					count: ''
				});
			}
			this.Nutrientlists = this.SoilTestData.get('Nutrientlists') as FormArray;
			for (let j = 1; j < SoilTestDataArray.length; j++) {
				this.Nutrientlists.push(this.getNutrientlists());
			}
			this.SoilTestData.patchValue({ Nutrientlists: SoilTestDataArray });
			this.NutrientlistData = new MatTableDataSource(SoilTestDataArray);
		});
	}

	CreateSoilTypeData() {
		//console.log(this.SoilTestData.value);
		if (!this.SoilTestData.valid) {
			Object.keys(this.SoilTestData.controls).forEach((field) => {
				const control = this.SoilTestData.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
		} else {
			this.SoilTestData.controls.created_by.patchValue(1);
			this.SoilTestData.value.SampleReceivedDate = this.dp.transform(
				this.SoilTestData.value.SampleReceivedDate,
				'yyyy-MM-dd'
			);
			this.SoilTestData.value.TestCompletedDate = this.dp.transform(
				this.SoilTestData.value.TestCompletedDate,
				'yyyy-MM-dd'
			);
			this.ls.saveSoilTestData(this.SoilTestData.value).subscribe(
				(res) => {
					//console.log(res, 'add');
					if (res['data'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added the SoilTestData',
							showConfirmButton: false,
							timer: 1500
						});
						this.SoilTestData.reset();
						this.Nutrientlists.clear();
						this.getSoilTestDataDetails();
						this.AddSoilTestData();
					}
					//  else if ((res['data'] = 'SoilTestData already exists!')) {
					// 	Swal.fire({
					// 		position: 'center',
					// 		type: 'info',
					// 		title: 'Already Exists The SoilTestData',
					// 		showConfirmButton: false,
					// 		timer: 1500
					// 	});
					// }
				},
				(err) => console.error(err)
			);
		}
	}

	toggleViewSoiltestdata(id: string) {
		//console.log(id);
		this.ls.getSoilTestDataByID(id).subscribe((res) => {
			this.Editsoiltestdata = res;
			this.listofnutrients = this.Editsoiltestdata.object.result;
			//console.log('nutreintlistdata', this.listofnutrients);
			this.NutrientData = new MatTableDataSource(this.listofnutrients);
		});
		this.viewSoiltestdata = !this.viewSoiltestdata;
		this.displayddl = !this.editSoiltestdata ? 'inline' : 'none';
	}

	toggleViewSoiltestdata1() {
		this.displayNoRecords = false;
		this.viewSoiltestdata = false;
		this.displayddl = !this.editSoiltestdata ? 'inline' : 'block';
	}

	deleteSoiltestdata(id: string) {
		//console.log(id);
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteSoilTestdataById(id).subscribe((res) => {
					if ((res['data'] = 'success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.getSoilTestDataDetails();
					}
				});
			}
		});
	}

	toggleUpdateSoiltestdata(id: string) {
		this.ls.getSoilTestDataByID(id).subscribe((res) => {
			this.Editsoiltestdata = res;
			this.SoilTestData.controls.modified_by.patchValue(1);
			this.Nutrientlists = this.SoilTestData.get('Nutrientlists') as FormArray;
			this.Nutrientlists.clear();
			for (let j = 0; j < this.Editsoiltestdata.object.result.length; j++) {
				//console.log('when ', this.Editsoiltestdata.object.result.length);
				this.Nutrientlists.push(this.getNutrientlists());
			}
			this.Editsoiltestdata.SampleReceivedDate = this.dp.transform(
				this.Editsoiltestdata.SampleReceivedDate,
				'yyyy-MM-dd'
			);
			this.Editsoiltestdata.TestCompletedDate = this.dp.transform(
				this.Editsoiltestdata.TestCompletedDate,
				'yyyy-MM-dd'
			);

			this.SoilTestData.patchValue({
				TestAgentID: this.Editsoiltestdata.object.TestAgentID,
				SampleNumber: this.Editsoiltestdata.object.SampleNumber,
				SampleReceivedDate: this.Editsoiltestdata.object.SampleReceivedDate,
				TestCompletedDate: this.Editsoiltestdata.object.TestCompletedDate,
				SampleQuantity: this.Editsoiltestdata.object.SampleQuantity,
				SamplePackaging: this.Editsoiltestdata.object.SamplePackaging,
				VerifiedBy: this.Editsoiltestdata.object.VerifiedBy,
				TblFarmer_ID: this.Editsoiltestdata.object.TblFarmer_ID,
				TblPloting_TblLand_ID: this.Editsoiltestdata.object.TblPloting_TblLand_ID,
				Remarks: this.Editsoiltestdata.object.Remarks,
				Nutrientlists: this.Editsoiltestdata.object.result,
				created_by: this.Editsoiltestdata.object.created_by,
				modified_by: this.Editsoiltestdata.modified_by
			});
			this.NutrientlistData1 = new MatTableDataSource(this.SoilTestData.get('Nutrientlists').value);
			//console.log('true', this.NutrientlistData1);
		});
		this.updateSoiltestdata = !this.updateSoiltestdata;
		this.displayddl = !this.editSoiltestdata ? 'inline' : 'none';
	}

	toggleUpdateSoilTestData2() {
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
		this.updateSoiltestdata = false;
		this.displayddl = this.editSoiltestdata ? 'inline' : 'block';
	}

	updateSoilTestData(Data) {
		//console.log('incoming updated data', Data);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.SoilTestData.valid) {
			Object.keys(this.SoilTestData.controls).forEach((field) => {
				const control = this.SoilTestData.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.SoilTestData.controls.modified_by.patchValue(1);
			this.SoilTestData.value.SampleReceivedDate = this.dp.transform(
				this.SoilTestData.value.SampleReceivedDate,
				'yyyy-MM-dd'
			);
			this.SoilTestData.value.TestCompletedDate = this.dp.transform(
				this.SoilTestData.value.TestCompletedDate,
				'yyyy-MM-dd'
			);
			this.ls.updateSoilTestDataById(this.Editsoiltestdata.object.ID, this.SoilTestData.value).subscribe(
				(res) => {
					if (
						this.Editsoiltestdata.object.TestAgentID === this.SoilTestData.controls.TestAgentID.value &&
						this.Editsoiltestdata.object.SampleNumber === this.SoilTestData.controls.SampleNumber.value &&
						this.Editsoiltestdata.object.SampleReceivedDate ===
						this.SoilTestData.controls.SampleReceivedDate.value &&
						this.Editsoiltestdata.object.TestCompletedDate ===
						this.SoilTestData.controls.TestCompletedDate.value &&
						this.Editsoiltestdata.object.SampleQuantity ===
						this.SoilTestData.controls.SampleQuantity.value &&
						this.Editsoiltestdata.object.SamplePackaging ===
						this.SoilTestData.controls.SamplePackaging.value &&
						this.Editsoiltestdata.object.VerifiedBy === this.SoilTestData.controls.VerifiedBy.value &&
						this.Editsoiltestdata.object.TblFarmer_ID === this.SoilTestData.controls.TblFarmer_ID.value &&
						this.Editsoiltestdata.object.TblPloting_TblLand_ID ===
						this.SoilTestData.controls.TblPloting_TblLand_ID.value &&
						this.Editsoiltestdata.object.Remarks === this.SoilTestData.controls.Remarks.value &&
						this.Editsoiltestdata.object.Nutrientlists === this.SoilTestData.controls.Nutrientlists.value
					) {
						// this.Editsoiltestdata.object.Nutrientlists === this.SoilTestData.controls.Nutrientlists.value
						//console.log('no update');
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['data'] === 'Success') {
						//console.log('update');
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Edited',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.getSoilTestDataDetails();
						this.toggleUpdateSoilTestData2();
					}
				},
				(err) => console.log(err)
			);
		}
	}
}
