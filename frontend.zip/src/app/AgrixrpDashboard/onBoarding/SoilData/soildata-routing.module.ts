import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SoildataComponent } from './soildata.component';
import { SoiltypeComponent } from './soiltype/soiltype.component';
import { SoilcatComponent } from './soilcat/soilcat.component';
import { SoilnutrientsComponent } from './soilnutrients/soilnutrients.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
import { SoiltestdataComponent } from './soiltestdata/soiltestdata.component';
import { SoiltestcorrectionsComponent } from './soiltestcorrections/soiltestcorrections.component';

const routes: Routes = [{
    path: '',
    component: SoildataComponent,
    children: [{
        path: 'Soil Type',
        component: SoiltypeComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Soil Category',
        component: SoilcatComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Soil Nutrients',
        component: SoilnutrientsComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Soil Test Data',
        component: SoiltestdataComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Soil Test Corrections',
        component: SoiltestcorrectionsComponent, canActivate: [AuthGuardService]
    },

    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class SoildataRoutingModule { }
