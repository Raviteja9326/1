import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator, MatDialog } from '@angular/material';
import { Farmer } from 'app/AgrixrpDashboard/onBoarding/FarmerData/farmerinfo/farmerinfo';
import { AbstractControl, FormArray, FormBuilder, Validators } from '@angular/forms';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import Swal from 'sweetalert2';
import { DialogBoxComponent } from '../dialog-box/dialog-box.component';
import { supplychain } from 'app/services/supplychain';
import { Landlayout } from '../../FarmerData/landlayout/landlayout';

export interface SoilCorrectionvalue {
	ID?: number;
	SoilConsultentName?: any;
	ActionItems?: any;
	TblSoilTestData_ID?: any;
	created_by: any;
	modified_by: any;
}

@Component({
	selector: 'app-soiltestcorrections',
	templateUrl: './soiltestcorrections.component.html',
	styleUrls: ['./soiltestcorrections.component.scss']
})
export class SoiltestcorrectionsComponent implements OnInit {
	soiltestdata = 'SoilCorrections List';
	edittype = 'add_circle';
	displayddl: string;
	editSoiltestdata = true;
	updateSoiltestdata = false;
	isLoading = true;
	displayNoRecords = false;
	FarmerData: Farmer[] = [];
	LandData: Landlayout[] = [];
	userNutrientData: any;
	Nutrientlists: FormArray;
	isLinear = false;
	usertestdata: any[];
	secretKey: string;
	Editsoiltestdata: any = [];
	viewSoiltestdata = false;
	listofnutrients: any;
	updatenutrinets: AbstractControl;
	empty = [];
	editing = true;

	SoilCorrectiveActions = this.formbuilder.group({
		SoilConsultentName: ['', [Validators.required]],
		ActionItems: ['', [Validators.required]],
		TblSoilTestData_ID: [''],
		created_by: [],
		modified_by: []
	});

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['ID', 'FarmerName', 'LandName', 'Actions'];

	/*for nutrient view data */
	NutrientData: MatTableDataSource<any>;
	displayedColumns2: string[] = ['NutrientList', 'count1'];

	/*for nutrient view data */
	soiltestdatabyid: MatTableDataSource<any>;
	displayedColumns3: string[] = ['ConsultentName', 'ActionItems', 'Action'];

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;
	soildata: any[];
	Editdata: any;
	Inputtoupdate: any;
	Outputtoupdate: any;

	constructor(private ls: supplychain, private formbuilder: FormBuilder, public dialog: MatDialog) { }

	AddSoilTestData() {
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
		//this.filteredFarmer.next(this.FarmerData.slice());
		//this.filteredland.next(this.LandData.slice());
		this.SoilCorrectiveActions.reset();
		this.soiltestdata = this.soiltestdata === 'SoilCorrections List' ? 'Add SoilCorrecitveActions' : 'SoilCorrections';
		this.editSoiltestdata = !this.editSoiltestdata;
		this.getSoilTestDataDetails();
		this.edittype = this.edittype === 'cancel' ? 'add_circle' : 'cancel';
		this.displayddl = this.editSoiltestdata ? 'inline' : 'none';
	}

	ngOnInit() {
		this.getSoilTestDataDetails();
	}

	getSoilTestDataDetails() {
		this.ls.getSoilTestData().subscribe((res) => {
			this.isLoading = false;
			this.usertestdata = res;
			//console.log(this.usertestdata);
			this.listData = new MatTableDataSource(this.usertestdata);
			/* config filter */
			this.listData.filterPredicate = (data: Farmer, filter: string) =>
				data.FarmerName.toLowerCase().indexOf(filter) !== -1 ||
				data.SurName.toLowerCase().indexOf(filter) !== -1;
			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}

	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	toggleViewSoiltestdata(id: string) {
		//console.log('id after delete', id);
		this.ls.getSoilTestDataByID(id).subscribe((res) => {
			this.Editsoiltestdata = res;
			//console.log(this.Editsoiltestdata, 'data with id');
			this.listofnutrients = this.Editsoiltestdata.object.result;
			//console.log('nutreintlistdata', this.listofnutrients);
			this.NutrientData = new MatTableDataSource(this.listofnutrients);
		});
		this.ls.getTestSoilDataByID(id).subscribe((res) => {
			this.soildata = res;
			//console.log('this is soiltestdata by id', this.soildata);
			this.soiltestdatabyid = new MatTableDataSource(this.soildata);
			if (this.soiltestdatabyid.filteredData.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
		});
		this.viewSoiltestdata = !this.viewSoiltestdata;
		this.displayddl = !this.editSoiltestdata ? 'inline' : 'none';
	}

	toggleViewSoiltestdata1() {
		this.displayNoRecords = false;
		this.viewSoiltestdata = false;
		this.SoilCorrectiveActions.reset();
		this.editing = true;
		this.displayddl = !this.editSoiltestdata ? 'inline' : 'block';
	}

	CreateSoilCorrectiveData() {
		if (!this.SoilCorrectiveActions.valid) {
			Object.keys(this.SoilCorrectiveActions.controls).forEach((field) => {
				const control = this.SoilCorrectiveActions.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
		} else {
			this.SoilCorrectiveActions.controls.TblSoilTestData_ID.patchValue(this.Editsoiltestdata.object.ID);
			this.SoilCorrectiveActions.controls.created_by.patchValue(1);
			this.ls.saveSoilCorrectiveData(this.SoilCorrectiveActions.value).subscribe(
				(res) => {
					//console.log(res, 'add');
					if (res['data'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added the SoilCorrectiveData',
							showConfirmButton: false,
							timer: 1500
						});
						this.SoilCorrectiveActions.reset();
						//this.Nutrientlists.clear();
						this.getSoilTestDataDetails();
						this.toggleViewSoiltestdata1();
						//this.AddSoilTestData();
					} else if ((res['data'] = 'SoilCorrectiveData already exists!')) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The SoilCorrectiveData',
							showConfirmButton: false,
							timer: 1500
						});
					}
				},
				(err) => console.error(err)
			);
		}
	}

	deleteSoiltestdata(data) {
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteSoilCorrectivedataById(data.ID).subscribe((res) => {
					if ((res['data'] = 'Success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.viewSoiltestdata = false;
						this.toggleViewSoiltestdata(data.TblSoilTestData_ID);
						//console.log('this id', data.TblSoilTestData_ID);
					}
				});
			}
		});
	}

	toggleUpdateSoiltestdata(id: string) {
		//console.log('update id is =', id);
		this.ls.getSoilCorrectiveActionByID(id).subscribe((res) => {
			this.Editdata = res;
			//console.log('editing data', this.Editdata);
			this.SoilCorrectiveActions.patchValue({
				SoilConsultentName: this.Editdata.SoilConsultentName,
				ActionItems: this.Editdata.ActionItems,
				modified_by: this.Editdata.modified_by
			});
			//console.log('patch data', this.SoilCorrectiveActions.value);
		});
		this.editing = false;
	}

	openDialog(action, obj) {
		////console.log('hello', obj);
		this.Inputtoupdate = obj;
		//console.log('this is when update =', this.Inputtoupdate);
		obj.action = action;
		const dialogRef = this.dialog.open(DialogBoxComponent, {
			width: '1000px',
			data: obj
		});

		dialogRef.afterClosed().subscribe((result) => {
			if (result.event == 'Update') {
				this.updateRowData(result.data);
			}
		});
	}

	updateRowData(row_obj) {
		this.Outputtoupdate = row_obj;
		if (
			this.Inputtoupdate.SoilConsultentName === this.Outputtoupdate.SoilConsultentName &&
			this.Inputtoupdate.ActionItems === this.Outputtoupdate.ActionItems
		) {
			//console.log('no update');
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'No update Found',
				showConfirmButton: false,
				timer: 1500
			});
			//this.openDialog(obj);
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.SoilCorrectiveActions.controls.created_by.patchValue(this.Inputtoupdate.created_by);
			this.SoilCorrectiveActions.controls.modified_by.patchValue(1);
			this.SoilCorrectiveActions.controls.TblSoilTestData_ID.patchValue(this.Inputtoupdate.TblSoilTestData_ID);
			this.SoilCorrectiveActions.controls.SoilConsultentName.patchValue(this.Outputtoupdate.SoilConsultentName);
			this.SoilCorrectiveActions.controls.ActionItems.patchValue(this.Outputtoupdate.ActionItems);
			this.ls
				.updateCorrectiveActionByID(this.Inputtoupdate.ID, this.SoilCorrectiveActions.value)
				.subscribe((res) => {
					//console.log('hulalalal id= ', this.SoilCorrectiveActions.value);
					if (res['data'] === 'Success') {
						//console.log('update');
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Edited',
							showConfirmButton: false,
							timer: 1500
						});
						this.viewSoiltestdata = false;
						this.SoilCorrectiveActions.reset();
						this.toggleViewSoiltestdata(this.Inputtoupdate.TblSoilTestData_ID);
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					}
				});
		}
	}
}
