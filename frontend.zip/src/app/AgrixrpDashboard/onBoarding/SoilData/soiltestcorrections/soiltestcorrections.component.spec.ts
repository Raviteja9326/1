import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoiltestcorrectionsComponent } from './soiltestcorrections.component';

describe('SoiltestcorrectionsComponent', () => {
  let component: SoiltestcorrectionsComponent;
  let fixture: ComponentFixture<SoiltestcorrectionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoiltestcorrectionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoiltestcorrectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
