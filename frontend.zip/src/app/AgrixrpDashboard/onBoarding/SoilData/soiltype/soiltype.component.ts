import { Component, OnInit, ViewChild } from '@angular/core';
import Swal from 'sweetalert2';
import { Soil } from 'app/AgrixrpDashboard/onBoarding/SoilData/soiltype/Soil';
import { HttpClient } from '@angular/common/http';
import { Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons'
import { MastersService } from "app/services/masters.service";


@Component({
  selector: 'app-soiltype',
  templateUrl: './soiltype.component.html',
  styleUrls: ['./soiltype.component.scss']
})
export class SoiltypeComponent implements OnInit {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'SoilType', 'Actions'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;



  // tslint:disable-next-line:member-ordering
  editsoiltype = true;
  // tslint:disable-next-line:member-ordering
  edittype = "add_circle";
  // tslint:disable-next-line:member-ordering
  Soiltypes = "Soil Type";
  // tslint:disable-next-line:member-ordering
  displayddl: string;
  // tslint:disable-next-line:member-ordering
  updateSoilType = false;
  // tslint:disable-next-line:member-ordering
  EditSoil: any = [];
  // tslint:disable-next-line:member-ordering
  viewSoilType = false;
  // tslint:disable-next-line:member-ordering
  viewsoil: any = [];
  // tslint:disable-next-line:member-ordering
  userSoilTypeData: any = [];
  // tslint:disable-next-line:member-ordering
  EditOldData: any = [];
  // tslint:disable-next-line:member-ordering
  isLoading = true;
  // tslint:disable-next-line:member-ordering
  secretKey: string;
  // tslint:disable-next-line:member-ordering
  displayNoRecords = false;


  SoilForm = this.formBuilder.group({
    SoilType: ['', [Validators.required, Validators.pattern('^[a-zA-Z\\s]+$')]],
    SoilTypeNotes: ['', [Validators.required]],
    created_by: [],
    modified_by: []
  });


  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }



  constructor(private ls: MastersService, private http: HttpClient,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.dispalySoilType();
  }
  dispalySoilType() {
    this.ls.getSoilTypeData().subscribe(
      list => {
        this.isLoading = false;
        this.userSoilTypeData = list;
        if (this.userSoilTypeData.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        };
        this.listData = new MatTableDataSource(this.userSoilTypeData);
        /* config filter */
        this.listData.filterPredicate =
          (data: Soil, filter: string) => data.SoilType.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
    );
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.SoilForm.valid) {
      this.SoilForm.reset();
    }
  }

  Addsoil() {
    this.SoilForm.reset();
    this.Soiltypes =
      this.Soiltypes === "Soil Type" ? "Add Soil Type" : "Soil Type";
    this.editsoiltype = !this.editsoiltype;
    this.edittype =
      this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editsoiltype ? "inline" : "none";
    this.dispalySoilType();
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  toggleUpdateSoiltype(getSoiltypeDataObj) {
    this.EditSoil = getSoiltypeDataObj;
    this.updateSoilType = !this.updateSoilType;
    this.displayddl = !this.editsoiltype ? "inline" : "none";
    this.SoilForm.controls.modified_by.patchValue(0);
    this.SoilForm.setValue({
      SoilType: this.EditSoil.SoilType,
      SoilTypeNotes: this.EditSoil.SoilTypeNotes,
      created_by: this.EditSoil.created_by,
      modified_by: this.EditSoil.modified_by
    });
  }



  CreateSoilType(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.SoilForm.valid) {
      Object.keys(this.SoilForm.controls).forEach(field => {
        const control = this.SoilForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.SoilForm.controls.created_by.patchValue(1);
      this.ls.saveSoilType(this.SoilForm.value).subscribe(
        res => {

          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Soil Type',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.resetForm();
            this.dispalySoilType();
            this.Addsoil();
          } else if (res['data'] = "serverErrorStateExistence") {
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The SoilType Name',
              showConfirmButton: false,
              timer: 1500
            })
          }
        },
        err => console.error(err)
      )
    }
  }

  updateSoilType1(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.SoilForm.valid) {
      Object.keys(this.SoilForm.controls).forEach(field => {
        const control = this.SoilForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.SoilForm.controls.modified_by.patchValue(0);
      this.ls.updateSoilTypeById(this.EditSoil.ID, this.SoilForm.value).subscribe(res => {
        if (this.EditSoil.SoilType === this.SoilForm.controls.SoilType.value &&
          this.EditSoil.SoilTypeNotes === this.SoilForm.controls.SoilTypeNotes.value
        ) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.dispalySoilType();
          this.toggleUpdateSoiltype2()
        }

      },

      )
    }

  }

  toggleUpdateSoiltype2() {
    this.updateSoilType = false;
    this.displayddl = this.EditSoil ? "inline" : "block";
  }

  toggleViewSoiltype(getSoiltypeDataObj) {
    this.viewSoilType = !this.viewSoilType;
    this.EditSoil = getSoiltypeDataObj;
    this.displayddl = !this.EditSoil ? "inline" : "none";
  }

  toggleViewSoiltype1() {
    this.viewSoilType = false;
    this.displayddl = this.EditSoil ? "inline" : "block";
  }

  deleteSoiltpye(id: string) {

    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ls.deleteSoilTypeById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.dispalySoilType();
            }
          }
        )
      }
    })
  }

}
