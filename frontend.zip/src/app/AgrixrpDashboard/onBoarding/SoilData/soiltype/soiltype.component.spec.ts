import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoiltypeComponent } from './soiltype.component';

describe('SoiltypeComponent', () => {
  let component: SoiltypeComponent;
  let fixture: ComponentFixture<SoiltypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoiltypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoiltypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
