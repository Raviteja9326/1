export interface Soil {
    ID?:number;
    SoilType?: string;
    SoilTypeNotes?: string;
    created_by:0;
    modified_by:0;
}
