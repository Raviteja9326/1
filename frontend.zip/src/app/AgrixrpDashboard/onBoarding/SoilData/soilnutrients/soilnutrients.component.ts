import { Component, OnInit, ViewChild } from '@angular/core';
import { Nutrient } from './Nutrients';
import Swal from 'sweetalert2';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort, MatSelect } from '@angular/material';
import { ReplaySubject, Subject } from 'rxjs';
import { Category } from '../soilcat/Category';
import { takeUntil } from 'rxjs/operators';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
@Component({
  selector: 'app-soilnutrients',
  templateUrl: './soilnutrients.component.html',
  styleUrls: ['./soilnutrients.component.scss']
})
export class SoilnutrientsComponent implements OnInit {

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'SoilNutrientName', 'SoilNutrientChemicalsymbol', 'Actions'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CatFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCat: ReplaySubject<Category[]> = new ReplaySubject<Category[]>(1);
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();



  editnutrients = true;
  editSoilnutrients = "add_circle";
  Soilnutrients = "Soil Nutrients";
  displayddl: string;
  updateSoilNutType = false;
  EditNutreint: any = [];
  userSoilNutData: any = [];
  getCategoryData: Category[] = [];
  EditOldData: any = [];
  viewsoilnut = false;
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  SoilNutvalidation = this.formBuilder.group({
    SoilNutrientName: ['', [Validators.required]],
    SoilNutrientChemicalsymbol: ['', [Validators.required]],
    SoilNutrientVerylow: [''],
    SoilNutrientLow: [''],
    SoilNutrientMedium: [''],
    SoilNutrientHigh: [''],
    SoilNutrientVeryHigh: [''],
    TblSoilCategory_ID: [''],
    created_by: [],
    modified_by: []
  })

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.dispalySoilNutrient();
    this.ls.getSoilCatData().subscribe(res => {
      this.getCategoryData = res;
    });
    this.CatFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterSoilCat();
      });
  }

  protected filterSoilCat() {
    if (!this.getCategoryData) {
      return;
    }
    // get the search keyword
    let search = this.CatFilterCtrl.value;

    if (!search) {
      this.filteredCat.next(this.getCategoryData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCat.next(
      this.getCategoryData.filter(bank => bank.SoilCatType.toLowerCase().indexOf(search) > -1)
    );
  }

  dispalySoilNutrient() {
    this.ls.getSoilNutData().subscribe(
      list => {
        this.isLoading = false;
        this.userSoilNutData = list;
        if (this.userSoilNutData.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userSoilNutData);
        /* config filter */
        this.listData.filterPredicate =
          (data: Nutrient, filter: string) => data.SoilNutrientName.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
    );
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.SoilNutvalidation.valid) {
      this.SoilNutvalidation.reset();
    }
  }

  AddNutrients() {
    this.filteredCat.next(this.getCategoryData.slice());
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.SoilNutvalidation.reset();
    this.editSoilnutrients =
      this.editSoilnutrients === "cancel" ? "add_circle" : "cancel";
    this.Soilnutrients =
      this.Soilnutrients === "Soil Nutrients" ? "Add Soil Nutrients" : "Soil Nutrients";
    this.editnutrients = !this.editnutrients;
    this.resetForm();
    this.displayddl = this.editnutrients ? "inline" : "none";
    this.dispalySoilNutrient();
  }

  toggleUpdateSoiltype(getSoilNutDataObj) {
    this.updateSoilNutType = !this.updateSoilNutType;
    this.EditNutreint = getSoilNutDataObj;
    this.displayddl = !this.EditNutreint ? "inline" : "none";
    this.SoilNutvalidation.controls.modified_by.patchValue(0);
    this.SoilNutvalidation.setValue({
      SoilNutrientName: this.EditNutreint.SoilNutrientName,
      SoilNutrientChemicalsymbol: this.EditNutreint.SoilNutrientChemicalsymbol,
      SoilNutrientVerylow: this.EditNutreint.SoilNutrientVerylow,
      SoilNutrientLow: this.EditNutreint.SoilNutrientLow,
      SoilNutrientMedium: this.EditNutreint.SoilNutrientMedium,
      SoilNutrientHigh: this.EditNutreint.SoilNutrientHigh,
      SoilNutrientVeryHigh: this.EditNutreint.SoilNutrientVeryHigh,
      TblSoilCategory_ID: this.EditNutreint.TblSoilCategory_ID,
      created_by: this.EditNutreint.created_by,
      modified_by: this.EditNutreint.modified_by
    });
  }

  toggleUpdateSoilnut2() {
    this.updateSoilNutType = false;
    this.displayddl = this.EditNutreint ? "inline" : "none";
  }

  CreateSoilNutrient(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.SoilNutvalidation.valid) {
      Object.keys(this.SoilNutvalidation.controls).forEach(field => {
        const control = this.SoilNutvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.SoilNutvalidation.controls.created_by.patchValue(0);
      this.ls.savesoilnut(this.SoilNutvalidation.value).subscribe(
        res => {
          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Soil Nutrients',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.resetForm();
            this.dispalySoilNutrient();
            this.AddNutrients();
          } else if (res['data'] = "serverErrorStateExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The SoilNutreint Name',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }

  }

  updateSoilNut(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.SoilNutvalidation.valid) {
      Object.keys(this.SoilNutvalidation.controls).forEach(field => {
        const control = this.SoilNutvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.SoilNutvalidation.controls.modified_by.patchValue(0);
      this.ls.updateSoilNutById(this.EditNutreint.ID, this.SoilNutvalidation.value).subscribe(res => {
        if (this.EditNutreint.SoilNutrientName === this.SoilNutvalidation.controls.SoilNutrientName.value &&
          this.EditNutreint.SoilNutrientChemicalsymbol === this.SoilNutvalidation.controls.SoilNutrientChemicalsymbol.value &&
          this.EditNutreint.SoilNutrientVerylow === this.SoilNutvalidation.controls.SoilNutrientVerylow.value &&
          this.EditNutreint.SoilNutrientLow === this.SoilNutvalidation.controls.SoilNutrientLow.value &&
          this.EditNutreint.SoilNutrientMedium === this.SoilNutvalidation.controls.SoilNutrientMedium.value &&
          this.EditNutreint.SoilNutrientHigh === this.SoilNutvalidation.controls.SoilNutrientHigh.value &&
          this.EditNutreint.TblSoilCategory_ID === this.SoilNutvalidation.controls.TblSoilCategory_ID.value &&
          this.EditNutreint.SoilNutrientVeryHigh === this.SoilNutvalidation.controls.SoilNutrientVeryHigh.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.dispalySoilNutrient();
          this.toggleUpdateSoilnut2()
        }

      },

      )
    }
  }



  toggleViewSoiltype(getSoilNutDataObj) {
    this.viewsoilnut = !this.viewsoilnut;
    this.EditNutreint = getSoilNutDataObj;
    this.displayddl = !this.EditNutreint ? "inline" : "none";
  }
  toggleViewSoilnut1() {
    this.viewsoilnut = false;
    this.displayddl = !this.EditNutreint ? "inline" : "block";
  }

  deleteSoiltpye(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ls.deleteSoilNutById(id).subscribe(
          res => {
            if (res['data'] = "successfully deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.dispalySoilNutrient();
            }
          }
        )
      }
    })
  }

}
