import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoilnutrientsComponent } from './soilnutrients.component';

describe('SoilnutrientsComponent', () => {
  let component: SoilnutrientsComponent;
  let fixture: ComponentFixture<SoilnutrientsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoilnutrientsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoilnutrientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
