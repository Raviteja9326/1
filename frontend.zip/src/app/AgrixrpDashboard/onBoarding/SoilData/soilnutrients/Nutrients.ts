export interface Nutrient {
    ID?: number;
    SoilNutrientName?: any;
    SoilNutrientChemicalsymbol?: any;
    SoilNutrientVerylow?: any;
    SoilNutrientLow?: any;
    SoilNutrientMedium?: any;
    SoilNutrientHigh?: any;
    SoilNutrientVeryHigh?: any;
    TblSoilCategory_ID?: number;
    created_by: any;
    modified_by: any;
}