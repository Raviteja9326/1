import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SoildataRoutingModule } from './soildata-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { SoildataComponent } from './soildata.component';
import { SoiltypeComponent } from './soiltype/soiltype.component';
import { SoilcatComponent } from './soilcat/soilcat.component';
import { SoilnutrientsComponent } from './soilnutrients/soilnutrients.component';
import { SoiltestcorrectionsComponent } from './soiltestcorrections/soiltestcorrections.component';
import { SoiltestdataComponent } from './soiltestdata/soiltestdata.component';
// tslint:disable-next-line:max-line-length
const components = [SoildataComponent, SoiltypeComponent, SoilcatComponent, SoilnutrientsComponent, SoiltestcorrectionsComponent, SoiltestdataComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [SoildataRoutingModule, CommonModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class SoildataModule { }