import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimaldiseasemanagementComponent } from './animaldiseasemanagement.component';

describe('AnimaldiseasemanagementComponent', () => {
  let component: AnimaldiseasemanagementComponent;
  let fixture: ComponentFixture<AnimaldiseasemanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimaldiseasemanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimaldiseasemanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
