export interface AnimalDisease {
    ID:number;
    DiseaseDesc?: any;
    Symptoms?:any;
    Cause?:any;
    Treatment?:any;
    Image?: any;
    ReferanceURL?:any;
    TblAnimalMaster_ID?:any;
    created_by?:any;
   modified_by?:any;
}

export interface Animal {
    AnimalName?:any;
}