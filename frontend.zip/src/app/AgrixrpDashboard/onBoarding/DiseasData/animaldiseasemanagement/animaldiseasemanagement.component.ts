import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";

import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatSelect,
  MatTableDataSource,
  MatPaginator,
  MatSort
} from "@angular/material";
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
import { Animal } from './animaldisease';
//import { Animal } from './crop-disease';

@Component({
  selector: 'app-animaldiseasemanagement',
  templateUrl: './animaldiseasemanagement.component.html',
  styleUrls: ['./animaldiseasemanagement.component.scss']
})
export class AnimaldiseasemanagementComponent implements OnInit {

  AnimalDiseaseManagement = "AnimalDisease";
  editAnimalDiseaseManagementcontent = "add_circle";
  displayddl: string;
  editAnimalDiseaseManagement = true;
  userAnimalDiseaseData: any = [];
  EditAnimalDisease: any = [];
  // getexpenseData: Observable<any[]>;
  UpdateAnimalDisease = false;
  viewAnimalDisease = false;

  animalDiseasedata: any = [];

  diseasedata: any[];
  getanimalDiseaseData: Animal[] = [];

  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "AnimalName", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  /** control for the MatSelect filter keyword */
  public AnimalDiseaseFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public animalCoun: ReplaySubject<Animal[]> = new ReplaySubject<
    Animal[]
  >(1);
  AnimalDisease = this.formBuilder.group({
    TblAnimalMaster_ID: ["", [Validators.required]],
    DiseaseDesc: [""],
    Symptoms: [""],
    Cause: [""],
    Treatment: [""],
    Image: [""],
    fileSource: [""],
    ReferanceURL: [""],
    created_by: [],
    modified_by: []
  });
  AnimalDisease2 = this.formBuilder.group({
    TblAnimalMaster_ID: ["", [Validators.required]],
    DiseaseDesc: [""],
    Symptoms: [""],
    Cause: [""],
    Treatment: [""],
    Image: [""],
    ReferanceURL: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(
    private ls: MastersService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  onFileChange(event) {

    if (event.target.files.length > 0) {
      const Image = event.target.files[0];
      this.AnimalDisease.patchValue({
        fileSource: Image
      });
    }
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.AnimalDisease.valid) {
      //console.log("Form Submitted");
      this.AnimalDisease.reset();
    }
  }

  ngOnInit() {


    this.displayanimaldisease();

    this.ls.getAnimalMaster().subscribe(res => {
      //console.log("data", res);
      this.getanimalDiseaseData = res;
      //console.log(this.getanimalDiseaseData, "data");
    });

    // listen for search field value changes
    this.AnimalDiseaseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterAnimalData();
      });
  }

  protected filterAnimalData() {
    //console.log("hello", this.getanimalDiseaseData);
    if (!this.getanimalDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.AnimalDiseaseFilterCtrl.value;
    if (!search) {
      this.animalCoun.next(this.getanimalDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.animalCoun.next(
      this.getanimalDiseaseData.filter(
        bank => bank.AnimalName.toLowerCase().indexOf(search) > -1
      )
    );
  }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displayanimaldisease() {
    this.ls.getAnimaldiseasedata().subscribe(list => {
      //console.log("mis", list);
      this.isLoading = false;
      this.userAnimalDiseaseData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      //console.log(this.userAnimalDiseaseData, "userAnimalDiseaseData");
      this.listData = new MatTableDataSource(this.userAnimalDiseaseData);
      this.listData.filterPredicate = (data: Animal, filter: string) =>
        data.AnimalName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }


  AddAnimalDiseases() {


    this.animalCoun.next(this.animalDiseasedata.slice());
    this.AnimalDisease.reset();
    this.displayanimaldisease();
    this.AnimalDiseaseManagement =
      this.AnimalDiseaseManagement === "AnimalDisease"
        ? "Add AnimalDisease"
        : "AnimalDisease";
    this.editAnimalDiseaseManagement = !this.editAnimalDiseaseManagement;
    this.editAnimalDiseaseManagementcontent =
      this.editAnimalDiseaseManagementcontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl = this.editAnimalDiseaseManagement ? "inline" : "none";
  }

  CreateAnimalDisease() {
    const formData = new FormData();
    formData.append('Image', this.AnimalDisease.get('fileSource').value);
    if (!this.AnimalDisease.valid) {
      Object.keys(this.AnimalDisease.controls).forEach(field => {
        const control = this.AnimalDisease.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.AnimalDisease.controls.created_by.patchValue(1);
      this.ls.saveAnimaldiseasedata(this.AnimalDisease.value).subscribe(
        res => {
          //console.log(res, "add");
          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
            this.AnimalDisease.reset();
            this.displayanimaldisease();
            this.AddAnimalDiseases();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateAnimalDisease(getAnimalDiseaseDataObj) {
    //console.log(getAnimalDiseaseDataObj);
    this.UpdateAnimalDisease = !this.UpdateAnimalDisease;
    this.EditAnimalDisease = getAnimalDiseaseDataObj;

    //console.log(this.EditAnimalDisease);
    this.displayddl = !this.editAnimalDiseaseManagement ? "inline" : "none";
    this.AnimalDisease2.setValue({
      TblAnimalMaster_ID: this.EditAnimalDisease.TblAnimalMaster_ID,
      DiseaseDesc: this.EditAnimalDisease.DiseaseDesc,
      Symptoms: this.EditAnimalDisease.Symptoms,
      Cause: this.EditAnimalDisease.Cause,
      Treatment: this.EditAnimalDisease.Treatment,
      Image: this.EditAnimalDisease.Image,
      ReferanceURL: this.EditAnimalDisease.ReferanceURL,
      created_by: this.EditAnimalDisease.created_by,
      modified_by: this.EditAnimalDisease.modified_by
    });
  }

  toggleAnimalDisease2() {
    this.UpdateAnimalDisease = false;
    this.displayddl = this.EditAnimalDisease ? "inline" : "block";
  }

  UpdateAnimalDiseases(getAnimalDiseaseDataObj) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.EditAnimalDisease = getAnimalDiseaseDataObj;
    if (!this.AnimalDisease2.valid) {
      Object.keys(this.AnimalDisease2.controls).forEach(field => {
        const control = this.AnimalDisease2.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ls.updateAnimaldiseaseByID(this.EditAnimalDisease.ID, this.AnimalDisease2.value).subscribe(res => {

        if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayanimaldisease();
          this.toggleAnimalDisease2();
        }

      },
        err => console.log(err)
      )
    }
  }

  deleteAnimalDisease(id: string) {
    //console.log(id);

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deleteAnimaldiseaseByID(id).subscribe(pdata => {
          if ((pdata["data"] = "Successfully Deleted")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displayanimaldisease();
          }
        });
      }
    });
  }

  toggleViewAnimalDisease(getAnimalDiseaseDataObj) {
    //console.log(getAnimalDiseaseDataObj);
    this.viewAnimalDisease = !this.viewAnimalDisease;
    this.EditAnimalDisease = getAnimalDiseaseDataObj;
    this.displayddl = !this.EditAnimalDisease ? "inline" : "none";
  }
  toggleViewCropDisease1() {
    this.viewAnimalDisease = false;
    this.displayddl = !this.EditAnimalDisease ? "inline" : "block";
  }
}
