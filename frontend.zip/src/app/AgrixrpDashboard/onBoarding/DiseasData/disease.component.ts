import { Component } from '@angular/core';

@Component({
  selector: 'app-disease',
  template: `<router-outlet></router-outlet>`,
})

export class DiseaseComponent {
}
