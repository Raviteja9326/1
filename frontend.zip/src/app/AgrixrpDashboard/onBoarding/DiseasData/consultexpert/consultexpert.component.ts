import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";

import { HttpClient } from "@angular/common/http";

import { CASService } from "app/services/cas.service";
import { MastersService } from "app/services/masters.service";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatSelect,
  MatTableDataSource,
  MatPaginator,
  MatSort
} from "@angular/material";
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { ExpertID } from './consultexpert';
import { Farmer } from '../../FarmerData/farmerinfo/farmerinfo';

@Component({
  selector: 'app-consultexpert',
  templateUrl: './consultexpert.component.html',
  styleUrls: ['./consultexpert.component.scss']
})
export class ConsultexpertComponent implements OnInit {
  ConsultExpert = "ConsultExpert";
  editConsultExpertcontent = "add_circle";
  displayddl: string;
  editConsultexpert = true;
  userConsultExpertData: any = [];
  EditConsultExpert: any = [];
  UpdateConsultExpert = false;
  viewConsultExpert = false;
  FarmerData: any = [];
  Expertdata: any = [];
  diseasedata: any[];
  getfarmerData: Farmer[] = [];
  getexpertData: ExpertID[] = [];


  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "FarmerName", "ExpertName", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  /** control for the MatSelect filter keyword */
  public FarmerFilterCtrl: FormControl = new FormControl();

  public ConultExpertFilterCtrl: FormControl = new FormControl();


  /** list of banks filtered by search keyword */
  public farmerCoun: ReplaySubject<Farmer[]> = new ReplaySubject<
    Farmer[]>(1);

  public Expert: ReplaySubject<ExpertID[]> = new ReplaySubject<
    ExpertID[]>(1);


  ConsultReport = this.formBuilder.group({
    QuerySubject: ["", [Validators.required]],
    QueryDesc: [""],
    FarmerID: [""],
    QueryType: [""],
    ExpertID: [""],
    ExpertName: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(
    private ls: MastersService,
    private ds: CASService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  onFileChange(event) {

    if (event.target.files.length > 0) {
      const Image = event.target.files[0];
      this.ConsultReport.patchValue({
        fileSource: Image
      });
    }
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.ConsultReport.valid) {
      //console.log("Form Submitted");
      this.ConsultReport.reset();
    }
  }

  ngOnInit() {


    this.displayconsultExpert();

    this.ls.getFarmerdata().subscribe(res => {
      //console.log("data", res);
      this.getfarmerData = res;
      //console.log(this.getfarmerData, "data");
    });

    this.ds.getAllRoles().subscribe(res => {
      //console.log("data", res);
      this.getexpertData = res;
      //console.log(this.getexpertData, "data");
    });


    // listen for search field value changes
    this.FarmerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFarmer();
      });
    this.ConultExpertFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterConsult();
      });



  }
  //for crop
  protected filterFarmer() {
    //console.log("hello", this.getfarmerData);
    if (!this.getfarmerData) {
      return;
    }
    // get the search keyword
    let search = this.FarmerFilterCtrl.value;
    if (!search) {
      this.farmerCoun.next(this.getfarmerData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.farmerCoun.next(
      this.getfarmerData.filter(
        bank => bank.FarmerName.toLowerCase().indexOf(search) > -1
      )
    );
  }


  //for consult
  protected filterConsult() {
    //console.log("hello", this.getexpertData);
    if (!this.getexpertData) {
      return;
    }
    // get the search keyword
    let search = this.ConultExpertFilterCtrl.value;
    if (!search) {
      this.Expert.next(this.getexpertData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.Expert.next(
      this.getexpertData.filter(
        bank => bank.RoleName.toLowerCase().indexOf(search) > -1
      )
    );
  }



  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displayconsultExpert() {
    this.ls.getconsutExpertdata().subscribe(list => {
      //console.log("mis", list);
      this.isLoading = false;
      this.userConsultExpertData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      //console.log(this.userConsultExpertData, "userConsultExpertData");
      this.listData = new MatTableDataSource(this.userConsultExpertData);
      this.listData.filterPredicate = (data: Farmer, filter: string) =>
        data.FarmerName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }


  AddConsultexpert() {
    this.farmerCoun.next(this.getfarmerData.slice());
    this.ConsultReport.reset();
    this.displayconsultExpert();
    this.ConsultExpert =
      this.ConsultExpert === "ConsultExpert"
        ? "Add ConsultExpert"
        : "ConsultExpert";
    this.editConsultexpert = !this.editConsultexpert;
    this.editConsultExpertcontent =
      this.editConsultExpertcontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl = this.editConsultexpert ? "inline" : "none";
  }

  CreateConsultExpert() {
    const formData = new FormData();
    formData.append('Image', this.ConsultReport.get('fileSource').value);
    if (!this.ConsultReport.valid) {
      Object.keys(this.ConsultReport.controls).forEach(field => {
        const control = this.ConsultReport.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.ConsultReport.controls.created_by.patchValue(1);
      this.ls.savecropreportdiseasedata(this.ConsultReport.value).subscribe(
        res => {
          //console.log(res, "add");
          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
            this.ConsultReport.reset();
            this.displayconsultExpert();
            this.AddConsultexpert();
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateConsultExpert(getConsultExpertDataObj) {
    //console.log(getConsultExpertDataObj);
    this.userConsultExpertData = !this.userConsultExpertData;
    this.EditConsultExpert = getConsultExpertDataObj;

    //console.log(this.EditConsultExpert);
    this.displayddl = !this.editConsultexpert ? "inline" : "none";
    this.ConsultReport.setValue({
      QuerySubject: this.EditConsultExpert.QuerySubject,
      QueryDesc: this.EditConsultExpert.QueryDesc,
      FarmerID: this.EditConsultExpert.FarmerID,
      QueryType: this.EditConsultExpert.QueryType,
      ExpertID: this.EditConsultExpert.ExpertID,
      ExpertName: this.EditConsultExpert.ExpertName,
      created_by: this.EditConsultExpert.created_by,
      modified_by: this.EditConsultExpert.modified_by
    });
  }

  toggleUpdateConsultExpert2() {
    this.UpdateConsultExpert = false;
    this.displayddl = this.EditConsultExpert ? "inline" : "block";
  }

  UpdateConsultentExpert(getConsultExpertDataObj) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.EditConsultExpert = getConsultExpertDataObj;
    if (!this.ConsultReport.valid) {
      Object.keys(this.ConsultReport.controls).forEach(field => {
        const control = this.ConsultReport.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ls.updateconsutExpertByID(this.EditConsultExpert.ID, this.ConsultReport.value).subscribe(res => {

        if (res['data'] === "Success") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayconsultExpert();
          this.toggleUpdateConsultExpert2();
        }

      },
        err => console.log(err)
      )
    }
  }

  deleteConsultExpert(id: string) {
    //console.log(id);

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deleteconsutExpertByID(id).subscribe(pdata => {
          if ((pdata["data"] = "success")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displayconsultExpert();
          }
        });
      }
    });
  }

  toggleViewConsultExpert(getConsultExpertDataObj) {
    //console.log(getConsultExpertDataObj);
    this.viewConsultExpert = !this.viewConsultExpert;
    this.EditConsultExpert = getConsultExpertDataObj;
    this.displayddl = !this.EditConsultExpert ? "inline" : "none";
  }
  toggleViewCropDisease1() {
    this.viewConsultExpert = false;
    this.displayddl = !this.EditConsultExpert ? "inline" : "block";
  }
}