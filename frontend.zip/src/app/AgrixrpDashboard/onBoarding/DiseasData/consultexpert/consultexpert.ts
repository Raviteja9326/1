export interface ConsultExpert {
    ID:number;
    QuerySubject?: any;
    QueryDesc?:any;
    FarmerID?:any;
    QueryType?:any;
    ExpertID?: any;
    ExpertName?:any;
    created_by?:any;
   modified_by?:any;
}

export interface ExpertID {
    RoleName?:any;
}