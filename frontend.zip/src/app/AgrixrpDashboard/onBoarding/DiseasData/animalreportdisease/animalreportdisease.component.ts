import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";

import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatSelect,
  MatTableDataSource,
  MatPaginator,
  MatSort
} from "@angular/material";
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
import { Crop } from '../crop-disease-management/crop-disease';
import { disease, diseaseType } from './animalreportdisease';
import { Animal } from '../animaldiseasemanagement/animaldisease';
//import {disease, diseaseType} from '../crop-report-disease/crop-report-disease'

@Component({
  selector: 'app-animalreportdisease',
  templateUrl: './animalreportdisease.component.html',
  styleUrls: ['./animalreportdisease.component.scss']
})
export class AnimalreportdiseaseComponent implements OnInit {

  AnimalReportDisease = "AnimalReportDisease";
  editAnimalReportDiseasecontent = "add_circle";
  displayddl: string;
  editAnimalReportDisease = true;
  userAnimalReportDiseaseData: any = [];
  EditAnimalReportDisease: any = [];
  UpdateAnimalReportDisease = false;
  viewAnimalReportDisease = false;

  animalDiseasedata: any = [];
  animalReportDiseasedata: any = [];
  animalDiseaseTypedata: any = [];
  diseasedata: any[];
  getanimalDiseaseData: Animal[] = [];
  getanimalReportDiseaseData: disease[] = [];
  getanimalDiseaseTypeData: diseaseType[] = [];

  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "AnimalName", "Disease", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  /** control for the MatSelect filter keyword */
  public AnimalDiseaseFilterCtrl: FormControl = new FormControl();
  public TypeFilterCtrl: FormControl = new FormControl();
  public AnimalDiseaseCauseFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public animalCoun: ReplaySubject<Animal[]> = new ReplaySubject<
    Animal[]>(1);
  public animaltype: ReplaySubject<diseaseType[]> = new ReplaySubject<
    diseaseType[]>(1);
  public animalcause: ReplaySubject<disease[]> = new ReplaySubject<
    disease[]>(1);

  AnimalReport = this.formBuilder.group({
    AnimalCycleID: ["", [Validators.required]],
    DiseaseID: [""],
    Symptoms: [""],
    RiskID: [""],
    DiseaseDate: [""],
    Impact: [""],
    Type: [""],
    ContingencyPlan: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(
    private ls: MastersService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  onFileChange(event) {

    if (event.target.files.length > 0) {
      const Image = event.target.files[0];
      this.AnimalReport.patchValue({
        fileSource: Image
      });
    }
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.AnimalReport.valid) {
      //console.log("Form Submitted");
      this.AnimalReport.reset();
    }
  }

  ngOnInit() {


    this.displayanimalReportdisease();

    this.ls.getAnimalMaster().subscribe(res => {
      //console.log("data", res);
      this.getanimalDiseaseData = res;
      //console.log(this.getanimalDiseaseData, "data");
    });
    this.ls.getanimaldisease().subscribe(res => {
      //console.log("data", res);
      this.getanimalDiseaseTypeData = res;
      //console.log(this.getanimalDiseaseTypeData, "data");
    });

    this.ls.getAnimaldiseasedata().subscribe(res => {
      //console.log("data", res);
      this.getanimalReportDiseaseData = res;
      //console.log(this.getanimalReportDiseaseData, "data");
    });

    // listen for search field value changes
    this.AnimalDiseaseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterAnimalData();
      });

    this.TypeFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDisease();
      });
    this.AnimalDiseaseCauseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDiseaseType();
      });
  }
  //for crop
  protected filterAnimalData() {
    //console.log("hello", this.getanimalDiseaseData);
    if (!this.getanimalDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.AnimalDiseaseFilterCtrl.value;
    if (!search) {
      this.animalCoun.next(this.getanimalDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.animalCoun.next(
      this.getanimalDiseaseData.filter(
        bank => bank.AnimalName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  //for disease type

  protected filterDiseaseType() {
    //console.log("hello", this.getanimalReportDiseaseData);
    if (!this.getanimalReportDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.AnimalDiseaseFilterCtrl.value;
    if (!search) {
      this.animalcause.next(this.getanimalReportDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.animalcause.next(
      this.getanimalReportDiseaseData.filter(
        bank => bank.Cause.toLowerCase().indexOf(search) > -1
      )
    );
  }
  //for disease
  protected filterDisease() {
    //console.log("hello", this.getanimalDiseaseTypeData);
    if (!this.getanimalDiseaseTypeData) {
      return;
    }
    // get the search keyword
    let search = this.TypeFilterCtrl.value;
    if (!search) {
      this.animaltype.next(this.getanimalDiseaseTypeData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.animaltype.next(
      this.getanimalDiseaseTypeData.filter(
        bank => bank.DiseaseType.toLowerCase().indexOf(search) > -1
      )
    );
  }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displayanimalReportdisease() {
    this.ls.getanimalreportdiseasedata().subscribe(list => {
      //console.log("mis", list);
      this.isLoading = false;
      this.userAnimalReportDiseaseData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      //console.log(this.userAnimalReportDiseaseData, "userAnimalReportDiseaseData");
      this.listData = new MatTableDataSource(this.userAnimalReportDiseaseData);
      this.listData.filterPredicate = (data: Animal, filter: string) =>
        data.AnimalName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }


  AddAnimalReportDiseases() {
    this.animalCoun.next(this.animalDiseasedata.slice());
    this.animaltype.next(this.animalDiseaseTypedata.slice());
    this.animalcause.next(this.animalReportDiseasedata.slice());
    this.AnimalReport.reset();
    this.displayanimalReportdisease();
    this.AnimalReportDisease =
      this.AnimalReportDisease === "AnimalReportDisease"
        ? "Add AnimalReportDisease"
        : "AnimalReportDisease";
    this.editAnimalReportDisease = !this.editAnimalReportDisease;
    this.editAnimalReportDiseasecontent =
      this.editAnimalReportDiseasecontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl = this.editAnimalReportDisease ? "inline" : "none";
  }

  CreateAnimalReportDisease() {

    if (!this.AnimalReport.valid) {
      Object.keys(this.AnimalReport.controls).forEach(field => {
        const control = this.AnimalReport.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.AnimalReport.controls.created_by.patchValue(1);
      this.ls.saveanimalreportdiseasedata(this.AnimalReport.value).subscribe(
        res => {
          //console.log(res, "add");
          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
            this.AnimalReport.reset();
            this.displayanimalReportdisease();
            this.AddAnimalReportDiseases();
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateAnimalReportDisease(getAnimalDiseaseReportDataObj) {
    //console.log(getAnimalDiseaseReportDataObj);
    this.UpdateAnimalReportDisease = !this.UpdateAnimalReportDisease;
    this.EditAnimalReportDisease = getAnimalDiseaseReportDataObj;
    this.EditAnimalReportDisease.Date = this.dp.transform(
      this.EditAnimalReportDisease.Date,
      "yyyy-MM-dd"
    );

    //console.log(this.EditAnimalReportDisease);
    this.displayddl = !this.EditAnimalReportDisease ? "inline" : "none";
    this.AnimalReport.setValue({
      AnimalCycleID: this.EditAnimalReportDisease.AnimalCycleID,
      DiseaseID: this.EditAnimalReportDisease.DiseaseID,
      Symptoms: this.EditAnimalReportDisease.Symptoms,
      RiskID: this.EditAnimalReportDisease.RiskID,
      DiseaseDate: this.EditAnimalReportDisease.DiseaseDate,
      Impact: this.EditAnimalReportDisease.Impact,
      Type: this.EditAnimalReportDisease.Type,
      ContingencyPlan: this.EditAnimalReportDisease.ContingencyPlan,
      created_by: this.EditAnimalReportDisease.created_by,
      modified_by: this.EditAnimalReportDisease.modified_by
    });
  }

  toggleUpdateAnimalReportDisease2() {
    //console.log("hello")
    this.UpdateAnimalReportDisease = false;
    this.displayddl = this.EditAnimalReportDisease ? "inline" : "block";
  }

  UpdateAnimalReportDiseases(getAnimalDiseaseReportDataObj) {
    //console.log(getAnimalDiseaseReportDataObj,"data")
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.EditAnimalReportDisease = getAnimalDiseaseReportDataObj;
    if (!this.AnimalReport.valid) {
      Object.keys(this.AnimalReport.controls).forEach(field => {
        const control = this.AnimalReport.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ls.updateanimalreportdiseaserByID(this.EditAnimalReportDisease.ID, this.AnimalReport.value).subscribe(res => {

        if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayanimalReportdisease();
          this.toggleUpdateAnimalReportDisease2();
        }

      },
        err => console.log(err)
      )
    }
  }

  deleteAnimalReportDisease(id: string) {
    //console.log(id);

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deleteanimalreportdiseaseByID(id).subscribe(pdata => {
          if ((pdata["data"] = "Successfully Deleted")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displayanimalReportdisease();
          }
        });
      }
    });
  }

  toggleViewAnimalReportDisease(getAnimalDiseaseReportDataObj) {
    //console.log(getAnimalDiseaseReportDataObj);
    this.viewAnimalReportDisease = !this.viewAnimalReportDisease;
    this.EditAnimalReportDisease = getAnimalDiseaseReportDataObj;
    this.displayddl = !this.EditAnimalReportDisease ? "inline" : "none";
  }
  toggleViewAnimalDisease1() {
    this.viewAnimalReportDisease = false;
    this.displayddl = !this.EditAnimalReportDisease ? "inline" : "block";
  }
}
