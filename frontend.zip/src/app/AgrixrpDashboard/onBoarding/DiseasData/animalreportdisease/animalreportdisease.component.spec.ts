import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalreportdiseaseComponent } from './animalreportdisease.component';

describe('AnimalreportdiseaseComponent', () => {
  let component: AnimalreportdiseaseComponent;
  let fixture: ComponentFixture<AnimalreportdiseaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimalreportdiseaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimalreportdiseaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
