export interface AnimalReportDisease {
    ID:number;
    AnimalCycleID?:any;
    DiseaseID?:any;
    Symptoms?:any;
    RiskID?:any;
    DiseaseDate?:any;
    Impact?:any;
    Type?:any;
    ContingencyPlan?:any;
    created_by?:any;
   modified_by?:any;
}
export interface disease{
    Cause?:any
}
export interface diseaseType{
    DiseaseType?:any
}