import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DiseaseComponent } from './disease.component';
import { AnimaldiseasemanagementComponent } from './animaldiseasemanagement/animaldiseasemanagement.component';
import { AnimalreportdiseaseComponent } from './animalreportdisease/animalreportdisease.component';
import { CropDiseaseManagementComponent } from './crop-disease-management/crop-disease-management.component';
import { CropReportDiseaseComponent } from './crop-report-disease/crop-report-disease.component';
import { DiseasetypeComponent } from './diseasetype/diseasetype.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
import { ConsultexpertComponent } from './consultexpert/consultexpert.component';

const routes: Routes = [{
    path: '',
    component: DiseaseComponent,
    children: [{
        path: 'Animal Management',
        component: AnimaldiseasemanagementComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Animal Report',
        component: AnimalreportdiseaseComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Crop Management',
        component: CropDiseaseManagementComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Crop Report',
        component: CropReportDiseaseComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Disease Type',
        component: DiseasetypeComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Consult Expert',
        component: ConsultexpertComponent, canActivate: [AuthGuardService]
    },
    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class DiseaseRoutingModule { }
