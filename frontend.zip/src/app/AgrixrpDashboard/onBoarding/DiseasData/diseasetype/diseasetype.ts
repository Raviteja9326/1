export interface Disease {
    ID:number;
    Type?:any;
    DiseaseType?: any;
    Description?:any;
    created_by?:any;
   modified_by?:any;
}

export interface Type{
    Type?:any;
}