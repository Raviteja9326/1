import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiseasetypeComponent } from './diseasetype.component';

describe('DiseasetypeComponent', () => {
  let component: DiseasetypeComponent;
  let fixture: ComponentFixture<DiseasetypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiseasetypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiseasetypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
