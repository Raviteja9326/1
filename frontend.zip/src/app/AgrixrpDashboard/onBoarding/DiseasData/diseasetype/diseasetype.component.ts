import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { Disease, Type } from "./diseasetype";
import { Validators, FormBuilder, FormControl } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
import { DatePipe } from '@angular/common';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-diseasetype',
  templateUrl: './diseasetype.component.html',
  styleUrls: ['./diseasetype.component.scss']
})
export class DiseasetypeComponent implements OnInit {


  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = ['S.No', 'DiseaseType', 'Actions'];
  editDisease = true;
  editDiseaseContent = "add_circle";
  DiseaseTypes = "Disease List";
  displayddl: string;
  updateDisease = false;
  viewDisease = false;
  userdiseasedata: any[];
  Editcoun: any = [];
  EditDiseaseData: any = [];
  EditOldData: any = [];
  getDiseaseData: Type[] = [];
  userDiseasedata: any[];
  usercropdata: any[];
  userlanddata: any[];
  usercopdata: any[];
  plotByLand: any[];
  cropByplot: any[];
  Editcoc: any = [];
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;
  protected _onDestroy = new Subject<void>();
  /** control for the MatSelect filter keyword */
  public DiseaseFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public DiseaseCoun: ReplaySubject<Type[]> = new ReplaySubject<
    Type[]
  >(1);
  DiseaseForm = this.formBuilder.group({
    Type: ['', [Validators.required]],
    DiseaseType: ['', [Validators.required]],
    Description: [''],
    modified_by: [''],
    created_by: ['']
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private ls: MastersService, private formBuilder: FormBuilder, private dp: DatePipe) { }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    if (this.DiseaseForm.valid) {
      //console.log("Form Submited");
      this.DiseaseForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }


  ngOnInit() {
    this.displaydisease();

    this.ls.getdiseasetype().subscribe(res => {
      //console.log("data", res);
      this.getDiseaseData = res;
      //console.log(this.getDiseaseData, "data");
    });

    // listen for search field value changes
    this.DiseaseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCropData();
      });
  }




  protected filterCropData() {
    //console.log("hello", this.getDiseaseData);
    if (!this.getDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.DiseaseFilterCtrl.value;
    if (!search) {
      this.DiseaseCoun.next(this.getDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.DiseaseCoun.next(
      this.getDiseaseData.filter(
        bank => bank.Type.toLowerCase().indexOf(search) > -1
      )
    );
  }

  displaydisease() {
    //console.log("hello")
    this.ls.getdiseasedata().subscribe(list => {
      this.isLoading = false;
      this.userDiseasedata = list;
      //console.log(this.userDiseasedata);
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userDiseasedata);
      // tslint:disable-next-line: max-line-length
      this.listData.filterPredicate = (data: Disease, filter: any) => data.DiseaseType.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    },
      err => console.error(err)
    );
  }

  CreateDisease() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    if (!this.DiseaseForm.valid) {
      Object.keys(this.DiseaseForm.controls).forEach(field => {
        const control = this.DiseaseForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The MandetoryFields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.DiseaseForm.controls.created_by.patchValue(1);
      this.ls.savediseasedata(this.DiseaseForm.value).subscribe(diseasedata => {
        //console.log(diseasedata);
        if (diseasedata['data'] === "Successfully Posted") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully added the cropcycle',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.DiseaseForm.reset();
          this.displaydisease()
          this.toggleEditDisease()
        }
      },
        err => console.error(err)
      )
    }
  }

  UpdateDisease(diseasedata) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.Editcoc = diseasedata;
    if (!this.DiseaseForm.valid) {
      Object.keys(this.DiseaseForm.controls).forEach(field => {
        const control = this.DiseaseForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ls.updatediseaserByID(this.Editcoc.ID, this.DiseaseForm.value).subscribe(res => {

        if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displaydisease();
          this.toggleUpdateDisease2();
        }

      },
        err => console.log(err)
      )
    }
  }
  deleteDisease(id: any) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ls.deletediseaseByID(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displaydisease();
            }
          }

        )

      }
    })
  }


  toggleEditDisease() {
    this.displaydisease();
    this.DiseaseForm.reset();
    this.DiseaseTypes =
      this.DiseaseTypes === "Add DiseaseType" ? "DiseaseType" : "Add DiseaseType";
    this.editDisease = !this.editDisease;
    this.editDiseaseContent =
      this.editDiseaseContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editDisease ? "inline" : "none";
  }

  toggleUpdateDisease(getDiseaseDataObj) {
    // //console.log(getFarmersDataObj)
    this.Editcoc = getDiseaseDataObj;
    this.updateDisease = !this.updateDisease;
    this.displayddl = !this.editDisease ? "inline" : "none";
    this.DiseaseForm.controls.modified_by.patchValue(1);
    this.DiseaseForm.setValue({
      Type: this.Editcoc.Type,
      DiseaseType: this.Editcoc.DiseaseType,
      Description: this.Editcoc.Description,
      modified_by: this.Editcoc.modified_by,
      created_by: this.Editcoc.created_by,
    });
  }

  toggleUpdateDisease2() {
    this.updateDisease = false;
    this.displayddl = this.editDisease ? "inline" : "block";
  }

  toggleViewDisease(getDiseaseDataObj) {
    //console.log('user signle data', getDiseaseDataObj);
    this.Editcoun = getDiseaseDataObj;
    this.viewDisease = !this.viewDisease;
    this.displayddl = !this.editDisease ? "inline" : "none";
  }

  toggleViewDisease2() {
    this.viewDisease = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }
}