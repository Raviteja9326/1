import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";

import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatSelect,
  MatTableDataSource,
  MatPaginator,
  MatSort
} from "@angular/material";
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
import { Crop } from '../crop-disease-management/crop-disease';
import { disease, diseaseType } from './crop-report-disease'

@Component({
  selector: 'app-crop-report-disease',
  templateUrl: './crop-report-disease.component.html',
  styleUrls: ['./crop-report-disease.component.scss']
})
export class CropReportDiseaseComponent implements OnInit {

  CropReportDisease = "CropReportDisease";
  editCropReportDiseasecontent = "add_circle";
  displayddl: string;
  editCropReportDisease = true;
  userCropReportDiseaseData: any = [];
  EditCropReportDisease: any = [];
  UpdateCropReportDisease = false;
  viewCropReportDisease = false;

  cropDiseasedata: any = [];
  cropReportDiseasedata: any = [];
  cropDiseaseTypedata: any = [];
  diseasedata: any[];
  getcropDiseaseData: Crop[] = [];
  getcropReportDiseaseData: disease[] = [];
  getcropDiseaseTypeData: diseaseType[] = [];

  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "CropVarietyName", "Disease", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  /** control for the MatSelect filter keyword */
  public CropDiseaseFilterCtrl: FormControl = new FormControl();
  public TypeFilterCtrl: FormControl = new FormControl();
  public CropDiseaseCauseFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public cropCoun: ReplaySubject<Crop[]> = new ReplaySubject<
    Crop[]>(1);
  public croptype: ReplaySubject<diseaseType[]> = new ReplaySubject<
    diseaseType[]>(1);
  public cropcause: ReplaySubject<disease[]> = new ReplaySubject<
    disease[]>(1);

  CropReport = this.formBuilder.group({
    CropCycleID: ["", [Validators.required]],
    DiseaseID: [""],
    Symptoms: [""],
    RiskID: [""],
    DiseaseDate: [""],
    Impact: [""],
    Type: [""],
    ContingencyPlan: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(
    private ls: MastersService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  onFileChange(event) {

    if (event.target.files.length > 0) {
      const Image = event.target.files[0];
      this.CropReport.patchValue({
        fileSource: Image
      });
    }
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.CropReport.valid) {
      //console.log("Form Submitted");
      this.CropReport.reset();
    }
  }

  ngOnInit() {


    this.displaycropReportdisease();

    this.ls.getcropmasterdata().subscribe(res => {
      //console.log("data", res);
      this.getcropDiseaseData = res;
      //console.log(this.getcropDiseaseData, "data");
    });
    this.ls.getcropdisease().subscribe(res => {
      //console.log("data", res);
      this.getcropDiseaseTypeData = res;
      //console.log(this.getcropDiseaseTypeData, "data");
    });

    this.ls.getCropdiseasedata().subscribe(res => {
      //console.log("data", res);
      this.getcropReportDiseaseData = res;
      //console.log(this.getcropReportDiseaseData, "data");
    });

    // listen for search field value changes
    this.CropDiseaseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCropData();
      });

    this.TypeFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDisease();
      });
    this.CropDiseaseCauseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDiseaseType();
      });
  }
  //for crop
  protected filterCropData() {
    //console.log("hello", this.getcropDiseaseData);
    if (!this.getcropDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.CropDiseaseFilterCtrl.value;
    if (!search) {
      this.cropCoun.next(this.getcropDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.cropCoun.next(
      this.getcropDiseaseData.filter(
        bank => bank.CropVarietyName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  //for disease type

  protected filterDiseaseType() {
    //console.log("hello", this.getcropReportDiseaseData);
    if (!this.getcropReportDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.CropDiseaseFilterCtrl.value;
    if (!search) {
      this.cropcause.next(this.getcropReportDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.cropcause.next(
      this.getcropReportDiseaseData.filter(
        bank => bank.Cause.toLowerCase().indexOf(search) > -1
      )
    );
  }
  //for disease
  protected filterDisease() {
    //console.log("hello", this.getcropDiseaseTypeData);
    if (!this.getcropDiseaseTypeData) {
      return;
    }
    // get the search keyword
    let search = this.TypeFilterCtrl.value;
    if (!search) {
      this.croptype.next(this.getcropDiseaseTypeData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.croptype.next(
      this.getcropDiseaseTypeData.filter(
        bank => bank.DiseaseType.toLowerCase().indexOf(search) > -1
      )
    );
  }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displaycropReportdisease() {
    this.ls.getcropreportdiseasedata().subscribe(list => {
      //console.log("mis", list);
      this.isLoading = false;
      this.userCropReportDiseaseData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      //console.log(this.userCropReportDiseaseData, "userCropReportDiseaseData");
      this.listData = new MatTableDataSource(this.userCropReportDiseaseData);
      this.listData.filterPredicate = (data: Crop, filter: string) =>
        data.CropVarietyName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }


  AddCropReportDiseases() {
    this.cropCoun.next(this.cropDiseasedata.slice());
    this.croptype.next(this.cropDiseaseTypedata.slice());
    this.cropcause.next(this.cropReportDiseasedata.slice());
    this.CropReport.reset();
    this.displaycropReportdisease();
    this.CropReportDisease =
      this.CropReportDisease === "CropReportDisease"
        ? "Add CropReportDisease"
        : "CropReportDisease";
    this.editCropReportDisease = !this.editCropReportDisease;
    this.editCropReportDiseasecontent =
      this.editCropReportDiseasecontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl = this.editCropReportDisease ? "inline" : "none";
  }

  CreateCropReportDisease() {

    if (!this.CropReport.valid) {
      Object.keys(this.CropReport.controls).forEach(field => {
        const control = this.CropReport.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.CropReport.controls.created_by.patchValue(1);
      this.ls.savecropreportdiseasedata(this.CropReport.value).subscribe(
        res => {
          //console.log(res, "add");
          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
            this.CropReport.reset();
            this.displaycropReportdisease();
            this.AddCropReportDiseases();
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateCropReportDisease(getCropDiseaseReportDataObj) {
    //console.log(getCropDiseaseReportDataObj);
    this.UpdateCropReportDisease = !this.UpdateCropReportDisease;
    this.EditCropReportDisease = getCropDiseaseReportDataObj;
    this.EditCropReportDisease.Date = this.dp.transform(
      this.EditCropReportDisease.Date,
      "yyyy-MM-dd"
    );

    //console.log(this.EditCropReportDisease);
    this.displayddl = !this.editCropReportDisease ? "inline" : "none";
    this.CropReport.setValue({
      CropCycleID: this.EditCropReportDisease.CropCycleID,
      DiseaseID: this.EditCropReportDisease.DiseaseID,
      Symptoms: this.EditCropReportDisease.Symptoms,
      RiskID: this.EditCropReportDisease.RiskID,
      DiseaseDate: this.EditCropReportDisease.DiseaseDate,
      Impact: this.EditCropReportDisease.Impact,
      Type: this.EditCropReportDisease.Type,
      ContingencyPlan: this.EditCropReportDisease.ContingencyPlan,
      created_by: this.EditCropReportDisease.created_by,
      modified_by: this.EditCropReportDisease.modified_by
    });
  }

  toggleUpdateCropReportDisease2() {
    this.UpdateCropReportDisease = false;
    this.displayddl = this.EditCropReportDisease ? "inline" : "block";
  }

  UpdateCropReportDiseases(getCropDiseaseReportDataObj) {
    //console.log(getCropDiseaseReportDataObj)
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.EditCropReportDisease = getCropDiseaseReportDataObj;
    if (!this.CropReport.valid) {
      Object.keys(this.CropReport.controls).forEach(field => {
        const control = this.CropReport.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ls.updatecropreportdiseaserByID(this.EditCropReportDisease.ID, this.CropReport.value).subscribe(res => {

        if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displaycropReportdisease();
          this.toggleUpdateCropReportDisease2();
        }

      },
        err => console.log(err)
      )
    }
  }

  deleteCropReportDisease(id: string) {
    //console.log(id);

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deletecropreportdiseaseByID(id).subscribe(pdata => {
          if ((pdata["data"] = "Successfully Deleted")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displaycropReportdisease();
          }
        });
      }
    });
  }

  toggleViewCropReportDisease(getCropDiseaseReportDataObj) {
    //console.log(getCropDiseaseReportDataObj);
    this.viewCropReportDisease = !this.viewCropReportDisease;
    this.EditCropReportDisease = getCropDiseaseReportDataObj;
    this.displayddl = !this.EditCropReportDisease ? "inline" : "none";
  }
  toggleViewCropDisease1() {
    this.viewCropReportDisease = false;
    this.displayddl = !this.EditCropReportDisease ? "inline" : "block";
  }
}
