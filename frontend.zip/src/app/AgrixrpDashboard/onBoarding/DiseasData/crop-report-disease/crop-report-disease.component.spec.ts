import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropReportDiseaseComponent } from './crop-report-disease.component';

describe('CropReportDiseaseComponent', () => {
  let component: CropReportDiseaseComponent;
  let fixture: ComponentFixture<CropReportDiseaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropReportDiseaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropReportDiseaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
