export interface CropDisease {
    ID:number;
    DiseaseDesc?: any;
    Symptoms?:any;
    Cause?:any;
    Treatment?:any;
    Image?: any;
    ReferanceURL?:any;
    TblCropMaster_ID?:any;
    created_by?:any;
   modified_by?:any;
}

export interface Crop {
    CropVarietyName?:any;
}