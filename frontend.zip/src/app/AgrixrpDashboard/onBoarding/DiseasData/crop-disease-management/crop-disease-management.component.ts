import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";

import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatSelect,
  MatTableDataSource,
  MatPaginator,
  MatSort
} from "@angular/material";
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from "app/services/masters.service";
import { Crop } from './crop-disease';

@Component({
  selector: 'app-crop-disease-management',
  templateUrl: './crop-disease-management.component.html',
  styleUrls: ['./crop-disease-management.component.scss']
})
export class CropDiseaseManagementComponent implements OnInit {

  CropDiseaseManagement = "CropDisease";
  editCropDiseaseManagementcontent = "add_circle";
  displayddl: string;
  editCropDiseaseManagement = true;
  userCropDiseaseData: any = [];
  EditCropDisease: any = [];
  // getexpenseData: Observable<any[]>;
  UpdateCropDisease = false;
  viewCropDisease = false;

  cropDiseasedata: any = [];

  diseasedata: any[];
  getcropDiseaseData: Crop[] = [];

  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "CropVarietyName", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  /** control for the MatSelect filter keyword */
  public CropDiseaseFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public cropCoun: ReplaySubject<Crop[]> = new ReplaySubject<
    Crop[]
  >(1);
  CropDisease = this.formBuilder.group({
    TblCropMaster_ID: ["", [Validators.required]],
    DiseaseDesc: [""],
    Symptoms: [""],
    Cause: [""],
    Treatment: [""],
    Image: [""],
    fileSource: [""],
    ReferanceURL: [""],
    created_by: [],
    modified_by: []
  });
  CropDisease2 = this.formBuilder.group({
    TblCropMaster_ID: ["", [Validators.required]],
    DiseaseDesc: [""],
    Symptoms: [""],
    Cause: [""],
    Treatment: [""],
    Image: [""],
    ReferanceURL: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(
    private ls: MastersService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  onFileChange(event) {

    if (event.target.files.length > 0) {
      const Image = event.target.files[0];
      this.CropDisease.patchValue({
        fileSource: Image
      });
    }
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.CropDisease.valid) {
      //console.log("Form Submitted");
      this.CropDisease.reset();
    }
  }

  ngOnInit() {


    this.displaycropdisease();

    this.ls.getcropmasterdata().subscribe(res => {
      //console.log("data", res);
      this.getcropDiseaseData = res;
      //console.log(this.getcropDiseaseData, "data");
    });

    // listen for search field value changes
    this.CropDiseaseFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCropData();
      });
  }

  protected filterCropData() {
    //console.log("hello", this.getcropDiseaseData);
    if (!this.getcropDiseaseData) {
      return;
    }
    // get the search keyword
    let search = this.CropDiseaseFilterCtrl.value;
    if (!search) {
      this.cropCoun.next(this.getcropDiseaseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.cropCoun.next(
      this.getcropDiseaseData.filter(
        bank => bank.CropVarietyName.toLowerCase().indexOf(search) > -1
      )
    );
  }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displaycropdisease() {
    this.ls.getCropdiseasedata().subscribe(list => {
      //console.log("mis", list);
      this.isLoading = false;
      this.userCropDiseaseData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      //console.log(this.userCropDiseaseData, "userCropDiseaseData");
      this.listData = new MatTableDataSource(this.userCropDiseaseData);
      this.listData.filterPredicate = (data: Crop, filter: string) =>
        data.CropVarietyName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }


  AddCropDiseases() {


    this.cropCoun.next(this.cropDiseasedata.slice());
    this.CropDisease.reset();
    this.displaycropdisease();
    this.CropDiseaseManagement =
      this.CropDiseaseManagement === "CropDisease"
        ? "Add CropDisease"
        : "CropDisease";
    this.editCropDiseaseManagement = !this.editCropDiseaseManagement;
    this.editCropDiseaseManagementcontent =
      this.editCropDiseaseManagementcontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl = this.editCropDiseaseManagement ? "inline" : "none";
  }

  CreateCropDisease() {
    const formData = new FormData();
    formData.append('Image', this.CropDisease.get('fileSource').value);
    if (!this.CropDisease.valid) {
      Object.keys(this.CropDisease.controls).forEach(field => {
        const control = this.CropDisease.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.CropDisease.controls.created_by.patchValue(1);
      this.ls.saveCropdiseasedata(this.CropDisease.value).subscribe(
        res => {
          //console.log(res, "add");
          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
            this.CropDisease.reset();
            this.displaycropdisease();
            this.AddCropDiseases();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The CropDisease",
              showConfirmButton: false,
              timer: 1500
            });
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateCropDisease(getCropDiseaseDataObj) {
    //console.log(getCropDiseaseDataObj);
    this.UpdateCropDisease = !this.UpdateCropDisease;
    this.EditCropDisease = getCropDiseaseDataObj;

    //console.log(this.EditCropDisease);
    this.displayddl = !this.editCropDiseaseManagement ? "inline" : "none";
    this.CropDisease2.setValue({
      TblCropMaster_ID: this.EditCropDisease.TblCropMaster_ID,
      DiseaseDesc: this.EditCropDisease.DiseaseDesc,
      Symptoms: this.EditCropDisease.Symptoms,
      Cause: this.EditCropDisease.Cause,
      Treatment: this.EditCropDisease.Treatment,
      Image: this.EditCropDisease.Image,
      ReferanceURL: this.EditCropDisease.ReferanceURL,
      created_by: this.EditCropDisease.created_by,
      modified_by: this.EditCropDisease.modified_by
    });
  }

  toggleUpdateCropDisease2() {
    this.UpdateCropDisease = false;
    this.displayddl = this.EditCropDisease ? "inline" : "block";
  }

  UpdateCropDiseases(getCropDiseaseDataObj) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.EditCropDisease = getCropDiseaseDataObj;
    if (!this.CropDisease2.valid) {
      Object.keys(this.CropDisease2.controls).forEach(field => {
        const control = this.CropDisease2.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ls.updateCropdiseaseByID(this.EditCropDisease.ID, this.CropDisease2.value).subscribe(res => {

        if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displaycropdisease();
          this.toggleUpdateCropDisease2();
        }

      },
        err => console.log(err)
      )
    }
  }

  deleteCropDisease(id: string) {
    //console.log(id);

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deleteCropdiseaseByID(id).subscribe(pdata => {
          if ((pdata["data"] = "success")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displaycropdisease();
          }
        });
      }
    });
  }

  toggleViewCropDisease(getCropDiseaseDataObj) {
    //console.log(getCropDiseaseDataObj);
    this.viewCropDisease = !this.viewCropDisease;
    this.EditCropDisease = getCropDiseaseDataObj;
    this.displayddl = !this.EditCropDisease ? "inline" : "none";
  }
  toggleViewCropDisease1() {
    this.viewCropDisease = false;
    this.displayddl = !this.EditCropDisease ? "inline" : "block";
  }
}
