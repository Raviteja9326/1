import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { DiseaseRoutingModule } from './disease-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { MatTableExporterModule } from 'mat-table-exporter';
import { DiseaseComponent } from './disease.component';
import { AnimaldiseasemanagementComponent } from './animaldiseasemanagement/animaldiseasemanagement.component';
import { AnimalreportdiseaseComponent } from './animalreportdisease/animalreportdisease.component';
import { CropDiseaseManagementComponent } from './crop-disease-management/crop-disease-management.component';
import { CropReportDiseaseComponent } from './crop-report-disease/crop-report-disease.component';
import { DiseasetypeComponent } from './diseasetype/diseasetype.component';
import { ConsultexpertComponent } from './consultexpert/consultexpert.component';
// tslint:disable-next-line:max-line-length
const components = [DiseaseComponent, AnimaldiseasemanagementComponent, AnimalreportdiseaseComponent, CropDiseaseManagementComponent, CropReportDiseaseComponent, DiseasetypeComponent, ConsultexpertComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [DiseaseRoutingModule, CommonModule, MatTableExporterModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class DiseaseModule { }
