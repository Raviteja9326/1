import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WatermasterComponent } from './watermaster.component';

describe('WatermasterComponent', () => {
  let component: WatermasterComponent;
  let fixture: ComponentFixture<WatermasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WatermasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WatermasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
