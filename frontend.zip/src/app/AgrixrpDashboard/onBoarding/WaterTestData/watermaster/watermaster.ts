export interface WaterMaster {
    ID?: number;
    Name?: any;
    Symbol?: any;
    UnitType?: any;
    VeryLow?: any;
    Low?: any;
    Medium?: any;
    High?: any;
    VeryHigh?: any;
    TblWaterCategory_ID?: number;
    created_by: string;
    modified_by: string;
}
