import { Component, OnInit, ViewChild } from '@angular/core';
import { WaterMaster } from './watermaster';
import { MastersService } from "app/services/masters.service";
import { FormGroup, FormControl, FormArray, Validators, FormBuilder } from '@angular/forms';
import { tap, startWith, debounceTime, switchMap, map, takeUntil } from 'rxjs/operators';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';
import { MatTableDataSource, MatPaginator, MatSort, MatSelect } from '@angular/material';
import { ReplaySubject, Subject } from 'rxjs';
import { Watercategory } from '../watercategory/Watercategory';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
@Component({
  selector: 'app-watermaster',
  templateUrl: './watermaster.component.html',
  styleUrls: ['./watermaster.component.scss']
})
export class WatermasterComponent implements OnInit {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['ID', 'Name', 'Actions'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  watermastertypes = "Water Master";
  edittype = "add_circle";
  displayddl: string;
  editwatermastertype = true;
  userwatermasterTypeData: any = [];
  EditWaterMaster: any = [];
  updatewatermaster = false;
  viewWatermaster = false;
  waterData: Watercategory[] = [];
  Water: any = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  /** control for the MatSelect filter keyword */
  public CatFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCat: ReplaySubject<Watercategory[]> = new ReplaySubject<Watercategory[]>(1);
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();
  watermaster = this.formBuilder.group({
    Name: ['', [Validators.required]],
    Symbol: ['', [Validators.required]],
    UnitType: [''],
    VeryLow: [''],
    Low: [''],
    Medium: [''],
    High: [''],
    VeryHigh: [''],
    TblWaterCategory_ID: ['', [Validators.required]],
    modified_by: [],
    created_by: []
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    // this.isLoading = true;
    this.displayWaterMaster();
    this.ls.getWaterCatData().subscribe(res => {
      this.waterData = res;

    });
    // listen for search field value changes
    this.CatFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterWaterCat();
      });
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  protected filterWaterCat() {
    if (!this.waterData) {
      return;
    }
    // get the search keyword
    let search = this.CatFilterCtrl.value;

    if (!search) {
      this.filteredCat.next(this.waterData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCat.next(
      this.waterData.filter(bank => bank.WaterCategory.toLowerCase().indexOf(search) > -1)
    );
  }


  displayWaterMaster() {
    this.ls.getWaterMasterData().subscribe(
      list => {
        this.isLoading = false;
        this.Water = list;
        if (this.Water.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.Water);
        /* config filter */
        this.listData.filterPredicate =
          (data: WaterMaster, filter: string) => data.Name.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
    );
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.watermaster.valid) {
      this.watermaster.reset();
    }
  }



  Addwatermaster() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.filteredCat.next(this.waterData.slice())
    this.watermaster.reset();
    this.displayWaterMaster();
    this.watermastertypes =
      this.watermastertypes === "Water Master" ? "Add Water Master" : "Water Master";
    this.editwatermastertype = !this.editwatermastertype;
    this.edittype =
      this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editwatermastertype ? "inline" : "none";
  }

  CreateWaterMasterType() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.watermaster.valid) {
      Object.keys(this.watermaster.controls).forEach(field => {
        const control = this.watermaster.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.watermaster.controls.created_by.patchValue(0);
      this.ls.savewatermasterdata(this.watermaster.value).subscribe(
        res => {
          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the WaterCategory',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.resetForm();
            this.displayWaterMaster();
            this.Addwatermaster();
          } else if (res['data'] = "serverErrorStateExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The Animal Category',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }

  }

  toggleUpdateWatermaster(getWatermasterDataObj) {
    this.updatewatermaster = !this.updatewatermaster;
    this.EditWaterMaster = getWatermasterDataObj;
    this.displayddl = !this.updatewatermaster ? "inline" : "none";
    this.watermaster.controls.modified_by.patchValue(0);
    this.watermaster.setValue({
      Name: this.EditWaterMaster.Name,
      Symbol: this.EditWaterMaster.Symbol,
      UnitType: this.EditWaterMaster.UnitType,
      VeryLow: this.EditWaterMaster.VeryLow,
      Low: this.EditWaterMaster.Low,
      Medium: this.EditWaterMaster.Medium,
      High: this.EditWaterMaster.High,
      VeryHigh: this.EditWaterMaster.VeryHigh,
      TblWaterCategory_ID: this.EditWaterMaster.TblWaterCategory_ID,
      created_by: this.EditWaterMaster.created_by,
      modified_by: this.EditWaterMaster.modified_by
    });
  }

  toggleUpdatewatermaster2() {
    this.updatewatermaster = false;
    this.displayddl = this.EditWaterMaster ? "inline" : "block";
  }

  UpdateWaterMasterType(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.EditWaterMaster = data;
    if (!this.watermaster.valid) {
      Object.keys(this.watermaster.controls).forEach(field => {
        const control = this.watermaster.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Required Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.watermaster.controls.modified_by.patchValue(0);
      this.ls.updateWaterMasterById(this.EditWaterMaster.ID, this.watermaster.value).subscribe(res => {
        if (this.EditWaterMaster.TblWaterCategory_ID === this.watermaster.controls.TblWaterCategory_ID.value &&
          this.EditWaterMaster.Name === this.watermaster.controls.Name.value &&
          this.EditWaterMaster.Symbol === this.watermaster.controls.Symbol.value &&
          this.EditWaterMaster.UnitType === this.watermaster.controls.UnitType.value &&
          this.EditWaterMaster.VeryLow === this.watermaster.controls.VeryLow.value &&
          this.EditWaterMaster.Low === this.watermaster.controls.Low.value &&
          this.EditWaterMaster.Medium === this.watermaster.controls.Medium.value &&
          this.EditWaterMaster.High === this.watermaster.controls.High.value &&
          this.EditWaterMaster.VeryHigh === this.watermaster.controls.VeryHigh.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayWaterMaster();
          this.toggleUpdatewatermaster2();
        }
      },

      )
    }
  }

  deleteWatermaster(id: string) {

    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ls.deleteWaterMasterById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayWaterMaster();
            }
          }
        )
      }
    })
  }

  toggleViewWatermastertype(getWatermasterDataObj) {
    this.viewWatermaster = !this.viewWatermaster;
    this.EditWaterMaster = getWatermasterDataObj;
    this.displayddl = !this.EditWaterMaster ? "inline" : "none";
  }
  toggleViewWaterMaster1() {
    this.viewWatermaster = false;
    this.displayddl = !this.EditWaterMaster ? "inline" : "block";
  }

}
