import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watertest',
  templateUrl: './watertest.component.html',
  styleUrls: ['./watertest.component.scss']
})
export class WatertestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
