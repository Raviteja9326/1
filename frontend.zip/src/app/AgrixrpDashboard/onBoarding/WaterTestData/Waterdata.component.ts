import { Component } from '@angular/core';

@Component({
  selector: 'app-waterdata',
  template: `<router-outlet></router-outlet>`,
})

export class WaterdataComponent {
}
