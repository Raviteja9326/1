import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { WaterdataRoutingModule } from './Waterdata-routing.module';
import { WaterdataComponent } from './Waterdata.component';
import { WatercategoryComponent } from './watercategory/watercategory.component';
import { WatermasterComponent } from './watermaster/watermaster.component';
import { WatertestComponent } from './watertest/watertest.component';
import { WatercorrectionComponent } from './watercorrection/watercorrection.component';
// tslint:disable-next-line:max-line-length
const components = [WaterdataComponent, WatercategoryComponent, WatermasterComponent, WatertestComponent,
    WatercorrectionComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [WaterdataRoutingModule, CommonModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components
    ],
})
export class WaterdataModule { }