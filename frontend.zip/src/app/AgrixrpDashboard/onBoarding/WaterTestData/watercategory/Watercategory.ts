export interface Watercategory {
    ID?:number;
    WaterCategory?: string;
    WaterCategorySource?: string;
    created_by:string;
    modified_by:string;
}
