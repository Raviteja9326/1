import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WatercategoryComponent } from './watercategory.component';

describe('WatercategoryComponent', () => {
  let component: WatercategoryComponent;
  let fixture: ComponentFixture<WatercategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WatercategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WatercategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
