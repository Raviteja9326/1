import { Component, OnInit, ViewChild } from "@angular/core";
import { Watercategory } from "./Watercategory";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import { MastersService } from "app/services/masters.service";
import Swal from "sweetalert2";
import { MatTableDataSource, MatPaginator, MatSort } from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";

@Component({
  selector: "app-watercategory",
  templateUrl: "./watercategory.component.html",
  styleUrls: ["./watercategory.component.scss"]
})
export class WatercategoryComponent implements OnInit {
  editwatertype = true;
  edittype = "add_circle";
  watertypes = "Water Category";
  displayddl: String;
  updateWatercat = false;
  EditWaterCat: any = [];
  viewWaterCat = false;
  submitted = false;
  userwaterTypeData: any = [];
  EditOldData: any = [];
  WaterCat: any = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "WaterCategory", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  // tslint:disable-next-line:member-ordering
  watercat = this.formBuilder.group({
    WaterCategory: ["", [Validators.required]],
    WaterCategorySource: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.isLoading = true;
    this.displayWaterCat();
  }

  displayWaterCat() {
    this.ls.getWaterCatData().subscribe(list => {
      this.isLoading = false;
      this.WaterCat = list;
      if (this.WaterCat.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.WaterCat);
      /* config filter */
      this.listData.filterPredicate = (data: Watercategory, filter: string) =>
        data.WaterCategory.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.watercat.valid) {
      this.watercat.reset();
    }
  }

  Addwater() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.watercat.reset();
    this.watertypes =
      this.watertypes === "Water Category"
        ? "Add Water Category"
        : "Water Category";
    this.editwatertype = !this.editwatertype;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editwatertype ? "inline" : "none";
    this.displayWaterCat();
  }

  CreateWaterType() {
    this.submitted = true;
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.watercat.valid) {
      Object.keys(this.watercat.controls).forEach(field => {
        const control = this.watercat.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.watercat.controls.created_by.patchValue(1);
      this.ls.saveWaterCatData(this.watercat.value).subscribe(
        res => {

          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the WaterCategory",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.watercat.reset();
            this.displayWaterCat();
            this.Addwater();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The WaterCategory Name",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  updateWaterCat1(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.watercat.valid) {
      Object.keys(this.watercat.controls).forEach(field => {
        const control = this.watercat.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.watercat.controls.modified_by.patchValue(1);
      this.ls
        .updateWaterCatDataById(this.EditWaterCat.ID, this.watercat.value)
        .subscribe(
          res => {
            if (
              this.EditWaterCat.WaterCategory ===
              this.watercat.controls.WaterCategory.value &&
              this.EditWaterCat.WaterCategorySource ===
              this.watercat.controls.WaterCategorySource.value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1000
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1000
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayWaterCat();
              this.toggleUpdatewatertype2();
            }
          },

        );
    }
  }

  toggleUpdateWatertype(getWatertypeDataObj) {
    this.EditWaterCat = getWatertypeDataObj;
    this.updateWatercat = !this.updateWatercat;
    this.displayddl = !this.editwatertype ? "inline" : "none";
    this.watercat.setValue({
      WaterCategory: this.EditWaterCat.WaterCategory,
      WaterCategorySource: this.EditWaterCat.WaterCategorySource,
      created_by: this.EditWaterCat.created_by,
      modified_by: this.EditWaterCat.modified_by
    });
  }

  toggleUpdatewatertype2() {
    this.updateWatercat = false;
    this.displayddl = this.editwatertype ? "inline" : "block";
  }

  toggleViewWatertype(getWatertypeDataObj) {
    this.viewWaterCat = !this.viewWaterCat;
    this.EditWaterCat = getWatertypeDataObj;
    this.displayddl = !this.editwatertype ? "inline" : "none";
  }

  toggleViewWaterCat1() {
    this.viewWaterCat = false;
    this.displayddl = !this.editwatertype ? "inline" : "block";
  }

  deleteWatertype(id: string) {

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteWaterCatDataById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayWaterCat();
          }
        });
      }
    });
  }
}
