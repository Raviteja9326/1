import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watercorrection',
  templateUrl: './watercorrection.component.html',
  styleUrls: ['./watercorrection.component.scss']
})
export class WatercorrectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
