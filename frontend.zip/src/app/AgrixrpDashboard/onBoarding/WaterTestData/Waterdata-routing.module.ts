import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WaterdataComponent } from './Waterdata.component';
import { WatercategoryComponent } from './watercategory/watercategory.component';
import { WatermasterComponent } from './watermaster/watermaster.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
import { WatertestComponent } from './watertest/watertest.component';
import { WatercorrectionComponent } from './watercorrection/watercorrection.component';

const routes: Routes = [{
    path: '',
    component: WaterdataComponent,
    children: [{
        path: 'Water Category',
        component: WatercategoryComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Water Master',
        component: WatermasterComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Water Test Data',
        component: WatertestComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Water Test Corrections',
        component: WatercorrectionComponent, canActivate: [AuthGuardService]
    }
    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class WaterdataRoutingModule { }
