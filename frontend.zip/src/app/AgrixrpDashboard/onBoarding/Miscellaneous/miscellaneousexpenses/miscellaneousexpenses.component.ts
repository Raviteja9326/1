import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";
import { MastersService } from "app/services/masters.service";
import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import { MiscellaneousExpenses } from "./miscllaneousexpenses";
import { Miscellaneous } from "./miscllaneousexpenses";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatSelect,
  MatTableDataSource,
  MatPaginator,
  MatSort
} from "@angular/material";
import { Expenses, supplier } from "./expenses";
import { MatProgressButtonOptions } from "mat-progress-buttons";
@Component({
  selector: "app-miscellaneousexpenses",
  templateUrl: "./miscellaneousexpenses.component.html",
  styleUrls: ["./miscellaneousexpenses.component.scss"]
})
export class MiscellaneousexpensesComponent implements OnInit {
  MiscellaneousExpensetype = "Expenses";
  editMiscellaneousExpensecontent = "add_circle";
  displayddl: string;
  editMiscellaneousExpense = true;
  userMiscellaneousData: any = [];
  EditMiscellaneous: any = [];
  // getexpenseData: Observable<any[]>;
  updateMiscellaneous = false;
  viewMiscellaneous = false;

  supplierdata: any = [];
  userMiscellanousData: any = [];
  expensedata: any[];
  getexpenseData: Expenses[] = [];
  getsupplierData: supplier[] = [];
  CounFilterCtrl: Observable<any[]>;
  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "ExpenseTypes", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  /** control for the MatSelect filter keyword */
  public ExpensesFilterCtrl: FormControl = new FormControl();
  public SupplierFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public ExpensesCoun: ReplaySubject<Expenses[]> = new ReplaySubject<
    Expenses[]
  >(1);
  public SupplierCoun: ReplaySubject<supplier[]> = new ReplaySubject<
    supplier[]
  >(1);

  Miscellaneous = this.formBuilder.group({
    TblExpensesTypes_ID: ["", [Validators.required]],
    Amount: [
      "",
      [Validators.required, Validators.pattern("^-?[0-9]\\d*(\\,\\d{1,10})?$")]
    ],
    Date: [""],
    PaidTo: [""],
    InvoiceNo: ["", [Validators.pattern("^[0-9]*$")]],
    AccountCode: ["", [Validators.pattern("^[0-9]*$")]],
    TblSupplier_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  constructor(
    private ls: MastersService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.Miscellaneous.valid) {
      this.Miscellaneous.reset();
    }
  }

  ngOnInit() {
    this.displaymiscellaneous();

    this.ls.getExpenseTypeData().subscribe(res => {
      this.getexpenseData = res;
    });

    // listen for search field value changes
    this.ExpensesFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterExpenses();
      });

    this.ls.getSupplierData().subscribe(res => {
      this.getsupplierData = res;
    });
    // listen for search field value changes
    this.SupplierFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.supplier();
      });
  }

  protected filterExpenses() {
    if (!this.getexpenseData) {
      return;
    }
    // get the search keyword
    let search = this.ExpensesFilterCtrl.value;
    if (!search) {
      this.ExpensesCoun.next(this.getexpenseData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.ExpensesCoun.next(
      this.getexpenseData.filter(
        bank => bank.ExpenseTypes.toLowerCase().indexOf(search) > -1
      )
    );
  }
  protected supplier() {
    if (!this.getsupplierData) {
      return;
    }
    // get the search keyword
    let search = this.SupplierFilterCtrl.value;
    if (!search) {
      this.SupplierCoun.next(this.getsupplierData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.SupplierCoun.next(
      this.getsupplierData.filter(
        bank => bank.SupplierType.toLowerCase().indexOf(search) > -1
      )
    );
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displaysupplier(id) {
    if (!id) {
      return "";
    }

    const index = this.supplierdata.findIndex(
      supplierobj => supplierobj.ID === id
    );

    return this.supplierdata[index].SupplierType;
  }
  doFiltersupplier(value) {
    return this.ls.getSupplierData().pipe(
      map(response =>
        response.filter(option => {
          if (typeof value === "string") {
            return (
              option.SupplierType.toLowerCase().indexOf(value.toLowerCase()) ===
              0
            );
          } else {
            return option.SupplierType.toLowerCase().indexOf(value) === 0;
          }
        })
      )
    );
  }
  displaymiscellaneous() {
    this.ls.getmiscellaneous().subscribe(list => {
      this.isLoading = false;
      this.userMiscellanousData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userMiscellanousData);
      this.listData.filterPredicate = (data: Miscellaneous, filter: string) =>
        data.ExpenseTypes.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  AddMiscellaneous() {
    this.ExpensesCoun.next(this.getexpenseData.slice());
    this.SupplierCoun.next(this.getsupplierData.slice());
    this.Miscellaneous.reset();
    this.displaymiscellaneous();
    this.MiscellaneousExpensetype =
      this.MiscellaneousExpensetype === "Expenses"
        ? "Add Expenses"
        : "Expenses";
    this.editMiscellaneousExpense = !this.editMiscellaneousExpense;
    this.editMiscellaneousExpensecontent =
      this.editMiscellaneousExpensecontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl = this.editMiscellaneousExpense ? "inline" : "none";
  }

  CreateMiscellaneous() {
    if (!this.Miscellaneous.valid) {
      Object.keys(this.Miscellaneous.controls).forEach(field => {
        const control = this.Miscellaneous.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.Miscellaneous.controls.created_by.patchValue(1);
      this.ls.savemiscellaneousdata(this.Miscellaneous.value).subscribe(
        res => {
          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the MiscllaneousExpense",
              showConfirmButton: false,
              timer: 1500
            });
            this.Miscellaneous.reset();
            this.displaymiscellaneous();
            this.AddMiscellaneous();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Miscellaneous",
              showConfirmButton: false,
              timer: 1500
            });
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdatelMiscellaneous(getMiscellaneousDataObj) {
    this.updateMiscellaneous = !this.updateMiscellaneous;
    this.EditMiscellaneous = getMiscellaneousDataObj;
    this.EditMiscellaneous.Date = this.dp.transform(
      this.EditMiscellaneous.Date,
      "yyyy-MM-dd"
    );
    this.displayddl = !this.editMiscellaneousExpense ? "inline" : "none";
    this.Miscellaneous.setValue({
      TblExpensesTypes_ID: this.EditMiscellaneous.TblExpensesTypes_ID,
      Amount: this.EditMiscellaneous.Amount,
      Date: this.EditMiscellaneous.Date,
      PaidTo: this.EditMiscellaneous.PaidTo,
      InvoiceNo: this.EditMiscellaneous.InvoiceNo,
      AccountCode: this.EditMiscellaneous.AccountCode,
      TblSupplier_ID: this.EditMiscellaneous.TblSupplier_ID,
      created_by: this.EditMiscellaneous.created_by,
      modified_by: this.EditMiscellaneous.modified_by
    });
  }

  toggleUpdateMiscellaneous2() {
    this.updateMiscellaneous = false;
    this.displayddl = this.EditMiscellaneous ? "inline" : "block";
  }
  UpdateMiscellaneous(res) {
    this.EditMiscellaneous = res;
    if (!this.Miscellaneous.valid) {
      Object.keys(this.Miscellaneous.controls).forEach(field => {
        const control = this.Miscellaneous.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      this.Miscellaneous.controls.modified_by.patchValue(0);
      this.ls
        .updatemiscellaneousById(
          this.EditMiscellaneous.ID,
          this.Miscellaneous.value
        )
        .subscribe(
          pdata => {
            // tslint:disable-next-line:max-line-length
            if (
              this.EditMiscellaneous.TblExpensesTypes_ID ===
              this.Miscellaneous.controls.TblExpensesTypes_ID.value &&
              this.EditMiscellaneous.Amount ===
              this.Miscellaneous.controls.Amount.value &&
              this.EditMiscellaneous.Date ===
              this.Miscellaneous.controls.Date.value &&
              // tslint:disable-next-line:max-line-length
              this.EditMiscellaneous.PaidTo ===
              this.Miscellaneous.controls.PaidTo.value &&
              this.EditMiscellaneous.InvoiceNo ===
              this.Miscellaneous.controls.InvoiceNo.value &&
              this.EditMiscellaneous.AccountCode ===
              this.Miscellaneous.controls.AccountCode.value &&
              this.EditMiscellaneous.TblSupplier_ID ===
              this.Miscellaneous.controls.TblSupplier_ID.value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
            } else if (pdata["data"] === "Successfully Updated") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.displaymiscellaneous();
              this.toggleUpdateMiscellaneous2();
            }
          },

        );
    }
  }

  deleteMiscellaneous(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deletemiscellaneousById(id).subscribe(pdata => {
          if ((pdata["data"] = "Successfully Deleted")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displaymiscellaneous();
          }
        });
      }
    });
  }

  toggleViewMiscellaneous(getAmountDataObj) {
    this.viewMiscellaneous = !this.viewMiscellaneous;
    this.EditMiscellaneous = getAmountDataObj;
    this.displayddl = !this.EditMiscellaneous ? "inline" : "none";
  }
  toggleViewMiscellaneous1() {
    this.viewMiscellaneous = false;
    this.displayddl = !this.EditMiscellaneous ? "inline" : "block";
  }
}
