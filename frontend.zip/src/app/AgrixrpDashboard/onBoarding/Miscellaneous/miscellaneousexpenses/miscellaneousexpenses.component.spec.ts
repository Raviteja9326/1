import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiscellaneousexpensesComponent } from './miscellaneousexpenses.component';

describe('MiscellaneousexpensesComponent', () => {
  let component: MiscellaneousexpensesComponent;
  let fixture: ComponentFixture<MiscellaneousexpensesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiscellaneousexpensesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiscellaneousexpensesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
