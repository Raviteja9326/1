export interface MiscellaneousExpenses{
    ID: 0,
    TblExpensesTypes_ID?:number,
    Amount?: any,
    Date?: any,
    PaidTo?: any,
    InvoiceNo?: any,
    AccountCode?: any,
    TblSupplier_ID:number,
    Created_by?:any  ,
    Modified_by?: any,
}
export interface Miscellaneous{
    ExpenseTypes?:any;
}