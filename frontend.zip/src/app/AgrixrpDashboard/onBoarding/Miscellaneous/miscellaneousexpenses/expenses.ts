export interface Expenses{
    ExpenseTypes?: any,
}
export interface supplier{
    SupplierType?: any,
}