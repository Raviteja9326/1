import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'
import { MiscellaneousexpensesComponent } from './miscellaneousexpenses/miscellaneousexpenses.component';
import { MiscellaneousComponent } from './miscellaneous.compont';
import { LabourhoursComponent } from './labourhours/labourhours.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';


const routes: Routes = [{
    path: '',
    component: MiscellaneousComponent,
    children: [
        {
            path: 'Expenses',
            component: MiscellaneousexpensesComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Labour Hours',
            component: LabourhoursComponent, canActivate: [AuthGuardService]
        }
    ]

}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class MiscellaneousRoutingModule { }
