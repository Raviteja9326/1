import { Component, OnInit, ViewChild } from "@angular/core";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { MastersService } from "app/services/masters.service";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { takeUntil } from "rxjs/operators";
import { Subject, ReplaySubject } from "rxjs";
import { Labour } from "../../FarmerData/labourinformation/Labour";
import { location, LabourActy } from "app/services/Dataservices";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import Swal from "sweetalert2";
import { Labourhours } from "./labourhours";

@Component({
  selector: "app-labourhours",
  templateUrl: "./labourhours.component.html",
  styleUrls: ["./labourhours.component.scss"]
})
export class LabourhoursComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "LabourName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /*for labourhours data */
  labourlistData: MatTableDataSource<any>;
  displayedColumns1: string[] = [
    "Date",
    "Name",
    "ActyName",
    "StartTime",
    "EndTIme",
    "OverTime",
    "Hours"
  ];

  /*labour hours data ends */

  /** control for the MatSelect filter keyword */
  public LabourFilterCtrl: FormControl = new FormControl();
  public LocationFilterCtrl: FormControl = new FormControl();
  public ActivityFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredLabour: ReplaySubject<Labour[]> = new ReplaySubject<Labour[]>(
    1
  );
  public filteredLocation: ReplaySubject<location[]> = new ReplaySubject<
    location[]
  >(1);
  public filteredActivity: ReplaySubject<LabourActy[]> = new ReplaySubject<
    LabourActy[]
  >(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  LabourHours = this.formBuilder.group({
    Date: ["", [Validators.required]],
    Hours: ["", [Validators.pattern("^[0-9]*$")]],
    PercentageOfWork: ["", [Validators.pattern("^[0-9]*$")]],
    StartTime: ["", [Validators.required]],
    EndTIme: ["", [Validators.required]],
    OverTime: [""],
    PayID: [""],
    TblLabour_ID: ["", [Validators.required]],
    TblLocation_ID: ["", [Validators.required]],
    TblLabourActy_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  LabourData: Labour[] = [];
  LocationData: location[] = [];
  ActivityData: LabourActy[] = [];
  labourhours = "LabourHoursData";
  editdata = "add_circle";
  displayddl: string;
  editlabourhours = true;
  viewlabourhoursData = false;
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;
  userlabourhoursData: any;
  getdatabyid: any;
  singlelabourdata: any[];

  constructor(private formBuilder: FormBuilder, private ls: MastersService) { }

  ngOnInit() {
    this.dispalyLabourHoursData();
    // for labour
    this.ls.getLabourinfoData().subscribe(res => {
      this.LabourData = res;
    });

    // listen for search field value changes
    this.LabourFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterLabour();
      });
    // labour end

    // for location data
    this.ls.getlocationdata().subscribe(res => {
      this.LocationData = res;
    });

    // listen for search field value changes
    this.LocationFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterLocation();
      });
    // location end

    // for Activity data
    this.ls.getActivitydata().subscribe(res => {
      this.ActivityData = res;
    });

    // listen for search field value changes
    this.ActivityFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterActivity();
      });
    // Activity end
  }

  /*units data*/
  protected filterLabour() {
    if (!this.LabourData) {
      return;
    }
    // get the search keyword
    let search = this.LabourFilterCtrl.value;

    if (!search) {
      this.filteredLabour.next(this.LabourData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredLabour.next(
      this.LabourData.filter(
        bank => bank.FullName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*units data ends*/

  /*location data */
  protected filterLocation() {
    if (!this.LocationData) {
      return;
    }
    // get the search keyword
    let search = this.LocationFilterCtrl.value;

    if (!search) {
      this.filteredLocation.next(this.LocationData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredLocation.next(
      this.LocationData.filter(
        bank => bank.Name.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*location data ends*/

  /*Activity data */
  protected filterActivity() {
    if (!this.ActivityData) {
      return;
    }
    // get the search keyword
    let search = this.ActivityFilterCtrl.value;

    if (!search) {
      this.filteredActivity.next(this.ActivityData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredActivity.next(
      this.ActivityData.filter(
        bank => bank.ActyName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*Activity data ends*/

  AddLabourHours() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredLabour.next(this.LabourData.slice());
    this.filteredLocation.next(this.LocationData.slice());
    this.filteredActivity.next(this.ActivityData.slice());
    this.LabourHours.reset();
    this.editdata = this.editdata === "cancel" ? "add_circle" : "cancel";
    this.labourhours =
      this.labourhours === "LabourHoursData"
        ? "Add LabourHoursData"
        : "LabourHoursData";
    this.editlabourhours = !this.editlabourhours;
    this.resetForm();
    this.displayddl = this.editlabourhours ? "inline" : "none";
    this.dispalyLabourHoursData();
  }

  resetForm() {
    if (this.LabourHours.valid) {
      this.LabourHours.reset();
    }
  }

  dispalyLabourHoursData() {
    this.ls.getLabourinfoData().subscribe(list => {
      this.isLoading = false;
      this.userlabourhoursData = list;
      if (this.userlabourhoursData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userlabourhoursData);
      /* config filter */
      this.listData.filterPredicate = (data: Labour, filter: string) =>
        data.FullName.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  createLabourHours() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.LabourHours.valid) {
      Object.keys(this.LabourHours.controls).forEach(field => {
        const control = this.LabourHours.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.LabourHours.controls.created_by.patchValue(0);
      this.ls.saveLabourHoursData(this.LabourHours.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the LabourHours",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.dispalyLabourHoursData();
            this.AddLabourHours();
          } else if ((res["data"] = "LabourHoursData already exists!")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The LabourHoursData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleViewLabourHours(id: string) {
    ;
    this.ls.getLabourHoursDataById(id).subscribe(res => {
      this.singlelabourdata = res;
      if (this.singlelabourdata.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.labourlistData = new MatTableDataSource(this.singlelabourdata);
    });
    this.viewlabourhoursData = !this.viewlabourhoursData;
    this.displayddl = !this.editlabourhours ? "inline" : "none";
  }

  toggleViewlabourhoursData1() {
    this.displayNoRecords = false;
    this.viewlabourhoursData = false;
    this.singlelabourdata = [];
    this.displayddl = !this.editlabourhours ? "inline" : "block";
  }
}
