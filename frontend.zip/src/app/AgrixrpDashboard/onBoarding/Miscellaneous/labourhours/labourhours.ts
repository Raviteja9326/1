export interface Labourhours {
  ID?: number;
  Date?: any;
  Hours?: any;
  PercentageOfWork?: any;
  StartTime?: any;
  EndTIme?: any;
  OverTime?: any;
  PayID?: any;
  TblLabour_ID?: number;
  TblLocation_ID?: number;
  TblLabourActy_ID?: number;
  created_by: any;
  modified_by: any;
}
