import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabourhoursComponent } from './labourhours.component';

describe('LabourhoursComponent', () => {
  let component: LabourhoursComponent;
  let fixture: ComponentFixture<LabourhoursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabourhoursComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabourhoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
