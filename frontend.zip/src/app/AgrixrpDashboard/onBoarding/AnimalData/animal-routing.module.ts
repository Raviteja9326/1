import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnimalComponent } from './animal.component';
import { AnimalbreedComponent } from './animalbreed/animalbreed.component';
import { AnimalcategoryComponent } from './animalcategory/animalcategory.component';
import { AnimalcopComponent } from './animalcop/animalcop.component';
import { AnimalhistoryComponent } from './animalhistory/animalhistory.component';
import { AnimalmasterComponent } from './animalmaster/animalmaster.component';
import { VaccinationComponent } from './vaccination/vaccination.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';


const routes: Routes = [{
    path: '',
    component: AnimalComponent,
    children: [{
        path: 'Animal Breed',
        component: AnimalbreedComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Animal Category',
        component: AnimalcategoryComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Animal Calender Of Operations',
        component: AnimalcopComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Animal Cycle',
        component: AnimalhistoryComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Animal Master',
        component: AnimalmasterComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Animal Vaccination',
        component: VaccinationComponent, canActivate: [AuthGuardService]
    }],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AnimalRoutingModule { }
