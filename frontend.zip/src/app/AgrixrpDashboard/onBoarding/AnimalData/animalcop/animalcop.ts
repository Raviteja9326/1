export interface AnimalCop {
    ID: number;
    COPNO: any;
    Activity: any;
    AnimalMilestoneID: number;
    CriticalActivity: any;
    Dependency: number;
    Dose: any;
    AgeofDose: any;
    TblAnimalMaster_ID: number;
    created_by: any;
    modified_by: any;
}