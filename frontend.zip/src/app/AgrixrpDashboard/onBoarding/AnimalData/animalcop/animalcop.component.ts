import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";
import { MastersService } from "app/services/masters.service";
import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl, FormArray } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import { MatSelect, MatTableDataSource, MatPaginator, MatSort, MatStepper } from '@angular/material';
import { Material, CropMaster } from '../../CropData/cropmast/cropmaster';
import Swal from 'sweetalert2';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { takeUntil } from 'rxjs/operators';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Animalmaster } from '../animalmaster/Animalmaster';
@Component({
  selector: 'app-animalcop',
  templateUrl: './animalcop.component.html',
  styleUrls: ['./animalcop.component.scss']
})
export class AnimalcopComponent implements OnInit {
  protected _onDestroy = new Subject<void>();
  /** control for the MatSelect filter keyword */
  public MatNameFilterCtrl: FormControl = new FormControl();


  /** list of banks filtered by search keyword */
  public MatNameCoun: ReplaySubject<Material[]> = new ReplaySubject<
    Material[]
  >(1);

  userAnimalCopData: any = [];
  value1 = '';
  value2 = '';
  value3 = '';

  listData: MatTableDataSource<any>;

  listData1 = new MatTableDataSource(this.userAnimalCopData);
  // tslint:disable-next-line: max-line-length
  displayedColumns1: string[] = ["S.No", "MatName", "Quantity", "Units", "Actions"];
  displayedColumns: string[] = [
    "S.No",
    "AnimalName",
    "Activity",
    "Actions"
  ];
  AnimalCopRawmaterial = "AnimalCopRawmaterial";
  editAnimalCopRawmaterialcontent = "add_circle";
  editAnimalCopRawmaterial = true;
  editAnimalCycle = true;
  editAnimalCycleContent = "add_circle";
  AnimalCycleNames = "AnimalCop List";
  displayddl: string;
  displayddl1: string;
  updateAnimalCycle = false;
  viewAnimalCycle = false;
  userAnimalCycledata: any[];

  getRawmaterialData: Material[] = [];
  Editcoun: any = [];
  EditAnimalCycleData: any = [];
  EditOldData: any = [];
  useranimalmasterdata: any[];
  usercroplanedata: any[];
  cropByplot: any[];
  animaldata: any[];
  Editcoc: any = [];
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;
  landSelect = ["Yes", "No"];



  AnimalCycleForm = this.formBuilder.group({
    COPNO: ["", [Validators.required]],
    Activity: ["", [Validators.required]],
    AnimalMilestoneID: [""],
    CriticalActivity: [""],
    Dependency: [""],
    Dose: [""],
    AgeofDose: [""],
    TblAnimalMaster_ID: ["", [Validators.required]],
    Rawmaterialdata: [''],
    modified_by: [""],
    created_by: [""]
  });
  AnimalCycleForm1 = this.formBuilder.group({
    COPNO: ["", [Validators.required]],
    Activity: ["", [Validators.required]],
    AnimalMilestoneID: [""],
    CriticalActivity: [""],
    Dependency: [""],
    Dose: [""],
    AgeofDose: [""],
    TblAnimalMaster_ID: ["", [Validators.required]],
    modified_by: [""],
    created_by: [""]
  });
  AnimalCopRawmaterialForm = this.formBuilder.group({
    TblMaterials_ID: [""],
    Quantity: [
      "",
      [Validators.required,]
    ],
    UnitID: [""],
    userCropCopData: [""],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)

  paginator: MatPaginator;
  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder,
  ) { }
  //tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    // eslint-disable-next-line no-restricted-globals
    this.resetdrop(event);
    if (this.AnimalCycleForm.valid) {
      ////console.log("Form Submited");
      this.AnimalCycleForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    // this.displayRawmaterial();

    this.ls.getMaterialType().subscribe(res => {
      //console.log(res)
      this.getRawmaterialData = res;
    });
    this.displayAnimalcycle();
    this.ls.getAnimalMaster().subscribe(res => {
      //console.log(res)
      this.animaldata = res
    })

    //listen for search field value changes
    this.MatNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterExpenses();
      });


  }
  protected filterExpenses() {
    if (!this.getRawmaterialData) {
      return;
    }
    // get the search keyword
    let search = this.MatNameFilterCtrl.value;
    if (!search) {
      this.MatNameCoun.next(this.getRawmaterialData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.MatNameCoun.next(
      this.getRawmaterialData.filter(
        bank => bank.MatName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  resetdrop(event) {

  }


  addRawMaterial() {
    this.userAnimalCopData.push({ MatName: this.value1, Quantity: this.value2, Units: this.value3 })
    this.listData1 = new MatTableDataSource(this.userAnimalCopData);
    //console.log('fgfgfgh', this.userAnimalCopData);
    this.AnimalCycleForm.controls.Rawmaterialdata.patchValue(this.userAnimalCopData);
    this.value1 = '';
    this.value2 = '';
    this.value3 = '';
  }


  AddAnimalCopRawmaterial() {

    this.AnimalCopRawmaterialForm.reset();
    // this.displayRawmaterial();
    this.AnimalCopRawmaterial =
      this.AnimalCopRawmaterial === "AnimalCopRawmaterial"
        ? "Add AnimalCopRawmaterial"
        : "AnimalCopRawmaterial";
    this.MatNameCoun.next(this.getRawmaterialData.slice());
    this.editAnimalCopRawmaterial = !this.editAnimalCopRawmaterial;
    this.editAnimalCopRawmaterialcontent =
      this.editAnimalCopRawmaterialcontent === "cancel"
        ? "add_circle"
        : "cancel";
    this.displayddl1 = this.editAnimalCopRawmaterial ? "inline" : "none";

  }


  displayAnimalcycle() {
    this.ls.getAnimalcopdata().subscribe(
      list => {
        this.isLoading = false;
        this.userAnimalCycledata = list;

        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userAnimalCycledata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Animalmaster, filter: any) =>
          data.AnimalName.toLowerCase().indexOf(filter) !== -1;

        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  CreateAnimalCycle(data) {
    //console.log('submit data', this.AnimalCycleForm.value);

    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Saving Data...";
    if (!this.AnimalCycleForm.valid) {
      Object.keys(this.AnimalCycleForm.controls).forEach(field => {
        const control = this.AnimalCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The MandetoryFields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      //console.log(this.AnimalCycleForm.value)
      this.AnimalCycleForm.controls.created_by.patchValue(1);
      this.ls.saveAnimalcopdata(this.AnimalCycleForm.value).subscribe(
        cropdata => {
          //console.log(cropdata);
          if (cropdata["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the cropcop",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.AnimalCycleForm.reset();
            this.displayAnimalcycle();
            this.toggleEditAnimalCycle();
          }
        },
        err => console.error(err)
      );
    }
  }



  UpdateAnimalCycle(Editaoc) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Saving Data...";
    this.Editcoc = Editaoc;
    if (!this.AnimalCycleForm1.valid) {
      Object.keys(this.AnimalCycleForm1.controls).forEach(field => {
        const control = this.AnimalCycleForm1.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalCycleForm1.controls.modified_by.patchValue(1);
      this.ls
        .updateAnimalcopByID(this.Editcoc.ID, this.AnimalCycleForm1.value)
        .subscribe(
          res => {
            if (res["data"] === "Successfully Updated") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayAnimalcycle();
              this.toggleUpdateAnimalCycle2();
            }
          },

        );
    }
  }

  deleteAnimalCycle(id: any) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteAnimalcopByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayAnimalcycle();
          }
        });
      }
    });
  }

  toggleEditAnimalCycle() {
    // eslint-disable-next-line no-restricted-globals
    this.resetdrop(event);
    this.displayAnimalcycle();
    this.AnimalCycleForm.reset();
    this.AnimalCycleNames =
      this.AnimalCycleNames === "Add AnimalCop" ? "AnimalCop" : "Add AnimalCop";
    this.editAnimalCycle = !this.editAnimalCycle;
    this.editAnimalCycleContent =
      this.editAnimalCycleContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editAnimalCycle ? "inline" : "none";
  }

  toggleUpdateAnimalCycle(getAnimalCycleDataObj) {
    this.Editcoc = getAnimalCycleDataObj;
    this.updateAnimalCycle = !this.updateAnimalCycle;
    this.displayddl = !this.editAnimalCycle ? "inline" : "none";
    this.AnimalCycleForm1.controls.modified_by.patchValue(1);
    this.AnimalCycleForm1.setValue({
      TblAnimalMaster_ID: this.Editcoc.TblAnimalMaster_ID,
      COPNO: this.Editcoc.COPNO,
      Activity: this.Editcoc.Activity,
      AnimalMilestoneID: this.Editcoc.AnimalMilestoneID,
      CriticalActivity: this.Editcoc.CriticalActivity,
      Dependency: this.Editcoc.Dependency,
      Dose: this.Editcoc.Dose,
      AgeofDose: this.Editcoc.AgeofDose,
      modified_by: this.Editcoc.modified_by,
      created_by: this.Editcoc.created_by
    });
  }




  toggleUpdateAnimalCycle2() {
    this.updateAnimalCycle = false;
    this.displayddl = this.editAnimalCycle ? "inline" : "block";
  }

  toggleViewCropCycle(getCropCycleDataObj) {
    this.Editcoun = getCropCycleDataObj;
    this.viewAnimalCycle = !this.viewAnimalCycle;
    this.displayddl = !this.editAnimalCycle ? "inline" : "none";
  }

  toggleViewCropCycle2() {
    this.viewAnimalCycle = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }

}
