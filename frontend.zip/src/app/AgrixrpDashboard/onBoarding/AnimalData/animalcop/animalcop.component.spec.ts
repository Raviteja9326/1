import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalcopComponent } from './animalcop.component';

describe('AnimalcopComponent', () => {
  let component: AnimalcopComponent;
  let fixture: ComponentFixture<AnimalcopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimalcopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimalcopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
