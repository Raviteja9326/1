import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalmasterComponent } from './animalmaster.component';

describe('AnimalmasterComponent', () => {
  let component: AnimalmasterComponent;
  let fixture: ComponentFixture<AnimalmasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimalmasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimalmasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
