import { Component, OnInit, ViewChild } from "@angular/core";
import { Animalmaster } from "./Animalmaster";
import Swal from "sweetalert2";
import { DatePipe } from "@angular/common";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatSelect
} from "@angular/material";
import { ReplaySubject, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { Animalcategory } from "../animalcategory/Animalcategory";
import { Animalbreed } from "../animalbreed/Animalbreed";
import { Farmer } from "app/AgrixrpDashboard/onBoarding/FarmerData/farmerinfo/farmerinfo";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";
@Component({
  selector: "app-animalmaster",
  templateUrl: "./animalmaster.component.html",
  styleUrls: ["./animalmaster.component.scss"]
})
export class AnimalmasterComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "AnimalName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CatFilterCtrl: FormControl = new FormControl();
  public BreedFilterCtrl: FormControl = new FormControl();
  public FarmerFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCat: ReplaySubject<Animalcategory[]> = new ReplaySubject<
    Animalcategory[]
  >(1);
  public filteredBreed: ReplaySubject<Animalbreed[]> = new ReplaySubject<
    Animalbreed[]
  >(1);
  public filteredFarmer: ReplaySubject<Farmer[]> = new ReplaySubject<Farmer[]>(
    1
  );

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  genders = ["Male", "Female", "Others"];

  // tslint:disable-next-line:member-ordering
  Animaltype = "Animal Master";
  editAnimal = "add_circle";
  editanimalmaster = true;
  displayddl: String;
  AnimalMasterData: any = [];
  getcatdata: Animalcategory[] = [];
  breed: Animalbreed[] = [];
  FarmerData: Farmer[] = [];
  Editanimalmaster: any = [];
  updateAnimalmaster = false;
  EditOldData: any = [];
  ViewAnimalMaster = false;
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  AnimalMastervalidation = this.formBuilder.group({
    AnimalGEOTAG: ["", [Validators.required]],
    AnimalName: ["", [Validators.required]],
    Sex: [""],
    DOB: [""],
    Age: ["", [Validators.pattern("^[0-9]*$")]],
    AgeGroup: ["", [Validators.pattern("^[0-9]*$")]],
    RemainingYears: ["", [Validators.pattern("^[0-9]*$")]],
    AnimalParentID: [""],
    Purpose: [""],
    HealthCondition: [""],
    Presentvalue: ["", [Validators.pattern("^[0-9]*$")]],
    CullValue: ["", [Validators.pattern("^[0-9]*$")]],
    FeedingscheduleTime: [""],
    FeedType: [""],
    DrinkingwaterTime: [""],
    DrinkingwaterCapacity: ["", [Validators.pattern("^[0-9]*$")]],
    WashingTime: [""],
    CleaningTime: [""],
    TblAnimalCategory_ID: ["", [Validators.required]],
    TblBreed_ID: ["", [Validators.required]],
    TblFarmer_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  constructor(
    private ls: MastersService,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.displayAnimalMaster();

    /*cat data */
    this.ls.getanimalcat().subscribe(res => {

      this.getcatdata = res;
    });
    this.CatFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterAnimalCat();
      });
    /*cat ends */

    /*Breed name data */
    this.BreedFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBreedName();
      });

    /*breed ends */

    // for farmer
    this.ls.getFarmerdata().subscribe(res => {
      this.FarmerData = res;
      ////console.log(this.FarmerData);
    });

    // listen for search field value changes
    this.FarmerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFarmer();
      });
    // farmer end
  }

  /*Animal  cat data */
  protected filterAnimalCat() {
    ////console.log("hello", this.getcatdata);
    if (!this.getcatdata) {
      return;
    }
    // get the search keyword
    let search = this.CatFilterCtrl.value;
    ////console.log(this.CatFilterCtrl.value);

    if (!search) {
      this.filteredCat.next(this.getcatdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCat.next(
      this.getcatdata.filter(
        bank => bank.AnimalCatName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*cat end */

  /*Breed data */
  protected filterBreedName() {
    ////console.log("breed", this.breed);
    if (!this.breed) {
      return;
    }
    // get the search keyword
    let search = this.BreedFilterCtrl.value;
    ////console.log(this.BreedFilterCtrl.value);

    if (!search) {
      this.filteredBreed.next(this.breed.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBreed.next(
      this.breed.filter(
        bank => bank.BreedName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*Breed end */

  /*farmer data */
  protected filterFarmer() {
    ////console.log("farmer", this.FarmerData);
    if (!this.FarmerData) {
      return;
    }
    // get the search keyword
    let search = this.FarmerFilterCtrl.value;
    ////console.log(this.FarmerFilterCtrl.value);

    if (!search) {
      this.filteredFarmer.next(this.FarmerData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredFarmer.next(
      this.FarmerData.filter(
        bank => bank.FarmerName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*farmer data ends*/

  displayAnimalMaster() {
    this.ls.getAnimalMaster().subscribe(list => {
      this.isLoading = false;
      this.AnimalMasterData = list;
      ////console.log(this.AnimalMasterData);
      if (this.AnimalMasterData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.AnimalMasterData);
      this.listData = new MatTableDataSource(this.AnimalMasterData);
      /* config filter */
      this.listData.filterPredicate = (data: Animalmaster, filter: string) =>
        data.AnimalName.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.AnimalMastervalidation.valid) {
      ////console.log("Form Submitted");
      this.AnimalMastervalidation.reset();
    }
  }

  AddMaster() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredCat.next(this.getcatdata.slice());
    this.filteredBreed.next(this.breed.slice());
    this.filteredFarmer.next(this.FarmerData.slice());
    this.resetdrop(event);
    this.AnimalMastervalidation.reset();
    this.displayAnimalMaster();
    this.Animaltype =
      this.Animaltype === "Animal Master"
        ? "Add Animal Master"
        : "Animal Master";
    this.editAnimal = this.editAnimal === "cancel" ? "add_circle" : "cancel";
    this.editanimalmaster = !this.editanimalmaster;
    this.displayddl = this.editanimalmaster ? "inline" : "none";
  }

  resetdrop(event) {
    this.filteredBreed.next((this.breed = []));
    this.breed = [];
  }

  onChangeCategoryType(value) {
    ////console.log("helloooo", value);
    this.ls.getBreedByCatID(value).subscribe(breedCat => {
      if (breedCat["data"] === "NO Breed Available with this ID") {
        Swal.fire({
          position: "center",
          type: "info",
          title: "No Breed Available with this Category",
          showConfirmButton: false,
          timer: 1500
        });
        this.breed = [];
        this.resetdrop(event);
        this.AnimalMastervalidation.controls.TblBreed_ID.patchValue("");
      } else {
        Swal.fire({
          position: "center",
          type: "info",
          title: "Please Select The Breed",
          showConfirmButton: false,
          timer: 1000
        });
        this.breed = breedCat;
        this.filteredBreed.next(this.breed.slice());
      }
    });
  }

  CreateAnimalmaster(data) {
    ////console.log(data);
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.AnimalMastervalidation.valid) {
      Object.keys(this.AnimalMastervalidation.controls).forEach(field => {
        const control = this.AnimalMastervalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalMastervalidation.controls.created_by.patchValue(0);
      this.ls.saveAnimalMaster(this.AnimalMastervalidation.value).subscribe(
        res => {


          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the AnimnalMaster",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.AnimalMastervalidation.reset();
            this.displayAnimalMaster();
            this.AddMaster();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The AnimnalMaster",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateAnimalMaster(getAnimalmasterDataObj) {
    ////console.log(getAnimalmasterDataObj);
    this.Editanimalmaster = getAnimalmasterDataObj;
    // Date formatting
    this.Editanimalmaster.DOB = this.dp.transform(
      this.Editanimalmaster.DOB,
      "yyyy-MM-dd"
    );
    this.updateAnimalmaster = !this.updateAnimalmaster;
    this.displayddl = !this.editanimalmaster ? "inline" : "none";
    this.AnimalMastervalidation.controls.modified_by.patchValue(0);
    this.ls
      .getBreedByCatID(this.Editanimalmaster.TblAnimalCategory_ID)
      .subscribe(res => {
        this.breed = res;
        ////console.log(this.breed);
      });
    this.AnimalMastervalidation.setValue({
      AnimalGEOTAG: this.Editanimalmaster.AnimalGEOTAG,
      AnimalName: this.Editanimalmaster.AnimalName,
      Sex: this.Editanimalmaster.Sex,
      DOB: this.Editanimalmaster.DOB,
      Age: this.Editanimalmaster.Age,
      AgeGroup: this.Editanimalmaster.AgeGroup,
      RemainingYears: this.Editanimalmaster.RemainingYears,
      AnimalParentID: this.Editanimalmaster.AnimalParentID,
      Purpose: this.Editanimalmaster.Purpose,
      HealthCondition: this.Editanimalmaster.HealthCondition,
      Presentvalue: this.Editanimalmaster.Presentvalue,
      CullValue: this.Editanimalmaster.CullValue,
      FeedingscheduleTime: this.Editanimalmaster.FeedingscheduleTime,
      FeedType: this.Editanimalmaster.FeedType,
      DrinkingwaterTime: this.Editanimalmaster.DrinkingwaterTime,
      DrinkingwaterCapacity: this.Editanimalmaster.DrinkingwaterCapacity,
      WashingTime: this.Editanimalmaster.WashingTime,
      CleaningTime: this.Editanimalmaster.CleaningTime,
      TblAnimalCategory_ID: this.Editanimalmaster.TblAnimalCategory_ID,
      TblBreed_ID: this.Editanimalmaster.TblBreed_ID,
      TblFarmer_ID: this.Editanimalmaster.TblFarmer_ID,
      created_by: this.Editanimalmaster.created_by,
      modified_by: this.Editanimalmaster.modified_by
    });
  }

  toggleUpdateanimalmaster2() {
    this.updateAnimalmaster = false;
    this.displayddl = this.editanimalmaster ? "inline" : "none";
  }

  updateanimalmaster1(data) {
    ////console.log(data);
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.AnimalMastervalidation.valid) {
      Object.keys(this.AnimalMastervalidation.controls).forEach(field => {
        const control = this.AnimalMastervalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalMastervalidation.controls.modified_by.patchValue(0);
      this.ls
        .updateAnimalmasterById(
          this.Editanimalmaster.ID,
          this.AnimalMastervalidation.value
        )
        .subscribe(
          res => {

            if (
              this.Editanimalmaster.AnimalGEOTAG ===
              this.AnimalMastervalidation.controls.AnimalGEOTAG.value &&
              this.Editanimalmaster.AnimalName ===
              this.AnimalMastervalidation.controls.AnimalName.value &&
              this.Editanimalmaster.Sex ===
              this.AnimalMastervalidation.controls.Sex.value &&
              this.Editanimalmaster.DOB ===
              this.AnimalMastervalidation.controls.DOB.value &&
              this.Editanimalmaster.Age ===
              this.AnimalMastervalidation.controls.Age.value &&
              this.Editanimalmaster.AgeGroup ===
              this.AnimalMastervalidation.controls.AgeGroup.value &&
              this.Editanimalmaster.RemainingYears ===
              this.AnimalMastervalidation.controls.RemainingYears.value &&
              this.Editanimalmaster.AnimalParentID ===
              this.AnimalMastervalidation.controls.AnimalParentID.value &&
              this.Editanimalmaster.Purpose ===
              this.AnimalMastervalidation.controls.Purpose.value &&
              this.Editanimalmaster.HealthCondition ===
              this.AnimalMastervalidation.controls.HealthCondition.value &&
              this.Editanimalmaster.Presentvalue ===
              this.AnimalMastervalidation.controls.Presentvalue.value &&
              this.Editanimalmaster.CullValue ===
              this.AnimalMastervalidation.controls.CullValue.value &&
              this.Editanimalmaster.FeedingscheduleTime ===
              this.AnimalMastervalidation.controls.FeedingscheduleTime
                .value &&
              this.Editanimalmaster.FeedType ===
              this.AnimalMastervalidation.controls.FeedType.value &&
              this.Editanimalmaster.DrinkingwaterTime ===
              this.AnimalMastervalidation.controls.DrinkingwaterTime.value &&
              this.Editanimalmaster.DrinkingwaterCapacity ===
              this.AnimalMastervalidation.controls.DrinkingwaterCapacity
                .value &&
              this.Editanimalmaster.WashingTime ===
              this.AnimalMastervalidation.controls.WashingTime.value &&
              this.Editanimalmaster.TblAnimalCategory_ID ===
              this.AnimalMastervalidation.controls.TblAnimalCategory_ID
                .value &&
              this.Editanimalmaster.TblBreed_ID ===
              this.AnimalMastervalidation.controls.TblBreed_ID.value &&
              this.Editanimalmaster.TblFarmer_ID ===
              this.AnimalMastervalidation.controls.TblFarmer_ID.value &&
              this.Editanimalmaster.CleaningTime ===
              this.AnimalMastervalidation.controls.CleaningTime.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.toggleUpdateanimalmaster2();
              this.displayAnimalMaster();
            }
          },

        );
    }
  }

  deleteAnimalMaster(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteAnimalMasterById(id).subscribe(res => {
          ////console.log("helloguru");
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayAnimalMaster();
          }
        });
      }
    });
  }

  toggleViewAnimalMaster(getAnimalmasterDataObj) {
    ////console.log(getAnimalmasterDataObj);
    this.Editanimalmaster = getAnimalmasterDataObj;
    this.ViewAnimalMaster = !this.ViewAnimalMaster;
    this.displayddl = !this.editanimalmaster ? "inline" : "none";
  }

  toggleViewAnimalMaster1() {
    this.ViewAnimalMaster = false;
    this.displayddl = this.editanimalmaster ? "inline" : "none";
  }
}
