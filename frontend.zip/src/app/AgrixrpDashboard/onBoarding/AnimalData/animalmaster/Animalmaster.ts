export interface Animalmaster {
  ID?: number;
  AnimalGEOTAG?: any;
  AnimalName?: any;
  Sex?: any;
  DOB?: any;
  Age?: any;
  AgeGroup?: any;
  RemainingYears?: any;
  AnimalParentID?: any;
  Purpose?: any;
  HealthCondition?: any;
  Presentvalue?: any;
  CullValue?: any;
  FeedingscheduleTime?: any;
  FeedType?: any;
  DrinkingwaterTime?: any;
  DrinkingwaterCapacity?: any;
  WashingTime?: any;
  CleaningTime?: any;
  TblAnimalCategory_ID?: any;
  TblBreed_ID?: any;
  TblFarmer_ID?: any;
  created_by: any;
  modified_by: any;
}
