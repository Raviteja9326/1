import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AnimalRoutingModule } from './animal-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { MatTableExporterModule } from 'mat-table-exporter';
import { AnimalComponent } from './animal.component';
import { AnimalbreedComponent } from './animalbreed/animalbreed.component';
import { AnimalcategoryComponent } from './animalcategory/animalcategory.component';
import { AnimalcopComponent } from './animalcop/animalcop.component';
import { AnimalhistoryComponent } from './animalhistory/animalhistory.component';
import { AnimalmasterComponent } from './animalmaster/animalmaster.component';
import { VaccinationComponent } from './vaccination/vaccination.component';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';

import { SharedModule } from 'app/AgrixrpDashboard/maincomponents/shared.module';
// tslint:disable-next-line:max-line-length
const components = [AnimalComponent, AnimalbreedComponent, AnimalcategoryComponent, AnimalcopComponent, AnimalhistoryComponent, VaccinationComponent, AnimalmasterComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [AnimalRoutingModule, SharedModule, CommonModule, MatTableExporterModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class AnimalModule { }
