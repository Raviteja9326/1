import { Component, OnInit, ViewChild } from "@angular/core";
import { Animalcategory } from "./Animalcategory";
import Swal from "sweetalert2";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from 'app/services/masters.service';

@Component({
  selector: "app-animalcategory",
  templateUrl: "./animalcategory.component.html",
  styleUrls: ["./animalcategory.component.scss"]
})
export class AnimalcategoryComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "AnimalCatName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  editcat = "add_circle";
  animalcat = "Animal Category";
  editanimalcat = true;
  displayddl: string;
  updateaniamlcategory = false;
  viewanimalcategory = false;
  EditAnimalCat: any = [];
  EditOldData: any = [];
  animalcatData: Animalcategory[] = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  AnimalCatvalidation = this.formBuilder.group({
    AnimalCatName: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.displayanimalcat();
  }
  displayanimalcat() {
    this.ls.getanimalcat().subscribe(list => {
      this.isLoading = false;
      this.animalcatData = list;
      if (this.animalcatData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.animalcatData);
      this.listData = new MatTableDataSource(this.animalcatData);
      /* config filter */
      this.listData.filterPredicate = (data: Animalcategory, filter: string) =>
        data.AnimalCatName.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.AnimalCatvalidation.valid) {
      ////console.log("Form Submitted");
      this.AnimalCatvalidation.reset();
    }
  }

  AddAnimalCat() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.AnimalCatvalidation.reset();
    this.displayanimalcat();
    this.animalcat =
      this.animalcat === "Animal Category"
        ? "Add Animal Category"
        : "Animal Category";
    this.editanimalcat = !this.editanimalcat;
    this.editcat = this.editcat === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editanimalcat ? "inline" : "none";
  }

  CreateAnimalCat(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    // ////console.log(data);
    if (!this.AnimalCatvalidation.valid) {
      Object.keys(this.AnimalCatvalidation.controls).forEach(field => {
        const control = this.AnimalCatvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalCatvalidation.controls.created_by.patchValue(1);
      this.ls.saveanimaldata(this.AnimalCatvalidation.value).subscribe(
        res => {

          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Animal Category",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayanimalcat();
            this.AddAnimalCat();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Animal Category",
              showConfirmButton: false,
              timer: 1500
            });

          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateAnimalCat(getAnimalcatDataObj) {
    ////console.log(getAnimalcatDataObj);
    this.updateaniamlcategory = !this.updateaniamlcategory;
    this.EditAnimalCat = getAnimalcatDataObj;
    ////console.log(this.EditAnimalCat);
    this.displayddl = !this.editanimalcat ? "inline" : "none";
    this.AnimalCatvalidation.controls.modified_by.patchValue(0);
    this.AnimalCatvalidation.setValue({
      AnimalCatName: this.EditAnimalCat.AnimalCatName,
      created_by: this.EditAnimalCat.created_by,
      modified_by: this.EditAnimalCat.modified_by
    });
  }

  togglecloseupdatecard() {
    this.updateaniamlcategory = false;
    this.displayddl = this.EditAnimalCat ? "inline" : "block";
  }

  updateaniamlcategory1(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    ////console.log(data);
    this.EditAnimalCat = data;
    ////console.log(this.EditAnimalCat);
    if (!this.AnimalCatvalidation.valid) {
      Object.keys(this.AnimalCatvalidation.controls).forEach(field => {
        const control = this.AnimalCatvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalCatvalidation.controls.modified_by.patchValue(0);
      this.ls
        .updateAnimaCatById(
          this.EditAnimalCat.ID,
          this.AnimalCatvalidation.value
        )
        .subscribe(
          res => {
            if (
              this.EditAnimalCat.AnimalCatName ===
              this.AnimalCatvalidation.controls.AnimalCatName.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayanimalcat();
              this.togglecloseupdatecard();
              // tslint:disable-next-line:max-line-length
            }
          }


        );
    }

  }

  deleteAnimalCat(id: string) {


    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteAnimalCatById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayanimalcat();
          }
        });
      }
    });
  }

  toggleViewAnimalCat(getAnimalcatDataObj) {
    ////console.log(getAnimalcatDataObj);
    this.viewanimalcategory = !this.viewanimalcategory;
    this.EditAnimalCat = getAnimalcatDataObj;
    this.displayddl = !this.EditAnimalCat ? "inline" : "none";
  }

  toggleAnimalCategory1() {
    this.viewanimalcategory = false;
    this.displayddl = this.EditAnimalCat ? "inline" : "block";
  }
}
