export interface Animalcategory {
    ID?: number;
    AnimalCatName?: string;
    created_by: string;
    modified_by: string;
}