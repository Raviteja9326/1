import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalcategoryComponent } from './animalcategory.component';

describe('AnimalcategoryComponent', () => {
  let component: AnimalcategoryComponent;
  let fixture: ComponentFixture<AnimalcategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimalcategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimalcategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
