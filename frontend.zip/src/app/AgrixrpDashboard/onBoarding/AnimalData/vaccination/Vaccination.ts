export interface Vaccination {
    ID?: number;
    Name?: any;
    Units?: any;
    BatchCode?: any;
    Function?: any;
    PlaceOfOrigin?: any;
    TblCompanyMaster_ID?: any;
    TblAnimalCategory_ID?: any;
    created_by: string;
    modified_by: string;
}