import { Component, OnInit, ViewChild } from "@angular/core";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import { Observable, ReplaySubject, Subject } from "rxjs";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import Swal from "sweetalert2";
import { Vaccination } from "./Vaccination";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { Companymaster } from "../../FarmData/FertilizersAndPestControl/companymaster/Companymaster";
import { MastersService } from "app/services/masters.service";
import { Animalcategory } from "../animalcategory/Animalcategory";

@Component({
  selector: "app-vaccination",
  templateUrl: "./vaccination.component.html",
  styleUrls: ["./vaccination.component.scss"]
})
export class VaccinationComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "Name", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public AnimalCatFilterCtrl: FormControl = new FormControl();
  public CampanyNameFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredAnimalCat: ReplaySubject<Animalcategory[]> = new ReplaySubject<
    Animalcategory[]
  >(1);
  public filteredCampanyName: ReplaySubject<
    Companymaster[]
  > = new ReplaySubject<Companymaster[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  vaccinationtype = "Vaccination Data";
  edittype = "add_circle";
  displayddl: string;
  editVaccinationdata = true;
  updateVaccinationData = false;
  viewVaccinationdata = false;
  AnimalCategorydata: Animalcategory[] = [];
  userVaccinationData: any = [];
  EditVaccinationData: any = [];
  CompanyData: Companymaster[] = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  VaccinationData = this.formBuilder.group({
    Name: ["", [Validators.required]],
    Units: ["", [Validators.pattern("^[0-9]+$")]],
    BatchCode: [""],
    Function: [""],
    PlaceOfOrigin: [""],
    TblCompanyMaster_ID: ["", [Validators.required]],
    TblAnimalCategory_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  AddVaccination() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredAnimalCat.next(this.AnimalCategorydata.slice());
    this.filteredCampanyName.next(this.CompanyData.slice());
    this.VaccinationData.reset();
    this.vaccinationtype =
      this.vaccinationtype === "Vaccination Data"
        ? "Add Vaccination Data"
        : "Vaccination Data";
    this.editVaccinationdata = !this.editVaccinationdata;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editVaccinationdata ? "inline" : "none";
    this.displayVaccinationdata();
  }

  ngOnInit() {
    this.displayVaccinationdata();
    /*animal cat*/
    this.ls.getanimalcat().subscribe(res => {
      this.AnimalCategorydata = res;
      ////console.log(this.AnimalCategorydata);
    });
    this.AnimalCatFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterAnimalCatName();
      });
    /*animal cat ends */

    /*company data */
    this.ls.getCompanyMasterData().subscribe(res => {
      this.CompanyData = res;
      ////console.log(this.CompanyData);
    });
    this.CampanyNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCompanyName();
      });
    /*company ends */
  }

  /*AnimalCat data*/
  protected filterAnimalCatName() {
    ////console.log("units", this.AnimalCategorydata);
    if (!this.AnimalCategorydata) {
      return;
    }
    // get the search keyword
    let search = this.AnimalCatFilterCtrl.value;
    ////console.log(this.AnimalCatFilterCtrl.value);

    if (!search) {
      this.filteredAnimalCat.next(this.AnimalCategorydata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredAnimalCat.next(
      this.AnimalCategorydata.filter(
        bank => bank.AnimalCatName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*AnimalCat data ends*/

  /*Company data*/
  protected filterCompanyName() {
    ////console.log("units", this.CompanyData);
    if (!this.CompanyData) {
      return;
    }
    // get the search keyword
    let search = this.CampanyNameFilterCtrl.value;
    ////console.log(this.CampanyNameFilterCtrl.value);

    if (!search) {
      this.filteredCampanyName.next(this.CompanyData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCampanyName.next(
      this.CompanyData.filter(
        bank => bank.Companyname.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*Company data ends*/

  displayVaccinationdata() {
    this.ls.getVaccinationdata().subscribe(list => {
      this.isLoading = false;
      this.userVaccinationData = list;
      if (this.userVaccinationData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.userVaccinationData);
      this.listData = new MatTableDataSource(this.userVaccinationData);
      /* config filter */
      this.listData.filterPredicate = (data: Vaccination, filter: string) =>
        data.Name.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  CreateVaccinationData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.VaccinationData.valid) {
      Object.keys(this.VaccinationData.controls).forEach(field => {
        const control = this.VaccinationData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.VaccinationData.controls.created_by.patchValue(0);
      this.ls.saveVaccinationData(this.VaccinationData.value).subscribe(
        res => {

          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the VaccinationData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.VaccinationData.reset();
            this.displayVaccinationdata();
            this.AddVaccination();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The VaccinationData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateVaccinationData(getVaccinationDataObj) {
    this.EditVaccinationData = getVaccinationDataObj;
    this.updateVaccinationData = !this.updateVaccinationData;
    this.displayddl = !this.EditVaccinationData ? "inline" : "none";
    this.VaccinationData.controls.modified_by.patchValue(0);
    this.VaccinationData.setValue({
      Name: this.EditVaccinationData.Name,
      Units: this.EditVaccinationData.Units,
      BatchCode: this.EditVaccinationData.BatchCode,
      Function: this.EditVaccinationData.Function,
      PlaceOfOrigin: this.EditVaccinationData.PlaceOfOrigin,
      TblCompanyMaster_ID: this.EditVaccinationData.TblCompanyMaster_ID,
      TblAnimalCategory_ID: this.EditVaccinationData.TblAnimalCategory_ID,
      created_by: this.EditVaccinationData.created_by,
      modified_by: this.EditVaccinationData.modified_by
    });
  }

  toggleUpdateVaccinationData2() {
    this.updateVaccinationData = false;
    this.displayddl = this.EditVaccinationData ? "inline" : "block";
  }

  UpdateVaccinationData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.VaccinationData.valid) {
      Object.keys(this.VaccinationData.controls).forEach(field => {
        const control = this.VaccinationData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.VaccinationData.controls.modified_by.patchValue(0);
      this.ls
        .updateVaccinationDataById(
          this.EditVaccinationData.ID,
          this.VaccinationData.value
        )
        .subscribe(
          res => {
            if (
              this.EditVaccinationData.Name ===
              this.VaccinationData.controls.Name.value &&
              this.EditVaccinationData.Units ===
              this.VaccinationData.controls.Units.value &&
              this.EditVaccinationData.BatchCode ===
              this.VaccinationData.controls.BatchCode.value &&
              this.EditVaccinationData.Function ===
              this.VaccinationData.controls.Function.value &&
              this.EditVaccinationData.PlaceOfOrigin ===
              this.VaccinationData.controls.PlaceOfOrigin.value &&
              this.EditVaccinationData.TblCompanyMaster_ID ===
              this.VaccinationData.controls.TblCompanyMaster_ID.value &&
              this.EditVaccinationData.TblAnimalCategory_ID ===
              this.VaccinationData.controls.TblAnimalCategory_ID.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayVaccinationdata();
              this.toggleUpdateVaccinationData2();
            }
          },

        );
    }
  }

  deleteVaccinationData(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteVaccinationDataById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayVaccinationdata();
          }
        });
      }
    });
  }

  toggleViewVaccinationData(getVaccinationDataObj) {
    this.viewVaccinationdata = !this.viewVaccinationdata;
    this.EditVaccinationData = getVaccinationDataObj;
    this.displayddl = !this.EditVaccinationData ? "inline" : "none";
  }

  toggleViewVaccinationdata1() {
    this.viewVaccinationdata = false;
    this.displayddl = !this.EditVaccinationData ? "inline" : "block";
  }
}
