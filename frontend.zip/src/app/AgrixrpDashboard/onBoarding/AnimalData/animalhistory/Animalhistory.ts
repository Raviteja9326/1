export interface Animalhistory {
    ID?: number;
    TblFarmer_ID?: number;
    startdate?: any;
    maturedate?: any;
    Status?: any;
    BatchNumber?: any;
    BatchCount?: any;
    OutputType?: any;
    TblShed_ID?: any;
    TblAnimalMaster_ID?: number;
    created_by: string;
    modified_by: string;
}
