import { Component, OnInit, ViewChild } from "@angular/core";
import { Animalhistory } from "./Animalhistory";
import Swal from "sweetalert2";
import { DatePipe } from "@angular/common";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import { location, Shed } from "app/services/Dataservices";
import { takeUntil } from "rxjs/operators";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { ReplaySubject, Subject } from "rxjs";
import { MastersService } from "app/services/masters.service";

import { MatProgressButtonOptions } from "mat-progress-buttons";
import { Animalmaster } from "../animalmaster/Animalmaster";
import { Farmer } from '../../FarmerData/farmerinfo/farmerinfo';



@Component({
  selector: "app-animalhistory",
  templateUrl: "./animalhistory.component.html",
  styleUrls: ["./animalhistory.component.scss"]
})
export class AnimalhistoryComponent implements OnInit {
  listData: MatTableDataSource<any>;
  listData1: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "AnimalName", "Actions"];
  displayedColumns1: string[] = ['S.No', 'Activity', 'Duration', 'Date'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public AnimalFilterCtrl: FormControl = new FormControl();
  public ShedFilterCtrl: FormControl = new FormControl();
  public FarmerFilterCtrl: FormControl = new FormControl();
  /** list of banks filtered by search keyword */

  public filteredFarmer: ReplaySubject<Farmer[]> = new ReplaySubject<Farmer[]>(1);
  /** list of banks filtered by search keyword */
  public filteredAnimal: ReplaySubject<Animalhistory[]> = new ReplaySubject<
    Animalhistory[]
  >(1);
  public filteredShed: ReplaySubject<Shed[]> = new ReplaySubject<Shed[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  Animaltype = "Animal Cycle";
  editanimal = "add_circle";
  editanimalmaster = true;
  displayddl: string;
  userfarmerdata: Farmer[] = [];
  AnimalHistorydata: Animalhistory[] = [];
  AnimalCycleData: any = [];
  AnimalCopData: any = [];

  EditAnimalHistory: any = [];
  updateAnimalhistory = false;
  EditOldData: any = [];
  animalmaster: any = [];
  ViewAnimalHistory = false;
  Shudname: Shed[] = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;
  animalactivities: any;
  date: Date;
  Editcoun: any = [];

  AnimalHistoryvalidation = this.formBuilder.group({
    startdate: ["", [Validators.required]],
    maturedate: ["", [Validators.required]],
    Status: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    BatchNumber: ["", [Validators.pattern("^[0-9]*$")]],
    BatchCount: ["", [Validators.pattern("^[0-9]*$")]],
    OutputType: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    TblShed_ID: ["", [Validators.required]],
    TblAnimalMaster_ID: ["", [Validators.required]],
    TblFarmer_ID: ['', [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  // tslint:disable-next-line:max-line-length
  constructor(
    private ls: MastersService,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.displayanimalhistory();
    /*for animal name */
    this.ls.getAnimalMaster().subscribe(res => {
      //console.log(res)
      this.AnimalCycleData = res;
    });
    //animalcop


    //farmer
    this.ls.getFarmerdata().subscribe(res => {
      //console.log(res)
      this.userfarmerdata = res;
    })

    /*animal end */
    //for farmer
    this.FarmerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFarmerName();
      });

    /*for shed name */
    this.ls.getShedData().subscribe(res => {
      //console.log(res)
      this.Shudname = res;
    });
    this.ShedFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterShedName();
      });
    /*shed end */

  }

  //for farmer
  protected filterFarmerName() {
    //console.log('shed', this.userfarmerdata)
    if (!this.userfarmerdata) {
      return;
    }
    // get the search keyword
    let search = this.FarmerFilterCtrl.value;
    //console.log(this.FarmerFilterCtrl.value);

    if (!search) {
      this.filteredFarmer.next(this.userfarmerdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredFarmer.next(
      this.userfarmerdata.filter(bank => bank.FarmerName.toLowerCase().indexOf(search) > -1)
    );
  }
  /*shed data */
  protected filterShedName() {
    //console.log('shed', this.Shudname)
    if (!this.Shudname) {
      return;
    }
    // get the search keyword
    let search = this.ShedFilterCtrl.value;
    //console.log(this.ShedFilterCtrl.value);

    if (!search) {
      this.filteredShed.next(this.Shudname.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredShed.next(
      this.Shudname.filter(bank => bank.Name.toLowerCase().indexOf(search) > -1)
    );
  }
  /*shed data ends*/

  /*animal data */
  protected filterAnimalName() {
    //console.log('animal', this.AnimalCycleData)
    if (!this.AnimalCycleData) {
      return;
    }
    // get the search keyword
    let search = this.AnimalFilterCtrl.value;
    //console.log(this.AnimalFilterCtrl.value);

    if (!search) {
      this.filteredAnimal.next(this.AnimalCycleData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredAnimal.next(
      this.AnimalCycleData.filter(bank => bank.AnimalName.toLowerCase().indexOf(search) > -1)
    );
  }
  /*animal data ends*/

  //animalcop

  displayanimalhistory() {
    this.ls.getAnimalhistorydata().subscribe(
      list => {
        this.isLoading = false;
        this.AnimalHistorydata = list;
        if (this.AnimalHistorydata.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        //console.log(this.AnimalHistorydata);
        this.listData = new MatTableDataSource(this.AnimalHistorydata);
        /* config filter */
        this.listData.filterPredicate =
          (data: Animalmaster, filter: string) => data.AnimalName.toLowerCase().indexOf(filter) !== -1;
        //console.log(this.listData);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
    )
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  AddHistory() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.AnimalHistoryvalidation.reset();
    this.Animaltype =
      this.Animaltype === "Animal Cycle" ? "Add Animal Cycle" : "Animal Cycle";
    this.editanimal =
      this.editanimal === "cancel" ? "add_circle" : "cancel";
    this.editanimalmaster = !this.editanimalmaster;
    this.displayddl = this.editanimalmaster ? "inline" : "none";
    this.filteredAnimal.next(this.AnimalCycleData.slice());
    this.filteredShed.next(this.Shudname.slice());
    this.displayanimalhistory();
  }

  resetForm() {
    if (this.AnimalHistoryvalidation.valid) {
      //console.log("Form Submitted");
      this.AnimalHistoryvalidation.reset();
    }
  }

  CreateAnimalhistory() {
    //console.log(this.AnimalHistoryvalidation.value);
    // delete this.animalhistory.ID;
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    if (!this.AnimalHistoryvalidation.valid) {
      Object.keys(this.AnimalHistoryvalidation.controls).forEach(field => {
        const control = this.AnimalHistoryvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.AnimalHistoryvalidation.controls.created_by.patchValue(0)
      this.ls.saveAnimalhistory(this.AnimalHistoryvalidation.value).subscribe(
        res => {
          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Farmer',
              showConfirmButton: false,
              timer: 1500
            })

            // var formData = new FormData();
            // for (var i = 0; i < this.files.length; i++) { 
            //   formData.append('sampleImage',  this.files[i]);
            //   formData.append('Activity', this.capti);
            //   formData.append('FarmerID', this.Editcoun.TblFarmer_ID);
            //   //console.log(formData);
            //   this.ls.uploadImage(formData, this.capti).subscribe((response) => {
            //     //console.log('this is response after uploading Image', response);
            //   });
            // }






            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.AnimalHistoryvalidation.reset();
            this.displayanimalhistory();
            this.AddHistory();
          } else if (res['data'] = "serverErrorStateExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The FarmerData',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }
  }

  toggleUpdateAnimalCycle(getAnimalcycleDataObj) {
    //console.log(getAnimalcycleDataObj);
    this.EditAnimalHistory = getAnimalcycleDataObj;
    this.EditAnimalHistory.startdate = this.dp.transform(this.EditAnimalHistory.startdate, 'yyyy-MM-dd');
    this.EditAnimalHistory.maturedate = this.dp.transform(this.EditAnimalHistory.maturedate, 'yyyy-MM-dd');
    this.updateAnimalhistory = !this.updateAnimalhistory;
    this.displayddl = !this.editanimalmaster ? "inline" : "none";
    this.AnimalHistoryvalidation.controls.modified_by.patchValue(0)
    this.AnimalHistoryvalidation.setValue({
      startdate: this.EditAnimalHistory.startdate,
      maturedate: this.EditAnimalHistory.maturedate,
      Status: this.EditAnimalHistory.Status,
      BatchNumber: this.EditAnimalHistory.BatchNumber,
      BatchCount: this.EditAnimalHistory.BatchCount,
      OutputType: this.EditAnimalHistory.OutputType,
      TblShed_ID: this.EditAnimalHistory.TblShed_ID,
      TblAnimalMaster_ID: this.EditAnimalHistory.TblAnimalMaster_ID,
      TblFarmer_ID: this.EditAnimalHistory.TblFarmer_ID,
      created_by: this.EditAnimalHistory.created_by,
      modified_by: this.EditAnimalHistory.modified_by
    });
  }

  files: any = [];

  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      this.files.push(element.name)
      //console.log(this.files)
    }
  }
  deleteAttachment(index) {
    this.files.splice(index, 1)
  }

  toggleUpdateanimalhistory2() {
    this.updateAnimalhistory = false;
    this.displayddl = this.editanimalmaster ? "inline" : "none";
  }

  updateanimalhistory1(data) {
    //console.log(data);
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    if (!this.AnimalHistoryvalidation.valid) {
      Object.keys(this.AnimalHistoryvalidation.controls).forEach(field => {
        const control = this.AnimalHistoryvalidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.AnimalHistoryvalidation.controls.modified_by.patchValue(0)
      this.ls.updateAnimalcycleById(this.EditAnimalHistory.ID, this.AnimalHistoryvalidation.value).subscribe(res => {
        //console.log(res);
        if (
          this.EditAnimalHistory.Status === this.AnimalHistoryvalidation.controls.Status.value &&
          this.EditAnimalHistory.BatchNumber === this.AnimalHistoryvalidation.controls.BatchNumber.value &&
          this.EditAnimalHistory.BatchCount === this.AnimalHistoryvalidation.controls.BatchCount.value &&
          this.EditAnimalHistory.OutputType === this.AnimalHistoryvalidation.controls.OutputType.value &&
          this.EditAnimalHistory.TblShed_ID === this.AnimalHistoryvalidation.controls.TblShed_ID.value &&
          this.EditAnimalHistory.TblAnimalMaster_ID === this.AnimalHistoryvalidation.controls.TblAnimalMaster_ID.value &&
          this.EditAnimalHistory.startdate === this.AnimalHistoryvalidation.controls.startdate.value &&
          this.EditAnimalHistory.maturedate === this.AnimalHistoryvalidation.controls.maturedate.value) {
          //console.log("no update");
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          //console.log('update');
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayanimalhistory();
          this.toggleUpdateanimalhistory2();
        }

      },
        err => console.log(err)
      )
    }
  }

  deleteAnimalCycle(id: string) {
    //console.log(id)

    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ls.deleteAnimalCycleById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              });
              this.displayanimalhistory();
            }
          }
        )
      }
    })
  }



  toggleViewAnimalCycle(id: string) {
    //console.log(id);
    this.ls.getAnimalCycleId(id).subscribe(res => {
      //console.log(res)
      this.Editcoun = res;
      this.animalactivities = this.Editcoun.object.result;
      //console.log(this.animalactivities)
      if (this.Editcoun.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }

      //console.log('mainact', this.animalactivities)
      this.date = new Date(this.Editcoun.object.startdate);
      //console.log('date after 1 day', this.date)
      //this.date.setDate(this.date.getDate()+10);

      //console.log('date after 7 day', this.date)
      let DurationArray = [];
      for (let i = 0; i < this.animalactivities.length; i++) {
        DurationArray.push({
          Activity: this.animalactivities[i].Activity,
          Duration: this.animalactivities[i].Duration,
          Date: this.date.setDate(this.date.getDate() + parseInt(this.animalactivities[i].Duration))
        });
        //console.log(DurationArray)

      }
      this.listData1 = new MatTableDataSource(DurationArray);
      //console.log(this.listData1)

      //console.log(this.Editcoun.object.startdate)


    });
    this.ViewAnimalHistory = !this.ViewAnimalHistory;
    this.displayddl = !this.editanimalmaster ? "inline" : "none";
  }

  toggleViewAnimalHistory1() {
    this.displayNoRecords = false;
    this.ViewAnimalHistory = false;
    this.Editcoun = [];
    this.displayddl = !this.editanimalmaster ? "inline" : "block";
  }

}
