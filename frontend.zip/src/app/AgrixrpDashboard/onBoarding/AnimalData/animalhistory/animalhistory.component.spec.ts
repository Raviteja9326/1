import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalhistoryComponent } from './animalhistory.component';

describe('AnimalhistoryComponent', () => {
  let component: AnimalhistoryComponent;
  let fixture: ComponentFixture<AnimalhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimalhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimalhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
