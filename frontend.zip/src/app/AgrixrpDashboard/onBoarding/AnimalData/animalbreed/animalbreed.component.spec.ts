import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalbreedComponent } from './animalbreed.component';

describe('AnimalbreedComponent', () => {
  let component: AnimalbreedComponent;
  let fixture: ComponentFixture<AnimalbreedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimalbreedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimalbreedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
