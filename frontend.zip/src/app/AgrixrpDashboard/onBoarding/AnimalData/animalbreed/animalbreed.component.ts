import { Component, OnInit, ViewChild } from "@angular/core";
import { Animalbreed } from "./Animalbreed";
import Swal from "sweetalert2";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { Animalcategory } from "../animalcategory/Animalcategory";
import { ReplaySubject, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { MastersService } from "app/services/masters.service";
@Component({
  selector: "app-animalbreed",
  templateUrl: "./animalbreed.component.html",
  styleUrls: ["./animalbreed.component.scss"]
})
export class AnimalbreedComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "BreedName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CatFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCat: ReplaySubject<Animalcategory[]> = new ReplaySubject<
    Animalcategory[]
  >(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  AnimalBreedValidation = this.formBuilder.group({
    BreedName: ["", [Validators.required]],
    ImprovedBreedName: [""],
    LocalBreedName: ["", [Validators.required]],
    BreedType: [""],
    PercentageOfimprovedbreed: ["", [Validators.pattern("^[0-9]*$")]],
    PercentageOfLocalbreed: ["", [Validators.pattern("^[0-9]*$")]],
    TotalNoOfImprovedbreed: ["", [Validators.pattern("^[0-9]*$")]],
    MostAvilableLocation: [""],
    TblAnimalCategory_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  Breedtype = "Anaimal Breed";
  editbreed = "add_circle";
  editanimalbreed = true;
  displayddl: string;
  updateAnimalbreed = false;
  EditAnimalBreed: any = [];
  EditOldData: any = [];
  ViewAnimalBreed = false;
  AnimalBreedData: any = [];
  getcatdata: Animalcategory[] = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.displayAnimalbreed();
    /*cat data */
    this.ls.getanimalcat().subscribe(res => {

      this.getcatdata = res;
    });
    this.CatFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterAnimalCat();
      });
    /*cat ends */
  }

  /*Animal  cat data */
  protected filterAnimalCat() {
    ////console.log("hello", this.getcatdata);
    if (!this.getcatdata) {
      return;
    }
    // get the search keyword
    let search = this.CatFilterCtrl.value;
    ////console.log(this.CatFilterCtrl.value);

    if (!search) {
      this.filteredCat.next(this.getcatdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCat.next(
      this.getcatdata.filter(
        bank => bank.AnimalCatName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*cat end */

  displayAnimalbreed() {
    this.ls.getAnimalbreed().subscribe(list => {
      this.isLoading = false;
      this.AnimalBreedData = list;
      if (this.AnimalBreedData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.AnimalBreedData);
      this.listData = new MatTableDataSource(this.AnimalBreedData);
      /* config filter */
      this.listData.filterPredicate = (data: Animalbreed, filter: string) =>
        data.BreedName.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.AnimalBreedValidation.valid) {
      ////console.log("Form Submitted");
      this.AnimalBreedValidation.reset();
    }
  }

  AddBreed() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredCat.next(this.getcatdata.slice());
    this.AnimalBreedValidation.reset();
    this.Breedtype =
      this.Breedtype === "Anaimal Breed"
        ? "Add Anaimal Breed"
        : "Anaimal Breed";
    this.editbreed = this.editbreed === "cancel" ? "add_circle" : "cancel";
    this.editanimalbreed = !this.editanimalbreed;
    this.displayddl = this.editanimalbreed ? "inline" : "none";
    this.displayAnimalbreed();
  }

  CreateAnimalbreed(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.AnimalBreedValidation.valid) {
      Object.keys(this.AnimalBreedValidation.controls).forEach(field => {
        const control = this.AnimalBreedValidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalBreedValidation.controls.created_by.patchValue(0);
      this.ls.saveAnimalbreed(this.AnimalBreedValidation.value).subscribe(
        res => {


          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the AnimnalBreed",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.AnimalBreedValidation.reset();
            this.displayAnimalbreed();
            this.AddBreed();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The AnimnalBreed",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateAnimalBreed(getAnimalbreedDataObj) {
    ////console.log(getAnimalbreedDataObj);
    this.updateAnimalbreed = !this.updateAnimalbreed;
    this.EditAnimalBreed = getAnimalbreedDataObj;
    this.displayddl = !this.editanimalbreed ? "inline" : "none";
    this.AnimalBreedValidation.controls.modified_by.patchValue(0);
    this.AnimalBreedValidation.setValue({
      BreedName: this.EditAnimalBreed.BreedName,
      ImprovedBreedName: this.EditAnimalBreed.ImprovedBreedName,
      LocalBreedName: this.EditAnimalBreed.LocalBreedName,
      BreedType: this.EditAnimalBreed.BreedType,
      PercentageOfimprovedbreed: this.EditAnimalBreed.PercentageOfimprovedbreed,
      PercentageOfLocalbreed: this.EditAnimalBreed.PercentageOfLocalbreed,
      TotalNoOfImprovedbreed: this.EditAnimalBreed.TotalNoOfImprovedbreed,
      MostAvilableLocation: this.EditAnimalBreed.MostAvilableLocation,
      TblAnimalCategory_ID: this.EditAnimalBreed.TblAnimalCategory_ID,
      created_by: this.EditAnimalBreed.created_by,
      modified_by: this.EditAnimalBreed.modified_by
    });
  }

  updateanimalbreed1(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    ////console.log(data);
    if (!this.AnimalBreedValidation.valid) {
      Object.keys(this.AnimalBreedValidation.controls).forEach(field => {
        const control = this.AnimalBreedValidation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.AnimalBreedValidation.controls.modified_by.patchValue(0);
      this.ls
        .updateAnimalbreedById(
          this.EditAnimalBreed.ID,
          this.AnimalBreedValidation.value
        )
        .subscribe(
          res => {

            if (
              this.EditAnimalBreed.BreedName ===
              this.AnimalBreedValidation.controls.BreedName.value &&
              this.EditAnimalBreed.ImprovedBreedName ===
              this.AnimalBreedValidation.controls.ImprovedBreedName.value &&
              this.EditAnimalBreed.LocalBreedName ===
              this.AnimalBreedValidation.controls.LocalBreedName.value &&
              this.EditAnimalBreed.BreedType ===
              this.AnimalBreedValidation.controls.BreedType.value &&
              this.EditAnimalBreed.PercentageOfimprovedbreed ===
              this.AnimalBreedValidation.controls.PercentageOfimprovedbreed
                .value &&
              this.EditAnimalBreed.PercentageOfLocalbreed ===
              this.AnimalBreedValidation.controls.PercentageOfLocalbreed
                .value &&
              this.EditAnimalBreed.TotalNoOfImprovedbreed ===
              this.AnimalBreedValidation.controls.TotalNoOfImprovedbreed
                .value &&
              this.EditAnimalBreed.TblAnimalCategory_ID ===
              this.AnimalBreedValidation.controls.TblAnimalCategory_ID
                .value &&
              this.EditAnimalBreed.MostAvilableLocation ===
              this.AnimalBreedValidation.controls.MostAvilableLocation.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayAnimalbreed();
              this.toggleUpdateanimalbreed2();
            }
          },

        );
    }
  }

  toggleUpdateanimalbreed2() {
    this.updateAnimalbreed = false;
    this.displayddl = this.editanimalbreed ? "inline" : "none";
  }

  deleteAnimalBreed(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteAnimalBreedById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayAnimalbreed();
          }
        });
      }
    });
  }

  toggleViewAnimalBreed(getAnimalbreedDataObj) {
    this.EditAnimalBreed = getAnimalbreedDataObj;
    this.ViewAnimalBreed = !this.ViewAnimalBreed;
    this.displayddl = !this.editanimalbreed ? "inline" : "none";
  }

  toggleViewAnimalBreed1() {
    this.ViewAnimalBreed = false;
    this.displayddl = this.editanimalbreed ? "inline" : "none";
  }
}
