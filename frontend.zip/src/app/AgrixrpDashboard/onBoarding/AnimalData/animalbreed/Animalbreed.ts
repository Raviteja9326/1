export interface Animalbreed {
  ID?: number;
  BreedName?: any;
  ImprovedBreedName?: any;
  LocalBreedName?: any;
  BreedType?: any;
  PercentageOfimprovedbreed?: any;
  PercentageOfLocalbreed?: any;
  TotalNoOfImprovedbreed?: any;
  MostAvilableLocation?: any;
  TblAnimalCategory_ID?: any;
  created_by: any;
  modified_by: any;
}
