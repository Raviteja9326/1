export interface Companymaster {
    ID?: number;
    Companyname?: string;
    created_by: string;
    modified_by: string;
}
