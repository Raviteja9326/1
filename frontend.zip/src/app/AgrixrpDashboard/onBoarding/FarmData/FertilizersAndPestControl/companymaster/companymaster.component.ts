import { Component, OnInit, ViewChild } from "@angular/core";
import { Companymaster } from "./Companymaster";
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder
} from "@angular/forms";
import Swal from "sweetalert2";
import { MatPaginator } from "@angular/material/paginator";
import { MatTableDataSource, MatSort } from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";
@Component({
  selector: "app-companymaster",
  templateUrl: "./companymaster.component.html",
  styleUrls: ["./companymaster.component.scss"]
})
export class CompanymasterComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "Companyname", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  companymstr = this.formBuilder.group({
    Companyname: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  editcompanymastertype = true;
  edittype = "add_circle";
  companymastertypes = "COMPANY MASTER";
  displayddl: String;
  updatecompanymstr = false;
  Editcompanymstr: any = [];
  viewcompanymstrData = false;
  submitted = false;
  usercompanymasterTypeData: any = [];
  EditOldData: any = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  ngOnInit() {
    this.displaycompanymstr();
  }
  displaycompanymstr() {
    this.ls.getCompanyMasterData().subscribe(list => {
      this.isLoading = false;
      this.usercompanymasterTypeData = list;
      if (this.usercompanymasterTypeData.length == 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.usercompanymasterTypeData);
      this.listData = new MatTableDataSource(this.usercompanymasterTypeData);
      /* config filter */
      this.listData.filterPredicate = (data: Companymaster, filter: string) =>
        data.Companyname.toLowerCase().indexOf(filter) != -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length == 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.companymstr.valid) {
      ////console.log("Form Submitted");
      this.companymstr.reset();
    }
  }
  Addcompanymaster() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.companymstr.reset();
    this.companymastertypes =
      this.companymastertypes === "COMPANY MASTER"
        ? "ADD COMPANY MASTER"
        : "COMPANY MASTER";
    this.editcompanymastertype = !this.editcompanymastertype;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editcompanymastertype ? "inline" : "none";
    this.displaycompanymstr();
  }

  CreatecompanymasterType() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.submitted = true;
    if (!this.companymstr.valid) {
      Object.keys(this.companymstr.controls).forEach(field => {
        const control = this.companymstr.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.companymstr.controls.created_by.patchValue(1);
      this.ls.saveCompanyMaster(this.companymstr.value).subscribe(
        res => {


          if (res["data"] == "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CompanyMaster",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.companymstr.reset();
            this.displaycompanymstr();
            this.Addcompanymaster();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The CompanyMaster",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }
  updateCompanymaster1(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.companymstr.valid) {
      Object.keys(this.companymstr.controls).forEach(field => {
        const control = this.companymstr.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.companymstr.controls.modified_by.patchValue(1);
      this.ls
        .updateCompanyMasterById(
          this.Editcompanymstr.ID,
          this.companymstr.value
        )
        .subscribe(
          res => {
            if (
              this.Editcompanymstr.Companyname ==
              this.companymstr.controls.Companyname.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] == "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displaycompanymstr();
              this.toggleUpdatecompanymaster2();
            }
          },

        );
    }
  }

  toggleUpdatecompanymaster(getCompanyMasterDataObj) {
    ////console.log(getCompanyMasterDataObj);
    this.Editcompanymstr = getCompanyMasterDataObj;
    this.updatecompanymstr = !this.updatecompanymstr;
    this.displayddl = !this.editcompanymastertype ? "inline" : "none";
    this.companymstr.controls.modified_by.patchValue(1);
    this.companymstr.setValue({
      Companyname: this.Editcompanymstr.Companyname,
      created_by: this.Editcompanymstr.created_by,
      modified_by: this.Editcompanymstr.modified_by
    });
  }

  toggleUpdatecompanymaster2() {
    this.updatecompanymstr = false;
    this.displayddl = this.editcompanymastertype ? "inline" : "block";
  }

  toggleViewcompanymaster(getCompanyMasterDataObj) {
    ////console.log(getCompanyMasterDataObj);
    this.viewcompanymstrData = !this.viewcompanymstrData;
    this.Editcompanymstr = getCompanyMasterDataObj;
    this.displayddl = !this.Editcompanymstr ? "inline" : "none";
  }

  togglecompanymaster1() {
    this.viewcompanymstrData = false;
    this.displayddl = !this.Editcompanymstr ? "inline" : "block";
  }

  deleteCompanymaster(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteCompanyMasterById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displaycompanymstr();
          }
        });
      }
    });
  }
}
