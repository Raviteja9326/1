export interface PestControl {
    ID?: number;
    PestName?: any;
    PestType?: any;
    PestGivingMethod?: any;
    TblDealer_ID?: any;
    TblFertilizerCompanyMaster_ID?: any;
    created_by: string;
    modified_by: string;
}