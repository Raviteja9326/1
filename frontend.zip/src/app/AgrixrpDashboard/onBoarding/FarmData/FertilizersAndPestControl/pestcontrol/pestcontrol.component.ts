import { Component, OnInit, ViewChild } from "@angular/core";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import { Observable, ReplaySubject, Subject } from "rxjs";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { PestControl } from "./Pestcontrol";
import Swal from "sweetalert2";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { DealerInformation } from "app/AgrixrpDashboard/onBoarding/Raw Material/dealersinformation/dealerinformation";
import { Companymaster } from "../companymaster/Companymaster";
import { MastersService } from "app/services/masters.service";

@Component({
  selector: "app-pestcontrol",
  templateUrl: "./pestcontrol.component.html",
  styleUrls: ["./pestcontrol.component.scss"]
})
export class PestcontrolComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "PestName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public DealerNameFilterCtrl: FormControl = new FormControl();
  public CampanyNameFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredDealerName: ReplaySubject<
    DealerInformation[]
  > = new ReplaySubject<DealerInformation[]>(1);
  public filteredCampanyName: ReplaySubject<
    Companymaster[]
  > = new ReplaySubject<Companymaster[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  editPesticidestype = true;
  updatePestControl = false;
  viewPestControlData = false;
  pesticidestype = "PestControl Data";
  edittype = "add_circle";
  displayddl: String;
  DealerData: DealerInformation[] = [];
  CompanyData: Companymaster[] = [];
  EditPestControl: any = [];
  userPesticidesData: any = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  PestControlData = this.formBuilder.group({
    PestName: ["", [Validators.required, Validators.pattern("^[a-zA-Z\\s]+$")]],
    PestType: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    PestGivingMethod: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    TblDealer_ID: ["", [Validators.required]],
    TblFertilizerCompanyMaster_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.displayPestControldata();
    /*dealer data */
    this.ls.getdealer().subscribe(res => {
      this.DealerData = res;
      ////console.log(this.DealerData);
    });
    this.DealerNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDealerName();
      });
    /*dealer ends */

    /*company data */
    this.ls.getCompanyMasterData().subscribe(res => {
      this.CompanyData = res;
      ////console.log(this.CompanyData);
    });
    this.CampanyNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCompanyName();
      });
    /*company ends */
  }

  /*dealer data*/
  protected filterDealerName() {
    ////console.log("units", this.DealerData);
    if (!this.DealerData) {
      return;
    }
    // get the search keyword
    let search = this.DealerNameFilterCtrl.value;
    ////console.log(this.DealerNameFilterCtrl.value);

    if (!search) {
      this.filteredDealerName.next(this.DealerData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredDealerName.next(
      this.DealerData.filter(
        bank => bank.DealerName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*dealer data ends*/

  /*Company data*/
  protected filterCompanyName() {
    ////console.log("units", this.CompanyData);
    if (!this.CompanyData) {
      return;
    }
    // get the search keyword
    let search = this.CampanyNameFilterCtrl.value;
    ////console.log(this.CampanyNameFilterCtrl.value);

    if (!search) {
      this.filteredCampanyName.next(this.CompanyData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCampanyName.next(
      this.CompanyData.filter(
        bank => bank.Companyname.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*Company data ends*/

  displayPestControldata() {
    this.ls.getPestControldata().subscribe(list => {
      this.isLoading = false;
      this.userPesticidesData = list;
      ////console.log(this.userPesticidesData);

      if (this.userPesticidesData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.userPesticidesData);
      this.listData = new MatTableDataSource(this.userPesticidesData);
      /* config filter */
      this.listData.filterPredicate = (data: PestControl, filter: string) =>
        data.PestName.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.PestControlData.valid) {
      ////console.log("Form Submitted");
      this.PestControlData.reset();
    }
  }

  AddPesticides() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredDealerName.next(this.DealerData.slice());
    this.filteredCampanyName.next(this.CompanyData.slice());
    this.PestControlData.reset();
    this.displayPestControldata();
    this.pesticidestype =
      this.pesticidestype === "PestControl Data"
        ? "Add PestControl Data"
        : "PestControl Data";
    this.editPesticidestype = !this.editPesticidestype;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editPesticidestype ? "inline" : "none";
  }

  CreatePestControlData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.PestControlData.valid) {
      Object.keys(this.PestControlData.controls).forEach(field => {
        const control = this.PestControlData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.PestControlData.controls.created_by.patchValue(0);
      this.ls.savePestControlData(this.PestControlData.value).subscribe(
        res => {

          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the PestControlData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayPestControldata();
            this.AddPesticides();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The PestControlData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdatePesticidesData(getPesticidesDataObj) {
    this.EditPestControl = getPesticidesDataObj;
    this.updatePestControl = !this.updatePestControl;
    this.displayddl = !this.EditPestControl ? "inline" : "none";
    this.PestControlData.controls.modified_by.patchValue(0);
    this.PestControlData.setValue({
      PestName: this.EditPestControl.PestName,
      PestType: this.EditPestControl.PestType,
      PestGivingMethod: this.EditPestControl.PestGivingMethod,
      TblDealer_ID: this.EditPestControl.TblDealer_ID,
      TblFertilizerCompanyMaster_ID: this.EditPestControl
        .TblFertilizerCompanyMaster_ID,
      created_by: this.EditPestControl.created_by,
      modified_by: this.EditPestControl.modified_by
    });
  }

  toggleUpdatePestControlData2() {
    this.updatePestControl = false;
    this.displayddl = this.EditPestControl ? "inline" : "block";
  }

  UpdatePestControlData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.PestControlData.valid) {
      Object.keys(this.PestControlData.controls).forEach(field => {
        const control = this.PestControlData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.PestControlData.controls.modified_by.patchValue(0);
      this.ls
        .updatePestControlDataById(
          this.EditPestControl.ID,
          this.PestControlData.value
        )
        .subscribe(
          res => {
            if (
              this.EditPestControl.PestName ===
              this.PestControlData.controls.PestName.value &&
              this.EditPestControl.PestType ===
              this.PestControlData.controls.PestType.value &&
              this.EditPestControl.PestGivingMethod ===
              this.PestControlData.controls.PestGivingMethod.value &&
              this.EditPestControl.TblDealer_ID ===
              this.PestControlData.controls.TblDealer_ID.value &&
              this.EditPestControl.TblFertilizerCompanyMaster_ID ===
              this.PestControlData.controls.TblFertilizerCompanyMaster_ID
                .value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayPestControldata();
              this.toggleUpdatePestControlData2();
            }
          },

        );
    }
  }

  deletePesticidesData(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deletePesticidesDataById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayPestControldata();
          }
        });
      }
    });
  }

  toggleViewPesticidesData(getPesticidesDataObj) {
    this.viewPestControlData = !this.viewPestControlData;
    this.EditPestControl = getPesticidesDataObj;
    this.displayddl = !this.EditPestControl ? "inline" : "none";
  }

  toggleViewPestControlData1() {
    this.viewPestControlData = false;
    this.displayddl = !this.EditPestControl ? "inline" : "block";
  }
}
