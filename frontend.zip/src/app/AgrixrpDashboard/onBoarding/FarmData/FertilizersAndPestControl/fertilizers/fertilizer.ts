export interface Fertilizer {
    ID?: number;
    FertilizerType?: any;
    FertilizerName?: any;
    VarietyOfFertilizer?: any;
    QuantityOfFertilizer?: any;
    NoOfFertilizerOutlets?: any;
    NameOfFertilizerOutlets?: any;
    TblDealer_ID?: any;
    TblFertilizerCompanyMaster_ID?: any;
    created_by: string;
    modified_by: string;
}
