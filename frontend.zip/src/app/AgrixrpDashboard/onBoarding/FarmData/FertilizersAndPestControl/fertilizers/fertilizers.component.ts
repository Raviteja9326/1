import { Component, OnInit, ViewChild } from "@angular/core";
import { Fertilizer } from "./fertilizer";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import { Observable, ReplaySubject, Subject } from "rxjs";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import Swal from "sweetalert2";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { Companymaster } from "../companymaster/Companymaster";
import { DealerInformation } from "../../../Raw Material/dealersinformation/dealerinformation";
import { MastersService } from "app/services/masters.service";
@Component({
  selector: "app-fertilizers",
  templateUrl: "./fertilizers.component.html",
  styleUrls: ["./fertilizers.component.scss"]
})
export class FertilizersComponent implements OnInit {
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  FertilizerData = this.formBuilder.group({
    FertilizerType: [
      "",
      [Validators.required, Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    FertilizerName: [
      "",
      [Validators.required, Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    VarietyOfFertilizer: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    QuantityOfFertilizer: ["", [Validators.pattern("^[0-9]+$")]],
    NoOfFertilizerOutlets: ["", [Validators.pattern("^[0-9]+$")]],
    NameOfFertilizerOutlets: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    TblDealer_ID: ["", [Validators.required]],
    TblFertilizerCompanyMaster_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  fertilizertype = "Fertilizer Data";
  edittype = "add_circle";
  editFertilizertype = true;
  updateFertilizer = false;
  viewFertilizationData = false;
  displayddl: string;
  userfetilizerData: any = [];
  EditFertilizer: any = [];
  DealerData: DealerInformation[] = [];
  CompanyData: Companymaster[] = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "FertilizerName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public DealerNameFilterCtrl: FormControl = new FormControl();
  public CampanyNameFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredDealerName: ReplaySubject<
    DealerInformation[]
  > = new ReplaySubject<DealerInformation[]>(1);
  public filteredCampanyName: ReplaySubject<
    Companymaster[]
  > = new ReplaySubject<Companymaster[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  AddFertilizer() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredDealerName.next(this.DealerData.slice());
    this.filteredCampanyName.next(this.CompanyData.slice());
    this.FertilizerData.reset();
    this.fertilizertype =
      this.fertilizertype === "Fertilizer Data"
        ? "Add Fertilizer Data"
        : "Fertilizer Data";
    this.editFertilizertype = !this.editFertilizertype;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editFertilizertype ? "inline" : "none";
    this.displayfertilizerdata();
  }

  ngOnInit() {
    this.displayfertilizerdata();
    /*dealer data */
    this.ls.getdealer().subscribe(res => {
      this.DealerData = res;
      ////console.log(this.DealerData);
    });
    this.DealerNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDealerName();
      });
    /*dealer ends */

    /*company data */
    this.ls.getCompanyMasterData().subscribe(res => {
      this.CompanyData = res;
      ////console.log(this.CompanyData);
    });
    this.CampanyNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCompanyName();
      });
    /*company ends */
  }

  /*dealer data*/
  protected filterDealerName() {
    ////console.log("units", this.DealerData);
    if (!this.DealerData) {
      return;
    }
    // get the search keyword
    let search = this.DealerNameFilterCtrl.value;
    ////console.log(this.DealerNameFilterCtrl.value);

    if (!search) {
      this.filteredDealerName.next(this.DealerData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredDealerName.next(
      this.DealerData.filter(
        bank => bank.DealerName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*dealer data ends*/

  /*Company data*/
  protected filterCompanyName() {
    ////console.log("units", this.CompanyData);
    if (!this.CompanyData) {
      return;
    }
    // get the search keyword
    let search = this.CampanyNameFilterCtrl.value;
    ////console.log(this.CampanyNameFilterCtrl.value);

    if (!search) {
      this.filteredCampanyName.next(this.CompanyData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCampanyName.next(
      this.CompanyData.filter(
        bank => bank.Companyname.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*Company data ends*/

  displayfertilizerdata() {
    this.ls.getfertilizerdata().subscribe(list => {
      this.isLoading = false;
      ////console.log("fertilizer list", list);
      this.userfetilizerData = list;
      if (this.userfetilizerData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.userfetilizerData);
      this.listData = new MatTableDataSource(this.userfetilizerData);
      /* config filter */
      this.listData.filterPredicate = (data: Fertilizer, filter: string) =>
        data.FertilizerName.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }
  // userfetilizerData

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    if (this.FertilizerData.valid) {
      ////console.log("Form Submitted");
      this.FertilizerData.reset();
    }
  }

  CreateFertilizerData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.FertilizerData.valid) {
      Object.keys(this.FertilizerData.controls).forEach(field => {
        const control = this.FertilizerData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.FertilizerData.controls.created_by.patchValue(0);
      this.ls.saveFertilizerData(this.FertilizerData.value).subscribe(
        res => {

          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the FertilizerData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayfertilizerdata();
            this.AddFertilizer();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The FertilizerData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateFertilizerData(getfetilizerDataObj) {
    this.EditFertilizer = getfetilizerDataObj;
    this.updateFertilizer = !this.updateFertilizer;
    this.displayddl = !this.EditFertilizer ? "inline" : "none";
    this.FertilizerData.controls.modified_by.patchValue(0);
    this.FertilizerData.setValue({
      FertilizerType: this.EditFertilizer.FertilizerType,
      FertilizerName: this.EditFertilizer.FertilizerName,
      VarietyOfFertilizer: this.EditFertilizer.VarietyOfFertilizer,
      QuantityOfFertilizer: this.EditFertilizer.QuantityOfFertilizer,
      NoOfFertilizerOutlets: this.EditFertilizer.NoOfFertilizerOutlets,
      NameOfFertilizerOutlets: this.EditFertilizer.NameOfFertilizerOutlets,
      TblDealer_ID: this.EditFertilizer.TblDealer_ID,
      TblFertilizerCompanyMaster_ID: this.EditFertilizer
        .TblFertilizerCompanyMaster_ID,
      created_by: this.EditFertilizer.created_by,
      modified_by: this.EditFertilizer.modified_by
    });
  }

  toggleUpdateFertilizerdata2() {
    this.updateFertilizer = false;
    this.displayddl = this.EditFertilizer ? "inline" : "block";
  }

  UpdateFertilizerData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.FertilizerData.valid) {
      Object.keys(this.FertilizerData.controls).forEach(field => {
        const control = this.FertilizerData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.FertilizerData.controls.modified_by.patchValue(0);
      this.ls
        .updateFertilizerDataById(
          this.EditFertilizer.ID,
          this.FertilizerData.value
        )
        .subscribe(
          res => {
            if (
              this.EditFertilizer.FertilizerType ===
              this.FertilizerData.controls.FertilizerType.value &&
              this.EditFertilizer.FertilizerName ===
              this.FertilizerData.controls.FertilizerName.value &&
              this.EditFertilizer.VarietyOfFertilizer ===
              this.FertilizerData.controls.VarietyOfFertilizer.value &&
              this.EditFertilizer.QuantityOfFertilizer ===
              this.FertilizerData.controls.QuantityOfFertilizer.value &&
              this.EditFertilizer.NoOfFertilizerOutlets ===
              this.FertilizerData.controls.NoOfFertilizerOutlets.value &&
              this.EditFertilizer.NameOfFertilizerOutlets ===
              this.FertilizerData.controls.NameOfFertilizerOutlets.value &&
              this.EditFertilizer.TblDealer_ID ===
              this.FertilizerData.controls.TblDealer_ID.value &&
              this.EditFertilizer.TblFertilizerCompanyMaster_ID ===
              this.FertilizerData.controls.TblFertilizerCompanyMaster_ID.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Successfully Updated") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayfertilizerdata();
              this.toggleUpdateFertilizerdata2();
            }
          },

        );
    }
  }

  deleteFertilizerData(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteFertilizerDataById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayfertilizerdata();
          }
        });
      }
    });
  }

  toggleViewFertilizerData(getfetilizerDataObj) {
    this.viewFertilizationData = !this.viewFertilizationData;
    this.EditFertilizer = getfetilizerDataObj;
    this.displayddl = !this.EditFertilizer ? "inline" : "none";
  }

  toggleViewFertilizerData1() {
    this.viewFertilizationData = false;
    this.displayddl = !this.EditFertilizer ? "inline" : "block";
  }
}
