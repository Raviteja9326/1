import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { FarmdataRoutingModule } from './Farmdata-routing.module';
import { FarmdataComponent } from './Farmdata.component';
import { CompanymasterComponent } from './FertilizersAndPestControl/companymaster/companymaster.component';
import { FertilizersComponent } from './FertilizersAndPestControl/fertilizers/fertilizers.component';
import { PestcontrolComponent } from './FertilizersAndPestControl/pestcontrol/pestcontrol.component';

// tslint:disable-next-line:max-line-length
const components = [FarmdataComponent,
    PestcontrolComponent, FertilizersComponent, CompanymasterComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [FarmdataRoutingModule, CommonModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class FarmdataModule { }
