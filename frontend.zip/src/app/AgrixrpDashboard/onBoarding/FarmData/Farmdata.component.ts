import { Component } from '@angular/core';

@Component({
  selector: 'app-Farmdata',
  template: `<router-outlet></router-outlet>`,
})

export class FarmdataComponent {
}