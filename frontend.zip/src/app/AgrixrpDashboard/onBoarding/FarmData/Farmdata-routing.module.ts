import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FarmdataComponent } from './Farmdata.component';
import { CompanymasterComponent } from './FertilizersAndPestControl/companymaster/companymaster.component';
import { FertilizersComponent } from './FertilizersAndPestControl/fertilizers/fertilizers.component';
import { PestcontrolComponent } from './FertilizersAndPestControl/pestcontrol/pestcontrol.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
const routes: Routes = [{
    path: '',
    component: FarmdataComponent,
    children: [
        {
            path: 'Company Master',
            component: CompanymasterComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Fertilizers',
            component: FertilizersComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Pest Control',
            component: PestcontrolComponent, canActivate: [AuthGuardService]
        }
    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class FarmdataRoutingModule { }
