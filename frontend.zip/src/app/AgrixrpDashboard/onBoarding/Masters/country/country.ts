export interface Country {
    ID?: number;
    CountryName?: string;
    CountryCode?: any;
    ISOCode?: any;
}
