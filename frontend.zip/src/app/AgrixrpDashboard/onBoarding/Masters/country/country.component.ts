import { Component, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import Swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder } from '@angular/forms';
import { tap, startWith, debounceTime, switchMap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Country } from './country';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { MastersService } from 'app/services/masters.service';
@Component({
  selector: "app-country",
  templateUrl: "./country.component.html",
  styleUrls: ["./country.component.scss"]
})
export class CountryComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'CountryName', 'CountryCode', 'ISOCode', 'Actions'];
  names: any = [];
  editCountry = true;
  editCountryContent = "add_circle";
  CountryNames = "Country List";
  userCountriesData: any = [];
  displayddl: string;
  updateCountry = false;
  EditCountriesData: any = [];
  EditCoun: any = [];
  EditOldData: any = [];
  submitted = false;
  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<any[]>;
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  CountForm = this.formBuilder.group({
    CountryName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(20), Validators.pattern('^[a-zA-Z ()-.,\\s]+$')]],
    CountryCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(6), Validators.pattern('^[0-9 +]+$')]],
    ISOCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(6), Validators.pattern('^[a-zA-Z]+$')]]
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }


  constructor(private http: HttpClient, private ds: MastersService, private route: Router, private activeRoute: ActivatedRoute,
    private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.displayCountries();
    this.ds.getISOCodes().subscribe(res => {
      this.names = res;
    });

    this.filteredOptions = this.CountForm.controls.CountryName.valueChanges.pipe(
      startWith(''),
      debounceTime(400),
      switchMap(
        value => {
          // ////console.log(value);
          // ////console.log('return data', this.doFilter(value || ''));
          return this.doFilter(value || '');
        }
      )

    )
  }
  doFilter(value) {

    return this.ds.getISOCodes()
      .pipe(
        map(response => response.filter(option => {
          return option.name.toLowerCase().indexOf(value.toLowerCase()) === 0
        }))
      )
  }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  emptyDropDown(event) {
    if (event.target.value.length === 0) {
      this.CountForm.controls.ISOCode.setValue('');
      this.CountForm.controls.CountryCode.setValue('');
    }

  }

  save(event) {
    return event;
  }



  getISOCodesByCountryName(ref) {
    for (let index = 0; index < this.names.length; index++) {
      if (this.names[index].name === ref) {
        this.CountForm.controls.ISOCode.setValue(this.names[index].code);
        this.CountForm.controls.CountryCode.setValue(this.names[index].dial_code);
      } else if (ref === '' || ref === undefined) {
        this.CountForm.controls.ISOCode.setValue('');
        this.CountForm.controls.CountryCode.setValue('');
      }
    }
  }

  displayCountries() {
    this.ds.getCountriesData().subscribe(
      list => {
        this.isLoading = false;
        this.userCountriesData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userCountriesData);
        this.listData.filterPredicate = (data: Country, filter: string) => data.CountryName.toLowerCase().indexOf(filter) !== -1;

        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },

    )
  }



  resetForm() {
    // if (this.CountForm.valid) {
    this.CountForm.reset();
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    // }
  }

  toggleEditCountry() {
    this.CountForm.reset();
    this.displayCountries();
    this.CountryNames =
      this.CountryNames === "Add Country"
        ? "Country List"
        : "Add Country";
    this.editCountryContent =
      this.editCountryContent === "cancel" ? "add_circle" : "cancel";
    this.editCountry = !this.editCountry;
    this.displayddl = this.editCountry ? "inline" : "none";
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  toggleUpdateCountries(getCountriesDataObj) {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.EditCoun = getCountriesDataObj;
    this.updateCountry = !this.updateCountry;
    this.displayddl = !this.editCountry ? "inline" : "none";
    this.CountForm.setValue({
      CountryName: this.EditCoun.CountryName,
      CountryCode: this.EditCoun.CountryCode,
      ISOCode: this.EditCoun.ISOCode,
    });
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  toggleUpdateCountries2() {

    this.updateCountry = false;
    this.displayddl = this.editCountry ? "inline" : "block";
  }







  CreateCountries(countries) {
    this.submitted = true;
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.CountForm.valid) {
      Object.keys(this.CountForm.controls).forEach(field => {
        const control = this.CountForm.get(field);
        control.markAsTouched({ onlySelf: false });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500,
        buttonsStyling: false,
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.saveCountriesData(this.CountForm.value).subscribe(
        res => {
          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Country',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.resetForm();
            this.displayCountries();
            this.toggleEditCountry();
          } else if (res['data'] = "serverErrorCountryExistence") {
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The CountryName',
              showConfirmButton: false,
              timer: 1500
            })
          }
        },
        err => console.error(err)
      )
    }
  }

  updateCountries(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.EditCoun = data;
    if (!this.CountForm.valid) {
      Object.keys(this.CountForm.controls).forEach(field => {
        const control = this.CountForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updateCountriesDataById(this.EditCoun.ID, this.CountForm.value).subscribe(res => {
        // tslint:disable-next-line:max-line-length
        if (this.EditCoun.CountryName === this.CountForm.controls.CountryName.value && this.EditCoun.CountryCode === this.CountForm.controls.CountryCode.value && this.EditCoun.ISOCode === this.CountForm.controls.ISOCode.value) {

          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayCountries();
          this.toggleUpdateCountries2();
        }

      },

      )
    }




  }

  deleteCountries(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deleteCountriesDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayCountries();
            }
          }

        )

      }
    })
  }

}

