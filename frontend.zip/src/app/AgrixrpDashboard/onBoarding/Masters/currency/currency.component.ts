import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Currency } from './currency';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Country } from '../country/country';
import { MastersService } from 'app/services/masters.service';
@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.scss']
})
export class CurrencyComponent implements OnInit, OnDestroy {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'CurrencyName', 'CurrCode', 'Actions'];
  editCurrency = true;
  editCurrencyContent = "add_circle";
  CurrencyNames = "Currency List";
  userCurrencyData: any = [];
  getCurrencyData: any = [];
  EditCurr: any = [];
  updateCurrency = false;
  displayddl: string;
  EditOldData: any = [];
  submitted = false;
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;
  isMobile: any;
  names: any = [];
  name: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  public CounFilterCtrl: FormControl = new FormControl();
  public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  protected _onDestroy = new Subject<void>();

  CurrForm = this.formBuilder.group({
    CurrencyName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20), Validators.pattern('^[a-zA-Z \\s]+$')]],
    CurrCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(6), Validators.pattern('^[a-zA-Z]+$')]],
    TblCountry_CountryID: ['', [Validators.required]]
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }
  constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }
  getISOCodesByCountryName(ref) {
    for (let indexx = 0; indexx < this.getCurrencyData.length; indexx++) {
      if (this.getCurrencyData[indexx].ID === ref) {
        this.name = this.getCurrencyData[indexx].CountryName;
      }
      for (let index = 0; index < this.names.length; index++) {
        if (this.names[index].name === this.name) {
          this.CurrForm.controls.CurrencyName.setValue(this.names[index].currency_name);
          this.CurrForm.controls.CurrCode.setValue(this.names[index].currency_code);
        } else if (ref === '' || ref === undefined) {
          this.CurrForm.controls.CurrencyName.setValue('');
          this.CurrForm.controls.CurrCode.setValue('');
        }
      }
    }
  }

  emptyDropDown(event) {
    if (event.target.value.length === 0) {
      this.CurrForm.controls.CurrencyName.setValue('');
      this.CurrForm.controls.CurrCode.setValue('');
    }

  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  ngOnInit() {
    this.CounFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCountries();
      });
    this.displayCurrency();
    this.ds.getCountriesData().subscribe(res => {
      this.getCurrencyData = res;
    });
    this.ds.getISOCode().subscribe(res => {
      this.names = res;
    });
  }

  protected filterCountries() {
    if (!this.getCurrencyData) {
      return;
    }
    // get the search keyword
    let search = this.CounFilterCtrl.value;
    if (!search) {
      this.filteredCoun.next(this.getCurrencyData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCoun.next(
      this.getCurrencyData.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  displayCurrency() {
    this.ds.getCurrencyData().subscribe(
      list => {
        this.isLoading = false;
        this.userCurrencyData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userCurrencyData);
        this.listData.filterPredicate = (data: Currency, filter: string) => data.CurrencyName.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      })
  }

  resetForm() {
    if (this.CurrForm.valid) {
      this.CurrForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }


  toggleEditCurrency() {
    this.filteredCoun.next(this.getCurrencyData.slice());
    this.CurrForm.reset();
    this.displayCurrency();
    this.CurrencyNames =
      this.CurrencyNames === "Add Currency" ? "Currency List" : "Add Currency";
    this.editCurrencyContent =
      this.editCurrencyContent === "cancel" ? "add_circle" : "cancel";
    this.editCurrency = !this.editCurrency;
    this.displayddl = this.editCurrency ? "inline" : "none";
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  toggleUpdateCurrency(getCurrencyDataObj) {
    this.EditCurr = getCurrencyDataObj;
    this.updateCurrency = !this.updateCurrency;
    this.displayddl = !this.editCurrency ? "inline" : "none";
    this.ds.getCountriesData().subscribe(res => {
      this.getCurrencyData = res;
      for (let data of this.getCurrencyData) {
        if (data.ID === this.EditCurr.TblCountry_CountryID) {
          this.EditCurr.TblCountry_CountryID = data.CountryName;
        }
      }
    });
    this.CurrForm.setValue({
      CurrencyName: this.EditCurr.CurrencyName,
      CurrCode: this.EditCurr.CurrCode,
      TblCountry_CountryID: this.EditCurr.TblCountry_CountryID,
    });
  }

  toggleUpdateCurrency2() {
    this.updateCurrency = false;
    this.displayddl = this.editCurrency ? "inline" : "block";
  }

  CreateCurrency() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.CurrForm.valid) {
      Object.keys(this.CurrForm.controls).forEach(field => {
        const control = this.CurrForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.saveCurrencyData(this.CurrForm.value).subscribe(
        res => {

          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Currency',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.CurrForm.reset();
            this.displayCurrency();
            this.toggleEditCurrency();

          } else if (res['data'] = "serverErrorCurrencyExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists With Country',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        },
        err => console.error(err)
      )
    }

  }

  updateCurr(data) {
    this.EditCurr = data;
    if (!this.CurrForm.valid) {
      Object.keys(this.CurrForm.controls).forEach(field => {
        const control = this.CurrForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updateCurrencyDataById(this.EditCurr.ID, this.CurrForm.value).subscribe(res => {
        // tslint:disable-next-line:max-line-length
        if (this.EditCurr.CurrencyName === this.CurrForm.controls.CurrencyName.value && this.EditCurr.CurrCode === this.CurrForm.controls.CurrCode.value && this.EditCurr.TblCountry_CountryID === this.CurrForm.controls.TblCountry_CountryID.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayCurrency();
          this.toggleUpdateCurrency2();
        }

      },

      )
    }


  }
  deleteCurrency(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deleteCurrencyDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayCurrency();
            }
          }

        )

      }
    })




  }




}
