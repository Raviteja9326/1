export interface Currency {
    ID?:number;
    CurrencyName?: string;
    CurrencySymbol?:string;
    CurrCode?:string;
    TblCountry_CountryID?:number;
}
