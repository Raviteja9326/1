import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from 'app/services/masters.service';
import { States } from './states';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator, MatSelect } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { Country } from '../country/country';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.scss']
})
export class StatesComponent implements OnInit, OnDestroy {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'StateName', 'StateCode', 'Actions'];
  editStates = true;
  editStatesContent = "add_circle";
  StatesNames = "States List";
  userStatesData: any = [];
  EditStatesData: any = [];
  updateStates = false;
  displayddl: string;
  getStatesDt: any = [];
  editSt: any = [];
  EditOldDt: any = [];
  submitted = false;
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;
  isMobile: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CounFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  StateForm = this.formBuilder.group({
    StateName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(40), Validators.pattern('^[a-zA-Z ()-.,\\s]+$')]],
    StateCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(6), Validators.pattern('^[a-zA-Z]+$')]],
    TblCountry_CountryID: ['', [Validators.required]]
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.StateForm.valid) {
      this.StateForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }


  ngOnInit() {
    this.displayStates();
    this.ds.getCountriesData().subscribe(res => {
      this.getStatesDt = res;
    })
    this.CounFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe((val) => {
        this.filterCountries();
      });
  }

  protected filterCountries() {
    if (!this.getStatesDt) {
      return;
    }
    // get the search keyword
    let search = this.CounFilterCtrl.value;
    if (!search) {
      this.filteredCoun.next(this.getStatesDt.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCoun.next(
      this.getStatesDt.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  displayStates() {
    this.ds.getStatesData().subscribe(
      list => {
        this.isLoading = false;
        this.userStatesData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userStatesData);
        this.listData.filterPredicate = (data: States, filter: string) => data.StateName.toLowerCase().indexOf(filter) !== -1;

        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      })
  }


  toggleEditStates() {
    this.StateForm.reset();
    this.displayStates();
    this.StatesNames =
      this.StatesNames === "Add States" ? "States List" : "Add States";
    this.editStatesContent =
      this.editStatesContent === "cancel" ? "add_circle" : "cancel";
    this.editStates = !this.editStates;
    this.displayddl = this.editStates ? "inline" : "none";
  }


  toggleUpdateStates(getStatesDataObj) {
    this.editSt = getStatesDataObj;
    this.updateStates = !this.updateStates;
    this.displayddl = !this.editStates ? "inline" : "none";
    this.ds.getCountriesData().subscribe(res => {
      this.getStatesDt = res;
      for (let data of this.getStatesDt) {
        if (data.ID === this.editSt.TblCountry_CountryID) {
          this.editSt.TblCountry_CountryID = data.CountryName;
        }
      }
    })
    this.StateForm.setValue({
      StateName: this.editSt.StateName,
      StateCode: this.editSt.StateCode,
      TblCountry_CountryID: this.editSt.TblCountry_CountryID,
    });
  }

  toggleUpdateStates2() {
    this.updateStates = false;
    this.displayddl = this.editStates ? "inline" : "block";
  }


  CreateStates() {
    this.submitted = true;
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.StateForm.valid) {
      Object.keys(this.StateForm.controls).forEach(field => {
        const control = this.StateForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.saveStatesData(this.StateForm.value).subscribe(
        res => {

          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the States',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.displayStates();
            this.toggleEditStates();
          } else if (res['data'] = "serverErrorStateExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The StateName',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }
  }

  updateStat(data) {
    //console.log(data)
    if (!this.StateForm.valid) {
      Object.keys(this.StateForm.controls).forEach(field => {
        const control = this.StateForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updateStatesDataById(this.editSt.ID, this.StateForm.value).subscribe(res => {
        // tslint:disable-next-line:max-line-length
        if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayStates();
          this.toggleUpdateStates2();
        }

      },

      )
    }


  }


  deleteStates(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deleteStatesDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayStates();
            }
          }

        )

      }
    })




  }



}
