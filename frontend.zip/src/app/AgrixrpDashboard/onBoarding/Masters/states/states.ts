export interface States {
    ID?:number;
    StateName?: string;
    StateCode?:string;
    TblCountry_CountryID?:number;
}
