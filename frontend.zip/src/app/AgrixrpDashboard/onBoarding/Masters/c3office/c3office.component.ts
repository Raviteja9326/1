import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from 'app/services/masters.service';
import { Districts } from '../districts/districts';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { Country } from '../country/country';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil } from 'rxjs/operators';
import { States } from '../states/states';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';


@Component({
	selector: 'app-c3office',
	templateUrl: './c3office.component.html',
	styleUrls: ['./c3office.component.scss']
})
export class C3officeComponent implements OnInit {
	[x: string]: any;
	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'C3OfficeName', 'Actions'];
	editC3office = true;
	editC3officeContent = 'add_circle';
	C3officeNames = 'C3office List';
	userC3officeData: any = [];
	EditC3officeData: any = [];
	updateC3office = false;
	viewC3office = false;
	displayddl: string;
	EditOldC3office: any = [];
	states: States[] = [];
	distr: Districts[] = [];
	getC3officeData: Country[] = [];
	editall: any = [];
	isLoading = true;
	secretKey: string;
	displayNoRecords = false;
	isMobile: any;
	viewall: any;

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;

	/** control for the MatSelect filter keyword */
	public CounFilterCtrl: FormControl = new FormControl();
	public StsFilterCtrl: FormControl = new FormControl();
	public DtsFilterCtrl: FormControl = new FormControl();

	/** list of banks filtered by search keyword */
	public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
	public filteredSts: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
	public filteredDts: ReplaySubject<Districts[]> = new ReplaySubject<Districts[]>(1);
	@ViewChild('singleSelect', { static: true })
	singleSelect: MatSelect;
	/** Subject that emits when the component has been destroyed. */

	protected _onDestroy = new Subject<void>();

	C3OfficeForm = this.formBuilder.group({
		Name: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(20)]],
		Address: ['', [Validators.required, Validators.maxLength(500)]],
		TblDistrict_ID: ['', [Validators.required]],
		TblCountry_ID: ['', [Validators.required]],
		TblState_ID: ['', [Validators.required]],
		created_by: [''],
		modified_by: ['']
	});

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	ngOnDestroy() {
		this._onDestroy.next();
		this._onDestroy.complete();
	}

	resetdrop(event) {
		this.filteredSts.next((this.states = []));
		this.filteredDts.next((this.distr = []));
		this.states = [];
		this.distr = [];
	}

	resetForm() {
		this.resetdrop(event);
		if (this.C3OfficeForm.valid) {
			this.C3OfficeForm.reset();
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		}
	}

	ngOnInit() {
		this.displayC3office();
		this.ds.getCountriesData().subscribe((res) => {
			//console.log(res);
			this.getC3officeData = res;
		});
		// listen for search field value changes
		this.CounFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterCountries();
		});

		this.StsFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterStates();
		});
		this.DtsFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterDists();
		});
	}

	protected filterCountries() {
		//console.log('ssaz', this.getC3officeData);
		if (!this.getC3officeData) {
			return;
		}
		// get the search keyword
		let search = this.CounFilterCtrl.value;
		if (!search) {
			this.filteredCoun.next(this.getC3officeData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredCoun.next(
			this.getC3officeData.filter((bank) => bank.CountryName.toLowerCase().indexOf(search) > -1)
		);
	}


	protected filterStates() {
		//console.log('ssaz', this.states);
		if (!this.getC3officeData) {
			return;
		}
		// get the search keyword
		let search = this.StsFilterCtrl.value;
		if (!search) {
			this.filteredSts.next(this.states.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredSts.next(this.states.filter((bank) => bank.StateName.toLowerCase().indexOf(search) > -1));
	}

	protected filterDists() {
		//console.log('ssaz', this.distr);
		if (!this.states) {
			return;
		}
		// get the search keyword
		let search = this.DtsFilterCtrl.value;
		if (!search) {
			this.filteredDts.next(this.distr.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredDts.next(this.distr.filter((bank) => bank.DistrictName.toLowerCase().indexOf(search) > -1));
	}

	displayC3office() {
		this.ds.getC3officeData().subscribe((list) => {
			//console.log('list of data', list);
			this.isLoading = false;
			this.userC3officeData = list;
			//console.log(this.userC3officeData);
			if (list.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			this.listData = new MatTableDataSource(this.userC3officeData);
			// this.listData.filterPredicate = (data: C3office, filter: string) => data.C3OfficeName.toLowerCase().indexOf(filter) !== -1;

			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	toggleEditC3office() {
		this.filteredCoun.next(this.getC3officeData.slice());
		this.displayC3office();
		this.resetdrop(event);
		this.C3OfficeForm.reset();
		this.C3officeNames = this.C3officeNames === 'Add C3office' ? 'C3office List' : 'Add C3office';
		this.editC3officeContent = this.editC3officeContent === 'cancel' ? 'add_circle' : 'cancel';
		this.editC3office = !this.editC3office;
		this.displayddl = this.editC3office ? 'inline' : 'none';
	}

	toggleUpdateC3office(getC3officeDataObj) {
		this.editall = getC3officeDataObj;
		this.updateC3office = !this.updateC3office;
		this.displayddl = !this.editC3office ? 'inline' : 'none';
		this.ds.getStatesDataByCountry(this.editall.TblCountry_ID).subscribe((res) => {
			this.states = res;
			for (let indexx = 0; indexx < this.getC3officeData.length; indexx++) {
				if (this.getC3officeData[indexx].ID === this.editall.TblCountry_ID) {
					this.editall.TblCountry_ID = this.getC3officeData[indexx].CountryName;
				}
			}
			for (let datast of this.states) {
				if (datast.ID === this.editall.TblState_ID) {
					this.editall.TblState_ID = datast.StateName;
				}
			}
		});
		this.ds.getDistrictDataByDist(this.editall.TblState_ID).subscribe((res) => {
			this.distr = res;
			for (let datast of this.distr) {
				if (datast.ID === this.editall.TblDistrict_ID) {
					this.editall.TblDistrict_ID = datast.DistrictName;
				}
			}
		});


		this.C3OfficeForm.patchValue({
			Name: this.editall.Name,
			TblDistrict_ID: this.editall.TblDistrict_ID,
			TblCountry_ID: this.editall.TblCountry_ID,
			TblState_ID: this.editall.TblState_ID,
			Address: this.editall.Address
		});

	}

	toggleUpdateC3office2() {
		this.updateC3office = false;
		this.displayddl = this.editC3office ? 'inline' : 'block';
	}

	onChangestates(ID: string) {
		if (ID) {
			this.states = [];
			this.distr = [];
			this.ds.getStatesDataByCountry(ID).subscribe((res) => {
				if (res['data'] === 'No Data Available with this ID') {
					Swal.fire({
						position: 'center',
						type: 'info',
						title: 'No States Available',
						showConfirmButton: false,
						timer: 1500
					});
					this.C3OfficeForm.controls.TblState_ID.patchValue('');
					this.filteredSts.next(this.states.slice());
					this.C3OfficeForm.controls.TblDistrict_ID.patchValue('');
					this.filteredDts.next(this.distr.slice());
				} else {
					this.C3OfficeForm.controls.TblState_ID.patchValue('');
					this.states = res;
					this.filteredSts.next(this.states.slice());



				}
			});
		}
	}

	onChangedist(ID: string) {
		if (ID) {
			this.distr = [];
			this.ds.getDistrictDataByDist(ID).subscribe((res) => {
				if (res['data'] === 'No Data Available with this ID') {
					Swal.fire({
						position: 'center',
						type: 'info',
						title: 'No Districts Available',
						showConfirmButton: false,
						timer: 1500
					});
					this.C3OfficeForm.controls.TblDistrict_ID.patchValue('');
					this.filteredDts.next(this.distr.slice());
				} else {
					this.C3OfficeForm.controls.TblDistrict_ID.patchValue('');
					this.distr = res;
					this.filteredDts.next(this.distr.slice());

				}
			});
		}
	}

	createC3office() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.C3OfficeForm.valid) {
			Object.keys(this.C3OfficeForm.controls).forEach((field) => {
				const control = this.C3OfficeForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Mandatory Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.C3OfficeForm.controls.created_by.patchValue('1');
			this.ds.saveC3officeData(this.C3OfficeForm.value).subscribe(
				(res) => {
					//console.log(res);
					if (res['data'] === 'Successfully Posted') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Successfully Added',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayC3office();
						this.toggleEditC3office();
					} else if ((res['data'] = 'serverErrorC3OfficeExistence')) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The C3officeName',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					}
				},
				(err) => console.error(err)
			);
		}
	}

	deleteC3office(id: string) {
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ds.deleteC3officeDataById(id).subscribe((res) => {
					if ((res['data'] = 'Successfully Deleted')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayC3office();
					}
				});
			}
		});
	}

	updateC3Office(data) {
		//console.log(data);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		this.editall = data;
		if (!this.C3OfficeForm.valid) {
			Object.keys(this.C3OfficeForm.controls).forEach((field) => {
				const control = this.C3OfficeForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Mandatory Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.ds.updateC3officeDataById(this.editall.ID, this.C3OfficeForm.value).subscribe(
				(res) => {
					// tslint:disable-next-line:max-line-length
					if (
						this.editall.Name === this.C3OfficeForm.controls.Name.value &&
						this.editall.TblDistrict_ID === this.C3OfficeForm.controls.TblDistrict_ID.value &&
						this.editall.TblCountry_ID === this.C3OfficeForm.controls.TblCountry_ID.value &&
						this.editall.TblState_ID === this.C3OfficeForm.controls.TblState_ID.value &&
						this.editall.Address === this.C3OfficeForm.controls.Address.value
					) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['data'] === 'Successfully Updated') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Edited',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayC3office();
						this.toggleUpdateC3office2();
					}
				},
				(err) => console.log(err)
			);
		}
	}

	toggleViewC3office(getC3officeDataObj) {
		this.viewall = getC3officeDataObj;
		this.ds.getStatesDataByCountry(this.viewall.TblCountry_ID).subscribe((res) => {
			this.states = res;
			for (let indexx = 0; indexx < this.getC3officeData.length; indexx++) {
				if (this.getC3officeData[indexx].ID === this.viewall.TblCountry_ID) {
					this.viewall.TblCountry_ID = this.getC3officeData[indexx].CountryName;
				}
			}
			for (let datast of this.states) {
				if (datast.ID === this.viewall.TblState_ID) {
					this.viewall.TblState_ID = datast.StateName;
				}
			}
		});
		this.ds.getDistrictDataByDist(this.viewall.TblState_ID).subscribe((res) => {
			this.distr = res;
			for (let datast of this.distr) {
				if (datast.ID === this.viewall.TblDistrict_ID) {
					this.viewall.TblDistrict_ID = datast.DistrictName;
				}
			}
		});
		this.viewC3office = !this.viewC3office;
		this.displayddl = !this.editC3office ? 'inline' : 'none';
	}

	toggleViewC3office1() {
		this.viewC3office = false;
		this.displayddl = this.editC3office ? 'inline' : 'block';
	}
}
