import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { C3officeComponent } from './c3office.component';

describe('C3officeComponent', () => {
  let component: C3officeComponent;
  let fixture: ComponentFixture<C3officeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ C3officeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(C3officeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
