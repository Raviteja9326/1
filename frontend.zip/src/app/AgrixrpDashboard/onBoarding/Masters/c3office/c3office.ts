export interface C3office {
    ID?: number;
    Name?: string;
    Address?: any;
    TblDistrict_ID?: number;
    TblCountry_ID?: number;
    TblState_ID?: number;
    created_by?: number;
    modified_by?: number;
}
