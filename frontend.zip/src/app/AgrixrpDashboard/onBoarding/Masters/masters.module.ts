import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MastersRoutingModule } from './masters-routing.module';
import { MastersComponent } from './masters.component';
import { CountryComponent } from './country/country.component';
import { CurrencyComponent } from './currency/currency.component';
import { DistrictsComponent } from './districts/districts.component';
import { MandalsComponent } from './mandals/mandals.component';
import { RevenueComponent } from './revenue/revenue.component';
import { StatesComponent } from './states/states.component';
import { VillagesComponent } from './villages/villages.component';
import { VillagesarpanchComponent } from './villagesarpanch/villagesarpanch.component';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { NgxMatSelectSearchModule } from '../../maincomponents/mat-select-search/ngx-mat-select-search.module';
import { MatTableExporterModule } from 'mat-table-exporter';
import { C3officeComponent } from './c3office/c3office.component';

// tslint:disable-next-line:max-line-length
const components = [MastersComponent, C3officeComponent, CountryComponent, CurrencyComponent, DistrictsComponent, MandalsComponent, RevenueComponent, StatesComponent, VillagesComponent, VillagesarpanchComponent];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [MastersRoutingModule, CommonModule, MatTableExporterModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class MastersModule { }
