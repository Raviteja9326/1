import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from 'app/services/masters.service';
import { Villagesarpanch } from './villagesarpanch';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil } from 'rxjs/operators';
import { States } from '../states/states';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Districts } from '../districts/districts';
import { Mandals } from '../mandals/mandals';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
@Component({
  selector: 'app-villagesarpanch',
  templateUrl: './villagesarpanch.component.html',
  styleUrls: ['./villagesarpanch.component.scss']
})
export class VillagesarpanchComponent implements OnInit, OnDestroy {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'VillageSarpanchName', 'VillageSarpanchAddress', 'VillageSarpanchContactnumber', 'Actions'];
  editvillagesarpanch = true;
  editvillagesarpanchContent = "add_circle";
  villagesarpanchNames = "VillageSarpanch List";
  uservillagesarpanchData: any = [];
  EditvillagesarpanchData: any = [];
  updatevillagesarpanch = false;
  displayddl: string;
  getVillData: any = [];
  getvillsts: States[] = [];
  getvilldts: Districts[] = [];
  getvillmand: Mandals[] = [];
  sendVill: any = [];
  editsarpach: any = [];
  EditOldsar: any = [];
  isLoading = true;
  secretKey: string;
  getvillId: any[] = []
  displayNoRecords = false;
  isMobile: any;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  villageSarpanchForm = this.formBuilder.group({
    // tslint:disable-next-line:max-line-length
    VillageSarpanchName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(30), Validators.pattern('^[a-zA-Z\\s]+$')]],
    VillageSarpanchContactnumber: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
    // tslint:disable-next-line: max-line-length
    VillageSarpanchAddress: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(30), Validators.pattern('^[a-zA-Z\\s]+$')]],
    TblVillage_ID: ['', [Validators.required]],
    TblCountry_CountryID: ['', [Validators.required]],
    TblState_StateID: ['', [Validators.required]],
    Tbldist_distID: ['', [Validators.required]],
    Tblmandal_mandalID: ['', [Validators.required]],
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  _keyPress(event: any) {
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();

    }
  }

  constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }


  ngOnDestroy() {
  }


  resetdrop(event) {
    this.getvillsts = [];
    this.getvilldts = [];
    this.getvillmand = []
  }

  resetForm() {
    this.resetdrop(event);
    if (this.villageSarpanchForm.valid) {
      this.villageSarpanchForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }


  ngOnInit() {
    this.displayVillagesarpanch();
    this.ds.getCountriesData().subscribe(res => {

      this.getVillData = res;
    });
  }

  displayVillagesarpanch() {
    this.ds.getvillagesarpanchData().subscribe(list => {
      this.isLoading = false;
      this.uservillagesarpanchData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.uservillagesarpanchData);
      // tslint:disable-next-line: max-line-length
      this.listData.filterPredicate = (data: Villagesarpanch, filter: string) => data.VillageSarpanchName.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    })
  }


  toggleEditvillagesarpanch() {
    this.displayVillagesarpanch();
    this.resetdrop(event);
    this.villageSarpanchForm.reset();
    this.villagesarpanchNames =
      this.villagesarpanchNames === "Add VillageSarpanch" ? "VillageSarpanch List" : "Add VillageSarpanch";
    this.editvillagesarpanchContent =
      this.editvillagesarpanchContent === "cancel" ? "add_circle" : "cancel";
    this.editvillagesarpanch = !this.editvillagesarpanch;
    this.displayddl = this.editvillagesarpanch ? "inline" : "none";
  }


  toggleUpdatevillagesarpanch(getvillagesarpanchDataObj) {
    this.editsarpach = getvillagesarpanchDataObj;
    this.updatevillagesarpanch = !this.updatevillagesarpanch;
    this.displayddl = !this.editvillagesarpanch ? "inline" : "none";
    this.ds.getStatesDataByCountry(this.editsarpach.TblCountry_CountryID).subscribe(res => {
      this.getvillsts = res;
    })
    this.ds.getDistrictDataByDist(this.editsarpach.TblState_StateID).subscribe(res => {
      this.getvilldts = res;
    })
    this.ds.getMandalsDataBydist(this.editsarpach.Tbldist_distID).subscribe(res => {
      this.getvillmand = res;
    })
    this.ds.getVillagesDataByMandalID(this.editsarpach.Tblmandal_mandalID).subscribe(res => {
      this.getvillId = res;
    })
    this.villageSarpanchForm.setValue({
      VillageSarpanchName: this.editsarpach.VillageSarpanchName,
      VillageSarpanchContactnumber: this.editsarpach.VillageSarpanchContactnumber,
      VillageSarpanchAddress: this.editsarpach.VillageSarpanchAddress,
      TblVillage_ID: this.editsarpach.TblVillage_ID,
      TblCountry_CountryID: this.editsarpach.TblCountry_CountryID,
      TblState_StateID: this.editsarpach.TblState_StateID,
      Tbldist_distID: this.editsarpach.Tbldist_distID,
      Tblmandal_mandalID: this.editsarpach.Tblmandal_mandalID
    });
  }

  toggleUpdatevillagesarpanch2() {
    this.updatevillagesarpanch = false;
    this.displayddl = this.updatevillagesarpanch ? "inline" : "block";
  }


  onChangeCountry(ID: string) {
    if (ID) {
      this.ds.getStatesDataByCountry(ID).subscribe(res => {
        if (res['data'] === "NO States Available with this Country ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No States Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.getvillsts = [];
          this.getvilldts = [];
          this.getvillmand = [];
          this.villageSarpanchForm.controls.TblState_StateID.patchValue('');
          this.villageSarpanchForm.controls.Tbldist_distID.patchValue('');
          this.villageSarpanchForm.controls.Tblmandal_mandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The States',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageSarpanchForm.controls.TblState_StateID.patchValue('');
          this.getvillsts = res;
          this.getvilldts = [];
        }
      })
    }
  }

  onChangedist(ID: string) {
    if (ID) {
      this.ds.getDistrictDataByDist(ID).subscribe(res => {
        if (res['data'] === "No Districts Available With This ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Districts Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.getvilldts = [];
          this.getvillmand = [];
          this.villageSarpanchForm.controls.Tbldist_distID.patchValue('');
          this.villageSarpanchForm.controls.Tblmandal_mandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Districts',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageSarpanchForm.controls.Tbldist_distID.patchValue('');
          this.getvilldts = res;
          this.getvillmand = [];
        }
      })
    }
  }

  onChangeMandals(ID: string) {
    if (ID) {
      this.ds.getMandalsDataBydist(ID).subscribe(res => {
        if (res['data'] === "No Mandals Available With This ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Mandals Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.getvillmand = [];
          this.getvillId = [];
          this.villageSarpanchForm.controls.Tblmandal_mandalID.patchValue('');
          this.villageSarpanchForm.controls.TblVillage_ID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Mandals',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageSarpanchForm.controls.Tblmandal_mandalID.patchValue('');
          this.getvillmand = res;
          this.getvillId = [];
        }
      })
    }
  }

  onChangeVillages(ID: string) {
    if (ID) {
      this.ds.getVillagesDataByMandalID(ID).subscribe(res => {
        if (res['data'] === "No Data Available with this ID :-(") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Villages Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.getvillId = [];
          this.villageSarpanchForm.controls.TblVillage_ID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Vilages',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageSarpanchForm.controls.TblVillage_ID.patchValue('');
          this.getvillId = res;
        }
      })
    }
  }



  CreatevillageSarpanch() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.villageSarpanchForm.valid) {
      Object.keys(this.villageSarpanchForm.controls).forEach(field => {
        const control = this.villageSarpanchForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.savevillagesarpanchData(this.villageSarpanchForm.value).subscribe(
        res => {
          if (res['data'] === "successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully Added The VillageSarpanch',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.displayVillagesarpanch();
            this.toggleEditvillagesarpanch();
          } else if (res['data'] = "serverErrorVillageSarpanchExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The VillageSarpanch Name',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }

  }

  Updatevillagesarpanch(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.editsarpach = data;
    if (!this.villageSarpanchForm.valid) {
      Object.keys(this.editsarpach.controls).forEach(field => {
        const control = this.editsarpach.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updatevillagesarpanchDataById(this.editsarpach.ID, this.villageSarpanchForm.value).subscribe(res => {
        if (this.editsarpach.VillageSarpanchName === this.villageSarpanchForm.controls.VillageSarpanchName.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayVillagesarpanch();
          this.toggleUpdatevillagesarpanch2();
        }

      },

      )
    }


  }

  deletevillagesarpanch(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and All The Inter-linking Connections will be Deleted!",
      type: 'error',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deletevillagesarpanchDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayVillagesarpanch();
            }
          }

        )

      }
    })
  }


}
