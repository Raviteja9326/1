import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VillagesarpanchComponent } from './villagesarpanch.component';

describe('VillagesarpanchComponent', () => {
  let component: VillagesarpanchComponent;
  let fixture: ComponentFixture<VillagesarpanchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VillagesarpanchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VillagesarpanchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
