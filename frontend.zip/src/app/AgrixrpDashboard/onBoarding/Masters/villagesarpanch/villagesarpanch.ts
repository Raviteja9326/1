export interface Villagesarpanch {
    ID?: number;
    VillageSarpanchName?: string;
    VillageSarpanchContactnumber?: string;
    VillageSarpanchAddress?:string;
    TblVillage_ID?:number;
    TblCountry_CountryID?:number;
    TblState_StateID?:number;
    Tbldist_distID?:number;
    Tblmandal_mandalID?:number
}
