import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from '../../../../services/masters.service';
import { Districts } from './districts';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { Country } from '../country/country';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil } from 'rxjs/operators';
import { States } from '../states/states';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
@Component({
  selector: 'app-districts',
  templateUrl: './districts.component.html',
  styleUrls: ['./districts.component.scss']
})
export class DistrictsComponent implements OnInit, OnDestroy {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'DistrictName', 'DistrictCollector', 'Actions'];
  userDistData: any = [];
  editDist = true;
  editDistContent = "add_circle";
  DistNames = "Districts List";
  EditDistrictsData: any = [];
  updateDistricts = false;
  displayddl: string;
  getDistData: Country[] = []
  editdist: any = [];
  editdist1: any;
  states: States[] = [];
  EditOldDist: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CounFilterCtrl: FormControl = new FormControl();
  public StsFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  public filteredSts: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  distForm = this.formBuilder.group({
    // tslint:disable-next-line:max-line-length
    DistrictName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(30), Validators.pattern('^[a-zA-Z ()-.,\\s]+$')]],
    // tslint:disable-next-line:max-line-length
    DistrictCollector: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(35), Validators.pattern('^[a-zA-Z ()-.,\\s]+$')]],
    TblState_TblCountry_CountryID: ['', [Validators.required]],
    TblState_StateID: ['', [Validators.required]]
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }



  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }



  resetdrop(event) {
    this.filteredSts.next(this.states = []);
    this.states = [];
  }

  resetForm() {
    this.resetdrop(event);
    if (this.distForm.valid) {
      this.distForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }

  ngOnInit() {
    this.CounFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCountries();
      });
    this.displayDistricts();
    this.ds.getCountriesData().subscribe(res => {
      this.getDistData = res;

    })
    // listen for search field value changes
    this.CounFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe((val) => {
        this.filterCountries();
      });

    this.StsFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterStates();
      });

  }

  protected filterCountries() {
    if (!this.getDistData) {
      return;
    }
    // get the search keyword
    let search = this.CounFilterCtrl.value;
    if (!search) {
      this.filteredCoun.next(this.getDistData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCoun.next(
      this.getDistData.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  protected filterStates() {
    if (!this.states) {
      return;
    }
    // get the search keyword
    let search = this.StsFilterCtrl.value;
    if (!search) {
      this.filteredSts.next(this.states.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredSts.next(
      this.states.filter(bank => bank.StateName.toLowerCase().indexOf(search) > -1)
    );
  }

  displayDistricts() {
    this.ds.getDistrictsData().subscribe(

      list => {
        this.isLoading = false;
        this.userDistData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userDistData);
        this.listData.filterPredicate = (data: Districts, filter: string) => data.DistrictName.toLowerCase().indexOf(filter) !== -1;

        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
    )
  }

  toggleEditDist() {
    this.filteredCoun.next(this.getDistData.slice());
    this.displayDistricts();
    this.resetdrop(event);
    this.distForm.reset();
    this.DistNames =
      this.DistNames === "Add Districts" ? "Districts List" : "Add Districts";
    this.editDistContent =
      this.editDistContent === "cancel" ? "add_circle" : "cancel";
    this.editDist = !this.editDist;
    this.displayddl = this.editDist ? "inline" : "none";
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  onChangeCountry(ID: string) {
    if (ID) {
      this.ds.getStatesDataByCountry(ID).subscribe(res => {
        if (res['data'] === "No Data Available with this ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No States Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.states = [];
          this.resetdrop(event);
          this.distForm.controls.TblState_StateID.patchValue('')
        } else {
          this.distForm.controls.TblState_StateID.patchValue('')
          this.states = res;
          this.filteredSts.next(this.states.slice());
        }
      })
    }
  }





  toggleUpdateDistricts(getDistDataObj) {
    this.editdist = getDistDataObj;
    this.updateDistricts = !this.updateDistricts;
    this.displayddl = !this.editDist ? "inline" : "none";

    this.distForm.setValue({
      DistrictName: this.editdist.DistrictName,
      DistrictCollector: this.editdist.DistrictCollector,
      TblState_TblCountry_CountryID: this.editdist.TblState_TblCountry_CountryID,
      TblState_StateID: this.editdist.TblState_StateID
    })
    this.ds.getStatesDataByCountry(this.editdist.TblState_TblCountry_CountryID).subscribe(res => {
      this.states = res;
      for (let data of this.getDistData) {
        if (data.ID === this.editdist.TblState_TblCountry_CountryID) {
          this.editdist.TblState_TblCountry_CountryID = data.CountryName;
        }
      }
      for (let datast of this.states) {
        if (datast.ID === this.editdist.TblState_StateID) {
          this.editdist.TblState_StateID = datast.StateName;
        }
      }
    })
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  toggleUpdateDistricts2() {
    this.updateDistricts = false;
    this.displayddl = this.editDist ? "inline" : "block";
  }

  CreateDistricts() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.distForm.valid) {
      Object.keys(this.distForm.controls).forEach(field => {
        const control = this.distForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.saveDistrictsData(this.distForm.value).subscribe(
        res => {
          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully added the Districts',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.displayDistricts();
            this.toggleEditDist();
          } else if (res['data'] = "serverErrorCountryExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The DistrictName',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }
  }



  updateDist(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.editdist = data;
    if (!this.distForm.valid) {
      Object.keys(this.distForm.controls).forEach(field => {
        const control = this.distForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updateDistrictsDataById(this.editdist.ID, this.distForm.value).subscribe(res => {
        // tslint:disable-next-line:max-line-length
        if (this.editdist.DistrictName === this.distForm.controls.DistrictName.value && this.editdist.DistrictCollector === this.distForm.controls.DistrictCollector.value && this.editdist.TblState_TblCountry_CountryID === this.distForm.controls.TblState_TblCountry_CountryID.value && this.editdist.TblState_StateID === this.distForm.controls.TblState_StateID.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayDistricts();
          this.toggleUpdateDistricts2();
        }

      },

      )
    }


  }

  deleteDistricts(id: string) {

    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deleteDistrictsDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayDistricts();
            }
          }
        )
      }
    })

  }


}
