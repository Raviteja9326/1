export interface Districts {
    ID?:number;
    DistrictName:string;
    DistrictCollector:string;
    TblState_TblCountry_CountryID?:number;
    TblState_StateID?:number;
}
