import { Component } from '@angular/core';

@Component({
  selector: 'app-masters',
  template: `<router-outlet></router-outlet>`,
})

export class MastersComponent {
}
