export interface Mandals {
    ID?: number;
    MandalName?: string;
    TblDistrict_DistrictID?: number;
    TblCountry_CountryID?: number;
    TblState_StateID?: number
    TblC3Office_C3OfficeID?: number;
}
