import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from 'app/services/masters.service';
import { Districts } from '../districts/districts';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { Country } from '../country/country';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil } from 'rxjs/operators';
import { States } from '../states/states';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Mandals } from './mandals';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { CASService } from 'app/services/cas.service';
import { C3office } from '../c3office/c3office';
@Component({
	selector: 'app-mandals',
	templateUrl: './mandals.component.html',
	styleUrls: ['./mandals.component.scss']
})
export class MandalsComponent implements OnInit, OnDestroy {
	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'MandalName', 'Actions'];
	editMandals = true;
	editMandalsContent = 'add_circle';
	MandalsNames = 'Mandals List';
	userMandalsData: any = [];
	EditMandalsData: any = [];
	updateMandals = false;
	displayddl: string;
	EditOldMandals: any = [];
	states: States[] = [];
	distr: Districts[] = [];
	getMandalsData: Country[] = [];
	C3Off: C3office[] = [];
	editall: any = [];
	isLoading = true;
	secretKey: string;
	displayNoRecords = false;
	isMobile: any;
	createBtn: boolean;
	editBtn: boolean;

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;

	/** control for the MatSelect filter keyword */
	public CounFilterCtrl: FormControl = new FormControl();
	public StsFilterCtrl: FormControl = new FormControl();
	public DtsFilterCtrl: FormControl = new FormControl();
	public C3OFilterCtrl: FormControl = new FormControl();

	/** list of banks filtered by search keyword */
	public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
	public filteredSts: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
	public filteredDts: ReplaySubject<Districts[]> = new ReplaySubject<Districts[]>(1);
	public filteredC3O: ReplaySubject<C3office[]> = new ReplaySubject<C3office[]>(1);
	@ViewChild('singleSelect', { static: true })
	singleSelect: MatSelect;
	/** Subject that emits when the component has been destroyed. */

	protected _onDestroy = new Subject<void>();

	madForm = this.formBuilder.group({
		MandalName: [
			'',
			[
				Validators.required,
				Validators.minLength(4),
				Validators.maxLength(20),
				Validators.pattern('^[a-zA-Z\\s]+$')
			]
		],
		TblDistrict_DistrictID: ['', [Validators.required]],
		TblCountry_CountryID: ['', [Validators.required]],
		TblState_StateID: ['', [Validators.required]],
		TblC3Office_C3OfficeID: ['', [Validators.required]]
	});

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};
	viewBtn: boolean;
	deleteBtn: boolean;


	constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder, private casService: CASService) { }

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	ngOnDestroy() {
		this._onDestroy.next();
		this._onDestroy.complete();
	}

	resetdrop(event) {
		this.filteredSts.next((this.states = []));
		this.filteredDts.next((this.distr = []));
		this.filteredC3O.next((this.C3Off = []));
		this.states = [];
		this.distr = [];
		this.C3Off = [];
	}

	resetForm() {
		this.resetdrop(event);
		if (this.madForm.valid) {
			this.madForm.reset();
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		}
	}

	ngOnInit() {
		this.displayMandals();
		this.ds.getCountriesData().subscribe((res) => {
			//console.log(res);
			this.getMandalsData = res;
		});
		// listen for search field value changes
		this.CounFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterCountries();
		});

		this.StsFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterStates();
		});
		this.DtsFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterDists();
		});
		this.C3OFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterC3O();
		});

		// this.hidingAction();


	}


	protected filterCountries() {
		//console.log('ssaz', this.getMandalsData);
		if (!this.getMandalsData) {
			return;
		}
		// get the search keyword
		let search = this.CounFilterCtrl.value;
		if (!search) {
			this.filteredCoun.next(this.getMandalsData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredCoun.next(
			this.getMandalsData.filter((bank) => bank.CountryName.toLowerCase().indexOf(search) > -1)
		);
	}

	// checkCountryExist() {
	//   //console.log(this.madForm.get('TblCountry_CountryID').value);
	//   if (this.madForm.get('TblCountry_CountryID').value === null) {
	//     this.madForm.controls.TblState_StateID.disable();
	//     this.filteredSts.next(this.states = []);
	//     alert('First Select Country');
	//   }
	// }

	protected filterStates() {
		//console.log('ssaz', this.states);
		if (!this.getMandalsData) {
			return;
		}
		// get the search keyword
		let search = this.StsFilterCtrl.value;
		if (!search) {
			this.filteredSts.next(this.states.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredSts.next(this.states.filter((bank) => bank.StateName.toLowerCase().indexOf(search) > -1));
	}

	protected filterDists() {
		//console.log('ssaz', this.distr);
		if (!this.states) {
			return;
		}
		// get the search keyword
		let search = this.DtsFilterCtrl.value;
		if (!search) {
			this.filteredDts.next(this.distr.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredDts.next(this.distr.filter((bank) => bank.DistrictName.toLowerCase().indexOf(search) > -1));
	}

	protected filterC3O() {
		//console.log('ssaz', this.C3Off);
		if (!this.C3Off) {
			return;
		}
		// get the search keyword
		let search = this.C3OFilterCtrl.value;
		if (!search) {
			this.filteredC3O.next(this.C3Off.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredC3O.next(this.C3Off.filter((bank) => bank.Name.toLowerCase().indexOf(search) > -1));
	}

	displayMandals() {
		this.ds.getMandalsData().subscribe((list) => {
			this.isLoading = false;
			this.userMandalsData = list;
			//console.log(this.userMandalsData);
			if (list.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			this.listData = new MatTableDataSource(this.userMandalsData);
			this.listData.filterPredicate = (data: Mandals, filter: string) =>
				data.MandalName.toLowerCase().indexOf(filter) !== -1;
			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	toggleEditMandals() {
		this.filteredCoun.next(this.getMandalsData.slice());
		this.displayMandals();
		this.resetdrop(event);
		this.madForm.reset();
		this.MandalsNames = this.MandalsNames === 'Add Mandals' ? 'Mandals List' : 'Add Mandals';
		this.editMandalsContent = this.editMandalsContent === 'cancel' ? 'add_circle' : 'cancel';
		this.editMandals = !this.editMandals;
		this.displayddl = this.editMandals ? 'inline' : 'none';
	}

	toggleUpdateMandals(getMandalsDataObj) {
		this.editall = getMandalsDataObj;
		//console.log(this.editall)
		this.updateMandals = !this.updateMandals;
		this.displayddl = !this.editMandals ? 'inline' : 'none';
		this.ds.getStatesDataByCountry(this.editall.TblCountry_CountryID).subscribe(res => {
			this.states = res;
			for (let data of this.getMandalsData) {
				if (data.ID === this.editall.TblCountry_CountryID) {
					this.editall.TblCountry_CountryID = data.CountryName;
				}
			}
			for (let datar of this.states) {
				if (datar.ID === this.editall.TblState_StateID) {
					this.editall.TblState_StateID = datar.StateName;
				}
			}
		})
		this.ds.getDistrictDataByDist(this.editall.TblState_StateID).subscribe(res => {
			this.distr = res;
			for (let datas of this.distr) {
				if (datas.ID === this.editall.TblDistrict_DistrictID) {
					this.editall.TblDistrict_DistrictID = datas.DistrictName;
				}
			}
		})
		this.ds.getC3officeDataBydist(this.editall.TblDistrict_DistrictID).subscribe(res => {
			this.C3Off = res;
			for (let dataf of this.C3Off) {
				if (dataf.ID === this.editall.TblC3Office_C3OfficeID) {
					this.editall.TblC3Office_C3OfficeID = dataf.Name;
					//console.log(this.editall.TblC3Office_C3OfficeID)
				}
			}
		});


		this.madForm.setValue({
			MandalName: this.editall.MandalName,
			TblDistrict_DistrictID: this.editall.TblDistrict_DistrictID,
			TblCountry_CountryID: this.editall.TblCountry_CountryID,
			TblState_StateID: this.editall.TblState_StateID,
			TblC3Office_C3OfficeID: this.editall.TblC3Office_C3OfficeID
		});
	}

	toggleUpdateMandals2() {
		this.updateMandals = false;
		this.displayddl = this.editMandals ? 'inline' : 'block';
	}

	onChangestates(ID: string) {
		if (ID) {
			this.states = [];
			this.distr = [];
			this.C3Off = [];
			this.ds.getStatesDataByCountry(ID).subscribe((res) => {
				if (res['data'] === 'No Data Available with this ID') {
					Swal.fire({
						position: 'center',
						type: 'info',
						title: 'No States Available',
						showConfirmButton: false,
						timer: 1500
					});
					this.madForm.controls.TblState_StateID.patchValue('');
					this.filteredSts.next(this.states.slice());
					this.madForm.controls.TblDistrict_DistrictID.patchValue('');
					this.filteredDts.next(this.distr.slice());
					this.madForm.controls.TblC3Office_C3OfficeID.patchValue('');
					this.filteredC3O.next(this.C3Off.slice());
				} else {
					this.madForm.controls.TblState_StateID.patchValue('');
					this.states = res;
					this.filteredSts.next(this.states.slice());

				}
			});
		}
	}

	onChangedist(ID: string) {
		if (ID) {
			this.distr = [];
			this.C3Off = [];
			this.ds.getDistrictDataByDist(ID).subscribe((res) => {
				if (res['data'] === 'No Data Available with this ID') {
					Swal.fire({
						position: 'center',
						type: 'info',
						title: 'No Districts Available',
						showConfirmButton: false,
						timer: 1500
					});
					this.madForm.controls.TblDistrict_DistrictID.patchValue('');
					this.filteredDts.next(this.distr.slice());
					this.madForm.controls.TblC3Office_C3OfficeID.patchValue('');
					this.filteredC3O.next(this.C3Off.slice());
				} else {

					this.madForm.controls.TblDistrict_DistrictID.patchValue('');
					this.distr = res;
					this.filteredDts.next(this.distr.slice());
				}
			});
		}
	}

	onChangeC3O(ID: string) {
		if (ID) {
			this.C3Off = [];
			this.ds.getC3officeDataBydist(ID).subscribe((res) => {
				if (res['data'] === 'No c3Office Available With This ID') {
					Swal.fire({
						position: 'center',
						type: 'info',
						title: 'No C3Office Available',
						showConfirmButton: false,
						timer: 1500
					});
					this.madForm.controls.TblC3Office_C3OfficeID.patchValue('');
					this.filteredC3O.next(this.C3Off.slice());
				} else {
					this.madForm.controls.TblC3Office_C3OfficeID.patchValue('');
					this.C3Off = res;
					this.filteredC3O.next(this.C3Off.slice());

				}
			});
		}
	}

	createMandals() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.madForm.valid) {
			Object.keys(this.madForm.controls).forEach((field) => {
				const control = this.madForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Mandatory Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.ds.saveMandalsData(this.madForm.value).subscribe(
				(res) => {
					//console.log(res);
					if (res['data'] === 'Successfully Posted') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Successfully Added',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayMandals();
						this.toggleEditMandals();
					} else if ((res['data'] = 'serverErrorMandalExistence')) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The MandalsName',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					}
				},
				(err) => console.error(err)
			);
		}
	}

	deleteMandals(id: string) {
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ds.deleteMandalsDataById(id).subscribe((res) => {
					if ((res['data'] = 'Successfully Deleted')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayMandals();
					}
				});
			}
		});
	}

	updatemand(data) {
		//console.log(data);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		this.editall = data;
		if (!this.madForm.valid) {
			Object.keys(this.madForm.controls).forEach((field) => {
				const control = this.madForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Mandatory Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.ds.updateMandalsDataById(this.editall.ID, this.madForm.value).subscribe(
				(res) => {
					// tslint:disable-next-line:max-line-length
					if (
						this.editall.MandalName === this.madForm.controls.MandalName.value &&
						this.editall.TblDistrict_DistrictID === this.madForm.controls.TblDistrict_DistrictID.value &&
						this.editall.TblCountry_CountryID === this.madForm.controls.TblCountry_CountryID.value &&
						this.editall.TblState_StateID === this.madForm.controls.TblState_StateID.value
					) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['data'] === 'Successfully Updated') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Edited',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayMandals();
						this.toggleUpdateMandals2();
					}
				},
				(err) => console.log(err)
			);
		}
	}
}
