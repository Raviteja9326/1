export interface Villages {
    ID?: number;
    VillageName?: string;
    TblMandal_MandalID?: number;
    TblCountry_CountryID?: number;
    TblState_StateID?: number;
    TblDist_DistID?: number;
    TblC3OfficeID?: number;
}
