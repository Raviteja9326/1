import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from 'app/services/masters.service';
import { Villages } from './villages';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil } from 'rxjs/operators';
import { States } from '../states/states';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Country } from '../country/country';
import { Revenue } from '../revenue/revenue';
import { Mandals } from '../mandals/mandals';
import { Districts } from '../districts/districts';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
@Component({
  selector: 'app-villages',
  templateUrl: './villages.component.html',
  styleUrls: ['./villages.component.scss']
})
export class VillagesComponent implements OnInit, OnDestroy {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'VillageName', 'Actions'];
  editVillages = true;
  editVillagesContent = "add_circle";
  VillagesNames = "Villages List";
  userVillagesData: any = [];
  EditvillagesData: any = [];
  updatevillages = false;
  displayddl: string;
  getvillageData: Country[] = [];
  states: States[] = [];
  revenuedist: Districts[] = [];
  mandals: Mandals[] = [];
  editvill: any = [];
  EditOldvill: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;
  isMobile: any;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CounFilterCtrl: FormControl = new FormControl();
  public StsFilterCtrl: FormControl = new FormControl();
  public DtsFilterCtrl: FormControl = new FormControl();
  public MandFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  public filteredSts: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
  public filteredDts: ReplaySubject<Districts[]> = new ReplaySubject<Districts[]>(1);
  public filteredMand: ReplaySubject<Mandals[]> = new ReplaySubject<Mandals[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  villageForm = this.formBuilder.group({
    // tslint:disable-next-line:max-line-length
    VillageName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(30), Validators.pattern('^[a-zA-Z\\s]+$')]],
    TblMandal_MandalID: ['', [Validators.required]],
    TblCountry_CountryID: ['', [Validators.required]],
    TblDist_DistID: ['', [Validators.required]],
    TblState_StateID: ['', [Validators.required]],
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }



  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }


  resetdrop(event) {
    this.filteredSts.next(this.states = []);
    this.filteredDts.next(this.revenuedist = []);
    this.filteredMand.next(this.mandals = []);
    this.states = [];
    this.revenuedist = [];
    this.mandals = []
  }

  resetForm() {
    this.resetdrop(event);
    if (this.villageForm.valid) {
      this.villageForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }


  ngOnInit() {
    this.displayVillages();
    this.ds.getCountriesData().subscribe(res => {

      this.getvillageData = res;
    })

  }

  displayVillages() {
    this.ds.getVillagesData().subscribe(list => {
      this.isLoading = false;
      this.userVillagesData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userVillagesData);
      this.listData.filterPredicate = (data: Villages, filter: string) => data.VillageName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    })
  }

  toggleEditVillages() {
    this.displayVillages();
    this.resetdrop(event);
    this.villageForm.reset();
    this.VillagesNames =
      this.VillagesNames === "Add Villages" ? "Villages List" : "Add Villages";
    this.editVillagesContent =
      this.editVillagesContent === "cancel" ? "add_circle" : "cancel";
    this.editVillages = !this.editVillages;
    this.displayddl = this.editVillages ? "inline" : "none";
  }

  toggleUpdateVillage(getVillagesDataObj) {
    this.editvill = getVillagesDataObj;
    this.updatevillages = !this.updatevillages;
    this.displayddl = !this.editVillages ? "inline" : "none";
    this.ds.getStatesDataByCountry(this.editvill.TblCountry_CountryID).subscribe(res => {
      this.states = res;
    })
    this.ds.getDistrictDataByDist(this.editvill.TblState_StateID).subscribe(res => {
      this.revenuedist = res;
    })
    this.ds.getMandalsDataBydist(this.editvill.TblDist_DistID).subscribe(res => {
      this.mandals = res;
    })
    this.villageForm.setValue({
      VillageName: this.editvill.VillageName,
      TblMandal_MandalID: this.editvill.TblMandal_MandalID,
      TblCountry_CountryID: this.editvill.TblCountry_CountryID,
      TblState_StateID: this.editvill.TblState_StateID,
      TblDist_DistID: this.editvill.TblDist_DistID
    });
  }

  toggleUpdatevillages2() {
    this.updatevillages = false;
    this.displayddl = this.updatevillages ? "inline" : "block";
  }


  onChangeCountry(ID: string) {
    if (ID) {
      this.ds.getStatesDataByCountry(ID).subscribe(res => {
        if (res['data'] === "NO States Available with this Country ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No States Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.states = [];
          this.revenuedist = [];
          this.mandals = [];
          this.villageForm.controls.TblState_StateID.patchValue('');
          this.villageForm.controls.TblDist_DistID.patchValue('');
          this.villageForm.controls.TblMandal_MandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The States',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageForm.controls.TblState_StateID.patchValue('');
          this.states = res;
          this.filteredSts.next(this.states.slice());
          this.revenuedist = [];
        }
      })
    }
  }

  onChangedist(ID: string) {
    if (ID) {
      this.ds.getDistrictDataByDist(ID).subscribe(res => {
        if (res['data'] === "No Districts Available With This ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Districts Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.revenuedist = [];
          this.mandals = [];
          this.villageForm.controls.TblDist_DistID.patchValue('');
          this.villageForm.controls.TblMandal_MandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Districts',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageForm.controls.TblDist_DistID.patchValue('');
          this.revenuedist = res;
          this.mandals = [];
          this.filteredDts.next(this.revenuedist.slice());
        }
      })
    }
  }

  onChangeMandals(ID: string) {
    if (ID) {
      this.ds.getMandalsDataBydist(ID).subscribe(res => {
        if (res['data'] === "No Mandals Available With This ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Mandals Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.mandals = [];
          this.villageForm.controls.TblMandal_MandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Mandals',
            showConfirmButton: false,
            timer: 1000
          })
          this.villageForm.controls.TblMandal_MandalID.patchValue('');
          this.mandals = res;
          this.filteredMand.next(this.mandals.slice());
        }
      })
    }
  }

  Createvillages() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.villageForm.valid) {
      Object.keys(this.villageForm.controls).forEach(field => {
        const control = this.villageForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.saveVillagesData(this.villageForm.value).subscribe(
        res => {
          if (res['data'] === "Successfully Added") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully Added The Villages',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.displayVillages();
            this.toggleEditVillages();
          } else if (res['data'] = "serverErrorVillageExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists With Village Name',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }

  }

  Updatevillages(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.editvill = data;
    if (!this.villageForm.valid) {
      Object.keys(this.villageForm.controls).forEach(field => {
        const control = this.villageForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updateVillagesDataById(this.editvill.ID, this.villageForm.value).subscribe(res => {
        if (this.editvill.VillageName === this.villageForm.controls.VillageName.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayVillages();
          this.toggleUpdatevillages2();
        }

      },

      )
    }


  }

  deletevillages(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deleteVillagesDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayVillages();
            }
          }

        )

      }
    })
  }



}
