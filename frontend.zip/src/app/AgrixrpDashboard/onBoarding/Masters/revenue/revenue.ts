export interface Revenue {
    ID?: number;
    RevenueDivisionName?: string;
    TblMandal_MandalID?: number;
    TblMandal_TblDistrict_DistrictID?: number;
    TblCountry_ID?: number;
    TblState_ID?: number;
}
