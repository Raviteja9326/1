import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MastersService } from 'app/services/masters.service';
import { Revenue } from './revenue';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil } from 'rxjs/operators';
import { States } from '../states/states';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Mandals } from '../mandals/mandals';
import { Country } from '../country/country';
import { Districts } from '../districts/districts';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.component.html',
  styleUrls: ['./revenue.component.scss']
})
export class RevenueComponent implements OnInit, OnDestroy {

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['S.No', 'RevenueDivisionName', 'Actions'];
  editRevenue = true;
  editRevenueContent = "add_circle";
  RevenueNames = "Revenue List";
  userRevenueData: any = [];
  EditrevenueData: any = [];
  updaterevenue = false;
  displayddl: string;
  revenuedist: Districts[] = [];
  mandals: Mandals[] = [];
  getrevData: Country[] = [];
  states: States[] = [];
  editrev: any = [];
  EditOldRev: any = []
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;
  isMobile: any;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public CounFilterCtrl: FormControl = new FormControl();
  public StsFilterCtrl: FormControl = new FormControl();
  public DtsFilterCtrl: FormControl = new FormControl();
  public MandFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  public filteredSts: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
  public filteredDts: ReplaySubject<Districts[]> = new ReplaySubject<Districts[]>(1);
  public filteredMand: ReplaySubject<Mandals[]> = new ReplaySubject<Mandals[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();


  RevForm = this.formBuilder.group({
    // tslint:disable-next-line:max-line-length
    RevenueDivisionName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(30), Validators.pattern('^[a-zA-Z\\s]+$')]],
    TblState_ID: ['', [Validators.required]],
    TblMandal_MandalID: ['', [Validators.required]],
    TblMandal_TblDistrict_DistrictID: ['', [Validators.required]],
    TblCountry_ID: ['', [Validators.required]],
  })

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }
  constructor(private http: HttpClient, private ds: MastersService, private formBuilder: FormBuilder) { }


  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }



  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }


  resetdrop(event) {
    this.filteredSts.next(this.states = []);
    this.filteredDts.next(this.revenuedist = []);
    this.filteredMand.next(this.mandals = []);
    this.states = [];
    this.revenuedist = [];
    this.mandals = []
  }

  resetForm() {
    this.resetdrop(event);
    if (this.RevForm.valid) {
      this.RevForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    }
  }


  ngOnInit() {

    this.displayRevenue();
    this.ds.getCountriesData().subscribe(res => {

      this.getrevData = res;
    });

    // listen for search field value changes
    this.CounFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCountries();
      });

    this.StsFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterStates();
      });

    this.DtsFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDists();
      });

    this.MandFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterMand();
      });

  }

  protected filterCountries() {
    if (!this.getrevData) {
      return;
    }
    // get the search keyword
    let search = this.CounFilterCtrl.value;
    if (!search) {
      this.filteredCoun.next(this.getrevData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCoun.next(
      this.getrevData.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  protected filterStates() {
    if (!this.getrevData) {
      return;
    }
    // get the search keyword
    let search = this.StsFilterCtrl.value;
    if (!search) {
      this.filteredSts.next(this.states.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredSts.next(
      this.states.filter(bank => bank.StateName.toLowerCase().indexOf(search) > -1)
    );
  }

  protected filterDists() {
    if (!this.states) {
      return;
    }
    // get the search keyword
    let search = this.DtsFilterCtrl.value;
    if (!search) {
      this.filteredDts.next(this.revenuedist.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredDts.next(
      this.revenuedist.filter(bank => bank.DistrictName.toLowerCase().indexOf(search) > -1)
    );
  }

  protected filterMand() {
    if (!this.revenuedist) {
      return;
    }
    // get the search keyword
    let search = this.MandFilterCtrl.value;
    if (!search) {
      this.filteredMand.next(this.mandals.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredMand.next(
      this.mandals.filter(bank => bank.MandalName.toLowerCase().indexOf(search) > -1)
    );
  }


  displayRevenue() {
    this.ds.getRevenueData().subscribe(list => {
      this.isLoading = false;
      this.userRevenueData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userRevenueData);
      this.listData.filterPredicate = (data: Revenue, filter: string) => data.RevenueDivisionName.toLowerCase().indexOf(filter) !== -1;

      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    }
    )
  }

  toggleEditRevenue() {
    this.filteredCoun.next(this.getrevData.slice());
    this.displayRevenue();
    this.resetdrop(event);
    this.RevForm.reset();
    this.RevenueNames =
      this.RevenueNames === "Add Revenue" ? "Revenue List" : "Add Revenue";
    this.editRevenueContent =
      this.editRevenueContent === "cancel" ? "add_circle" : "cancel";
    this.editRevenue = !this.editRevenue;
    this.displayddl = this.editRevenue ? "inline" : "none";
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }


  toggleUpdaterevenue(getRevenueDataObj) {
    this.editrev = getRevenueDataObj;
    this.updaterevenue = !this.updaterevenue;
    this.displayddl = !this.updaterevenue ? "inline" : "none";
    this.ds.getStatesDataByCountry(this.editrev.TblCountry_ID).subscribe(res => {
      this.states = res;
    })
    this.ds.getDistrictDataByDist(this.editrev.TblState_ID).subscribe(res => {
      this.revenuedist = res;
    })
    this.ds.getMandalsDataBydist(this.editrev.TblMandal_TblDistrict_DistrictID).subscribe(res => {
      this.mandals = res;
    })
    this.RevForm.setValue({
      RevenueDivisionName: this.editrev.RevenueDivisionName,
      TblMandal_MandalID: this.editrev.TblMandal_MandalID,
      TblMandal_TblDistrict_DistrictID: this.editrev.TblMandal_TblDistrict_DistrictID,
      TblCountry_ID: this.editrev.TblCountry_ID,
      TblState_ID: this.editrev.TblState_ID
    });
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
  }

  toggleUpdaterevenue2() {
    this.updaterevenue = false;
    this.displayddl = this.updaterevenue ? "inline" : "block";
  }

  onChangeCountry(ID: string) {
    if (ID) {
      this.ds.getStatesDataByCountry(ID).subscribe(res => {
        if (res['data'] === "NO States Available with this Country ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No States Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.states = [];
          this.revenuedist = [];
          this.mandals = [];
          this.RevForm.controls.TblState_ID.patchValue('');
          this.RevForm.controls.TblMandal_TblDistrict_DistrictID.patchValue('');
          this.RevForm.controls.TblMandal_MandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The States',
            showConfirmButton: false,
            timer: 1000
          })
          this.RevForm.controls.TblState_ID.patchValue('');
          this.states = res;
          this.filteredSts.next(this.states.slice());
          this.revenuedist = [];
        }
      })
    }
  }

  onChangedist(ID: string) {
    if (ID) {
      this.ds.getDistrictDataByDist(ID).subscribe(res => {
        if (res['data'] === "No Districts Available With This ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Districts Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.revenuedist = [];
          this.mandals = [];
          this.RevForm.controls.TblMandal_TblDistrict_DistrictID.patchValue('');
          this.RevForm.controls.TblMandal_MandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Districts',
            showConfirmButton: false,
            timer: 1000
          })
          this.RevForm.controls.TblMandal_TblDistrict_DistrictID.patchValue('');
          this.revenuedist = res;
          this.mandals = [];
          this.filteredDts.next(this.revenuedist.slice());
        }
      })
    }
  }

  onChangeMandals(ID: string) {
    if (ID) {
      this.ds.getMandalsDataBydist(ID).subscribe(res => {
        if (res['data'] === "No Mandals Available With This ID") {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No Mandals Available',
            showConfirmButton: false,
            timer: 1500
          })
          this.mandals = [];
          this.RevForm.controls.TblMandal_MandalID.patchValue('');
        } else {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'Please Select The Mandals',
            showConfirmButton: false,
            timer: 1000
          })
          this.RevForm.controls.TblMandal_MandalID.patchValue('');
          this.mandals = res;
          this.filteredMand.next(this.mandals.slice());
        }
      })
    }
  }

  createrevenue(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    if (!this.RevForm.valid) {
      Object.keys(this.RevForm.controls).forEach(field => {
        const control = this.RevForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.saverevenueData(this.RevForm.value).subscribe(
        res => {
          if (res['data'] === "Successfully Posted") {
            Swal.fire({
              position: 'center',
              type: 'success',
              title: 'Sucessfully Added The RevenueDivision',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.displayRevenue();
            this.toggleEditRevenue();
          } else if (res['data'] = "serverErrorRDExistence") {
            Swal.fire({
              position: 'center',
              type: 'info',
              title: 'Already Exists The RevenueDivision Name',
              showConfirmButton: false,
              timer: 1500
            })
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      )
    }
  }


  deleterevenue(id: string) {


    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then((result) => {
      if (result.value) {

        this.ds.deleterevenueDataById(id).subscribe(
          res => {
            if (res['data'] = "Successfully Deleted") {
              Swal.fire({
                title: 'Deleted!',
                text: 'Your Record has been deleted.',
                type: 'success',
                confirmButtonClass: 'btn btn-success'
              })
              this.displayRevenue();
            }
          }

        )

      }
    })
  }

  updaterev(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Saving Data...';
    this.editrev = data;
    if (!this.RevForm.valid) {
      Object.keys(this.RevForm.controls).forEach(field => {
        const control = this.RevForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Fill The Mandatory Fields',
        showConfirmButton: false,
        timer: 1500
      })
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.ds.updaterevenueDataById(this.editrev.ID, this.RevForm.value).subscribe(res => {
        // tslint:disable-next-line:max-line-length
        if (this.editrev.RevenueDivisionName === this.RevForm.controls.RevenueDivisionName.value && this.editrev.TblMandal_MandalID === this.RevForm.controls.TblMandal_MandalID.value && this.editrev.TblMandal_TblDistrict_DistrictID === this.RevForm.controls.TblMandal_TblDistrict_DistrictID.value && this.editrev.TblCountry_ID === this.RevForm.controls.TblCountry_ID.value && this.editrev.TblState_ID === this.RevForm.controls.TblState_ID.value) {
          Swal.fire({
            position: 'center',
            type: 'info',
            title: 'No update Found',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
        } else if (res['data'] === "Successfully Updated") {
          Swal.fire({
            position: 'center',
            type: 'success',
            title: 'Sucessfully Edited',
            showConfirmButton: false,
            timer: 1500
          })
          this.barButtonOptions.active = false;
          this.barButtonOptions.text = 'SUBMIT';
          this.displayRevenue();
          this.toggleUpdaterevenue2();
        }

      },

      )
    }
  }





}
