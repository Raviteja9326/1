import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MastersComponent } from './masters.component';
import { CountryComponent } from './country/country.component';
import { CurrencyComponent } from './currency/currency.component';
import { DistrictsComponent } from './districts/districts.component';
import { MandalsComponent } from './mandals/mandals.component';
import { RevenueComponent } from './revenue/revenue.component';
import { StatesComponent } from './states/states.component';
import { VillagesComponent } from './villages/villages.component';
import { VillagesarpanchComponent } from './villagesarpanch/villagesarpanch.component';
import { C3officeComponent } from './c3office/c3office.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';

const routes: Routes = [{
    path: '',
    component: MastersComponent,
    children: [{
        path: 'Country',
        component: CountryComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Currency',
        component: CurrencyComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Districts',
        component: DistrictsComponent, canActivate: [AuthGuardService]
    }, {
        path: 'C3Office',
        component: C3officeComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Mandal',
        component: MandalsComponent, canActivate: [AuthGuardService]
    }, {
        path: 'RevenueDivision',
        component: RevenueComponent, canActivate: [AuthGuardService]
    }, {
        path: 'States',
        component: StatesComponent, canActivate: [AuthGuardService]
    }, {
        path: 'Village',
        component: VillagesComponent, canActivate: [AuthGuardService]
    }, {
        path: 'VillageSarpanch',
        component: VillagesarpanchComponent, canActivate: [AuthGuardService]
    }],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class MastersRoutingModule { }
