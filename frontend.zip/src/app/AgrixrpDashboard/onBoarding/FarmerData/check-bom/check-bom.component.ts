import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-bom',
  templateUrl: './check-bom.component.html',
  styleUrls: ['./check-bom.component.scss']
})
export class CheckBomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
