import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { Validators, FormBuilder } from "@angular/forms";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";
import { DatePipe } from "@angular/common";
import Swal from "sweetalert2";
import { Croplanes } from "./croplanes";

@Component({
  selector: "app-croplanes",
  templateUrl: "./croplanes.component.html",
  styleUrls: ["./croplanes.component.scss"]
})
export class CroplanesComponent implements OnInit {
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "TblPloting_TblLand_ID",
    "TblPloting_ID",
    "Name",
    "Area",
    "NoOfLines",
    "Spacing",
    "Utilization",
    "Actions"
  ];
  editCropCycle = true;
  editCropCycleContent = "add_circle";
  CropCycleNames = "CropLanes List";
  displayddl: string;
  updateCropCycle = false;
  viewCropCycle = false;
  userCropCycledata: any[];
  Editcoun: any = [];
  EditCropCycleData: any = [];
  EditOldData: any = [];
  usercropmasterdata: any[];
  usercroplanedata: any[];
  userplotdata: any[];
  usercropdata: any[];
  userlanddata: any[];
  usercopdata: any[];
  plotByLand: any[];
  cropByplot: any[];
  Editcoc: any = [];
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;

  CropCycleForm = this.formBuilder.group({
    TblPloting_TblLand_ID: ["", [Validators.required]],
    TblPloting_ID: ["", [Validators.required]],
    Name: ["", [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
    Area: [""],
    NoOfLines: [""],
    Spacing: [""],
    Utilization: [""]
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  Editfarm: any;
  FarmerForm: any;
  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder,
    private dp: DatePipe
  ) { }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }
  resetForm() {
    if (this.CropCycleForm.valid) {
      this.CropCycleForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    this.displaycropcycle();

    this.ls.getlandlayoutData().subscribe(cdata => {
      this.userlanddata = cdata;
    });
  }

  resetdrop(event) {
    this.plotByLand = [];
  }

  onChangeLand(ID: string) {
    if (ID) {
      this.ls.getplottingDataByLand(ID).subscribe(res => {
        if (res["data"] === "NO plotting Available with this Land ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "NO plotting Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.plotByLand = [];
          this.resetdrop(event);
          this.CropCycleForm.controls.TblPloting_ID.patchValue("");
        } else {
          Swal.fire({
            position: "center",
            type: "info",
            title: "Please Select The plotting",
            showConfirmButton: false,
            timer: 1000
          });
          this.CropCycleForm.controls.TblPloting_ID.patchValue("");
          this.plotByLand = res;
        }
      });
    }
  }

  displaycropcycle() {
    this.ls.getcroplaneData().subscribe(
      list => {
        this.isLoading = false;
        this.userCropCycledata = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userCropCycledata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Croplanes, filter: any) =>
          data.Name.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  CreateCropCycle() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The MandetoryFields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ls.savecroplaneData(this.CropCycleForm.value).subscribe(
        cropdata => {
          if (cropdata["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the CropLane",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.CropCycleForm.reset();
            this.displaycropcycle();
            this.toggleEditCropCycle();
          }
        },
        err => console.error(err)
      );
    }
  }

  UpdateCropCycle(cropdata) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.Editcoc = cropdata;
    if (!this.CropCycleForm.valid) {
      Object.keys(this.CropCycleForm.controls).forEach(field => {
        const control = this.CropCycleForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ls
        .updatecroplaneDataById(this.Editcoc.ID, this.CropCycleForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displaycropcycle();
              this.toggleUpdateCropCycle2();
            }
          },

        );
    }
  }
  deleteCropCycle(id: any) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deletecroplaneDataById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displaycropcycle();
          }
        });
      }
    });
  }

  toggleEditCropCycle() {
    this.resetdrop(event);
    this.displaycropcycle();
    this.CropCycleForm.reset();
    this.CropCycleNames =
      this.CropCycleNames === "Add CropLane" ? "CropLane List" : "Add CropLane";
    this.editCropCycle = !this.editCropCycle;
    this.editCropCycleContent =
      this.editCropCycleContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editCropCycle ? "inline" : "none";
  }

  toggleUpdateCropCycle(getCropCycleDataObj) {
    // ////console.log(getFarmersDataObj)
    this.Editcoc = getCropCycleDataObj;
    this.updateCropCycle = !this.updateCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
    this.ls
      .getplottingDataByLand(this.Editcoc.TblPloting_TblLand_ID)
      .subscribe(res => {
        this.plotByLand = res;
      });
    this.CropCycleForm.setValue({
      TblPloting_TblLand_ID: this.Editcoc.TblPloting_TblLand_ID,
      TblPloting_ID: this.Editcoc.TblPloting_ID,
      Name: this.Editcoc.Name,
      Area: this.Editcoc.Area,
      NoOfLines: this.Editcoc.NoOfLines,
      Spacing: this.Editcoc.Spacing,
      Utilization: this.Editcoc.Utilization
    });
  }

  toggleUpdateCropCycle2() {
    this.updateCropCycle = false;
    this.displayddl = this.editCropCycle ? "inline" : "block";
  }

  toggleViewCropCycle(getCropCycleDataObj) {
    this.Editcoun = getCropCycleDataObj;
    this.viewCropCycle = !this.viewCropCycle;
    this.displayddl = !this.editCropCycle ? "inline" : "none";
  }

  toggleViewCropCycle2() {
    this.viewCropCycle = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }
}
