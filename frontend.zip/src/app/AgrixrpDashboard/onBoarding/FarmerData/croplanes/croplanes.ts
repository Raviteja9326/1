export interface Croplanes {
    ID?: number;
    Name?: string;
    Area?: any;
    NoOfLines?: any;
    Spacing?: any;
    Utilization?: any;
    TblPloting_ID?: number;
    TblPloting_TblLand_ID?: number;
}
