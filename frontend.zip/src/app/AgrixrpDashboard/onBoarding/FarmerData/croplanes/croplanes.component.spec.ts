import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CroplanesComponent } from './croplanes.component';

describe('CroplanesComponent', () => {
  let component: CroplanesComponent;
  let fixture: ComponentFixture<CroplanesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CroplanesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CroplanesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
