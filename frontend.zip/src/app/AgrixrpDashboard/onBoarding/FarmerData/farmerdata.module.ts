import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FarmerdataRoutingModule } from "./farmerdata-routing.module";
import { FarmerDataComponent } from "./farmerdata.component";
import { HttpClientModule } from "@angular/common/http";
import { NgxMatSelectSearchModule } from "../../maincomponents/mat-select-search/ngx-mat-select-search.module";
import { MatTableExporterModule } from "mat-table-exporter";
import { LabourinformationComponent } from "./labourinformation/labourinformation.component";
import { RxReactiveFormsModule } from "@rxweb/reactive-form-validators";
import { SharedModule } from 'app/AgrixrpDashboard/maincomponents/shared.module';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { CroplanesComponent } from './croplanes/croplanes.component';
import { LandlayoutComponent } from './landlayout/landlayout.component';
import { LoanEMIComponent } from './loan-emi/loan-emi.component';
import { LoanhistoryComponent } from './loanhistory/loanhistory.component';
import { PlottingComponent } from './plotting/plotting.component';
import { IrrigationComponent } from './irrigation/irrigation.component';
import { CopworkflowComponent } from './copworkflow/copworkflow.component';
import { CheckcopworkflowComponent } from './checkcopworkflow/checkcopworkflow.component';
import { CheckBomComponent } from './check-bom/check-bom.component';
import { InsuranceComponent } from './insurance/insurance.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { FarmercheckComponent } from './farmerchecklist/farmerchecklist.component';
import { FarmerinfoComponent } from './farmerinfo/farmerinfo.component';
// tslint:disable-next-line:max-line-length
const components = [
  FarmerDataComponent,
  FarmercheckComponent,
  FarmerinfoComponent,
  LabourinformationComponent, CroplanesComponent, LandlayoutComponent, LoanEMIComponent, LoanhistoryComponent, PlottingComponent, IrrigationComponent, CopworkflowComponent, CheckcopworkflowComponent, CheckBomComponent, InsuranceComponent
];

@NgModule({
  // tslint:disable-next-line:max-line-length
  imports: [
    MaterialFileInputModule,
    NgxSpinnerModule,
    SharedModule,
    FarmerdataRoutingModule,
    RxReactiveFormsModule,
    CommonModule,
    MatTableExporterModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MaterialModule,
    NgxMatSelectSearchModule
  ],
  declarations: [...components]
})
export class FarmerDataModule { }
