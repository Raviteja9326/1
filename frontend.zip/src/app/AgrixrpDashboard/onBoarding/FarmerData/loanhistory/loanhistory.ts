export interface Loan {
    ID: number;
    LoanNumber: any;
    LoanAmount?:any;
    LoanPurpose?: any;
    LoanDate?: any;
   LoanOfficer?: string;
   LoanBank?: string;
   LoanBankBranch?: string;
   LoanIntrest?: any;
   Status?: string;
   Tenure?: any;
   PaymentFrequency_ID?: string;
   OutstandingAmount?: any;
   TblFarmer_ID?: any;
   created_by:any;
   modified_by:any;
}
