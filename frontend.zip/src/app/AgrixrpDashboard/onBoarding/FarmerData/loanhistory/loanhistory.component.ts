import { Component, OnInit, ViewChild, Output } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import Swal from "sweetalert2";
import { Validators, FormBuilder, FormGroup } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { MastersService } from "app/services/masters.service";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import {
  RxwebValidators,
  NumericValueType
} from "@rxweb/reactive-form-validators";
import { Farmer } from '../farmerinfo/farmerinfo';
@Component({
  selector: "app-loanhistory",
  templateUrl: "./loanhistory.component.html",
  styleUrls: ["./loanhistory.component.scss"]
})
export class LoanhistoryComponent implements OnInit {
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "FarmerName",
    "LoanNumber",
    "LoanAmount",
    "LoanYear",
    "LoanPurpose",
    "LoanDate",
    "LoanOfficer",
    "LoanBank",
    "LoanBankBranch",
    "LoanIntrest",
    "Status",
    "Tenure",
    "PaymentFrequency_ID",
    "OutstandingAmount",
    "Actions"
  ];
  userfarmerdata: any = [];
  userpaymentdata: any = [];
  userLoandata: any = [];
  EditOldData: any = [];
  date: any;
  editLoan = true;
  editLoanContent = "add_circle";
  Loan = "Farmer's Loan List";
  Editloan: any;
  Editcoun: any = [];
  updateLoan = false;
  viewLoan = false;
  displayddl: string;
  isLoading = true;
  displayNoRecords = false;
  secretKey: string;
  EditFarmloan: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  Status = ["Paid", "Not Paid", "Pending"];
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  @Output() TwoDigitDecimaNumber: string;

  LoanForm: FormGroup;
  constructor(
    private http: HttpClient,
    private ls: MastersService,
    private formBuilder: FormBuilder,
    private dp: DatePipe
  ) { }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  ngOnInit() {
    this.LoanForm = this.formBuilder.group({
      LoanNumber: ["", [Validators.required]],
      LoanAmount: [
        "",
        RxwebValidators.numeric({
          acceptValue: NumericValueType.PositiveNumber,
          allowDecimal: false,
          isFormat: true
        })
      ],
      LoanPurpose: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
      LoanDate: [""],
      LoanOfficer: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
      LoanBank: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
      LoanBankBranch: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
      LoanIntrest: [""],
      Status: [""],
      Tenure: [""],
      PaymentFrequency_ID: [""],
      OutstandingAmount: [
        "",
        RxwebValidators.numeric({
          acceptValue: NumericValueType.PositiveNumber,
          allowDecimal: false,
          isFormat: true
        })
      ],
      TblFarmer_ID: ["", [Validators.required]],
      created_by: [""],
      modified_by: [""]
    });
    this.displayLoan();
    this.ls.getFarmerdata().subscribe(ref => {
      this.userfarmerdata = ref;
    });

    this.ls.getpaymenent().subscribe(ref => {
      this.userpaymentdata = ref;
    });
  }

  displayLoan() {
    this.ls.getLoan().subscribe(
      list => {
        this.isLoading = false;
        this.userLoandata = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userLoandata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Farmer, filter: string) =>
          data.FarmerName.toLowerCase().indexOf(filter) !== -1 ||
          data.SurName.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  resetForm() {
    if (this.LoanForm.valid) {
      this.LoanForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  CreateLoan() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.LoanForm.valid) {
      Object.keys(this.LoanForm.controls).forEach(field => {
        const control = this.LoanForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.LoanForm.controls.created_by.patchValue(0);
      this.LoanForm.value.LoanDate = this.dp.transform(
        this.LoanForm.value.LoanDate,
        "yyyy-MM-dd"
      );
      this.ls.saveLoandata(this.LoanForm.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Loan",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayLoan();
            this.toggleEditLoan();
          } else if ((res["data"] = "serverErrorloanExistence")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Loan Number Exists",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  UpdateLoans(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.EditFarmloan = data;
    if (!this.LoanForm.valid) {
      Object.keys(this.LoanForm.controls).forEach(field => {
        const control = this.LoanForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.LoanForm.value.LoanDate = this.dp.transform(
        this.LoanForm.value.LoanDate,
        "yyyy-MM-dd"
      );
      this.ls
        .updateLoanByID(this.EditFarmloan.ID, this.LoanForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.EditFarmloan.LoanNumber === this.LoanForm.controls.LoanNumber.value && this.EditFarmloan.LoanAmount === this.LoanForm.controls.LoanAmount.value && this.EditFarmloan.LoanYear === this.LoanForm.controls.LoanYear.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayLoan();
              this.toggleUpdateLoan2();
            }
          },

        );
    }
  }

  deleteLoan(id: any) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteLoanByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayLoan();
          }
        });
      }
    });
  }

  toggleEditLoan() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.displayLoan();
    this.LoanForm.reset();
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.Loan = this.Loan === "Add Loan" ? "Farmer's Loan List" : "Add Loan";
    this.editLoan = !this.editLoan;
    this.editLoanContent =
      this.editLoanContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editLoan ? "inline" : "none";
  }

  toggleUpdateLoan(getLoanDataObj) {
    this.EditFarmloan = getLoanDataObj;
    this.updateLoan = !this.updateLoan;
    this.displayddl = !this.editLoan ? "inline" : "none";
    this.EditFarmloan.LoanDate = this.dp.transform(
      this.EditFarmloan.LoanDate,
      "yyyy-MM-dd"
    );
    this.LoanForm.controls.modified_by.patchValue(1);
    this.LoanForm.setValue({
      LoanNumber: this.EditFarmloan.LoanNumber,
      LoanAmount: this.EditFarmloan.LoanAmount,
      LoanPurpose: this.EditFarmloan.LoanPurpose,
      LoanDate: this.EditFarmloan.LoanDate,
      LoanOfficer: this.EditFarmloan.LoanOfficer,
      LoanBank: this.EditFarmloan.LoanBank,
      LoanBankBranch: this.EditFarmloan.LoanBankBranch,
      LoanIntrest: this.EditFarmloan.LoanIntrest,
      Status: this.EditFarmloan.Status,
      created_by: this.EditFarmloan,
      modified_by: this.EditFarmloan.modified_by,
      Tenure: this.EditFarmloan.Tenure,
      PaymentFrequency_ID: this.EditFarmloan.PaymentFrequency_ID,
      OutstandingAmount: this.EditFarmloan.OutstandingAmount,
      TblFarmer_ID: this.EditFarmloan.TblFarmer_ID
    });
  }

  toggleUpdateLoan2() {
    this.updateLoan = false;
    this.displayddl = this.editLoan ? "inline" : "block";
  }

  toggleViewLoan(getLoanDataObj) {
    this.Editcoun = getLoanDataObj;
    this.Editcoun.LoanDate = this.dp.transform(
      this.Editcoun.LoanDate,
      "dd-MMMM-y"
    );
    this.viewLoan = !this.viewLoan;
    this.displayddl = !this.editLoan ? "inline" : "none";
  }
  toggleViewLoan2() {
    this.viewLoan = false;
    this.displayddl = this.editLoan ? "inline" : "block";
  }
}
