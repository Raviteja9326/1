import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copworkflow',
  templateUrl: './copworkflow.component.html',
  styleUrls: ['./copworkflow.component.scss']
})
export class CopworkflowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
