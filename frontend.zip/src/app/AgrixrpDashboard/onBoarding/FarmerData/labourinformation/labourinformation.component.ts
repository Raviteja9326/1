import { Component, OnInit, ViewChild } from "@angular/core";
import { Labour } from "./Labour";
import Swal from "sweetalert2";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatSelect
} from "@angular/material";
import { ReplaySubject, Subject } from "rxjs";
import { MastersService } from "app/services/masters.service";
import { MatProgressButtonOptions } from "mat-progress-buttons";

@Component({
  selector: "app-labourinformation",
  templateUrl: "./labourinformation.component.html",
  styleUrls: ["./labourinformation.component.scss"]
})
export class LabourinformationComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "FullName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  Labour = "Labour Data";
  Labourtype = "add_circle";
  editlabour = true;
  displayddl: string;
  ViewLabour = false;
  EditLabour: any = [];
  updateLabour = false;
  EditOldData: any = [];
  userLabourData: Labour[] = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  /** control for the MatSelect filter keyword */
  public CatFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredCat: ReplaySubject<Labour[]> = new ReplaySubject<Labour[]>(1);
  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();
  Farm = ["Yes", "No"];
  genders = ["Male", "Female", "Others"];
  status = ["Yes", "No"];

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  labourinformation = this.formBuilder.group({
    FullName: ["", [Validators.required, Validators.pattern("^[a-zA-Z\\s]+$")]],
    ResidingatFarm: [""],
    Relationship: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    MaritalStatus: [""],
    Age: [
      "",
      [
        Validators.required,
        Validators.maxLength(3),
        Validators.minLength(2),
        Validators.pattern("^[0-9]*$")
      ]
    ],
    Sex: [""],
    TypeofWork: [
      "",
      [Validators.required, Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    PaymentType: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    PaymentFrequency: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    Holidays: ["", [Validators.pattern("^[0-9]*$")]],
    Education: [""],
    DependentStatus: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    PercentageTimeonFarm: ["", [Validators.pattern("^[0-9]*$")]],
    MajorWork: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    MinorWork: ["", [Validators.pattern("^[a-zA-Z\\s]+$")]],
    created_by: [],
    modified_by: []
  });

  constructor(private ls: MastersService, private formBuilder: FormBuilder) { }

  AddLabour() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.dispalyLabourinformation();
    this.labourinformation.reset();
    this.Labour =
      this.Labour === "Labour Data" ? "Add Labour Data" : "Labour Data";
    this.editlabour = !this.editlabour;
    this.Labourtype = this.Labourtype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editlabour ? "inline" : "none";
  }

  ngOnInit() {
    this.dispalyLabourinformation();
  }
  dispalyLabourinformation() {
    this.ls.getLabourinfoData().subscribe(list => {
      this.isLoading = false;
      this.userLabourData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userLabourData);
      /* config filter */
      this.listData.filterPredicate = (data: Labour, filter: string) =>
        data.FullName.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.labourinformation.valid) {
      this.labourinformation.reset();
    }
  }

  CreateLabour(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.labourinformation.valid) {
      Object.keys(this.labourinformation.controls).forEach(field => {
        const control = this.labourinformation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.labourinformation.controls.created_by.patchValue(1);
      this.ls.saveLabourInformation(this.labourinformation.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Labour Information",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.dispalyLabourinformation();
            this.AddLabour();
          } else if ((res["data"] = "Labour information already exists!")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Labour Info",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleViewLabour(getLabourDataObj) {
    this.EditLabour = getLabourDataObj;
    this.ViewLabour = !this.ViewLabour;
    this.displayddl = !this.EditLabour ? "inline" : "none";
  }

  toggleViewLabourinformation() {
    this.ViewLabour = false;
    this.displayddl = this.EditLabour ? "inline" : "none";
  }

  toggleUpdateLabour(getLabourDataObj) {
    this.updateLabour = !this.updateLabour;
    this.EditLabour = getLabourDataObj;
    this.displayddl = !this.editlabour ? "inline" : "none";
    this.labourinformation.setValue({
      FullName: this.EditLabour.FullName,
      ResidingatFarm: this.EditLabour.ResidingatFarm,
      Relationship: this.EditLabour.Relationship,
      MaritalStatus: this.EditLabour.MaritalStatus,
      Age: this.EditLabour.Age,
      Sex: this.EditLabour.Sex,
      TypeofWork: this.EditLabour.TypeofWork,
      PaymentType: this.EditLabour.PaymentType,
      PaymentFrequency: this.EditLabour.PaymentFrequency,
      Holidays: this.EditLabour.Holidays,
      Education: this.EditLabour.Education,
      DependentStatus: this.EditLabour.DependentStatus,
      PercentageTimeonFarm: this.EditLabour.PercentageTimeonFarm,
      MajorWork: this.EditLabour.MajorWork,
      MinorWork: this.EditLabour.MinorWork,
      created_by: this.EditLabour.created_by,
      modified_by: this.EditLabour.modified_by
    });
  }

  togglecloseLabourUpdate() {
    this.updateLabour = false;
    this.displayddl = this.editlabour ? "inline" : "none";
  }

  updateLabourInformation(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.labourinformation.valid) {
      Object.keys(this.labourinformation.controls).forEach(field => {
        const control = this.labourinformation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.labourinformation.controls.modified_by.patchValue(0);
      this.ls
        .updateLabourInfoById(this.EditLabour.ID, this.labourinformation.value)
        .subscribe(
          res => {

            if (
              this.EditLabour.FullName ===
              this.labourinformation.controls.FullName.value &&
              this.EditLabour.ResidingatFarm ===
              this.labourinformation.controls.ResidingatFarm.value &&
              this.EditLabour.Relationship ===
              this.labourinformation.controls.Relationship.value &&
              this.EditLabour.MaritalStatus ===
              this.labourinformation.controls.MaritalStatus.value &&
              this.EditLabour.Age ===
              this.labourinformation.controls.Age.value &&
              this.EditLabour.Sex ===
              this.labourinformation.controls.Sex.value &&
              this.EditLabour.TypeofWork ===
              this.labourinformation.controls.TypeofWork.value &&
              this.EditLabour.PaymentType ===
              this.labourinformation.controls.PaymentType.value &&
              this.EditLabour.PaymentFrequency ===
              this.labourinformation.controls.PaymentFrequency.value &&
              this.EditLabour.Holidays ===
              this.labourinformation.controls.Holidays.value &&
              this.EditLabour.Education ===
              this.labourinformation.controls.Education.value &&
              this.EditLabour.DependentStatus ===
              this.labourinformation.controls.DependentStatus.value &&
              this.EditLabour.PercentageTimeonFarm ===
              this.labourinformation.controls.PercentageTimeonFarm.value &&
              this.EditLabour.MajorWork ===
              this.labourinformation.controls.MajorWork.value &&
              this.EditLabour.MinorWork ===
              this.labourinformation.controls.MinorWork.value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.dispalyLabourinformation();
              this.togglecloseLabourUpdate();
            }
          },

        );
    }
  }

  deleteLabourInfo(id: string) {
    ;
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteLabourInfoById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.dispalyLabourinformation();
          }
        });
      }
    });
  }
}
