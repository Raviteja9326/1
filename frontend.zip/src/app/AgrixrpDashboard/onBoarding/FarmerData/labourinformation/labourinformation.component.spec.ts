import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabourinformationComponent } from './labourinformation.component';

describe('LabourinformationComponent', () => {
  let component: LabourinformationComponent;
  let fixture: ComponentFixture<LabourinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabourinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabourinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
