export interface Labour {
    ID?:any;
    FullName?: any;
    ResidingatFarm?: any;
    Relationship?: any;
    MaritalStatus?: any;
    Age?: any;
    Sex?: any;
    TypeofWork?: any;
    PaymentType?: any;
    PaymentFrequency:any;
    Holidays:any;
    Education?: any;
    DependentStatus?: any;
    PercentageTimeonFarm?: any;
    MajorWork?: any;
    MinorWork?: any;
    Created_by:any;
    Modified_by:any;
}