import { Component, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { MastersService } from "app/services/masters.service";
import Swal from "sweetalert2";
import { FormBuilder, Validators } from "@angular/forms";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { Landlayout } from "./landlayout";

@Component({
  selector: "app-landlayout",
  templateUrl: "./landlayout.component.html",
  styleUrls: ["./landlayout.component.scss"]
})
export class LandlayoutComponent implements OnInit {
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "TblFarmer_ID",
    "TblSoilType_ID",
    "LandName",
    "SoilErrotions",
    "Tenure",
    "LandValue",
    "LandRevenueValue",
    "RentalValue",
    "Area",
    "LandinUse",
    "UnderBorders",
    "Irrigation",
    "Topography",
    "Leased",
    "Drinage",
    "Actions"
  ];
  editLand = true;
  editLandContent = "add_circle";
  LandNames = "Land List";
  userLandData: any = [];
  displayddl: string;
  updateLand = false;
  viewLand = false;
  editfarm: any = [];
  userSoilTypeData: any = [];
  EditLandlay: any = [];
  EditOldLand: any = [];
  editViewLand: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  landSelect = ["Yes", "No"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  LandForm = this.formBuilder.group({
    TblFarmer_ID: ["", [Validators.required]],
    TblSoilType_ID: ["", [Validators.required]],
    LandName: ["", [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
    Tenure: [""],
    LandinUse: [""],
    UnderBorders: [""],
    LandValue: [""],
    Irrigation: [""],
    Topography: [""],
    Leased: [""],
    Drinage: [""],
    SoilErrotions: [""],
    LandRevenueValue: [""],
    RentalValue: [""],
    Area: [""]
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  constructor(
    private http: HttpClient,
    private formBuilder: FormBuilder,
    private ds: MastersService
  ) { }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }

  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.LandForm.valid) {
      this.LandForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    this.displayLand();
    this.ds.getFarmerdata().subscribe(res => {
      this.editfarm = res;
    });

    this.ds.getSoilTypeData().subscribe(
      res => {
        this.userSoilTypeData = res;
      },
      err => console.error(err)
    );
  }

  displayLand() {
    this.ds.getlandlayoutData().subscribe(
      list => {
        this.isLoading = false;
        this.userLandData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userLandData);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Landlayout, filter: string) =>
          data.LandName.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  toggleEditLand() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.displayLand();
    this.LandForm.reset();
    this.LandNames = this.LandNames === "Add Land" ? "Land List" : "Add Land";
    this.editLandContent =
      this.editLandContent === "cancel" ? "add_circle" : "cancel";
    this.editLand = !this.editLand;
    this.displayddl = this.editLand ? "inline" : "none";
  }

  toggleUpdateLand(getLandDataObj) {
    this.EditLandlay = getLandDataObj;
    this.updateLand = !this.updateLand;
    this.displayddl = !this.editLand ? "inline" : "none";
    this.LandForm.setValue({
      Tenure: this.EditLandlay.Tenure,
      LandName: this.EditLandlay.LandName,
      LandinUse: this.EditLandlay.LandinUse,
      UnderBorders: this.EditLandlay.UnderBorders,
      LandValue: this.EditLandlay.LandValue,
      Irrigation: this.EditLandlay.Irrigation,
      Topography: this.EditLandlay.Topography,
      Leased: this.EditLandlay.Leased,
      Drinage: this.EditLandlay.Drinage,
      SoilErrotions: this.EditLandlay.SoilErrotions,
      LandRevenueValue: this.EditLandlay.LandRevenueValue,
      RentalValue: this.EditLandlay.RentalValue,
      TblFarmer_ID: this.EditLandlay.TblFarmer_ID,
      TblSoilType_ID: this.EditLandlay.TblSoilType_ID,
      Area: this.EditLandlay.Area
    });
  }

  toggleUpdateLand2() {
    this.updateLand = false;
    this.displayddl = this.editLand ? "inline" : "block";
  }

  toggleViewLand(getLandDataObj) {
    this.editViewLand = getLandDataObj;
    this.viewLand = !this.viewLand;
    this.displayddl = !this.editLand ? "inline" : "none";
  }

  toggleViewLand2() {
    this.viewLand = false;
    this.displayddl = !this.editLand ? "inline" : "block";
  }

  createLand(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.LandForm.valid) {
      Object.keys(this.LandForm.controls).forEach(field => {
        const control = this.LandForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ds.savelandlayoutsData(this.LandForm.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Loan",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayLand();
            this.toggleEditLand();
          }
        },
        err => console.error(err)
      );
    }
  }

  deleteLand(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ds.deletelandlayoutsDataById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayLand();
          }
        });
      }
    });
  }

  updateLandLayout(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.EditLandlay = data;
    if (!this.LandForm.valid) {
      Object.keys(this.LandForm.controls).forEach(field => {
        const control = this.LandForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ds
        .updatelandlayoutsDataById(this.EditLandlay.ID, this.LandForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayLand();
              this.toggleUpdateLand2();
            }
          },

        );
    }
  }
}
