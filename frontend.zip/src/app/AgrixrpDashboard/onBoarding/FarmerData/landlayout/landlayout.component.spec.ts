import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LandlayoutComponent } from './landlayout.component';

describe('LandlayoutComponent', () => {
  let component: LandlayoutComponent;
  let fixture: ComponentFixture<LandlayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LandlayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LandlayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
