export interface Landlayout {
    ID?: number;
    Tenure?: any;
    LandName?: any;
    LandinUse?: any;
    UnderBorders?: any;
    LandValue?: any;
    Irrigation?: any;
    Topography?: any;
    Leased?: any;
    Drinage?: any;
    SoilErrotions?: any;
    LandRevenueValue?: any;
    RentalValue?: any;
    TblFarmer_ID?: number;
    TblSoilType_ID?:number;
    Area?: any;
}
