import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkcopworkflow',
  templateUrl: './checkcopworkflow.component.html',
  styleUrls: ['./checkcopworkflow.component.scss']
})
export class CheckcopworkflowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
