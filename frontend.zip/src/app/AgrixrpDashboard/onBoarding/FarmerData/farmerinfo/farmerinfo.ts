export interface Farmer {
    ID: number;
    FarmerName?: string;
    SurName?: string;
    FatherName?: string;
    AadhaarNo?: number;
    BankName?: any;
    BankBranch?: any;
    IFSCCode?: any;
    MobileNumber?: any;
    BankAccountNo?: any;
    Address?: any;
    created_by?: number;
    modified_by?: number;
    Gender?: any;
    CultivateCrop?: any;
    FarmerImage?: any;
    TblVillage_ID?: number;

}
export interface stepcheck {
    QCIModuleID?: number;
    CheckListID?: number;
    Action?: any;
    ExtraAction?: any;
    FarmerID?: number;
}
