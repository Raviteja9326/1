import { Component, OnInit, ViewChild } from "@angular/core";
import Swal from "sweetalert2";
import { Farmer } from "./farmerinfo";
import { Validators, FormBuilder } from "@angular/forms";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "../../../../services/masters.service";
import { CASService } from 'app/services/cas.service';

@Component({
  selector: "app-farmerinfo",
  templateUrl: "./farmerinfo.component.html",
  styleUrls: ["./farmerinfo.component.scss"]
})
export class FarmerinfoComponent implements OnInit {

  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "FarmerName",
    "Gender",
    "FatherName",
    "MobileNumber",
    "AadhaarNo",
    "BankName",
    "BankBranch",
    "IFSCCode",
    "BankAccountNo",
    "Address",
    "CultivateCrop",
    "TblVillage_ID",
    "Actions"
  ];
  editFarmer = true;
  editFarmerContent = "add_circle";
  FarmerNames = "Farmer's List";
  displayddl: string;
  updateFarmer = false;
  viewFarmer = false;
  userFarmersdata: Farmer[] = [];
  Editcoun: any = [];
  Editfarm: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;
  getvillId: any;
  villid: any;
  sStatesData: any[];
  sDistrtictsData: any[];
  sMandalsData: any[];
  sCountriesData: any[];
  createBtn: boolean;
  EditBtn: boolean;
  delBtn: boolean;
  read: boolean;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  FarmerForm = this.formBuilder.group({
    FarmerName: [
      "",
      [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(30),
        Validators.pattern("^[a-zA-Z\\s]+$")
      ]
    ],
    SurName: [
      "",
      [
        Validators.required,
        Validators.maxLength(30),
        Validators.pattern("^[a-zA-Z\\s]+$")
      ]
    ],
    MobileNumber: [
      "",
      [
        Validators.required,
        Validators.minLength(10),
        Validators.pattern("[6-9]\\d{9}")
      ]
    ],
    AadhaarNo: [""],
    FatherName: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    BankName: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    BankBranch: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    IFSCCode: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[A-Za-z0-9]+$")]
    ],
    BankAccountNo: ["", [Validators.pattern("^[0-9 +]+$")]],
    Address: [
      "",
      [Validators.required, Validators.maxLength(100)]
    ],
    Gender: [""],
    CultivateCrop: ["", [Validators.required]],
    FarmerImage: [""],
    TblVillage_ID: ["", [Validators.required]],
    created_by: [""],
    modified_by: [""],

  });



  genders = ["Male", "Female", "Others"];


  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };


  constructor(
    private ls: MastersService,
    private formBuilder: FormBuilder,
    private ps: CASService,
  ) { }

  Image = this.formBuilder.group({
    Activity: ['', [Validators.required]]
  });

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.FarmerForm.valid) {
      this.FarmerForm.reset();
    }
  }


  ngOnInit() {
    this.displayfarmers();
    this.getCountrties();
    this.createBtn = this.ps.checkCrud("Farmer Information", "C");
    this.read = this.ps.checkCrud("Farmer Information", "R")
    this.EditBtn = this.ps.checkCrud("Farmer Information", "U");
    this.delBtn = this.ps.checkCrud("Farmer Information", "D");
  }

  getCountrties() {
    this.sStatesData = [];
    this.sDistrtictsData = [];
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getCountriesData().subscribe((response) => {
      this.sCountriesData = response;
      //console.log('thisis cohntries', this.sCountriesData);
    });
  }
  async onChangeCountry(ID: string) {
    this.sStatesData = [];
    this.sDistrtictsData = [];
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getStatesDataByCountry(ID).subscribe((response) => {
      if (response['data'] === 'NO States Available with this Country ID') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No States Available with this Country',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.sStatesData = response;
      }
    });
  }
  async onChangedist(ID: string) {
    this.sDistrtictsData = [];
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getDistrictDataByDist(ID).subscribe((response) => {
      if (response['data'] === 'No Districts Available With This ID') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No Districts Available With this State',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.sDistrtictsData = response;
      }
    });
  }
  async onChangeMandals(ID: string) {
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getMandalsDataBydist(ID).subscribe((response) => {
      //console.log('this is reposce after selecting sitr', response);
      if (response['data'] === 'No Mandals Available With This ID') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No Mandals Available with this District',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.sMandalsData = response;
      }
    });
  }
  async onChangeVillages(ID: string) {
    this.getvillId = [];
    this.ls.getVillagesDataByMandalID(ID).subscribe((response) => {
      if (response['data'] === 'No Data Available with this ID :-(') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No villages Available with this District',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.getvillId = response;
      }
    });
  }

  displayfarmers() {
    this.ls.getFarmerdata().subscribe(
      list => {
        this.isLoading = false;
        this.userFarmersdata = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userFarmersdata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Farmer, filter: string) =>
          data.FarmerName.toLowerCase().indexOf(filter) !== -1 ||
          data.SurName.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  toggleEditFarmer() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.displayfarmers();
    this.FarmerForm.reset();
    this.FarmerNames =
      this.FarmerNames === "Add Farmer" ? "Farmer's List" : "Add Farmer";
    this.editFarmer = !this.editFarmer;
    this.editFarmerContent =
      this.editFarmerContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editFarmer ? "inline" : "none";
  }

  toggleUpdateFarmers(getFarmersDataObj) {
    this.Editfarm = getFarmersDataObj;
    this.updateFarmer = !this.updateFarmer;
    this.displayddl = !this.editFarmer ? "inline" : "none";
    this.FarmerForm.setValue({
      FarmerName: this.Editfarm.FarmerName,
      SurName: this.Editfarm.SurName,
      FatherName: this.Editfarm.FatherName,
      AadhaarNo: this.Editfarm.AadhaarNo,
      BankName: this.Editfarm.BankName,
      BankBranch: this.Editfarm.BankBranch,
      IFSCCode: this.Editfarm.IFSCCode,
      MobileNumber: this.Editfarm.MobileNumber,
      BankAccountNo: this.Editfarm.BankAccountNo,
      Address: this.Editfarm.Address,
      created_by: this.Editfarm,
      modified_by: this.Editfarm.modified_by,
      Gender: this.Editfarm.Gender,
      CultivateCrop: this.Editfarm.CultivateCrop,
      FarmerImage: this.Editfarm.FarmerImage,
      TblVillage_ID: this.Editfarm.TblVillage_ID,
    });
  }

  toggleUpdateFarmer2() {
    this.updateFarmer = false;
    this.displayddl = this.editFarmer ? "inline" : "block";
  }


  toggleViewFarmers(getFarmersDataObj) {
    this.Editcoun = getFarmersDataObj;
    //console.log(this.Editcoun)
    this.ls.getVillagesDataByID(this.Editcoun.TblVillage_ID).subscribe(res => {
      this.villid = res;
    });
    this.viewFarmer = !this.viewFarmer;
    this.displayddl = !this.editFarmer ? "inline" : "none";
  }


  toggleViewFarmer2() {
    this.viewFarmer = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }




  CreateFarmer() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.FarmerForm.valid) {
      Object.keys(this.FarmerForm.controls).forEach(field => {
        const control = this.FarmerForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.FarmerForm.controls.created_by.patchValue(1);
      this.ls.saveFarmerdata(this.FarmerForm.value).subscribe(
        res => {

          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Farmer",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayfarmers();
            this.toggleEditFarmer();
          } else if ((res["data"] = "serverErrorfarmerExistences")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Farmer Already Exists with Same Details",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  UpdateFarmers(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.Editfarm = data;
    if (!this.FarmerForm.valid) {
      Object.keys(this.FarmerForm.controls).forEach(field => {
        const control = this.FarmerForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.FarmerForm.controls.modified_by.patchValue(1);
      this.ls
        .updateFarmerByID(this.Editfarm.ID, this.FarmerForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Successfully Updated") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayfarmers();
              this.toggleUpdateFarmer2();
            } else if ((res["data"] = "serverErrorfarmerExistences")) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "Farmer Already Exists with Details",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            }
          },

        );
    }
  }

  deleteFarmer(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteFarmerByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayfarmers();
          }
        });
      }
    });
  }

}
