export interface stepcheck {
    QCIModuleID?: number;
    CheckListID?: number;
    Action?: any;
    ExtraAction?: any;
    FarmerID?: number;
}
