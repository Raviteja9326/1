import { Component, OnInit, ViewChild, Input, ElementRef } from "@angular/core";
import Swal from "sweetalert2";
import { Validators, FormBuilder } from "@angular/forms";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService, API_URl } from "../../../../services/masters.service";
import { FlipAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';
import { CASService } from 'app/services/cas.service';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Farmer } from '../farmerinfo/farmerinfo';
import { MatAccordion } from '@angular/material';

@Component({
  selector: "app-farmerchecklist",
  templateUrl: "./farmerchecklist.component.html",
  styleUrls: ["./farmerchecklist.component.scss"],
  animations: FlipAnimation.animations
})
export class FarmercheckComponent implements OnInit {
  landSelect = ["Yes", "No"];
  land1Select = ["Manual", "Tractor"];
  land2Select = ["Organic", "Inorganic"];
  landsSelect = ["Rain fed", "Irrigation"];
  landwsSelect = [" Manual", "Machinery"];
  landwssSelect = [" Multi crop", "Single crop"];
  landwsssSelect = ["sowing", "Planting methods"]


  sandy = [
    { id: 1, label: "vegetable + rice" },
    { id: 2, label: "maze" },
    { id: 3, label: "cotton" },
    { id: 4, label: "others" }
  ];

  days = [
    { id: 1, label: "Monday" },
    { id: 2, label: "Tuesday" },
    { id: 3, label: "Wensday" },
    { id: 4, label: "Thursday" },
    { id: 5, label: "Friday" },
    { id: 6, label: "Saturday" },
    { id: 7, label: "Sunday" },

  ];

  breswell = [
    { id: 1, label: "surface" },
    { id: 2, label: "localized" },
    { id: 3, label: "Drip" },
    { id: 4, label: "Sprinkler" },
    { id: 5, label: "Center pivot" },
    { id: 6, label: "Lateral move" },
    { id: 7, label: "Sub – irrigation" },
    { id: 8, label: "Manual" },
    { id: 9, label: "None" },
  ];
  brewell = [
    { id: 1, label: "Bore well" },
    { id: 2, label: "Lake" },
    { id: 3, label: "River" },
    { id: 4, label: "Rain water harvesting" },
    { id: 5, label: "None" },
  ]

  inorganic = [
    { id: 1, label: "Sprayers " },
    { id: 2, label: "Thru drip" },
    { id: 3, label: "Thru sprinklers" },
    { id: 4, label: "None" },

  ]
  harvest = [
    { id: 1, label: "Manual " },
    { id: 2, label: "Tools" },
    { id: 3, label: "Both" },
    { id: 4, label: "None" },

  ]
  harvests = [
    { id: 1, label: "1Hrs " },
    { id: 2, label: "2Hrs" },
    { id: 3, label: "3Hrs" },
    { id: 4, label: "4Hrs" },
    { id: 5, label: "5Hrs" },
    { id: 6, label: "6Hrs" },
    { id: 7, label: "7Hrs" },

  ]
  soils = [
    { id: 1, label: "Red soil" },
    { id: 2, label: "Lateritic soil" },
    { id: 3, label: "Black Soil" },
    { id: 4, label: "Forest And hill soil" },
    { id: 5, label: "Forest soil" },
    { id: 6, label: "Blue soil" },
    { id: 7, label: "Fertile soil" },
    { id: 7, label: "Yellow soil" },

  ]
  animal = [
    { id: 1, label: "Diary" },
    { id: 2, label: "Poultry" },
    { id: 3, label: "Sheep" },
    { id: 4, label: "Piggery" },
    { id: 5, label: "Fishery" },
    { id: 6, label: "None" },

  ]
  flip = 'inactive';
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "FarmerName",
    "MobileNumber",
    "CheckList",
    "Actions"
  ];
  editFarmer = true;
  editFarmerContent = "add_circle";
  FarmerNames = "Farmer's CheckList";
  imgshow: boolean;
  imgsadh: boolean;
  imgsland: boolean;
  imgscompost: boolean;
  imgssoil: boolean;
  imgswater: boolean;
  imgsinorganic: boolean;
  imgsorganic: boolean;
  imgsmachine: boolean;
  sampletraining: boolean;
  displayddl: string;
  updateFarmer = false;
  viewFarmer = false;
  userFarmersdata: Farmer[] = [];
  Editcoun: any = [];
  checkobj: any = [];
  checksobj: any = [];
  Editfarm: any = [];
  EditFarmersData: any = [];
  EditOldData: any = [];
  userVillagedata: any = [];
  viewchecking: any[] = [];
  Checking: any;
  submitted = false;
  viewFarmerimages = false;
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;
  getvillId: any;
  villid: any;
  checking: any = []
  ctry: any;
  sts: any;
  dts: any;
  sStatesData: any[];
  sDistrtictsData: any[];
  sMandalsData: any[];
  sCountriesData: any[];
  fileData: any = [];
  filesData: any = [];
  filesSoil: string[] = [];
  filesland: string[] = [];
  fileswater: string[] = [];
  filesseed: string[] = [];
  filesinorganic: string[] = [];
  filesorganics: string[] = [];
  filesmachine: string[] = [];
  filescompost: string[] = [];
  filestraning: string[] = [];
  capti: any;
  dete: any;
  rawImage: any[];
  activities: any[];
  FarmerChecklist = false;
  viewFarmerCheckLists = false;
  FarmerviewChecklist = false;
  checkdata: any = [];
  stepfarmer: any = {}
  createBtn: boolean;
  EditBtn: boolean;
  delBtn: boolean;
  read: boolean;
  sheet = false;
  sheets = false;
  sheets2 = false;
  sheeting = false;
  dies = false;
  panelOpenState = false;

  @Input() max: any;
  tomorrow = new Date();
  @ViewChild('fileUploader') fileUploader: ElementRef;
  @ViewChild('fileUploader2') fileUploader2: ElementRef;
  @ViewChild('fileUploader3') fileUploader3: ElementRef;
  @ViewChild('fileUploader4') fileUploader4: ElementRef;
  @ViewChild('fileUploader5') fileUploader5: ElementRef;
  @ViewChild('fileUploader6') fileUploader6: ElementRef;
  @ViewChild('fileUploader7') fileUploader7: ElementRef;
  @ViewChild('fileUploader8') fileUploader8: ElementRef;
  @ViewChild('fileUploader9') fileUploader9: ElementRef;
  @ViewChild('fileUploader10') fileUploader10: ElementRef;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild('accordion', { static: true }) Accordion: MatAccordion


  FarmerForm = this.formBuilder.group({
    FarmerName: [
      "",
      [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(30),
        Validators.pattern("^[a-zA-Z\\s]+$")
      ]
    ],
    SurName: [
      "",
      [
        Validators.required,
        Validators.maxLength(30),
        Validators.pattern("^[a-zA-Z\\s]+$")
      ]
    ],
    MobileNumber: [
      "",
      [
        Validators.required,
        Validators.minLength(10),
        Validators.pattern("[6-9]\\d{9}")
      ]
    ],
    AadhaarNo: [""],
    FatherName: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    BankName: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    BankBranch: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[a-zA-Z\\s]+$")]
    ],
    IFSCCode: [
      "",
      [Validators.maxLength(30), Validators.pattern("^[A-Za-z0-9]+$")]
    ],
    BankAccountNo: ["", [Validators.pattern("^[0-9 +]+$")]],
    Address: [
      "",
      [Validators.required, Validators.maxLength(100)]
    ],
    Gender: [""],
    CultivateCrop: ["", [Validators.required]],
    FarmerImage: [""],
    TblVillage_ID: ["", [Validators.required]],
    created_by: [""],
    modified_by: [""],

  });
  Checking1: any;
  Checking2: any;
  farmerpic: any[];
  url: any;
  farmid: any[];
  ardharImages: any[];
  landImages: any[];
  compstImages: any[];
  soilImages: any[];
  waterImages: any[];
  machineryImages: any[];
  trainingImages: any[];
  inorganImages: any[];
  organImages: any[];

  show() {
    this.sheet = true
  }
  hide() {
    this.checklists14.reset();
    this.sheet = false
  }

  shows() {
    this.sheets = true
  }
  hides() {
    this.sheets = false
  }

  shows2() {
    this.sheeting = true
  }
  hides2() {
    this.sheeting = false
  }

  shows1() {
    this.sheets2 = true
  }
  hides1() {
    this.sheets2 = false
  }


  beforePanelClosed(panel) {
    panel.isExpanded = false;
    console.log("Panel going to close!");
  }
  beforePanelOpened(panel) {
    panel.isExpanded = true;
    console.log("Panel going to  open!");
  }

  afterPanelClosed() {
    console.log("Panel closed!");
  }
  afterPanelOpened() {
    console.log("Panel opened!");
  }


  closeAllPanels() {
    this.Accordion.closeAll();
  }
  openAllPanels() {
    this.Accordion.openAll();
  }


  checklists = this.formBuilder.group({
    phn: [""]
  });

  checklists1 = this.formBuilder.group({
    patta: [""],
    living: [""],
    sanitiser: [""],
    testing: [""]
  });


  checklists21 = this.formBuilder.group({
    crop1: [""],
    crop4: [""],
    crop6: [""],
    crop7: [""]

  });

  checklists22 = this.formBuilder.group({
    crop2: [""],
    crop3: [""]

  });

  checklists14 = this.formBuilder.group({
    brick: [""],
    category: [""]
  })

  checklists2 = this.formBuilder.group({
    soil: [""],
    saas: [""],
    ploughing: [""],
    fertilizer: [""],
    date: [""],
  });

  checklists3 = this.formBuilder.group({
    Water: [""],
    Source: [""],
    irrigation: [""],
    Type: [""],
    fertigation: [""],
    conservation: [""],
  });

  checklists4 = this.formBuilder.group({
    emptys: [""],
    sowing: [""],
    Planting: [""],
    rootstock: [""],
    empty: [""],
    pratice: [""],
  });

  checklists5 = this.formBuilder.group({
    inorganic: [""],
    sprayers: [""],
    pesticides: [""],
    covered: [""],
    contaminate: [""],
    protect: [""],
  });

  checklists6 = this.formBuilder.group({
    farm: [""],
    List: [""],
    using: [""],
    Clean: [""],
  });

  checklists7 = this.formBuilder.group({
    machines: [""],
    safe: [""],
    precautions: [""],

  });
  checklists15 = this.formBuilder.group({
    tractor: [""],
    sentiment: [""]
  })
  checklists8 = this.formBuilder.group({
    Manually: [""],
    hygienic: [""],
    transportation: [""],
  });

  checklists9 = this.formBuilder.group({
    cautions: [""],
    instruction: [""],
    working: [""],
    aid: [""],
    cloths: [""],
    Dust: [""],
  });

  checklists10 = this.formBuilder.group({
    drinking: [""],
    maintain: [""],
    protective: [""],
    Provide: [""],
    Separate: [""],
    Manure: [""],
  });

  checklists11 = this.formBuilder.group({
    safety: [""],
    pest: [""],
    program: [""],
    Training: [""],
  });

  checklists12 = this.formBuilder.group({
    Animal: [""],
    Specify: [""],
    Fodder: [""],
    drainage: [""],
    collection: [""],
    Medicine: [""],
    Vaccination: [""],
    Stall: [""],
    poultry: [""],
    Clean: [""],
  });




  resetunknow() {
    this.fileData = [];
    this.filesData = [];
    this.filesSoil = [];
    this.filesland = [];
    this.fileswater = [];
    this.filesseed = [];
    this.filesinorganic = [];
    this.filesorganics = [];
    this.filesmachine = [];
    this.filescompost = [];
    this.filestraning = [];
    this.checklists12.reset();
    this.checklists11.reset();
    this.checklists10.reset();
    this.checklists9.reset();
    this.checklists8.reset();
    this.checklists15.reset();
    this.checklists7.reset();
    this.checklists6.reset();
    this.checklists5.reset();
    this.checklists4.reset();
    this.checklists3.reset();
    this.checklists2.reset();
    this.checklists14.reset();
    this.checklists1.reset();
    this.checklists21.reset();
    this.checklists22.reset();
    this.checklists.reset();
    this.sheet = false;
    this.sheets2 = false;
    this.sheets = false;
    this.sheeting = false;
    this.imgshow = false;
    this.imgsadh = false;
    this.imgsland = false;
    this.imgscompost = false;
    this.imgssoil = false;
    this.imgswater = false;
    this.imgsinorganic = false;
    this.imgsorganic = false;
    this.imgsmachine = false;
    this.sampletraining = false;
  }


  genders = ["Male", "Female", "Others"];


  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  toggleFlip() {
    this.activities = [
      'Crop',
      'Animal',
      'Loan',
      'Land',
      'Asset',
      'Disease',
      'Pest Control',
      'Soil Test',
      'Water Test'
    ];
    //console.log(this.activities);
    this.flip = this.flip === 'active' ? 'inactive' : 'active';
  }

  constructor(
    private toastr: ToastrService,
    private ls: MastersService,
    private formBuilder: FormBuilder,
    private ps: CASService,
    private dp: DatePipe,
    private spinner: NgxSpinnerService
  ) { this.tomorrow.setDate(this.tomorrow.getDate() + 1); }

  Image = this.formBuilder.group({
    Activity: ['', [Validators.required]]
  });

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.FarmerForm.valid) {
      this.FarmerForm.reset();
    }
  }


  ngOnInit() {
    this.displayfarmers();
    this.getCountrties();
    this.createBtn = this.ps.checkCrud("Farmer Information", "C");
    this.read = this.ps.checkCrud("Farmer Information", "R")
    this.EditBtn = this.ps.checkCrud("Farmer Information", "U");
    this.delBtn = this.ps.checkCrud("Farmer Information", "D");
    this.url = API_URl;
  }

  getCountrties() {
    this.sStatesData = [];
    this.sDistrtictsData = [];
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getCountriesData().subscribe((response) => {
      this.sCountriesData = response;
      //console.log('thisis cohntries', this.sCountriesData);
    });
  }
  async onChangeCountry(ID: string) {
    this.sStatesData = [];
    this.sDistrtictsData = [];
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getStatesDataByCountry(ID).subscribe((response) => {
      if (response['data'] === 'NO States Available with this Country ID') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No States Available with this Country',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.sStatesData = response;
      }
    });
  }
  async onChangedist(ID: string) {
    this.sDistrtictsData = [];
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getDistrictDataByDist(ID).subscribe((response) => {
      if (response['data'] === 'No Districts Available With This ID') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No Districts Available With this State',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.sDistrtictsData = response;
      }
    });
  }
  async onChangeMandals(ID: string) {
    this.sMandalsData = [];
    this.getvillId = [];
    this.ls.getMandalsDataBydist(ID).subscribe((response) => {
      //console.log('this is reposce after selecting sitr', response);
      if (response['data'] === 'No Mandals Available With This ID') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No Mandals Available with this District',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.sMandalsData = response;
      }
    });
  }
  async onChangeVillages(ID: string) {
    this.getvillId = [];
    this.ls.getVillagesDataByMandalID(ID).subscribe((response) => {
      if (response['data'] === 'No Data Available with this ID :-(') {
        Swal.fire({
          position: 'center',
          type: 'info',
          title: 'No villages Available with this District',
          showConfirmButton: false,
          timer: 1500
        });
      } else {
        this.getvillId = response;
      }
    });
  }

  displayfarmers() {
    this.ls.getFarmerdata().subscribe(
      list => {
        this.isLoading = false;
        this.userFarmersdata = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userFarmersdata);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Farmer, filter) =>
          data.FarmerName.trim().toLowerCase().indexOf(filter) !== -1 ||
          data.SurName.trim().toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  toggleEditFarmer() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.displayfarmers();
    this.FarmerForm.reset();
    this.FarmerNames =
      this.FarmerNames === "Add Farmer" ? "Farmer's List" : "Add Farmer";
    this.editFarmer = !this.editFarmer;
    this.editFarmerContent =
      this.editFarmerContent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editFarmer ? "inline" : "none";
  }

  toggleUpdateFarmers(getFarmersDataObj) {
    this.Editfarm = getFarmersDataObj;
    this.updateFarmer = !this.updateFarmer;
    this.displayddl = !this.editFarmer ? "inline" : "none";
    this.FarmerForm.setValue({
      FarmerName: this.Editfarm.FarmerName,
      SurName: this.Editfarm.SurName,
      FatherName: this.Editfarm.FatherName,
      AadhaarNo: this.Editfarm.AadhaarNo,
      BankName: this.Editfarm.BankName,
      BankBranch: this.Editfarm.BankBranch,
      IFSCCode: this.Editfarm.IFSCCode,
      MobileNumber: this.Editfarm.MobileNumber,
      BankAccountNo: this.Editfarm.BankAccountNo,
      Address: this.Editfarm.Address,
      created_by: this.Editfarm,
      modified_by: this.Editfarm.modified_by,
      Gender: this.Editfarm.Gender,
      CultivateCrop: this.Editfarm.CultivateCrop,
      FarmerImage: this.Editfarm.FarmerImage,
      TblVillage_ID: this.Editfarm.TblVillage_ID,
    });
  }

  toggleUpdateFarmer2() {
    this.updateFarmer = false;
    this.displayddl = this.editFarmer ? "inline" : "block";
  }


  toggleViewFarmers(getFarmersDataObj) {
    this.Editcoun = getFarmersDataObj;
    //console.log(this.Editcoun)
    this.ls.getVillagesDataByID(this.Editcoun.TblVillage_ID).subscribe(res => {
      this.villid = res;
    });
    this.viewFarmer = !this.viewFarmer;
    this.displayddl = !this.editFarmer ? "inline" : "none";
  }

  toggleCheckList(getFarmersDataObj) {
    this.resetunknow();
    this.checkobj = getFarmersDataObj
    this.FarmerChecklist = !this.FarmerChecklist
    this.displayddl = !this.editFarmer ? "inline" : "none";
  }


  togglechecklistview(ID) {
    this.ls.getcheckfarmerID(ID).subscribe(res => {
      this.farmid = res;
    })
    this.ls.viewImageChecklist(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.farmerpic = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.farmerpic = res;
      }
    })
    this.ls.viewchecklistById(ID).subscribe(res => {
      if (res["data"] === "No Data Available with this ID") {
        Swal.fire({
          position: "center",
          type: "error",
          title: "NO Record Found",
          showConfirmButton: false,
          timer: 1500
        });
        this.toggleCloseFarmerCheckList();
      }
      else if (res["data"] = "data") {
        this.viewchecking = res;
        this.viewFarmerCheckLists = true;
        this.displayddl = !this.editFarmer ? "inline" : "none";
      }
    })

  }

  toggleCloseFarmerCheckList() {
    this.viewFarmerCheckLists = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }

  ConvertToJSON(checkList: any) {
    return JSON.parse(checkList);
  }

  toggleviewFarmerimages(ID) {
    this.ls.getardharimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.dies = true;
        this.ardharImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.dies = false;
        this.ardharImages = res;
      }
    })
    this.ls.getlandimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.landImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.landImages = res;
      }
    })
    this.ls.getCompostimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.compstImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.compstImages = res;
      }
    })
    this.ls.getsoilimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.soilImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.soilImages = res;
      }
    })
    this.ls.getwaterimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.waterImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.waterImages = res;
      }
    })
    this.ls.getMachineryimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.machineryImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.machineryImages = res;
      }
    })
    this.ls.getTraningimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.trainingImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.trainingImages = res;
      }
    })
    this.ls.getInorganicimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.inorganImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.inorganImages = res;
      }
    })
    this.ls.getInorganicimage(ID).subscribe(res => {
      if (res["data"] === "No Image Found") {
        this.organImages = [];
      }
      else if (res["data"] = "dataToSubmit") {
        this.organImages = res;
      }
    })

    this.viewFarmerimages = true;
    this.displayddl = !this.editFarmer ? "inline" : "none";
  }

  toggleCloseFarmerimages() {
    this.viewFarmerimages = false;
    this.displayddl = !this.editFarmer ? "inline" : "block";
  }


  toggleViewFarmer2() {
    this.viewFarmer = false;
    this.displayddl = !this.Editcoun ? "inline" : "block";
  }




  CreateFarmer() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.FarmerForm.valid) {
      Object.keys(this.FarmerForm.controls).forEach(field => {
        const control = this.FarmerForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.FarmerForm.controls.created_by.patchValue(1);
      this.ls.saveFarmerdata(this.FarmerForm.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Farmer",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayfarmers();
            this.toggleEditFarmer();
          } else if ((res["data"] = "serverErrorfarmerExistences")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Farmer Already Exists with Same Details",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  UpdateFarmers(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.Editfarm = data;
    if (!this.FarmerForm.valid) {
      Object.keys(this.FarmerForm.controls).forEach(field => {
        const control = this.FarmerForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.FarmerForm.controls.modified_by.patchValue(1);
      this.ls
        .updateFarmerByID(this.Editfarm.ID, this.FarmerForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayfarmers();
              this.toggleUpdateFarmer2();
            } else if ((res["data"] = "serverErrorfarmerExistences")) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "Farmer Already Exists with Details",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            }
          },

        );
    }
  }

  deleteFarmer(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteFarmerByID(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayfarmers();
          }
        });
      }
    });
  }
  sucesmsg() {
    this.savechecklist(this.checklists.value, 1);
    this.checkdata = [];
    this.savechecklist(this.checklists1.value, 2);
    this.checkdata = [];
    this.savechecklist(this.checklists2.value, 3);
    this.checkdata = [];
    this.savechecklist(this.checklists3.value, 4);
    this.checkdata = [];
    this.savechecklist(this.checklists4.value, 5);
    this.checkdata = [];
    this.savechecklist(this.checklists5.value, 6);
    this.checkdata = [];
    this.savechecklist(this.checklists6.value, 7);
    this.checkdata = [];
    this.savechecklist(this.checklists7.value, 8);
    this.checkdata = [];
    this.savechecklist(this.checklists8.value, 9);
    this.checkdata = [];
    this.savechecklist(this.checklists9.value, 10);
    this.checkdata = [];
    this.savechecklist(this.checklists10.value, 11);
    this.checkdata = [];
    this.savechecklist(this.checklists11.value, 12);
    this.checkdata = [];
    this.savechecklist(this.checklists12.value, 13);
    this.checkdata = [];
    this.savechecklist(this.checklists21.value, 14);
    this.checkdata = [];
    this.checkdata.push({ QCIModuleID: 2, CheckListID: 5, Action: this.checklists14.value.brick, extraAction: this.checklists14.value.category, FarmerID: this.checkobj.ID });
    this.checkdata.push();
    this.checkdata.push({ QCIModuleID: 8, CheckListID: 4, Action: this.checklists15.value.tractor, extraAction: this.checklists15.value.sentiment, FarmerID: this.checkobj.ID });
    this.checkdata.push();
    this.checkdata.push({ QCIModuleID: 14, CheckListID: 5, Action: this.checklists22.value.crop2, extraAction: this.checklists22.value.crop3, FarmerID: this.checkobj.ID });
    this.checkdata.push();
    this.ls.createCheckList(this.checkdata).subscribe(res => {
      if ((res["data"] = "Success")) {
        Swal.fire({
          position: "center",
          type: "success",
          title: "Sucessfully Checklist Added",
          showConfirmButton: false,
          timer: 1500
        });
        this.resetunknow();
        this.FarmerChecklist = false
        this.displayddl = this.editFarmer ? "inline" : "block";
        this.barButtonOptions.active = false;
        this.barButtonOptions.text = "SUBMIT";
      }
      else {
        Swal.fire({
          position: "center",
          type: "error",
          title: "Please Contact Admin",
          showConfirmButton: false,
          timer: 1500
        });
        this.barButtonOptions.active = false;
        this.barButtonOptions.text = "SUBMIT";
      }

    })
  }

  toggleFarmerviewChecklist() {
    this.FarmerviewChecklist = false;
    this.displayddl = this.editFarmer ? "inline" : "block";
  }

  toggleviewCheckList() {
    this.FarmerviewChecklist = !this.FarmerChecklist
    this.displayddl = !this.editFarmer ? "inline" : "none";
  }

  savechecklist(data, moduleID) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";

    for (let index = 0; index < Object.values(data).length; index++) {
      this.checkdata.push({ QCIModuleID: moduleID, CheckListID: 1 + index, Action: Object.values(data)[index], extraAction: "", FarmerID: this.checkobj.ID });
    }
    if (this.checklists14.value.brick == null) {
      this.checklists14.value.brick = this.landSelect[1];
    }
    if (this.checklists1.value.living == null) {
      this.checklists1.value.living = this.landSelect[1];
    }
    if (this.checklists1.value.sanitiser == null) {
      this.checklists1.value.sanitiser = this.landSelect[1];
    }
    if (this.checklists7.value.safe == null) {
      this.checklists7.value.safe = this.landSelect[0];
    }
    if (this.checklists7.value.precautions == null) {
      this.checklists7.value.precautions = this.landSelect[0];
    }
    if (this.checklists8.value.hygienic == null) {
      this.checklists8.value.hygienic = this.landSelect[0];
    }
    if (this.checklists8.value.transportation == null) {
      this.checklists8.value.transportation = this.landSelect[0];
    }
    if (this.checklists9.value.cautions == null) {
      this.checklists9.value.cautions = this.landSelect[0];
    }
    if (this.checklists9.value.instruction == null) {
      this.checklists9.value.instruction = this.landSelect[0];
    }
    if (this.checklists9.value.working == null) {
      this.checklists9.value.working = this.landSelect[0];
    }
    if (this.checklists9.value.aid == null) {
      this.checklists9.value.aid = this.landSelect[0];
    }
    if (this.checklists9.value.cloths == null) {
      this.checklists9.value.cloths = this.landSelect[0];
    }
    if (this.checklists9.value.Dust == null) {
      this.checklists9.value.Dust = this.landSelect[0];
    }
    if (this.checklists10.value.drinking == null) {
      this.checklists10.value.drinking = this.landSelect[0];
    }
    if (this.checklists10.value.maintain == null) {
      this.checklists10.value.maintain = this.landSelect[0];
    }
    if (this.checklists10.value.protective == null) {
      this.checklists10.value.protective = this.landSelect[0];
    }
    if (this.checklists10.value.Separate == null) {
      this.checklists10.value.Separate = this.landSelect[0];
    }
    if (this.checklists10.value.Provide == null) {
      this.checklists10.value.Provide = this.landSelect[0];
    }
    if (this.checklists10.value.Manure == null) {
      this.checklists10.value.Manure = this.landSelect[0];
    }
    if (this.checklists11.value.safety == null) {
      this.checklists11.value.safety = this.landSelect[0];
    }
    if (this.checklists11.value.pest == null) {
      this.checklists11.value.pest = this.landSelect[0];
    }
    if (this.checklists11.value.Training == null) {
      this.checklists11.value.Training = this.landSelect[0];
    }
    if (this.checklists11.value.program == null) {
      this.checklists11.value.program = this.landSelect[0];
    }

    this.checklists2.value.fertilizer = this.dp.transform(
      this.checklists2.value.fertilizer,
      "yyyy-MM-dd"
    );
    this.checklists2.value.date = this.dp.transform(
      this.checklists2.value.date,
      "yyyy-MM-dd"
    );
    this.checklists4.value.Planting = this.dp.transform(
      this.checklists4.value.Planting,
      "yyyy-MM-dd"
    );
    this.checklists4.value.rootstock = this.dp.transform(
      this.checklists4.value.rootstock,
      "yyyy-MM-dd"
    );
    console.log(this.checkdata)
    this.ls.createCheckList(this.checkdata).subscribe(res => {
    })

  }


  toggleFarmerChecklist() {
    this.FarmerChecklist = false;
    this.displayddl = this.editFarmer ? "inline" : "block";
  }

  Files: string[] = [];

  uploadFile(event) {
    let reader = new FileReader();
    this.fileData = event.target.files[0];
    //console.log(this.fileData)
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(this.fileData);
    }
    console.log(this.fileData)
  }
  uploadFiles(event) {
    let readers = new FileReader();
    this.filesData = event.target.files[0];
    //console.log(this.fileData)
    if (event.target.files && event.target.files[0]) {
      readers.readAsDataURL(this.filesData);
    }
    console.log(this.fileData)
  }

  uploadSoil(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filesSoil.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }

  uploadland(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filesland.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }

  uploadcompost(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filescompost.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }

  uploadwater(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.fileswater.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }
  uploadseed(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filesseed.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }
  uploadinorganic(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filesinorganic.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }

  uploadorganic(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filesorganics.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }

  uploadmachine(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filesmachine.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }

  uploadtraining(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filestraning.push(event.target.files[i]);
    }
    console.log(this.filesSoil)
  }


  resetprofile() {
    this.fileData = [];
    this.imgshow = false
    this.fileUploader.nativeElement.value = null;
  }
  resetadhar() {
    this.filesData = [];
    this.imgsadh = false
    this.fileUploader2.nativeElement.value = null;
  }
  resetland() {
    this.filesland = []
    this.imgsland = false
    this.fileUploader3.nativeElement.value = null;
  }

  resetcompost() {
    this.filescompost = []
    this.imgscompost = false
    this.fileUploader4.nativeElement.value = null;
  }
  resetsoil() {
    this.filesSoil = []
    this.imgssoil = false
    this.fileUploader5.nativeElement.value = null;
  }
  resetwater() {
    this.fileswater = []
    this.imgswater = false
    this.fileUploader6.nativeElement.value = null;
  }
  resetinorganic() {
    this.filesinorganic = []
    this.imgsinorganic = false
    this.fileUploader7.nativeElement.value = null;
  }

  resetorganic() {
    this.filesorganics = []
    this.imgsorganic = false
    this.fileUploader8.nativeElement.value = null;
  }

  resetmachine() {
    this.filesmachine = []
    this.imgsmachine = false
    this.fileUploader9.nativeElement.value = null;
  }

  resettraning() {
    this.filestraning = []
    this.sampletraining = false
    this.fileUploader10.nativeElement.value = null;
  }



  profile() {
    if (this.fileData === null || this.fileData === undefined || this.fileData === [] || this.fileData === "" || this.fileData === {} || this.fileData <= 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.fileData = [];
      this.imgshow = false
      this.fileUploader.nativeElement.value = null;
    }
    else {
      console.log(this.checkobj.ID)
      var formData = new FormData();
      formData.append('sampleImages', this.fileData);
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciProfile");
      this.spinner.show()
      this.ls.saveFarmerprofile(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide();
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.fileData = [];
          this.imgshow = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 1',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }
  adhar() {
    if (this.filesData === null || this.filesData === undefined || this.filesData === [] || this.filesData === "" || this.filesData === {} || this.filesData <= 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filesData = [];
      this.imgsadh = false
      this.fileUploader2.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      formData.append('sampleImage', this.filesData);
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciAdhar");
      this.spinner.show()
      this.ls.saveFarmeradhar(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesData = []
          this.imgsadh = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 1',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }

  soil() {
    if (this.filesSoil.length === null || this.filesSoil.length === undefined || this.filesSoil.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filesSoil = []
      this.imgssoil = false
      this.fileUploader5.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filesSoil.length; i++) {
        formData.append("samplesoil", this.filesSoil[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciSoil");
      this.spinner.show()
      this.ls.saveFarmersoil(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesSoil = []
          this.imgssoil = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }

  land() {
    if (this.filesland.length === null || this.filesland.length === undefined || this.filesland.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filesland = []
      this.imgsland = false
      this.fileUploader3.nativeElement.value = null;

    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filesland.length; i++) {
        formData.append("sampleland", this.filesland[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciLand");
      this.spinner.show()
      this.ls.saveFarmerland(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesland = []
          this.imgsland = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }

  compost() {
    if (this.filescompost.length === null || this.filescompost.length === undefined || this.filescompost.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filescompost = []
      this.imgscompost = false
      this.fileUploader4.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filescompost.length; i++) {
        formData.append("samplecompost", this.filescompost[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciCompost");
      this.spinner.show()
      this.ls.saveFarmercompost(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filescompost = []
          this.imgscompost = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }



  inorganics() {
    if (this.filesinorganic.length === null || this.filesinorganic.length === undefined || this.filesinorganic.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filesinorganic = []
      this.imgsinorganic = false
      this.fileUploader7.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filesinorganic.length; i++) {
        formData.append("sampleinorganic", this.filesinorganic[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciInorganic");
      this.spinner.show()
      this.ls.saveFarmerinorganic(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesinorganic = []
          this.imgsinorganic = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }


  organics() {
    if (this.filesorganics.length === null || this.filesorganics.length === undefined || this.filesorganics.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filesorganics = []
      this.imgsorganic = false
      this.fileUploader8.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filesorganics.length; i++) {
        formData.append("sampleorganic", this.filesorganics[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciOrganic");
      this.spinner.show()
      this.ls.saveFarmerorganic(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesorganics = []
          this.imgsorganic = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }


  machine() {
    if (this.filesmachine.length === null || this.filesmachine.length === undefined || this.filesmachine.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filesmachine = []
      this.imgsmachine = false
      this.fileUploader9.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filesmachine.length; i++) {
        formData.append("sampleMachinery", this.filesmachine[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciMachinery");
      this.spinner.show()
      this.ls.saveFarmermachine(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesmachine = []
          this.imgsmachine = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }


  traning() {
    if (this.filestraning.length === null || this.filestraning.length === undefined || this.filestraning.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.filestraning = []
      this.sampletraining = false
      this.fileUploader10.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.filestraning.length; i++) {
        formData.append("sampletraining", this.filestraning[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciTraning");
      this.spinner.show()
      this.ls.saveFarmertraning(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filestraning = []
          this.sampletraining = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }


  water() {
    if (this.fileswater.length === null || this.fileswater.length === undefined || this.fileswater.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
      this.fileswater = []
      this.imgswater = false
      this.fileUploader6.nativeElement.value = null;
    }
    else {
      var formData = new FormData();
      for (var i = 0; i < this.fileswater.length; i++) {
        formData.append("samplewater", this.fileswater[i])
      }
      formData.append('FarmerID', this.checkobj.ID);
      formData.append('Activity', "QciWater");
      this.spinner.show()
      this.ls.saveFarmerwater(this.checkobj.ID, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.fileswater = []
          this.imgswater = true
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'You Can Upload Only 10',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }

  seed() {
    if (this.filesseed.length === null || this.filesseed.length === undefined || this.filesseed.length === 0) {
      Swal.fire({
        position: 'center',
        type: 'info',
        title: 'Please Select image',
        showConfirmButton: false,
        timer: 1500
      });
    }

    else {
      var formData = new FormData();
      for (var i = 0; i < this.filesseed.length; i++) {
        formData.append("sampleseed", this.filesseed[i])
      }
      formData.append('FarmerID', this.checksobj);
      formData.append('Activity', "QciSeed");
      this.spinner.show()
      this.ls.saveFarmerseed(this.checksobj, formData).subscribe(res => {
        this.spinner.hide()
        if (res['data'] === "Successfully uploaded images") {
          this.toastr.success("Successfully uploaded");
          this.filesseed = []
        }
        else if (res['data'] === 'something gone wrong') {
          Swal.fire({
            position: 'center',
            type: 'warning',
            title: 'Error In Uploading',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
    }
  }

}
