import { Component, ViewChild } from "@angular/core";
import { Irrigation } from "./irrigation";
import {
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import { ReplaySubject, Subject } from "rxjs";
import {
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";
import { Landlayout } from '../../FarmerData/landlayout/landlayout';

@Component({
  selector: "app-irrigation",
  templateUrl: "./irrigation.component.html",
  styleUrls: ["./irrigation.component.scss"]
})
export class IrrigationComponent {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "IrrigationName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public LandNameFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredLandName: ReplaySubject<Landlayout[]> = new ReplaySubject<
    Landlayout[]
  >(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  irrigationdata = "Irrigation Data";
  edittype = "add_circle";
  displayddl: string;
  editIrrigation = true;
  updateirrigation = false;
  viewIrrigationData = false;
  landData: Landlayout[] = [];
  userirrigationData: any = [];
  EditIrrigation: any = [];
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;

  IrrigationData = this.formBuilder.group({
    IrrigationName: ["", [Validators.required]],
    Source_Type: ["", [Validators.required]],
    Net_Area_Irrigated: ["", [Validators.pattern("^[0-9]+$")]],
    Area_Irrigated_More_Than_Once: ["", [Validators.pattern("^[0-9]+$")]],
    Gross_Area_Irrigated: ["", [Validators.pattern("^[0-9]+$")]],
    Number_Of_Irrigation: ["", [Validators.pattern("^[0-9]+$")]],
    Method_Of_Irrigation: ["", [Validators.required]],
    No_of_Tube_Borewell: ["", [Validators.pattern("^[0-9]+$")]],
    Tube_Borewell_Area: ["", [Validators.pattern("^[0-9]+$")]],
    No_Of_Lift: ["", [Validators.pattern("^[0-9]+$")]],
    Lift_Area: ["", [Validators.pattern("^[0-9]+$")]],
    No_of_Tanks: ["", [Validators.pattern("^[0-9]+$")]],
    Tank_Area: ["", [Validators.pattern("^[0-9]+$")]],
    No_Of_Openwells: ["", [Validators.pattern("^[0-9]+$")]],
    No_Of_Ponds: ["", [Validators.pattern("^[0-9]+$")]],
    Irrigated_Area: ["", [Validators.pattern("^[0-9]+$")]],
    Irrigation_Method: [""],
    Irrigation_System: [""],
    Area_Coverage_In_A_Year: ["", [Validators.pattern("^[0-9]+$")]],
    TblLand_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  constructor(private formBuilder: FormBuilder, private ls: MastersService) { }

  AddIrrigation() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredLandName.next(this.landData.slice());
    this.IrrigationData.reset();
    this.irrigationdata =
      this.irrigationdata === "Irrigation Data"
        ? "Add Irrigation Data"
        : "Irrigation Data";
    this.editIrrigation = !this.editIrrigation;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editIrrigation ? "inline" : "none";
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnInit() {
    this.displayIrrigation();

    this.ls.getlandlayoutData().subscribe(res => {
      this.landData = res;
      ////console.log(this.landData);
    });
    this.LandNameFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterLandname();
      });
  }
  /*land data*/
  protected filterLandname() {
    ////console.log("land", this.landData);
    if (!this.landData) {
      return;
    }
    // get the search keyword
    let search = this.LandNameFilterCtrl.value;
    ////console.log(this.LandNameFilterCtrl.value);

    if (!search) {
      this.filteredLandName.next(this.landData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredLandName.next(
      this.landData.filter(
        bank => bank.LandName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*land data ends*/

  displayIrrigation() {
    this.ls.getIrrigationData().subscribe(list => {
      this.isLoading = false;
      this.userirrigationData = list;
      ////console.log(this.userirrigationData);
      if (this.userirrigationData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      ////console.log(this.userirrigationData);
      this.listData = new MatTableDataSource(this.userirrigationData);
      /* config filter */
      this.listData.filterPredicate = (data: Irrigation, filter: string) =>
        data.IrrigationName.toLowerCase().indexOf(filter) !== -1;
      //
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    ////console.log("form reset");
    this.IrrigationData.reset();
  }

  CreateIrrigationData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.IrrigationData.valid) {
      Object.keys(this.IrrigationData.controls).forEach(field => {
        const control = this.IrrigationData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.IrrigationData.controls.created_by.patchValue(1);
      this.ls.saveIrrigationdata(this.IrrigationData.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the IrrigationData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayIrrigation();
            this.AddIrrigation();
          } else if ((res["data"] = "IrrigationData already exists!")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The IrrigationData",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateIrridationdata(getirrigationDataObj) {
    this.EditIrrigation = getirrigationDataObj;
    this.updateirrigation = !this.updateirrigation;
    this.displayddl = !this.updateirrigation ? "inline" : "none";
    this.IrrigationData.controls.modified_by.patchValue(1);
    this.IrrigationData.setValue({
      IrrigationName: this.EditIrrigation.IrrigationName,
      Source_Type: this.EditIrrigation.Source_Type,
      Net_Area_Irrigated: this.EditIrrigation.Net_Area_Irrigated,
      Area_Irrigated_More_Than_Once: this.EditIrrigation
        .Area_Irrigated_More_Than_Once,
      Gross_Area_Irrigated: this.EditIrrigation.Gross_Area_Irrigated,
      Number_Of_Irrigation: this.EditIrrigation.Number_Of_Irrigation,
      Method_Of_Irrigation: this.EditIrrigation.Method_Of_Irrigation,
      No_of_Tube_Borewell: this.EditIrrigation.No_of_Tube_Borewell,
      Tube_Borewell_Area: this.EditIrrigation.Tube_Borewell_Area,
      No_Of_Lift: this.EditIrrigation.No_Of_Lift,
      Lift_Area: this.EditIrrigation.Lift_Area,
      No_of_Tanks: this.EditIrrigation.No_of_Tanks,
      Tank_Area: this.EditIrrigation.Tank_Area,
      No_Of_Openwells: this.EditIrrigation.No_Of_Openwells,
      No_Of_Ponds: this.EditIrrigation.No_Of_Ponds,
      Irrigated_Area: this.EditIrrigation.Irrigated_Area,
      Irrigation_Method: this.EditIrrigation.Irrigation_Method,
      Irrigation_System: this.EditIrrigation.Irrigation_System,
      Area_Coverage_In_A_Year: this.EditIrrigation.Area_Coverage_In_A_Year,
      TblLand_ID: this.EditIrrigation.TblLand_ID,
      created_by: this.EditIrrigation.created_by,
      modified_by: this.EditIrrigation.modified_by
    });
  }

  toggleUpdateirrigationdata2() {
    this.updateirrigation = false;
    this.displayddl = this.EditIrrigation ? "inline" : "block";
  }

  UpdateIrrigationData() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.IrrigationData.valid) {
      Object.keys(this.IrrigationData.controls).forEach(field => {
        const control = this.IrrigationData.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.IrrigationData.controls.modified_by.patchValue(1);
      this.ls
        .updateIrrigationDataById(
          this.EditIrrigation.ID,
          this.IrrigationData.value
        )
        .subscribe(
          res => {
            if (
              this.EditIrrigation.TblLand_ID ===
              this.IrrigationData.controls.TblLand_ID.value &&
              this.EditIrrigation.IrrigationName ===
              this.IrrigationData.controls.IrrigationName.value &&
              this.EditIrrigation.Source_Type ===
              this.IrrigationData.controls.Source_Type.value &&
              this.EditIrrigation.Net_Area_Irrigated ===
              this.IrrigationData.controls.Net_Area_Irrigated.value &&
              this.EditIrrigation.Area_Irrigated_More_Than_Once ===
              this.IrrigationData.controls.Area_Irrigated_More_Than_Once
                .value &&
              this.EditIrrigation.Gross_Area_Irrigated ===
              this.IrrigationData.controls.Gross_Area_Irrigated.value &&
              this.EditIrrigation.Number_Of_Irrigation ===
              this.IrrigationData.controls.Number_Of_Irrigation.value &&
              this.EditIrrigation.Method_Of_Irrigation ===
              this.IrrigationData.controls.Method_Of_Irrigation.value &&
              this.EditIrrigation.No_of_Tube_Borewell ===
              this.IrrigationData.controls.No_of_Tube_Borewell.value &&
              this.EditIrrigation.Tube_Borewell_Area ===
              this.IrrigationData.controls.Tube_Borewell_Area.value &&
              this.EditIrrigation.No_Of_Lift ===
              this.IrrigationData.controls.No_Of_Lift.value &&
              this.EditIrrigation.Lift_Area ===
              this.IrrigationData.controls.Lift_Area.value &&
              this.EditIrrigation.No_of_Tanks ===
              this.IrrigationData.controls.No_of_Tanks.value &&
              this.EditIrrigation.Tank_Area ===
              this.IrrigationData.controls.Tank_Area.value &&
              this.EditIrrigation.No_Of_Openwells ===
              this.IrrigationData.controls.No_Of_Openwells.value &&
              this.EditIrrigation.No_Of_Ponds ===
              this.IrrigationData.controls.No_Of_Ponds.value &&
              this.EditIrrigation.Irrigated_Area ===
              this.IrrigationData.controls.Irrigated_Area.value &&
              this.EditIrrigation.Irrigation_Method ===
              this.IrrigationData.controls.Irrigation_Method.value &&
              this.EditIrrigation.Irrigation_System ===
              this.IrrigationData.controls.Irrigation_System.value &&
              this.EditIrrigation.Area_Coverage_In_A_Year ===
              this.IrrigationData.controls.Area_Coverage_In_A_Year.value
            ) {
              ////console.log("no update");
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Success") {
              ////console.log("update");
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayIrrigation();
              this.toggleUpdateirrigationdata2();
            }
          },

        );
    }
  }

  deleteIrridationdata(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteIrrigationDataById(id).subscribe(res => {
          if ((res["data"] = "success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayIrrigation();
          }
        });
      }
    });
  }

  toggleViewIrridationdata(getirrigationDataObj) {
    ////console.log(getirrigationDataObj);
    this.viewIrrigationData = !this.viewIrrigationData;
    this.EditIrrigation = getirrigationDataObj;
    this.displayddl = !this.EditIrrigation ? "inline" : "none";
  }
  toggleViewIrrigation1() {
    this.viewIrrigationData = false;
    this.displayddl = !this.EditIrrigation ? "inline" : "block";
  }
}
