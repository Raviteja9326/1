export interface Irrigation {
    ID?: number;
    IrrigationName?: any;
    Source_Type?: any;
    Net_Area_Irrigated?: any;
    Area_Irrigated_More_Than_Once?: any;
    Gross_Area_Irrigated?: any;
    Number_Of_Irrigation?: any;
    Method_Of_Irrigation?: any;
    No_of_Tube_Borewell?: any;
    Tube_Borewell_Area?: any;
    No_Of_Lift?: any;
    Lift_Area?: any;
    No_of_Tanks?: any;
    Tank_Area?: any;
    No_Of_Openwells?: any;
    No_Of_Ponds?: any;
    Irrigated_Area?: any;
    Irrigation_Method?: any;
    Irrigation_System?: any;
    Area_Coverage_In_A_Year?: any;
    TblLand_ID?: number;
    created_by: string;
    modified_by: string;
}
