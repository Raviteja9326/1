
export interface Plotting {
    ID?: number;
    PlotingName?: string;
    PlottingPurpose?: string;
    PlottingArea?: any;
    PlottingDirection?: string;
    TblLand_ID?: number;
}
