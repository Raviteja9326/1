import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { Validators, FormBuilder } from "@angular/forms";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";
import { Plotting } from "./plotting";
import Swal from "sweetalert2";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-plotting",
  templateUrl: "./plotting.component.html",
  styleUrls: ["./plotting.component.scss"]
})
export class PlottingComponent implements OnInit {
  listData: MatTableDataSource<any>;
  // tslint:disable-next-line: max-line-length
  displayedColumns: string[] = [
    "S.No",
    "TblLand_ID",
    "PlotingName",
    "PlottingPurpose",
    "PlottingArea",
    "PlottingDirection",
    "Actions"
  ];
  editLand = true;
  editLandContent = "add_circle";
  LandNames = "Plotting List";
  userLandData: any = [];
  displayddl: string;
  updateLand = false;
  viewLand = false;
  editfarm: any = [];
  userSoilTypeData: any = [];
  EditLandlay: any = [];
  EditOldLand: any = [];
  editViewLand: any = [];
  isLoading = true;
  secretKey: string;
  displayNoRecords = false;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  LandForm = this.formBuilder.group({
    TblLand_ID: ["", [Validators.required]],
    PlotingName: ["", [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
    PlottingPurpose: [
      "",
      [Validators.required, Validators.pattern("^[a-zA-Z]+$")]
    ],
    PlottingArea: [""],
    PlottingDirection: [
      "",
      [Validators.required, Validators.pattern("^[a-zA-Z\\s]+$")]
    ]
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  constructor(
    private http: HttpClient,
    private formBuilder: FormBuilder,
    private ds: MastersService
  ) { }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }

  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    if (this.LandForm.valid) {
      this.LandForm.reset();
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    }
  }

  ngOnInit() {
    this.displayLand();
    this.ds.getlandlayoutData().subscribe(res => {
      this.editfarm = res;
    });
  }

  displayLand() {
    this.ds.getplottingData().subscribe(
      list => {
        this.isLoading = false;
        this.userLandData = list;
        if (list.length === 0) {
          this.displayNoRecords = true;
        } else {
          this.displayNoRecords = false;
        }
        this.listData = new MatTableDataSource(this.userLandData);
        // tslint:disable-next-line: max-line-length
        this.listData.filterPredicate = (data: Plotting, filter: string) =>
          data.PlotingName.toLowerCase().indexOf(filter) !== -1;
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      },
      err => console.error(err)
    );
  }

  toggleEditLand() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.displayLand();
    this.LandForm.reset();
    this.LandNames =
      this.LandNames === "Add plotting" ? "Plotting List" : "Add Plotting";
    this.editLandContent =
      this.editLandContent === "cancel" ? "add_circle" : "cancel";
    this.editLand = !this.editLand;
    this.displayddl = this.editLand ? "inline" : "none";
  }

  toggleUpdateLand(getLandDataObj) {
    this.EditLandlay = getLandDataObj;
    this.updateLand = !this.updateLand;
    this.displayddl = !this.editLand ? "inline" : "none";
    this.LandForm.setValue({
      PlotingName: this.EditLandlay.PlotingName,
      PlottingPurpose: this.EditLandlay.PlottingPurpose,
      PlottingArea: this.EditLandlay.PlottingArea,
      PlottingDirection: this.EditLandlay.PlottingDirection,
      TblLand_ID: this.EditLandlay.TblLand_ID
    });
  }

  toggleUpdateLand2() {
    this.updateLand = false;
    this.displayddl = this.editLand ? "inline" : "block";
  }

  toggleViewLand(getLandDataObj) {
    this.editViewLand = getLandDataObj;
    this.viewLand = !this.viewLand;
    this.displayddl = !this.editLand ? "inline" : "none";
  }

  toggleViewLand2() {
    this.viewLand = false;
    this.displayddl = !this.editLand ? "inline" : "block";
  }

  createLand(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.LandForm.valid) {
      Object.keys(this.LandForm.controls).forEach(field => {
        const control = this.LandForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ds.saveplottingData(this.LandForm.value).subscribe(
        res => {

          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the plotting",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayLand();
            this.toggleEditLand();
          }
        },
        err => console.error(err)
      );
    }
  }

  deleteLand(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text:
        "You won't be able to revert this back and all Inter-linking Connections will be Deleted!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ds.deleteplottingDataDataById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayLand();
          }
        });
      }
    });
  }

  updateLandLayout(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.EditLandlay = data;
    if (!this.LandForm.valid) {
      Object.keys(this.LandForm.controls).forEach(field => {
        const control = this.LandForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Mandatory Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.ds
        .updateplottingDataDataById(this.EditLandlay.ID, this.LandForm.value)
        .subscribe(
          res => {
            // tslint:disable-next-line:max-line-length
            // if (this.Editfarm.FarmerName === this.FarmerForm.controls.FarmerName.value  && this.Editfarm.MobileNumber === this.FarmerForm.controls.MobileNumber.value) {
            //   ////console.log("no update");
            //   Swal.fire({
            //     position: 'center',
            //     type: 'info',
            //     title: 'No update Found',
            //     showConfirmButton: false,
            //     timer: 1500
            //   })
            //   this.barButtonOptions.active = false;
            //   this.barButtonOptions.text = 'SUBMIT';
            // } else
            if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayLand();
              this.toggleUpdateLand2();
            }
          },

        );
    }
  }
}
