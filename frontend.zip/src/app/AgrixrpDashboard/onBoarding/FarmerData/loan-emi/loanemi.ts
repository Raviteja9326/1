export interface LoanEMI {
    ID:number;
    ReceiptNo?:any;
    Amount?:any;
    EMIDate?:any;
    ReceivedBy?:any;
    EMINo?:any;
    PaymentType?:any;
    CheckNo?:any;
    Signedby?:any;
    Witness?:any;
    GeneralLedgeID?:any;
    TblLoan_ID?:any;
    created_by?:any;
    modified_by?:any;

}
