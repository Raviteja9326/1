import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanEMIComponent } from './loan-emi.component';

describe('LoanEMIComponent', () => {
  let component: LoanEMIComponent;
  let fixture: ComponentFixture<LoanEMIComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoanEMIComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanEMIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
