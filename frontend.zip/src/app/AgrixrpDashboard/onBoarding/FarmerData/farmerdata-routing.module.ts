import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FarmerDataComponent } from './farmerdata.component';
import { LabourinformationComponent } from './labourinformation/labourinformation.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
import { CroplanesComponent } from './croplanes/croplanes.component';
import { LandlayoutComponent } from './landlayout/landlayout.component';
import { LoanEMIComponent } from './loan-emi/loan-emi.component';
import { LoanhistoryComponent } from './loanhistory/loanhistory.component';
import { PlottingComponent } from './plotting/plotting.component';
import { IrrigationComponent } from './irrigation/irrigation.component';
import { CopworkflowComponent } from './copworkflow/copworkflow.component';
import { CheckcopworkflowComponent } from './checkcopworkflow/checkcopworkflow.component';
import { CheckBomComponent } from './check-bom/check-bom.component';
import { InsuranceComponent } from './insurance/insurance.component';
import { FarmercheckComponent } from './farmerchecklist/farmerchecklist.component';
import { FarmerinfoComponent } from './farmerinfo/farmerinfo.component';
const routes: Routes = [{
    path: '',
    component: FarmerDataComponent,
    children: [
        {
            path: 'Farmer Information',
            component: FarmerinfoComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Farmer Checklist',
            component: FarmercheckComponent, canActivate: [AuthGuardService]
        },

        {
            path: 'Labour Information',
            component: LabourinformationComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Crop Lanes',
            component: CroplanesComponent, canActivate: [AuthGuardService]
        },

        {
            path: 'Land Layout',
            component: LandlayoutComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Loan EMI',
            component: LoanEMIComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Loan Information',
            component: LoanhistoryComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Plotting',
            component: PlottingComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Irrigation',
            component: IrrigationComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Crop COP Workflow',
            component: CopworkflowComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Check Crop COP Workflow ',
            component: CheckcopworkflowComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Check BOM',
            component: CheckBomComponent, canActivate: [AuthGuardService]
        },
        {
            path: 'Insurance',
            component: InsuranceComponent, canActivate: [AuthGuardService]
        },
    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class FarmerdataRoutingModule { }

