export interface RawMaterialStockData {
    ID?: number;
    Quantity?: string;
    ByProduct?: string;
    ByProductID?: string;
    TblFarmer_ID?: string;
    TblUnits_ID?: string;
    TblLocation_ID?: string;
    TblMaterials_ID?: string;
    TblMatCategory_ID?: string;
    created_by: string;
    modified_by: string;
}
