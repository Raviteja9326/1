import { Component, OnInit, ViewChild } from "@angular/core";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatSelect
} from "@angular/material";
import { ReplaySubject, Subject } from "rxjs";
import {
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import { Units, MaterialName, MaterialCategory } from "app/services/Dataservices";
import { location } from "app/services/Dataservices";
import { takeUntil } from "rxjs/operators";
import Swal from "sweetalert2";
import { MatProgressButtonOptions } from "mat-progress-buttons";
import { MastersService } from "app/services/masters.service";
import { Farmer } from '../../FarmerData/farmerinfo/farmerinfo';

@Component({
  selector: "app-rawmaterialstock",
  templateUrl: "./rawmaterialstock.component.html",
  styleUrls: ["./rawmaterialstock.component.scss"]
})
export class RawmaterialstockComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["ID", "FarmerName", "MatCatName", "Actions"];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  /** control for the MatSelect filter keyword */
  public UnitFilterCtrl: FormControl = new FormControl();
  public FarmerFilterCtrl: FormControl = new FormControl();
  public LocationFilterCtrl: FormControl = new FormControl();
  public MaterialTypeFilterCtrl: FormControl = new FormControl();
  public MaterialCategoryFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredUnit: ReplaySubject<Units[]> = new ReplaySubject<Units[]>(1);
  public filteredFarmer: ReplaySubject<Farmer[]> = new ReplaySubject<Farmer[]>(
    1
  );
  public filteredLocation: ReplaySubject<location[]> = new ReplaySubject<
    location[]
  >(1);
  public filteredMaterialType: ReplaySubject<
    MaterialName[]
  > = new ReplaySubject<MaterialName[]>(1);
  public filteredMaterialCategory: ReplaySubject<
    MaterialCategory[]
  > = new ReplaySubject<MaterialCategory[]>(1);

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */

  protected _onDestroy = new Subject<void>();

  status = ["Yes", "No"];

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };

  rawmaterialtypes = "Raw Material Stock";
  edittype = "add_circle";
  displayddl: string;
  editrawmaterialstock = true;
  updaterawmaterialstock = false;
  ViewRawMaterialStock = false;
  secretKey: string;
  isLoading = true;
  displayNoRecords = false;
  getfarmerdatalist: any = [];
  UnitsData: Units[] = [];
  FarmerData: Farmer[] = [];
  LocationData: location[] = [];
  MaterialNameData: MaterialName[] = [];
  matCatNames: MaterialCategory[] = [];
  editStock: any;

  RawMaterial = this.formBuilder.group({
    Quantity: [
      "",
      [Validators.required, Validators.pattern("^-?[0-9]\\d*(\\.\\d{1,2})?$")]
    ],
    ByProduct: [""],
    ByProductID: ["", [, Validators.pattern("^[0-9]*$")]],
    TblFarmer_ID: ["", [Validators.required]],
    TblUnits_ID: ["", [Validators.required]],
    TblLocation_ID: ["", [Validators.required]],
    TblMaterials_ID: ["", [Validators.required]],
    TblMatCategory_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  constructor(private formBuilder: FormBuilder, private ls: MastersService) { }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  ngOnInit() {
    this.displayRawMaterialsfarmerdata();
    // for units
    this.ls.getunitsdata().subscribe(res => {
      this.UnitsData = res;
    });

    // listen for search field value changes
    this.UnitFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterUnits();
      });
    // unit end

    // for farmer
    this.ls.getFarmerdata().subscribe(res => {
      this.FarmerData = res;
    });

    // listen for search field value changes
    this.FarmerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFarmer();
      });
    // farmer end

    // for location data
    this.ls.getlocationdata().subscribe(res => {
      this.LocationData = res;
    });

    // listen for search field value changes
    this.LocationFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterLocation();
      });
    // locastion end

    // for materialtype
    this.ls.getMaterialType().subscribe(res => {
      this.MaterialNameData = res
    });

    // listen for search field value changes
    this.MaterialTypeFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterMaterialType();
      });
    // materialtype end

    // material category
    this.MaterialCategoryFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterMaterialCategory();
      });
    // matcat end
  }

  /*units data*/
  protected filterUnits() {
    if (!this.UnitsData) {
      return;
    }
    // get the search keyword
    let search = this.UnitFilterCtrl.value;

    if (!search) {
      this.filteredUnit.next(this.UnitsData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredUnit.next(
      this.UnitsData.filter(
        bank => bank.Units.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*units data ends*/

  /*location data */
  protected filterLocation() {
    if (!this.LocationData) {
      return;
    }
    // get the search keyword
    let search = this.LocationFilterCtrl.value;

    if (!search) {
      this.filteredLocation.next(this.LocationData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredLocation.next(
      this.LocationData.filter(
        bank => bank.Name.toLowerCase().indexOf(search) > -1
      )
    );
  }

  /*farmer data */
  protected filterFarmer() {
    if (!this.FarmerData) {
      return;
    }
    // get the search keyword
    let search = this.FarmerFilterCtrl.value;

    if (!search) {
      this.filteredFarmer.next(this.FarmerData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredFarmer.next(
      this.FarmerData.filter(
        bank => bank.FarmerName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*farmer data ends*/

  /*materialtype data*/
  protected filterMaterialType() {
    if (!this.MaterialNameData) {
      return;
    }
    // get the search keyword
    let search = this.MaterialTypeFilterCtrl.value;

    if (!search) {
      this.filteredMaterialType.next(this.MaterialNameData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredMaterialType.next(
      this.MaterialNameData.filter(
        bank => bank.MatName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*materialtype ends*/

  /*materialCategory data*/
  protected filterMaterialCategory() {
    if (!this.MaterialNameData) {
      return;
    }
    // get the search keyword
    let search = this.MaterialCategoryFilterCtrl.value;

    if (!search) {
      this.filteredMaterialCategory.next(this.matCatNames.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredMaterialCategory.next(
      this.matCatNames.filter(
        bank => bank.MatCatName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  /*materialCategory ends*/

  displayRawMaterialsfarmerdata() {
    this.ls.getrawmaterialdata().subscribe(list => {
      this.isLoading = false;
      this.getfarmerdatalist = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.getfarmerdatalist);
      /* config filter */
      this.listData.filterPredicate = (data: Farmer, filter: string) =>
        data.FarmerName.indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  resetForm() {
    this.resetdrop(event);
    if (this.RawMaterial.valid) {
      this.RawMaterial.reset();
    }
  }

  AddRawMaterialStock() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.filteredUnit.next(this.UnitsData.slice());
    this.filteredFarmer.next(this.FarmerData.slice());
    this.filteredLocation.next(this.LocationData.slice());
    this.filteredMaterialType.next(this.MaterialNameData.slice());
    this.resetdrop(event);
    this.RawMaterial.reset();
    this.displayRawMaterialsfarmerdata();
    this.rawmaterialtypes =
      this.rawmaterialtypes === "Raw Material Stock"
        ? "Add Raw Material Stock"
        : "Raw Material Stock";
    this.editrawmaterialstock = !this.editrawmaterialstock;
    this.edittype = this.edittype === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editrawmaterialstock ? "inline" : "none";
  }

  resetdrop(event) {
    this.filteredMaterialCategory.next((this.matCatNames = []));
    this.matCatNames = [];
  }

  onChangeMaterialType(value) {
    this.ls.getMatCatByMatID(value).subscribe(matCat => {
      if (matCat["data"] === "NO Categories Available with this Type ID") {
        Swal.fire({
          position: "center",
          type: "info",
          title: "No MatCat Available",
          showConfirmButton: false,
          timer: 1500
        });
        this.matCatNames = [];
        this.resetdrop(event);
        this.RawMaterial.controls.TblMatCategory_ID.patchValue("");
      } else {
        Swal.fire({
          position: "center",
          type: "info",
          title: "Please Select The Category",
          showConfirmButton: false,
          timer: 1000
        });
        this.matCatNames = matCat;
        this.filteredMaterialCategory.next(this.matCatNames.slice());
      }
    });
  }

  CreateRawMaterialStock() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.RawMaterial.valid) {
      Object.keys(this.RawMaterial.controls).forEach(field => {
        const control = this.RawMaterial.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.RawMaterial.controls.created_by.patchValue(0);
      this.ls.saveRawMaterialStock(this.RawMaterial.value).subscribe(
        res => {


          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Stock",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displayRawMaterialsfarmerdata();
            this.AddRawMaterialStock();
          } else if ((res["data"] = "Stock already exists!")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Stock",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateRawMaterialStock(getRawMaterialStockDataObj) {
    this.editStock = getRawMaterialStockDataObj;
    this.updaterawmaterialstock = !this.updaterawmaterialstock;
    this.displayddl = !this.editrawmaterialstock ? "inline" : "none";
    this.RawMaterial.controls.modified_by.patchValue(0);
    this.ls.getMatCatByMatID(this.editStock.TblMaterials_ID).subscribe(res => {
      this.matCatNames = res;
    });
    this.RawMaterial.setValue({
      Quantity: this.editStock.Quantity,
      ByProduct: this.editStock.ByProduct,
      ByProductID: this.editStock.ByProductID,
      TblFarmer_ID: this.editStock.TblFarmer_ID,
      TblUnits_ID: this.editStock.TblUnits_ID,
      TblLocation_ID: this.editStock.TblLocation_ID,
      TblMaterials_ID: this.editStock.TblMaterials_ID,
      TblMatCategory_ID: this.editStock.TblMatCategory_ID,
      created_by: this.editStock.created_by,
      modified_by: this.editStock.modified_by
    });
  }

  toggleUpdateRawMaterialStock2() {
    this.updaterawmaterialstock = false;
    this.displayddl = this.editrawmaterialstock ? "inline" : "block";
  }

  updateRawMaterialStock(data) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    this.editStock = data;
    if (!this.RawMaterial.valid) {
      Object.keys(this.RawMaterial.controls).forEach(field => {
        const control = this.RawMaterial.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.RawMaterial.controls.modified_by.patchValue(0);
      this.ls
        .updateRawMaterialStockById(this.editStock.ID, this.RawMaterial.value)
        .subscribe(
          res => {
            if (
              this.editStock.Quantity ===
              this.RawMaterial.controls.Quantity.value &&
              this.editStock.ByProduct ===
              this.RawMaterial.controls.ByProduct.value &&
              this.editStock.ByProductID ===
              this.RawMaterial.controls.ByProductID.value &&
              this.editStock.TblFarmer_ID ===
              this.RawMaterial.controls.TblFarmer_ID.value &&
              this.editStock.TblUnits_ID ===
              this.RawMaterial.controls.TblUnits_ID.value &&
              this.editStock.TblLocation_ID ===
              this.RawMaterial.controls.TblLocation_ID.value &&
              this.editStock.TblMaterials_ID ===
              this.RawMaterial.controls.TblMaterials_ID.value &&
              this.editStock.TblMatCategory_ID ===
              this.RawMaterial.controls.TblMatCategory_ID.value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (res["data"] === "Success") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displayRawMaterialsfarmerdata();
              this.toggleUpdateRawMaterialStock2();
            }
          },

        );
    }
  }

  deleteRawMaterialStock(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it AnyWay!",
      confirmButtonClass: "btn btn-primary",
      cancelButtonClass: "btn btn-danger"
    }).then(result => {
      if (result.value) {
        this.ls.deleteRawMaterialStockById(id).subscribe(res => {
          if ((res["data"] = "Successfully Deleted")) {
            Swal.fire({
              title: "Deleted!",
              text: "Your Record has been deleted.",
              type: "success",
              confirmButtonClass: "btn btn-success"
            });
            this.displayRawMaterialsfarmerdata();
          }
        });
      }
    });
  }

  toggleViewRawMaterialStock(getRawMaterialStockDataObj) {
    this.ViewRawMaterialStock = !this.ViewRawMaterialStock;
    this.editStock = getRawMaterialStockDataObj;
    this.displayddl = !this.editrawmaterialstock ? "inline" : "none";
  }

  toggleViewRawMaterialStock1() {
    this.ViewRawMaterialStock = false;
    this.displayddl = !this.editrawmaterialstock ? "inline" : "block";
  }
}
