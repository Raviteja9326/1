import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RawmaterialstockComponent } from './rawmaterialstock.component';

describe('RawmaterialstockComponent', () => {
  let component: RawmaterialstockComponent;
  let fixture: ComponentFixture<RawmaterialstockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RawmaterialstockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RawmaterialstockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
