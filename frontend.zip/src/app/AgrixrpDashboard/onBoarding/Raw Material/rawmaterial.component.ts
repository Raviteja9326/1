import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-rawmaterial",
  template: `
    <router-outlet></router-outlet>
  `
})
export class RawmaterialComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
