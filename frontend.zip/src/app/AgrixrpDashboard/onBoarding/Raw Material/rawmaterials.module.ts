import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { DealersinformationComponent } from './dealersinformation/dealersinformation.component';
import { MatTableExporterModule } from 'mat-table-exporter';
import { HttpClientModule } from '@angular/common/http';
import { NgxMatSelectSearchModule } from 'app/AgrixrpDashboard/maincomponents/mat-select-search/public_api';
import { RawmaterialsRoutingModule } from './rawmaterials-routing.module';
import { RawmaterialComponent } from './rawmaterial.component';
import { RawmaterialstockComponent } from './rawmaterialstock/rawmaterialstock.component';
import { InventoryComponent } from './inventory/inventory.component';
import { BillofmaterialsComponent } from './billofmaterials/billofmaterials.component';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';


const components = [RawmaterialComponent, DealersinformationComponent, RawmaterialstockComponent, InventoryComponent, BillofmaterialsComponent]

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [RawmaterialsRoutingModule, CommonModule, MatTableExporterModule, RouterModule, FormsModule, ReactiveFormsModule, HttpClientModule, MaterialModule, NgxMatSelectSearchModule],
    declarations: [
        ...components,
    ],
})
export class RawmaterialModule { }
