export interface Inventory{
    ID?:number;
    InventoryDate?:any;
    SalesOrderID?:any;
    ReceivedBy?:any;
    ReceivedDate?:any;
    TblStock_ID?:any;
    created_by:string;
    modified_by:string;

}
export interface Stock{
    MatCatName?:any;
}