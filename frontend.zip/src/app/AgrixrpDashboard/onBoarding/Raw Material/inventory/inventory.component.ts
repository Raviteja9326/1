import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from "@angular/core";
import { MastersService } from "app/services/masters.service";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import Swal from "sweetalert2";
import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { FormBuilder, Validators, FormControl } from "@angular/forms";
import { Observable, ReplaySubject, Subject } from "rxjs";
import { Stock, Inventory } from "./inventory";
import {
  MatTableDataSource,
  MatSort,
  MatPaginator,
  MatSelect
} from "@angular/material";
import { MatProgressButtonOptions } from 'mat-progress-buttons';
@Component({
  selector: "app-inventory",
  templateUrl: "./inventory.component.html",
  styleUrls: ["./inventory.component.scss"]
})
export class InventoryComponent implements OnInit {
  Inventorytype = "Inventory";
  editInventorycontent = "add_circle";
  displayddl: string;
  editInventory = true;
  userInventoryData: any = [];
  EditInventory: any = [];
  updateInventory = false;
  viewInventory = false;

  supplierdata: any = [];

  inventorydata: any[];
  getstockData: Stock[] = [];
  CounFilterCtrl: Observable<any[]>;
  /** control for the MatSelect filter keyword */
  displayNoRecords = false;
  isLoading = true;
  secretKey: string;
  isMobile: any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ["S.No", "MatCatName", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();
  /** control for the MatSelect filter keyword */
  public InventoryFilterCtrl: FormControl = new FormControl();
  /** list of banks filtered by search keyword */
  public InventoryCoun: ReplaySubject<Stock[]> = new ReplaySubject<Stock[]>(1);
  Inventory = this.formBuilder.group({
    InventoryDate: ["", [Validators.required]],
    SalesOrderID: ["", [Validators.required]],
    ReceivedBy: [""],
    ReceivedDate: [""],
    TblStock_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });

  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'SUBMIT',
    buttonColor: 'accent',
    barColor: 'primary',
    raised: true,
    mode: 'indeterminate',
    value: 0,
    customClass: 'btn btn-success',
  }

  constructor(
    private ls: MastersService,
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder
  ) { }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm() {
    if (this.Inventory.valid) {
      this.Inventory.reset();
    }
  }
  ngOnInit() {
    this.displayinventory();

    this.ls.getStockData().subscribe(res => {
      this.getstockData = res;
    });
    // listen for search field value changes
    this.InventoryFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterInventory();
      });
  }

  protected filterInventory() {
    if (!this.getstockData) {
      return;
    }
    // get the search keyword
    let search = this.InventoryFilterCtrl.value;
    if (!search) {
      this.InventoryCoun.next(this.getstockData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.InventoryCoun.next(
      this.getstockData.filter(
        bank => bank.MatCatName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }
  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  displayinventory() {
    this.ls.getinventory().subscribe(list => {
      this.isLoading = false;
      this.userInventoryData = list;
      if (list.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userInventoryData);
      this.listData.filterPredicate = (data: Stock, filter: string) =>
        data.MatCatName.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  AddInventory() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = 'SUBMIT';
    this.InventoryCoun.next(this.getstockData.slice());
    this.Inventory.reset();
    this.Inventorytype =
      this.Inventorytype === "Inventory" ? "Add Inventory Data" : "Inventory";
    this.editInventory = !this.editInventory;
    this.editInventorycontent =
      this.editInventorycontent === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editInventory ? "inline" : "none";
    this.displayinventory();
  }

  CreateInventory() {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    if (!this.Inventory.valid) {
      Object.keys(this.Inventory.controls).forEach(field => {
        const control = this.Inventory.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.Inventory.controls.created_by.patchValue(1);
      this.ls.saveinventorydata(this.Inventory.value).subscribe(
        res => {
          if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Inventory",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.Inventory.reset();
            this.displayinventory();
            this.AddInventory();
          } else if ((res["data"] = "Inventory already exists!")) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Inventory",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateInventory(getInventoryDataObj) {
    this.updateInventory = !this.updateInventory;
    this.EditInventory = getInventoryDataObj;
    this.EditInventory.InventoryDate = this.dp.transform(
      this.EditInventory.InventoryDate,
      "yyyy-MM-dd"
    );
    this.EditInventory.ReceivedDate = this.dp.transform(
      this.EditInventory.ReceivedDate,
      "yyyy-MM-dd"
    );
    this.displayddl = !this.editInventory ? "inline" : "none";
    this.Inventory.controls.modified_by.patchValue(0);
    this.Inventory.setValue({
      InventoryDate: this.EditInventory.InventoryDate,
      SalesOrderID: this.EditInventory.SalesOrderID,
      ReceivedBy: this.EditInventory.ReceivedBy,
      ReceivedDate: this.EditInventory.ReceivedDate,
      TblStock_ID: this.EditInventory.TblStock_ID,
      created_by: this.EditInventory.created_by,
      modified_by: this.EditInventory.modified_by
    });
  }

  toggleUpdateInventory2() {
    this.updateInventory = false;
    this.displayddl = this.EditInventory ? "inline" : "block";
  }
  UpdateInventory(res) {
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = 'Please Wait...';
    this.EditInventory = res;
    if (!this.Inventory.valid) {
      Object.keys(this.Inventory.controls).forEach(field => {
        const control = this.Inventory.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = 'SUBMIT';
    } else {
      this.Inventory.controls.modified_by.patchValue(0);
      this.ls.updateinventoryById(this.EditInventory.ID, this.Inventory.value)
        // tslint:disable-next-line:no-shadowed-variable
        .subscribe(res => {
          if (
            this.EditInventory.InventoryDate === this.Inventory.controls.InventoryDate.value &&
            this.EditInventory.SalesOrderID === this.Inventory.controls.SalesOrderID.value &&
            this.EditInventory.ReceivedBy === this.Inventory.controls.ReceivedBy.value &&
            this.EditInventory.ReceivedDate === this.Inventory.controls.ReceivedDate.value &&
            this.EditInventory.TblStock_ID === this.Inventory.controls.TblStock_ID.value
          ) {
            Swal.fire({
              position: "center",
              type: "info",
              title: "No update Found",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
          } else if (res["data"] === "Success") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully Edited",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = 'SUBMIT';
            this.displayinventory();
            this.toggleUpdateInventory2();
          }
        },

        );
    }
  }

  deleteInventory(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it AnyWay!',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn btn-danger'
    }).then(result => {
      if (result.value) {
        this.ls.deleteinventoryById(id).subscribe(res => {
          if ((res["data"] = "Success")) {
            Swal.fire({
              title: 'Deleted!',
              text: 'Your Record has been deleted.',
              type: 'success',
              confirmButtonClass: 'btn btn-success'
            })
            this.displayinventory();
          }
        });
      }
    });
  }

  toggleViewInventory(getInventoryDataObj) {
    this.viewInventory = !this.viewInventory;
    this.EditInventory = getInventoryDataObj;
    this.displayddl = !this.EditInventory ? "inline" : "none";
  }
  toggleViewInventory1() {
    this.viewInventory = false;
    this.displayddl = !this.EditInventory ? "inline" : "block";
  }
}
