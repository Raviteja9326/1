export interface Billofmaterials {
    ID: 0,
    Qty?:number,
    TblUnits_ID?: any,
    UnitCost?: any,
    Cost?: any,
    Tbl_StockParentID?: any,
    Level?: any,
    TblStock_ID:number,
    Created_by?:any  ,
    Modified_by?: any,
}

export interface BOM {
    MatCatName?:any;
}
export interface Units {
    Units?:any
}
