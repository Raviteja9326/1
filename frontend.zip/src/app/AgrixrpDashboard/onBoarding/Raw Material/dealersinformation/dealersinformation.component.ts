import { Component, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { DatePipe } from "@angular/common";
import { Validators, FormBuilder, FormControl } from "@angular/forms";
import { DealerInformation, CompanyMaster } from "./dealerinformation";
import Swal from "sweetalert2";
import {
  startWith,
  debounceTime,
  switchMap,
  map,
  takeUntil
} from "rxjs/operators";
import { Observable, ReplaySubject, Subject } from "rxjs";
import {
  MatSelect,
  MatSort,
  MatPaginator,
  MatTableDataSource
} from "@angular/material";
import { States } from "../../Masters/states/states";
import { Country } from "../../Masters/country/country";
import { MastersService } from "app/services/masters.service";
import { Districts } from "../../Masters/districts/districts";
import { Villages } from "../../Masters/villages/villages";
import { Mandals } from "../../Masters/mandals/mandals";
import { MatProgressButtonOptions } from "mat-progress-buttons";
@Component({
  selector: "app-dealersinformation",
  templateUrl: "./dealersinformation.component.html",
  styleUrls: ["./dealersinformation.component.scss"]
})
export class DealersinformationComponent implements OnInit {
  [x: string]: any;
  // Getter method to access formcontrols
  get myForm() {
    return this.Dealersinformation.controls;
  }
  displayedColumns: string[] = ["S.No", "DealerName", "Actions"];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;

  @ViewChild("singleSelect", { static: true }) singleSelect: MatSelect;

  protected _onDestroy = new Subject<void>();
  listData: any;
  isLoading = true;
  // tslint:disable-next-line:member-ordering
  DealersInformation = "Dealer Information ";
  editDealersInformation = "add_circle";
  displayddl: string;
  editDealersinformation = true;
  userDealerData: any = [];
  EditDealerinformation: any = [];
  updateDealersinformation = false;
  viewDealersInformation = false;
  displayNoRecords = false;
  secretKey: string;
  submitted = false;
  country: {};
  states: {};
  mandal: {};
  village: {};
  districts: {};
  fertilizerdata: any[];
  getstateData: States[] = [];
  getcountryData: Country[] = [];
  getdistrictData: Districts[] = [];
  getmandaldata: Mandals[] = [];
  getvillageData: Villages[] = [];
  getfertilizerData: CompanyMaster[] = [];
  CounFilterCtrl: Observable<any[]>;
  userDealersData: any = [];
  /** control for the MatSelect filter keyword */
  public CountryFilterCtrl: FormControl = new FormControl();
  public StatesFilterCtrl: FormControl = new FormControl();
  public DistrictsFilterCtrl: FormControl = new FormControl();
  public MandalFilterCtrl: FormControl = new FormControl();
  public VillageFilterCtrl: FormControl = new FormControl();
  public FertilizerFilterCtrl: FormControl = new FormControl();
  /** list of banks filtered by search keyword */
  public FilterCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  public StatesCoun: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
  public DistrictCoun: ReplaySubject<Districts[]> = new ReplaySubject<
    Districts[]
  >(1);
  public MandalCoun: ReplaySubject<Mandals[]> = new ReplaySubject<Mandals[]>(1);
  // tslint:disable-next-line:member-ordering
  public VillageCoun: ReplaySubject<Villages[]> = new ReplaySubject<Villages[]>(
    1
  );
  public FertilizerCoun: ReplaySubject<CompanyMaster[]> = new ReplaySubject<
    CompanyMaster[]
  >(1);

  Dealersinformation = this.formBuilder.group({
    DealerName: [
      "",
      [
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern("^[_A-z]+$")
      ]
    ],
    DealerType: ["", [Validators.required]],
    SellsFertilizerType: [""],
    Dealeraddress: [""],
    LicenseStartDate: [""],
    LicenseEndDate: [""],
    TblCountry_ID: ["", [Validators.required]],
    TblState_ID: ["", [Validators.required]],
    TblDistrict_ID: ["", [Validators.required]],
    TblMandal_ID: ["", [Validators.required]],
    TblVillage_ID: ["", [Validators.required]],
    ContactNos: [
      "",
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern("[6-9]\\d{9}")
      ]
    ],
    ContactPersonName: [""],
    Website: [""],
    Email: ["", [Validators.pattern("^[a-zA-Z0-9_.+-]+@+.[a-zA-Z0-9-.]+$")]],
    TblFertilizerCompanyMaster_ID: ["", [Validators.required]],
    created_by: [],
    modified_by: []
  });
  barButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: "SUBMIT",
    buttonColor: "accent",
    barColor: "primary",
    raised: true,
    mode: "indeterminate",
    value: 0,
    customClass: "btn btn-success"
  };
  constructor(
    private http: HttpClient,
    private dp: DatePipe,
    private formBuilder: FormBuilder,
    private ds: MastersService
  ) { }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetdrop(event) {
    this.StatesCoun.next((this.states = []));
    this.DistrictCoun.next((this.districts = []));
    this.MandalCoun.next((this.mandal = []));
    this.VillageCoun.next((this.village = []));
    this.country = [];
    this.states = [];
    this.districts = [];
    this.mandal = [];
    this.village = [];
  }

  resetForm() {
    this.workpls(event);
    if (this.Dealersinformation.valid) {
      this.Dealersinformation.reset();
    }
  }

  ngOnInit() {
    this.displaydealerinformation();

    this.ds.getCountriesData().subscribe(res => {
      this.getcountryData = res;
    });
    this.ds.getfertilizer().subscribe(res => {
      this.getfertilizerData = res;
    });
    // listen for search field value changes

    this.CountryFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCountry();
      });

    this.StatesFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterStates();
      });
    this.DistrictsFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDistrict();
      });
    this.MandalFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filtermandal();
      });
    this.VillageFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterVillage();
      });

    this.FertilizerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFertilizer();
      });
  }

  protected filterCountry() {
    if (!this.getcountryData) {
      return;
    }
    // get the search keyword
    let search = this.CountryFilterCtrl.value;
    if (!search) {
      this.FilterCoun.next(this.getcountryData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.FilterCoun.next(
      this.getcountryData.filter(
        bank => bank.CountryName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  protected filterStates() {
    if (!this.getcountryData) {
      return;
    }
    // get the search keyword
    let search = this.StatesFilterCtrl.value;
    if (!search) {
      this.StatesCoun.next(this.getstateData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.StatesCoun.next(
      this.getstateData.filter(
        bank => bank.StateName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  protected filterDistrict() {
    if (!this.getstateData) {
      return;
    }
    // get the search keyword
    let search = this.DistrictsFilterCtrl.value;
    if (!search) {
      this.DistrictCoun.next(this.getdistrictData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.DistrictCoun.next(
      this.getdistrictData.filter(
        bank => bank.DistrictName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  protected filtermandal() {
    if (!this.getdistrictData) {
      return;
    }
    // get the search keyword
    let search = this.MandalFilterCtrl.value;
    if (!search) {
      this.MandalCoun.next(this.getmandaldata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.MandalCoun.next(
      this.getmandaldata.filter(
        bank => bank.MandalName.toLowerCase().indexOf(search) > -1
      )
    );
  }
  protected filterVillage() {
    if (!this.getmandaldata) {
      return;
    }
    // get the search keyword
    let search = this.VillageFilterCtrl.value;
    if (!search) {
      this.VillageCoun.next(this.getvillageData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.VillageCoun.next(
      this.getvillageData.filter(
        bank => bank.VillageName.toLowerCase().indexOf(search) > -1
      )
    );
  }

  protected filterFertilizer() {
    if (!this.getfertilizerData) {
      return;
    }
    // get the search keyword
    let search = this.FertilizerFilterCtrl.value;
    if (!search) {
      this.FertilizerCoun.next(this.getfertilizerData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.FertilizerCoun.next(
      this.getfertilizerData.filter(
        bank => bank.Companyname.toLowerCase().indexOf(search) > -1
      )
    );
  }

  workpls(event) {
    this.states = [];
    this.districts = [];
    this.mandal = [];
    this.village = [];
  }
  applyFilter() {
    this.listData.filter = this.secretKey.trim().toLowerCase();
    if (this.listData.filteredData.length === 0) {
      this.displayNoRecords = true;
    } else {
      this.displayNoRecords = false;
    }
  }

  onSearchClear() {
    this.secretKey = "";
    this.applyFilter();
  }

  onChangeCountry(ID: string) {
    if (ID) {
      this.ds.getStatesDataByCountry(ID).subscribe(res => {
        if (res["data"] === "NO States Available with this Country ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "No States Available",
            showConfirmButton: false,
            timer: 1500
          });

          this.states = [];
          this.districts = [];
          this.mandal = [];
          this.village = [];
          this.resetdrop(event);

          this.Dealersinformation.controls.TblState_ID.patchValue("");
          this.Dealersinformation.controls.TblDistrict_ID.patchValue("");
          this.Dealersinformation.controls.TblMandal_ID.patchValue("");
          this.Dealersinformation.controls.TblVillage_ID.patchValue("");
        } else {
          Swal.fire({
            position: "center",
            type: "info",
            title: "Please Select The States",
            showConfirmButton: false,
            timer: 1000
          });
          this.Dealersinformation.controls.TblState_ID.patchValue("");
          this.states = res;

          this.StatesCoun.next(this.getstateData.slice());
          this.DistrictCoun.next(this.getdistrictData.slice());
          this.MandalCoun.next(this.getmandaldata.slice());
          this.VillageCoun.next(this.getvillageData.slice());
        }
      });
    }
  }

  onChangedist(ID: string) {
    if (ID) {
      this.ds.getDistrictDataByDist(ID).subscribe(res => {
        //console.log(res,"dist")
        if (res["data"] === "No Districts Available With This ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "No Districts Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.districts = [];
          this.mandal = [];
          this.village = [];
          this.resetdrop(event);

          this.Dealersinformation.controls.TblDistrict_ID.patchValue("");
          this.Dealersinformation.controls.TblMandal_ID.patchValue("");
          this.Dealersinformation.controls.TblVillage_ID.patchValue("");
        } else {
          Swal.fire({
            position: "center",
            type: "info",
            title: "Please Select The Districts",
            showConfirmButton: false,
            timer: 1000
          });
          this.districts = res;

          this.MandalCoun.next(this.getmandaldata.slice());
          this.VillageCoun.next(this.getvillageData.slice());
        }
      });
    }
  }

  onChangeMandals(ID: string) {
    if (ID) {
      this.ds.getMandalsDataBydist(ID).subscribe(res => {
        //console.log(res,"mandals")
        if (res["data"] === "No Mandals Available With This ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "No Mandals Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.mandal = [];
          this.village = [];
          this.resetdrop(event);

          this.Dealersinformation.controls.TblMandal_ID.patchValue("");
          this.Dealersinformation.controls.TblVillage_ID.patchValue("");
        } else {
          Swal.fire({
            position: "center",
            type: "info",
            title: "Please Select The Mandal",
            showConfirmButton: false,
            timer: 1000
          });
          this.mandal = res;

          this.VillageCoun.next(this.getvillageData.slice());
        }
      });
    }
  }
  onChangeVillages(ID: string) {
    if (ID) {
      this.ds.getVillagesDataByMandalID(ID).subscribe(res => {
        //console.log("village",res)
        if (res["data"] === "No Villages Available With This ID") {
          Swal.fire({
            position: "center",
            type: "info",
            title: "No villages Available",
            showConfirmButton: false,
            timer: 1500
          });
          this.village = [];
          this.resetdrop(event);

          this.Dealersinformation.controls.TblVillage_ID.patchValue("");

          this.village = null;
        } else {
          Swal.fire({
            position: "center",
            type: "info",
            title: "Please Select The village",
            showConfirmButton: false,
            timer: 1000
          });
          this.village = res;

          this.VillageCoun.next(this.getvillageData.slice());
        }
      });
    }
  }

  displaydealerinformation() {
    this.ds.getdealer().subscribe(list => {
      this.isLoading = false;
      this.userDealersData = list;
      if (this.userDealersData.length === 0) {
        this.displayNoRecords = true;
      } else {
        this.displayNoRecords = false;
      }
      this.listData = new MatTableDataSource(this.userDealersData);
      this.listData.filterPredicate = (
        data: DealerInformation,
        filter: string
      ) => data.DealerName.toLowerCase().indexOf(filter) !== -1;
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }

  AddDealersInformation() {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.FertilizerCoun.next(this.getfertilizerData.slice());
    this.resetdrop(event);
    this.workpls(event);
    this.Dealersinformation.reset();
    this.DealersInformation =
      this.DealersInformation === "Add Dealer Information"
        ? "Dealer Information"
        : "Add Dealer Information";
    this.editDealersinformation = !this.editDealersinformation;
    this.editDealersInformation =
      this.editDealersInformation === "cancel" ? "add_circle" : "cancel";
    this.displayddl = this.editDealersinformation ? "inline" : "none";
  }

  CreateDealersInformation() {
    this.submitted = true;
    this.barButtonOptions.active = true;
    this.barButtonOptions.text = "Please Wait...";
    if (!this.Dealersinformation.valid) {
      Object.keys(this.Dealersinformation.controls).forEach(field => {
        const control = this.Dealersinformation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500,
        buttonsStyling: false
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.Dealersinformation.controls.created_by.patchValue(1);
      this.ds.savedealerdata(this.Dealersinformation.value).subscribe(
        res => {
          if (res["data"] === "Successfully Posted") {
            Swal.fire({
              position: "center",
              type: "success",
              title: "Sucessfully added the Dealer",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            this.resetForm();
            this.displaydealerinformation();
            this.AddDealersInformation();
          } else if ((res["data"] = "serverErrorStateExistence")) {
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
            Swal.fire({
              position: "center",
              type: "info",
              title: "Already Exists The Dealer",
              showConfirmButton: false,
              timer: 1500
            });
            this.barButtonOptions.active = false;
            this.barButtonOptions.text = "SUBMIT";
          }
        },
        err => console.error(err)
      );
    }
  }

  toggleUpdateDealer(getDealerDataObj) {
    this.EditDealerinformation = getDealerDataObj;
    this.ds
      .getStatesDataByCountry(this.EditDealerinformation.TblCountry_ID)
      .subscribe(res => {
        this.states = res;
      });
    this.ds
      .getDistrictDataByDist(this.EditDealerinformation.TblState_ID)
      .subscribe(res => {
        this.districts = res;
      });
    this.ds.getMandalsDataBydist(this.EditDealerinformation.TblDistrict_ID).subscribe(res => {
      this.mandal = res;

    })

    this.ls
      .getvillageDataByMandal(this.EditDealerinformation.TblMandal_ID)
      .subscribe(res => {
        this.village = res;
      });
    this.EditDealerinformation.LicenseStartDate = this.dp.transform(
      this.EditDealerinformation.LicenseStartDate,
      "yyyy-MM-dd"
    );
    this.EditDealerinformation.LicenseEndDate = this.dp.transform(
      this.EditDealerinformation.LicenseEndDate,
      "yyyy-MM-dd"
    );

    this.updateDealersinformation = !this.updateDealersinformation;
    this.displayddl = !this.updateDealersinformation ? "inline" : "none";

    this.Dealersinformation.setValue({
      DealerName: this.EditDealerinformation.DealerName,
      DealerType: this.EditDealerinformation.DealerType,
      SellsFertilizerType: this.EditDealerinformation.SellsFertilizerType,
      Dealeraddress: this.EditDealerinformation.Dealeraddress,
      LicenseStartDate: this.EditDealerinformation.LicenseStartDate,
      LicenseEndDate: this.EditDealerinformation.LicenseEndDate,
      TblCountry_ID: this.EditDealerinformation.TblCountry_ID,
      TblState_ID: this.EditDealerinformation.TblState_ID,
      TblDistrict_ID: this.EditDealerinformation.TblDistrict_ID,
      TblMandal_ID: this.EditDealerinformation.TblMandal_ID,
      TblVillage_ID: this.EditDealerinformation.TblVillage_ID,
      ContactNos: this.EditDealerinformation.ContactNos,
      ContactPersonName: this.EditDealerinformation.ContactPersonName,
      Website: this.EditDealerinformation.Website,
      Email: this.EditDealerinformation.Email,
      TblFertilizerCompanyMaster_ID: this.EditDealerinformation
        .TblFertilizerCompanyMaster_ID,
      created_by: this.EditDealerinformation.created_by,
      modified_by: this.EditDealerinformation.modified_by
    });
  }

  toggleUpdateDealerInformation2() {
    this.updateDealersinformation = false;
    this.displayddl = this.EditDealerinformation ? "inline" : "block";
  }

  UpdateDealerInformation(res) {
    this.barButtonOptions.active = false;
    this.barButtonOptions.text = "SUBMIT";
    this.EditDealerinformation = res;
    if (!this.Dealersinformation.valid) {
      Object.keys(this.Dealersinformation.controls).forEach(field => {
        const control = this.Dealersinformation.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      Swal.fire({
        position: "center",
        type: "info",
        title: "Fill The Required Fields",
        showConfirmButton: false,
        timer: 1500
      });
      this.barButtonOptions.active = false;
      this.barButtonOptions.text = "SUBMIT";
    } else {
      this.Dealersinformation.controls.modified_by.patchValue(0);
      this.ls
        .updatedealerById(
          this.EditDealerinformation.ID,
          this.Dealersinformation.value
        )
        .subscribe(
          ddata => {
            // tslint:disable-next-line:max-line-length
            if (
              this.EditDealerinformation.DealerName ===
              this.Dealersinformation.controls.DealerName.value &&
              this.EditDealerinformation.DealerType ===
              this.Dealersinformation.controls.DealerType.value &&
              this.EditDealerinformation.SellsFertilizerType ===
              this.Dealersinformation.controls.SellsFertilizerType.value &&
              // tslint:disable-next-line:max-line-length
              this.EditDealerinformation.Dealeraddress ===
              this.Dealersinformation.controls.Dealeraddress.value &&
              this.EditDealerinformation.LicenseStartDate ===
              this.Dealersinformation.controls.LicenseStartDate.value &&
              this.EditDealerinformation.LicenseEndDate ===
              this.Dealersinformation.controls.LicenseEndDate.value &&
              // tslint:disable-next-line:max-line-length
              this.EditDealerinformation.TblCountry_ID ===
              this.Dealersinformation.controls.TblCountry_ID.value &&
              this.EditDealerinformation.TblState_ID ===
              this.Dealersinformation.controls.TblState_ID.value &&
              this.EditDealerinformation.TblDistrict_ID ===
              this.Dealersinformation.controls.TblDistrict_ID.value &&
              // tslint:disable-next-line:max-line-length
              this.EditDealerinformation.TblMandal_ID ===
              this.Dealersinformation.controls.TblMandal_ID.value &&
              this.EditDealerinformation.TblVillage_ID ===
              this.Dealersinformation.controls.TblVillage_ID.value &&
              this.EditDealerinformation.ContactNos ===
              this.Dealersinformation.controls.ContactNos.value &&
              this.EditDealerinformation.ContactPersonName ===
              this.Dealersinformation.controls.ContactPersonName.value &&
              // tslint:disable-next-line:max-line-length
              this.EditDealerinformation.Website ===
              this.Dealersinformation.controls.Website.value &&
              this.EditDealerinformation.Email ===
              this.Dealersinformation.controls.Email.value &&
              this.EditDealerinformation.TblFertilizerCompanyMaster_ID ===
              this.Dealersinformation.controls.TblFertilizerCompanyMaster_ID
                .value
            ) {
              Swal.fire({
                position: "center",
                type: "info",
                title: "No update Found",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
            } else if (ddata["data"] === "Successfully Updated") {
              Swal.fire({
                position: "center",
                type: "success",
                title: "Sucessfully Edited",
                showConfirmButton: false,
                timer: 1500
              });
              this.barButtonOptions.active = false;
              this.barButtonOptions.text = "SUBMIT";
              this.displaydealerinformation();
              this.toggleUpdateDealerInformation2();
            }
          },

        );
    }
  }

  deleteDealer(id: string) {
    ;

    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.ls.deletedealerinformationById(id).subscribe(pdata => {
          if ((pdata["data"] = "Successfully Deleted")) {
            Swal.fire("Deleted!", "Your Data has been deleted.", "success");
            this.displaydealerinformation();
          }
        });
      }
    });
  }

  toggleViewDealer(getDealerDataObj) {
    this.viewDealersInformation = !this.viewDealersInformation;
    this.EditDealerinformation = getDealerDataObj;
    this.displayddl = !this.EditDealerinformation ? "inline" : "none";
  }
  toggleViewDealersInformation1() {
    this.viewDealersInformation = false;
    this.displayddl = !this.EditDealerinformation ? "inline" : "block";
  }
}
