export interface DealerInformation {
  DealerName?: any;
  DealerType?: any;
  SellsFertilizerType?: any;
  Dealeraddress?: any;
  LicenseStartDate?: any;
  LicenseEndDate?: any;
  TblCountry_ID?:any;

  TblState_ID?: number;
  TblDistrict_ID?: number;
  TblMandal_ID?: number;
  TblVillage_ID?: number;
  ContactNos?: any;
  ContactPersonName?: any;
  Website?: any;
  Email?: any;
  TblFertilizerCompanyMaster_ID?: number;
  Created_by?: any;
  Modified_by?: any;
}
export interface CompanyMaster{
  Companyname?:any;
}