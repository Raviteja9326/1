import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealersinformationComponent } from './dealersinformation.component';

describe('DealersinformationComponent', () => {
  let component: DealersinformationComponent;
  let fixture: ComponentFixture<DealersinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealersinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealersinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
