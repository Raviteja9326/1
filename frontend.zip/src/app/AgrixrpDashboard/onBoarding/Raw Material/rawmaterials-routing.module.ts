import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DealersinformationComponent } from './dealersinformation/dealersinformation.component';
import { RawmaterialComponent } from './rawmaterial.component';
import { RawmaterialstockComponent } from './rawmaterialstock/rawmaterialstock.component';
import { InventoryComponent } from './inventory/inventory.component';
import { BillofmaterialsComponent } from './billofmaterials/billofmaterials.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';



const routes: Routes = [{
    path: '',
    component: RawmaterialComponent,
    children: [{
        path: 'Dealers',
        component: DealersinformationComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Raw Materials',
        component: RawmaterialstockComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Inventory',
        component: InventoryComponent, canActivate: [AuthGuardService]
    },
    {
        path: 'Bill Of Materials',
        component: BillofmaterialsComponent, canActivate: [AuthGuardService]
    }

    ]

}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RawmaterialsRoutingModule { }
