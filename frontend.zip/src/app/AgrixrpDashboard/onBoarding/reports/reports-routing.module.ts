import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
import { ReportsComponent } from './reports.component';
import { FarmerReportsComponent } from './farmer-reports/farmer-reports.component';
const routes: Routes = [{
    path: '',
    component: ReportsComponent,
    children: [
        {
            path: 'Farmers Dashboard',
            component: FarmerReportsComponent, canActivate: [AuthGuardService]
        },

    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ReportsRoutingModule { }

