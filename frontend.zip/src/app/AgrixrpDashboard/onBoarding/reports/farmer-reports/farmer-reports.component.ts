import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { MastersService } from 'app/services/masters.service';
import { CASService } from 'app/services/cas.service';

@Component({
  selector: 'app-farmer-reports',
  templateUrl: './farmer-reports.component.html',
  styleUrls: ['./farmer-reports.component.scss']
})
export class FarmerReportsComponent implements OnInit {
  countries: any;
  counrtyID: any;
  stateBool: any;
  districtBool: any;
  states: any[];
  graphdata: any[];
  districts: any[];

  constructor(private masterService: MastersService, private casService: CASService) { }

  ngOnInit() {
    this.masterService.getCountriesData().subscribe((res) => {
      this.countries = res;
    });
    this.casService.getCertificationGraphData(25, 'country').subscribe((res) => {
      this.graphdata = res;
      this.barChart(this.graphdata, 'FPO-1');
    });
    this.casService.getNonCertificationGraphData(3, 'country').subscribe((res) => {
      this.lineChart(res, 'FPO-1');
    });
    this.campainLineChart();


  }

  changeInCountry(country) {
    this.graphdata = [];
    this.casService.getCertificationGraphData(country.ID, 'country').subscribe((res) => {
      this.graphdata = res;
      this.barChart(this.graphdata, country.CountryName);
      this.masterService.getStatesDataByCountry(country.ID).subscribe((res) => {
        if (res['data'] === 'No Data Available with this ID') {
          this.states = [];
          this.districts = [];
        } else {
          this.states = res;
        }
      });
    });

    this.casService.getNonCertificationGraphData(country.ID, 'country').subscribe((res) => {
      this.lineChart(res, country.CountryName);
    });
  }
  changeInState(state) {
    this.graphdata = [];
    this.casService.getCertificationGraphData(state.ID, 'state').subscribe((res) => {
      this.graphdata = res;
      this.barChart(this.graphdata, state.StateName);
      this.masterService.getDistrictDataByDist(state.ID).subscribe((res) => {
        res['data'] === 'No Data Available with this ID' ? (this.districts = []) : (this.districts = res);
      });
    });
    this.casService.getNonCertificationGraphData(state.ID, 'state').subscribe((res) => {
      this.lineChart(res, state.StateName);
    });
  }

  changeInDsitrict(district) {
    this.graphdata = [];
    this.casService.getCertificationGraphData(district.ID, 'district').subscribe((res) => {
      this.graphdata = res;
      this.barChart(this.graphdata, district.DistrictName);
    });
    this.casService.getNonCertificationGraphData(district.ID, 'district').subscribe((res) => {
      this.lineChart(res, district.DistrictName);
    });
  }

  barChart = (data, legend) => {
    new Chart('chart', {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
          {
            label: `Certified Famers In ${legend}`,
            backgroundColor: [
              '#454777',
              '#746ABA',
              '#EFB5C3',
              '#FFCF56',
              '#6D9773',
              '#B46617',
              '#F85DC6',
              '#7E4BFF',
              '#FF5134',
              '#1E2843',
              '#FF5B64',
              '#00BE65'
            ],

            data: data
          }
        ]
      },
      options: {
        legend: {
          labels: {
            fontColor: 'black',
            fontSize: 15
          }
        },
        scales: {
          xAxes: [
            {
              scaleLabel: {
                display: true,
                labelString: new Date().getFullYear()
              },
              gridLines: {
                display: false
              }
            }
          ],
          yAxes: [
            {
              scaleLabel: {
                display: true,
                labelString: 'No of Farmers'
              },
              ticks: {
                beginAtZero: true
              },
              gridLines: {
                display: false
              }
            }
          ]
        }
      }
    });
  };

  lineChart = (data, legendName) => {
    new Chart('nonCertified', {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
          {
            label: `Total Famers In ${legendName}`,
            fill: false,
            backgroundColor: 'rgba(0,0,0,0)',

            borderColor: '#319fe2',
            data: data
          }
        ]
      },
      options: {
        scales: {
          xAxes: [
            {
              scaleLabel: {
                display: true,
                labelString: new Date().getFullYear()
              },
              gridLines: {
                display: true
              }
            }
          ],
          yAxes: [
            {
              scaleLabel: {
                display: true,
                labelString: 'No of Farmers'
              },
              ticks: {
                beginAtZero: true
              },
              gridLines: {
                display: true
              }
            }
          ]
        }
      }
    });
  };

  campainLineChart = () => {
    new Chart('campainChart', {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
          {
            label: `No of Attenders in Campaign-1`,
            fill: true,
            backgroundColor: 'rgba(0,0,0,0)',

            borderColor: '#FFCF56',
            data: [21, 49, 21, 32, 23, 45, 41, 45, 87, 67, 32, 86]
          },
          {
            label: `No of Attenders in Campaign-2`,
            fill: true,
            backgroundColor: 'rgba(0,0,0,0)',

            borderColor: '#FF5134',
            data: [11, 24, 21, 32, 23, 35, 41, 45, 81, 66, 32, 86]
          },
          {
            label: `No of Attenders in Campaign-3`,
            fill: true,
            backgroundColor: 'rgba(0,0,0,0)',

            borderColor: '#00BE65',
            data: [45, 34, 21, 42, 23, 45, 51, 45, 81, 66, 38, 76]
          }
        ]
      },
      options: {
        scales: {
          xAxes: [
            {
              scaleLabel: {
                display: true,
                labelString: new Date().getFullYear()
              },
              gridLines: {
                display: true
              }
            }
          ],
          yAxes: [
            {
              scaleLabel: {
                display: true,
                labelString: 'No of Attenders'
              },
              ticks: {
                beginAtZero: true
              },
              gridLines: {
                display: true
              }
            }
          ]
        }
      }
    });
  };

}
