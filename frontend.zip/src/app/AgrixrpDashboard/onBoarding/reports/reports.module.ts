import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NgxMatSelectSearchModule } from "../../maincomponents/mat-select-search/ngx-mat-select-search.module";
import { RxReactiveFormsModule } from "@rxweb/reactive-form-validators";
import { SharedModule } from 'app/AgrixrpDashboard/maincomponents/shared.module';
import { MaterialModule } from 'app/AgrixrpDashboard/material/material.module';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { NgxSpinnerModule } from "ngx-spinner";
import { ReportsComponent } from './reports.component';
import { FarmerReportsComponent } from './farmer-reports/farmer-reports.component';
import { ReportsRoutingModule } from './reports-routing.module';
// tslint:disable-next-line:max-line-length
const components = [
    ReportsComponent,
    FarmerReportsComponent
];

@NgModule({
    // tslint:disable-next-line:max-line-length
    imports: [
        MaterialFileInputModule,
        NgxSpinnerModule,
        SharedModule,
        ReportsRoutingModule,
        RxReactiveFormsModule,
        CommonModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        MaterialModule,
        NgxMatSelectSearchModule
    ],
    declarations: [...components]
})
export class ReportsModule { }
