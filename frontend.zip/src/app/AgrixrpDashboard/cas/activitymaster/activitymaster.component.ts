import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Validators, FormBuilder } from '@angular/forms';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { CASService } from 'app/services/cas.service';
import Swal from 'sweetalert2';
import { rowsAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';

export interface ActivityMaster {
	ActyMasterName?: any;
}

@Component({
	selector: 'app-activitymaster',
	templateUrl: './activitymaster.component.html',
	styleUrls: ['./activitymaster.component.scss'],
	animations: [rowsAnimation],
})
export class ActivitymasterComponent implements OnInit {
	ActivityType = 'Activity Master';
	editActivity = 'add_circle';
	editActivitytype = true;
	updateActivitytype = false;
	displayddl: string;
	secretKey: string;
	isLoading = false;
	displayNoRecords = false;
	EditActivity: any = [];
	ActivityData: any[] = [];

	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'Activity', 'Actions'];

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;
	userActivityData: any[];

	constructor(private formBuilder: FormBuilder, private ls: CASService) { }

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	ActivityForm = this.formBuilder.group({
		ActyMasterName: ['', [Validators.required]]
	});

	AddActivity() {
		this.ActivityForm.reset();
		this.ActivityType = this.ActivityType === 'Activity Master' ? 'Add Activity Master' : 'Activity Master';
		this.editActivitytype = !this.editActivitytype;
		this.editActivity = this.editActivity === 'cancel' ? 'add_circle' : 'cancel';
		this.displayddl = this.editActivitytype ? 'inline' : 'none';
		this.displayActivity();
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	ngOnInit() {
		this.displayActivity();
	}

	displayActivity() {

		this.ls.getAllMasterActivities().subscribe((list) => {
			this.ActivityData = list['data'];
			//console.log(this.ActivityData);
			if (this.ActivityData.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			//console.log(this.ActivityData);
			this.listData = new MatTableDataSource(this.ActivityData);
			/* config filter */
			this.listData.filterPredicate = (data: ActivityMaster, filter: string) =>
				data.ActyMasterName.toLowerCase().indexOf(filter) !== -1;

			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	resetForm() {
		if (this.ActivityForm.valid) {
			this.ActivityForm.reset();
		}
	}

	createActivityMaster() {
		//console.log(this.ActivityForm.value);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.ActivityForm.valid) {
			Object.keys(this.ActivityForm.controls).forEach((field) => {
				const control = this.ActivityForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			//	this.SoilForm.controls.created_by.patchValue(1);
			this.ls.saveActivityMaster(this.ActivityForm.value).subscribe(
				(res) => {
					//console.log(res);

					if (res['message'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added Activity Master',
							showConfirmButton: false,
							timer: 2500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.resetForm();
						this.displayActivity();
						this.AddActivity();
						// this.route.navigate(['/Agrixrp/CAS/RoleActivity']);
					} else if ((res['data'] = 'Activity is already exists!')) {
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The Activity Name',
							showConfirmButton: false,
							timer: 1500
						});
					}
				},
				(err) => console.error(err)
			);
		}
	}

	toggleUpdateActivityName(getActivityNameDataObj) {
		this.EditActivity = getActivityNameDataObj;
		//console.log('update act', this.EditActivity);
		this.updateActivitytype = !this.updateActivitytype;
		this.displayddl = !this.editActivitytype ? 'inline' : 'none';
		this.ActivityForm.setValue({
			ActyMasterName: this.EditActivity.ActyMasterName
		});
	}

	togglecloseActivityType1() {
		this.updateActivitytype = false;
		this.displayddl = this.editActivitytype ? 'inline' : 'block';
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	updateActivity() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.ActivityForm.valid) {
			Object.keys(this.ActivityForm.controls).forEach((field) => {
				const control = this.ActivityForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.ls.updateActivityMasterById(this.EditActivity.ID, this.ActivityForm.value).subscribe(
				(res) => {
					//console.log(res);
					if (this.EditActivity.ActyMasterName === this.ActivityForm.controls.ActyMasterName.value) {
						//console.log('no update');
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['message'] === 'Success') {
						//console.log('update');
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Updated',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayActivity();
						this.togglecloseActivityType1();
					}
				},
				(err) => console.log(err)
			);
		}
	}

	deleteActivitytpye(id: string) {
		//console.log(id);
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteActivityMasterById(id).subscribe((res) => {
					if ((res['message'] = 'success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayActivity();
					}
				});
			}
		});
	}
}
