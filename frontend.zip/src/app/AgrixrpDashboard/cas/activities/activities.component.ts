import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject, ReplaySubject } from 'rxjs';
import { ActivityMaster } from '../activitymaster/activitymaster.component';
import { CASService } from 'app/services/cas.service';
import Swal from 'sweetalert2';
import { rowsAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';

export interface Activities {
	ActyName?: any;
	TblActivityMaster_ID?: number;
}

@Component({
	selector: 'app-activities',
	templateUrl: './activities.component.html',
	styleUrls: ['./activities.component.scss'],
	animations: [rowsAnimation],
})
export class ActivitiesComponent implements OnInit {
	ActivitiesType = 'Activities';
	edittype = 'add_circle';
	editActivities = true;
	UpdateActivitiestype = false;
	displayddl: string;
	secretKey: string;
	isLoading = false;
	displayNoRecords = false;
	ActivityData: any;
	EditActivities: any;
	allActivities: any;

	constructor(private formBuilder: FormBuilder, private ls: CASService) { }

	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'Activities', 'ActivityMaster', 'Actions'];

	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;

	protected _onDestroy = new Subject<void>();

	ActivitiesForm = this.formBuilder.group({
		ActyName: ['', [Validators.required]],
		TblActivityMaster_ID: ['', [Validators.required]]
	});

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	/** control for the MatSelect filter keyword */
	public ActivtyFilterCtrl: FormControl = new FormControl();

	/** list of banks filtered by search keyword */
	public filteredActivty: ReplaySubject<ActivityMaster[]> = new ReplaySubject<ActivityMaster[]>(1);

	AddActivities() {
		this.ActivitiesForm.reset();
		this.filteredActivty.next(this.ActivityData.slice());
		this.ActivitiesType = this.ActivitiesType === 'Activities' ? 'Add Activities' : 'Activities';
		this.editActivities = !this.editActivities;
		this.edittype = this.edittype === 'cancel' ? 'add_circle' : 'cancel';
		this.displayddl = this.editActivities ? 'inline' : 'none';
		this.displayActivities();
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	resetForm() {
		this.ActivitiesForm.reset();
	}

	displayActivities() {
		this.ls.getAllActivities().subscribe((res) => {
			this.allActivities = res['data'];
			//console.log('all data', this.allActivities);
			if (this.allActivities.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			//console.log(this.allActivities);
			this.listData = new MatTableDataSource(this.allActivities);
			/* config filter */

			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	createBtn: boolean;
	EditBtn: boolean;
	delBtn: boolean;
	read: boolean;

	ngOnInit() {
		this.displayActivities();
		// Activity master data
		this.ls.getAllMasterActivities().subscribe((list) => {
			this.ActivityData = list['data'];
			//console.log(this.ActivityData);
		});
		this.ActivtyFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterActivity();
		});
		this.createBtn = this.ls.checkCrud("UserManagement", "C");
		this.read = this.ls.checkCrud("UserManagement", "R")
		this.EditBtn = this.ls.checkCrud("UserManagement", "U");
		this.delBtn = this.ls.checkCrud("UserManagement", "D");
		// avtivity master data ends
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	/*Activity data*/
	protected filterActivity() {
		//console.log('Activity', this.ActivityData);
		if (!this.ActivityData) {
			return;
		}
		// get the search keyword
		let search = this.ActivtyFilterCtrl.value;
		//console.log(this.ActivtyFilterCtrl.value);

		if (!search) {
			this.filteredActivty.next(this.ActivityData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredActivty.next(
			this.ActivityData.filter((bank) => bank.ActyMasterName.toLowerCase().indexOf(search) > -1)
		);
	}
	/*Role data ends*/

	createActivities() {
		//console.log(this.ActivitiesForm.value);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.ActivitiesForm.valid) {
			Object.keys(this.ActivitiesForm.controls).forEach((field) => {
				const control = this.ActivitiesForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			//	this.SoilForm.controls.created_by.patchValue(1);
			this.ls.saveActivities(this.ActivitiesForm.value).subscribe(
				(res) => {
					//console.log(res);

					if (res['message'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added Activities',
							showConfirmButton: false,
							timer: 2500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.resetForm();
						this.displayActivities();
						this.AddActivities();
						// this.route.navigate(['/Agrixrp/CAS/RoleActivity']);
					} else if ((res['message'] = 'Already Exists')) {
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The Activity Name',
							showConfirmButton: false,
							timer: 1500
						});
					}
				},
				(err) => console.error(err)
			);
		}
	}

	toggleUpdateActivitiesName(getActivitiesNameDataObj) {
		this.EditActivities = getActivitiesNameDataObj;
		//console.log('update', this.EditActivities);
		this.UpdateActivitiestype = !this.UpdateActivitiestype;
		this.displayddl = !this.editActivities ? 'inline' : 'none';
		this.filteredActivty.next(this.ActivityData.slice());
		this.ActivitiesForm.setValue({
			ActyName: this.EditActivities.ActyName,
			TblActivityMaster_ID: this.EditActivities.TblActivityMaster_ID
		});
	}

	toggleUpdateactivities1() {
		this.UpdateActivitiestype = false;
		this.displayddl = this.editActivities ? 'inline' : 'block';
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	updateActivities() {
		//console.log(this.ActivitiesForm.value);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.ActivitiesForm.valid) {
			Object.keys(this.ActivitiesForm.controls).forEach((field) => {
				const control = this.ActivitiesForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.ls.updateActivitiesById(this.EditActivities.ID, this.ActivitiesForm.value).subscribe(
				(res) => {
					//console.log(res);
					if (
						this.EditActivities.ActyName === this.ActivitiesForm.controls.ActyName.value &&
						this.EditActivities.TblActivityMaster_ID ===
						this.ActivitiesForm.controls.TblActivityMaster_ID.value
					) {
						//console.log('no update');
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['message'] === 'Success') {
						//console.log('update');
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Updated',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayActivities();
						this.toggleUpdateactivities1();
					}
				},
				(err) => console.log(err)
			);
		}
	}

	deleteActivitiestpye(id: string) {
		//console.log(id);
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteActivitiesById(id).subscribe((res) => {
					if ((res['message'] = 'success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayActivities();
					}
				});
			}
		});
	}
}
