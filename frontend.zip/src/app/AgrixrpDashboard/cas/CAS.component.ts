import { Component } from '@angular/core';

import { rowsAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';

@Component({
	selector: 'app-CASComponent',
	template: `<router-outlet></router-outlet>`,
	animations: [rowsAnimation],
})
export class CASDataComponent { }
