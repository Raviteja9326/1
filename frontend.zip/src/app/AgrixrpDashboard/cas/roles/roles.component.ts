import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { FormBuilder, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { CASService } from '../../../services/cas.service';
import { Router } from '@angular/router';
import { rowsAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';

export interface Roles {
	RoleName?: any;
}

@Component({
	selector: 'app-roles',
	templateUrl: './roles.component.html',
	styleUrls: ['./roles.component.scss'],
	animations: [rowsAnimation],
})
export class RolesComponent implements OnInit {
	RolesType = 'Roles';
	editrole = 'add_circle';
	editRoletype = true;
	updateRoletype = false;
	displayddl: string;
	secretKey: string;
	isLoading = false;
	displayNoRecords = false;
	EditRole: any = [];

	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'Roles', 'Actions'];

	@ViewChild(MatSort) sort: MatSort;
	@ViewChild(MatPaginator) paginator: MatPaginator;
	userRolesData: any[];

	constructor(private formBuilder: FormBuilder, private ls: CASService, private readonly route: Router) { }

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	RoleForm = this.formBuilder.group({
		RoleName: ['', [Validators.required]]
	});

	AddRole() {
		this.RoleForm.reset();
		this.RolesType = this.RolesType === 'Roles' ? 'Add Roles' : 'Roles';
		this.editRoletype = !this.editRoletype;
		this.editrole = this.editrole === 'cancel' ? 'add_circle' : 'cancel';
		this.displayddl = this.editRoletype ? 'inline' : 'none';
		this.displayRoles();
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	createBtn: boolean;
	EditBtn: boolean;
	delBtn: boolean;
	read: boolean;
	ngOnInit() {
		this.displayRoles();
		this.createBtn = this.ls.checkCrud("UserManagement", "C");
		this.read = this.ls.checkCrud("UserManagement", "R")
		this.EditBtn = this.ls.checkCrud("UserManagement", "U");
		this.delBtn = this.ls.checkCrud("UserManagement", "D");
	}

	displayRoles() {
		this.ls.getAllRoles().subscribe((list) => {
			//console.log('thid is das\ta');
			this.isLoading = false;
			this.userRolesData = list['data'];
			if (this.userRolesData.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			//console.log(this.userRolesData);
			this.listData = new MatTableDataSource(this.userRolesData);
			/* config filter */

			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	resetForm() {
		if (this.RoleForm.valid) {
			this.RoleForm.reset();
		}
	}

	CreateRoles() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.RoleForm.valid) {
			Object.keys(this.RoleForm.controls).forEach((field) => {
				const control = this.RoleForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			//	this.SoilForm.controls.created_by.patchValue(1);
			this.ls.saveRoles(this.RoleForm.value).subscribe(
				(res) => {
					//console.log(res);

					if (res['message'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added Role & Please Assign Activities To This Role Here',
							showConfirmButton: false,
							timer: 2500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.resetForm();
						this.displayRoles();
						this.AddRole();
						this.route.navigate(['/Agrixrp/CAS/RoleActivity']);
					} else if ((res['data'] = 'Already Exists')) {
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The Role Name',
							showConfirmButton: false,
							timer: 1500
						});
					}
				},
				(err) => console.error(err)
			);
		}
	}

	toggleUpdateRoleName(getRoleNameDataObj) {
		this.EditRole = getRoleNameDataObj;
		//console.log('update role', this.EditRole);
		this.updateRoletype = !this.updateRoletype;
		this.displayddl = !this.editRoletype ? 'inline' : 'none';
		this.RoleForm.setValue({
			RoleName: this.EditRole.RoleName
		});
	}

	togglecloseRoleType1() {
		this.updateRoletype = false;
		this.displayddl = this.editRoletype ? 'inline' : 'block';
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	updateRoles() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.RoleForm.valid) {
			Object.keys(this.RoleForm.controls).forEach((field) => {
				const control = this.RoleForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.ls.updateRoleTypeById(this.EditRole.ID, this.RoleForm.value).subscribe(
				(res) => {
					//console.log(res);
					if (this.EditRole.RoleName === this.RoleForm.controls.RoleName.value) {
						//console.log('no update');
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['message'] === 'Success') {
						//console.log('update');
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Updated',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayRoles();
						this.togglecloseRoleType1();
					}
				},
				(err) => console.log(err)
			);
		}
	}

	deleteRoletpye(id: string) {
		//console.log(id);
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteRoleTypeById(id).subscribe((res) => {
					//console.log('res', res);
					if ((res['message'] = "This Role Is In Use Can't Delete")) {
						Swal.fire({
							title: "Can't Delete!",
							text: 'This Role Is In Use Unable to Delete',
							type: 'warning',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayRoles();
					} else if ((res['message'] = 'success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayRoles();
					}
				});
			}
		});
	}
}
