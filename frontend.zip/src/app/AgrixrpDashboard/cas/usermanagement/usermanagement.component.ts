import { Component, OnInit, ViewChild, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
import { MatSort, MatPaginator, MatTableDataSource } from '@angular/material';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { ReplaySubject, Subject } from 'rxjs';
import { Roles } from '../roles/roles.component';
import { takeUntil } from 'rxjs/operators';
import { CASService } from 'app/services/cas.service';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import Swal from 'sweetalert2';
import { MastersService, API_URl } from 'app/services/masters.service';
import { User } from './user';
import { SelectionModel } from '@angular/cdk/collections';
import { Country } from 'app/AgrixrpDashboard/onBoarding/Masters/country/country';
import { States } from 'app/AgrixrpDashboard/onBoarding/Masters/states/states';
import { Districts } from 'app/AgrixrpDashboard/onBoarding/Masters/districts/districts';
import { ToastrService } from 'ngx-toastr';
import { C3office } from 'app/AgrixrpDashboard/onBoarding/Masters/c3office/c3office';
import { rowsAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';



@Component({
	selector: 'app-usermanagement',
	templateUrl: './usermanagement.component.html',
	styleUrls: ['./usermanagement.component.scss'],
	animations: [rowsAnimation],
})



export class UsermanagementComponent implements OnInit, OnDestroy {
	mandals: any;
	c3data: any[];
	Email: { Email: any; };
	err: string;
	getID: any;
	Phone: { PhoneNo: any; };
	UserName: { UserName: any; };


	constructor(private toastr: ToastrService, private formBuilder: FormBuilder, private ls: CASService, private ms: MastersService, private cd: ChangeDetectorRef) {
	}
	ngOnDestroy(): void {

	}

	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'UserName', 'Actions'];

	userroles = 'Users List';
	edittype = 'add_circle';
	editmanagement = true;
	displayddl: string;
	updateusermanagement = false;
	viewusermanagement = false;
	displayNoRecords = false;
	RoleData: any[];
	oldSelectData: [];
	newSelectData: [];
	filterdData: [];
	deletedData: [];
	ActivityData: any;
	ActivityDataByID: any = [];
	ActivityDataByID1: any[];
	villid: any;
	sStatesData: any[];
	sDistrtictsData: any[];
	sCountriesData: any[];
	sC3OfficeData: any[];
	hide = true;
	isLoading = true;
	getusres: any = [];
	secretKey: string;
	EditUserData: any = [];
	roles: any[];
	c3offices: any[];
	data: any[] = [];
	imageManagement: any;
	fileData: any;
	createBtn: boolean;
	EditBtn: boolean;
	delBtn: boolean;
	read: boolean;
	url: any;

	imageUrl: any = 'assets/img/user.jpg';
	editFile: boolean = true;
	removeUpload: boolean = false;

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	/*for activities list data */
	ActivityRoles = new MatTableDataSource<Element>(this.data);
	displayedColumns3: string[] = ['select', 'Acivities'];
	selection = new SelectionModel<Element>(true, []);

	checkedData = [];

	/*for selected activity list data */
	checkedDataSource = new MatTableDataSource<Element>(this.checkedData);
	checkedSelection = new SelectionModel<Element>(true, []);

	uncheckedData: any[] = [];

	protected _onDestroy = new Subject<void>();

	/** control for the MatSelect filter keyword */
	public RoleFilterCtrl: FormControl = new FormControl();

	/** list of banks filtered by search keyword */
	public filteredRole: ReplaySubject<Roles[]> = new ReplaySubject<Roles[]>(1);

	@ViewChild('fileInput') el: ElementRef;
	@ViewChild(MatSort)
	sort: MatSort;
	@ViewChild(MatPaginator)
	paginator: MatPaginator;


	/** control for the MatSelect filter keyword */
	public CounFilterCtrl: FormControl = new FormControl();
	public StsFilterCtrl: FormControl = new FormControl();
	public DtsFilterCtrl: FormControl = new FormControl();
	public C3OFilterCtrl: FormControl = new FormControl();
	public filteredCoun: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
	public filteredSts: ReplaySubject<States[]> = new ReplaySubject<States[]>(1);
	public filteredDts: ReplaySubject<Districts[]> = new ReplaySubject<Districts[]>(1);
	public filteredC3O: ReplaySubject<C3office[]> = new ReplaySubject<C3office[]>(1);



	UserManagement = this.formBuilder.group({
		FirstName: ['', [Validators.required, Validators.maxLength(20), Validators.pattern('^[a-zA-Z ()-.,\\s]+$')]],
		LastName: ['', [Validators.required, Validators.maxLength(20), Validators.pattern('^[a-zA-Z ()-.,\\s]+$')]],
		UserName: ['', [Validators.required, Validators.maxLength(20)]],
		Password: ['', [Validators.required, Validators.pattern('^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^!&*+=]).*$')]],
		AadharNo: ['', [Validators.required, Validators.maxLength(12), Validators.minLength(12)]],
		Address: [''],
		PhoneNo: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
		Email: ['', [Validators.required, Validators.email]],
		TblRole1_ID: ['', [Validators.required]],
		TblCountry_ID: ['', [Validators.required]],
		TblState_ID: ['',],
		TblDistrict_ID: ['',],
		TblC3Office_ID: ['', [Validators.required]],
		created_by: [''],
		modified_by: [''],
		user: ['']

	});

	UpdateUserManagementForm = this.formBuilder.group({
		UserName: ['', [Validators.required]],
		Address: [''],
		PhoneNo: ['', [Validators.required, Validators.minLength(10), Validators.pattern('[6-9]\\d{9}')]],
		TblRole1_ID: ['', [Validators.required]],
		TblCountry_ID: ['', [Validators.required]],
		TblState_ID: ['',],
		TblDistrict_ID: ['',],
		TblC3Office_ID: ['',],
		modified_by: ['', [Validators.required]]
	});

	ImageManagementForm = this.formBuilder.group({
		user: ['']
	})


	AddUserManagement() {
		this.resetForm()
		this.displayUsers();
		this.userroles = this.userroles === 'Users List' ? 'Add User' : 'Users List';
		this.edittype = this.edittype === 'add_circle' ? 'cancel' : 'add_circle';
		this.filteredRole.next(this.RoleData.slice());
		this.editmanagement = !this.editmanagement;
		this.displayddl = this.editmanagement ? 'inline' : 'none';
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	resetForm() {
		this.removeUploadedFile();
		this.ImageManagementForm.reset();
		this.UserManagement.reset();
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
		this.sStatesData = [];
		this.sDistrtictsData = [];
		this.sC3OfficeData = [];
	}

	numberOnly(event): boolean {
		const charCode = event.which ? event.which : event.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)) {
			return false;
		}
		return true;
	}

	uploadFile(event) {
		let reader = new FileReader();
		this.fileData = event.target.files[0];
		//console.log(this.fileData)
		if (event.target.files && event.target.files[0]) {
			reader.readAsDataURL(this.fileData);

			// When file uploads set it to file formcontrol
			reader.onload = () => {
				this.imageUrl = reader.result;
				this.editFile = false;
				this.removeUpload = true;
			}
			// ChangeDetectorRef since file is loading outside the zone
			this.cd.markForCheck();
		}
	}

	removeUploadedFile() {
		this.imageUrl = 'assets/img/user.jpg';
		this.editFile = true;
		this.removeUpload = false;
		this.ImageManagementForm.patchValue({
			user: [null]
		});
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}


	displayUsers() {
		this.ls.getAllUsers().subscribe((res) => {
			this.isLoading = false;
			this.getusres = res['data'];
			//console.log('all users', this.getusres);
			if (this.getusres.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			//console.log(this.getusres);
			this.listData = new MatTableDataSource(this.getusres);
			/* config filter */
			this.listData.filterPredicate = (data: User, filter: string) =>
				data.UserName.toLowerCase().indexOf(filter) !== -1;

			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}
	convertBools(obj) {
		const newObj = {};

		if (typeof obj !== 'object') {
			return obj;
		}

		for (const prop in obj) {
			if (!obj.hasOwnProperty(prop)) {
				continue;
			}
			if (Array.isArray(obj[prop])) {
				newObj[prop] = obj[prop].map((val) => this.convertBools(val));
			} else if (obj[prop] === 'true') {
				newObj[prop] = true;
			} else if (obj[prop] === 'false') {
				newObj[prop] = false;
			} else {
				newObj[prop] = this.convertBools(obj[prop]);
			}
		}

		return newObj;
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}

	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	ngOnInit() {
		this.getCountrties();
		this.displayUsers();

		// role data
		this.ls.getAllRoles().subscribe((res) => {
			this.RoleData = res['data'];
			//console.log(this.RoleData);
		});
		this.RoleFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterRole();
		});
		// role data ends
		// this.createBtn = this.ls.checkCrud("UserManagement", "C");
		// this.read = this.ls.checkCrud("UserManagement", "R")
		// this.EditBtn = this.ls.checkCrud("UserManagement", "U");
		// this.delBtn = this.ls.checkCrud("UserManagement", "D");
		this.url = API_URl

	}

	/*Role data*/
	protected filterRole() {
		//console.log('Roles', this.RoleData);
		if (!this.RoleData) {
			return;
		}
		// get the search keyword
		let search = this.RoleFilterCtrl.value;
		//console.log(this.RoleFilterCtrl.value);

		if (!search) {
			this.filteredRole.next(this.RoleData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredRole.next(this.RoleData.filter((bank) => bank.RoleName.toLowerCase().indexOf(search) > -1));
	}
	/*Role data ends*/

	getCountrties() {
		this.sStatesData = [];
		this.sDistrtictsData = [];
		this.sC3OfficeData = [];
		this.ms.getCountriesData().subscribe((response) => {
			this.sCountriesData = response;
		});
	}
	async onChangeCountry(ID: string) {
		this.sStatesData = [];
		this.sDistrtictsData = [];
		this.sC3OfficeData = [];
		this.ms.getC3officeDataByCountry(ID).subscribe((response) => {
			if (response['data'] === 'No c3Office Available With This ID') {
				Swal.fire({
					position: 'center',
					type: 'info',
					title: 'No C3Office Available with this Country',
					showConfirmButton: false,
					timer: 1500
				});
			} else {
				this.UserManagement.controls.TblC3Office_ID.patchValue('');
				this.sC3OfficeData = response;
			}
		});

		this.ms.getStatesDataByCountry(ID).subscribe((response) => {
			//console.log('states res', response)
			if (response['data'] === 'No Data Available with this ID') {
				Swal.fire({
					position: 'center',
					type: 'info',
					title: 'No C3Office Available with this Country',
					showConfirmButton: false,
					timer: 1500
				});
			} else {
				this.UserManagement.controls.TblState_ID.patchValue(null);
				this.sStatesData = response;
			}

		});
	}
	async onChangedist(ID: string) {
		this.sDistrtictsData = [];
		this.sC3OfficeData = [];
		this.ms.getC3officeDataByState(ID).subscribe((response) => {
			if (response['data'] === 'No c3Office Available With This ID') {
				Swal.fire({
					position: 'center',
					type: 'info',
					title: 'No C3Office Available with this State',
					showConfirmButton: false,
					timer: 1500
				});

			} else {
				this.UserManagement.controls.TblC3Office_ID.patchValue('');
				this.sC3OfficeData = response;
			}
		});
		this.ms.getDistrictDataByDist(ID).subscribe((response) => {
			if (response['data'] === 'No Data Available with this ID') {
				Swal.fire({
					position: 'center',
					type: 'info',
					title: 'No C3Office Available with this State',
					showConfirmButton: false,
					timer: 1500
				});
			}
			else {
				this.UserManagement.controls.TblDistrict_ID.setValue(null);
				this.sDistrtictsData = response;
			}
		});
	}
	async onChangeC3Office(ID: string) {
		this.sC3OfficeData = [];
		this.ms.getC3officeDataBydist(ID).subscribe((response) => {
			if (response['data'] === 'No c3Office Available With This ID') {
				Swal.fire({
					position: 'center',
					type: 'info',
					title: 'No C3Office Available With this State',
					showConfirmButton: false,
					timer: 1500
				});
			} else {
				this.UserManagement.controls.TblC3Office_ID.patchValue('');
				this.sC3OfficeData = response;
			}
		});
	}


	skipimage() {
		this.imageManagement = !this.imageManagement;
		this.edittype = this.edittype === 'add_circle' ? 'cancel' : 'add_circle';
		this.displayddl = this.editmanagement ? 'inline' : 'none';
		this.displayUsers();
		this.resetForm()
	}

	uploadimage(id) {
		this.getID = id
		this.removeUploadedFile();
		this.fileData = ''
		this.editmanagement = !this.editmanagement;
		this.imageManagement = !this.imageManagement;
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	upimage() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Please Wait...';
		if (this.fileData === {} || this.fileData === null || this.fileData === undefined || this.fileData === "") {
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Please Select image',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		}
		else {
			var formData = new FormData();
			formData.append('user', this.fileData);
			formData.append('farmer', "suresh");
			console.log(formData)
			this.ms.uploadusImage(formData, this.getID).subscribe(res => {
				if (res['data'] === "Successfully Uploaded Images") {
					Swal.fire({
						position: 'center',
						type: 'success',
						title: 'Sucessfully Added',
						showConfirmButton: false,
						timer: 1500
					});
					this.barButtonOptions.active = false;
					this.barButtonOptions.text = 'SUBMIT';
					this.imageManagement = !this.imageManagement;
					this.edittype = this.edittype === 'add_circle' ? 'cancel' : 'add_circle';
					this.displayddl = this.editmanagement ? 'inline' : 'none';
					this.displayUsers();
					this.resetForm()
				}
				else if (res['data'] === 'something gone wrong') {
					Swal.fire({
						position: 'center',
						type: 'warning',
						title: 'Error In Uploading',
						showConfirmButton: false,
						timer: 1500
					});
					this.barButtonOptions.active = false;
					this.barButtonOptions.text = 'SUBMIT';
				}
			})
		}
	}



	createUserManagement() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Please Wait...';
		if (!this.UserManagement.valid) {
			Object.keys(this.UserManagement.controls).forEach((field) => {
				const control = this.UserManagement.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		}
		else {
			Swal.fire({
				title: 'Are you sure?',
				html: `<span style="
				color: red;
			">AdharNumber : ${this.UserManagement.value.AadharNo}</span><br/><br/> <span style="
			color: red;
		">PhoneNumber : ${this.UserManagement.value.PhoneNo}</span> <br/><br/> Is this ok,or would you like to Edit`,
				position: 'center',
				width: 400,
				padding: '0.1em',
				confirmButtonText: 'ok',
				focusConfirm: false,
				showCancelButton: true,
				confirmButtonClass: 'btn btn-success',
				cancelButtonClass: 'btn btn-warning',
				cancelButtonText: 'Edit',
				cancelButtonAriaLabel: 'Edit'
			}).then((result) => {
				this.barButtonOptions.active = false;
				this.barButtonOptions.text = 'SUBMIT';
				if (result.value) {
					//console.log(this.UserManagement.value)
					this.UserManagement.controls.created_by.patchValue('1');
					this.ls.saveUserRoles(this.UserManagement.value).subscribe(
						(res) => {
							//console.log(res)
							if (result.value) {
								this.barButtonOptions.active = true;
								this.barButtonOptions.text = 'Saving Data...';
								if (res['data'] === "Successfully Posted") {
									this.uploadimage(res['userId']);
									this.toastr.success("Successfully Posted");
								}
								else if (res['message'] === "MobileNumber Already exists") {
									this.barButtonOptions.active = false;
									this.barButtonOptions.text = 'SUBMIT';
									this.toastr.warning(`MobileNumber Already exists`)
									this.UserManagement.controls.PhoneNo.patchValue('');
								}
								else if (res['message'] === "Email Already exists") {
									this.barButtonOptions.active = false;
									this.barButtonOptions.text = 'SUBMIT';
									this.toastr.warning(`Email Already exists`)
									this.UserManagement.controls.Email.patchValue('');
								}
								else if (res['message'] === "UserName Already exists") {
									this.barButtonOptions.active = false;
									this.barButtonOptions.text = 'SUBMIT';
									this.toastr.warning(`Username Already exists`)
									this.UserManagement.controls.UserName.patchValue('');
								}

							}
						}

					)
				}
			})
		}
	}



	onBlurmail(data) {
		//console.log(data)
		this.Email = {
			Email: this.UserManagement.value.Email
		}
		if (data.length === 0) {
		}
		else {
			this.ls.checkmail(this.Email).subscribe(response => {
				if (response['message'] === "Email Already exists") {
					this.toastr.warning(`Email Already exists`)
				}
				else if (response['message'] === "Email is ok") {
					this.toastr.success(`Email is ok`)

				}
			})
		}
	}

	onBlurph(data) {
		//console.log(data)
		this.Phone = {
			PhoneNo: this.UserManagement.value.PhoneNo
		}
		if (data.length === 0) {
		}
		else {
			this.ls.checkphone(this.Phone).subscribe(response => {
				if (response['message'] === "PhoneNumber Already exists") {
					this.toastr.warning(`MobileNumber Already exists`)
				}
				else if (response['message'] === "PhoneNumber is ok") {
					this.toastr.success(`MobileNumber is ok`)

				}
			})
		}
	}

	onBluruser(data) {
		//console.log(data)
		this.UserName = {
			UserName: this.UserManagement.value.UserName
		}
		if (data.length === 0) {
		}
		else {
			this.ls.checkuser(this.UserName).subscribe(response => {
				if (response['message'] === "UserName Already exists") {
					this.toastr.warning(`Username Already exists`)
				}
				else if (response['message'] === "UserName is ok") {
					this.toastr.success(`Username is ok`)

				}
			})
		}
	}


	toggleUpdateUserManagement(ID: string) {
		this.filteredRole.next(this.RoleData.slice());
		//console.log('id', ID);
		this.ls.getUserDataByID(ID).subscribe((res) => {
			this.EditUserData = res['data'];
			//console.log('helll', this.EditUserData);
			this.ms.getStatesDataByCountry(this.EditUserData.TblCountry_ID).subscribe((res) => {
				this.sStatesData = res;
			});
			this.ms.getDistrictDataByDist(this.EditUserData.TblState_ID).subscribe((res) => {
				this.sDistrtictsData = res;
			});
			this.ms.getC3officeDataBydist(this.EditUserData.TblDistrict_ID).subscribe((res) => {
				this.sC3OfficeData = res;
			});
			this.UpdateUserManagementForm.patchValue({
				UserName: this.EditUserData.UserName,
				Address: this.EditUserData.Address,
				PhoneNo: this.EditUserData.PhoneNo,
				TblRole1_ID: this.EditUserData.TblRole1_ID,
				TblCountry_ID: this.EditUserData.TblCountry_ID,
				TblState_ID: this.EditUserData.TblState_ID,
				TblDistrict_ID: this.EditUserData.TblDistrict_ID,
				TblC3Office_ID: this.EditUserData.TblC3Office_ID
			});
			//console.log(this.UpdateUserManagementForm.get('TblRole1_ID').value);
		});
		this.updateusermanagement = !this.updateusermanagement;
		this.displayddl = !this.editmanagement ? 'inline' : 'none';
	}

	toggleUpdateUser2() {
		this.EditUserData = [];
		this.updateusermanagement = false;
		this.displayddl = this.editmanagement ? 'inline' : 'block';
	}

	updateUserManagement() {
		//console.log(this.UpdateUserManagementForm.value);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.UpdateUserManagementForm.valid) {
			Object.keys(this.UpdateUserManagementForm.controls).forEach((field) => {
				const control = this.UpdateUserManagementForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Mandatory Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.UpdateUserManagementForm.controls.modified_by.patchValue('1');
			this.ls.updateUserDataById(this.EditUserData.ID, this.UpdateUserManagementForm.value).subscribe(
				(res) => {
					if (
						this.EditUserData.UserName === this.UpdateUserManagementForm.controls.UserName.value &&
						this.EditUserData.Address === this.UpdateUserManagementForm.controls.Address.value &&
						this.EditUserData.PhoneNo === this.UpdateUserManagementForm.controls.PhoneNo.value &&
						this.EditUserData.TblRole1_ID === this.UpdateUserManagementForm.controls.TblRole1_ID.value &&
						this.EditUserData.TblCountry_ID ===
						this.UpdateUserManagementForm.controls.TblCountry_ID.value &&
						this.EditUserData.TblState_ID === this.UpdateUserManagementForm.controls.TblState_ID.value &&
						this.EditUserData.TblDistrict_ID ===
						this.UpdateUserManagementForm.controls.TblDistrict_ID.value &&
						this.EditUserData.TblC3Office_ID ===
						this.UpdateUserManagementForm.controls.TblC3Office_ID.value
					) {
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'No update Found',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
					} else if (res['message'] === 'success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Edited',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayUsers();
						this.toggleUpdateUser2();
					}
				},
				(err) => console.log(err)
			);
		}
	}



	toggleViewUserManagement(ID) {
		this.ls.getUserDataByID(ID).subscribe((res) => {
			this.EditUserData = res['data'];
			//console.log('roles data', this.EditUserData);
			this.roles = this.EditUserData.roles.map(function (roles: { [x: string]: any }) {
				return roles['Role'];
			});
			this.c3offices = this.EditUserData.c3offices.map(function (c3offices: { [x: string]: any }) {
				return c3offices['C3OfficeName']
			})
			//console.log(this.c3offices)
		});
		this.viewusermanagement = !this.viewusermanagement;
		this.displayddl = !this.editmanagement ? 'inline' : 'none';
	}

	toggleViewUserdata1() {
		this.viewusermanagement = false;
		this.displayddl = this.editmanagement ? 'inline' : 'none';
	}

	deleteUserManagement(ID: string) {
		//console.log(ID);
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it AnyWay!',
			confirmButtonClass: 'btn btn-primary',
			cancelButtonClass: 'btn btn-danger'
		}).then((result) => {
			if (result.value) {
				this.ls.deleteUserdataById(ID).subscribe((res) => {
					if ((res['data'] = 'success')) {
						Swal.fire({
							title: 'Deleted!',
							text: 'Your Record has been deleted.',
							type: 'success',
							confirmButtonClass: 'btn btn-success'
						});
						this.displayUsers();
					}
				});
			}
		});
	}
}
