export class User {
	ID?: number;
	FirstName?: string;
	LastName?: string;
	UserName?: any;
	Address?: any;
	PhoneNo?: number;
	TblRole1_ID?: number;
	TblCountry_ID?: number;
	TblState_ID?: number;
	TblDistrict_ID?: number;
	TblC3Office_ID?: number;
	TblMandal_ID?: number;
	TblVillage_ID?: number;
	modified_by?: number;
	user?: any;
}
