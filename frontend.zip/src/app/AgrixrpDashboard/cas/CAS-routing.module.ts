import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RolesComponent } from './roles/roles.component';
import { CASDataComponent } from './CAS.component';
import { RoleactivityComponent } from './roleactivity/roleactivity.component';
import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { ActivitymasterComponent } from './activitymaster/activitymaster.component';
import { ActivitiesComponent } from './activities/activities.component';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';
const routes: Routes = [
	{
		path: '',
		component: CASDataComponent,
		children: [
			{
				path: 'Roles',
				component: RolesComponent, canActivate: [AuthGuardService]
			},
			{
				path: 'Role Activity',
				component: RoleactivityComponent, canActivate: [AuthGuardService]
			},
			{
				path: 'User Management',
				component: UsermanagementComponent, canActivate: [AuthGuardService]
			},
			{
				path: 'Activity Master',
				component: ActivitymasterComponent, canActivate: [AuthGuardService]
			},
			{
				path: 'Activities',
				component: ActivitiesComponent, canActivate: [AuthGuardService]
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class CASRoutingModule { }
