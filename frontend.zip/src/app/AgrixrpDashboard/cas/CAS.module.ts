import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxMatSelectSearchModule } from 'app/AgrixrpDashboard/maincomponents/mat-select-search/ngx-mat-select-search.module';
import { CASRoutingModule } from './CAS-routing.module';
import { CASDataComponent } from './CAS.component';
import { RolesComponent } from './roles/roles.component';
import { RoleactivityComponent } from './roleactivity/roleactivity.component';
import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { ActivitymasterComponent } from './activitymaster/activitymaster.component';
import { ActivitiesComponent } from './activities/activities.component';
import { MaterialModule } from '../material/material.module';
import { MaterialFileInputModule } from 'ngx-material-file-input';

import { NgxSpinnerModule } from "ngx-spinner";
// tslint:disable-next-line:max-line-length
const components = [
	CASDataComponent,
	RolesComponent,
	RoleactivityComponent,
	UsermanagementComponent,
	ActivitymasterComponent,
	ActivitiesComponent
];

@NgModule({
	// tslint:disable-next-line:max-line-length
	imports: [
		NgxSpinnerModule,
		MaterialFileInputModule,
		CASRoutingModule,
		CommonModule,
		RouterModule,
		FormsModule,
		ReactiveFormsModule,
		HttpClientModule,
		MaterialModule,
		NgxMatSelectSearchModule
	],
	schemas: [CUSTOM_ELEMENTS_SCHEMA],
	declarations: [...components]
})
export class CASDataModule { }
