import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleactivityComponent } from './roleactivity.component';

describe('RoleactivityComponent', () => {
  let component: RoleactivityComponent;
  let fixture: ComponentFixture<RoleactivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoleactivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleactivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
