import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { Validators, FormBuilder, FormControl, FormArray, FormGroup } from '@angular/forms';
import { CASService } from '../../../services/cas.service';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Roles } from '../roles/roles.component';
import { SelectionModel } from '@angular/cdk/collections';
import Swal from 'sweetalert2';
import { ActivityMaster } from '../activitymaster/activitymaster.component';
import { rowsAnimation } from 'app/AgrixrpDashboard/maincomponents/animations';
import { NgxSpinnerService } from 'ngx-spinner';

export interface RoleActivity {
	TblRole_ID?: any;
	TblActivityMaster_ID?: any;
	TblActivities?: any;
}

@Component({
	selector: 'app-roleactivity',
	templateUrl: './roleactivity.component.html',
	styleUrls: ['./roleactivity.component.scss'],
	animations: [rowsAnimation],
})
export class RoleactivityComponent implements OnInit {
	UpdtActivityFlsRoles: any;
	UpdtActivityTruRoles: any;
	trueactivities: any[] = [];
	onlyactivities: any[] = [];

	constructor(private formBuilder: FormBuilder, private ls: CASService, private spinner: NgxSpinnerService) { }

	TblActivities: FormArray;
	@Input('matColumnDef') name: string;

	RoleActivityForm = this.formBuilder.group({
		TblRole_ID: ['', [Validators.required]],
		TblActivityMaster_ID: new FormControl(),
		TblActivities: this.formBuilder.array([this.actvt()])
	});

	private actvt(): FormGroup {
		return this.formBuilder.group({
			TblActivity_ID: [''],
			operations: ['']
		});
	}

	RolesType = 'Role Activity';
	editrole = 'add_circle';
	editRoletype = true;
	updateroleactivitytype = false;
	viewroleactivity = false;
	displayddl: string;
	isLoading = false;
	displayNoRecords = false;
	ActivityData: any;
	RoleData: any[];
	ActivityDataByID: any = [];
	TblActivityMaster_ID: FormArray;
	activitydata: any[];
	a: any;
	b: any;
	ActivityDataByID1: any[];
	oldSelectData: [];
	newSelectData: [];
	filterdData: [];
	deletedData: [];
	secretKey: string;
	updatedata: any = [];
	activities: any = [];
	activitiesmaster: any = [];
	UpdtActivityRoles: any = [];
	checkedindata: any[] = [];
	roles: any[];
	hel: any[];
	data2: any[] = [];
	updatedcheckeddata: any[] = [];
	operation: any[] = [];

	listData: MatTableDataSource<any>;
	displayedColumns: string[] = ['S.No', 'Roles', 'Actions'];

	data: any[] = [];

	@ViewChild(MatSort) sort: MatSort;
	@ViewChild(MatPaginator) paginator: MatPaginator;
	userRolesData: any[];

	barButtonOptions: MatProgressButtonOptions = {
		active: false,
		text: 'SUBMIT',
		buttonColor: 'accent',
		barColor: 'primary',
		raised: true,
		mode: 'indeterminate',
		value: 0,
		customClass: 'btn btn-success'
	};

	protected _onDestroy = new Subject<void>();

	/** control for the MatSelect filter keyword */
	public RoleFilterCtrl: FormControl = new FormControl();
	public ActivtyFilterCtrl: FormControl = new FormControl();

	/** list of banks filtered by search keyword */
	public filteredRole: ReplaySubject<Roles[]> = new ReplaySubject<Roles[]>(1);
	public filteredActivty: ReplaySubject<ActivityMaster[]> = new ReplaySubject<ActivityMaster[]>(1);
	activityID: any;

	SendRoles() {
		this.oldSelectData = this.oldSelectData;
		if (this.oldSelectData == undefined) {
			this.oldSelectData = this.RoleActivityForm.value.TblActivityMaster_ID;
			var value = {
				TblActivityMaster_ID: this.oldSelectData
			};
		} else {
			this.newSelectData = this.RoleActivityForm.value.TblActivityMaster_ID;
			this.filterdData = this.newSelectData.filter((d) => !this.oldSelectData.includes(d)) as [];
			this.deletedData = this.oldSelectData.filter((d) => !this.newSelectData.includes(d)) as [];
			this.oldSelectData = this.RoleActivityForm.value.TblActivityMaster_ID;
			// //console.log('delete ids', this.deletedData);
			// //console.log('old ids', this.oldSelectData);
			// //console.log('new ids', this.filterdData.length);
			var value = {
				TblActivityMaster_ID: this.filterdData
			};
		}
		if (value.TblActivityMaster_ID.length > 0) {
			this.ls.getActivitiesByMasterID(value).subscribe((res) => {
				this.ActivityDataByID1 = res;
				for (let i = 0; i < this.ActivityDataByID1.length; i++) {
					this.ActivityDataByID.push(this.convertBools(this.ActivityDataByID1[i]));
				}
				this.data = Object.assign(this.ActivityDataByID);
				this.ActivityRoles = new MatTableDataSource<Element>(this.data.filter((x) => !x.isSelected));
			});
		}
	}

	/*for activities list data */
	ActivityRoles = new MatTableDataSource<Element>(this.data);
	displayedColumns3: string[] = ['select', 'Acivities'];
	selection = new SelectionModel<Element>(true, []);

	checkedData = [];

	/*for selected activity list data */
	checkedDataSource = new MatTableDataSource<Element>(this.checkedData);
	checkedSelection = new SelectionModel<Element>(true, []);
	displayedColumns4: string[] = ['select', 'Acivities', 'option'];
	uncheckedData: any[] = [];

	/** Whether the number of selected elements matches the total number of rows. */
	isAllSelected() {
		const numSelected = this.selection.selected.length;
		const numRows = this.ActivityRoles.data.length;
		return numSelected === numRows;
	}

	isAllCheckedSelected() {
		const numSelected = this.checkedSelection.selected.length;
		const numRows = this.checkedDataSource.data.length;
		return numSelected === numRows;
	}

	/** Selects all rows if they are not all selected; otherwise clear selection. */
	masterToggle() {
		this.isAllSelected()
			? this.selection.clear()
			: this.ActivityRoles.data.forEach((row) => this.selection.select(row));
	}

	masterCheckedToggle() {
		this.isAllCheckedSelected()
			? this.checkedSelection.clear()
			: this.checkedDataSource.data.forEach((row) => this.checkedSelection.select(row));
	}

	/*-------------------------------Function moveToSecondTable( )---------------------------*/

	moveToSecondTable() {
		this.uncheckedData = this.data;
		this.selection.selected.forEach((item) => {
			let index: number = this.uncheckedData.findIndex((d) => d === item);
			this.uncheckedData[index].isSelected = true;
		});
		this.selection = new SelectionModel<Element>(true, []);
		this.ActivityRoles = new MatTableDataSource<Element>(this.uncheckedData.filter((x) => !x.isSelected));
		this.checkedDataSource = new MatTableDataSource<Element>(
			this.uncheckedData.filter((x) => x.isSelected === true)
		);
	}

	/*-------------------------------Function moveToFirstTable( )---------------------------*/
	moveToFirstTable() {
		this.checkedSelection.selected.forEach((item) => {
			let index: number = this.uncheckedData.findIndex((d) => d === item);
			this.uncheckedData[index].isSelected = false;
		});
		this.checkedSelection = new SelectionModel<Element>(true, []);
		this.ActivityRoles = new MatTableDataSource<Element>(this.uncheckedData.filter((x) => !x.isSelected));
		this.checkedDataSource = new MatTableDataSource<Element>(
			this.uncheckedData.filter((x) => x.isSelected === true)
		);
	}

	/*-------------------------------Function TO Update moveToSecondTable( )---------------------------*/

	updateMoveToSecondTable() {
		// if (this.data.length == 0 || this.data.length == undefined) {
		// 	this.uncheckedData = this.data2;
		// }
		if (this.uncheckedData.length == 0 && this.data.length !== 0) {
			this.uncheckedData = this.data;
			for (let i = 0; i < this.checkedindata.length; i++) {
				this.uncheckedData.push(this.checkedindata[i]);
			}
		} else if (this.uncheckedData.length !== 0 && this.data.length !== 0) {
			for (let i = 0; i < this.data.length; i++) {
				if (!this.uncheckedData.includes(this.data[i])) this.uncheckedData.push(this.data[i]);
			}
		}
		this.selection.selected.forEach((item) => {
			let index: number = this.uncheckedData.findIndex((d) => d === item);
			this.uncheckedData[index].isSelected = true;
		});

		this.selection = new SelectionModel<Element>(true, []);
		this.ActivityRoles = new MatTableDataSource<Element>(this.uncheckedData.filter((x) => !x.isSelected));
		this.updatedcheckeddata = this.uncheckedData.filter((x) => x.isSelected === true);
		this.checkedDataSource = new MatTableDataSource<Element>(this.updatedcheckeddata);
	}

	/*-------------------------------Function update moveToFirstTable( )---------------------------*/
	updateMoveToFirstTable() {
		this.checkedSelection.selected.forEach((item) => {
			let index: number = this.uncheckedData.findIndex((d) => d === item);
			this.uncheckedData[index].isSelected = false;
		});
		this.checkedSelection = new SelectionModel<Element>(true, []);
		this.ActivityRoles = new MatTableDataSource<Element>(this.uncheckedData.filter((x) => !x.isSelected));
		this.checkedDataSource = new MatTableDataSource<Element>(
			this.uncheckedData.filter((x) => x.isSelected === true)
		);
	}

	AddRole() {
		this.RolesType = this.RolesType === 'Add Role Activities' ? 'Role Activity' : 'Add Role Activities';
		this.editRoletype = !this.editRoletype;
		this.filteredRole.next(this.RoleData.slice());
		this.filteredActivty.next(this.ActivityData.slice());
		this.editrole = this.editrole === 'cancel' ? 'add_circle' : 'cancel';
		this.displayddl = this.editRoletype ? 'inline' : 'none';
		this.resetForm();
		this.displayRoles();
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
	}

	resetForm() {
		this.RoleActivityForm.reset();
		this.ActivityDataByID = [];
		this.data = [];
		this.data2 = [];
		this.oldSelectData = [];
		this.uncheckedData = [];
		this.updatedata = [];
		this.checkedindata = [];
		this.ActivityRoles = new MatTableDataSource([]);
		this.checkedDataSource = new MatTableDataSource([]);
	}

	displayRoles() {
		this.ls.getAllRoles().subscribe((list) => {
			this.isLoading = false;
			this.userRolesData = list['data'];
			if (this.userRolesData.length === 0) {
				this.displayNoRecords = true;
			} else {
				this.displayNoRecords = false;
			}
			this.listData = new MatTableDataSource(this.userRolesData);
			/* config filter */
			this.listData.filterPredicate = (data: Roles, filter: string) =>
				data.RoleName.toLowerCase().indexOf(filter) !== -1;
			this.listData.sort = this.sort;
			this.listData.paginator = this.paginator;
		});
	}

	applyFilter() {
		this.listData.filter = this.secretKey.trim().toLowerCase();
		if (this.listData.filteredData.length === 0) {
			this.displayNoRecords = true;
		} else {
			this.displayNoRecords = false;
		}
	}
	onSearchClear() {
		this.secretKey = '';
		this.applyFilter();
	}

	ngOnInit() {
		this.displayRoles();

		//operations data
		this.ls.getOpertaions().subscribe((res) => {
			this.operation = res['data'];
		});

		// role data
		this.ls.getAllRoles().subscribe((res) => {
			this.RoleData = res['data'];
		});
		this.RoleFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterRole();
		});
		// role data ends

		// Activity master data
		this.ls.getAllMasterActivities().subscribe((list) => {
			this.ActivityData = list['data'];
		});
		this.ActivtyFilterCtrl.valueChanges.pipe(takeUntil(this._onDestroy)).subscribe(() => {
			this.filterActivity();
		});
		// avtivity master data ends
	}

	/*Role data*/
	protected filterRole() {
		if (!this.RoleData) {
			return;
		}
		// get the search keyword
		let search = this.RoleFilterCtrl.value;

		if (!search) {
			this.filteredRole.next(this.RoleData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredRole.next(this.RoleData.filter((bank) => bank.RoleName.toLowerCase().indexOf(search) > -1));
	}
	/*Role data ends*/

	/*Activity data*/
	protected filterActivity() {
		if (!this.ActivityData) {
			return;
		}
		// get the search keyword
		let search = this.ActivtyFilterCtrl.value;
		if (!search) {
			this.filteredActivty.next(this.ActivityData.slice());
			return;
		} else {
			search = search.toLowerCase();
		}
		// filter the banks
		this.filteredActivty.next(
			this.ActivityData.filter((bank) => bank.ActyMasterName.toLowerCase().indexOf(search) > -1)
		);
	}
	/*Role data ends*/

	change(event) {
		this.TblActivityMaster_ID = this.RoleActivityForm.get('TblActivityMaster_ID') as FormArray;

		if (event.checked) {
			this.TblActivityMaster_ID.push(new FormControl(event.source.value));
		} else {
			const i = this.TblActivityMaster_ID.controls.findIndex((x) => x.value === event.source.value);
			this.TblActivityMaster_ID.removeAt(i);
		}
	}

	setAssessmentLevel(element, value) {
		this.activitydata = this.checkedDataSource.data;
		this.activitydata[this.activitydata.indexOf(element)] = {
			...element,
			operations: value
		};
	}

	CreateRoles() {
		// this.activitydata = this.checkedDataSource.data;
		// //console.log('khgjhghj', this.activitydata);
		// this.a = this.activitydata.map(function(a) {
		// 	return a['ID'];
		// });
		// this.b = this.activitydata.map(function(b) {
		// 	return b['operations'];
		// });
		// //console.log(this.RoleActivityForm.get('TblActivities'));
		// for (let i = 0; i < this.a.length; i++) {
		// 	if (this.RoleActivityForm.get('TblActivities').value[0].TblActivity_ID == null) {
		// 		this.RoleActivityForm.get('TblActivities').value[i].TblActivity_ID = this.a[i];
		// 		this.RoleActivityForm.get('TblActivities').value[i].operations = this.b[i];
		// 	} else {
		// 		this.RoleActivityForm.get('TblActivities').value.push({
		// 			TblActivity_ID: this.a[i],
		// 			operations: this.b[i]
		// 		});
		// 	}
		// }
		// //console.log(this.RoleActivityForm.value);
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.RoleActivityForm.valid) {
			Object.keys(this.RoleActivityForm.controls).forEach((field) => {
				const control = this.RoleActivityForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.activitydata = this.checkedDataSource.data;
			this.a = this.activitydata.map(function (a) {
				return a['ID'];
			});
			this.b = this.activitydata.map(function (b) {
				return b['operations'];
			});
			for (let i = 0; i < this.a.length; i++) {
				if (this.RoleActivityForm.get('TblActivities').value[0].TblActivity_ID == null) {
					this.RoleActivityForm.get('TblActivities').value[i].TblActivity_ID = this.a[i];
					this.RoleActivityForm.get('TblActivities').value[i].operations = this.b[i];
				} else {
					this.RoleActivityForm.get('TblActivities').value.push({
						TblActivity_ID: this.a[i],
						operations: this.b[i]
					});
				}
			}
			this.ls.saveRoleActivity(this.RoleActivityForm.value).subscribe(
				(res) => {
					if (res['message'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully added Role',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.resetForm();
						this.displayRoles();
						this.AddRole();
					} else if ((res['data'] = 'Role is already exists!')) {
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						Swal.fire({
							position: 'center',
							type: 'info',
							title: 'Already Exists The Role Name',
							showConfirmButton: false,
							timer: 1500
						});
					}
				},
				(err) => console.error(err)
			);
		}
	}

	convertBools(obj) {
		const newObj = {};

		if (typeof obj !== 'object') {
			return obj;
		}

		for (const prop in obj) {
			if (!obj.hasOwnProperty(prop)) {
				continue;
			}
			if (Array.isArray(obj[prop])) {
				newObj[prop] = obj[prop].map((val) => this.convertBools(val));
			} else if (obj[prop] === 'true') {
				newObj[prop] = true;
			} else if (obj[prop] === 'false') {
				newObj[prop] = false;
			} else {
				newObj[prop] = this.convertBools(obj[prop]);
			}
		}

		return newObj;
	}

	toggleUpdateRoleName(id: string) {

		this.ActivityRoles = new MatTableDataSource([]);
		this.checkedDataSource = new MatTableDataSource([]);
		this.filteredRole.next(this.RoleData.slice());
		this.filteredActivty.next(this.ActivityData.slice());
		this.UpdtActivityRoles = [];
		this.UpdtActivityTruRoles = [];
		this.UpdtActivityFlsRoles = [];
		this.uncheckedData = [];
		this.spinner.show();
		this.ls.getActivitiesByRoleID(id).subscribe((res) => {
			this.updatedata = res['data'];
			this.spinner.hide();
			for (let i = 0; i < this.updatedata.Activities.length; i++) {
				this.UpdtActivityRoles.push(this.convertBools(this.updatedata.Activities[i]));
				if (this.updatedata.Activities[i].isSelected == 'false') {
					this.UpdtActivityFlsRoles.push(this.convertBools(this.updatedata.Activities[i]));
				} else {
					this.UpdtActivityTruRoles.push(this.convertBools(this.updatedata.Activities[i]));
				}
			}
			this.data2 = Object.assign(this.UpdtActivityRoles);
			this.uncheckedData = this.data2;
			this.checkedDataSource = new MatTableDataSource<Element>(this.data2.filter((x) => x.isSelected));
			this.ActivityRoles = new MatTableDataSource<Element>(this.data2.filter((x) => !x.isSelected));
			for (let i = 0; i < this.ActivityRoles.filteredData.length; i++) {
				this.ActivityDataByID.push(this.ActivityRoles.filteredData[i]);
			}
			for (let i = 0; i < this.checkedDataSource.filteredData.length; i++) {
				this.checkedindata.push(this.checkedDataSource.filteredData[i]);
			}
			for (let i = 0; i < this.checkedindata.length; i++) {
				this.RoleActivityForm.get('TblActivities').value[0].operations = this.checkedindata[0].operations;
			}

			this.activities = this.updatedata.ActivityMaster.map(function (activities) {
				return activities['ID'];
			});

			this.activitiesmaster = this.updatedata.ActivityMaster.map(function (activitiesmaster) {
				return activitiesmaster['ID'];
			});
			this.oldSelectData = this.activitiesmaster;

			this.RoleActivityForm.patchValue({
				TblRole_ID: this.updatedata.RoleID,
				TblActivityMaster_ID: this.activities
			});
			for (let role of this.userRolesData) {
				if (role.ID === this.updatedata.RoleID) {
					this.updatedata.RoleID = role.RoleName;
				}
			}
		});
		this.updateroleactivitytype = !this.updateroleactivitytype;
		this.displayddl = !this.editRoletype ? 'inline' : 'none';


	}

	closeUpdateAactivities() {
		this.data = [];
		this.data2 = [];
		this.oldSelectData = [];
		this.ActivityDataByID = [];
		this.uncheckedData = [];
		this.updatedata = [];
		this.checkedindata = [];
		this.ActivityRoles = new MatTableDataSource([]);
		this.checkedDataSource = new MatTableDataSource([]);
		this.updateroleactivitytype = false;
		this.barButtonOptions.active = false;
		this.barButtonOptions.text = 'SUBMIT';
		this.displayddl = this.editRoletype ? 'inline' : 'block';
	}

	updateRoleActivities() {
		this.barButtonOptions.active = true;
		this.barButtonOptions.text = 'Saving Data...';
		if (!this.RoleActivityForm.valid) {
			Object.keys(this.RoleActivityForm.controls).forEach((field) => {
				const control = this.RoleActivityForm.get(field);
				control.markAsTouched({ onlySelf: true });
			});
			Swal.fire({
				position: 'center',
				type: 'info',
				title: 'Fill The Required Fields',
				showConfirmButton: false,
				timer: 1500
			});
			this.barButtonOptions.active = false;
			this.barButtonOptions.text = 'SUBMIT';
		} else {
			this.activitydata = this.checkedDataSource.data;
			this.a = this.activitydata.map(function (a) {
				return a['ID'];
			});
			this.b = this.activitydata.map(function (b) {
				return b['operations'];
			});
			for (let i = 0; i < this.a.length; i++) {
				if (this.RoleActivityForm.get('TblActivities').value[0].TblActivity_ID == 0) {
					this.RoleActivityForm.get('TblActivities').value[i].TblActivity_ID = this.a[i];
					this.RoleActivityForm.get('TblActivities').value[i].operations = this.b[i];
				} else {
					this.RoleActivityForm.get('TblActivities').value.push({
						TblActivity_ID: this.a[i],
						operations: this.b[i]
					});
				}
			}
			this.ls.updateRoleActivitiesById(this.updatedata.RoleID, this.RoleActivityForm.value).subscribe(
				(res) => {
					if (res['message'] === 'Success') {
						Swal.fire({
							position: 'center',
							type: 'success',
							title: 'Sucessfully Updated',
							showConfirmButton: false,
							timer: 1500
						});
						this.barButtonOptions.active = false;
						this.barButtonOptions.text = 'SUBMIT';
						this.displayRoles();
						this.closeUpdateAactivities();
					}
				},
				(err) => console.log(err)
			);
		}
	}

	toggleViewRoleName(ID) {
		this.ls.getActivitiesByRoleID(ID).subscribe((res) => {
			this.updatedata = res['data'];
			this.UpdtActivityRoles = [];
			this.UpdtActivityTruRoles = [];
			this.UpdtActivityFlsRoles = [];
			for (let i = 0; i < this.updatedata.Activities.length; i++) {
				this.UpdtActivityRoles.push(this.convertBools(this.updatedata.Activities[i]));
				if (this.updatedata.Activities[i].isSelected == 'false') {
					this.UpdtActivityFlsRoles.push(this.convertBools(this.updatedata.Activities[i]));
				} else {
					this.UpdtActivityTruRoles.push(this.convertBools(this.updatedata.Activities[i]));
				}
			}
			this.onlyactivities = Object.assign(this.UpdtActivityRoles);
			console.log(this.onlyactivities)
			this.trueactivities = this.onlyactivities.filter((x) => x.isSelected);
			console.log(this.trueactivities)
			this.activities = this.trueactivities.map(function (activities) {
				return activities['ActyName'];
			});
			console.log(this.activities)
			this.b = this.updatedata.ActivityMaster.map(function (b) {
				return b['ActyMasterName'];
			});
			console.log(this.b)
		});
		this.viewroleactivity = !this.viewroleactivity;
		this.displayddl = !this.editRoletype ? 'inline' : 'none';
	}

	toggleCloseView() {
		this.updatedata = [];
		this.activities = [];
		this.b = [];
		this.viewroleactivity = false;
		this.displayddl = this.editRoletype ? 'inline' : 'none';
	}
}
