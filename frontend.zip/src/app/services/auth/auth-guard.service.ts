import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CASService } from '../cas.service';
import { UserActy } from './user';

@Injectable({
    providedIn: 'root'
})
export class AuthGuardService implements CanActivate {
    constructor(
        private authService: AuthService,
        private router: Router,
        private readonly userActy: UserActy,
        private readonly casService: CASService
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        var endPath = route.routeConfig.path;
        //console.log('this is Auth Guard ', route.routeConfig.path, 'this is state ', state);
        if (!this.authService.isAuthenticated()) {
            this.userActy.logout();
            alert('Session expired Please login to continue....');
            this.router.parseUrl('/Login');
            return false;
        } else {
            const data = this.casService.isActivities([endPath]);
            //console.log(data);
            if (data === true) {
                return true;
            } else {
                alert('UnAuthorized Access');
                return false;
            }
        }
        return true;
    }
}