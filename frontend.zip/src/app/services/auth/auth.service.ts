import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { UserActy } from './user';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    constructor(private jwtHelper: JwtHelperService, private readonly serr: UserActy) { }

    isAuthenticated(): Boolean {
        const tokensssss = this.serr.getToken();
        //console.log(' checking token', !this.jwtHelper.isTokenExpired(tokensssss));
        return !this.jwtHelper.isTokenExpired(tokensssss);
    }
}