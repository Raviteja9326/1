import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
    providedIn: 'root'
})

export class UserActy {
    fullData: any;
    userDetails: any;
    activities: string[];
    masterActy: string[];
    token: string;
    asasas: string;
    constructor(private router: Router) { }
    getdata(fullData, activities, masterActy, token, userDetails) {
        this.fullData = fullData;
        this.token = token;
        this.masterActy = masterActy;
        this.activities = activities;
        this.userDetails = userDetails;

    }

    getFullData() {
        return this.fullData;
    }

    getuserdetails() {
        return this.userDetails;
    }

    getToken() {
        return this.token;
    }
    getActivitiesWithout() {
        return this.activities;
    }
    getMasterActivitiesWithout() {
        return this.masterActy;
    }
    getActivities() {
        this.asasas = this.activities.toString();
        return this.asasas;
    }
    getMasterActivites() {
        this.asasas = this.masterActy.toString();
        return this.asasas;
    }

    logout() {
        this.token = '';
        this.activities = [];
        this.masterActy = [];
        this.router.navigate(['/Login']);
    }

    getActivitiesFor = () => {
        const output = this.fullData.map((element) => {
            return element.ActivityMaster.map((ele) => {
                return ele.Activities;
            });
        });

		/*
		This Method Wont Support ON IE So Iam not using :) srinivas
		return output.flat(Infinity);
		*/
        const final = [].concat(...output);
        return [].concat(...final);
    };
}