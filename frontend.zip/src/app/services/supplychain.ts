import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Soil } from 'app/AgrixrpDashboard/onBoarding/SoilData/soiltype/Soil';
import { Watercategory } from 'app/AgrixrpDashboard/onBoarding/WaterTestData/watercategory/Watercategory';
import { Nutrient } from 'app/AgrixrpDashboard/onBoarding/SoilData/soilnutrients/Nutrients';
import { Category } from 'app/AgrixrpDashboard/onBoarding/SoilData/soilcat/Category';
import { WaterMaster } from 'app/AgrixrpDashboard/onBoarding/WaterTestData/watermaster/watermaster';
import { FollowUp } from 'app/AgrixrpDashboard/supplychain/Prerequisites/correction followup/correctionsfollowup/correctionsfollowup.component';
import { Soiltestinfo } from 'app/AgrixrpDashboard/onBoarding/SoilData/soiltestdata/soiltestdata.component';
import { SoilCorrectionvalue } from 'app/AgrixrpDashboard/onBoarding/SoilData/soiltestcorrections/soiltestcorrections.component';
export const API_URl = "http://139.59.67.91:3200";
@Injectable({
	providedIn: 'root'
})
export class supplychain {

	constructor(private http: HttpClient) { }

	// SoilType service

	saveSoilType(soil): Observable<any[]> {
		//console.log(soil);
		return this.http.post<any[]>(`${API_URl}/soiltype/create`, soil);
	}

	getSoilTypeData(): Observable<any[]> {
		//console.log();
		return this.http.get<any[]>(`${API_URl}/soiltype/all`);
	}

	getSoilTypeId(id: string): Observable<any[]> {
		//console.log(id);
		return this.http.get<any[]>(`${API_URl}/soiltype/${id}`);
	}

	updateSoilTypeById(id: string | number, updatedSoil: Soil): Observable<Soil[]> {
		//console.log(updatedSoil);
		return this.http.put<Soil[]>(`${API_URl}/soiltype/update/${id}`, updatedSoil);
	}

	deleteSoilTypeById(id: string): Observable<any[]> {
		//console.log();
		return this.http.delete<any[]>(`${API_URl}/soiltype/delete/${id}`);
	}

	// SoilCategory services

	getSoilCatData(): Observable<any[]> {
		//console.log();
		return this.http.get<any[]>(`${API_URl}/soilcategory/all`);
	}

	saveSoilCatType(category): Observable<any[]> {
		//console.log(category);
		return this.http.post<any[]>(`${API_URl}/soilcategory/create`, category);
	}

	getSoilCatId(id: string): Observable<any[]> {
		//console.log(id);
		return this.http.get<any[]>(`${API_URl}/soilcategory/${id}`);
	}

	updateSoilCatById(id: string | number, updatedCat: Category): Observable<Category[]> {
		//console.log(updatedCat);
		return this.http.put<Category[]>(`${API_URl}/soilcategory/update/${id}`, updatedCat);
	}

	deleteSoilCatById(id: string): Observable<any[]> {
		//console.log();
		return this.http.delete<any[]>(`${API_URl}/soilcategory/delete/${id}`);
	}

	// SoilNutrients

	getSoilNutData(): Observable<any[]> {
		//console.log();
		return this.http.get<any[]>(`${API_URl}/soilnutrient/all`);
	}

	savesoilnut(nutrient): Observable<any[]> {
		//console.log(nutrient);
		return this.http.post<any[]>(`${API_URl}/soilnutrient/create`, nutrient);
	}

	getSoilNutId(id: string): Observable<any[]> {
		//console.log(id);
		return this.http.get<any[]>(`${API_URl}/soilnutrient/${id}`);
	}

	updateSoilNutById(id: string | number, updatedNut: Nutrient): Observable<Nutrient[]> {
		//console.log(updatedNut);
		return this.http.put<Nutrient[]>(`${API_URl}/soilnutrient/update/${id}`, updatedNut);
	}

	deleteSoilNutById(id: string): Observable<any[]> {
		//console.log();
		return this.http.delete<any[]>(`${API_URl}/soilnutrient/delete/${id}`);
	}

	// WaterCategory services

	getWaterCatData(): Observable<any[]> {
		//console.log();
		return this.http.get<any[]>(`${API_URl}/watercategory/all`);
	}

	saveWaterCatData(watercategory): Observable<any[]> {
		//console.log(watercategory);
		return this.http.post<any[]>(`${API_URl}/watercategory/create`, watercategory);
	}

	getWaterCatById(id: string): Observable<any[]> {
		//console.log(id);
		return this.http.get<any[]>(`${API_URl}/watercategory/${id}`);
	}

	updateWaterCatDataById(id: string | number, updatedCat: Watercategory): Observable<Watercategory[]> {
		//console.log(updatedCat);
		return this.http.put<Watercategory[]>(`${API_URl}/watercategory/update/${id}`, updatedCat);
	}

	deleteWaterCatDataById(id: string): Observable<any[]> {
		//console.log();
		return this.http.delete<any[]>(`${API_URl}/watercategory/delete/${id}`);
	}

	// WaterMaster Source services

	getAllWaterCatData(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/watercategory/all`);
	}

	getWaterMasterData(): Observable<any[]> {
		//console.log();
		return this.http.get<any[]>(`${API_URl}/watermaster/all`);
	}

	savewatermasterdata(waterMaster): Observable<any[]> {
		//console.log(waterMaster);
		return this.http.post<any[]>(`${API_URl}/watermaster/create`, waterMaster);
	}

	updateWaterMasterById(id: string | number, updatedmaster: WaterMaster): Observable<WaterMaster[]> {
		//console.log(updatedmaster);
		return this.http.put<WaterMaster[]>(`${API_URl}/watermaster/update/${id}`, updatedmaster);
	}

	deleteWaterMasterById(id: string): Observable<any[]> {
		//console.log();
		return this.http.delete<any[]>(`${API_URl}/watermaster/delete/${id}`);
	}

	//for soiltestdata details

	getSoilTestData(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/soiltestdata/all`);
	}

	getSoilTestDataByID(id: string): Observable<any[]> {
		////console.log('this',id);
		return this.http.get<any[]>(`${API_URl}/soiltestdata/${id}`);
	}

	saveSoilTestData(soiltestdata): Observable<any[]> {
		//console.log(soiltestdata);
		return this.http.post<any[]>(`${API_URl}/soiltestdata/create`, soiltestdata);
	}

	deleteSoilTestdataById(id: string): Observable<any[]> {
		return this.http.delete<any[]>(`${API_URl}/soiltestdata/delete/${id}`);
	}

	updateSoilTestDataById(id: string | number, updateddata: Soiltestinfo): Observable<Soiltestinfo> {
		//console.log('from service', updateddata);
		return this.http.put<Soiltestinfo>(`${API_URl}/soiltestdata/update/${id}`, updateddata);
	}

	//SoilCorrective data service

	saveSoilCorrectiveData(SoilCorrectivedata): Observable<any[]> {
		//console.log('posting data', SoilCorrectivedata);
		return this.http.post<any[]>(`${API_URl}/SoilCorrectiveActions/create`, SoilCorrectivedata);
	}

	getTestSoilDataByID(id: string): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/SoilCorrectiveActions/SoiltestdataByID/${id}`);
	}

	deleteSoilCorrectivedataById(id: string): Observable<any[]> {
		////console.log('this is service id =',id)
		return this.http.delete<any[]>(`${API_URl}/SoilCorrectiveActions/delete/${id}`);
	}

	getSoilCorrectiveActionByID(id: string): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/SoilCorrectiveActions/${id}`);
	}

	updateCorrectiveActionByID(id: string | number, updateddata: SoilCorrectionvalue): Observable<SoilCorrectionvalue> {
		//console.log('after update the values', updateddata);
		return this.http.put<SoilCorrectionvalue>(`${API_URl}/SoilCorrectiveActions/update/${id}`, updateddata);
	}

	//for correctionfollowup service

	getAllCorrectionFollowupData(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/CorrectionFollowUpData/all`);
	}

	saveCorrectionFollowUpData(correctionfollowupdata): Observable<any[]> {
		//console.log('service Data', correctionfollowupdata);
		return this.http.post<any[]>(`${API_URl}/CorrectionFollowUpData/create`, correctionfollowupdata);
	}

	updateCorrectionFollowUpById(id: string | number, updateddata: FollowUp): Observable<FollowUp> {
		//console.log('after update the values', updateddata);
		return this.http.put<FollowUp>(`${API_URl}/CorrectionFollowUpData/update/${id}`, updateddata);
	}

	deleteCorrectionfollowUpDataById(id: string): Observable<any> {
		//console.log('id from service file =', id);
		return this.http.delete<any[]>(`${API_URl}/CorrectionFollowUpData/delete/${id}`);
	}
}
