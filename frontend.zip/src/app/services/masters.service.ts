import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { Country } from "../AgrixrpDashboard/onBoarding/Masters/country/country";
import { States } from "../AgrixrpDashboard/onBoarding/Masters/states/states";
import { Districts } from "../AgrixrpDashboard/onBoarding/Masters/districts/districts";
import { Mandals } from "../AgrixrpDashboard/onBoarding/Masters/mandals/mandals";
import { Revenue } from "../AgrixrpDashboard/onBoarding/Masters/revenue/revenue";
import { Villages } from "../AgrixrpDashboard/onBoarding/Masters/villages/villages";
import { Villagesarpanch } from "../AgrixrpDashboard/onBoarding/Masters/villagesarpanch/villagesarpanch";
import { tap } from "rxjs/operators";
import { Animalcategory } from '../AgrixrpDashboard/onBoarding/AnimalData/animalcategory/Animalcategory';
import { Animalbreed } from '../AgrixrpDashboard/onBoarding/AnimalData/animalbreed/Animalbreed';
import { Animalmaster } from '../AgrixrpDashboard/onBoarding/AnimalData/animalmaster/Animalmaster';
import { VermincompostCOP } from '../AgrixrpDashboard/onBoarding/AssetManagement/Construction/vermincompost-cop-master/vermincompostcop';
import { VermicompostPITMaster } from '../AgrixrpDashboard/onBoarding/AssetManagement/Construction/vermincompost-pit-master/vermicompostpitmaster';
// tslint:disable-next-line: max-line-length
import { VermicompostCycle } from '../AgrixrpDashboard/onBoarding/AssetManagement/Construction/vermincompost-cycle-master/vermicompost-cycle-master';
import { Fertilizer } from '../AgrixrpDashboard/onBoarding/FarmData/FertilizersAndPestControl/fertilizers/fertilizer';
import { PestControl } from '../AgrixrpDashboard/onBoarding/FarmData/FertilizersAndPestControl/pestcontrol/Pestcontrol';
import { Vaccination } from '../AgrixrpDashboard/onBoarding/AnimalData/vaccination/Vaccination';
import { Companymaster } from '../AgrixrpDashboard/onBoarding/FarmData/FertilizersAndPestControl/companymaster/Companymaster';
import { Cropcategory } from '../AgrixrpDashboard/onBoarding/CropData/cropcat/cropcatgory';
import { CropMaster } from '../AgrixrpDashboard/onBoarding/CropData/cropmast/cropmaster';
import { CropCycle } from '../AgrixrpDashboard/onBoarding/CropData/cropcycle/cropcycle';
import { Labour } from '../AgrixrpDashboard/onBoarding/FarmerData/labourinformation/Labour';
import { Animalhistory } from '../AgrixrpDashboard/onBoarding/AnimalData/animalhistory/Animalhistory';
import { Labourhours } from '../AgrixrpDashboard/onBoarding/Miscellaneous/labourhours/labourhours';
import { MiscellaneousExpenses } from '../AgrixrpDashboard/onBoarding/Miscellaneous/miscellaneousexpenses/miscllaneousexpenses';
import { DealerInformation } from '../AgrixrpDashboard/onBoarding/Raw Material/dealersinformation/dealerinformation';
import { RawMaterialStockData } from '../AgrixrpDashboard/onBoarding/Raw Material/rawmaterialstock/rawmaterialstock';
import { Inventory } from '../AgrixrpDashboard/onBoarding/Raw Material/inventory/inventory';
import { BOM } from '../AgrixrpDashboard/onBoarding/Raw Material/billofmaterials/billofmaterial.component';
import { Soil } from '../AgrixrpDashboard/onBoarding/SoilData/soiltype/Soil';
import { Category } from '../AgrixrpDashboard/onBoarding/SoilData/soilcat/Category';
import { Nutrient } from '../AgrixrpDashboard/onBoarding/SoilData/soilnutrients/Nutrients';
import { Watercategory } from '../AgrixrpDashboard/onBoarding/WaterTestData/watercategory/Watercategory';
import { WaterMaster } from '../AgrixrpDashboard/onBoarding/WaterTestData/watermaster/watermaster';
import { CropCop } from '../AgrixrpDashboard/onBoarding/CropData/CropCop/cropcop';
import { AnimalCop } from 'app/AgrixrpDashboard/onBoarding/AnimalData/animalcop/animalcop';
import { CropCopRawmaterial } from 'app/AgrixrpDashboard/onBoarding/CropData/CropCop/cropcoprawmaterial';
import { AnimalDisease } from 'app/AgrixrpDashboard/onBoarding/DiseasData/animaldiseasemanagement/animaldisease';
import { Disease } from 'app/AgrixrpDashboard/onBoarding/DiseasData/diseasetype/diseasetype';
import { CropReportDisease } from 'app/AgrixrpDashboard/onBoarding/DiseasData/crop-report-disease/crop-report-disease';
import { AnimalReportDisease } from 'app/AgrixrpDashboard/onBoarding/DiseasData/animalreportdisease/animalreportdisease';
import { CropDisease } from 'app/AgrixrpDashboard/onBoarding/DiseasData/crop-disease-management/crop-disease';
import { Shed } from './Dataservices';
import { ConsultExpert } from 'app/AgrixrpDashboard/onBoarding/DiseasData/consultexpert/consultexpert';
import { C3office } from 'app/AgrixrpDashboard/onBoarding/Masters/c3office/c3office';
import { Landlayout } from 'app/AgrixrpDashboard/onBoarding/FarmerData/landlayout/landlayout';
import { Plotting } from 'app/AgrixrpDashboard/onBoarding/FarmerData/plotting/plotting';
import { Croplanes } from 'app/AgrixrpDashboard/onBoarding/FarmerData/croplanes/croplanes';
import { Loan } from 'app/AgrixrpDashboard/onBoarding/FarmerData/loanhistory/loanhistory';
import { LoanEMI } from 'app/AgrixrpDashboard/onBoarding/FarmerData/loan-emi/loanemi';
import { Irrigation } from 'app/AgrixrpDashboard/onBoarding/FarmerData/irrigation/irrigation';
import { Farmer } from 'app/AgrixrpDashboard/onBoarding/FarmerData/farmerinfo/farmerinfo';
export const API_URl = "http://139.59.67.91:3200";
@Injectable({
  providedIn: "root"
})
export class MastersService {

  opts = [];

  // vaccination data service
  optcat = [];

  constructor(private http: HttpClient) { }
  getISOCodes(): Observable<any[]> {
    return this.opts.length
      ? of(this.opts)
      : this.http
        .get<any[]>(`${API_URl}/isocodes/all`)
        .pipe(tap(data => (this.opts = data)));
  }

  getISOCode(): Observable<any[]> {
    return this.http
      .get<any[]>(`${API_URl}/isocodes/all`);
  }

  // Countries opertions

  getCountriesData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/countries/all`);
  }

  getCountriesDataById(id: string): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/countries/${id}`);
  }

  saveCountriesData(country: Country): Observable<any[]> {

    const data = {
      CountryName: country.CountryName,
      CountryCode: "+" + country.CountryCode,
      ISOCode: country.ISOCode.toUpperCase()
    };
    return this.http.post<any[]>(`${API_URl}/countries/create`, data);
  }

  deleteCountriesDataById(id: string): Observable<any[]> {

    return this.http.delete<any[]>(`${API_URl}/countries/delete/${id}`);
  }

  updateCountriesDataById(
    id: string | number,
    updatedCountry: Country
  ): Observable<Country[]> {
    return this.http.put<Country[]>(
      `${API_URl}/countries/update/${id}`,
      updatedCountry
    );
  }

  // Currency opertions

  getCurrencyData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/currency/all`);
  }

  getCurrencyDataById(id: string): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/currency/${id}`);
  }

  saveCurrencyData(currency): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/currency/create`, currency);
  }

  deleteCurrencyDataById(id: string): Observable<any[]> {

    return this.http.delete<any[]>(`${API_URl}/currency/delete/${id}`);
  }

  updateCurrencyDataById(id: string | number, updatedCurrency) {
    return this.http.put(
      `${API_URl}/currency/update/${id}`,
      updatedCurrency
    );
  }

  // C3office operations

  getC3officeData(): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/c3office/all`);
  }

  getC3officeDataByID(id: string): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/c3office/${id}`);
  }

  getC3officeDataBydist(id: string): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/c3office/getC3OfficeByDistrictId/${id}`);
  }
  getC3officeDataByCountry(id: string): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/c3office/getC3OfficeByCountryId/${id}`);
  }
  getC3officeDataByState(id: string): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/c3office/getC3OfficeByStateId/${id}`);
  }

  saveC3officeData(c3office): Observable<any[]> {
    //console.log(c3office);
    return this.http.post<any[]>(`${API_URl}/c3office/create`, c3office);
  }

  deleteC3officeDataById(id: string): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/c3office/delete/${id}`);
  }

  updateC3officeDataById(id: string | number, updatedc3office: C3office): Observable<C3office[]> {
    //console.log();
    return this.http.put<C3office[]>(`${API_URl}/c3office/update/${id}`, updatedc3office);
  }

  // states operations

  getStatesData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/states/all`);
  }

  getStatesDataByID(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/states/${id}`);
  }

  getStatesDataByCountry(id: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_URl}/states/getStatesByCountryID/${id}`
    );
  }

  saveStatesData(states: States): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/states/create`, states);
  }

  deleteStatesDataById(id: string): Observable<any[]> {

    return this.http.delete<any[]>(`${API_URl}/states/delete/${id}`);
  }

  updateStatesDataById(
    id: string | number,
    updatedStates: States
  ): Observable<States[]> {
    return this.http.put<States[]>(
      `${API_URl}/states/update/${id}`,
      updatedStates
    );
  }

  // Districts operations

  getDistrictsData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/districts/all`);
  }

  getDistrictsDataByID(id: string): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/districts/${id}`);
  }

  getDistrictDataByDist(id: string): Observable<any[]> {

    return this.http.get<any[]>(
      `${API_URl}/districts/getDistrictsByStateID/${id}`
    );
  }

  saveDistrictsData(districts: Districts): Observable<any[]> {
    const data = {
      DistrictName: districts.DistrictName,
      DistrictCollector: districts.DistrictCollector.toLowerCase() + ", IAS",
      TblState_TblCountry_CountryID: districts.TblState_TblCountry_CountryID,
      TblState_StateID: districts.TblState_StateID
    };
    return this.http.post<any[]>(`${API_URl}/districts/create`, data);
  }

  deleteDistrictsDataById(id: string): Observable<any[]> {

    return this.http.delete<any[]>(`${API_URl}/districts/delete/${id}`);
  }

  updateDistrictsDataById(
    id: string | number,
    updateddistricts: Districts
  ): Observable<Districts[]> {

    return this.http.put<Districts[]>(
      `${API_URl}/districts/update/${id}`,
      updateddistricts
    );
  }

  // mandals operations

  getMandalsData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/mandals/all`);
  }

  getMandalsDataByID(id: string): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/mandals/${id}`);
  }

  getMandalsDataBydist(id: string): Observable<any[]> {

    return this.http.get<any[]>(
      `${API_URl}/mandals/getMandalsByDistrictID/${id}`
    );
  }
  getMandalsDataByc3(id: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_URl}/mandals/getMandalsByC3OfficeID/${id}`
    );
  }

  saveMandalsData(mandals: Mandals): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/mandals/create`, mandals);
  }

  deleteMandalsDataById(id: string): Observable<any[]> {

    return this.http.delete<any[]>(`${API_URl}/mandals/delete/${id}`);
  }

  updateMandalsDataById(
    id: string | number,
    updatedmandals: Mandals
  ): Observable<Mandals[]> {

    return this.http.put<Mandals[]>(
      `${API_URl}/mandals/update/${id}`,
      updatedmandals
    );
  }


  // revenue operations

  getRevenueData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/revenuedivision/all`);
  }

  getrevenueDataByID(id: string): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/revenuedivision/${id}`);
  }

  saverevenueData(revenue: Revenue): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/revenuedivision/create`,
      revenue
    );
  }

  deleterevenueDataById(id: string): Observable<any[]> {

    return this.http.delete<any[]>(
      `${API_URl}/revenuedivision/delete/${id}`
    );
  }

  updaterevenueDataById(
    id: string | number,
    updatedrevenue: Revenue
  ): Observable<Revenue[]> {

    return this.http.put<Revenue[]>(
      `${API_URl}/revenuedivision/update/${id}`,
      updatedrevenue
    );
  }

  // villages operations

  getVillagesData(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/villages/all`);
  }

  getVillagesDataByID(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/villages/${id}`);
  }
  getVillagesDataByMandalID(id: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_URl}/villages/getVillagesByMandalID/${id}`
    );
  }
  saveVillagesData(villages: Villages): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/villages/create`, villages);
  }

  deleteVillagesDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/villages/delete/${id}`);
  }

  updateVillagesDataById(
    id: string | number,
    updatedvillages: Villages
  ): Observable<Villages[]> {
    return this.http.put<Villages[]>(
      `${API_URl}/villages/update/${id}`,
      updatedvillages
    );
  }

  // villagesarpanch operations

  getvillagesarpanchData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/villagesarpanch/all`);
  }

  getvillagesarpanchDataByID(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/villagesarpanch/${id}`);
  }

  savevillagesarpanchData(villages: Villagesarpanch): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/villagesarpanch/create`,
      villages
    );
  }

  deletevillagesarpanchDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(
      `${API_URl}/villagesarpanch/delete/${id}`
    );
  }

  updatevillagesarpanchDataById(
    id: string | number,
    updatedvillages: Villagesarpanch
  ): Observable<Villagesarpanch[]> {
    return this.http.put<Villagesarpanch[]>(
      `${API_URl}/villagesarpanch/update/${id}`,
      updatedvillages
    );
  }


  // vermicompostCOP master  services

  getVermicompostCOPData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/vermicompostcop/all`);
  }

  savevermincompostCOPdata(vermincompostCOP): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/vermicompostcop/create`, vermincompostCOP);
  }

  updateVermiCompostCOPMasterById(id: string | number, updatedmaster: VermincompostCOP): Observable<VermincompostCOP[]> {
    return this.http.put<VermincompostCOP[]>(`${API_URl}/vermicompostcop/update/${id}`, updatedmaster);
  }

  deleteVermicompostCOPMasterById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/vermicompostcop/delete/${id}`);
  }

  // vermicompost pit data
  getVermicompostPITData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/vermicompostpit/all`);
  }

  savevermincompostPITdata(vermicompostPITMaster): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/vermicompostpit/create`, vermicompostPITMaster);
  }

  updateVermiCompostPITMasterById(id: string | number, updatedmaster: VermicompostPITMaster): Observable<VermicompostPITMaster[]> {
    return this.http.put<VermicompostPITMaster[]>(`${API_URl}/vermicompostpit/update/${id}`, updatedmaster);
  }

  deleteVermicompostPITMasterById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/vermicompostpit/delete/${id}`);
  }

  // irrigation data
  getIrrigationData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/irregation/all`);
  }

  saveIrrigationdata(irrigation): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/irregation/create`, irrigation);
  }

  updateIrrigationDataById(id: string | number, updated: Irrigation): Observable<Irrigation[]> {
    return this.http.put<Irrigation[]>(`${API_URl}/irregation/update/${id}`, updated);
  }

  deleteIrrigationDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/irregation/delete/${id}`);
  }

  // getAllVermicompostCOPData(): Observable<any[]> {
  //   return this.opts3.length ?
  //     of(this.opts3) : this.http.get<any[]>(`${API_URl}/vermicompostcop/all`).pipe(tap(data => this.opts3 = data));
  // }

  // getAllVermicompostPITData(): Observable<any[]> {
  //   return this.opts2.length ?
  //     of(this.opts2) : this.http.get<any[]>(`${API_URl}/vermicompostpit/all`).pipe(tap(data => this.opts2 = data));
  // }

  // vermicompost cycle data
  getVermicompostcycleData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/vermicompostcycle/all`);
  }

  savevermincompostcycledata(vermincompostcycle): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/vermicompostcycle/create`, vermincompostcycle);
  }

  updateVermiCompostCycleById(id: string | number, updatedcycle: VermicompostCycle): Observable<VermicompostCycle[]> {
    return this.http.put<VermicompostCycle[]>(`${API_URl}/vermicompostcycle/update/${id}`, updatedcycle);
  }

  deleteVermicompostCycleById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/vermicompostcycle/delete/${id}`);
  }




  // Pit Type Servieces

  // option1 = [];
  // opt = [];
  // options = [];
  // getpitype(): Observable<any[]> {
  //   return this.option1.length ?
  //     of(this.option1) : this.http.get<any[]>(`${API_URl}/pittypes/all`).pipe(tap(data => this.option1 = data));
  // }
  // getconstruction(): Observable<any[]> {
  //   return this.opt.length ?
  //     of(this.opt) : this.http.get<any[]>(`${API_URl}/pitconstructiontypes/all`).pipe(tap(data => this.opt = data));
  // }
  // getplotingData(): Observable<any[]> {
  //   return this.options.length ?
  //     of(this.options) : this.http.get<any[]>(`${API_URl1}/plotting/all`).pipe(tap(data => this.options = data));
  // }

  // getpit(): Observable<any[]> {
  //   
  //   return this.http.get<any[]>(`${API_URl}/pit/all`)
  // }

  // savepittypedata(pittype): Observable<any[]> {
  //   ////console.log(pittype);
  //   return this.http.post<any[]>(`${API_URl}/pit/create`, pittype)
  // }
  // updatepittypeById(id: number, updatedpit: PitType): Observable<any[]> {
  //   ////console.log('new form data', updatedpit);
  //   return this.http.put<PitType[]>(`${API_URl}/pit/update/${id}`, updatedpit);
  // }
  // deletepittypeById(id: any): Observable<any[]> {
  //   
  //   return this.http.delete<any[]>(`${API_URl}/pit/delete/${id}`)
  // }

  // shed data service

  getShedData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/shed/all`);
  }

  saveShedData(shed): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/shed/create`, shed);
  }

  updateShedDataById(id: string | number, updated: Shed): Observable<Shed[]> {
    return this.http.put<Shed[]>(`${API_URl}/shed/update/${id}`, updated);
  }

  deleteshedById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/shed/delete/${id}`);
  }


  getAllDealersdata(): Observable<any[]> {
    return this.opts.length ?
      of(this.opts) : this.http.get<any[]>(`${API_URl}/dealer/all`).pipe(tap(data => this.opts = data));
  }
  getAllcompanydata(): Observable<any[]> {
    return this.opts.length ?
      of(this.opts) : this.http.get<any[]>(`${API_URl}/companymaster/all`).pipe(tap(data => this.opts = data));
  }

  getfertilizerdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/fertilizers/all`);
  }

  saveFertilizerData(fertilizer): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/fertilizers/create`, fertilizer);
  }

  updateFertilizerDataById(id: string | number, updated: Fertilizer): Observable<Fertilizer[]> {
    return this.http.put<Fertilizer[]>(`${API_URl}/fertilizers/update/${id}`, updated);
  }

  deleteFertilizerDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/fertilizers/delete/${id}`);
  }

  // pest control data sevices

  getPestControldata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/pesticides/all`);
  }

  savePestControlData(pestcontrol: PestControl): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/pesticides/create`, pestcontrol);
  }

  updatePestControlDataById(id: string | number, updated: PestControl): Observable<PestControl[]> {
    return this.http.put<PestControl[]>(`${API_URl}/pesticides/update/${id}`, updated);
  }

  deletePesticidesDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/pesticides/delete/${id}`);
  }
  getAllAnimalCategorydata(): Observable<any[]> {
    return this.optcat.length ?
      of(this.optcat) : this.http.get<any[]>(`${API_URl}/animalcategory/all`).pipe(tap(data => this.optcat = data));
  }

  getVaccinationdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/vaccines/all`);
  }

  saveVaccinationData(vaccination): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/vaccines/create`, vaccination);
  }

  updateVaccinationDataById(id: string | number, updated: Vaccination): Observable<Vaccination[]> {
    return this.http.put<Vaccination[]>(`${API_URl}/vaccines/update/${id}`, updated);
  }

  deleteVaccinationDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/vaccines/delete/${id}`);
  }

  // companymaster service

  saveCompanyMaster(Companyname): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/companymaster/create`, Companyname);

  }

  getCompanyMasterData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/companymaster/all`);
  }

  getCompanyMasterId(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/companymaster/${id}`);
  }

  updateCompanyMasterById(id: string | number, updatedCompanyMaster: Companymaster): Observable<Companymaster[]> {
    return this.http.put<Companymaster[]>(`${API_URl}/companymaster/update/${id}`, updatedCompanyMaster);
  }

  deleteCompanyMasterById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/companymaster/delete/${id}`);
  }

  getcropcategorydata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcategory/all`)
  }
  getcropcategoryByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcategory/${id}`)
  }
  savecropcategorydata(cropcategory: Cropcategory): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/cropcategory/create`, cropcategory)
  }
  updatecropcategoryByID(id: number, updatedcropcat: Cropcategory): Observable<any[]> {
    return this.http.put<Cropcategory[]>(`${API_URl}/cropcategory/update/${id}`, updatedcropcat);
  }
  deletecropcategoryByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/cropcategory/delete/${id}`)
  }

  // cropmaster servieces
  getcropmasterdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropmaster/all`)
  }
  getcropmasterdataByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropmaster/${id}`)
  }
  savecropmasterdata(cropmaster: CropMaster): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/cropmaster/create`, cropmaster)
  }
  updatecropmasterByID(id: number, updatedcropmas: CropMaster): Observable<any[]> {
    return this.http.put<Cropcategory[]>(`${API_URl}/cropmaster/update/${id}`, updatedcropmas);
  }
  deletecropmasterByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/cropmaster/delete/${id}`)
  }

  // cropcycle services
  getCropcycle(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcycle/all`)
  }
  getCropcycleByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcycle/${id}`)
  }
  saveCropcycledata(cropcycle: CropCycle): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/cropcycle/create`, cropcycle)
  }
  updateCropcycleByID(id: string | number, updatedcropcycle: CropCycle): Observable<any[]> {
    return this.http.put<Cropcategory[]>(`${API_URl}/cropcycle/update/${id}`, updatedcropcycle);
  }
  deleteCropcycleByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/cropcycle/delete/${id}`)
  }

  // crop_cop servieces
  getCropcopdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcop/all`)
  }
  getCropcopByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcop/${id}`)
  }
  saveCropcopdata(cropcycle: CropCop): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/cropcop/create`, cropcycle)
  }
  updateCropcopByID(id: string | number, updatedcropcycle: CropCop): Observable<any[]> {
    return this.http.put<any[]>(`${API_URl}/cropcop/update/${id}`, updatedcropcycle);
  }
  deleteCropcopByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/cropcop/delete/${id}`)
  }


  // farmer data services

  getFarmerByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/farmerdata/${id}`);
  }

  getFarmerdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/farmerdata/all`);
  }
  saveFarmerdata(farmer: Farmer): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmerdata/create`, farmer);
  }
  saveFarmeradhar(id, adhar): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/image/${id}`, adhar);
  }
  saveFarmerprofile(id, profile): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerimage/${id}`, profile);
  }
  saveFarmersoil(id, soil): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmersoil/${id}`, soil);
  }
  saveFarmerland(id, land): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerland/${id}`, land);
  }
  saveFarmerwater(id, water): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerwater/${id}`, water);
  }
  saveFarmerseed(id, seed): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerseed/${id}`, seed);
  }
  saveFarmercompost(id, compost): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmercompost/${id}`, compost);
  }
  saveFarmerinorganic(id, inorganic): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerinorganic/${id}`, inorganic);
  }
  saveFarmerorganic(id, organic): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerorganic/${id}`, organic);
  }

  saveFarmermachine(id, machine): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmerMachinery/${id}`, machine);
  }

  saveFarmertraning(id, traning): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/farmer/upload/farmertraining/${id}`, traning);
  }





  updateFarmerByID(id: any, updatedFarmer: Farmer): Observable<any[]> {
    return this.http.put<any>(
      `${API_URl}/farmerdata/update/${id}`,
      updatedFarmer
    );
  }
  deleteFarmerByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/farmerdata/delete/${id}`);
  }

  // loan services
  getLoanByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/loan/${id}`);
  }

  getLoan(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/loan/all`);
  }

  getpaymenent(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/paymentfrequency/all`);
  }
  saveLoandata(loan: Loan): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/loan/create`, loan);
  }
  updateLoanByID(id: any, updatedLoan: Loan): Observable<any[]> {
    return this.http.put<Loan[]>(
      `${API_URl}/loan/update/${id}`,
      updatedLoan
    );
  }
  deleteLoanByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/loan/delete/${id}`);
  }

  uploadImage(data, name): Observable<any> {
    return this.http.post<any>(`${API_URl}/${name}/upload/image`, data);
  }

  uploadanimal(data, name): Observable<any> {
    return this.http.post<any>(`${API_URl}/${name}/animalmaster/upload/image`, data);
  }


  uploadusImage(data, ID): Observable<any> {
    return this.http.put<any>(`${API_URl}/user/upload/image/${ID}`, data);
  }

  getLoanImages(farmerID): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/loan/uploaded/image/${farmerID}`)
  }

  // LoanEMI Services
  getLoanEMIByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/loanEMI/${id}`);
  }
  getLoanEMI(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/loanEMI/all`);
  }
  saveLoanEMI(loanEMI: LoanEMI): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/loanEMI/create`, loanEMI);
  }
  updateLoanEMIByID(id: any, updatedLoanEMI: LoanEMI): Observable<any[]> {
    return this.http.put<LoanEMI[]>(
      `${API_URl}/loanEMI/update/${id}`,
      updatedLoanEMI
    );
  }
  deleteLoanEMIByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/loanEMI/delete/${id}`);
  }

  // Assigning C3

  // getvillagesID(id: any): Observable<any[]>
  // {
  //   ;
  //   return this.http.get<any[]>(`${API_URl}/villages/${id}`)
  // }
  // getc3() : Observable <any[]>
  // {
  //   
  // return this.http.get<any[]>(`${API_URl}/c3office/all`);
  // }
  // savec3(res): Observable <any>
  // {
  //   ////console.log(res, 'helloooo............');
  //   return this.http.post<any>(`${API_URl}/farmerc3/create`,res);
  // }

  // Labour data service

  getLabourinfoData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/labour/all`);
  }

  saveLabourInformation(labour: Labour): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/labour/create`, labour);
  }

  getLabourinfoId(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/labour/${id}`);
  }

  updateLabourInfoById(
    id: string | number,
    updatedLabour: Labour
  ): Observable<Labour[]> {
    return this.http.put<Labour[]>(
      `${API_URl}/labour/update/${id}`,
      updatedLabour
    );
  }

  deleteLabourInfoById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/labour/delete/${id}`);
  }

  // Animal history service

  getAnimalhistorydata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/animalcycle/all`);
  }

  saveAnimalhistory(animalhistory: Animalhistory): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/animalcycle/create`,
      animalhistory
    );
  }

  getAnimalCycleId(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/animalcycle/${id}`);
  }

  updateAnimalcycleById(
    id: string | number,
    updatedHistory: Animalhistory
  ): Observable<Animalhistory[]> {
    return this.http.put<Animalhistory[]>(
      `${API_URl}/animalcycle/update/${id}`,
      updatedHistory
    );
  }

  deleteAnimalCycleById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/animalcycle/delete/${id}`);
  }

  // Landlayout operations

  getlandlayoutData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/landlayout/all`);
  }

  getlandlayoutDataByID(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/landlayout/${id}`);
  }

  getlandlayoutDataByDist(id: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_URl}/landlayout/getlandlayoutByFarmerId/${id}`
    );
  }

  savelandlayoutsData(landlayout: Landlayout): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/landlayout/create`,
      landlayout
    );
  }

  deletelandlayoutsDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/landlayout/delete/${id}`);
  }

  updatelandlayoutsDataById(
    id: string | number,
    updatedlandlayout: Landlayout
  ): Observable<Landlayout[]> {
    return this.http.put<Landlayout[]>(
      `${API_URl}/landlayout/update/${id}`,
      updatedlandlayout
    );
  }

  // Ploting Servieces
  getplottingData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/plotting/all`);
  }

  getplottingDataByLand(id: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_URl}/plotting/getplottingByLandId/${id}`
    );
  }

  saveplottingData(plotting: Plotting): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/plotting/create`, plotting);
  }

  deleteplottingDataDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/plotting/delete/${id}`);
  }

  updateplottingDataDataById(
    id: string | number,
    plotting: Plotting
  ): Observable<Plotting[]> {
    return this.http.put<Plotting[]>(
      `${API_URl}/plotting/update/${id}`,
      plotting
    );
  }

  // serviecesCropLanes
  getcroplaneData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/croplines/all`);
  }

  getcroplaneDataByplotting(id: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_URl}/croplines/getcroplinesByPlottingId/${id}`
    );
  }

  savecroplaneData(croplines: Croplanes): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/croplines/create`, croplines);
  }

  deletecroplaneDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/croplines/delete/${id}`);
  }

  updatecroplaneDataById(
    id: string | number,
    croplines: Croplanes
  ): Observable<Croplanes[]> {
    return this.http.put<Croplanes[]>(
      `${API_URl}/croplines/update/${id}`,
      croplines
    );
  }

  // labourhours
  getActivitydata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/labouractivities/all`);
  }
  saveLabourHoursData(labourhours: Labourhours): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/labourhours/create`,
      labourhours
    );
  }

  getLabourHoursData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/labourhours/all`);
  }

  getLabourHoursDataById(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/labourhours/${id}`);
  }


  getExpenseTypeData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/expensetype/all`)
  }

  getSupplierData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/suppliertype/all`)
  }


  getmiscellaneous(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/miscellaneous/all`)
  }

  savemiscellaneousdata(miscellaneouses): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/miscellaneous/create`, miscellaneouses)
  }
  updatemiscellaneousById(id: number, updatedmiscllaneous: MiscellaneousExpenses): Observable<any[]> {
    return this.http.put<MiscellaneousExpenses[]>(`${API_URl}/miscellaneous/update/${id}`, updatedmiscllaneous);
  }
  deletemiscellaneousById(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/miscellaneous/delete/${id}`)
  }


  getfertilizer(): Observable<any[]> {

    return this.http.get<any[]>(`${API_URl}/companymaster/all`);
  }

  getdealer(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/dealer/all`)
  }

  savedealerdata(dealersinformation): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/dealer/create`, dealersinformation)
  }
  updatedealerById(id: number, updateddealer: DealerInformation): Observable<any[]> {
    return this.http.put<DealerInformation[]>(`${API_URl}/dealer/update/${id}`, updateddealer);
  }
  deletedealerinformationById(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/dealer/delete/${id}`)
  }

  // Raw Material Stock services

  getunitsdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/units/all`)
  }

  getlocationdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/location/all`)
  }

  getMaterialType(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/materials/all`);
  }

  getMatCatByMatID(value): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/getMaterialCatByMatID/${value}`);
  }

  getrawmaterialdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/stock/all`)
  }

  saveRawMaterialStock(rawMaterialStockData: RawMaterialStockData): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/stock/create`, rawMaterialStockData);
  }

  updateRawMaterialStockById(id: string | number, updated: RawMaterialStockData): Observable<RawMaterialStockData[]> {
    return this.http.put<RawMaterialStockData[]>(`${API_URl}/stock/update/${id}`, updated);
  }

  deleteRawMaterialStockById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/stock/delete/${id}`);
  }

  // inventory
  getStockData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/stock/all`);
  }
  getinventory(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/inventory/all`);
  }

  saveinventorydata(inventory): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/inventory/create`,
      inventory
    );
  }
  updateinventoryById(id: any, updated: Inventory): Observable<any[]> {
    return this.http.put<Inventory[]>(`${API_URl}/inventory/update/${id}`, updated);
  }
  deleteinventoryById(id: any): Observable<any[]> {
    return this.http.delete<any[]>(
      `${API_URl}/inventory/delete/${id}`
    );
  }
  // bom
  getbom(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/bom/all`);
  }
  getunits(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/units/all`);
  }

  savebomdata(bom): Observable<any[]> {
    return this.http.post<any[]>(
      `${API_URl}/bom/create`,
      bom
    );
  }
  updatebomById(id: any, updated: BOM): Observable<any[]> {
    return this.http.put<BOM[]>(`${API_URl}/bom/update/${id}`, updated);
  }
  deletebomById(id: any): Observable<any[]> {
    return this.http.delete<any[]>(
      `${API_URl}/bom/delete/${id}`
    );
  }

  // SoilType service

  saveSoilType(soil): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/soiltype/create`, soil);

  }

  getSoilTypeData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/soiltype/all`);
  }

  getSoilTypeId(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/soiltype/${id}`);
  }

  updateSoilTypeById(id: string | number, updatedSoil: Soil): Observable<Soil[]> {
    return this.http.put<Soil[]>(`${API_URl}/soiltype/update/${id}`, updatedSoil);
  }

  deleteSoilTypeById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/soiltype/delete/${id}`);
  }

  // SoilCategory services

  getSoilCatData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/soilcategory/all`);
  }

  saveSoilCatType(category): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/soilcategory/create`, category);
  }

  getSoilCatId(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/soilcategory/${id}`);
  }

  updateSoilCatById(id: string | number, updatedCat: Category): Observable<Category[]> {
    return this.http.put<Category[]>(`${API_URl}/soilcategory/update/${id}`, updatedCat);
  }

  deleteSoilCatById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/soilcategory/delete/${id}`);
  }

  // SoilNutrients

  getSoilNutData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/soilnutrient/all`);
  }

  savesoilnut(nutrient): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/soilnutrient/create`, nutrient);
  }

  getSoilNutId(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/soilnutrient/${id}`);
  }

  updateSoilNutById(id: string | number, updatedNut: Nutrient): Observable<Nutrient[]> {
    return this.http.put<Nutrient[]>(`${API_URl}/soilnutrient/update/${id}`, updatedNut);
  }

  deleteSoilNutById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/soilnutrient/delete/${id}`);
  }


  // WaterCategory services

  getWaterCatData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/watercategory/all`);
  }

  saveWaterCatData(watercategory): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/watercategory/create`, watercategory);
  }

  getWaterCatById(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/watercategory/${id}`);
  }

  updateWaterCatDataById(id: string | number, updatedCat: Watercategory): Observable<Watercategory[]> {
    return this.http.put<Watercategory[]>(`${API_URl}/watercategory/update/${id}`, updatedCat);
  }

  deleteWaterCatDataById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/watercategory/delete/${id}`);
  }


  // WaterMaster Source services


  getAllWaterCatData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/watercategory/all`);
  }

  getWaterMasterData(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/watermaster/all`);
  }

  savewatermasterdata(waterMaster): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/watermaster/create`, waterMaster);
  }

  updateWaterMasterById(id: string | number, updatedmaster: WaterMaster): Observable<WaterMaster[]> {
    return this.http.put<WaterMaster[]>(`${API_URl}/watermaster/update/${id}`, updatedmaster);
  }

  deleteWaterMasterById(id: string): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/watermaster/delete/${id}`);
  }

  // Animal Category service

  saveanimaldata(animalcategory): Observable<any[]> {
    //console.log(animalcategory);
    return this.http.post<any[]>(`${API_URl}/animalcategory/create`, animalcategory);
  }

  getanimalcat(): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/animalcategory/all`)
  }

  getanimalcatId(id: string): Observable<any[]> {
    //console.log(id);
    return this.http.get<any[]>(`${API_URl}/animalcategory/${id}`);
  }


  updateAnimaCatById(id: string | number, updatedanimalcat: Animalcategory): Observable<Animalcategory[]> {
    //console.log(updatedanimalcat);
    return this.http.put<Animalcategory[]>(`${API_URl}/animalcategory/update/${id}`, updatedanimalcat);
  }

  deleteAnimalCatById(id: string): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/animalcategory/delete/${id}`);
  }

  // Animal Breed services

  getAnimalbreed(): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/animalbreed/all`);
  }

  saveAnimalbreed(animalbreed): Observable<any[]> {
    //console.log(animalbreed);
    return this.http.post<any[]>(`${API_URl}/animalbreed/create`, animalbreed);
  }

  getAnimalbreedId(id: string): Observable<any[]> {
    //console.log(id);
    return this.http.get<any[]>(`${API_URl}/animalbreed/${id}`);
  }

  updateAnimalbreedById(id: string | number, updatedanimalbreed: Animalbreed): Observable<Animalbreed[]> {
    //console.log(updatedanimalbreed);
    return this.http.put<Animalbreed[]>(`${API_URl}/animalbreed/update/${id}`, updatedanimalbreed);
  }

  deleteAnimalBreedById(id: string): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/animalbreed/delete/${id}`);
  }

  getBreedByCatID(value): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/animalbreed/getBreedByCatName/${value}`);
  }

  // Animal Master services

  getAnimalMaster(): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/animalmaster/all`);
  }

  saveAnimalMaster(animalmaster): Observable<any[]> {
    //console.log(animalmaster);
    return this.http.post<any[]>(`${API_URl}/animalmaster/create`, animalmaster);
  }

  getAnimalbmasterId(id: string): Observable<any[]> {
    //console.log(id);
    return this.http.get<any[]>(`${API_URl}/animalmaster/${id}`);
  }

  updateAnimalmasterById(id: string | number, updatedanimalmaster: Animalmaster): Observable<Animalmaster[]> {
    //console.log(updatedanimalmaster);
    return this.http.put<Animalmaster[]>(`${API_URl}/animalmaster/update/${id}`, updatedanimalmaster);
  }

  deleteAnimalMasterById(id: string): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/animalmaster/delete/${id}`);
  }

  //animalcop
  getAnimalcopdata(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/animalcop/all`)
  }
  getAnimalcopByID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/animalcop/${id}`)
  }
  saveAnimalcopdata(animalcycle: AnimalCop): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/animalcop/create`, animalcycle)
  }

  updateAnimalcopByID(id: string | number, updatedanimalcycle: AnimalCop): Observable<any[]> {
    return this.http.put<any[]>(`${API_URl}/animalcop/update/${id}`, updatedanimalcycle);
  }
  deleteAnimalcopByID(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/animalcop/delete/${id}`)
  }

  //CropCopRawmaterial


  getmaterial(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/materials/all`);
  }
  getCropCopRawmaterial(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/cropcoprawmaterial/all`);
  }
  saveCropCopRawmaterial(cropcoprawmaterial): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/cropcoprawmaterial/create`, cropcoprawmaterial);
  }
  updateCropCopRawmaterialById(id: number, updatedRawmaterial: CropCopRawmaterial): Observable<any[]> {
    return this.http.put<CropCopRawmaterial[]>(`${API_URl}/cropcoprawmaterial/update/${id}`, updatedRawmaterial);
  }
  deleteCropCopRawmaterialById(id: any): Observable<any[]> {
    return this.http.delete<any[]>(`${API_URl}/cropcoprawmaterial/delete/${id}`)
  }

  //animaldiseasedata
  getAnimaldiseasedata(): Observable<any[]> {
    //console.log("ello");
    return this.http.get<any[]>(`${API_URl}/animaldisease/all`)
  }
  getAnimaldiseasedataByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/animaldisease/${id}`)
  }
  saveAnimaldiseasedata(AnimalDisease: AnimalDisease): Observable<any[]> {
    //console.log(AnimalDisease);
    return this.http.post<any[]>(`${API_URl}/animaldisease/create`, AnimalDisease)
  }
  updateAnimaldiseaseByID(id: number, updateddisease: AnimalDisease): Observable<any[]> {
    //console.log('new form data', updateddisease);
    return this.http.put<Cropcategory[]>(`${API_URl}/animaldisease/update/${id}`, updateddisease);
  }
  deleteAnimaldiseaseByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/animaldisease/delete/${id}`)
  }

  //disease 
  getdiseasetype(): Observable<any[]> {
    //console.log("hello")
    return this.http.get<any[]>(`${API_URl}/type/all`)
  }
  getcropdisease(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/croptypedisease/all`)
  }
  getanimaldisease(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/animaltypedisease/all`)
  }
  getdiseasedata(): Observable<any[]> {
    //console.log("ello");
    return this.http.get<any[]>(`${API_URl}/disease/all`)
  }
  getdiseasedataByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/disease/${id}`)
  }
  savediseasedata(disease: Disease): Observable<any[]> {
    //console.log(disease);
    return this.http.post<any[]>(`${API_URl}/disease/create`, disease)
  }
  updatediseaserByID(id: number, updateddisease: Disease): Observable<any[]> {
    //console.log('new form data', updateddisease);
    return this.http.put<Cropcategory[]>(`${API_URl}/disease/update/${id}`, updateddisease);
  }
  deletediseaseByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/disease/delete/${id}`)
  }
  //cropReport disease

  getcropreportdiseasedata(): Observable<any[]> {
    //console.log("ello");
    return this.http.get<any[]>(`${API_URl}/cropreportdisease/all`)
  }
  getcropreportdiseasedataByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/cropreportdisease/${id}`)
  }
  savecropreportdiseasedata(reportdisease: CropReportDisease): Observable<any[]> {
    //console.log(reportdisease);
    return this.http.post<any[]>(`${API_URl}/cropreportdisease/create`, reportdisease)
  }
  updatecropreportdiseaserByID(id: number, updateddisease: CropReportDisease): Observable<any[]> {
    //console.log('new form data', updateddisease);
    return this.http.put<Cropcategory[]>(`${API_URl}/cropreportdisease/update/${id}`, updateddisease);
  }
  deletecropreportdiseaseByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/cropreportdisease/delete/${id}`)
  }

  //animalReport disease

  getanimalreportdiseasedata(): Observable<any[]> {
    //console.log("ello");
    return this.http.get<any[]>(`${API_URl}/animalreportdisease/all`)
  }
  getanimalreportdiseasedataByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/animalreportdisease/${id}`)
  }
  saveanimalreportdiseasedata(reportdisease: AnimalReportDisease): Observable<any[]> {
    //console.log(reportdisease);
    return this.http.post<any[]>(`${API_URl}/animalreportdisease/create`, reportdisease)
  }
  updateanimalreportdiseaserByID(id: number, updateddisease: AnimalReportDisease): Observable<any[]> {
    //console.log('new form data', updateddisease);
    return this.http.put<Cropcategory[]>(`${API_URl}/animalreportdisease/update/${id}`, updateddisease);
  }
  deleteanimalreportdiseaseByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/animalreportdisease/delete/${id}`)
  }
  //consult Expert

  getconsutExpertdata(): Observable<any[]> {
    //console.log("ello");
    return this.http.get<any[]>(`${API_URl}/consultexpert/all`)
  }
  getconsutExpertdataByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/consultexpert/${id}`)
  }
  saveconsutExpertdata(reportdisease: ConsultExpert): Observable<any[]> {
    //console.log(reportdisease);
    return this.http.post<any[]>(`${API_URl}/consultexpert/create`, reportdisease)
  }
  updateconsutExpertByID(id: number, updateddisease: ConsultExpert): Observable<any[]> {
    //console.log('new form data', updateddisease);
    return this.http.put<Cropcategory[]>(`${API_URl}/consultexpert/update/${id}`, updateddisease);
  }
  deleteconsutExpertByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/consultexpert/delete/${id}`)
  }

  //cropdiseasedata
  getCropdiseasedata(): Observable<any[]> {
    //console.log("ello");
    return this.http.get<any[]>(`${API_URl}/cropdisease/all`)
  }
  getCropdiseasedataByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.get<any[]>(`${API_URl}/cropdisease/${id}`)
  }
  saveCropdiseasedata(CropDisease: CropDisease): Observable<any[]> {
    //console.log(CropDisease);
    return this.http.post<any[]>(`${API_URl}/cropdisease/create`, CropDisease)
  }
  updateCropdiseaseByID(id: number, updateddisease: CropDisease): Observable<any[]> {
    //console.log('new form data', updateddisease);
    return this.http.put<Cropcategory[]>(`${API_URl}/cropdisease/update/${id}`, updateddisease);
  }
  deleteCropdiseaseByID(id: any): Observable<any[]> {
    //console.log();
    return this.http.delete<any[]>(`${API_URl}/cropdisease/delete/${id}`)
  }

  checklist(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qcifarmer/all`)
  }

  checklistById(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qcifarmer/${id}`)
  }

  qcimodule(): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qcimodule/all`)
  }

  createCheckList(checklist): Observable<any[]> {
    return this.http.post<any[]>(`${API_URl}/qcifarmer/create`, checklist)
  }

  viewchecklistById(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/farmerdata/checklist/${id}`)
  }

  viewImageChecklist(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/image/${id}`)
  }
  getcheckfarmerID(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/farmerdata/single/${id}`)
  }
  getardharimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/ardhar/${id}`)
  }
  getlandimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/land/${id}`)
  }
  getCompostimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/Compost/${id}`)
  }
  getMachineryimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/Machinery/${id}`)
  }
  getOrganicimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/Organic/${id}`)
  }
  getsoilimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/soil/${id}`)
  }
  getTraningimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/Traning/${id}`)
  }
  getInorganicimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/Inorganic/${id}`)
  }
  getwaterimage(id: any): Observable<any[]> {
    return this.http.get<any[]>(`${API_URl}/qachecklist/Water/${id}`)
  }
}
