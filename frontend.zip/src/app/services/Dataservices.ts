export interface Units {
    Units?: any;
}
export interface MaterialName {
    MatName?: any;
}
export interface MaterialCategory {
    MatCatName?: any;
}
// tslint:disable-next-line: class-name
export interface location {
    Name?: any;
}
export interface Shed {
    Name?: any;
}
export interface LabourActy {
    ActyName?: any;
}
export interface PlottingName {
    PlotingName?: any;
}
