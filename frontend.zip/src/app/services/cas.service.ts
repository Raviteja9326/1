import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Activities } from '../AgrixrpDashboard/cas/activities/activities.component';
import { ActivityMaster } from '../AgrixrpDashboard/cas/activitymaster/activitymaster.component';
import { User } from '../AgrixrpDashboard/cas/usermanagement/user';
import { Roles } from '../AgrixrpDashboard/cas/roles/roles.component';
import { UserActy } from './auth/user';
import { RoleActivity } from '../AgrixrpDashboard/cas/roleactivity/roleactivity.component';
export const API_URl = "http://139.59.67.91:3200";
@Injectable({
	providedIn: 'root'
})
export class CASService {

	constructor(private http: HttpClient, private readonly userActy: UserActy) { }

	login(data: any): Observable<any[]> {
		return this.http.post<any[]>(`${API_URl}/user/login`, data);
	}

	checkmail(data) {
		return this.http.post<any[]>(`${API_URl}/user/checkmail`, data);
	}
	checkphone(data) {

		return this.http.post<any[]>(`${API_URl}/user/checkphone`, data);
	}
	checkuser(data) {
		return this.http.post<any[]>(`${API_URl}/user/checkusername`, data);
	}
	//for roles service
	saveRoles(roles): Observable<any[]> {
		return this.http.post<any[]>(`${API_URl}/roles/create`, roles);
	}

	getAllRoles(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/roles/all`);
	}

	getAllMasterActivities(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/masteractivities/all`);
	}

	getActivitiesByMasterID(value): Observable<any[]> {
		//console.log('this is service id =', value);
		return this.http.post<any[]>(`${API_URl}/activitiesbyMasterIDs`, value);
	}

	saveRoleActivity(Actvity): Observable<any[]> {
		//console.log('activityroles = ', Actvity);
		return this.http.post<any[]>(`${API_URl}/roleactivities/create`, Actvity);
	}

	updateRoleActivitiesById(id: string | number, updatedRoleactivities: RoleActivity): Observable<Roles[]> {
		return this.http.put<Roles[]>(`${API_URl}/roleactivities/update/${id}`, updatedRoleactivities);
	}

	getOpertaions(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/CRUDoperations/all`);
	}

	//for adding user
	saveUserRoles(data): Observable<any[]> {
		//console.log(data);
		return this.http.post<any[]>(`${API_URl}/user/create`, data);
	}

	isActivityMaster(inComingActivityMaster): Boolean {
		var isThere = false;
		var isRoles: string = this.userActy.getMasterActivites();
		if (!isRoles || isRoles.length === 0) {
			return isThere;
		} else {
			inComingActivityMaster.forEach((element: string) => {
				if (isRoles.indexOf(element) > -1) {
					isThere = true;
					return false;
				}
			});
		}
		return isThere;
	}

	isActivities(inComingActivities): Boolean {
		var isThere = false;
		var isRoles = this.userActy.getActivities();
		if (!isRoles || isRoles.length === 0) {
			return isThere;
		} else {
			inComingActivities.forEach((element: string) => {
				if (isRoles.indexOf(element) > -1) {
					isThere = true;
					return false;
				}
			});
		}
		return isThere;
	}

	updateRoleTypeById(id: string | number, updatedRole: Roles): Observable<Roles[]> {
		//console.log('aftr update role', updatedRole);
		return this.http.put<Roles[]>(`${API_URl}/roles/update/${id}`, updatedRole);
	}

	deleteRoleTypeById(id: string): Observable<any[]> {
		return this.http.delete<any[]>(`${API_URl}/roles/delete/${id}`);
	}

	//for adding user

	getAllUsers(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/user/all`);
	}

	getUserDataByID(id: string) {
		return this.http.get<any[]>(`${API_URl}/user/${id}`);
	}

	updateUserDataById(id: string, update: User): Observable<User[]> {
		//console.log('updated data', update, id);
		return this.http.put<User[]>(`${API_URl}/user/update/${id}`, update);
	}

	deleteUserdataById(ID: string): Observable<any[]> {
		return this.http.delete<any[]>(`${API_URl}/user/delete/${ID}`);
	}

	//for role activity

	getActivitiesByRoleID(id: string): Observable<any[]> {
		//console.log('incomng data id =', id);
		return this.http.get<any[]>(`${API_URl}/roles/${id}`);
	}

	//for activitymaster serive

	saveActivityMaster(activitymaster): Observable<any[]> {
		return this.http.post<any[]>(`${API_URl}/activitymaster/create`, activitymaster);
	}

	updateActivityMasterById(id: string | number, updatedactivitymaster: ActivityMaster): Observable<ActivityMaster[]> {
		//console.log('aftr update', updatedactivitymaster);
		return this.http.put<ActivityMaster[]>(`${API_URl}/activitymaster/update/${id}`, updatedactivitymaster);
	}

	deleteActivityMasterById(ID: string): Observable<any[]> {
		return this.http.delete<any[]>(`${API_URl}/activitymaster/delete/${ID}`);
	}

	//for activities serive

	getAllActivities(): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/activities/all`);
	}

	saveActivities(activities): Observable<any[]> {
		return this.http.post<any[]>(`${API_URl}/activities/create`, activities);
	}

	updateActivitiesById(id: string | number, updatedactivity: Activities): Observable<Activities[]> {
		//console.log('aftr update', updatedactivity);
		return this.http.put<Activities[]>(`${API_URl}/activities/update/${id}`, updatedactivity);
	}

	deleteActivitiesById(ID: string): Observable<any[]> {
		return this.http.delete<any[]>(`${API_URl}/activities/delete/${ID}`);
	}

	//for OTP form
	sendMobileNo(mobile): Observable<any[]> {
		//console.log('mobile no', mobile);
		return this.http.post<any[]>(`${API_URl}/user/forgotPassword`, mobile);
	}

	changePasswordRequest(password, ID: string): Observable<any[]> {
		//console.log('mobile no', ID, password);
		return this.http.put<any[]>(`${API_URl}/user/updatePasword/${ID}`, password);
	}
	checkCrud = (component: string, operation: string): boolean => {
		var isThere = false;
		var activities = this.userActy.getActivitiesFor();
		//console.log("ssssss", activities)
		activities.forEach((ele) => {
			if (ele.ActiyName === component) {
				ele.operations.includes(operation) ? (isThere = true) : isThere;
			}
		});
		return isThere;
	};
	getCertificationGraphData(ID: number, name: string): Observable<any[]> {
		return this.http.get<any[]>(`${API_URl}/user/chart/${name}/${ID}`);
	}

	getNonCertificationGraphData(ID: number, name: string) {
		return this.http.get<any[]>(`${API_URl}/user/noncertified/${name}/${ID}`);
	}

}
