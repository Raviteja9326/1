import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from "@angular/core";
import { HttpModule, BrowserXhr } from "@angular/http";
import { RouterModule } from "@angular/router";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { NgProgressModule, NgProgressBrowserXhr } from "ngx-progressbar";
import { CommonModule } from "@angular/common";
import { AdminLayoutModule } from './AgrixrpDashboard/admin-layout.module';
import { HttpErrorInterceptor } from './services/http-error.interceptor';
import { BrowserModule } from '@angular/platform-browser';
import { JwtModule } from '@auth0/angular-jwt';
import { MaterialModule } from './AgrixrpDashboard/material/material.module';
import { AuthGuardService } from 'app/services/auth/auth-guard.service';


export function getToken() {
  return localStorage.getItem('access_token');
}

@NgModule({
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AdminLayoutModule,
    CommonModule,
    HttpModule,
    RouterModule,
    MaterialModule,
    AppRoutingModule,
    HttpClientModule,
    NgProgressModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getToken
      }
    })
  ],
  declarations: [AppComponent],
  providers: [
    { provide: AuthGuardService, useClass: AuthGuardService },
    { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },
    { provide: BrowserXhr, useClass: NgProgressBrowserXhr },

  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
