/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  ID: string;
}
