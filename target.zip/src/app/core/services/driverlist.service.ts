import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { Observable } from 'rxjs';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class DriverlistService {

  constructor(private http: HttpMethodService) {}

  getdriverlist(page:any, size:any): Observable<any> {
    return this.http.getMethod(`${api.serviceEndpoint}`,`${api.getdriverlist}/${page}?size=${size}`)
  }
  getdrivertypelist(): Observable<any> {
    return this.http.getMethod(`${api.serviceEndpoint}`,`${api.getjobtypelist}`)
  }
  getvehicletypelist(): Observable<any> {
    return this.http.getMethod(`${api.serviceEndpoint}`,`${api.getvehicletypelist}`)
  }
  getlicencetypelist(): Observable<any> {
    return this.http.getMethod(`${api.serviceEndpoint}`,`${api.getlicencetypelist}`)
  }
}
