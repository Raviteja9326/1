import { Injectable } from '@angular/core';
import { HttpMethodService } from './httpMethod.service';
import { Observable } from 'rxjs';
import { api } from '../constants/api.constants';

@Injectable({
  providedIn: 'root'
})
export class RealtimeService {

  constructor(private http: HttpMethodService) {}

  getrealtimedata(data:any): Observable<any> {
    return this.http.getMethod(`${api.serviceEndpoint}`,`${api.getrealtimelist}?interval-type=${data}`)
  }
}
