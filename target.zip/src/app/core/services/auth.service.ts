import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { api } from '../constants/api.constants';
import { HttpMethodService } from './httpMethod.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpMethodService) {}

  useremaillogin(data:any): Observable<any> {
    const headers = new HttpHeaders({
      'SkipInterceptor': 'true', // Skip the interceptor for login request
    });
    return this.http.loginpostMethod(`${api.serviceEndpoint}`,`${api.loginTokenApi}`,data,{ headers })
  }

  userloginpwd(data:any): Observable<any> {
    return this.http.postMethod(`${api.serviceEndpoint}`,`${api.changepwd}`,data)
  }
}
