import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
const SecureStorage = require('secure-web-storage');
const SECRET_KEY: any = "Weatherford Monitoring Drilling Optimization Platform Created By BirlaSoft in june 2023";
declare var require: any;

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  constructor() {}

  secureStorage = new SecureStorage(sessionStorage, {
    hash: function hash(key: any) {
      key = CryptoJS.SHA256(key, SECRET_KEY);
      return key.toString();
    },

    // Encrypt the localstorage data
    encrypt: function encrypt(data: any) {
      data = CryptoJS.AES.encrypt(data, SECRET_KEY);
      data = data.toString();
      return data;
    },

    // Decrypt the encrypted data
    decrypt: function decrypt(data: any) {
      data = CryptoJS.AES.decrypt(data, SECRET_KEY);
      data = data.toString(CryptoJS.enc.Utf8);
      return data;
    },
  });

  public setRoles(roles: any) {
    return this.secureStorage.setItem('roles', roles);
  }

  public getRoles() {
    return this.secureStorage.getItem('roles');
  }

  public setToken(jwtToken: any) {
    return this.secureStorage.setItem('jwtToken', jwtToken);
  }

  public getToken(): string {
    return this.secureStorage.getItem('jwtToken');
  }

  public getuser(): any {
    return this.secureStorage.getItem('username');
  }

  public setusername(username: any) {
    return this.secureStorage.setItem('username', username);
  }

  public setWellName(data: any) {
    return this.secureStorage.setItem('well-name', data);
  }

  public getWellName(): string {
    return this.secureStorage.getItem('well-name');
  }

  public menu(data: any) {
    return this.secureStorage.setItem('menu', data);
  }

  public getmenu(): string {
    return this.secureStorage.getItem('menu');
  }

  public clear() {
    return this.secureStorage.clear();
  }
}
