import { Api_urls } from "src/app/shared/config";


/**
 * This file contains endpoint constants.
 */
export const api = {
    serviceEndpoint: Api_urls.apiUrl,
    loginTokenApi:"v1/user/login",
    changepwd:"v1/user/change-password",
    getdriverlist:"v2/drivers",
    getjobtypelist:"v1/job-types",
    getvehicletypelist:"v1/vehicle-types",
    getlicencetypelist:"v1/licence-types",
    getownerslist:"v2/owners",
    postownerlist:"v1/owner",
    postdriverlist:"v1/owner",
    postvehiclelist:"v1/vehicle-types",
    postjobist:"v1/job-types",
    postjobtypesist:"v1/job-titles",
    getjoblist:"v1/jobs",
    postlicencetypesist:"v1/licence-types",
    getcountylist:"v1/settings/country",
    postcountylist:"v1/country",
    getappnotificationslist:"v1/app/notifications",
    getrealtimelist:"v1/users/count"



   

} //end of 'api' block
