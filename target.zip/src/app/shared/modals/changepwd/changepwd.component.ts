import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AuthService } from 'src/app/core/services/auth.service';
import { StorageService } from 'src/app/core/services/storage.service';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
    const control = updateforgotpasswordform.controls[controlName];
    const matchingControl =
      updateforgotpasswordform.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors['mustMatch']) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  };
}
@Component({
  selector: 'app-changepwd',
  templateUrl: './changepwd.component.html',
  styleUrls: ['./changepwd.component.css'],
})
export class ChangepwdComponent implements OnInit {
  fieldTextType: boolean = false;

  constructor(
    private ngxLoader: NgxUiLoaderService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private auth: AuthService
  ) {
    this.ngxLoader.stop();
  }

  loginform = this.formBuilder.group(
    {
      oldPassword: new FormControl('', [Validators.required]),
      newPassword: new FormControl('', [
        Validators.required,
        Validators.pattern(
          /^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/
        ),
      ]),
      confirmPassword: new FormControl('', [Validators.required]),
    },
    {
      validator: MustMatch('newPassword', 'confirmPassword'),
    }
  );

  get loginControl() {
    return this.loginform.controls;
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  ngOnInit(): void { }

  changepwdsubmit() {
    if (!this.loginform.valid) {
      Object.keys(this.loginform.controls).forEach((field) => {
        const control: any = this.loginform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    } else if (this.loginform.valid) {
      this.ngxLoader.start();
      // service call of login api
      this.auth.userloginpwd(this.loginform.value).subscribe({
        next: (data) => {
          this.ngxLoader.stop();
          this.toastr.success(data.message);
        },
        error: (error) => {
          this.ngxLoader.stop();
          this.toastr.error(error.error.message);
        },
      });
    }
  }
}
