import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './material.module';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HighchartsChartModule } from 'highcharts-angular';
import { NumericOnlyDirective } from '../core/directives/numeric-only.directive';
const Modules = [
  FormsModule,
  ReactiveFormsModule,
  MaterialModule,
  RouterModule,
  CommonModule,
  HighchartsChartModule
]

const Declarations = [
  NumericOnlyDirective
]

@NgModule({
  declarations: [...Declarations],
  imports: [...Modules],
  exports:[...Modules, ...Declarations]
})
export class AllModule { }
