export const Api_urls = {
    apiUrl : "https://app.wanteddrivers.in/"
}