// import { GlobalSharedService } from './../../core/services/globalShared.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AuthService } from 'src/app/core/services/auth.service';
import { StorageService } from 'src/app/core/services/storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  fieldTextType: boolean = false;

  constructor(private route: Router, private auth:AuthService, private storage:StorageService, private ngxLoader: NgxUiLoaderService, private toastr: ToastrService) {
    this.storage.clear();
    this.ngxLoader.stop();
   }

   loginform = new FormGroup({
    email:new FormControl('',[Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"), Validators.required]),
    password:new FormControl('', [Validators.required])
  })

  get loginControl(){
    return this.loginform.controls;
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  ngOnInit(): void {
  }

 async loginWithToken(){
  this.ngxLoader.start();
    // service call of login api
  this.auth.useremaillogin(this.loginform.value).subscribe({
     next: (data) => {
      this.storage.setusername(data.payload);
      this.storage.setToken(data.payload.uuid);
      this.ngxLoader.stop();
      this.route.navigate(['/dashboard/realtime'])
     },
     error: (error) => {
      this.ngxLoader.stop();
      this.toastr.error(error.error.message);
     }
   });
  }
}