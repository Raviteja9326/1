import { Component, OnInit } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnInit {

  Name:string= 'NA';
  Emailid:string='NA';
  Role:string='NA';
  constructor(private store: StorageService) {}

  ngOnInit(): void {
    this.getLoginDetails();
  }


  getLoginDetails(){
    console.log(this.store.getuser());
    this.Name = this.store.getuser().firstName;
    this.store.getuser().emails?.map((res:any)=>{
      this.Emailid = res?.email
    });
    this.store.getuser().roles?.map((res:any)=>{
      this.Role = res
    });
  }

}
