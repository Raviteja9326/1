import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { ChangepwdComponent } from '../shared/modals/changepwd/changepwd.component';


const routes: Routes = [
{path:'',component:HomeComponent, children:[
  {path:'changepwd',component:ChangepwdComponent},
  {path:'driver', data: {preload: false}, loadChildren:()=> import('../wanted_components/driver/driver.module').then(m=>m.DriverModule)},
  {path:'jobs', data: {preload: false}, loadChildren:()=> import('../wanted_components/jobs/jobs.module').then(m=>m.JobsModule)},
  {path:'owner', data: {preload: false}, loadChildren:()=> import('../wanted_components/owner/owner.module').then(m=>m.OwnerModule)},
  {path:'location', data: {preload: false}, loadChildren:()=> import('../wanted_components/location/location.module').then(m=>m.LocationModule)},
  {path:'realtime', data: {preload: false}, loadChildren:()=> import('../wanted_components/realtime/realtime.module').then(m=>m.RealtimeModule)}
]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
