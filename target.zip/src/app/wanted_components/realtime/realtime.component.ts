import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { RealtimeService } from 'src/app/core/services/realtime.service';

@Component({
  selector: 'app-realtime',
  templateUrl: './realtime.component.html',
  styleUrls: ['./realtime.component.css']
})
export class RealtimeComponent implements OnInit, OnDestroy {

  selectedRange: string = 'Weekly';
  Highcharts: typeof Highcharts = Highcharts;
  Highcharts2: typeof Highcharts = Highcharts;
  driverchartOptions!: Highcharts.Options;
  ownerchartOptions!: Highcharts.Options;
  driver: any = [];
  owner: any = [];
  driverLables: any;
  ownerLables: any;

  constructor(private ngxLoader: NgxUiLoaderService, private toastr: ToastrService, private real_time: RealtimeService, private datepipe: DatePipe) { }

  ngOnDestroy(): void { }

  ngOnInit(): void {
    this.getdashboardlist(this.selectedRange);
  }

  getdashboardlist(daterange:any) {
    console.log(daterange)
    this.ngxLoader.start();
    this.driverLables = [];
    this.ownerLables = [];
    this.driver = [];
    this.owner = [];
    // service call of login api
    this.real_time.getrealtimedata(daterange).subscribe({
      next: (data) => {
        if (data.payload != null || undefined) {
          data.payload.createdOwnersCount.forEach((res: any) => {
            let formattedDate:any = ''; 
            if(daterange == 'Weekly'){
               formattedDate = this.datepipe.transform(res.date, 'MMM d');
            }
            else if(daterange == 'Monthly'){
               formattedDate = this.datepipe.transform(res.date, 'MMM YYYY');
            }
            else if(daterange == 'Yearly'){
               formattedDate = this.datepipe.transform(res.date, 'YYYY');
            }
            if (formattedDate) {
              this.ownerLables.push(formattedDate);
              this.owner.push(res.count);
            }
          })
          data.payload.createdDriversCount.forEach((res: any) => {
            let formattedDate:any = ''; 
            if(daterange == 'Weekly'){
               formattedDate = this.datepipe.transform(new Date(res.date), 'MMM d');
            }
            else if(daterange == 'Monthly'){
               formattedDate = this.datepipe.transform(new Date(res.date), 'MMM YYYY');
            }
            else if(daterange == 'Yearly'){
               formattedDate = this.datepipe.transform(new Date(res.date), 'YYYY');
            }
            if (formattedDate) {
              this.driverLables.push(formattedDate);
              this.driver.push(res.count);
            }
          })
          this.ngxLoader.stop();
          this.drivergraphsbydate();
          this.ownergraphsbydate();
        }
      },
      error: (error) => {
        this.ngxLoader.stop();
        this.toastr.error(error.error.message);
      }
    });
  }

  drivergraphsbydate() {
    this.driverchartOptions = {
      chart: {
        type: 'column',
        zooming: { type: 'x' }
      },
      accessibility: {
        enabled: false,
      },
      credits: {
        text: '',
        href: '',
      },
      title: {
        text: ''
      },
      subtitle: {
        text: ''
      },
      xAxis: [
        {
          gridLineWidth: 0.5,
          lineWidth: 0,
          lineColor: 'transparent',
          categories: [...this.driverLables],
          crosshair: true,
          labels: {
            style: {
              color: '#000',
              fontWeight: '600',
              fontFamily: '"Montserrat", sans-serif',
            },
          }
        }
      ],
      yAxis: {
        gridLineWidth: 0.5,
        min: 0,
        tickInterval: 100,
        title: {
          text: '',
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          },
        },
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          }
        }
      },
      tooltip: {
        style: {
          color: '#000',
          fontWeight: '600',
          fontFamily: "'Open Sans', sans-serif"
        },
        headerFormat: '<span style="font-size:13px; font-weight:600; margin-bottom:5px">{point.x}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding-top:10px;font-weight:600;font-size:13px; ">Total {series.name} Count </td>' + '<td style="padding-top:10px; padding-left:10px; font-size:13px;">:</td>' + 
          '<td style="padding-top:10px;padding-left:10px;font-size:13px;">{point.y}</td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
      },
      legend: {
        enabled: false,
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        x: 0,
        y: 25,
        floating: false,
        itemMarginTop: 5,
        itemMarginBottom: 10,
        itemStyle: {
          lineHeight: '10px',
          fontSize:'15px',
          fontWeight: '600'
        }
      },
      plotOptions: {
        column: {
          grouping: true,
          stacking:'normal',
          pointPadding: 0.2,
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: true, // Display data labels
            inside: true, // Place data labels inside the bars
            color: 'white', // Color of data labels
            style: {
              textOutline: 'none', // Remove text outline
            },
            formatter: function () {
              return this.y; // Display the count as data label
            },
          }
        }
      },
      series: [{
        type: 'column',
        name: 'Driver',
        color: '#89bd74',
        data: [...this.driver]
      }]
    }
  }

  ownergraphsbydate() {
    this.ownerchartOptions = {
      chart: {
        type: 'column',
        zooming: { type: 'x' }
      },
      accessibility: {
        enabled: false,
      },
      credits: {
        text: '',
        href: '',
      },
      title: {
        text: ''
      },
      subtitle: {
        text: ''
      },
      xAxis: [
        {
          gridLineWidth: 0.5,
          lineWidth: 0,
          lineColor: 'transparent',
          categories: [...this.ownerLables],
          crosshair: true,
          labels: {
            style: {
              color: '#000',
              fontWeight: '600',
              fontFamily: '"Montserrat", sans-serif',
            },
          }
        }
      ],
      yAxis: {
        gridLineWidth: 0.5,
        min: 0,
        tickInterval: 100,
        title: {
          text: '',
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          },
        },
        labels: {
          style: {
            color: '#000',
            fontWeight: '600',
            fontFamily: "'Open Sans', sans-serif",
          }
        }
      },
      tooltip: {
        style: {
          color: '#000',
          fontWeight: '600',
          fontFamily: "'Open Sans', sans-serif"
        },
        headerFormat: '<span style="font-size:13px; font-weight:600; margin-bottom:5px">{point.x}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding-top:10px;font-weight:600;font-size:13px; ">Total {series.name} Count </td>' + '<td style="padding-top:10px; padding-left:10px; font-size:13px;">:</td>' + 
          '<td style="padding-top:10px;padding-left:10px;font-size:13px;">{point.y}</td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
        valueDecimals: 0,
      },
      legend: {
        enabled: false,
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        x: 0,
        y: 25,
        floating: false,
        itemMarginTop: 5,
        itemMarginBottom: 10,
        itemStyle: {
          lineHeight: '10px',
          fontSize:'15px',
          fontWeight: '600'
        }
      },
      plotOptions: {
        column: {
          grouping: true,
          stacking:'normal',
          pointPadding: 0.2,
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: true, // Display data labels
            inside: true, // Place data labels inside the bars
            color: 'white', // Color of data labels
            style: {
              textOutline: 'none', // Remove text outline
            },
            formatter: function () {
              return this.y; // Display the count as data label
            },
          }
        }
      },
      series: [{
        type: 'column',
        name: 'Owner',
        color: '#316aa9',
        data: [...this.owner]
      }]
    }
  }

  callApi(event:any){
     console.log("hi")
  }
}
