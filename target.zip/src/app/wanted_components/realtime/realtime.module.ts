import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RealtimeRoutingModule } from './realtime-routing.module';
import { RealtimeComponent } from './realtime.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    RealtimeComponent
  ],
  imports: [
    CommonModule,
    RealtimeRoutingModule,
    AllModule
  ]
})
export class RealtimeModule { }
