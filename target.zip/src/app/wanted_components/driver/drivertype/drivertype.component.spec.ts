import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrivertypeComponent } from './drivertype.component';

describe('DrivertypeComponent', () => {
  let component: DrivertypeComponent;
  let fixture: ComponentFixture<DrivertypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DrivertypeComponent]
    });
    fixture = TestBed.createComponent(DrivertypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
