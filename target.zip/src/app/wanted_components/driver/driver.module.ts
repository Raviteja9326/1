import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DriverRoutingModule } from './driver-routing.module';
import { DriverComponent } from './driver.component';
import { DriverlistComponent } from './driverlist/driverlist.component';
import { DrivertypeComponent } from './drivertype/drivertype.component';
import { VehicletypeComponent } from './vehicletype/vehicletype.component';
import { LicensetypeComponent } from './licensetype/licensetype.component';
import { AllModule } from 'src/app/shared/all_modules';


@NgModule({
  declarations: [
    DriverComponent,
    DriverlistComponent,
    DrivertypeComponent,
    VehicletypeComponent,
    LicensetypeComponent
  ],
  imports: [
    CommonModule,
    DriverRoutingModule,
    AllModule
  ]
})
export class DriverModule { }
