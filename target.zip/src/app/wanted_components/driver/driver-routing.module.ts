import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DriverComponent } from './driver.component';
import { DriverlistComponent } from './driverlist/driverlist.component';
import { DrivertypeComponent } from './drivertype/drivertype.component';
import { LicensetypeComponent } from './licensetype/licensetype.component';
import { VehicletypeComponent } from './vehicletype/vehicletype.component';

const routes: Routes = [
  {path:"",component:DriverComponent,children:[
    {path:"driverlist",component:DriverlistComponent},
    {path:"drivertype",component:DrivertypeComponent},
    {path:"licensetype",component:LicensetypeComponent},
    {path:"vehicletype",component:VehicletypeComponent},
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DriverRoutingModule { }
