import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { DriverlistService } from 'src/app/core/services/driverlist.service';

@Component({
  selector: 'app-vehicletype',
  templateUrl: './vehicletype.component.html',
  styleUrls: ['./vehicletype.component.css']
})
export class VehicletypeComponent implements OnInit {

  dataSource!: MatTableDataSource<any>;
  _value = '';
  expanded: boolean = false;
  displayNoRecords: boolean = false;
  pageIndex = 0;
  pageSize = 50;
  totalItems = 0;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  displayedColumns: string[] = ['vehicle Type','isActive','Actions'];

  constructor(private ngxLoader: NgxUiLoaderService, private toastr: ToastrService, private driver:DriverlistService){}

  ngOnInit(): void {
      this.getdriverlist();
  }

  getdriverlist() {
    this.ngxLoader.start();
    // service call of login api
  this.driver.getvehicletypelist().subscribe({
     next: (data) => {
      console.log(data);
      if (data.payload.length != 0) {
      this.dataSource = new MatTableDataSource<any>(data.payload.map((user:any) => {
        return {...user,
           'vehicle Type': user.vehicleTypeName,
           isActive: '',
           Actions: ''};
      }));
      setTimeout(() => {
        this.dataSource.sort = this.sort;
        this.totalItems = this.dataSource.data.length;
        this.dataSource.paginator = this.paginator;
      });
    }
    else if (data.payload.list.length != 0) {
      this.displayNoRecords = true;
     }
      this.ngxLoader.stop();
     },
     error: (error) => {
      this.ngxLoader.stop();
      this.toastr.error(error.error.message);
     }
   });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  pageChanged(event:any) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }
  close() {
    this._value = '';
  }
  onBlur() {
    if (!(this._value && this._value.length > 0)) {
      this.expanded = false;
    }
  }

}
