import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LocationComponent } from './location.component';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';

const routes: Routes = [
  {path:"",component:LocationComponent,children:[
    {path:"country", component:CountryComponent},
    {path:"state", component:StateComponent},
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationRoutingModule { }
