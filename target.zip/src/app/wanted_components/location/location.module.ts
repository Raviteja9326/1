import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationRoutingModule } from './location-routing.module';
import { LocationComponent } from './location.component';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';


@NgModule({
  declarations: [
    LocationComponent,
    CountryComponent,
    StateComponent
  ],
  imports: [
    CommonModule,
    LocationRoutingModule
  ]
})
export class LocationModule { }
