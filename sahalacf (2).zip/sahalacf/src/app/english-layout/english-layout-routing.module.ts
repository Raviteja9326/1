import { Routes, RouterModule } from "@angular/router";
import { NgModule } from "@angular/core";
import { EnglishLayoutComponent } from './english-layout.component';
import { DashboardComponent } from '../smeenglish/smeengwebapp/dashboard/dashboard.component';
import { SmeengwebappComponent } from '../smeenglish/smeengwebapp/smeengwebapp.component';
import { AuthguardGuard } from '../services/authguard.guard';

const routes: Routes = [
  {
    path: "englishwebsmeapp",
    component: EnglishLayoutComponent,
    children: [
      { path: "webappdashboard", component: DashboardComponent },
        {path:'',component:SmeengwebappComponent,
        loadChildren:() =>import('../smeenglish/smeengwebapp/smeengwebapp.module').then(s=>s.SmeengwebappModule)}, 
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes),],
  exports: [RouterModule],
})
export class EnglishLayoutRoutingModule { }
