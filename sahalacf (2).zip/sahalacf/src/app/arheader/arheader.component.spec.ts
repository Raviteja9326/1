import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArheaderComponent } from './arheader.component';

describe('ArheaderComponent', () => {
  let component: ArheaderComponent;
  let fixture: ComponentFixture<ArheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
