import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-arheader',
  templateUrl: './arheader.component.html',
  styleUrls: ['./arheader.component.scss']
})
export class ArheaderComponent implements OnInit {

  sign = false;
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  signup(){
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }

}
  