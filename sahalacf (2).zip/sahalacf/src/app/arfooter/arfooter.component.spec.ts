import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArfooterComponent } from './arfooter.component';

describe('ArfooterComponent', () => {
  let component: ArfooterComponent;
  let fixture: ComponentFixture<ArfooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArfooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
