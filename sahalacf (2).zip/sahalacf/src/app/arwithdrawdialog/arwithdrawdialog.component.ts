import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AuthService } from 'src/app/services/auth.service';

import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-arwithdrawdialog',
  templateUrl: './arwithdrawdialog.component.html',
  styleUrls: ['./arwithdrawdialog.component.scss']
})
export class ArwithdrawdialogComponent implements OnInit {

  deviceInfo: any;
  accesstoken: any;
  data2: any;
  bankName:any;
  ibanName:any;
  bankaccountholdername:any
  intiateerrormsg: any;
  withdrawalDataArray: any;
  processeerrormsg: string;
  processsucessmsg: string;
  processsucessmsgb: boolean;
  processeerrormsgb: boolean;
  intiatsussessmsg: string;
  intiatsussessmsgb: boolean;
  intiateerrormsgb: boolean;
  tarnsfermsg: string;
  withdrawresponse: any;





  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<ArwithdrawdialogComponent>,@Inject(MAT_DIALOG_DATA) public data: any,private deviceService: DeviceDetectorService,
  private deviceinfoservice:DeviceinfoserviceService,private authService:AuthService,private spinnerfull: NgxSpinnerService) { 
    this.data2= JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data2!=null || this.data2 !=''){
        this.accesstoken= this.data2.accesstoken;
      }
    this.withdrawuserData=data
    console.log(data)
    console.log(this.withdrawuserData)
    console.log(this.deviceinfoservice.deviceinfo)
    // this.bankName=data.
  
  }

  // withdraw2:false
  // withdraw1:true
  withdrawuserData: any;
  withdrawForm:FormGroup;
  withdrawprocessForm:FormGroup;
  withdrawcontrol: boolean;
withdraw1= true;
withdraw2=false;
withdraw3=false;
get f() { return this.withdrawForm.controls }
get withdrawFormComtrol() { return this.withdrawForm.controls; }
  ngOnInit(): void {
    console.log("dia")
    this.GetBankDetails()
    this.detectDevice()

    this.withdrawForm = this.fb.group({
      bankname:['',Validators.required],
      ibannumber:['',Validators.required],
      holdername:['',Validators.required],
      amount:['',Validators.required]
    })
    this.withdrawprocessForm = this.fb.group({
      bankname:['',Validators.required],
      ibannumber:['',Validators.required],
      holdername:['',Validators.required],
      amount:['',Validators.required],
      transamtbank:['',Validators.required],
      transcharges:['',Validators.required],
    })
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
   
  }
  withdraeprocess(){
    const object: any = {}
object['transactionId'] = this.withdrawalDataArray.transaction_id;
console.log(object)
console.log(object)
this.spinnerfull.show()
this.authService.requestwithdrawalprocess(this.accesstoken,object).subscribe(response=>{
  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){
    console.log('hi')
    if(response.withdrawl_status =='1000'){
      this.tarnsfermsg="اكتمل بنجاح"
   this.processsucessmsg="اكتمل بنجاح" 
   this.processsucessmsgb = true;

   setTimeout(() => {
     this.processsucessmsgb = false;
    //  this.dialogRef.close();
  }, 3000)
  this. withdraw2= false;
this.withdraw1=false;
this.withdraw3=true
       this.withdrawresponse = response.withdrawl_status
  // this.dialogRef.close();
    }
    else if(response.withdrawl_status =='1002') {
     this.processeerrormsg='هنالك خطا ما'
     this.processeerrormsgb = true;
     setTimeout(() => {
      this.processeerrormsgb = false;
      this.dialogRef.close();
   }, 3000)
   
    }
    else if(response.withdrawl_status =='1210') {
      this.processeerrormsg='تم تجهيز معرّف المعاملة بالفعل'
      this.processeerrormsgb = true;
      setTimeout(() => {
       this.processeerrormsgb = false;
       this.dialogRef.close();
    }, 3000)
    
     }
     else if(response.withdrawl_status =='1207') {
      this.processeerrormsg='هنالك خطا ما'
      this.processeerrormsgb = true;
      setTimeout(() => {
       this.processeerrormsgb = false;
       this.dialogRef.close();
    }, 3000)
    
     }
     else if(response.withdrawl_status =='1208') {
      this.processeerrormsg='هنالك خطا ما'
      this.processeerrormsgb = true;
      setTimeout(() => {
       this.processeerrormsgb = false;
       this.dialogRef.close();
    }, 3000)
    
     }
     else if(response.withdrawl_status =='1198') {
      this.processeerrormsg='رصيد غير كاف'
      this.processeerrormsgb = true;
      setTimeout(() => {
       this.processeerrormsgb = false;
       this.dialogRef.close();
    }, 3000)
    
     }
     else if(response.withdrawl_status =='1208') {
      this.processeerrormsg='هنالك خطا ما'
      this.processeerrormsgb = true;
      setTimeout(() => {
       this.processeerrormsgb = false;
       this.dialogRef.close();
    }, 3000)
    
     }
    
    else if(response.withdrawl_status =='1001') {
      this.tarnsfermsg="فشل"
      this.processeerrormsg='فشل '
      this.processeerrormsgb = true;
      setTimeout(() => {
        this.processeerrormsgb = false;
        // this.dialogRef.close();
     }, 3000)
     this.withdraw3=true
     this.withdraw2=false
     this.withdraw1=false
    }
  }else if(response.Token_Status=='1120'){
    this.processeerrormsgb = true;
    this.processeerrormsg = 'غير مصرح';
    setTimeout(() => {
      this.processeerrormsgb = false;
      this.dialogRef.close();
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.processeerrormsgb = true;
    this.processeerrormsg = 'انتهت صلاحية الرمز';
    setTimeout(() => {
      this.processeerrormsgb = false;
      this.dialogRef.close();
    }, 3000);
  }
 
  
})

  }
  withdrawfun(){
    this.withdrawcontrol=true;
    if(this.withdrawForm.valid){
      this.withdrawcontrol=false;
    
   
    console.log(this.withdrawForm.value == '')
    if(this.withdrawForm.valid){
      this.withdrawForm.get('amount').markAsTouched();
const object: any = {}
object['withdrawlAmount'] = this.withdrawForm.value.amount;
console.log(object)
this.spinnerfull.show()
this.authService.requestwithdrawalintial(this.accesstoken,object).subscribe(response=>{
  this.withdrawcontrol=false;
  console.log(response)
  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){
    console.log('hi')
    if(response.validate_amout_status =='1000'){
     
   
    this.withdrawalDataArray=response 
this.withdrawprocessForm.patchValue({
  bankname:response.bank_name,
  ibannumber:response.iban_number,
  holdername:response.account_holder_name,
  amount:response.withdral_amount,
  transamtbank:response.transferred_amount_to_bank,
  transcharges:response.transaction_charges

})
this.intiatsussessmsg='اكتمل بنجاح'
this.intiatsussessmsgb = true;
setTimeout(() => {
  this.intiatsussessmsgb = false;
   this. withdraw2= true;
   this.withdraw1=false
   this.withdraw3=false
}, 1000)

    }
    else if(response.validate_amout_status =='1002') {
     this.intiateerrormsg='هنالك خطا ما'
     this.intiateerrormsgb = true;
setTimeout(() => {
  this.intiateerrormsgb = false;
}, 3000)
    }
    else if(response.validate_amout_status =='1204') {
      this.intiateerrormsg='يجب ألا يكون الرصيد صفريًا أو فارغًا'
      this.intiateerrormsgb = true;
 setTimeout(() => {
   this.intiateerrormsgb = false;
 }, 3000)
     }
     else if(response.validate_amout_status =='1206') {
      this.intiateerrormsg='الرصيد غير صالح '
      this.intiateerrormsgb = true;
 setTimeout(() => {
   this.intiateerrormsgb = false;
 }, 3000)
     }
     else if(response.validate_amout_status =='1205') {
      this.intiateerrormsg='الحد الأدنى للرصيد 100 ريال'
      this.intiateerrormsgb = true;
 setTimeout(() => {
   this.intiateerrormsgb = false;
 }, 3000)
     }
     else if(response.validate_amout_status =='1203') {
      this.intiateerrormsg='يجب أن يكون الرصيد اقل من  10000 ريال'
      this.intiateerrormsgb = true;
 setTimeout(() => {
   this.intiateerrormsgb = false;
 }, 3000)
     }
    
     else if(response.validate_amout_status =='1197') {
      this.intiateerrormsg='هنالك خطا ما'
      this.intiateerrormsgb = true;
 setTimeout(() => {
   this.intiateerrormsgb = false;
 }, 3000)
     }
    else if(response.validate_amout_status =='1198') {
      this.intiateerrormsg='رصيد غير كاف'
      this.intiateerrormsgb = true;
 setTimeout(() => {
   this.intiateerrormsgb = false;
 }, 3000)
     }
    else if(response.validate_amout_status =='1001') {
      this.intiateerrormsg='فشل '
      this.intiateerrormsgb = true;
setTimeout(() => {
  this.intiateerrormsgb = false;
}, 3000)
    }
  }else if(response.Token_Status=='1120'){
    this.intiateerrormsgb = true;
    this.intiateerrormsg = 'غير مصرح';
    setTimeout(() => {
      this.intiateerrormsgb = false;
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.intiateerrormsgb = true;
    this.intiateerrormsg = 'انتهت صلاحية الرمز';
    setTimeout(() => {
      this.intiateerrormsgb = false;
    }, 3000);
  }

 
  // this.bankName=response.bank_name
  // this.ibanName=response.bank_iban
  // this.bankaccountholdername=response.bank_account_holder_name
})
} }
  }
  closedialog(){
    this.dialogRef.close(this.withdrawresponse);
  }
  GetBankDetails(){
    this.detectDevice()
    console.log("bank")
    const object: any = {}
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
     object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
     console.log(object)
     this.spinnerfull.show()
     this.authService.GetBankDetails(object,this.accesstoken).subscribe(response=>{
      this.spinnerfull.hide()
      console.log(response)
      this.withdrawForm.patchValue({
        bankname:response.bank_name,
        ibannumber:response.bank_iban,
        holdername:response.bank_account_holder_name
        
        
      })
      // this.bankName=response.bank_name
      // this.ibanName=response.bank_iban
      // this.bankaccountholdername=response.bank_account_holder_name
    })
  }
 
}

