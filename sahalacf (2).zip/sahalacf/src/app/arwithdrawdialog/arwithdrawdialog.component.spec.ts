import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArwithdrawdialogComponent } from './arwithdrawdialog.component';

describe('ArwithdrawdialogComponent', () => {
  let component: ArwithdrawdialogComponent;
  let fixture: ComponentFixture<ArwithdrawdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArwithdrawdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArwithdrawdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
