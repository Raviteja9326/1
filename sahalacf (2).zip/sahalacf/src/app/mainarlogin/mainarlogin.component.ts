import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorStateMatcher } from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { NgxSpinnerService } from "ngx-spinner";
import { RefreshtokenService } from '../services/refreshtoken.service';


export function MustMatch(controlName: string, matchingControlName: string) {
  return (otpForm: FormGroup) => {
    const control = otpForm.controls[controlName];
    const matchingControl = otpForm.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  }
}
export function MustMatch1(controlName: string, matchingControlName: string) {
  return (forgotOtp: FormGroup) => {
    const control = forgotOtp.controls[controlName];
    const matchingControl = forgotOtp.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  }
}
@Component({
  selector: 'app-mainarlogin',
  templateUrl: './mainarlogin.component.html',
  styleUrls: ['./mainarlogin.component.scss']
})
export class MainarloginComponent implements OnInit {

  
    forgot2Form = false;
    password = false;
    spinner = false;
    forgotdata=[];
    submitted4 = false;
    otpsubmitted = false;
    forgot1Form = false;
    sign = false;
    errmsg;
    errmsg1;
    forgotOtp :FormGroup;
    loginResponse: any;
    submitted: boolean;
    forgotForm:FormGroup;
    otpsubmitted1 = false;
    submitted6 = false;
    errorMessage: string;
    loginError: boolean;
    login = true; 
    otpform = false;
    deviceInfo = null;
    hide1 = true;
    hide4 = false;
    hide6 = false;
  msgdis;
  msgdis1;
    passupdateSucess: string;
    passupdatesucc: boolean;
    otperrmessage: string;
  tokener: boolean;
  tokenmsg: string;
    constructor(private fb: FormBuilder, private router: Router, private http: HttpClient,private spinnerfull: NgxSpinnerService,
      private token:RefreshtokenService,
      private auth:AuthService,private devicedetect:DeviceDetectorService,private deviceservice:DeviceinfoserviceService) {
  
     
        this.token.unArauthmsg.subscribe(message =>{
          console.log(message)
          
  
          if(message != 'default arabictoken') {
            
        this.tokener = true;
        this.tokenmsg = message
        setTimeout(() => {
          this.tokener = false;
        }, 9000); 
  
          }
          else { 
            this.tokenmsg = ''
          }
        })
      
  
    }
    loginForm: FormGroup;
    otpForm: FormGroup;
    geolocationPosition: object;
    longitude: string;
    latitude: string;
    ipAddress: string;
    hide3=false;
    hide=false;
    ngOnInit() {
  
  
  
      this.http.get<{ ip: string }>('https://jsonip.com/')
        .subscribe(geoLocationResponse => {
          this.ipAddress = geoLocationResponse.ip;
        });
      //     this.authService.getIp().subscribe(response=>{
      // response
  
      //     })
      this.geolocationPosition = {};
      if (window.navigator && window.navigator.geolocation) {
        window.navigator.geolocation.getCurrentPosition(
          position => {
            this.geolocationPosition = position;
          }
        );
      } else {
  
      }
      this.loginForm = this.fb.group({
        useremail: ['', [Validators.required, Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
      });
  
  
  
      this.otpForm = this.fb.group({
        otp: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(6), Validators.pattern("^[0-9]*$")]],
  
      });
  
      this.forgotForm = this.fb.group({
        email: ['', [Validators.required, Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")]],
    
      });
  
      this.forgotOtp = this.fb.group({
        otp: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(6), Validators.pattern("^[0-9]*$")]],
  
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]],
        
       confirmpassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
      },{
        validator: MustMatch1('password', 'confirmpassword')
        });
  
  
    }
  
  
    get loginControllers() { return this.loginForm.controls }
  
    get Otpcontrol() { return this.otpForm.controls }
  
    get e() {
      return this.forgotForm.controls
    }
    get o() {
      return this.forgotOtp.controls
    }
  
    numberOnly(event): boolean {
      const charCode = event.which ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
  
    showPosition(position) {
      if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
      } else {
  
      }
    }
  
  
    isUserAuthenticated() {
      this.submitted = true;
  if(this.loginForm.valid) {
    
  const obj:any = {}
  
  // obj['email'] = this.loginForm.value.useremail;
  // obj['password'] = this.loginForm.value.password;
    
    obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
    obj['deviceType'] = 'Web';
    obj['iPAddress'] = this.deviceservice.deviceinfo.ipAdress;
    obj['longitude'] = this.deviceservice.deviceinfo.logintude;
    obj['latitude'] = this.deviceservice.deviceinfo.latitude;
    obj['browserType'] = this.deviceservice.deviceinfo.browserType;
    obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
    obj['osType'] = this.deviceservice.deviceinfo.osType;
    obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
    obj['language'] ='en';
  
  // console.log(obj)
  // this.spinner = true;
  this.spinnerfull.show();
  this.auth.isauthenticated(obj,this.loginForm.value.useremail,this.loginForm.value.password).subscribe(res =>{
    // console.log(res)
    // this.spinner = false;
    this.spinnerfull.hide();
    const object:any = {}
    if(res.login_status =='1000'){
      object['FirstName'] = res.FirstName;
      object['LastName']   = res.LastName;
      object['LastLogin'] = res.LastLogin;
      object['isMobileVerified'] = res.isMobileVerified;
      object['isEmailVerified']  = res.isEmailVerified;
      object['accesstoken']   = res.token;
      object['id']=res.id
      object['profileStatus']=res.profileStatus;
      object['ProfilePic'] = res.ProfilePic;
     
      if(res.UserType == 'SME') {
        this.router.navigate(['/arabicwebsmeapp/webappsmedashboard'])
        object['redirect'] = "arabicwebsmeapp";
        object['isBankInformationProvided']    = res.isBankInformationProvided;
        object['isCompnayInformationProvided']    = res.isCompnayInformationProvided;
        object['isDcoumentsInformationProvided']   = res.isDcoumentsInformationProvided;
        object['isShareHolderInformationProvided'] = res.isShareHolderInformationProvided;
        object['isPolicyAccepted'] = res.isPolicyAccepted;
        object['isTermsAccepted'] = res.isTermsAccepted;
      }
      else {
  
        this.router.navigate(['/arabicwebapp/webappdashboard'])
        
        object['redirect'] = "arabicwebapp";
        object['isPolicyAccepted']   = res.isPolicyAccepted;
        object['isBankInfoProvided']    = res.isBankInfoProvided;
        object['isInvestorInfoProvided']    = res.isInvestorInfoProvided;
        object['isTermsAccepted']  = res.isTermsAccepted;
        object['isBankAccountLetterUploaded'] = res.isBankAccountLetterUploaded;
      }
   
      sessionStorage.setItem('currentUser',JSON.stringify(object))
      this.token.changeMessage(res);
    }
  
    else if(res.login_status == '1002') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1023') {
      this.errmsg = 'بريد المستخدم الالكتروني  مطلوب';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1024') {
      this.errmsg = 'معرف البريد الالكتروني غير صالح ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1025') {
      this.errmsg = 'حقل كلمة المرور فارغ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
    else if(res.login_status == '1026') {
      this.errmsg = 'كلمة المرور يجب ان تكون كحد ادني ٨ احرف وكحد اقصى ٢٠ حرف';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1013') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1014') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1011') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1012') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
      else if(res.login_status == '1003') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1004') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1005') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1006') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1007') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
  
      else if(res.login_status == '1009') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1010') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1008') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1015') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
        else if(res.login_status == '1016') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1090') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1091') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1092') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
        else if(res.login_status == '1095') {
          this.errmsg = 'الحساب غير موجود';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1099') {
          this.errmsg = 'حسابك معلّق مؤقتًا ، يُرجى الاتصال بخدمة دعم العملاء على الرقم +920092 أو الكتابة إلينا على support@sahlahcf.com من عنوان بريدك الإلكتروني المسجل';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1093') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1097') {
          this.errmsg = 'كلمة المرور المؤقتة  أرسلت';
          // this.msgdis = true;
          // setTimeout(() => {
          //   this.msgdis = false;
          // }, 3000);
          this.otpform = true;
          this.login = false;
  
  
        }
        else if(res.login_status == '1096') {
          this.errmsg = 'بيانات الاعتماد غير صالحة';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000000);
        }
  
        else if(res.login_status == '1098') {
          this.errmsg = 'كلمة المرور المؤقتة لم ترسل';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1094') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1001') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }

        else if(res.login_status == '1100') {
  
          this.msgdis = true;
          this.errmsg = 'لحساب محظور يرجي المحاولة في وقت اخر';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
  
        }
  })
  }
  
    }
  
    signup() {
      this.sign = !this.sign;
      if(this.sign){
      this.sign = true;
      } else {
        this.sign = false;
      }
    }
  
   
  
  
    isOtpVerified() {
      this.otpsubmitted = true;
      if(this.otpForm.valid) {
        const obj:any = []
        obj['email'] = this.loginForm.value.useremail;
  obj['password'] = this.loginForm.value.password;
    
    obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
    obj['deviceType'] = 'Web';
    obj['iPAddress'] = this.deviceservice.deviceinfo.ipAdress;
    obj['longitude'] = this.deviceservice.deviceinfo.logintude;
    obj['latitude'] = this.deviceservice.deviceinfo.latitude;
    obj['browserType'] = this.deviceservice.deviceinfo.browserType;
    obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
    obj['osType'] = this.deviceservice.deviceinfo.osType;
    obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
    obj['language'] ='en'
    obj['otp'] = this.otpForm.value.otp;
  
    // console.log(obj)
    // this.spinner = true;
    this.spinnerfull.show();
  this.auth.loginotpverified(obj).subscribe(res =>{
    // this.spinner = false;
    this.spinnerfull.hide();
    // console.log(res)
    const object:any  = {}
    if(res.login_status =='1000'){
      object['FirstName']  = res.FirstName;
      object['LastName']     = res.LastName;
      object['LastLogin']    = res.LastLogin;
      object['isMobileVerified']   = res.isMobileVerified;
      object['isEmailVerified']   = res.isEmailVerified;
      object['token']   = res.token;
      object['ProfilePic'] = res.ProfilePic;
      if(res.UserType == 'SME') {
        this.router.navigate(['/arabicwebsmeapp/webappsmedashboard'])
        object['isBankInformationProvided']    = res.isBankInformationProvided;
        object['isCompnayInformationProvided']    = res.isCompnayInformationProvided;
        object['isDcoumentsInformationProvided']   = res.isDcoumentsInformationProvided;
        object['isShareHolderInformationProvided'] = res.isShareHolderInformationProvided;
        object['isPolicyAccepted'] = res.isPolicyAccepted;
        object['isTermsAccepted'] = res.isTermsAccepted;
        
      }
      else { 
  
        // this.router.navigate(['/englishwebapp/webappdashboard'])
        this.router.navigate(['/arabicwebapp/webappdashboard'])
        object['isPolicyAccepted']   = res.isPolicyAccepted;
        object['isBankInfoProvided']    = res.isBankInfoProvided;
        object['isInvestorInfoProvided']    = res.isInvestorInfoProvided;
        object['isTermsAccepted']  = res.isTermsAccepted;
        object['isBankAccountLetterUploaded'] = res.isBankAccountLetterUploaded;
      }
  
      sessionStorage.setItem('currentUser',JSON.stringify(object))
      this.token.changeMessage(res);
    }
    
    else if(res.login_status == '1002') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1023') {
      this.errmsg = 'بريد المستخدم الالكتروني  مطلوب';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1024') {
      this.errmsg = 'معرف البريد الالكتروني غير صالح ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1025') {
      this.errmsg = 'كلمة المرور فارغة';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
    else if(res.login_status == '1026') {
      this.errmsg = 'يجب أن تكون كلمة المرور على الأقل 8 و 20 بحد أقصى';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1013') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1014') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1011') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1012') {
      this.errmsg = 'هناك خطئ ما ';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
      else if(res.login_status == '1003') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1004') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1005') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1006') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1007') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
  
      else if(res.login_status == '1009') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1010') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1008') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1015') {
        this.errmsg = 'هناك خطئ ما ';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
        else if(res.login_status == '1016') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1090') {
          this.errmsg = 'otp فارغ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1091') {
          this.errmsg = 'يجب أن يكون OTP عددية';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1092') {
          this.errmsg = 'يجب أن يكون طول OTP 4 أرقام';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
        else if(res.login_status == '1095') {
          this.errmsg = 'الحساب غير موجود';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1099') {
          this.errmsg = 'حسابك معلّق مؤقتًا ، يُرجى الاتصال بخدمة دعم العملاء على الرقم +920092 أو الكتابة إلينا على support@sahlahcf.com من عنوان بريدك الإلكتروني المسجل';

          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1093') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
       
        else if(res.login_status == '1096') {
          this.errmsg = 'بيانات الاعتماد غير صالحة ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
        else if(res.login_status == '1098') {
          this.errmsg = 'لم يتم إرسال كلمة المرور لمرة واحدة ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1099') {
          this.errmsg = 'حسابك معلّق مؤقتًا ، يُرجى الاتصال بخدمة دعم العملاء على الرقم +920092 أو الكتابة إلينا على support@sahlahcf.com من عنوان بريدك الإلكتروني المسجل';

          this.msgdis = true;
          setTimeout(() => { 
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1094') {
          this.errmsg = 'هناك خطئ ما ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1095') {
          this.errmsg = 'الحساب غير موجود';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1001') {
          this.errmsg = 'فشل';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }

        else if(res.login_status == '1100') {
  
          this.msgdis = true;
          this.errmsg = 'لحساب محظور يرجي المحاولة في وقت اخر';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
  
        }
  })
      }
  
     
  
    }
  
    forgot() {
      this.forgot1Form = true;
      this.login = false;
      // console.log('hdfjdfh')
    }
  
    forgot1(){
      this.submitted4 = true;
    
      this.login = false;
      if(this.forgotForm.value.email !== ''&& this.forgotForm.value.email !== null) {
        const obj :any ={}
        obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
        obj['deviceType'] = 'Web';
        obj['ipAddress'] = this.deviceservice.deviceinfo.ipAdress;
        obj['longitude'] = this.deviceservice.deviceinfo.logintude;
        obj['latitude'] = this.deviceservice.deviceinfo.latitude;
        obj['browserType'] = this.deviceservice.deviceinfo.browserType;
        obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
        obj['osType'] = this.deviceservice.deviceinfo.osType;
        obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
        obj['language'] ='en'
        obj['email'] = this.forgotForm.value.email;
        obj['countryCode'] = 'SA';
        this.spinnerfull.show();
      
  // console.log(obj)
  // this.spinner = true;
  this.auth.forgotpassword(obj).subscribe(res =>{
    // console.log(res)
  // this.spinner= false;
  this.spinnerfull.hide();
    if(res.forgetpwd_response =='1000'){
      this.forgot2Form = true;
      this.forgot1Form = false;
    }
   else if(res.forgetpwd_response == '1001'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if (res.forgetpwd_response == '1002'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1003'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1004'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
  
    else if(res.forgetpwd_response == '1005'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1006'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1007'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1008'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1009'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1010'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1011'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1012'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1013'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
      else if(res.forgetpwd_response == '1014'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1015'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1016'){
      this.errmsg1 ='هناك خطئ ما ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1023'){
      this.errmsg1 ='بريد المستخدم الالكتروني  مطلوب';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    } 
    else if(res.forgetpwd_response == '1024'){
      this.errmsg1 ='معرف البريد الالكتروني غير صالح ';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
     }
    else if(res.forgetpwd_response == '1095'){
      this.errmsg1 ='الحساب غير موجود';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
     }
  
  
  
      })
      
    }
  }
  
  passwordpage(){
   if(this.forgotOtp.value.otp.length >= 6){
    this.otperrmessage='';
    this.forgot1Form = false;
    this.login = false;
    this.forgot2Form = true;
    this.password = true;
   }
   else {
    this.otperrmessage="ادخل OTP صالح للمتابعة"
    this.password = false;
   }
  }
  
    otpsave() {
      this.submitted6 = true;
      this.forgot1Form = false;
      this.login = false;
      console.log(this.forgotOtp.valid)
    if(this.forgotOtp.valid) {
      const obj :any ={}
      obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
      obj['deviceType'] = 'Web';
      obj['ipAddress'] = this.deviceservice.deviceinfo.ipAdress;
      obj['longitude'] = this.deviceservice.deviceinfo.logintude;
      obj['latitude'] = this.deviceservice.deviceinfo.latitude;
      obj['browserType'] = this.deviceservice.deviceinfo.browserType;
      obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
      obj['osType'] = this.deviceservice.deviceinfo.osType;
      obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
      obj['language'] ='en'
      obj['email'] = this.forgotForm.value.email;
      obj['countryCode'] = 'SA';
      obj['otp'] = this.forgotOtp.value.otp;
      obj['newPassword'] = this.forgotOtp.value.password;
      obj['conformPassword'] = this.forgotOtp.value.confirmpassword;
      this.spinnerfull.show();
  
       console.log(obj)
    //  this.spinner = true;
      this.auth.forgotpasswordotp(obj).subscribe(res =>{
        this.spinnerfull.hide();
       console.log(res)
        this.spinner = false;
        if(res.forgetpwd_response =='1000'){
          this.forgotOtp.reset();
          this.submitted6 = false;
         this.passupdateSucess="تم تحديث كلمة السر بنجاح";
         this.passupdatesucc=true;
         setTimeout(() => {
           this.passupdatesucc = false;
           this.login=true;
           this.forgot2Form=false;
         }, 3000);
        }
       else if(res.forgetpwd_response == '1001'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if (res.forgetpwd_response == '1002'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1003'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1004'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
      
        else if(res.forgetpwd_response == '1005'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1006'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1007'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1008'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1009'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1010'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1011'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1012'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1013'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
          else if(res.forgetpwd_response == '1014'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1015'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1016'){
          this.errmsg1 ='هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1023'){
          this.errmsg1 ='بريد المستخدم الالكتروني  مطلوب';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        } 
        else if(res.forgetpwd_response == '1024'){
          this.errmsg1 ='معرف البريد الالكتروني غير صالح ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
        else if(res.forgetpwd_response == '1093'){
          this.errmsg1 ='كلمة المرور غير صحيحة';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1085'){
          this.errmsg1 ='كلمة المرور الجديدة فارغة';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1086'){
          this.errmsg1 ='كلمة المرور السرية فارغة';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
  
         else if(res.forgetpwd_response == '1087'){
          this.errmsg1 ='يجب أن يكون طول كلمة المرور الجديدة 8 دقائق وحد أقصى 16';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1088'){
          this.errmsg1 ='يجب تأكيد مدة كلمة المرور على الأقل 8 و 16';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1089'){
          this.errmsg1 ='كلمة المرور الجديدة وكلمة المرور المعيارية ليست متطابقة';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1090'){
          this.errmsg1 ='الحساب غير موجود';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1090'){
          this.errmsg1 ='كلمة المرور لمرة واحدة فارغة';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1091'){
          this.errmsg1 ='يجب أن يكون OTP عددية';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1092'){
          this.errmsg1 ='otp غير صالح';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
          else if(res.forgetpwd_response == '1093'){
            this.errmsg1 ='otp غير صالح';
            this.msgdis1=true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
         } else if(res.forgetpwd_response == '1094'){
          //this.errmsg1 ='OTP LEANGTH SHOULD BE 4 DIGITS';
          this.errmsg1 = 'هناك خطئ ما ';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1042'){
          this.errmsg1 ='الحساب غير موجود';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
      
      })
  
    }
  
     
    }
    navigateenglish(){
      this.router.navigate(['/auth/login'])
      this.router.navigate(['/home'])
    }
    forgetBack(){
   
      this.forgot1Form = false;
      this.login = true;
    }
    otpBack(){
      this.forgot2Form=false
      this.forgot1Form=true; 
    }
  }