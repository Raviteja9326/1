import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainarloginComponent } from './mainarlogin.component';

describe('MainarloginComponent', () => {
  let component: MainarloginComponent;
  let fixture: ComponentFixture<MainarloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainarloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainarloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
