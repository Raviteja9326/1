import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArlayoutComponent } from './arlayout.component';

describe('ArlayoutComponent', () => {
  let component: ArlayoutComponent;
  let fixture: ComponentFixture<ArlayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArlayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArlayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
