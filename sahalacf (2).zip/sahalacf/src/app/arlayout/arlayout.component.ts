import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arlayout',
  templateUrl: './arlayout.component.html',
  styleUrls: ['./arlayout.component.scss']
})
export class ArlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
