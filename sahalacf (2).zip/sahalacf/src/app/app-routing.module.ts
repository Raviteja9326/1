import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MatTableComponent } from './mat-table/mat-table.component';
import { WildcardComponent } from './wildcard/wildcard.component';
import { MainloginComponent } from './mainlogin/mainlogin.component';
import { MainarloginComponent } from './mainarlogin/mainarlogin.component';

const routes: Routes = [
 
 {path:'auth',loadChildren:()=>import('./auth/auth.module').then(m=>m.AuthModule)},

// {path:'arabicwebapp',component: ArsidebarComponent,loadChildren:()=>import('./arabicWebapp/arabic.module').then(m=>m.ArabicModule),canActivate:[AuthguardGuard]},

  {path:'home',component:MainloginComponent},

{path:'arhome',component:MainarloginComponent},

{path:'',redirectTo:'arhome',pathMatch:'full'},

{path:'error',component:WildcardComponent},

{path: '**', redirectTo: 'error', pathMatch: 'full'}
,
{path:'table',component:MatTableComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true, scrollPositionRestoration: 'enabled',
  anchorScrolling: 'enabled',onSameUrlNavigation: 'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
