import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { AuthService } from '../../services/auth.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ArwithdrawdialogComponent } from '../../arwithdrawdialog/arwithdrawdialog.component';
import PerfectScrollbar from 'perfect-scrollbar';
import * as $ from "jquery";
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { DocumentComponent } from '../arabicWebapp/dashboard/dashboard.component';

declare interface ROUTES {
  path: string;
  title: string;
  icon: string;
  class: string; 
} 
export const ROUTES = [];

@Component({
  selector: 'app-invarabicsidenav',
  templateUrl: './invarabicsidenav.component.html',
  styleUrls: ['./invarabicsidenav.component.scss']
})
export class InvarabicsidenavComponent implements OnInit {
  user: any;
  name: any;
  registrationid: any;
  profileStatus: string;
  accesstoken: any;
  errormsg: string;
  deviceInfo: any;
  balance: any;
  doop: any;
  withdrawUser: any;
  profilestatuserrmsg: string;
  menuItems: any[];
  sessiondata: any;

  constructor(private router:Router,private authservice:AuthService,public dialog: MatDialog,
    private deviceinfoservice:DeviceinfoserviceService,private token:RefreshtokenService,
    private deviceService:DeviceDetectorService) {
      
    this.user = JSON.parse(sessionStorage.getItem('currentUser'))

    this.accesstoken = this.user.accesstoken;
    this.detectDevice()

    this.name=this.user.FirstName 
    this.registrationid=this.user.id
    
    // if( this.user.profileStatus=='1197'){ 
    //   this.profileStatus="قيد الانتظار"
    //    }else if( this.user.profileStatus=='1196'){
    //     this.profileStatus="تم الموافقة"
    //      }



    

    this.detectDevice()
     // if( this.user.profileStatus=='1197'){
     //   this.profileStatus="Pending for Approval"
     //    }else if( this.user.profileStatus=='1196'){
     //     this.profileStatus="Approved"
     //      }
    
  
// this.routerallfundsgetbalance();
// this.routerdashboardgetbalance();
// this.routerinvestgetbalance();
// this.routermanage()
// this.routeropeergetbalance()
// this.routerprofile();
// this.routertransgetbalance();
// this.routeropeergetbalance();
  }
  updatePS(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && !this.isMac()) {
      const elemSidebar = <HTMLElement>document.querySelector('.sidebar .sidebar-wrapper');
      let ps = new PerfectScrollbar(elemSidebar, { wheelSpeed: 2, suppressScrollX: true });
    }
  }
  isMac(): boolean {
    let bool = false;
    if (navigator.platform.toUpperCase().indexOf('MAC') >= 0 || navigator.platform.toUpperCase().indexOf('IPAD') >= 0) {
      bool = true;
    }
    return bool;
  }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  }

  ngOnInit(): void {

  this.menuItems = ROUTES.filter(menuItem => menuItem);
    
  history.pushState(null, null, location.href);
  window.onpopstate = function () {
      history.go(1);
  };

  $(".nav li").click(function(){ $(".collapse").collapse('hide'); });

  $('.nav-container').addClass('expand');
          
  $('.nav-container ul li a').on('click', function () {
         $('.nav-container ul .active').removeClass('active');
        $(this).addClass('active');
  });
  this.grtbalancedetails();

  $('.nav-section').addClass('expand');
  $('.nav-section ul li a').on('click', function () {
         $('.nav-section ul .active').removeClass('active');
        $(this).addClass('active');
  });
 $('.menu-icon').click(function () {
  
   $('.nav-section').addClass('expand');
   $('.main-section').toggleClass('expand');

 });
  // $('.menu-icon').click(function () {

  //   $('.nav-section').toggleClass('expand');
  //   $('.main-section').toggleClass('expand');
  // });

  // $('.dropdown-toggle').dropdown();
  }



  

  routerdashboardgetbalance() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))


    if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

      const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
        width: '650px',
        height:'auto',
    
    
    
      }); 
    }

else {
this.router.navigate(['/arabicwebapp/webappdashboard'])
}



    this.grtbalancedetails();

  }


  routeropeergetbalance() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
width: '650px',
height:'auto',



}); 



}

else {

console.log('routeeeeeee')
this.router.navigate(['/arabicwebapp/webappoppotunities'])
}



    this.grtbalancedetails();

  }
  

  routerreceivegetbalance() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
width: '650px',
height:'auto',



});

}

else {

console.log('routeeeeeee')
this.router.navigate(['/arabicwebapp/webappreceivable'])
}



    this.grtbalancedetails();

  }
  
  routertransgetbalance() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
width: '650px',
height:'auto',



});

}

else {

console.log('routeeeeeee')
this.router.navigate(['/arabicwebapp/webapptransaction'])
}



    this.grtbalancedetails();

  }
  
  routerinvestgetbalance() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
width: '650px',
height:'auto',



});

}

else {

console.log('routeeeeeee')
this.router.navigate(['/arabicwebapp/webappinvestment'])
}



    this.grtbalancedetails();

  }
  

  routerallfundsgetbalance() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
width: '650px',
height:'auto',



});

}

else {

console.log('routeeeeeee')
this.router.navigate(['/arabicwebapp/webappallfunds'])
}



    this.grtbalancedetails();

  }
  

  routerprofile() {
    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

    if(this.sessiondata.isBankAccountLetterUploaded == 'No') {
    
      const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
        width: '650px',
        height:'auto',
    
    
    
      });
    
    }
    
    else {
    
      console.log('routeeeeeee')
      this.router.navigate(['/arabicwebapp/profile'])
    }

  }



  routermanage() {
    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

    if(this.sessiondata.isBankAccountLetterUploaded == 'No') {
    
      const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
        width: '650px',
        height:'auto',
    
    
    
      });
    
    }
    
    else {
    
      console.log('routeeeeeee')
      this.router.navigate(['/arabicwebapp/manageAccount'])
    }

  }
  







  
  reqwrdialogfun(){

    this.withdrawUser =JSON.parse(sessionStorage.getItem('currentUserbalance'))
    // console.log(this.withdrawUser)
      if(this.withdrawUser.profileStatus === "1197"){
        this.profilestatuserrmsg ="حالة الملف الشخصي معلقة"
        const dialogRef = this.dialog.open(ProfilestatusComponent, {
          width: '250px',
          data:this.profilestatuserrmsg
    
    
        });
        dialogRef.afterClosed().subscribe(result => {
          
    
        })
       
  
      }
      else  if (this.withdrawUser.balance === "0.0"){
        this.profilestatuserrmsg ="الرصيد غير متاح للسحب."
      
        const dialogRef = this.dialog.open(ProfilestatusComponent, {
          width: '250px',
          data:this.profilestatuserrmsg
    
    
        });
        dialogRef.afterClosed().subscribe(result => {
          
    
        })
      }
  
      else  {
        
  
      // console.log("dialog open")
      const dialogRef = this.dialog.open(ArwithdrawdialogComponent, {
        panelClass: 'custom-dialog-container',
        disableClose: true,
        width: '60%',
        height:'500px',
        data:this.withdrawUser
  
  
      });
  
      dialogRef.afterClosed().subscribe(result => {
        // console.log(result)
      
  
      });
    }
    }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log(this.deviceInfo)
  }


  // grtbalancedetails() {
  //   console.log('navya')
  //      this.authservice.getbalanceinfo(this.user.accesstoken,this.doop).subscribe(res =>{
  //        console.log(res)
    
  //        if(res.Token_Status == '1119') {
  //          this.balance = res.balance; 
  //          this.profileStatus = res.profile_status

  //          if(  res.profile_status=='1197'){ 
  //           this.profileStatus="قيد الانتظار"
  //            }else if(  res.profile_status=='1196'){
  //             this.profileStatus="تم الموافقة"
  //              }
  //        }
    
  //      })
  //    }
  grtbalancedetails() {
    // console.log('navya')

    this.user = JSON.parse(sessionStorage.getItem('currentUser'))

    this.accesstoken = this.user.accesstoken;
    this.detectDevice()

    this.name=this.user.FirstName 
    this.registrationid=this.user.id
    
       this.authservice.getbalanceinfo(this.user.accesstoken,this.data).subscribe(res =>{
        //  console.log(res)
    
         if(res.Token_Status == '1119') {
           this.balance = res.balance; 
           if(  res.profile_status=='1197'){
            this.profileStatus="بانتظار الموافقة"
             }else if( res.profile_status=='1196'){
              this.profileStatus="تمت الموافقة"
               }
         }
    
       
         
    
       
        //  const object2: any = {}
        //  object2['profileStatus']=  res.profile_status
        //  object2['balance'] = res.balance

        
        //  sessionStorage.setItem('currentUserbalance',JSON.stringify(object2))
        
        this.token.changebalance(res)
       })
    
       
     }
  data(accesstoken: any, data: any) {
    throw new Error("Method not implemented.");
  }
  
    logout(){ 
    
      const obj :any ={}
      obj['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      obj['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
   
      this.authservice.logout(obj,this.accesstoken).subscribe(res =>{
        console.log(res)
        sessionStorage.clear();
  
      //  this.router.navigate(['/arhome'])
        if(res.Token_Status =='1119'){
          if(res.logout_response == '1000') {
           
          }
  
          else if(res.logout_response == '1001'){
            sessionStorage.clear();
  
          //  this.router.navigate(['/arhome'])
          }
          else if(res.logout_response == '1011'){
            sessionStorage.clear();
  
           // this.router.navigate(['/arhome'])
          }
          else if(res.logout_response == '1012'){
  
            sessionStorage.clear();
  
          //  this.router.navigate(['/arhome'])
          }
        }
  
        else if(res.Token_Status =='1120'){
          this.errormsg = 'غير مصرح به '
        }
        else if(res.Token_Status =='1121'){
          this.errormsg = '  انتهت صلاحية التزكر'
        }
       
  
  
  
  
      })
   
    }
    openNav(){
      document.getElementById("mySidenav").style.width = "250px";
    }
    closeNav(){
      document.getElementById("mySidenav").style.width = "0";
      this.grtbalancedetails();
    }

}
@Component({
  selector: 'app-profilestatus',
  template: `
  <div style="display: flex;justify-content: space-between;direction: rtl; ">
    <h2></h2>
<div style="cursor:pointer;">
<i class="fa fa-times" aria-hidden="true"   (click)="onNoClick()"></i>
</div>
    </div>
  <div class="row">
  <div class="col-lg-12">
<div class="row" style="padding-left: 15px;float: right;">
{{profilestatuserrmsg}}
</div>






</div>



  `
})
export class ProfilestatusComponent implements OnInit {
  profilestatuserrmsg: any;

 

  constructor(
    public dialogRef: MatDialogRef<ProfilestatusComponent>,@Inject(MAT_DIALOG_DATA) public data: any
   
   
    // @Optional() @Inject(MAT_DIALOG_DATA) public data: dataSource
  ) {
    
    this.profilestatuserrmsg=data
  }


  ngOnInit() {
    

  }
  onNoClick() {
    
    this.dialogRef.close();
  }

  

  
}