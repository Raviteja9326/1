import { Component, ElementRef, OnInit } from '@angular/core';
import {Location} from "@angular/common";
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { MatDialog } from '@angular/material/dialog';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ArwithdrawdialogComponent } from 'src/app/arwithdrawdialog/arwithdrawdialog.component';
import { ProfilestatusComponent } from '../invarabicsidenav/invarabicsidenav.component';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { DocumentComponent } from '../arabicWebapp/dashboard/dashboard.component';
@Component({
  selector: 'app-invheaderarbic',
  templateUrl: './headerarbic.component.html',
  styleUrls: ['./headerarbic.component.scss']
})
export class HeaderarbicComponent implements OnInit {
  private listTitles: any[];
  location: Location;
  mobile_menu_visible: any = 0; 
  private toggleButton: any;
  private sidebarVisible: boolean;
  user: any;
  name: any;
  registrationid: any;
  profileStatus: string;
  accesstoken: any;
  errormsg: string;
  deviceInfo: any;
  data: any;
  balance: any;
  withdrawUser: any;
  profilestatuserrmsg: string;
  balanceprofile: any;
  sessiondata: any;

  constructor(location: Location,
      private element: ElementRef,private router:Router, private authservice:AuthService,public dialog: MatDialog,
      private deviceinfoservice:DeviceinfoserviceService,private token:RefreshtokenService,
      private deviceService:DeviceDetectorService) {
        this.user = JSON.parse(sessionStorage.getItem('currentUser'))

        this.accesstoken = this.user.accesstoken;
        this.detectDevice()
    
        this.name=this.user.FirstName 
        this.registrationid=this.user.id


        this.token.balanceammount.subscribe(balancedetails =>{
          console.log(balancedetails)
          sessionStorage.setItem('currentUserbalance',JSON.stringify(balancedetails))
          this.balanceprofile = balancedetails
          this.balance = this.balanceprofile.balance
    
     if( this.balanceprofile.profile_status=='1197'){
      this.profileStatus="بانتظار الموافقة"
           }else if( this.balanceprofile.profile_status=='1196'){
            this.profileStatus="تمت الموافقة"
             }
           
        })
       }

  ngOnInit(): void {
    const navbar: HTMLElement = this.element.nativeElement;
    this.toggleButton = navbar.getElementsByClassName("navbar-toggler")[0];
    this.router.events.subscribe(() => {
      this.sidebarClose();
      // tslint:disable-next-line:prefer-const
      var $layer: any = document.getElementsByClassName("close-layer")[0];
      if ($layer) {
        $layer.remove();
        this.mobile_menu_visible = 0;
      }
    });
  }

  getit(){
    this.router.navigate(['/englishwebapp/webappdashboard'])
.then(() => {
window.location.reload();
});

}


  sidebarOpen() {
    const toggleButton = this.toggleButton;
    const body = document.getElementsByTagName("body")[0];
    setTimeout(function () {
      toggleButton.classList.add("toggled");
    }, 500);

    body.classList.add("nav-open");

    this.sidebarVisible = true;
  }
  sidebarClose() {
    const body = document.getElementsByTagName("body")[0];
    this.toggleButton.classList.remove("toggled");
    this.sidebarVisible = false;
    body.classList.remove("nav-open");
  }
  sidebarToggle() {
    // const toggleButton = this.toggleButton;
    // const body = document.getElementsByTagName('body')[0];
    // tslint:disable-next-line:prefer-const
    var $toggle = document.getElementsByClassName("navbar-toggler")[0];

    if (this.sidebarVisible === false) {
      this.sidebarOpen();
    } else {
      this.sidebarClose();
    }
    const body = document.getElementsByTagName("body")[0];

    if (this.mobile_menu_visible === 1) { 
      // $('html').removeClass('nav-open');
      body.classList.remove("nav-open");
      // tslint:disable-next-line: no-use-before-declare
      if ($layer) {
        // tslint:disable-next-line: no-use-before-declare
        $layer.remove();
      }
      setTimeout(function () {
        $toggle.classList.remove("toggled");
      }, 400);

      this.mobile_menu_visible = 0;
    } else {
      setTimeout(function () {
        $toggle.classList.add("toggled");
      }, 430);

      // tslint:disable-next-line:prefer-const
      var $layer = document.createElement("div");
      $layer.setAttribute("class", "close-layer");

      if (body.querySelectorAll(".main-panel")) {
        document.getElementsByClassName("main-panel")[0].appendChild($layer);
      } else if (body.classList.contains("off-canvas-sidebar")) {
        document
          .getElementsByClassName("wrapper-full-page")[0]
          .appendChild($layer);
      }

      setTimeout(function () {
        $layer.classList.add("visible");
      }, 100);

      $layer.onclick = function () {
        // asign a function
        body.classList.remove("nav-open");
        this.mobile_menu_visible = 0;
        $layer.classList.remove("visible");
        setTimeout(function () {
          $layer.remove();
          $toggle.classList.remove("toggled");
        }, 400);
      }.bind(this);

      body.classList.add("nav-open");
      this.mobile_menu_visible = 1;
    }
  } 

 
  reqwrdialogfun(){



    this.withdrawUser =JSON.parse(sessionStorage.getItem('currentUserbalance'))


    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))


    if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

      const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
        width: '650px',
        height:'auto',
    
    
    
      }); 
    }

else {




      if(this.withdrawUser.profileStatus === "1197"){
        this.profilestatuserrmsg ="حالة الملف الشخصي معلقة"
        const dialogRef = this.dialog.open(ProfilestatusComponent, {
          width: '250px',
          data:this.profilestatuserrmsg
    
    
        });
        dialogRef.afterClosed().subscribe(result => {
          
    
        })
       
  
      }
      else  if (this.withdrawUser.balance === "0.0"){
        this.profilestatuserrmsg ="الرصيد غير متاح للسحب"
      
        const dialogRef = this.dialog.open(ProfilestatusComponent, {
          width: '250px',
          data:this.profilestatuserrmsg
    
    
        });
        dialogRef.afterClosed().subscribe(result => {
          
    
        })
      }
  
      else  {
        
  
      const dialogRef = this.dialog.open(ArwithdrawdialogComponent, {
        panelClass: 'custom-dialog-container',
        disableClose: true,
        width: '60%',
        height:'500px',
        data:this.withdrawUser
  
  
      });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result == 1000) {
          this.grtbalancedetails()
        }
  
      });
    }
  }
    }

    grtbalancedetails() {
         this.authservice.getbalanceinfo(this.user.accesstoken,this.data).subscribe(res =>{
      
           if(res.Token_Status == '1119') {
             this.balance = res.balance; 
             if(  res.profile_status=='1197'){
              this.profileStatus="بانتظار الموافقة"
               }else if( res.profile_status=='1196'){
                this.profileStatus="تمت الموافقة"
                 }
           } 
      
          
          //  const object2: any = {}
          //  object2['profileStatus']=  res.profile_status
          //  object2['balance'] = res.balance
  
          
          //  sessionStorage.setItem('currentUserbalance',JSON.stringify(object2))
      
          
          this.token.changebalance(res)
       
         })
      
         
       }

  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    console.log(this.deviceInfo)
  }
  
    logout(){
      const obj :any ={}
      obj['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      obj['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
      this.authservice.logout(obj,this.accesstoken).subscribe(res =>{
        console.log(res)
        sessionStorage.clear();
 
       // this.router.navigate(['/arhome'])
        if(res.Token_Status =='1119'){
          if(res.logout_response == '1000') {
           
          }
  
          else if(res.logout_response == '1001'){
            sessionStorage.clear();
  
          //  this.router.navigate(['/arhome'])
          }
          else if(res.logout_response == '1011'){
            sessionStorage.clear();
  
          //  this.router.navigate(['/arhome'])
          }
          else if(res.logout_response == '1012'){
  
            sessionStorage.clear();
  
          //  this.router.navigate(['/arhome'])
          }
        }
  
        else if(res.Token_Status =='1120'){
          this.errormsg = 'UNAUTHORIZED'
        }
        else if(res.Token_Status =='1121'){
          this.errormsg = 'TOKEN EXPIRED'
        }
      })
   
    }


}
