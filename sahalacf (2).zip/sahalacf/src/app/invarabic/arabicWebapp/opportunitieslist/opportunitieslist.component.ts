import { Component, OnInit, Inject, Optional } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { ProgressBarMode } from '@angular/material/progress-bar';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from '@angular/common/http';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { style } from '@angular/animations';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
declare var Fingerprint2: any;



@Component({
  selector: 'app-opportunitieslist',
  templateUrl: './opportunitieslist.component.html',
  styleUrls: ['./opportunitieslist.component.scss']
})
export class OpportunitieslistComponent implements OnInit {
  displayedColumns:any = [];
  dataSource:any  = []
  color: ThemePalette = 'primary';
  mode: ProgressBarMode = 'determinate';
  value = 50;
  bufferValue = 75;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  data: any;
  acesstoken: any;
  deviceInfo: any;
  getDeviceId: any;
  deviceId: any;
  ipAddress: any;
  investform:FormGroup;
  geolocationPosition: object;
  longitude: any;
  latitude: any;
  tablepage = true;
  idpage = false;
  tabledata: any;
  errdis: string;
  display: boolean;
  loanid: any;
  loanAmount: any;
  fundedAmount: any;
  loandate: any;
  loantenure: any;
  issueInvoice: any;
  invoiceDate: any;
  industryType: any;
  companyName: any;
  compyoe: any;
  noEmp: any;
  compTurn: any;
  city: any;
  website: any;
  singleId: any;
  fundpercent: any;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private refresh:RefreshtokenService,private router:Router,
    private deviceService: DeviceDetectorService, private http:HttpClient, public dialog: MatDialog) {



    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.acesstoken= this.data.accesstoken;
    }


   


  }

  showPosition(position) {
    if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
      this.latitude = position.coords.latitude;
      this.longitude = position.coords.longitude;
     
    }
  }

  ngOnInit(): void {

    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
    
    this.getallopportunities();
    });

this.displayedColumns =['loan_id','amount','tenure','annual_roi','loan_status']




    new Fingerprint2().get((components) => {

      // console.log(components)
     
    this.deviceId = components
    this.getallopportunities();
    
    });


    this.geolocationPosition = {};
    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
        position => {
          this.geolocationPosition = position;
     
          this.showPosition(position);
        }
      );
    }


  
    this.detectDevice();
  //  console.log(this.deviceinfoservice.deviceinfo.latitude)
    
  }


  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log(this.deviceInfo)
  }

getallopportunities() {

//  console.log(this.data.accesstoken)

const object:any = {}

  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = "183.82.100.179";
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.longitude;
  object['latitude'] =  this.latitude;
  object['language'] = 'en';
  object['device_id'] =  this.deviceId
 // object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
  object['page_number'] = '0'
  object['page_size'] = '1000'
   

   console.log(object)

this.authService.getallopportunities(this.data.accesstoken,object).subscribe(res =>{
  console.log(res)

if(res.Token_Status == '1119') {

  if(res.all_opportunities_status == '1126') {
    this.tabledata = res.all_opportunities_list
    this.dataSource = this.tabledata
  } 

  if(res.all_opportunities_status == '1127') {
    this.tabledata = []
    this.dataSource = this.tabledata
console.log(this.tabledata)
this.display  = true
    this.errdis = 'لا تتوافر بيانات'
    setTimeout(() => {
      this.display = false
    }, 5000000);
  }
  
  else if(res.all_opportunities_status == '1002') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }
  else if(res.all_opportunities_status == '1003') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1004') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1005') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1006') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1007') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1008') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1009') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1010') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1011') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1012') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1013') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1014') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1015') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1016') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1150') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1151') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1152') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }
  
  else if(res.all_opportunities_status == '1153') {

    this.display = true
    this.errdis ='حدث خطا ما'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }


}


else if(res.Token_Status == '1120') {


  this.display = true
  //   this.errdis ='غير مصرح به '
     setTimeout(() => {
       this.display = false
       this.refresh.unAuthorizeArabic(this.tokenmessage)
       this.router.navigate(['/arhome'])
       sessionStorage.clear()
     }, 3000);
   }
   else if(res.Token_Status == '1121') {


    this.display = true
      
    
//this.errdis ='انتهت صلاحية التزكر'
       setTimeout(() => {
         this.display = false
         this.refresh.unAuthorizeArabic(this.tokenmessage)
         this.router.navigate(['/arhome'])
         sessionStorage.clear()
       }, 3000);
     }


     else  {


      this.display = true
         this.errdis ='حدث خطا ما'
         setTimeout(() => {
           this.display = false
         }, 3000);
       }

})



}

back() {
  // console.log('navyaaa')


  this.tablepage = true;
  this.idpage = false;
}

getparticulardata(val) {

  
    this.tablepage = false;
    this.idpage = true;
  
    // console.log(this.tabledata)
  
    this.loanid = val.loan_id
    
    this.loanAmount = val.amount
     
  
    this.fundedAmount = val.funded_amount
     
    this.fundpercent = val.fundingPercent
  
    this.loandate = val.loan_published_date
    
  
    this.loantenure = val.tenure
  
    this.issueInvoice =val.issued_invoice_for
    this.invoiceDate = val.invoice_date
    
  
    this.industryType = val.industry_type
  
    
  this.companyName = val.company_name
  
  this.compyoe = val.company_years_of_exp
  
  this.noEmp = val.number_of_employees
  
  this.compTurn = val.company_turnover
  
  this.city = val.company_city
  
  this.website = val.company_website
  
  
  
  
  }

invest() {

 
    const dialogRef = this.dialog.open(DeleteComponent,  {disableClose: true,
      width: '450px',
      data: this.loanid
 
    });
    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
      


    });
    
  }

}



/////////////invest dialog


@Component({
  
  selector: 'app-delete',
  template: `

<form [formGroup]="investform">
<div class="row" style="margin-bottom: 3%;">
<div (click)="close()" class="closeicon"><i class="fa fa-times"  style="cursor: pointer;" aria-hidden="true"></i></div>

</div>

  <div class="row">
  <div class="col-lg-12">
<div class="row amountrow" style="padding-left: 15px;">
<div class="col-lg-6"  style=" font-family: Cairo;">
أدخل مبلغ الاستثمار
</div>
<div class="col-lg-6 amount">
<input class="form-control form-control-sm"  formControlName="investamount"  (input)="amount($event.target.value)"   type="text" placeholder="أدخل مبلغ الاستثمار" 
[ngClass]="{ 'is-invalid': submittedinvest && o.investamount.errors }">
<div *ngIf="submittedinvest && o.investamount.errors" class="invalid-feedback marginrequired">
<div *ngIf="o.investamount.errors.required"   style="margin-left: 55%;"> مبلغ الاستثمار
مطلوب</div>
  </div>
</div>
</div>
<div class="error"  *ngIf="display"> {{errdis}}</div>
<div *ngIf="displaysuc" class="errorsuc">{{errdissuc}}</div>
<div class="row" style="margin-top: 11%;">
<div class="col-lg-3">

</div>
<div class="col-lg-6 text-center">
<button type="button" class="btn btn-success"  (click)="investammount()"   style=" font-family: Cairo;">استثمار&nbsp;&nbsp;<b style="font-size: 18px;">{{btnammount}}</b>&nbsp;<span  *ngIf="sar">ريال</span></button>
</div>
<div class="col-lg-3">

</div>
</div>
</div>
</div>

</form>

  `,
  styleUrls: ['./opportunitieslist.component.scss']




})
export class DeleteComponent implements OnInit {

  id;
  user: any;
  accessToken: any;
  investform:FormGroup;
  listError: boolean;
  sucessMessage: string;
  errorMessage: string;
  makercheckerlist: any;
  submittedinvest = false;
  ipAddress: any;
  geolocationPosition:object;
  sar = false;
  data: any;
  latitude: any;
  longitude: any;
  btnammount: any;
  loanid: UsersData;
  errdis: string;
  display: boolean;
  displaysuc: boolean;
  errdissuc: string;
  acesstoken: any;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  constructor(private fb:FormBuilder,private http:HttpClient,private auth:AuthService,
    private refresh:RefreshtokenService,private router:Router,
    private spinnerfull: NgxSpinnerService,
    public dialogRef: MatDialogRef<DeleteComponent>, private dialog:MatDialog,
    @Optional() @Inject(MAT_DIALOG_DATA)  public dat: UsersData
  ) {


this.loanid = dat
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    // console.log(this.data)
  if(this.data!=null || this.data !=''){
    this.accessToken= this.data.accesstoken;
  }

    

  }


  amount(val) {
    this.btnammount = val
if(val.length >0){
   

    this.sar = true;
}
else {
  this.sar = false;
}
  }


  get o(){return this.investform.controls}
  close() {
    this.dialogRef.close();
  }

  ngOnInit() {
    

    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
   
   
    });



    this.geolocationPosition = {};
    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
        position => {
          this.geolocationPosition = position;
    //  this.  investammount();
          this.showPosition(position);
        }
      );
    }

    
   this.investform = this.fb.group({
    investamount:['',Validators.required]
   })

  }

showPosition(position) {
  if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
    this.latitude = position.coords.latitude;
    this.longitude = position.coords.longitude;
   
  }
}




  onNoClick() {
    this.dialogRef.close();
  }


  investammount() {
    this.submittedinvest = true;

    
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.acesstoken= this.data.accesstoken;
    }


    if(this.investform.valid){

const obj:any = {}


obj['amount'] =this.investform.value.investamount;
obj['iPAddress'] = this.ipAddress;
obj['longitude'] = this.longitude;
obj['latitude'] = this.latitude;
obj['loanId'] = this.loanid

// console.log(obj)
this.spinnerfull.show()
this.auth.investamount(this.data.accesstoken,obj).subscribe(res =>{
  // console.log(res)
this.spinnerfull.hide()

  if(res.Token_Status == '1119') {
    if(res.profile_status == '1197') {
      if(res.investment_response == '1001') {

        this.display = true;
        this.errdis ='حالة الملف الشخصي معلقة'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
      }
    }
    if(res.profile_status == '1196') {

      if(res.balance_status == '1199') {
      if(res.investment_response == '1001') {

        this.display = true;
        this.errdis ='هنالك خطاً'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
        } 
      }
    }else if(res.investment_response == '1261'){
      this.display = true;
      this.errdis ='استثمر المستخدم بالفعل مبلغ لهذا القرض'
      setTimeout(() => {
        this.display = false
        this.dialogRef.close()
      }, 3000);
    }

   
    if(res.profile_status == '1196') {

      if(res.balance_status == '1199') {
      if(res.investment_response == '1000') {

const obj :any = {}

obj['FirstName'] = this.data.FirstName;
obj['LastName'] = this.data.LastName;
obj['LastLogin'] = this.data.LastLogin;
obj['accesstoken'] = this.data.accesstoken;
obj['id'] = this.data.id;
obj['isBankInfoProvided'] = this.data.isBankInfoProvided;
obj['isEmailVerified'] = this.data.isEmailVerified;
obj['isInvestorInfoProvided'] = this.data.isInvestorInfoProvided;
obj['isMobileVerified'] = this.data.isMobileVerified;
obj['isPolicyAccepted'] = this.data.isPolicyAccepted;
obj['isTermsAccepted'] = this.data.isTermsAccepted;
obj['profileStatus'] = this.data.profileStatus;
obj['redirect'] = this.data.redirect;
obj['balanceAmount'] = this.investform.value.investamount
obj['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;

sessionStorage.setItem('currentUser',JSON.stringify(obj))


        this.displaysuc = true;
        this.errdissuc =' المبلغ المستثمر بنجاح'
        setTimeout(() => {
          this.displaysuc = false
          this.dialogRef.close()
        }, 3000);
        }  
      }
    }

    if(res.profile_status == '1196') {

      if(res.balance_status == '1198') {
      if(res.investment_response == '1001') {

        this.display = true;
        this.errdis ='بالفشل'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
        }
      }
    }



    if(res.investment_response == '1203') {
  
  
  
      this.display = true;
      this.errdis ='يجب أن يكون الرصيد أقل من 10،000 ريال سعودي'
      setTimeout(() => {
        this.display = false
        this.dialogRef.close()
      }, 3000);
    }

    

    if(res.investment_response == '1211') {



      this.display = true;
      this.errdis ='مبلغ الاستثمار أقل من أو يساوي 10٪ من مبلغ القرض حتى 10،000 ريال سعودي'
      setTimeout(() => {
        this.display = false
        this.dialogRef.close()
      }, 3000);
    }



  }



  else if(res.Token_Status == '1120') {


    this.display = true
     //  this.errdis ='غير مصرح به '
       setTimeout(() => {
         this.display = false
         
         this.dialogRef.close()
         this.refresh.unAuthorizeArabic(this.tokenmessage)
         this.router.navigate(['/arhome'])
         sessionStorage.clear()
       }, 3000);
     }
     else if(res.Token_Status == '1121') {
  
  
      this.display = true
        // this.errdis ='انتهت صلاحية التزكر'
         setTimeout(() => {
           this.display = false
           this.dialogRef.close()
           this.refresh.unAuthorizeArabic(this.tokenmessage)
           this.router.navigate(['/arhome'])
           sessionStorage.clear()
         }, 3000);
       }
  
  
       else  {
  
  
        this.display = true
           this.errdis ='حدث خطا ما'
           setTimeout(() => {
             this.display = false
             this.dialogRef.close()
           }, 3000);
         }
  
})
     
    }
  }

 
}
export interface UsersData {
 
  id: number;
}