import { Component } from '@angular/core';

@Component({
  selector: 'app-arabic',
  template: `<router-outlet></router-outlet>`,
})

export class ArabicComponent {
}
