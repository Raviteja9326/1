import { Component, OnInit, Optional } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AralertComponent } from '../aralert/aralert.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';
import { deviceinfo } from 'src/app/shared/models/deviceinfo.model';
import { Inject } from '@angular/core';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { Router } from '@angular/router';
import { TermsandconditionsComponent } from 'src/app/shared/termsandconditions/termsandconditions.component';
import { ArtermsandconditionsComponent } from 'src/app/shared/artermsandconditions/artermsandconditions.component';
declare var Fingerprint2: any;


@Component({ 
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html', 
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {


  displayedColumns: string[] = ['position', 'weight', 'symbol','risk','status'];

  displayedColumns1: string[] = [ 'name', 'weight', 'symbol','status','product','risk'];

  deviceInfo: any;
  token:any;
  recentOportunitiesList: any;
  recentOportunitiesStatus: any;
  recentOptList: any;
  loanStatusInFundingcount: any;
  loanStatusInFundingcountsum: any;
  completedLoanCount: any;
  completedLoanSum: any;
  Fundedcount: any;
  FundedSum: any;
  defaultedCount: any;
  defaultedSum: any;
  investementsEarnings: any;
  investementAmountInvested: any;
  investementsAmountReceived: any;
  investementsExpertedEarnings: any;
  investAmountAnnualROI: any;
  earnings: any;
  amountInvested: any;
  amount_Received: any;
  expectedEarnings: any;
  errorMessage: string;
  dashBordError: boolean;
  dashBordrecentClosedError: boolean;
  errorRecentClosedOportMessage: string;
  errorRecentOpertMessage: string;
  dashBordrecentOportError: boolean;
  data: any;
  errmsg: string;
  msgdis: boolean;
  errmsg1: string;
  msgdis1: boolean;
  ismobilealert: boolean;
  list: any;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  isemailverified: boolean;
  latepayment: any;
  latepaymentsum: any;
  payablecount: any;
  payablecountsum: any;
  financefullcount: any;
  financefullcountsum: any;
  isprofilealert: boolean;
  accesstoken: any;
  isdocumentupload = false;
  mgdis: boolean;
  dataSourcedoc: any;
  deviceinfo: deviceinfo;
  getDeviceId: string;
  displayedColumnsdoc: string[];
  errmsgdoc: string;
  sessiondata: any;
  constructor(private fb: FormBuilder,public dialog: MatDialog,private spinnerfull: NgxSpinnerService,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private deviceService: DeviceDetectorService,private refresh:RefreshtokenService,
    private router:Router) {
     

    
   
      this.detectDevice();
      this.deviceinfo = new deviceinfo();
      new Fingerprint2().get((components) => {
        // console.log((this));
        this.getDeviceId = components;
        
        
         this.deviceinfo.deviceId = this.getDeviceId;
         console.log(this.getDeviceId)
      }),
    
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      this.accesstoken = this.data.accesstoken;
   if(this.data!=null || this.data !=''){
     this.token= this.data.accesstoken;
     if(this.data.isMobileVerified =='No') {
      this.ismobilealert = true;
    }
    if(this.data.isMobileVerified =='Yes') {
      this.ismobilealert = false;
    }

    if(this.data.isEmailVerified == 'No'){
      this.isemailverified = true;
    }

   else if(this.data.isEmailVerified == 'Yes'){
      this.isemailverified = false;
    }

if(this.data.isBankInfoProvided == 'No' && this.data.isInvestorInfoProvided == 'No') {
  this.isprofilealert = true;
}
if(this.data.isBankInfoProvided == 'No') {
  this.isprofilealert = true;
}
if( this.data.isInvestorInfoProvided == 'No') {
  this.isprofilealert = true;
}


if(this.data.isPolicyAccepted == 'No' && this.data.isTermsAccepted == 'No') {

  // this.isdocumentupload = true;

  if(this.dialog.openDialogs.length == 0){
  this.dialog.open(ArtermsandconditionsComponent,{ disableClose: true,
    width: '450px',
   
  
   
  })
}
} 
// else {
//   this.isdocumentupload = false;
// }


if(this.data.isPolicyAccepted == 'No') {

  if(this.dialog.openDialogs.length == 0){
  this.dialog.open(ArtermsandconditionsComponent,{ disableClose: true,
    width: '450px',
   
  
  
  })
}
}

if( this.data.isTermsAccepted == 'No') {

  if(this.dialog.openDialogs.length == 0){
  this.dialog.open(ArtermsandconditionsComponent,{ disableClose: true,
    width: '450px',
   
  
  
  })
}


}




// if(this.data.isBankInfoProvided == 'Yes' && this.data.isInvestorInfoProvided == 'Yes') {
//   this.isprofilealert = false;
// }

if(this.data.isBankAccountLetterUploaded == 'No') {
  this.isdocumentupload = true;
}

else {
  this.isdocumentupload = false;
} 



   }
      this.dashboardDetails();
      this.recenetClosedOpportunities();
    this.recentOportunitites();



    this.refresh.document.subscribe(res =>{
      console.log(res)

      if(res == 'Yes') {
        console.log('docyessss')
        this.isdocumentupload = false;
        this.getdocuments()
      }
    })



     }

  ngOnInit(): void {

    this.deviceinfo = new deviceinfo();
    new Fingerprint2().get((components) => {
      // console.log((this));
      this.getDeviceId = components;
      
      
       this.deviceinfo.deviceId = this.getDeviceId;
    }),

    this. displayedColumnsdoc = ['SNo', 'FileType', 'FileName', 'Action']


    this.getdocuments()
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log(this.deviceInfo)
  }




  completeprofile() {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))
  
    if(this.sessiondata.isBankAccountLetterUploaded == 'No') {
      const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
        width: '650px',
        height:'auto',
    
    
    
      });
    
    
      dialogRef.afterClosed().subscribe(result =>{
    
        console.log(result)
        if(result == '1000') {
          this.getdocuments();
          this.isdocumentupload = false;
        }
      })
  
  
    }
  
    else {
      this.router.navigate(['/arabicwebapp/profile'])
    }
  
  }

dashboardDetails(){
  this.detectDevice();
  const object: any = {}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
       object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
    //  console.log(object)
this.authService.dashBoardDetails(object,this.token).subscribe(response=>
 this.dashboardDetSubmit(response))

}
dashboardDetSubmit(response){
  // console.log(response)
  if(response.Token_Status=='1119'){
if(response.investor_dashboard_status=='1000'){

  this.earnings=response.earnings;
this.amountInvested=response.amount_invested;


this.amount_Received=response.amount_received;
this.expectedEarnings=response.expected_earnings;
this.investementsEarnings=response.investments.earnings
this.investementAmountInvested=response.investments.amount_invested
this.investementsAmountReceived=response.investments.amount_received
this.investementsExpertedEarnings=response.investments.expected_earnings
this.investAmountAnnualROI=response.investments.amount_annual_roi


this.loanStatusInFundingcount=response.loan_status.In_Funding.count  
this.loanStatusInFundingcountsum=response.loan_status.In_Funding.sum

this.latepayment=response.loan_status.Late_Payment.count

this.latepaymentsum=response.loan_status.Late_Payment.sum

this.Fundedcount=response.loan_status.Acceptable.count
this.FundedSum=response.loan_status.Acceptable.sum

this.defaultedCount=response.loan_status.Stumbled_Financing.count
this.defaultedSum=response.loan_status.Stumbled_Financing.sum

this.payablecount=response.loan_status.Payable.count
this.payablecountsum=response.loan_status.Payable.sum




this.financefullcount=response.loan_status.Finances_paid_full.count
this.financefullcountsum=response.loan_status.Finances_paid_full.sum

}else if(response.investor_dashboard_status=='1002'){
  this.dashBordError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1003'){
  this.dashBordError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1004'){
  this.dashBordError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1005'){
  this.dashBordError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1006'){
  this.dashBordError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1007'){
  this.dashBordError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1008'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1009'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1010'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1011'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1012'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1015'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1016'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}
  }else if(response.Token_Status=='1120'){
    this.dashBordError = true;
  // this.errorMessage = ' غير مصرح به ';
    setTimeout(() => {
      this.dashBordError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.dashBordError = true;
 //   this.errorMessage = ' انتهت صلاحية التزكر';
    setTimeout(() => {
      this.dashBordError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }
}

recentOportunitites(){
  const object: any = {}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
      // object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
       object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
       object['page_number'] = '0';
       object['page_size'] = '120'

       this.authService.recentOportunitiesSubmit(object,this.token).subscribe(response=>
        this.recentOportunititesSubmit(response))
}
recentOportunititesSubmit(response){
  // console.log(response)
if(response.Token_Status=='1119'){

  if(response.recent_opportunities_status=='1126'){
    this.recentOptList=response.recent_opportunities_list;

  }else if(response.recent_opportunities_status=='1127'){
    this.dashBordrecentOportError = true;
    this.errorRecentOpertMessage = 'لا تتوافر بيانات';
    setTimeout(() => {
      this.dashBordrecentOportError = false;
    }, 300000);
  }else if(response.recent_opportunities_status=='1002'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1003'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1004'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1005'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1006'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1007'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1008'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1009'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1010'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1011'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1012'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1015'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1016'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1150'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1151'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1152'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1153'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }
}else if(response.Token_Status=='1120'){
  this.dashBordrecentOportError = true;
 // this.errorRecentOpertMessage = ' غير مصرح به ';
  setTimeout(() => {
    this.dashBordrecentOportError = false;
    this.refresh.unAuthorizeArabic(this.tokenmessage)
    this.router.navigate(['/arhome'])
    sessionStorage.clear()
  }, 3000);
}else if(response.Token_Status=='1121'){
  this.dashBordrecentOportError = true;
 // this.errorRecentOpertMessage = ' انتهت صلاحية التزكر';
  setTimeout(() => {
    this.dashBordrecentOportError = false;
    this.refresh.unAuthorizeArabic(this.tokenmessage)
    this.router.navigate(['/arhome'])
    sessionStorage.clear()
  }, 3000);
}








}
recenetClosedOpportunities(){
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
  object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
//   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   object['page_number'] = '0'; 
   object['page_size'] = '120'
   this.authService.recentClosedOportunites(object,this.token).subscribe(response=>
    this.recenetClosedOpportunitiesSubmit(response))
}
recenetClosedOpportunitiesSubmit(response){
  // console.log(response)
  if(response.Token_Status=='1119'){
if(response.recent_closed_opportunities_status=='1126'){
this.recentOportunitiesList=response.recent_closed_opportunities_list
}else if(response.recent_closed_opportunities_status=='1127'){
  this.dashBordrecentClosedError = true;
  this.errorRecentClosedOportMessage = 'لايوجد انترنت - البيانات غير متاحة';
  setTimeout(() => {
    this.dashBordrecentClosedError = false;
  }, 30000);
}else if(response.recent_closed_opportunities_status=='1002'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1003'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1004'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1005'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1006'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1007'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1008'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1009'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1010'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1011'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1012'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1015'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1016'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1150'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1151'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1152'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1153'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}
  }else if(response.Token_Status=='1120'){
    this.dashBordrecentClosedError = true;
   // this.errorRecentClosedOportMessage = ' غير مصرح به ';
    setTimeout(() => {
      this.dashBordrecentClosedError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.dashBordrecentClosedError = true;
   // this.errorRecentClosedOportMessage = ' انتهت صلاحية التزكر';
    setTimeout(() => {
      this.dashBordrecentClosedError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }
}



getdocuments(){


  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  this.accesstoken = this.data.accesstoken;


  const object:any = {}
  object['deviceId'] = 'e390e843469573f2f18157951ba89e6e'
  object['language'] = 'ar'

  this.authService.getinvestersdashdoc(object,this.accesstoken).subscribe(response =>{
console.log(response)

    if(response.Token_Status == '1119') {
      if(response.documents_status == '1126') {
      this.mgdis = true;
        // this.dashboarddetails = response.documents;
        // this.dataSource = this.dashboarddetails;

        this.dataSourcedoc = response.documents
      }
      if(response.documents_status == '1011') {
        this.errmsgdoc = 'حدث خطا ما'
     
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
      }
      if(response.documents_status == '1012') {
        this.mgdis = true;
        this.errmsgdoc = 'حدث خطا ما'
     
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
      }
      if(response.documents_status == '1127') {
        this.mgdis = true;
        this.errmsgdoc = 'لايوجد انترنت - البيانات غير متاحة ';
        this.dataSourcedoc = [];
    
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
      }
    }


  })
}


opendocument() {

  

  const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
    width: '650px',
    height:'auto',

 

  });


  dialogRef.afterClosed().subscribe(result =>{

    console.log(result)
    if(result == '1000') {
      this.getdocuments();
      this.isdocumentupload = false;
    }
  })
}

clearalert(val) {


  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(val == 'email')
 {
  this.isemailverified = false;


       const object:any ={}

       object['FirstName']  = this.data.FirstName;
       object['LastName']     = this.data.LastName;
       object['LastLogin']    = this.data.LastLogin;
       object['isMobileVerified']   = this.data.isMobileVerified;
       object['isEmailVerified']   = "Yes";
       object['redirect'] = "arabicwebapp";
       object['accesstoken']   = this.data.accesstoken;
       object['ProfilePic'] =  this.data.ProfilePic;
       object['id']=this.data.id
       object['profileStatus']=this.data.profileStatus
       object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;
      
  
      object['isBankInfoProvided']   = this.data.isBankInfoProvided;
       object['isPolicyAccepted']= this.data.isPolicyAccepted;
      object['isTermsAccepted'] = this.data.isTermsAccepted;
     
     
      sessionStorage.setItem('currentUser',JSON.stringify(object));

 }


 if(val == 'Mobile') {

  this.ismobilealert = false;
  const object:any ={}

  object['FirstName']  = this.data.FirstName;
  object['LastName']     = this.data.LastName;
  object['LastLogin']    = this.data.LastLogin;
  object['redirect'] = "arabicwebapp";
  object['isEmailVerified']   = this.data.isEmailVerified;
  object['accesstoken']   = this.data.accesstoken;
  object['ProfilePic'] =  this.data.ProfilePic;
  object['id']=this.data.id
 

 object['isMobileVerified']  = "Yes"
  object['isPolicyAccepted']= this.data.isPolicyAccepted;
 object['isTermsAccepted'] = this.data.isTermsAccepted;
 object['profileStatus']  = this.data.profileStatus;
 object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;

 object['isBankInfoProvided']   = this.data.isBankInfoProvided;
 sessionStorage.setItem('currentUser',JSON.stringify(object));
 }


 if(val == 'profile'){
   this.isprofilealert = false;

   const object:any ={}

   object['FirstName']  = this.data.FirstName;
   object['LastName']     = this.data.LastName;
   object['LastLogin']    = this.data.LastLogin;
   object['redirect'] = "arabicwebapp";
   object['isEmailVerified']   = this.data.isEmailVerified;
   object['accesstoken']   = this.data.accesstoken;
   object['ProfilePic'] =  this.data.ProfilePic;
   object['id']=this.data.id
  
 
  object['isMobileVerified']  = this.data.isMobileVerified;
   object['isPolicyAccepted']= this.data.isPolicyAccepted;
  object['isTermsAccepted'] = this.data.isTermsAccepted;
  object['profileStatus']  = this.data.profileStatus;
  object['isInvestorInfoProvided']= "Yes";
 
  object['isBankInfoProvided']   = "Yes";

  sessionStorage.setItem('currentUser',JSON.stringify(object));
 }





}
 

alertmsg(val){
  // console.log(val);

  this.data = JSON.parse(sessionStorage.getItem('currentUser'));

  
  if(val == 'Mobile') {

    const obj:any ={}


// console.log()
 
obj['ipAddress'] =this.deviceinfoservice.deviceinfo.ipAdress;
obj['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
obj['countryCode'] = 'SA';
obj['deviceType'] = 'Web';
obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
obj['language']= 'en';

// console.log(obj)

this.spinnerfull.show() 

this.authService.alertinvesmobile(obj,this.data.accesstoken).subscribe(res=>{
  // console.log(res)
  this.spinnerfull.hide()
  if(res.Token_Status =='1119'){
    if(res.Verify_Mobile_Otp_Response =='1000'){
      const dialogRef = this.dialog.open(AralertComponent,   {disableClose: true,
        width: '658px',
          height: 'auto',
        data:val
      
      });

      dialogRef.afterClosed().subscribe(result =>{
        // console.log('closed')
        this.list = result;
     if(this.list == '1000'){
       this.ismobilealert = false;


       const object:any ={}

       object['FirstName']  = this.data.FirstName;
       object['LastName']     = this.data.LastName;
       object['LastLogin']    = this.data.LastLogin;
       object['redirect'] = "arabicwebapp";
       object['isEmailVerified']   = this.data.isEmailVerified;
       object['accesstoken']   = this.data.accesstoken;
       object['ProfilePic'] =  this.data.ProfilePic;
       object['id']=this.data.id
      
     
      object['isMobileVerified']  = "Yes"
       object['isPolicyAccepted']= this.data.isPolicyAccepted;
      object['isTermsAccepted'] = this.data.isTermsAccepted;
      object['profileStatus']  = this.data.profileStatus;
      object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;
      object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;
      object['isBankInfoProvided']   = this.data.isBankInfoProvided;
      sessionStorage.setItem('currentUser',JSON.stringify(object));
     }

      })
    
    }
  
   else if(res.Verify_Mobile_Otp_Response =='1011'){
     this.errmsg = 'حدث خطا ما';
     this.msgdis = true;
     setTimeout(() => {
      this.msgdis = false;
     }, 3000);
   }
   else if(res.Verify_Mobile_Otp_Response =='1012'){
    this.errmsg = 'حدث خطا ما';
    this.msgdis = true;
    setTimeout(() => {
     this.msgdis = false;
    }, 3000);
   }
    else if(res.Verify_Mobile_Otp_Response =='1015'){
      this.errmsg = 'حدث خطا ما';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
    else if(res.Verify_Mobile_Otp_Response =='1016'){
      this.errmsg = 'حدث خطا ما';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
    else if(res.Verify_Mobile_Otp_Response =='1224'){
      this.errmsg = 'تم تجاوز حد OTP';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
    else if(res.Verify_Mobile_Otp_Response =='1001'){
      this.errmsg = 'فشل';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }


  }

 
  if(res.Token_Status =='1120'){
   // this.errmsg = ' غير مصرح به ';
    this.msgdis = true;
    setTimeout(() => {
     this.msgdis = false;
     this.refresh.unAuthorizeArabic(this.tokenmessage)
     this.router.navigate(['/arhome'])
     sessionStorage.clear()
    }, 3000);
  }
  if(res.Token_Status =='1121'){
   // this.errmsg = ' انتهت صلاحية التزكر';
    this.msgdis = true;
    setTimeout(() => {
     this.msgdis = false;
     this.refresh.unAuthorizeArabic(this.tokenmessage)
     this.router.navigate(['/arhome'])
     sessionStorage.clear()
    }, 3000);
  }


})
 
 
  
}


if(val == 'email') {

  const obj:any ={}


  // console.log('email')

obj['ipAddress'] =this.deviceinfoservice.deviceinfo.ipAdress;
obj['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
obj['countryCode'] = 'SA';
obj['deviceType'] = 'Web';
obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
obj['language']= 'en';

// console.log(obj)

this.spinnerfull.show()

this.authService.alertemail(obj,this.data.accesstoken).subscribe(res=>{
// console.log(res)
this.spinnerfull.hide()
if(res.Token_Status =='1119'){
  if(res.Verify_Email_Otp_Response =='1000'){
    const dialogRef = this.dialog.open(AralertComponent,  {disableClose: true,
      width: '658px',
        height: 'auto',
      data:val
    
    });


     dialogRef.afterClosed().subscribe(result =>{
        // console.log('closed')
        this.list = result;
     if(this.list == '1000'){
       this.isemailverified = false;


       const object:any ={}

       object['FirstName']  = this.data.FirstName;
       object['LastName']     = this.data.LastName;
       object['LastLogin']    = this.data.LastLogin;
       object['isMobileVerified']   = this.data.isMobileVerified;
       object['isEmailVerified']   = "Yes";
       object['redirect'] = "arabicwebapp";
       object['accesstoken']   = this.data.accesstoken;
       object['ProfilePic'] =  this.data.ProfilePic;
       object['id']=this.data.id
       object['profileStatus']=this.data.profileStatus
       object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;
       object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;
  
      object['isBankInfoProvided']   = this.data.isBankInfoProvided;
       object['isPolicyAccepted']= this.data.isPolicyAccepted;
      object['isTermsAccepted'] = this.data.isTermsAccepted;
     
     
      sessionStorage.setItem('currentUser',JSON.stringify(object));
     }

      })
   
  }

  else if(res.Verify_Email_Otp_Response =='1011'){
    this.errmsg1 = 'حدث خطا ما';
    this.msgdis1 = true;
    setTimeout(() => {
     this.msgdis1 = false;
    }, 3000);
  }
  else if(res.Verify_Email_Otp_Response =='1012'){
   this.errmsg1 = 'حدث خطا ما';
   this.msgdis1 = true;
   setTimeout(() => {
    this.msgdis1 = false;
   }, 3000);
  }
   else if(res.Verify_Email_Otp_Response =='1015'){
     this.errmsg1 = 'حدث خطا ما';
     this.msgdis1 = true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
   }
   else if(res.Verify_Email_Otp_Response =='1016'){
     this.errmsg1 = 'حدث خطا ما';
     this.msgdis1 = true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
   }
   else if(res.Verify_Email_Otp_Response =='1001'){
     this.errmsg1 = 'فشل';
     this.msgdis1= true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
   }

}


if(res.Token_Status =='1120'){
//  this.errmsg1 = ' غير مصرح به ';
  this.msgdis1 = true;
  setTimeout(() => {
   this.msgdis1 = false;
   this.refresh.unAuthorizeArabic(this.tokenmessage)
   this.router.navigate(['/arhome'])
   sessionStorage.clear()
  }, 3000);
}
if(res.Token_Status =='1121'){
 // this.errmsg1 = ' انتهت صلاحية التزكر';
  this.msgdis1 = true;
  setTimeout(() => {
   this.msgdis1 = false;
   this.refresh.unAuthorizeArabic(this.tokenmessage)
   this.router.navigate(['/arhome'])
   sessionStorage.clear()
  }, 3000);
}


})



}
  }
 

}





///////   documnet


@Component({
  
  selector: 'app-document',
  template: `


  <i class="fa fa-times text-left" aria-hidden="true"      style=" cursor:pointer;"  (click)="onNoClick()"></i>
<div class="container-fluid">
<p   class="text-right mt-0"  style="color:green; font-weight:600;font-size:18px font-family:Cairo"
>  الوثائق</p>

<p  class="mt-2"  style="font-family:Cairo"> يجب أن يكون حجم المستند المراد تحويله أقل من 5 ميجابايت وأن تكون التنسيقات الصالحة المقبولة للمستند .pdf أو .xls أو .xlsx.</p>
<form [formGroup]="uploadfileForm" autocomplete="off">
<div class="row">




<div class="col-lg-6 ">


<label for="exampleFormControlFile1"></label>
<input type="file" class="form-control-file" id="exampleFormControlFile1"  accept="application/pdf, application/vnd.ms-excel" name="fileName"
(change)="onFileChange($event)"   [ngClass]="{ 'is-invalid': submitted5 && o.fileName.errors }">


<div *ngIf="submitted5 && o.fileName.errors" class="invalid-feedback">
<div *ngIf="o.fileName.errors.required">  المستند مطلوب
  

</div>
</div>
</div>
<div class="col-lg-6 mt-4">
<div  style="color:blue; font-family:Cairo; text-align:right;">
خطاب حساب بنكي
</div>
</div>


</div>
</form>

<div class="row">
<div class="col-lg-12">
<div  *ngIf="mobileEmaiError" style="color:red;text-align: center;" >{{mobileEmailFileError}}</div>
<div  *ngIf="docdisplaysuc" style="color:green;text-align: center;" >{{docerrsuc}}</div>
<div  *ngIf="docdisplay" style="color:red;text-align: center;" >{{docerr}}</div>
</div>
</div>
<div class="row">

<div class="col-lg-12  text-center mt-3">
<button type="button" class="btn btn-success" (click)="uploaddocument()">رفع </button>

</div>
</div>

</div> 

 


  `,

  styleUrls: ['./dashboard.component.scss']

  

  


 
})
export class DocumentComponent implements OnInit {

  id;
  user: any;
  accessToken: any;
  investform:FormGroup;
  listError: boolean;
  sucessMessage: string;
  errorMessage: string;
  makercheckerlist: any;
  submittedinvest = false;
  ipAddress: any; 
  geolocationPosition:object;
  data: any;
  latitude: any;
  longitude: any;
  btnammount: any;
  display: boolean;
  errdis: string;
  mobileEmailFileError: string;
  mobileEmaiError: boolean;
  
  uploadfileForm:FormGroup;
  docname: any;
  docdisplaysuc: boolean;
  docerr: string;
  docdisplay: boolean;
  docerrsuc: string;
  submitted5: boolean;
  docnameeng: any;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  constructor(private fb:FormBuilder,private auth:AuthService, private dialog:MatDialog,private router:Router,
    private refresh:RefreshtokenService,
    public dialogRef: MatDialogRef<DocumentComponent>,  private spinnerfull: NgxSpinnerService,
    @Optional() @Inject(MAT_DIALOG_DATA) public dataval: UsersData
   
  ) {

// this.docname = dataval.FileType;
// this.docnameeng = dataval.FileType1;
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accessToken= this.data.accesstoken;
  }

    

  }



  ngOnInit() {
    
    this.uploadfileForm = this.fb.group({ 
      fileName: ['',Validators.required],
     
    })
  
}

  onFileChange(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.mobileEmaiError = false;
       this.uploadfileForm.get('fileName').setValue(file);
    }
  }else{
    this.mobileEmailFileError="يجب أن يكون حجم المستند أقل من 5 ميغا بايت";
    this.mobileEmaiError = true;
    // setTimeout(() => {
    //   this.mobileEmaiError = false;
    // }, 3000)
  }
  }


  uploaddocument() {
    this.submitted5 = true;
    if(this.uploadfileForm.valid) {
      this.submitted5 = false;
     
      const formData = new FormData();
     
        console.log('navya')
      formData.append('file',this.uploadfileForm.get('fileName').value);

      formData.append('fileName',this.uploadfileForm.value.fileName);





    

  

    
     // console.log( formData.has('typeOfFileName'))

   this.spinnerfull.show()

this.auth.uploadinvesterdashboarddocuments(formData,this.accessToken).subscribe(res =>{
  console.log(res)

  this.spinnerfull.hide()
  if(res.token_staus == '1119') {
    if(res.upload_documents_response =='1000') {
      this.docdisplaysuc = true;
      this.docerrsuc = 'تم تحميل المستند بنجاح ، سيكون المستند الذي تم تحميله متاحًا في دقيقتين';
      this.refresh.getdocsuccess('Yes');

      const object:any ={}

      object['FirstName']  = this.data.FirstName;
      object['LastName']     = this.data.LastName;
      object['LastLogin']    = this.data.LastLogin;
      object['redirect'] = "arabicwebapp";
      object['isEmailVerified']   = this.data.isEmailVerified;
      object['accesstoken']   = this.data.accesstoken;
      object['ProfilePic'] =  this.data.ProfilePic;
      object['id']=this.data.id
     
    
     object['isMobileVerified']  = this.data.isMobileVerified;
      object['isPolicyAccepted']= this.data.isPolicyAccepted;
     object['isTermsAccepted'] = this.data.isTermsAccepted;
     object['profileStatus']  = this.data.profileStatus;
     object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;
     object['isBankAccountLetterUploaded'] = 'Yes';
     object['isBankInfoProvided']   = this.data.isBankInfoProvided;
     sessionStorage.setItem('currentUser',JSON.stringify(object));
      setTimeout(() => {
        this.docdisplaysuc = false;
        this.dialogRef.close(res.upload_documents_response );


        
      }, 3000);
    }


   else if(res.upload_documents_response =='1001') {
      this.docdisplaysuc = true;
      this.docerr = 'فشل';
      setTimeout(() => {
        this.docdisplay = false;
      }, 3000);
    }

   else if(res.upload_documents_response =='1126') {
      this.docdisplaysuc = true;
      this.docerr = 'القائمة متاحة';
      setTimeout(() => {
        this.docdisplay = false;
      }, 3000);
    }

   else if(res.upload_documents_response =='1127') {
      this.docdisplaysuc = true;
      this.docerr = 'القائمة غير متوفرة';
      setTimeout(() => {
        this.docdisplay = false;
      }, 3000);
    }

    



  }

else if(res.Token_Status == '1120') {
  this.docdisplay = true;
 // this.docerr = 'غير مصرح';
  setTimeout(() => {
    this.docdisplay = false;
    
    this.refresh.unAuthorizeArabic(this.tokenmessage)
    this.router.navigate(['/arhome'])
    sessionStorage.clear()
  }, 3000);
  
}

else if(res.Token_Status == '1121') {
 
  this.docdisplay = true;
 // this.docerr = ' انتهت صلاحية التزكر';
  setTimeout(() => {
   this.docdisplay = false;
   this.refresh.unAuthorizeArabic(this.tokenmessage)
   this.router.navigate(['/arhome'])
   sessionStorage.clear()
  }, 3000);
}




})



  }


  }



  get o(){return this.uploadfileForm.controls}


  

  onNoClick() {
    this.dialogRef.close();
  }


 
}

export interface UsersData {
  SNo: any;
  FileType:any;
  FileName:any;
  Action:any;
  FileType1:any;

}