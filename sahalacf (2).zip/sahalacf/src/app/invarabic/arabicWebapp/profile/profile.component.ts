import { Component, OnInit ,ViewEncapsulation, Injectable, ElementRef, ViewChild} from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import * as moment from 'moment';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgbDatepickerI18n, NgbDateStruct, NgbCalendar, NgbCalendarIslamicUmalqura } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, personalForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = personalForm && personalForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

const WEEKDAYS = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];
const MONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال',
  'ذو القعدة', 'ذو الحجة'];

@Injectable()
export class IslamicI18n extends NgbDatepickerI18n {

  getWeekdayShortName(weekday: number) {
    return WEEKDAYS[weekday - 1];
  }

  getMonthShortName(month: number) {
    return MONTHS[month - 1];
  }

  getMonthFullName(month: number) {
    return MONTHS[month - 1];
  }

  getDayAriaLabel(date: NgbDateStruct): string {
    return `${date.day}-${date.month}-${date.year}`;
  }
}







@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  providers: [
   
    {provide: NgbCalendar, useClass: NgbCalendarIslamicUmalqura},
    {provide: NgbDatepickerI18n, useClass: IslamicI18n}
],
  encapsulation:ViewEncapsulation.Emulated
})
export class ProfileComponent implements OnInit {
  BankDetHide=true;
  basicForm:FormGroup;
  personalForm:FormGroup;
submitted = false;
submitted1 = false;
  deviceInfo: any;
  accesstoken: any;
  profileError: boolean;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  errorMessage: string;
  BankDetailsForm:FormGroup
  otpForm:FormGroup
  SucessError: boolean;
  sucessMessage: string;
  profilepage=true;
  otpShow=false;
  bankotpShow=false
  basicotpShow=false
  sucessinfo: boolean;
  SucessMessage: string;
  data: any;
  PersonalFormHide=true;
  BasicInfoHide=true
hide6 = false;
hide7 = false;
hide8 = false;
uploadfileForm:FormGroup;
mobileEmailFileError: string;
mobileEmaiError: boolean;
bankstatementFileError: string;
bankstaatmentsError: boolean;
responseMessgaeer: string;
responseMessgae: string;
registError: boolean;
submitted2: boolean;
submitted5: boolean;
msgError: boolean;
responseUploadDocMessgae: string;
registuploaddocError: boolean;

  anualincome = [

    {value: 'أقل من 50,000 ريال', viewValue: 'أقل من 50,000 ريال'},

    {value: 'من 50,000 إلى 100,000 ريال', viewValue: 'من 50,000 إلى 100,000 ريال'},

    {value: 'من 101,000 إلى 250,000 ريال', viewValue: 'من 101,000 إلى 250,000 ريال'},

    {value: 'من 251,000 إلى 500,000 ريال', viewValue: 'من 251,000 إلى 500,000 ريال'},

    {value: 'من 500,000 إلى 1,000,000', viewValue: 'من 500,000 إلى 1,000,000'},

    {value: 'أكثر من 1,000,000 ريال', viewValue: 'أكثر من 1,000,000 ريال'}
  ];
  sourceincome = [
    {value: 'موظف حكومي', viewValue: 'موظف حكومي'},
    {value: 'موظف قطاع خاص', viewValue: 'موظف قطاع خاص'},
    {value:'صاحب عمل',viewValue:'صاحب عمل'},
    {value:'متقاعد',viewValue:'متقاعد'},
    {value: 'طالب', viewValue: 'طالب'},
    {value: 'أخرى', viewValue: 'أخرى'}
  ];
  jobstatus = [
    {value: 'صاحب العمل', viewValue: 'صاحب العمل '},
    {value: 'طالب', viewValue: 'طالب'},
    {value: 'آخر', viewValue: 'اٌخر'},
  ];

  // banks = [
  //   {value: 'Alawwal Bank', viewValue: 'ALAWWAL Bank'},
  //   {value: 'ARAB NATIONAL BANK', viewValue: 'ARAB NATIONAL BANK'},
  //   {value: 'AL RAJHI BANKING AND INV.CORP.', viewValue: 'AL RAJHI BANKING AND INV.CORP.'}, 
  //   {value: 'AL BANK AL SAUDI AL FRANSI', viewValue: 'AL BANK AL SAUDI AL FRANSI'},
  //   {value: 'Alinma Bank', viewValue: 'ALINMA BANK'},
  //   {value: 'BANK AlBILAD', viewValue: 'BANK AlBILAD'},
  //   {value: 'BANK MUSCAT', viewValue: 'BANK MUSCAT'},
  //   {value: 'BANK ALJAZIRA', viewValue: 'BANK ALJAZIRA'},
  //   {value: 'DEUTSHE BANK', viewValue: 'DEUTSHE BANK'},
  //   {value: 'Emirates Bank', viewValue: 'EMIRATES BANK'}, 
  //   {value: 'GULF INTERNATIONAL BANK', viewValue: 'GULF INTERNATIONAL BANK'},
  //   {value: 'NATIONAL COMMERCIAL BANK', viewValue: 'NATIONAL COMMERCIAL BANK'},
  //   {value: 'NATIONAL BANK OF BAHRAIN', viewValue: 'NATIONAL BANK OF BAHRAIN'},
  //   {value: 'National Bank of Kuwait', viewValue: 'NATIONAL BANK OF KUWAIT'},
  //   {value: 'National Bank of Pakistan', viewValue: 'NATIONAL BANK OF PAKISTAN'},
  //   {value: 'Paryabas Bank', viewValue: 'PARYABAS BANK'},
  //   {value: ' Riyad Bank', viewValue: ' Riyad Bank'},
  //   {value: 'SAUDI INVESTMENT BANK', viewValue: 'SAUDI INVESTMENT BANK'},
  //   {value: 'SAUDI BRITISH BANK', viewValue: 'SAUDI BRITISH BANK'},
  //   {value: 'SAUDI ARABIAN MONETARY AGENCY', viewValue: 'SAUDI ARABIAN MONETARY AGENCY'},
  //   {value: 'SAUDI AMERICAN BANK', viewValue: 'SAUDI AMERICAN BANK'},
  //   {value:'SAUDI HOLLANDI BANK', viewValue:'SAUDI HOLLANDI BANK'},
  //   {value: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI', viewValue: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI'},
    
  // ];
  banks = [
    {value: 'البنك الأول', viewValue: 'البنك الأول'},
    {value: 'البنك العربي الوطني', viewValue: 'البنك العربي الوطني'},
    {value: 'مصرف الراجحي', viewValue: 'مصرف الراجحي'}, 
    {value: 'البنك السعودي الفرنسي', viewValue: 'البنك السعودي الفرنسي'},
    {value: 'مصرف الإنماء', viewValue: 'مصرف الإنماء'},

    {value: 'بنك البلاد', viewValue: 'بنك البلاد'},
    {value: 'بنك مسقط', viewValue: ' بنك مسقط'},
    {value: 'بنك الجزيرة ', viewValue: 'بنك الجزيرة'},
    {value: ' دويتشه بنك', viewValue: ' دويتشه بنك'},
    {value: 'بنك الإمارات', viewValue: 'بنك الإمارات'},
    {value: 'بنك الخليج الدولي', viewValue: 'بنك الخليج الدولي'},
    {value: 'البنك الأهلي التجاري', viewValue: 'البنك الأهلي التجاري'},

    {value: 'بنك البحرين الوطني', viewValue: 'بنك البحرين الوطني'},

    {value: 'بنك الكويت الوطني', viewValue: 'بنك الكويت الوطني'},

    {value: 'البنك الوطني الباكستاني', viewValue: 'البنك الوطني الباكستاني'},

     {value: 'بنك الرياض', viewValue: 'بنك الرياض'},
    {value: 'البنك السعودي للإستثمار', viewValue: 'البنك السعودي للإستثمار'},
    {value: '(البنك السعودي الأمريكي (سامبا', viewValue: 'البنك السعودي الأمريكي (سامبا)'},
    {value: 'مؤسسة النقد العربي السعودي', viewValue: 'مؤسسة النقد العربي السعودي'},
    // {value: 'SAUDI AMERICAN BANK', viewValue: 'SAUDI AMERICAN BANK'},
     {value:'(البنك السعودي البريطاني(ساب', viewValue:'البنك السعودي البريطاني(ساب)'},
    // {value: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI', viewValue: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI'},
    
  ];
  idvaliddate: string; 
  bankdeterr: boolean;
  BankDetailsUpdatedSuces: string;
  updatepersonalInformation: string;
  updateprosucMessage: boolean;
  personalInfoprofileError: boolean;
  bacicprofilesucess: boolean;
  basicinfo: string;
  bacicprofileError: boolean;
  profileErrorbefotp: boolean;
  idexpire: any;
  fileinput1 = false;
  fileinput = false;
  dataaaaae: any;
  nonsaudi: boolean;
  saudi: boolean;
  datdob: string;
  todaydate: any;
  dobdatcurrent: boolean;
  doberr: string;
  doberrdis: boolean;
  doberrdiseng: boolean;
  setDate: any;
  finalengcurrentdat: any;
  currentengdob: string | number | Date;
  bobdattt: string;
  backendnationality: any;
  changeenablenational: any;
  submittedo: boolean;
  idattt: string;
  model: NgbDateStruct;
  submittedb: boolean;
  submittedp: boolean;
    elsedate: any;
  bobdatttid: any;
  personalresponse: any;
  iqamaNA: boolean;
  iqama: boolean;
  basicdetails: any;
  genvalue: boolean;
  genna: boolean;

  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private dialog:MatDialog, private router:Router,private refresh:RefreshtokenService,
    private deviceService: DeviceDetectorService, private spinnerfull: NgxSpinnerService, private calendar: NgbCalendar) { 


      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }

      this.detectDevice();
      this.GetbasicProfile();
  }

  get investeryourInfoControllers() { return this.basicForm.controls }
  get f() { return this.personalForm.controls }
  get g() { return this.BankDetailsForm.controls }
get o(){return this.otpForm.controls}
  ngOnInit(): void {


    this.selectToday();
    this.basicForm = this.fb.group({
      firstName:['',[Validators.required]],
      lastName:['',[Validators.required]],
      mobileNo:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),  Validators.pattern("^(5)[0-9]{8}$")]],
      riyadName:[''],
      email:['',]
      // email:['',[Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      // + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),Validators.required]]

    })

    this.personalForm = this.fb.group({
      annualIncome : ['',[Validators.required]],
      sourceIncome : ['',[Validators.required]],
      jobstatus : ['',[Validators.required]],
      iqama : ['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),]],
      nameen : ['',[Validators.required,Validators.pattern("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$")]],
      namear:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF\ ]*$')]],
      placeOfBirth:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      currentResidentLocation:['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]],
      nationality : ['',[Validators.required]],
      gender : ['',[Validators.required]],
      dob : ['',[Validators.required]],
      idexpiryDate : ['',[Validators.required]],
      dobnon : ['',[Validators.required]],
      idexpiryDatenon : ['',[Validators.required]]


    })
    this.BankDetailsForm= this.fb.group({ 
      bankname : ['',[Validators.required]],
      accountholder :  ['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      baniban : ['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]],

    })
    this.otpForm=this.fb.group({
      otp: ['',[Validators.required,Validators.minLength(6), Validators.maxLength(6), Validators.pattern("^[0-9]*$")]],
    })
    this.uploadfileForm = this.fb.group({
     
      monthbankstatement:[''],
      mobileEmail:[''],
      docName1:[''],
      docName2:['']
   
    })
  }

  // updatebasic() {
  //   this.submitted = true;
  //   (this.basicForm.value)
  // }

  // updateprofile() {
  //   this.submitted1 = true;
  //   this.personalForm.get('dob').markAsTouched();
  //   this.personalForm.get('idexpiryDate').markAsTouched();
  //   (this.personalForm.value)
  // }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
   
  }
  selectToday() {
    this.model = this.calendar.getToday();
    
  
    this.todaydate =  `${this.model.year}-${this.model.month}-${this.model.day}`
  
 
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  onFileChange(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.fileinput = true
      this.mobileEmaiError = false;
      this.uploadfileForm.get('mobileEmail').setValue(file);
    }
  }else{
    this.mobileEmailFileError="يجب أن يكون حجم رسالة الهاتف المحمول والبريد الإلكتروني أقل من 5 ميجابايت";
    this.mobileEmaiError = true;
    // setTimeout(() => {
    //   this.mobileEmaiError = false;
    // }, 3000)
  }
  } 
  onFileChange2(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.fileinput1 = true
      this.bankstaatmentsError = false;
      this.uploadfileForm.get('monthbankstatement').setValue(file);
    }
  }else{
    this.bankstatementFileError="يجب أن تكون كشوف الحساب أقل من 5 ميغابايت";
    this.bankstaatmentsError = true;
    // setTimeout(() => {
    //   this.bankstaatmentsError = false;
    // }, 3000)
  }
  }
  get u() {
    return this.uploadfileForm.controls;
  }

  @ViewChild('myInput')
  myInputVariable: ElementRef;
  @ViewChild('myInput1')
  myInputVariable1: ElementRef;
 
 


 uploadform() {
  // console.log(this.uploadfileForm.value.mobileEmail.size)
  this.submitted2 = true;
  this.submitted5=true;
//  console.log(this.uploadfileForm.value)
 this.detectDevice();

 this.data = JSON.parse(sessionStorage.getItem('currentUser'));
 if(this.data!=null || this.data !=''){
   this.accesstoken= this.data.accesstoken;
 }


if(this.uploadfileForm.value.mobileEmail  !='' || this.uploadfileForm.value.monthbankstatement  !='' ) {

this.responseMessgaeer = ''
    this.submitted5 = false;
    this.msgError = false;
    var formData = new FormData();
   


    var f = new File([""], "filename");

    if(this.uploadfileForm.value.mobileEmail =='' || this.uploadfileForm.value.mobileEmail == null){ 
           formData.append('document1',f);
          
        }else{
          formData.append('document1',this.uploadfileForm.value.mobileEmail);
        }



        if(this.uploadfileForm.value.monthbankstatement ==''  || this.uploadfileForm.value.monthbankstatement == null){
          console.log('secupload')
          formData.append('document2',f);
         
       }else{ 
         formData.append('document2',this.uploadfileForm.value.monthbankstatement);
       }



    // formData.append('document1',this.uploadfileForm.value.mobileEmail);
    // formData.append('document2',this.uploadfileForm.value.monthbankstatement);

    if(this.uploadfileForm.value.docName1 == '') {

      formData.append('docName1','NA');
    }
    else{
      formData.append('docName1',this.uploadfileForm.value.docName1);
    }
   

    if(this.uploadfileForm.value.docName2 == '') {

      formData.append('docName2','NA');
    }
    else {
      formData.append('docName2',this.uploadfileForm.value.docName2);
    }


    formData.append('deviceType',this.deviceinfoservice.deviceinfo.deviceType);
    formData.append('deviceId	',this.deviceinfoservice.deviceinfo.deviceId);
    formData.append('iPAddress	',this.deviceinfoservice.deviceinfo.ipAdress);
    
    console.log( formData.has('document1'))
    console.log( formData.has('document2')) 
    console.log( formData.has('document3')) 
    console.log( formData.has('iPAddress')) 
    console.log(this.deviceinfoservice.deviceinfo.deviceId)
    console.log(this.uploadfileForm.value.mobileEmail)
    console.log(this.uploadfileForm.value.monthbankstatement)
 
  

 // this.spinner = true;
     this.spinnerfull.show();
     console.log(formData)
    this.authService.uploadinvestorprofiledocuments(formData,this.accesstoken).subscribe(response =>{
     console.log(response)
      this.spinnerfull.hide();
   
      if(response.upload_documents_response == 1000){
        this.submitted5=false;
        this.responseUploadDocMessgae = "تم تحميل المستند بنجاح";

        
                  this.registuploaddocError = true;
                  setTimeout(() => {
                   
                    this.registuploaddocError = false;
                    this.myInputVariable.nativeElement.value = "";
                    this.myInputVariable1.nativeElement.value = "";
               this.fileinput = false;
               this.fileinput1 = false;

               this.uploadfileForm.reset()
               
const object:any = {}
object['FirstName']  = this.data.FirstName;
object['LastName']     = this.data.LastName;
object['LastLogin']    = this.data.LastLogin;
object['isMobileVerified']   = this.data.isMobileVerified;
object['isEmailVerified']   = this.data.isEmailVerified;
object['accesstoken']   = this.data.accesstoken; 

object['id']=this.data.id
object['profileStatus']=this.data.profileStatus
object['ProfilePic'] = this.data.Profile_Pic;
object['isPolicyAccepted']   = this.data.isPolicyAccepted;
object['isBankInfoProvided']    = this.data.isBankInfoProvided;
object['isInvestorInfoProvided']    = this.data.isInvestorInfoProvided;
object['isTermsAccepted']  = this.data.isTermsAccepted;
object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;


  sessionStorage.setItem('currentUser',JSON.stringify(object)) 
               
                  }, 3000)
      }else if(response.upload_documents_response== 1001){
        this.responseMessgae = "فشل";
       
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1002){
        this.responseMessgae = "حدث خطا ما";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
    
      else if(response.upload_documents_response== 1011){
        this.responseMessgae = "حدث خطا ما";
      
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1012){
        this.responseMessgae = "حدث خطا ما";
      
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1013){
    
         this.responseMessgae = "حدث خطا ما";
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1014){
        this.spinnerfull.hide();
        this.responseMessgae = "حدث خطا ما";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1255){
        this.responseMessgae = "يجب أن لا يكون المستند فارغ";
        this.spinnerfull.hide();
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1256){
        this.responseMessgae = "يجب أن لا يكون المستند فارغ ";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1257){
        this.spinnerfull.hide();
        this.responseMessgae = "حجم المستند اقل من 5 ميغابايت";    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1258){
        this.spinnerfull.hide();
        this.responseMessgae = "حجم المستندات بين 2 الي 5 ميغابايت";    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1259){
        this.spinnerfull.hide();
        this.responseMessgae = "PNG ,JPG ,PDF ,XLS تنسيقات المستندات المسموح بيها ";    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.upload_documents_response== 1260){
        this.spinnerfull.hide();
        this.responseMessgae = "PNG ,JPG ,PDF ,XLS تنسيقات المستندات المسموح بيها ";    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      

      else {

        this.spinnerfull.hide();
        this.responseMessgae = "حدث خطا ما";   
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
    })
   
  }

//   }

// else {
//   this.responseMessgaeer = 'اختر وثيقة واحدة على الأقل'
// }



}
 

  GetProfiles(tab){
  if(tab.index=='0'){

    this.BasicInfoHide = true;
    this.basicotpShow = false;
    this.ngOnInit();
    this.GetbasicProfile()
  }else if(tab.index=='1'){

    this.PersonalFormHide = true;
    this.otpShow = false;
    this.ngOnInit();
    this.GetPersonalProfile();
  }else if(tab.index=='2'){
    this.BankDetHide = true;
    this.bankotpShow = false;
    this.ngOnInit();
    this.GetBankDetails();
  }else if(tab.index=='3'){
   // this.GetBankDetails();
  }
}
GetbasicProfile(){
  
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'ar';
   //object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'

   console.log(object)
   this.spinnerfull.show();
   this.authService.GetbasicProfile(object,this.accesstoken).subscribe(response=>
    this.basicprofileResponse(response))
  }
  basicprofileResponse(response){
   console.log(response)
   this.basicdetails = response
    this.spinnerfull.hide();
    if(response.Token_Status=='1119'){
    if(response.basic_profile_status=='1000'){
      this.basicForm.patchValue({
        firstName:response.first_name,
        lastName:response.last_name,
        mobileNo:response.mobile_number,
        riyadName:response.virtual_account_number,
        email:response.email,
      })
    }
  }else if(response.Token_Status=='1120'){
    this.profileError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.profileError = true;
    this.errorMessage = ' ';
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }
  }

  GetPersonalProfile(){
    const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'ar';
   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   this.spinnerfull.show();
   this.authService.GetPersonalProfile(object,this.accesstoken).subscribe(response=>
    this.basicpersonalprofResponse(response))
  }



  nationalitychange(val) {
    (val)
    this.changeenablenational = val;
    if(val == 'Saudi') {
this.saudi = true;
this.nonsaudi = false;
    }
    if(val == 'Non-Saudi') {
      this.saudi = false;
      this.nonsaudi = true;
          }


  }
  basicpersonalprofResponse(response){
console.log(response)

this.personalresponse = response
if(response.nationality_number == 'NA') {

  this.iqamaNA = true;
  this.iqama = false;
}

else{
  
  console.log('navya')
  this.iqamaNA = false;
  this.iqama = true;
}
if(response.gender == 'NA') {

  this.genvalue = true;
  this.genna = false;
}

else{
  
  console.log('navya')
  this.genvalue = false;
  this.genna = true;
}
    this.spinnerfull.hide();
    if(response.Token_Status=='1119'){

if(response.personal_profile_status=='1168'){
  // const formattedDat = moment(response.id_expiry_date).format("MM-DD-YYYY");
  // (formattedDat);
  // this.idvaliddate=formattedDat

  this.backendnationality = response.is_saudi_resident
  if(response.is_saudi_resident == "Non-Saudi") {

    this.nonsaudi = true;
    this.saudi = false;

  }
  if(response.is_saudi_resident == "Saudi") {

    this.nonsaudi = false;
    this.saudi  = true;

  }
  if(response.annual_income != "NA" || response.job_status != "NA" || response.source_of_income != "NA"){
    this.personalForm.patchValue({
      annualIncome:response.annual_income,
      sourceIncome:response.source_of_income,
      jobstatus:response.job_status,
    
    })
      }
  
  this.personalForm.patchValue({
    // annualIncome:response.annual_income,
    // sourceIncome:response.source_of_income,
    // jobstatus:response.job_status,
    iqama:response.nationality_number,
    nameen:response.full_name_en,
        namear:response.full_name_ar,
        placeOfBirth:response.placeOfBirth,
        currentResidentLocation:response.currentResidentLocation,
    nationality:response.is_saudi_resident,
    gender:response.gender,
    dob:response.dob,
    
    idexpiryDate:response.id_expiry_date,
    dobnon:response.dob,
    
    idexpiryDatenon:response.id_expiry_date
  })

}else if(response.personal_profile_status=='1169'){
  this.profileError = true;
     // this.errorMessage = 'PERSONAL PROFILE DETAILS NOT AVALIABLE';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);
}


    }else if(response.Token_Status=='1120'){
      this.profileError = true;
    //  this.errorMessage = 'غير مصرح';
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);

    
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = ' ';
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);

    
    }
  }

GetBankDetails(){
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'ar';
   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
  
   this.spinnerfull.show();
   this.authService.GetBankDetails(object,this.accesstoken).subscribe(response=>
    this.bankdetailsResponse(response))
}
bankdetailsResponse(response){
console.log(response)
  this.spinnerfull.hide();

  (response)
  if(response.Token_Status=='1119'){

    if(response.bank_info_status=='1172'){
      if(response.bank_name !="NA"){
        this.BankDetailsForm.patchValue({
          bankname:response.bank_name,
      
        })
      }

      this.BankDetailsForm.patchValue({
        // bankname:response.bank_name,
        accountholder:response.bank_account_holder_name,
        baniban:response.bank_iban,
        virtualaccountNum:response.virtual_account_number,
        
      })



    }else if(response.bank_info_status=='1173'){
      this.profileError = true;
     // this.errorMessage = 'Bank Details Not Avaliable';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);
    }
  }else if(response.Token_Status=='1120'){
    this.profileError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.profileError = true;
    this.errorMessage = ' ';
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }
}




changeDate(val) {
  (val)


  var age = 18;
  const formattedDate = val;
 
  
  
  if(formattedDate.day < 10  && formattedDate.month < 10 ) {

 
    this.datdob =  `${formattedDate.year}-0${formattedDate.month}-0${formattedDate.day}`
    
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-0${formattedDate.month -1}-0${formattedDate.day}` ;
    (setDate)
  var currdate = this.todaydate;

  if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18
  
  // alert("above 18");
  } else {
  
  this.doberrdis = true;
  this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);
  }
    return this.datdob
  
  }
  else if(formattedDate.month < 10 ) {
  
   
    this.datdob =  `${formattedDate.year}-0${formattedDate.month}-${formattedDate.day}`
    
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-0${formattedDate.month -1}-${formattedDate.day}` ;
    (setDate)
  var currdate = this.todaydate;
  
  if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18
  
  // alert("above 18");
  } else {
  
  this.doberrdis = true;
  this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);
  }
    return this.datdob
  
  }
  else if(formattedDate.day < 10 ) {
  
   
    this.datdob =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
  
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-0${formattedDate.day}` ;
   
  var currdate = this.todaydate;
  
  if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18
  
  // alert("above 18");
  } else {
  
  this.doberrdis = true;
  this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);
  }
    return this.datdob
  
  }
else{
  this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
  
  // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
  var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;
  
var currdate = this.todaydate;


if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate
// you are above 18

//alert("above 18");
} else {

this.doberrdis = true;
this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);

// alert("below 18");
}
  return this.datdob

}
}

onidDateChange(val) {
    
      
  (val)


  
   // Replace event.value with your date value
   var d = new Date(val),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

        this.idattt = [year, month, day].join('-')

}

changeidDate(val) {
  const formattedDate = val;
  

  if(formattedDate.day < 10){
    this.idexpire =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
  //  (this.dataaaaae)
    return this.idexpire
  }
  else {
    this.idexpire =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
  //  (this.dataaaaae)
    return this.idexpire
  }

}







// UpdatePersonalProfile(){
 
  
//   this.submitted1=true;
//   this.personalForm.get('annualIncome').markAsTouched();
//   this.personalForm.get('sourceIncome').markAsTouched();
//   this.personalForm.get('jobstatus').markAsTouched();
//   this.personalForm.get('iqama').markAsTouched();
//   this.personalForm.get('nameen').markAsTouched();
//   this.personalForm.get('namear').markAsTouched();
//   this.personalForm.get('nationality').markAsTouched();
//   this.personalForm.get('gender').markAsTouched();
//   this.personalForm.get('dob').markAsTouched();
//   this.personalForm.get('idexpiryDate').markAsTouched();


  
//   if(this.changeenablenational  == 'Saudi') {
//     ('navysdfdf')
//     (this.personalForm.valid)
// if(this.dobdatcurrent == true){
// if(this.personalForm.valid){

//   const object:any={}
//   object['browserType'] = this.deviceInfo.browser;
//   object['browserVersion'] = this.deviceInfo.browser_version;
//   object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//   object['osVersion'] = this.deviceInfo.os_version;
//   object['osType'] = this.deviceInfo.os;
//   object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//   object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//   object['language'] = 'en';
//   object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//   object['anualIncome'] = this.personalForm.value.annualIncome
//   object['sourceIncome'] = this.personalForm.value.sourceIncome
//    object['jobStatus'] = this.personalForm.value.jobstatus;
//    object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//    object['nameEn'] = this.personalForm.value.nameen;
//    object['nameAr'] = this.personalForm.value.namear;
//    if(this.personalForm.value.nationality=='Saudi'){
//     object['isSauthiResident'] = '1';
   
//    }else if(this.personalForm.value.nationality=='Non-Saudi'){
//     object['isSauthiResident'] =  '0';
//    }
//   object['deviceType']='Web'
//    object['gender'] = this.personalForm.value.gender;



//    object['idExpiryDate'] =this.idexpire;

//     object['dob'] = this.datdob
   
//    (object)
//     this.spinnerfull.show()
//     this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//       this.updateProfileresponse(response))

// }

// }
//   }


//  else if(this.changeenablenational  == 'Non-Saudi')  {
//    ('manasa')
//    (this.personalForm.valid)


// const object:any={}
// object['browserType'] = this.deviceInfo.browser;
// object['browserVersion'] = this.deviceInfo.browser_version;
// object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
// object['osVersion'] = this.deviceInfo.os_version;
// object['osType'] = this.deviceInfo.os;
// object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
// object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
// object['language'] = 'en';
// object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
// object['anualIncome'] = this.personalForm.value.annualIncome
// object['sourceIncome'] = this.personalForm.value.sourceIncome
//  object['jobStatus'] = this.personalForm.value.jobstatus;
//  object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//  object['nameEn'] = this.personalForm.value.nameen;
//  object['nameAr'] = this.personalForm.value.namear;

//  (this.personalForm.value.dob)
//  if(this.personalForm.value.nationality =='Saudi'){
//   object['isSauthiResident'] = '1';

//  }else if(this.personalForm.value.nationality=='Non-Saudi'){
//   object['isSauthiResident'] =  '0';
 
//  }

//  object['dob'] = this.bobdattt

// object['deviceType']='Web'
//  object['gender'] = this.personalForm.value.gender;

//   object['idExpiryDate'] = this.idattt;

//   (object)
//   this.spinnerfull.show()

//   this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//     this.updateProfileresponse(response))


// }

// else {
// if(this.personalForm.valid){

//   const object:any={}
//   object['browserType'] = this.deviceInfo.browser;
//   object['browserVersion'] = this.deviceInfo.browser_version;
//   object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//   object['osVersion'] = this.deviceInfo.os_version;
//   object['osType'] = this.deviceInfo.os;
//   object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//   object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//   object['language'] = 'en';
//   object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//   object['anualIncome'] = this.personalForm.value.annualIncome
//   object['sourceIncome'] = this.personalForm.value.sourceIncome
//    object['jobStatus'] = this.personalForm.value.jobstatus;
//    object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//    object['nameEn'] = this.personalForm.value.nameen;
//    object['nameAr'] = this.personalForm.value.namear;




//    (this.personalForm.value.dob)
//    if(this.personalForm.value.nationality =='Saudi'){
//     object['isSauthiResident'] = '1';
 
//    }else if(this.personalForm.value.nationality=='Non-Saudi'){
//     object['isSauthiResident'] =  '0';
   
//    }



   

    

//    if(this.backendnationality == "Non-Saudi") {
//     this.onDateChange(this.personalForm.value.dob);
//     object['dob'] =this.bobdattt;
//     object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
    
//    }

   
//    if(this.backendnationality == "Saudi") {
//     this.changeDate(this.personalForm.value.dob);
//     object['dob'] =this.datdob;
//     object['idExpiryDate'] =this.idexpire;
    
//    }



   
 
//   object['deviceType']='Web'
//    object['gender'] = this.personalForm.value.gender;

    

//     (object)
//     this.spinnerfull.show()

//     this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//       this.updateProfileresponse(response))

// }
// }


// }

// UpdatePersonalProfile(){
 

  
//   this.submitted1=true;
//   this.personalForm.get('annualIncome').markAsTouched();
//   this.personalForm.get('sourceIncome').markAsTouched();
//   this.personalForm.get('jobstatus').markAsTouched();
//   this.personalForm.get('iqama').markAsTouched();
//   this.personalForm.get('nameen').markAsTouched();
//   this.personalForm.get('namear').markAsTouched();
//   this.personalForm.get('nationality').markAsTouched();
//   this.personalForm.get('gender').markAsTouched();
//   this.personalForm.get('dob').markAsTouched();
//   this.personalForm.get('idexpiryDate').markAsTouched();


  
//   if(this.changeenablenational  == 'Saudi') {
//     ('navysdfdf')
// if(this.dobdatcurrent == true){
// if(this.personalForm.valid){

//   const object:any={}
//   object['browserType'] = this.deviceInfo.browser;
//   object['browserVersion'] = this.deviceInfo.browser_version;
//   object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//   object['osVersion'] = this.deviceInfo.os_version;
//   object['osType'] = this.deviceInfo.os;
//   object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//   object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//   object['language'] = 'en';
//   object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//   object['anualIncome'] = this.personalForm.value.annualIncome
//   object['sourceIncome'] = this.personalForm.value.sourceIncome
//    object['jobStatus'] = this.personalForm.value.jobstatus;
//    object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//    object['nameEn'] = this.personalForm.value.nameen;
//    object['nameAr'] = this.personalForm.value.namear;
//    if(this.personalForm.value.nationality=='Saudi'){
//     object['isSauthiResident'] = '1';
   
//    }else if(this.personalForm.value.nationality=='Non-Saudi'){
//     object['isSauthiResident'] =  '0';
//    }
//   object['deviceType']='Web'
//    object['gender'] = this.personalForm.value.gender;



//    object['idExpiryDate'] =this.idexpire;

//     object['dob'] = this.datdob
   
//    (object)
//     this.spinnerfull.show()
//     this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//       this.updateProfileresponse(response))

// }

// }
//   }


//  else if(this.changeenablenational  == 'Non-Saudi')  {
//    ('manasa')
//    (this.personalForm.valid)
// (this.bobdattt)
// this.getcurrentengdob()
// const object:any={}
// object['browserType'] = this.deviceInfo.browser;
// object['browserVersion'] = this.deviceInfo.browser_version;
// object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
// object['osVersion'] = this.deviceInfo.os_version;
// object['osType'] = this.deviceInfo.os;
// object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
// object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
// object['language'] = 'en';
// object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
// object['anualIncome'] = this.personalForm.value.annualIncome
// object['sourceIncome'] = this.personalForm.value.sourceIncome
//  object['jobStatus'] = this.personalForm.value.jobstatus;
//  object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//  object['nameEn'] = this.personalForm.value.nameen;
//  object['nameAr'] = this.personalForm.value.namear;

//  (this.personalForm.value.dob)
//  if(this.personalForm.value.nationality =='Saudi'){
//   object['isSauthiResident'] = '1';

//  }else if(this.personalForm.value.nationality=='Non-Saudi'){
//   object['isSauthiResident'] =  '0';
 
//  }

 
//  if(this.backendnationality == "Non-Saudi") {

//   (this.personalForm.value.dobnon)
//   this.onDateChange(this.personalForm.value.dobnon);
//   object['dob'] =this.bobdattt;
//   this.changeidDate(this.personalForm.value.idexpiryDate);
//   (this.personalForm.value.idexpiryDate)
//   object['idExpiryDate'] =this.personalForm.value.idexpiryDatenon;
  
//  }
//  else {
//    ('connn')
  
//   object['dob'] = this.bobdattt
//   object['idExpiryDate'] = this.idattt;
//  }



// object['deviceType']='Web'
//  object['gender'] = this.personalForm.value.gender;

 

//   (object)
//   this.spinnerfull.show()

//   this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//     this.updateProfileresponse(response))


// }

// else {
//     if(this.personalForm.valid){
  
//       const object:any={}
//       object['browserType'] = this.deviceInfo.browser;
//       object['browserVersion'] = this.deviceInfo.browser_version;
//       object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//       object['osVersion'] = this.deviceInfo.os_version;
//       object['osType'] = this.deviceInfo.os;
//       object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//       object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//       object['language'] = 'en';
//       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//       object['anualIncome'] = this.personalForm.value.annualIncome
//       object['sourceIncome'] = this.personalForm.value.sourceIncome
//        object['jobStatus'] = this.personalForm.value.jobstatus;
//        object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//        object['nameEn'] = this.personalForm.value.nameen;
//        object['nameAr'] = this.personalForm.value.namear;
    
    
    
    
//        (this.personalForm.value.dob)
//        if(this.personalForm.value.nationality =='Saudi'){
//         object['isSauthiResident'] = '1';
     
//        }else if(this.personalForm.value.nationality=='Non-Saudi'){
//         object['isSauthiResident'] =  '0';
       
//        }
    
    
    
       
    
        
    
//        if(this.backendnationality == "Non-Saudi") {
      
  
//          let dateerr = (this.dobdatcurrent == true)
//          (dateerr)
//          if(dateerr == false){
//            ('djhfksdjfh')
          
//            this.onDateChange(this.personalForm.value.dob);
//            object['dob'] =this.personalForm.value.dob;
//            object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//          }
//         if(this.dobdatcurrent == true){
  
//           ('trueeee')
//         this.onDateChange(this.elsedate);
        
//         object['dob'] =this.bobdattt;
//         object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//         object['deviceType']='Web'
//         object['gender'] = this.personalForm.value.gender;
     
         
     
//          (object)
//          this.spinnerfull.show()
     
//          this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//            this.updateProfileresponse(response))
     
//         }
        
//        }
    
       
//        if(this.backendnationality == "Saudi") {
//         this.changeDate(this.personalForm.value.dob);
//         object['dob'] =this.datdob;
//         object['idExpiryDate'] =this.idexpire;
//         object['deviceType']='Web'
//         object['gender'] = this.personalForm.value.gender;
     
         
     
//          (object)
//          this.spinnerfull.show()
     
//          this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//            this.updateProfileresponse(response))
     
        
//        }
    
    
    
       
     
    
//     }
//   }



// }




UpdatePersonalProfile(){
  // this.profilepage=false;
  // this.otpShow=true;
  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }
  this.submitted1=true;
  // this.personalForm.get('annualIncome').markAsTouched();
  // this.personalForm.get('sourceIncome').markAsTouched();
  // this.personalForm.get('jobstatus').markAsTouched();
  // this.personalForm.get('iqama').markAsTouched();
  // this.personalForm.get('nameen').markAsTouched();
  // this.personalForm.get('namear').markAsTouched();
  // this.personalForm.get('nationality').markAsTouched();
  // this.personalForm.get('gender').markAsTouched();
  this.personalForm.get('dob').markAsTouched();
  this.personalForm.get('idexpiryDate').markAsTouched();
 
if(this.dobdatcurrent  == true){
if(this.personalForm.valid){

  const object:any={}
  object['browserType'] = this.deviceInfo.browser;
  object['browserVersion'] = this.deviceInfo.browser_version;
  object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['osVersion'] = this.deviceInfo.os_version;
  object['osType'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
  object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
  object['anualIncome'] = this.personalForm.value.annualIncome
  object['sourceIncome'] = this.personalForm.value.sourceIncome
   object['jobStatus'] = this.personalForm.value.jobstatus;
   object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
   object['placeOfBirth'] = this.personalForm.value.placeOfBirth

   if(this.personalresponse.nationality_number =='NA'){
    object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
    
   if(this.personalForm.value.nationality=='سعودي'){
    object['isSauthiResident'] = '1';
   }else if(this.personalForm.value.nationality=='غير سعودي'){
    object['isSauthiResident'] =  '0';
   }
   }
   else{
    object['nationalNumberiqamaNumber'] = this.personalresponse.nationality_number;
    if(this.personalresponse.is_saudi_resident=='سعودي'){
      object['isSauthiResident'] = '1';
     }else if(this.personalresponse.is_saudi_resident=='غير سعودي'){
      object['isSauthiResident'] =  '0';
     }
   }
   object['nameEn'] = this.personalForm.value.nameen;
   object['nameAr'] = this.personalForm.value.namear;

  object['deviceType']='Web'
   object['gender'] = this.personalForm.value.gender;
   const momentDate1 = new Date(this.personalForm.value.dob); 
const formattedDate = moment(momentDate1).format("YYYY-MM-DD");



var d = new Date(this.personalForm.value.dob),
month = '' + (d.getMonth() + 1),
day = '' + d.getDate(),
year = d.getFullYear();

if (month.length < 2) 
month = '0' + month;
if (day.length < 2) 
day = '0' + day;

this.bobdattt = [year, month, day].join('-')


    object['dob'] = this.bobdattt
    const momentDate= new Date(this.personalForm.value.idexpiryDate); 
    const formattedDat = moment(momentDate).format("MM-DD-YYYY");
    


    var d = new Date(this.personalForm.value.dob),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
    
    if (month.length < 2) 
    month = '0' + month;
    if (day.length < 2) 
    day = '0' + day;
    
    this.bobdatttid = [year, month, day].join('-')

    object['idExpiryDate'] = this.bobdatttid 
console.log(object)
    this.spinnerfull.show()
    this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
      this.updateProfileresponse(response))

}
}

else if(this.dobdatcurrent  == false) {
  if(this.personalForm.valid){

    const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['anualIncome'] = this.personalForm.value.annualIncome
    object['sourceIncome'] = this.personalForm.value.sourceIncome
     object['jobStatus'] = this.personalForm.value.jobstatus;
     object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
     object['placeOfBirth'] = this.personalForm.value.placeOfBirth
  
    //  object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
     object['nameEn'] = this.personalForm.value.nameen;
     object['nameAr'] = this.personalForm.value.namear;
     if(this.personalresponse.nationality_number =='NA'){
      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
      
     if(this.personalForm.value.nationality=='سعودي'){
      object['isSauthiResident'] = '1';
     }else if(this.personalForm.value.nationality=='غير سعودي'){
      object['isSauthiResident'] =  '0';
     }
     }
     else{
      object['nationalNumberiqamaNumber'] = this.personalresponse.nationality_number;
      if(this.personalresponse.is_saudi_resident=='سعودي'){
        object['isSauthiResident'] = '1';
       }else if(this.personalresponse.is_saudi_resident=='غير سعودي'){
        object['isSauthiResident'] =  '0';
       }
     }
    object['deviceType']='Web'
     object['gender'] = this.personalForm.value.gender;
     const momentDate1 = new Date(this.personalForm.value.dob); 
  const formattedDate = moment(momentDate1).format("YYYY-MM-DD");
 
  
  
  var d = new Date(this.personalForm.value.dob),
  month = '' + (d.getMonth() + 1),
  day = '' + d.getDate(),
  year = d.getFullYear();
  
  if (month.length < 2) 
  month = '0' + month;
  if (day.length < 2) 
  day = '0' + day;
  
  this.bobdattt = [year, month, day].join('-')
  
  
      object['dob'] = this.bobdattt
      const momentDate= new Date(this.personalForm.value.idexpiryDate); 
      const formattedDat = moment(momentDate).format("MM-DD-YYYY");
   
  
  
      var d = new Date(this.personalForm.value.dob),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
      
      if (month.length < 2) 
      month = '0' + month;
      if (day.length < 2) 
      day = '0' + day;
      
      this.bobdatttid = [year, month, day].join('-')
  
      object['idExpiryDate'] = this.bobdatttid 
      console.log(object)
      this.spinnerfull.show()
      this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
        this.updateProfileresponse(response))
  
  }


}

else {
  if(this.personalForm.valid){

    const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'ar';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['anualIncome'] = this.personalForm.value.annualIncome
    object['sourceIncome'] = this.personalForm.value.sourceIncome
     object['jobStatus'] = this.personalForm.value.jobstatus;
     object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
     object['nameEn'] = this.personalForm.value.nameen;
     object['nameAr'] = this.personalForm.value.namear;
     object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
     object['placeOfBirth'] = this.personalForm.value.placeOfBirth
  
     if(this.personalresponse.nationality_number =='NA'){
      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
      
     if(this.personalForm.value.nationality=='سعودي'){
      object['isSauthiResident'] = '1';
     }else if(this.personalForm.value.nationality=='غير سعودي'){
      object['isSauthiResident'] =  '0';
     }
     } 
     else{
      object['nationalNumberiqamaNumber'] = this.personalresponse.nationality_number;
      if(this.personalresponse.is_saudi_resident=='سعودي'){
        object['isSauthiResident'] = '1';
       }else if(this.personalresponse.is_saudi_resident=='غير سعودي'){
        object['isSauthiResident'] =  '0';
       }
     }
    object['deviceType']='Web'
     object['gender'] = this.personalForm.value.gender;
     const momentDate1 = new Date(this.personalForm.value.dob); 
  const formattedDate = moment(momentDate1).format("YYYY-MM-DD");

  
  
  var d = new Date(this.personalForm.value.dob),
  month = '' + (d.getMonth() + 1),
  day = '' + d.getDate(),
  year = d.getFullYear();
  
  if (month.length < 2) 
  month = '0' + month;
  if (day.length < 2) 
  day = '0' + day;
  
  this.bobdattt = [year, month, day].join('-')
  
  
      object['dob'] = this.bobdattt
      const momentDate= new Date(this.personalForm.value.idexpiryDate); 
      const formattedDat = moment(momentDate).format("MM-DD-YYYY");
    
  
  
      var d = new Date(this.personalForm.value.dob),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
      
      if (month.length < 2) 
      month = '0' + month;
      if (day.length < 2) 
      day = '0' + day;
      
      this.bobdatttid = [year, month, day].join('-')
  
      object['idExpiryDate'] = this.bobdatttid 
      console.log(object)
      this.spinnerfull.show()
      this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
        this.updateProfileresponse(response))
  
  }
}

  
}



  getcurrentengdob() {
    this.currentengdob =new Date()

    var d = new Date(this.currentengdob),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
    
    if (month.length < 2) 
    month = '0' + month;
    if (day.length < 2) 
    day = '0' + day;
    
    this.finalengcurrentdat = [year, month, day].join('-');
    
    return this.finalengcurrentdat
    
    }
    
    
  
    
    onDateChange(val) {
    
    this. getcurrentengdob()
      (val)
 
      this.elsedate = val;
      
       // Replace event.value with your date value
       var d = new Date(val),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
            this.bobdattt = [year, month, day].join('-')
         
    this.setDate = [year+ 18, month, day].join('-');
            var currdate = this.finalengcurrentdat;
    
           
            (currdate >= this.setDate)
    
            if (currdate >= this.setDate) {
            this.dobdatcurrent = currdate >= this.setDate
         
            this.doberr = ''
           
            } else {
           
            this.doberrdiseng = true;
            this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
            // setTimeout(() => {
            //   this.doberrdiseng = false;
            // }, 3000);
            
     
            
            }
        return  this.bobdattt;
    
    }











  updateProfileresponse(response){
    
    this.spinnerfull.hide();
    this.submitted1=false;
    if(response.Token_Status=='1119'){

      if(response.Update_Personal_ProfileOtp_Response=='1000'){
        this.PersonalFormHide=false;
        this.otpShow=true;





        
      //   this.SucessError = true;
      // this.sucessMessage = 'Update';
      // setTimeout(() => {
      //   this.SucessError = false;
      // }, 3000);
      }else  if(response.Update_Personal_ProfileOtp_Response=='1001'){
        this.profileError = true;
        this.errorMessage = 'فشل';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1132'){
        this.profileError = true;
        this.errorMessage = 'الدخل السنوي فارغ ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1133'){
        this.profileError = true;
        this.errorMessage = 'مصدر الدخل السنوي فارغ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1134'){
        this.profileError = true;
        this.errorMessage = 'الحاله الوظيفية فارغة';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1135'){
        this.profileError = true;
        this.errorMessage = 'رقم الهوية الوطنية فارغ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1136'){
        this.profileError = true;
        this.errorMessage = 'الاسم الكامل بالانجليزية فارغ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1137'){
        this.profileError = true;
        this.errorMessage = 'الاسم الكامل بالعربية فارغ ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1138'){
        this.profileError = true;
        this.errorMessage = 'رقم الاقامة فارغ ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1139'){
        this.profileError = true;
        this.errorMessage = 'الجنس فارغ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1140'){
        this.profileError = true;
        this.errorMessage = 'تاريخ الميلاد فارغ ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1141'){
        this.profileError = true;
        this.errorMessage = 'تاريخ انتهاء صلاحية هويتك فارغ ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1142'){
        this.profileError = true;
        this.errorMessage = 'هنالك خطاً ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }if(response.Update_Personal_ProfileOtp_Response=='1143'){
        this.profileError = true;
        this.errorMessage = 'هنالك خطاً ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }if(response.Update_Personal_ProfileOtp_Response=='1144'){
        this.profileError = true;
        this.errorMessage = 'هنالك خطاً ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }

      if(response.Update_Personal_ProfileOtp_Response=='1253'){
        this.profileError = true;
        this.errorMessage = 'مكان الميلاد فارغ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }if(response.Update_Personal_ProfileOtp_Response=='1254'){
        this.profileError = true;
        this.errorMessage = 'موقع المقيم الحالي فارغ';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }
    }else if(response.Token_Status=='1120'){
      this.profileError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
  }
}

  VerifyOtp(){
    this.submitted=true;
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    
    if(this.otpForm.valid){
    const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'ar';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['anualIncome'] = this.personalForm.value.annualIncome
    object['sourceIncome'] = this.personalForm.value.sourceIncome
     object['jobStatus'] = this.personalForm.value.jobstatus;
     object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
     object['nameEn'] = this.personalForm.value.nameen;
     object['nameAr'] = this.personalForm.value.namear;
     object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
     object['placeOfBirth'] = this.personalForm.value.placeOfBirth
     if(this.personalForm.value.nationality=='Saudi'){
      object['isSauthiResident'] = '1';
     }else if(this.personalForm.value.nationality=='Non-Saudi'){
      object['isSauthiResident'] =  '0';
     }
     object['deviceType']='Web'
     object['gender'] = this.personalForm.value.gender;
     const momentDate1 = new Date(this.personalForm.value.dob); 
const formattedDate = moment(momentDate1).format("YYYY-MM-DD");

      object['dob'] = this.bobdattt
      const momentDate= new Date(this.personalForm.value.idexpiryDate); 
      //MM-DD-YYYY
      const formattedDat = moment(momentDate).format("YYYY-MM-DD");
    
      object['idExpiryDate'] =this.bobdatttid
      object['otp'] =this.otpForm.value.otp
      
      this.spinnerfull.show()
      this.authService.updateprofile(object,this.accesstoken).subscribe(response=>
        this.updatepersonalprofileotp(response))
      }
  }


  updatepersonalprofileotp(response){
   
    this.spinnerfull.hide();
    this.submitted=false;
if(response.Token_Status=='1119'){
  if(response.Update_Personal_Profile_Response=='1000'){
    this.updateprosucMessage = true;
      this.updatepersonalInformation="تم تحديث المعلومات الشخصية بنجاح "
       setTimeout(() => {
      this.PersonalFormHide=true;
      this.otpShow=false;
      this.otpForm.reset();
      this.updateprosucMessage = false;


      const object:any =  {}

      object['FirstName']  = this.data.FirstName;
      object['LastName']     = this.data.LastName;
      object['LastLogin']    = this.data.LastLogin;
      object['isMobileVerified']   = this.data.isMobileVerified;
      object['isEmailVerified']   = this.data.isEmailVerified;
      object['accesstoken']   = this.data.accesstoken;
      object['ProfilePic'] = this.data.ProfilePic;
      object['id']=this.data.id
      object['profileStatus']=this.data.profileStatus
      object['redirect'] = "arabicWebapp";
      object['isPolicyAccepted']  = this.data.isPolicyAccepted;
      object['isBankInfoProvided']   = this.data.isBankInfoProvided;
      object['isInvestorInfoProvided']  = "Yes";
      object['isTermsAccepted']  = this.data.isTermsAccepted;


      object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;

      sessionStorage.setItem('currentUser',JSON.stringify(object))
    }, 3000);

  }else  if(response.Update_Personal_Profile_Response=='1001'){
    this.personalInfoprofileError = true;
        this.errorMessage = 'فشل';
        setTimeout(() => {
          this.personalInfoprofileError = false;
        }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1090'){
    this.personalInfoprofileError = true;
        this.errorMessage = ' حقل كلمة المرور. المؤقتة فارغ ';
        setTimeout(() => {
          this.personalInfoprofileError = false;
        }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1091'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1092'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1093'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1094'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'انتهت صلاحية كلمة المرور المؤقتة ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }

  
  if(response.Update_Personal_Profile_Response=='1253'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'مكان الميلاد فارغ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }if(response.Update_Personal_Profile_Response=='1254'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'موقع المقيم الحالي فارغ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }
   }else if(response.Token_Status=='1120'){
    this.personalInfoprofileError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.personalInfoprofileError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.personalInfoprofileError = true;
    this.errorMessage = ' ';
    setTimeout(() => {
      this.personalInfoprofileError = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }
}


updateBankInfo(){


  
  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }


  this.submitted1=true;
  // this.BankDetailsForm.get('bankname').markAsTouched();
  // this.BankDetailsForm.get('baniban').markAsTouched();
  // this.BankDetailsForm.get('accountholder').markAsTouched();
 console.log(this.BankDetailsForm.valid)

if(this.BankDetailsForm.valid){
  const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'ar';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['bankName'] = this.BankDetailsForm.value.bankname
    object['ibanNumber'] = this.BankDetailsForm.value.baniban;
    object['acountName'] = this.BankDetailsForm.value.accountholder;
    object['deviceType']='Web'
    this.spinnerfull.show();
    console.log(object)
    this.authService.updateBankDetailsOtp(object,this.accesstoken).subscribe(response=>
      this.updatebankDertOtpResponse(response))
}
    
}
updatebankDertOtpResponse(response){

  console.log(response)
  this.submitted1=false;
 
  this.spinnerfull.hide();
  if(response.Token_Status=='1119'){
  if(response.Bank_Info_Otp_Response=='1000'){
  //  this.profilepage=false;
  this.BankDetHide=false;
    this.bankotpShow=true;

 

    const object:any =  {}

    object['FirstName']  = this.data.FirstName;
    object['LastName']     = this.data.LastName;
    object['LastLogin']    = this.data.LastLogin;
    object['isMobileVerified']   = this.data.isMobileVerified;
    object['isEmailVerified']   = this.data.isEmailVerified;
    object['accesstoken']   = this.data.accesstoken;
    object['ProfilePic'] = this.data.ProfilePic;
    object['id']=this.data.id
    object['profileStatus']=this.data.profileStatus
    object['redirect'] = "arabicWebapp";
    object['isPolicyAccepted']  = this.data.isPolicyAccepted;
    object['isBankInfoProvided']   = "Yes";
    object['isInvestorInfoProvided']  = this.data.isInvestorInfoProvided;
    object['isTermsAccepted']  = this.data.isTermsAccepted;
    object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;

    sessionStorage.setItem('currentUser',JSON.stringify(object))

  }else if(response.Bank_Info_Otp_Response=='1001'){

    this.profileErrorbefotp = true;
    this.errorMessage = 'فشل';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);
  }else if(response.Bank_Info_Otp_Response=='1054'){

    this.profileErrorbefotp = true;
    this.errorMessage = 'يجب الا يكون اسم المصرف فارغ ';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);
  }else if(response.Bank_Info_Otp_Response=='1055'){
    this.profileErrorbefotp = true;
    this.errorMessage = 'يجب الا يكون رقم الايبان فارغا';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1145'){
    this.profileErrorbefotp = true;
    this.errorMessage = 'اسم الحساب المصرفي فارغ';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1003'){
    this.profileErrorbefotp = true;
    this.errorMessage = 'هنالك خطاً ';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1004'){
    this.profileErrorbefotp = true;
    this.errorMessage = 'هنالك خطاً ';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1005'){

    this.profileErrorbefotp = true;
    this.errorMessage = 'هنالك خطاً ';
    setTimeout(() => {
      this.profileErrorbefotp = false;
    }, 3000);
  }
  }else if(response.Token_Status=='1120'){
    this.profileErrorbefotp = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.profileErrorbefotp = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.profileErrorbefotp = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.profileErrorbefotp = false;
      this.refresh.unAuthorizeArabic(this.tokenmessage)
      this.router.navigate(['/arhome'])
      sessionStorage.clear()
    }, 3000);
  }
}

UpdatebankInfoOtpSubmit(){
  this.submittedb=true
  if(this.otpForm.valid){
  const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'ar';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['bankName'] = this.BankDetailsForm.value.bankname
    object['ibanNumber'] = this.BankDetailsForm.value.baniban;
    object['acountName'] = this.BankDetailsForm.value.accountholder;
    object['otp'] = this.otpForm.value.otp;
    object['deviceType']='Web'
    this.spinnerfull.show();
    this.authService.updateBankDetails(object,this.accesstoken).subscribe(response=>
      this.updatebankdetResponse(response))
    }
    // else{
    //   this.profileError = true;
    //   this.errorMessage = 'OTP_IS_EMPTY';
    //   setTimeout(() => { 
    //     this.profileError = false;
    //   }, 3000);
    // }
}
updatebankdetResponse(response){
 
  this.spinnerfull.hide();
  this.submitted=false
  if(response.Token_Status=='1119'){
    if(response.Bank_Info_Response=='1000'){
   //   alert("Bank Details Updated SucessFully")
   this.BankDetailsForm.reset();
  // this.otpForm.reset();
  //  this.profilepage=true;
  //  this.bankotpShow=false;
  //  this.sucessinfo = true;
      this.BankDetailsUpdatedSuces=" تم تحديث معلومات الحساب المصرفي بنجاح "
      this.GetBankDetails();
      this.bankdeterr = true;
      setTimeout(() => {
        //  this.profilepage=true;
        this.BankDetHide=true;
   this.bankotpShow=false;
   this.sucessinfo = true;
               this.bankdeterr = false;
               this.GetBankDetails();
               this.otpForm.reset();
      }, 3000);
     
      // this.SucessMessage = 'SUCCESS';
      // setTimeout(() => {
      //   this.sucessinfo = false;
      // }, 3000);
    }else  if(response.Bank_Info_Response=='1001'){
      this.profileError = true;
          this.errorMessage = 'فشل';
          setTimeout(() => {
            this.profileError = false;
          }, 3000);
    }else  if(response.Bank_Info_Response=='1090'){
      this.profileError = true;
          this.errorMessage = 'حقل كلمة المرور. المؤقتة فارغ ';
          setTimeout(() => {
            this.profileError = false;
          }, 3000);
    }else  if(response.Bank_Info_Response=='1091'){
      this.profileError = true;
      this.errorMessage = ' كلمة المرور المؤقتة غير صالحة';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else  if(response.Bank_Info_Response=='1092'){
      this.profileError = true;
      this.errorMessage = ' كلمة المرور المؤقتة غير صالحة';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else  if(response.Bank_Info_Response=='1093'){
      this.profileError = true;
      this.errorMessage = ' كلمة المرور المؤقتة غير صالحة';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else  if(response.Bank_Info_Response=='1094'){
      this.profileError = true;
      this.errorMessage = 'انتهت صلاحية كلمة المرور المؤقتة ';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }
     }else if(response.Token_Status=='1120'){
      this.profileError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){ 
      this.profileError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }
}

UpdateBasicDetails(){
  this.basicForm.get('mobileNo').markAsTouched();
  this.basicForm.get('firstName').markAsTouched();
  this.basicForm.get('lastName').markAsTouched();
this.submitted = true
if(this.basicForm.valid){
  const object: any = {}
  object['mobileNumber'] = this.basicForm.value.mobileNo;
  object['firstName'] = this.basicdetails.first_name;
  object['lastName'] = this.basicdetails.last_name;

  object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'ar';
   object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
   this.spinnerfull.show();
   console.log(object)
   this.authService.updateBasicInfoOtp(object,this.accesstoken).subscribe(response=>
    this.updatebasicinfootpres(response))
   }

}
updatebasicinfootpres(response){
console.log(response)
  this.spinnerfull.hide();
  if(response.update_profile=='1000'){
    this.BasicInfoHide=false
this.basicotpShow=true;
  }else if(response.update_profile=='1017'){
    this.profileError = true;
    this.errorMessage = 'رقم الجوال فارغ ';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1018'){
    this.profileError = true;
    this.errorMessage = 'رقم الجوال غير صالح ';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1019'){
    this.profileError = true;
    this.errorMessage = 'الاسم الأول فارغ';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1020'){
    this.profileError = true;
    this.errorMessage = 'الاسم الأخير فارغ ';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1021'){
    this.profileError = true;
    this.errorMessage = 'لايسمح باستخدام الرموز في الأسم الأول ';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1022'){
    this.profileError = true;
    this.errorMessage = 'لايسمح باستخدام الرموز في الأسم الاخير ';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }
}
BasicInfoOtpSubmit(){
  this.submittedo=true;
  if(this.otpForm.valid){
    const object: any = {}
    object['mobileNumber'] = this.basicForm.value.mobileNo;
    object['firstName'] = this.basicForm.value.firstName;
    object['lastName'] = this.basicForm.value.lastName;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'ar';
     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
     object['otp'] =this.otpForm.value.otp;
     this.spinnerfull.show();
     this.authService.basicInfoOtpSubmit(object,this.accesstoken).subscribe(response=>{
       this.basicInfoOtpSubmitResponse(response)
     }
      )

  }
  // else{
  //   this.profileError = true;
  //   this.errorMessage = 'OTP Required';
  //   setTimeout(() => {
  //     this.profileError = false;
  //   }, 3000);
  // }
}

basicInfoOtpSubmitResponse(response){
 
  this.spinnerfull.hide();
  if(response.Token_Status=='1119'){
    if(response.update_profile=='1000'){
      this.basicinfo="تم التحديث بنجاح"
      this.bacicprofilesucess = true;
      setTimeout(() => {
        this.otpForm.reset();
        this.bacicprofilesucess= false;
        this.BasicInfoHide=true
        this.basicotpShow=false;
      }, 3000);


    
    }else  if(response.update_profile=='1001'){
      this.bacicprofileError = true;
          this.errorMessage = 'فشل';
          setTimeout(() => {
            this.bacicprofileError = false;
          }, 3000);
    }else  if(response.update_profile=='1090'){
      this.bacicprofileError = true; 
          this.errorMessage = 'حقل كلمة المرور. المؤقتة فارغ ';
          setTimeout(() => {
            this.bacicprofileError = false;
          }, 3000);
    }else  if(response.update_profile=='1091'){
      this.bacicprofileError = true;
      this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }else  if(response.update_profile=='1092'){
      this.bacicprofileError = true;
      this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }else  if(response.update_profile=='1093'){
      this.bacicprofileError = true;
      this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }else  if(response.update_profile=='1094'){
      this.bacicprofileError = true;
      this.errorMessage = ' انتهت صلاحية كلمة المرور المؤقتة ';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }
     }else if(response.Token_Status=='1120'){
      this.bacicprofileError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.bacicprofileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.bacicprofileError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.bacicprofileError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }
}

otpBack(){
  this.PersonalFormHide=true;
  this.otpShow=false;
}
otpBack1(){
  this.BankDetHide=true;
  this.bankotpShow=false;
}

otpBack2(){
  this.BasicInfoHide=true; 
  this.basicotpShow=false;
}


}

