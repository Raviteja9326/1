
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ArabicRoutingModule } from './arabic-routing.module';
import {MatCardModule} from '@angular/material/card';
import {MatDividerModule} from '@angular/material/divider'; 
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatRadioModule} from '@angular/material/radio';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import { DeviceDetectorModule, DeviceDetectorService } from 'ngx-device-detector';

import { RecaptchaModule,RecaptchaFormsModule, RECAPTCHA_SETTINGS, RecaptchaSettings } from 'ng-recaptcha';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule,NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { MaindashboardComponent } from './maindashboard/maindashboard.component';
import { DashboardComponent, DocumentComponent } from './dashboard/dashboard.component';
import {MatTableModule} from '@angular/material/table';
import { AllfundsComponent } from './allfunds/allfunds.component';
import {MatTabsModule} from '@angular/material/tabs';

import { OpportunitieslistComponent,DeleteComponent } from './opportunitieslist/opportunitieslist.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ReceivableComponent } from './receivable/receivable.component';
import { TransactionComponent } from './transaction/transaction.component';
import { InvestmentComponent } from './investment/investment.component';
import { InvestmentcritieriaComponent } from './investmentcritieria/investmentcritieria.component';
import { ProfileComponent } from './profile/profile.component';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';
import { AralertComponent } from './aralert/aralert.component';
// import { RegisterComponent } from 'src/app/auth/register/register.component';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { AuthService } from 'src/app/services/auth.service';
import { ArabicComponent } from './arabic.component';


@NgModule({
  declarations: [ MaindashboardComponent, AllfundsComponent,DeleteComponent,ArabicComponent,DocumentComponent,
    OpportunitieslistComponent, ReceivableComponent, TransactionComponent, InvestmentComponent, InvestmentcritieriaComponent, ProfileComponent, ManageaccountComponent, AralertComponent],
  imports: [
    CommonModule,
    ArabicRoutingModule,
MatCardModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatTableModule,
    FormsModule,
    NgbModule,
    NgbDatepickerModule,
    DeviceDetectorModule,
    MatDividerModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    MatDatepickerModule,
    MatRadioModule,
    MatCardModule,MatNativeDateModule,
    MatSelectModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    MatProgressBarModule,
  
  ],
  providers:[ {
    provide:RECAPTCHA_SETTINGS,
    useValue:{siteKey:'6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI'} as RecaptchaSettings
  },
  DeviceinfoserviceService,
  DeviceDetectorService,
  AuthService

],
entryComponents:[AralertComponent,
  DeleteComponent,
  DocumentComponent
],
schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ArabicModule { }
