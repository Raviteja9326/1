import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog } from '@angular/material/dialog';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-allfunds',
  templateUrl: './allfunds.component.html',
  styleUrls: ['./allfunds.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class AllfundsComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol','status','product'];

  displayedColumns1: string[] = ['position', 'name', 'weight', 'symbol','status','product'];
 
  displayedColumns2: string[] = ['position', 'name', 'weight', 'symbol','status','product'];

  deviceInfo: any;
  tokenmessage = 'لقد انتهت جلستك ، يرجى تسجيل الدخول من هنا';
  accesstoken: any;
  FundsList: any;
  errorMessage: string;
  fundsError: boolean;
  data: any;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private dialog:MatDialog,private refresh :RefreshtokenService,private router:Router,
    private deviceService: DeviceDetectorService,private spinnerfull: NgxSpinnerService) {

      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
     const object1:any={}
     object1['index']='0'
     this. GetActiveFunds(object1);
     }

  ngOnInit(): void {
  
  }

 
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log(this.deviceInfo)
  }
  GetActiveFunds(tab){
   
    this.detectDevice();
// console.log(tab)
const object: any = {}
if(tab.index=='0'){
  object['fund_type']='ActiveFunds'
}else if(tab.index=='1'){
  object['fund_type']='SuccessfulFunds'
}else if(tab.index=='2'){
  object['fund_type']='RejectedFunds'
}

   
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    //object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
    object['page_number'] = '0'
    object['page_size'] = '20';
   
    object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
  //  console.log(object)
   this.spinnerfull.show()
    this.authService.getactiveFunds(object,this.accesstoken).subscribe(response=>
      this.getActiveFundsRes(response))
  }
  
  getActiveFundsRes(response){
     console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
      if(response.all_funds_status=='1126'){
        this.FundsList=response.all_funds_list;

      }else if(response.all_funds_status=='1127'){
        this.fundsError = true;
        this.errorMessage = 'القائمة غير متاحة';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1002'){
        this.fundsError = true;
  this.errorMessage = 'حدث خطا ما';
  setTimeout(() => {
    this.fundsError = false;
  }, 3000);
      }else if(response.all_funds_status=='1003'){
        
      }else if(response.all_funds_status=='1004'){
        
      }else if(response.all_funds_status=='1005'){
        
      }else if(response.all_funds_status=='1006'){
        
      }else if(response.all_funds_status=='1007'){
        
      }else if(response.all_funds_status=='1008'){
        
      }else if(response.all_funds_status=='1009'){
        
      }else if(response.all_funds_status=='1010'){
        
      }else if(response.all_funds_status=='1011'){
        
      }else if(response.all_funds_status=='1012'){
        
      }else if(response.all_funds_status=='1015'){
        
      }else if(response.all_funds_status=='1016'){
        this.fundsError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.fundsError = false;
      }, 3000);
      }else if(response.all_funds_status=='1150'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1151'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1152'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1153'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1154'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1155'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }
    }else  if(response.Token_Status=='1120'){
      this.fundsError = true;
     // this.errorMessage = 'غير مصرح';
      setTimeout(() => {
        this.fundsError = false;

        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }else  if(response.Token_Status=='1121'){
      this.fundsError = true;
     
    //  this.errorMessage = 'انتهت صلاحية الرمز';
      setTimeout(() => {
        this.fundsError = false;
        this.refresh.unAuthorizeArabic(this.tokenmessage)
        this.router.navigate(['/arhome'])
        sessionStorage.clear()
      }, 3000);
    }
  }
}
