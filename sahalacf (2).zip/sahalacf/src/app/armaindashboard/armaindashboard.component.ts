import { Component, OnInit ,ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-armaindashboard',
  templateUrl: './armaindashboard.component.html',
  styleUrls: ['./armaindashboard.component.scss'],
  encapsulation:ViewEncapsulation.Emulated
})
export class ArmaindashboardComponent implements OnInit {
  sign= false;

  constructor() { }

  ngOnInit(): void {
  }

  register() { 
   
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  
}

}
