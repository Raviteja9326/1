import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArmaindashboardComponent } from './armaindashboard.component';

describe('ArmaindashboardComponent', () => {
  let component: ArmaindashboardComponent;
  let fixture: ComponentFixture<ArmaindashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArmaindashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArmaindashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
