import { TestBed } from '@angular/core/testing';

import { SmeborrowerService } from './smeborrower.service';

describe('SmeborrowerService', () => {
  let service: SmeborrowerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SmeborrowerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
