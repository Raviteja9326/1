import { Injectable } from '@angular/core';
import {User,ForgotUser} from '../Models/user';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  source$ :any;
  totalcount=0;
  baseUrl: any;
  getipaddress: Observable<Object>;
  constructor(private router: Router,
    private http: HttpClient) { 
      this.baseUrl = environment.baseUrl;
    }


    public getIPAddress()  

    {  
  this.getipaddress = this.http.get("http://api.ipify.org/?format=json");
      return this.getipaddress
    }  




    RegistrationDetails(value,email,password) {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + btoa(email+ ':' + password)
  
        })
      };
      return this.http.post(this.baseUrl+'v1/register/investorORsme',value,httpOptions);
    }
    submitInvesterInfo(object,accesstoken){
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        })
  
      };
  
      return this.http.post(this.baseUrl+'v1/register/investor/info/otp',object,httpOptions);
    }
    submitInvesterInfoOtp(object,accesstoken){
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        })
  
      };
      return this.http.post(this.baseUrl+'v1/register/investor/info/verify/otp',object,httpOptions);
    }

    investorYourInfo(object,accesstoken){
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        })
  
      };
      return this.http.post(this.baseUrl+'v1/register/investor/yourInfo',object,httpOptions);
    }
    incomeInformationSubmit(object,accesstoken){
      
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        })
  
      };
      return this.http.post(this.baseUrl+'v1/register/investor/incomeInfo',object,httpOptions);
    }
    bankinformation(data,accesstoken) {
     
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        })
  
      };
      return this.http.post<any>(this.baseUrl+'v1/register/bankinfo',data,httpOptions)
         }
  
         uploadbankletter(list,accesstoken) {
  
        
          const httpOptions = {
            headers: new HttpHeaders({
              //'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + accesstoken
            })
      
          };
      
          return this.http.post<any>( this.baseUrl+'v1/register/investor/uploadBankAccountLetter',list,httpOptions)
        }
        dashBoardDetails(data,accesstoken){
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + accesstoken
            })
      
          };
          return this.http.post<any>( this.baseUrl+'v1/web/investor/dashboard',data,httpOptions)
        }

      isauthenticated(user:User,eamil,password) :Observable<any> {

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa(eamil+ ':' + password)
          })
    
        }

     return this.http.post<any>( this.baseUrl+'v1/login/password',user,httpOptions)
      }

      loginotpverified(user:User):Observable<any>{
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa(user.email + ':' + user.password)
          })
    
        }

        return this.http.post<any>( this.baseUrl+'v1/login/otp',user,httpOptions)
      }

      forgotpassword(forgo:ForgotUser):Observable<any>{

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa(forgo.email)
          })
    
        }
        return this.http.post<any>( this.baseUrl+'v1/forget/password/otp',forgo,httpOptions)

      }

      forgotpasswordotp(forgo:ForgotUser):Observable<any> {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa(forgo.email + ':' + forgo.otp)
          })
    
        }

        return this.http.post<any>( this.baseUrl+'v1/forget/password/otp/verify',forgo,httpOptions)
      }



      getinvestersdashdoc(dat,accesstoken):Observable<any> {
        const httpOptions = {
          headers: new HttpHeaders({
            // 'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>( this.baseUrl+'v1/web/investor/getDocuments',dat,httpOptions)
      }

      UpadteProfile(list,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            // 'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>( this.baseUrl+'v1/profile/uploadImage',list,httpOptions)
      }

      updatePasswordOtp(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/profile/password/otp',data,httpOptions)
      }

      VerifyOtpUpdatePassword(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/profile/password/update',data,httpOptions)
      }

      GetbasicProfile(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/profile/basicProfile',data,httpOptions)
      }

      
      GetPersonalProfile(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/profile/investor/personalProfile',data,httpOptions)
      }

      GetBankDetails(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/profile/investor/getBankDetails',data,httpOptions)
      }

      UpdatePersonalProfile(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/update/personalProfile/otp',data,httpOptions)
      }

      updateprofile(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/update/personalProfile',data,httpOptions)
      }

      updateBankDetailsOtp(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/update/bankInfo/Otp',data,httpOptions)
      }

      updateBankDetails(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/update/bankInfo',data,httpOptions)
      }

      updateBasicInfoOtp(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/profile/update',data,httpOptions)
      }

      basicInfoOtpSubmit(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/profile/updateMobile',data,httpOptions)
      }

      recentOportunitiesSubmit(data,accesstoken){ 
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/investor/recentOpportunities',data,httpOptions)
      }
      recentClosedOportunites(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/investor/recentClosedOpportunities',data,httpOptions)
      }
      getactiveFunds(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/investor/allFunds',data,httpOptions)
      }
      getInvestements(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/investor/recentInvestments',data,httpOptions)
      }
    

      investorInvoiceInformation(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/register/sme/invoiceInfo',data,httpOptions)
      }

      companyDetailsSubmit(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/register/sme/companyInformation',data,httpOptions)
      }


      smeuploadDocuments(list,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
           // 'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
     
        };
        return this.http.post<any>(this.baseUrl+'v1/register/sme/uploadDocuments',list,httpOptions)
      }

      GetInvestementCrituera(data,accesstoken){
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
        return this.http.post<any>(this.baseUrl+'v1/web/investor/investmentsCriteria',data,httpOptions)
      }


      public getObservable(value) {
        this. source$ = new BehaviorSubject<number>(value);
        this.totalcount=this.totalcount+1;
       
        if(this.totalcount ==1){
            setInterval(() => {
           const newVal = this.source$.getValue() - 1;
      //  console.log(newVal)
           if(newVal > -1){
           this.source$.next(newVal);
          
           }
         }, 
         
         1000);
         } if(this.totalcount == 2){
           setInterval(() => {
             const newVal = this.source$.getValue() - 1;
         
             if(newVal > -1){
             this.source$.next(newVal);
            
             }
           }, 
           
           132000);
         }
         if(this.totalcount == 3){
           setInterval(() => {
             const newVal = this.source$.getValue() - 1;
         
             if(newVal > -1){
             this.source$.next(newVal);
            
             }
           }, 
           
           176000);
         } if(this.totalcount == 4){
           setInterval(() => {
             const newVal = this.source$.getValue() - 1;
         
             if(newVal > -1){
             this.source$.next(newVal);
            
             }
           }, 
           
           220000);
         } if(this.totalcount == 5){
          
           setInterval(() => {
             const newVal = this.source$.getValue() - 1;
         
             if(newVal > -1){
             this.source$.next(newVal);
            
             }
           }, 
           
           32000);
         }
         if(this.totalcount == 6){
          
           setInterval(() => {
             const newVal = this.source$.getValue() - 1;
         
             if(newVal > -1){
             this.source$.next(newVal);
            
             }
           }, 
           
           42000);
         }
         return this.source$.asObservable();
       }
    


       logout(obj,accesstoken):Observable<any>{

       const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        })
  
      };

       return this.http.post<any>(this.baseUrl+'v1/logout',obj,httpOptions)
       }

       alertinvesmobile(obj,accesstoken) {
        const httpOptions = {
         headers: new HttpHeaders({
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + accesstoken
         })
    
       };
 
        return this.http.post<any>(this.baseUrl+'v1/verify/investor/mobile/otp',obj,httpOptions)
      }

 

       alertmobile(obj,accesstoken) {
        const httpOptions = {
         headers: new HttpHeaders({
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + accesstoken
         })
   
       };
 
        return this.http.post<any>(this.baseUrl+'v1/verify/mobile/otp',obj,httpOptions)
      }

      alertemail(obj,accesstoken) {
        const httpOptions = {
         headers: new HttpHeaders({ 
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + accesstoken
         })
   
       };
 
        return this.http.post<any>(this.baseUrl+'v1/verify/email/otp',obj,httpOptions)
      }
      

      alertinvesotpverify(obj,accesstoken){
        const httpOptions = {
         headers: new HttpHeaders({
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + accesstoken
         })
   
       };
 
        return this.http.post<any>(this.baseUrl+'v1/verify/investor/mobile/verifyOTP',obj,httpOptions)
      }
    
      alertotpverify(obj,accesstoken){
        const httpOptions = {
         headers: new HttpHeaders({
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + accesstoken
         }) 
   
       };
  
        return this.http.post<any>(this.baseUrl+'v1/verify/mobile',obj,httpOptions)
      }

      alertotpemailverify(obj,accesstoken){
        const httpOptions = {
         headers: new HttpHeaders({
           'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + accesstoken
         })
   
       };
 
        return this.http.post<any>(this.baseUrl+'v1/verify/email',obj,httpOptions)
      }


      submitShareHolderInfo(accesstoken,obj){
        const httpOptions = {
          headers: new HttpHeaders({
             'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accesstoken
          })
    
        };
  
         return this.http.post<any>(this.baseUrl+'v1/register/shareholderInfo',obj,httpOptions)
      }




getallopportunities(accesstoken,obj): Observable<any> {
  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };

return this.http.post<any>(this.baseUrl+'v1/web/investor/allOpportunities',obj,httpOptions)



}


getbalanceinfo(accesstoken,data) :Observable<any> {
  
  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };

return this.http.post<any>(this.baseUrl+'v1/profile/balance',data,httpOptions)
}


investamount(accesstoken,obj):Observable<any> {
  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };


  return this.http.post<any>(this.baseUrl+'v1/invest/doInvestment',obj,httpOptions)

}



getpendingtransactions(accesstoken,obj) {

  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };


  return this.http.post<any>(this.baseUrl+'v1/web/investor/pendingTransactions',obj,httpOptions)


}





getapprovedtransactions(accesstoken,obj) {

  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };


  return this.http.post<any>(this.baseUrl+'v1/web/investor/approvedTransactions',obj,httpOptions)


}

getreceivables(accesstoken,obj):Observable<any> {

  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };
 

  return this.http.post<any>(this.baseUrl+'v1/web/investor/receivables',obj,httpOptions)


}


requestwithdrawalintial(accesstoken,obj):Observable<any> {
  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };


  return this.http.post<any>(this.baseUrl+'v1/withdrawl/initiate',obj,httpOptions)

}



requestwithdrawalprocess(accesstoken,obj):Observable<any> {
  const httpOptions = {
    headers:new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    })

  };

  return this.http.post<any>(this.baseUrl+'v1/withdrawl/process',obj,httpOptions)

}



uploadsmeprofiledoc(obj,accesstoken) {


  const httpOptions = {
    headers: new HttpHeaders({
     // 'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    }),
  }
  return this.http.post<any>( this.baseUrl+'v1/web/profile/sme/uploadDocuments',obj,httpOptions)
}



uploadsmedashboarddocuments(obj,accesstoken) :Observable<any> {
console.log(obj)
  const httpOptions = {
    headers: new HttpHeaders({
     // 'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + accesstoken
    }),
  }
  return this.http.post<any>( this.baseUrl+'v1/dashboard/uploadDocument',obj,httpOptions)
}


uploadinvesterdashboarddocuments(obj,accesstoken) :Observable<any> {
  console.log(obj)
    const httpOptions = {
      headers: new HttpHeaders({
       // 'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }
    return this.http.post<any>( this.baseUrl+'v1/dashboard/investor/uploadDocument',obj,httpOptions)
  }

  uploadinvestorprofiledocuments(obj,accesstoken) :Observable<any> {
    console.log(obj)
      const httpOptions = {
        headers: new HttpHeaders({
         // 'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        }),
      }
      return this.http.post<any>( this.baseUrl+'v1/web/profile/investor/uploadDocuments',obj,httpOptions)
    }

 accept:any;

    Accepttermsandpolicy(accesstoken):Observable<any> {
      console.log(accesstoken)
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + accesstoken
        }),
      }
      return this.http.post<any>( this.baseUrl+'v1/acceptTermsConditions',this.accept,httpOptions)



    }


}





