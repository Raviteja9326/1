import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SmeborrowerService {
  baseUrl: string;

  constructor(private http:HttpClient) {
    this.baseUrl = environment.baseUrl;
   }

  getsmedashboard(object,accesstoken):Observable <any>{

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }

    return this.http.post<any>( this.baseUrl+'v1/sme/dashboard/documents',object,httpOptions)

  }

  getdashboardfeilds(obj,accesstoken):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }
    return this.http.post<any>( this.baseUrl+'v1/sme/dashboard',obj,httpOptions)

  }

  getloantable(obj,accesstoken):Observable<any>{
   // console.log(accesstoken)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }), 
    }

      return this.http.post<any>( this.baseUrl+'v1/sme/myloans',obj,httpOptions)
    
  }

  getCompanyInformation(obj,accesstoken){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }
    return this.http.post<any>( this.baseUrl+'v1/profile/getCompanyInformation',obj,httpOptions)
  }

  updatecompanyotp(obj,accesstoken) :Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }

    return this.http.post<any>( this.baseUrl+'v1/web/profile/sme/companyInfo/otp',obj,httpOptions)

  }

  updatecompanyotpverified(obj,accesstoken):Observable<any>{

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }

    return this.http.post<any>( this.baseUrl+'v1/web/profile/sme/companyInfo/update',obj,httpOptions)
  }

  getloaniddetails(obj,accesstoken) : Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      }),
    }
    return this.http.post<any>( this.baseUrl+'v1/sme/fundingDetails',obj,httpOptions)
  }

 

  refreshToken(accesstoken) :Observable<any> {

    const object:any = {}
    console.log(accesstoken)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accesstoken
      })
    }


    return this.http.post<any>( this.baseUrl+"v1/login/refreshtoken",object,httpOptions);
  }


  
}
