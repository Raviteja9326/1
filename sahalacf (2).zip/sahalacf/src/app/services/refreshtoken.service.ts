import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RefreshtokenService {

  source$ :any;
  totalcount=0;
  public first1: boolean;
  public first2:boolean = false;
  public first3:boolean = false;
  public firstx:boolean = false;
  public first4:boolean = false;
  public first5:boolean = false;
  public first6:boolean = false;
  public first7:boolean = false;
  sessiondata : any;
  constructor() { }
 

  private messageSource = new BehaviorSubject('default message');
  currentMessage = this.messageSource.asObservable();

  private balancesrc = new BehaviorSubject('default message');
  balanceammount = this.balancesrc.asObservable();


  private Docsuccess = new BehaviorSubject('default message');
  document = this.Docsuccess.asObservable();

  private sessionsrc = new BehaviorSubject('default message');
  sessiontime = this.sessionsrc.asObservable();

  private unauthirize = new BehaviorSubject('default token');
  unauthmsg = this.unauthirize.asObservable();

  
  private unarauthirize = new BehaviorSubject('default arabictoken');
  unArauthmsg = this.unarauthirize.asObservable();


  changeMessage(message: any) {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentsessiondata'))

   console.log(message)
    this.messageSource.next(message) 


    const object:any ={}

    object['FirstName']  = this.sessiondata.FirstName;
    object['LastName']     = this.sessiondata.LastName;
    object['LastLogin']    = this.sessiondata.LastLogin;
    object['isMobileVerified']   = this.sessiondata.isMobileVerified;
    object['isEmailVerified']   = this.sessiondata.isEmailVerified;
    object['accesstoken']   = message.token;
    object['ProfilePic'] = this.sessiondata.ProfilePic;
    object['id']=this.sessiondata.id
    object['profileStatus']=this.sessiondata.profileStatus;
    if(this.sessiondata.isCompnayInformationProvided   &&  this.sessiondata.isDcoumentsInformationProvided) {
     object['redirect'] = this.sessiondata.redirect;
     object['isBankInformationProvided']    = this.sessiondata.isBankInformationProvided;
     object['isCompnayInformationProvided']    = this.sessiondata.isCompnayInformationProvided;
     object['isDcoumentsInformationProvided']   = this.sessiondata.isDcoumentsInformationProvided;
     object['isShareHolderInformationProvided'] = this.sessiondata.isShareHolderInformationProvided;
     object['isPolicyAccepted'] = this.sessiondata.isPolicyAccepted;
     object['isTermsAccepted'] = this.sessiondata.isTermsAccepted;
    }

    else {
     object['redirect'] = this.sessiondata.redirect;
     object['isPolicyAccepted']  = this.sessiondata.isPolicyAccepted;
     object['isBankInfoProvided']   = this.sessiondata.isBankInfoProvided;
     object['isInvestorInfoProvided']  = this.sessiondata.isInvestorInfoProvided;
     object['isTermsAccepted']  = this.sessiondata.isTermsAccepted;
     object['isBankAccountLetterUploaded'] = this.sessiondata.isBankAccountLetterUploaded;
    }
 

    sessionStorage.setItem('currentUser',JSON.stringify(object))

  }
 


  changeMessagereg(message: any) {

    this.sessiondata = JSON.parse(sessionStorage.getItem('currentsessiondata'))

   console.log(message)
    this.messageSource.next(message) 

    
  }
 
  changebalance(balance:any) {
    console.log(balance);
    this.balancesrc.next(balance)


    

  }

  getsession(balance:any) {
    console.log(balance);
    this.sessionsrc.next(balance)
  }

  unAuthorize(engauth:any) {

    console.log(engauth)

    this.unauthirize.next(engauth)
  }


  unAuthorizeArabic(arauth:any) {

    console.log(arauth)

    this.unarauthirize.next(arauth)
  }



  getdocsuccess(doc:any) {
    console.log(doc);
    this.Docsuccess.next(doc)


    

  }

  public getObservable(value) {
    this. source$ = new BehaviorSubject<number>(value);
    this.totalcount=this.totalcount+1;
   
    if(this.totalcount ==1){
        setInterval(() => {
       const newVal = this.source$.getValue() - 1;
  //  console.log(newVal)
       if(newVal > -1){
       this.source$.next(newVal);
      
       }
     }, 
     
     1000);
     } if(this.totalcount == 2){
       setInterval(() => {
         const newVal = this.source$.getValue() - 1;
     
         if(newVal > -1){
         this.source$.next(newVal);
        
         }
       }, 
       
       132000);
     }
     if(this.totalcount == 3){
       setInterval(() => {
         const newVal = this.source$.getValue() - 1;
     
         if(newVal > -1){
         this.source$.next(newVal);
        
         }
       }, 
       
       176000);
     } if(this.totalcount == 4){
       setInterval(() => {
         const newVal = this.source$.getValue() - 1;
     
         if(newVal > -1){
         this.source$.next(newVal);
        
         }
       }, 
       
       220000);
     } if(this.totalcount == 5){
      
       setInterval(() => {
         const newVal = this.source$.getValue() - 1;
     
         if(newVal > -1){
         this.source$.next(newVal);
        
         }
       }, 
       
       32000);
     }
     if(this.totalcount == 6){
      
       setInterval(() => {
         const newVal = this.source$.getValue() - 1;
     
         if(newVal > -1){
         this.source$.next(newVal);
        
         }
       }, 
       
       42000);
     }
     return this.source$.asObservable();
   }


}