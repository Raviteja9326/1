import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';


@Injectable({
  providedIn: 'root'
})
export class AuthguardGuard implements CanActivate {
  currentUser: any;
  expectedRoleArray: any;
  expectedRole: any;
  constructor(private router:Router){

  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
      this. expectedRoleArray = route.url
      this. expectedRoleArray = this.expectedRoleArray[0].path


        // if(this.expectedRole == 'englishwebapp') {
        // console.log('nabayu')
        //   if(this.expectedRoleArray == 'englishwebapp') {

        //     console.log("Roles Matched");
        //  this. expectedRole = this.currentUser.redirect;
        
        //   }
        
        // }

        //   if(this.expectedRole == 'arabicwebapp') {
        //     console.log('na')
        //   if(this.expectedRoleArray == 'englishwebapp') {
        //     console.log("Roles Matched");
        //  this. expectedRole = this.currentUser.redirect;
        
        //   }
        
        // }


        if(this.expectedRoleArray == this.currentUser.redirect){
         this. expectedRole = this.currentUser.redirect;
        
        
        }
        
  
      

        if(this.expectedRole == 'englishwebapp') {
        
          if(this.expectedRoleArray == 'englishwebsmeapp') {
  
    
            this.router.navigate(['/home'])
          }
        
        }
        if(this.expectedRole == 'englishwebsmeapp') {
        
          if(this.expectedRoleArray == 'englishwebapp') {
  
    
            this.router.navigate(['/home'])
          }
        
        }

        
      

        if(this.expectedRole == 'arabicwebapp') {
        
          if(this.expectedRoleArray == 'arabicwebsmeapp') {
  
    
            this.router.navigate(['/arhome'])
          }
        
        }
        if(this.expectedRole == 'arabicwebsmeapp') {
        
          if(this.expectedRoleArray == 'arabicwebapp') {
  
    
            this.router.navigate(['/arhome'])
          }
        
        }
       
        
        // && this.currentUser.redirect == this.expectedRole
      
        if (sessionStorage.getItem('currentUser') && this.currentUser.redirect == this.expectedRole) {
         
       
          
          return true;
        }
        return false;
    

  }
  
}
