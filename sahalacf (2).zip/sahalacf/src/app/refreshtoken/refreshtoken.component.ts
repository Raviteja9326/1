import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SmeborrowerService } from '../services/smeborrower.service';
import { BnNgIdleService } from 'bn-ng-idle';
import { MatDialog } from '@angular/material/dialog';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-refreshtoken',
  templateUrl: './refreshtoken.component.html',
  styleUrls: ['./refreshtoken.component.scss']
})
export class RefreshtokenComponent implements OnInit {
  data: any;
  accesstoken: any;
  subscription:Subscription;
  constructor(private router: Router,private bnIdle: BnNgIdleService, public dialog: MatDialog,
    private sme :SmeborrowerService,private service:SmeborrowerService) {
     
     
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
console.log(this.data)
   
this.getdata()
      const source = interval(200);
     
          this.subscription = source.subscribe(val =>
           //  this.callingrefreshtoken()
            
          console.log('refresh')
            );
    


    }



  ngOnInit(): void {
  }

  getdata(){
    console.log(this.data)
  }

}
 