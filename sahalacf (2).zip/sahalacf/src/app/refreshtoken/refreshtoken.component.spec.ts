import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RefreshtokenComponent } from './refreshtoken.component';

describe('RefreshtokenComponent', () => {
  let component: RefreshtokenComponent;
  let fixture: ComponentFixture<RefreshtokenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RefreshtokenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RefreshtokenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
