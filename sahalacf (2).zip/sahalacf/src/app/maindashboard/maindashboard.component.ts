import { Component, OnInit ,ViewEncapsulation} from '@angular/core';
declare var $ :any;
@Component({
  selector: 'app-maindashboard',
  templateUrl: './maindashboard.component.html',
  styleUrls: ['./maindashboard.component.scss'],
  encapsulation:ViewEncapsulation.Emulated
})
export class MaindashboardComponent implements OnInit {
  sign: boolean;

  constructor() { }

  ngOnInit(): void {

    $('linktext').on("click",function() {
      $('body').scrollTop(0)
    })

    //console.log(sessionStorage.getItem('loginuserdata'))
  }

  register() {
   
      this.sign = !this.sign;
      if(this.sign){
      this.sign = true;
      } else {
        this.sign = false;
      }
    
  }

}
