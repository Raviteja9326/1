import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-maindashboard',
  templateUrl: './maindashboard.component.html',
  styleUrls: ['./maindashboard.component.scss']
})
export class MaindashboardComponent implements OnInit {

  user
  ;
  name;
  secname;
  todaydate  = new Date();
    bobdattt: string;
  iqamaId: any;
    constructor(private router:Router) { 
  
  
      this.user = JSON.parse(sessionStorage.getItem('currentUser'))
      this.name = this.user.FirstName;
      this.secname = this.user.LastName;
      this.iqamaId = this.user.iqamaId;
  
  
  
  
  
    }
  
    ngOnInit() {
  this.gettodaydate();
  
    }
  
    dashboard(){
  this.router.navigate(['/arabicwebapp/webappdashboard'])
    }
  
  gettodaydate() {
    
    var d = new Date(this.todaydate),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
  
  if (month.length < 2) 
    month = '0' + month;
  if (day.length < 2) 
    day = '0' + day;
  
    this.bobdattt = [day, month, year].join('/')
  
  }
  

}






