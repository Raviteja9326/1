import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MaindashboardComponent } from './maindashboard/maindashboard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AllfundsComponent } from './allfunds/allfunds.component';
import { OpportunitieslistComponent } from './opportunitieslist/opportunitieslist.component';

import { ReceivableComponent } from './receivable/receivable.component';
import { TransactionComponent } from './transaction/transaction.component';
import { InvestmentComponent } from './investment/investment.component';
import { InvestmentcritieriaComponent } from './investmentcritieria/investmentcritieria.component';
import { ProfileComponent } from './profile/profile.component';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';




const routes: Routes = [

  { path: 'webappmaindashboard', component: MaindashboardComponent },
  { path: 'webappdashboard', component: DashboardComponent },
  { path: 'webappoppotunities', component: OpportunitieslistComponent },
  {path: 'webappreceivable' , component: ReceivableComponent},
  {path: 'webapptransaction' , component: TransactionComponent},
  {path: 'webappinvestment' , component: InvestmentComponent},
  {path: 'weappinvestmentcritieria' , component: InvestmentcritieriaComponent},
  {path:'webappallfunds',component:AllfundsComponent},
  {path: 'profile' , component: ProfileComponent},
  {path:'manageAccount',component:ManageaccountComponent},
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ArabicRoutingModule { }
