import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvestmentcritieriaComponent } from './investmentcritieria.component';

describe('InvestmentcritieriaComponent', () => {
  let component: InvestmentcritieriaComponent;
  let fixture: ComponentFixture<InvestmentcritieriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvestmentcritieriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvestmentcritieriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
