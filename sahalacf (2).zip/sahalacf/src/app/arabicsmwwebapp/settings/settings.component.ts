import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { HttpClient } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NgxSpinnerService } from 'ngx-spinner';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, changepasswordForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = changepasswordForm && changepasswordForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

export const passwordMatchValidator: ValidatorFn = (changepasswordForm: FormGroup): ValidationErrors | null => {
  if (changepasswordForm.get('newapassword').value === changepasswordForm.get('reenternewPassword').value)
    return null;
  else
    return {passwordMismatch: true};
};
  
@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class SettingsComponent implements OnInit {

  changepasswordForm:FormGroup;
  hide = true;
  hide1 = true; 
  hide2 = true;
  hidePassword=true;
  uploadprofleForm:FormGroup
  ErrorMsg: string;
  msgError: boolean;
  responseMessgae: string;
  registError: boolean;
  acesstoken: any;
  deviceInfo: any;
  responseUpdatePasswordMessgae: string;
  otpForm:FormGroup
  otperror: string;
  otpShow: boolean;
  userdata;
  
  data: any;
  submitted: boolean;
  profileimage: string;
  UpdatePasswordsuccMessgae: string;
  updtpasssucess: boolean;
  UpdatePassworderrMessgae: string;
  updtpassError: boolean;
  imageerr: string;
  imgError: boolean;
  uploadsucess: boolean;
  uploadprofile: string;
  uploadfailue: boolean;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private spinnerfull: NgxSpinnerService,

    private http: HttpClient, private deviceService: DeviceDetectorService) {

      this.userdata = JSON.parse(sessionStorage.getItem('currentUser'))
      this.acesstoken  = this.userdata.accesstoken;

   }

 

   get oldPassword() { return this.changepasswordForm.get('oldPassword'); }
   get newapassword() { return this.changepasswordForm.get('newapassword'); }
   get reenternewPassword() { return this.changepasswordForm.get('reenternewPassword'); }

   get o(){return this.otpForm.controls}
  ngOnInit() {

    this.changepasswordForm = this.fb.group({
      oldPassword :['',[Validators.required, Validators.minLength(8), Validators.maxLength(20)]],
      newapassword:['',[Validators.required, Validators.minLength(8), Validators.maxLength(20)]],
      reenternewPassword:['',[Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
    },
    {
      validator: passwordMatchValidator
    });
    this.uploadprofleForm=this.fb.group({
      uploadProfile: [''],
 });
 this.otpForm=this.fb.group({
  otp: ['',[Validators.required,Validators.minLength(8), Validators.maxLength(8), Validators.pattern("^[A-za-z0-9]*$")]],
});
  }

  onPasswordInput() {
    if (this.changepasswordForm.hasError('passwordMismatch'))
      this.reenternewPassword.setErrors([{'passwordMismatch': true}]);
    else
      this.reenternewPassword.setErrors(null);
  }


  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadprofleForm.get('uploadProfile').setValue(file);
    }
  } 
  UpdateProfile(){
    
    if(this.uploadprofleForm.value.uploadProfile != '' && this.uploadprofleForm.value.uploadProfile != '') {

      this.msgError = false;
      const formData = new FormData();
      formData.append('file',this.uploadprofleForm.get('uploadProfile').value);
      formData.append('attachement',this.uploadprofleForm.value.uploadProfile);
      formData.append('deviceid',this.deviceinfoservice.deviceinfo.deviceId);
      formData.append('devicetype',this.deviceinfoservice.deviceinfo.deviceType);
      formData.append('ipaddress',this.deviceinfoservice.deviceinfo.ipAdress),
      formData.append('latitude',this.deviceinfoservice.deviceinfo.latitude);
      formData.append('longitude',this.deviceinfoservice.deviceinfo.logintude);

     this.authService.UpadteProfile(formData,this.acesstoken).subscribe(response=>{
      this.updateProfileResponse(response)})
     

    }else{
      this.imageerr="Please Select Image"
      this.imgError = true;
      setTimeout(() => {
        this.imgError = false;
      }, 3000)
    }
  }
 
  updateProfileResponse(response){
    // console.log(response)
    if(response.Token_Status=='1119'){

      if(response.Upload_Image_Response=='1000'){
      // this.profileimage='https://images.sahlahcf.com/profile_images/bc77984251bb462ea50540bada3293a5.jpg'
      this.profileimage=response.Profile_Pic;
       this.uploadprofile="Profile Image Uploaded SucessFFully"
       this.uploadsucess = true;
       setTimeout(() => {
         this.uploadsucess = false;
       }, 3000)
      }else if(response.Upload_Image_Response=='1001'){
        this.responseMessgae = "FAILURE";
      
        this.uploadfailue = true;
        setTimeout(() => {
          this.uploadfailue = false;
        }, 3000)
      }else {
        this.responseMessgae = "FAILURE";
      
        this.uploadfailue = true;
        setTimeout(() => {
          this.uploadfailue = false;
        }, 3000)
      }

    }else if(response.Token_Status=='1120'){
      this.responseMessgae = "UNAUTHORIZED";
      
      this.uploadfailue = true;
      setTimeout(() => {
        this.uploadfailue = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
      this.responseMessgae = "TOKEN_EXPIRED";
      
      this.uploadfailue = true;
      setTimeout(() => {
        this.uploadfailue = false;
      }, 3000)
    }
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }
  UpdatePassword(){
   
    this.changepasswordForm.get('reenternewPassword').markAsTouched();
    this.changepasswordForm.get('oldPassword').markAsTouched();
    this.changepasswordForm.get('newapassword').markAsTouched();
   
    if(this.changepasswordForm.valid) {
      this.detectDevice();
const object:any={}
object['browserType'] = this.deviceInfo.browser;
object['browserVersion'] = this.deviceInfo.browser_version;
object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
object['osVersion'] = this.deviceInfo.os_version;
object['osType'] = this.deviceInfo.os;
object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
object['language'] = 'en';
 object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
 object['oldPassword']=this.changepasswordForm.value.oldPassword
 object['newPassword']=this.changepasswordForm.value.newapassword
 object['conformPassword']=this.changepasswordForm.value.reenternewPassword
 this.spinnerfull.show()
this.authService.updatePasswordOtp(object,this.acesstoken).subscribe(response=>
  this.updatePasswordOtpResponse(response))
    }
  }
  updatePasswordOtpResponse(response){
    // console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
if(response.Update_Password_Otp_Response=='1000'){
 
  this.hidePassword=false;
  this.otpShow=true;
}else if(response.Update_Password_Otp_Response=='1001'){
  this.responseUpdatePasswordMessgae = "FAILURE";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
}else if(response.Update_Password_Otp_Response=='1002'){
  this.responseUpdatePasswordMessgae = "SOMTHING WENT";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
}else if(response.Update_Password_Otp_Response=='1129'){
  this.responseUpdatePasswordMessgae = "OLD_PASSWORD_IS_INVALID";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
}
    }else if(response.Token_Status=='1120'){
      this.responseUpdatePasswordMessgae = "UNAUTHORIZED";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
      this.responseUpdatePasswordMessgae = "TOKEN_EXPIRED";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }
  }
  VerifyOtp(){
    this.submitted=true;
    if(this.otpForm.valid){
      const object:any={}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
       object['oldPassword']=this.changepasswordForm.value.oldPassword
       object['newPassword']=this.changepasswordForm.value.newapassword
       object['conformPassword']=this.changepasswordForm.value.reenternewPassword
       object['otp'] = this.otpForm.value.otp;
       this.spinnerfull.show()
       this.authService.VerifyOtpUpdatePassword(object,this.acesstoken).subscribe(response=>
        this.verifyOtpPasswordResponse(response))
    }else{
      this.otperror="Otp  Required"
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }
  }
  verifyOtpPasswordResponse(response){
    // console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
if(response.update_password_status=='1000'){
  this.changepasswordForm.reset();
 // alert("Passowrd Update SucessFully")
 
  this.UpdatePasswordsuccMessgae = "Password Updated SucessFully";
      
  this.updtpasssucess = true;
  setTimeout(() => {
    this.hidePassword=true;
    this.otpShow=false;
    this.otpForm.reset();
    this.updtpasssucess = false;
  }, 3000)
}else if(response.update_password_status=='1089'){
  this.UpdatePassworderrMessgae= "NEW_PASSOWRD_AND_CONFORM_PASSWORD_ARE_NOT_SAME";
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1090'){
  this.UpdatePassworderrMessgae= "OTP_IS_EMPTY"
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1091'){
  this.UpdatePassworderrMessgae= "Invalid Otp"
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1092'){
  this.UpdatePassworderrMessgae= "Invalid Otp"
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1093'){
  this.UpdatePassworderrMessgae= "OTP_IS_INVALID"
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1094'){
  this.UpdatePassworderrMessgae= "OTP EXPIRED"
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}
    }else if(response.Token_Status=='1120'){
      this.responseUpdatePasswordMessgae = "UNAUTHORIZED";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
 this.responseUpdatePasswordMessgae = "TOKEN_EXPIRED";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }
  }
  otpBack(){
    this.hidePassword=true;
    this.otpShow=false;
  }
}
