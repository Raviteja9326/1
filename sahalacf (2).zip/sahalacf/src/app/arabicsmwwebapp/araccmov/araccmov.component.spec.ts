import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AraccmovComponent } from './araccmov.component';

describe('AraccmovComponent', () => {
  let component: AraccmovComponent;
  let fixture: ComponentFixture<AraccmovComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AraccmovComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AraccmovComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
