import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArsettingsComponent } from './arsettings.component';

describe('ArsettingsComponent', () => {
  let component: ArsettingsComponent;
  let fixture: ComponentFixture<ArsettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArsettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArsettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
