import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatCardModule} from '@angular/material/card';
import {MatDividerModule} from '@angular/material/divider';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatRadioModule} from '@angular/material/radio';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import { DeviceDetectorModule, DeviceDetectorService } from 'ngx-device-detector';
import { RecaptchaModule,RecaptchaFormsModule, RECAPTCHA_SETTINGS, RecaptchaSettings } from 'ng-recaptcha';
import { HttpClientModule } from '@angular/common/http';
import { DeviceinfoserviceService } from '../shared/deviceinfoservice.service';
import { AuthService } from '../services/auth.service';
import { NgbModule,NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import {MatTableModule} from '@angular/material/table';

import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ArabicsmwwebappRoutingModule } from './arabicsmwwebapp-routing.module';
import { ArmyloansComponent } from './armyloans/armyloans.component';
import { AraccmovComponent } from './araccmov/araccmov.component';
import { ArdashComponent, DeleteComponent } from './ardash/ardash.component';
import { Arloan2Component } from './arloan2/arloan2.component';
import { ArprofileComponent } from './arprofile/arprofile.component';

import { MatTabsModule } from '@angular/material/tabs';
import { SmeborrowerService } from '../services/smeborrower.service';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';
import { AralertComponent } from './aralert/aralert.component';
import { MatDialogModule } from '@angular/material/dialog';



@NgModule({
  declarations: [ArmyloansComponent, AraccmovComponent, ArdashComponent, AralertComponent,DeleteComponent,Arloan2Component, ArprofileComponent, ManageaccountComponent],
  imports: [
    CommonModule,
    ArabicsmwwebappRoutingModule,
    MatCardModule,
    MatIconModule,
    MatFormFieldModule,
    MatButtonModule,
    MatInputModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatTableModule,
    FormsModule,
    MatDialogModule,
    NgbModule,
    NgbDatepickerModule,
    DeviceDetectorModule,
    MatDividerModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    MatDatepickerModule,
    MatRadioModule,
    MatCardModule,MatNativeDateModule,
    MatSelectModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    MatProgressBarModule
  ],
  providers: [
    AuthService,
    DeviceDetectorService,
    DeviceinfoserviceService,
    SmeborrowerService
  ],
  entryComponents:[
    AralertComponent,
    DeleteComponent
  ]
})
export class ArabicsmwwebappModule { }
