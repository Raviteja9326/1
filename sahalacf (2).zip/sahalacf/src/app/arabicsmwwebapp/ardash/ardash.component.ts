import { Component, OnInit } from '@angular/core';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { deviceinfo } from 'src/app/shared/models/deviceinfo.model';
import { getMatIconNameNotFoundError } from '@angular/material/icon';
import { SmeborrowerService } from 'src/app/services/smeborrower.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from '@angular/common/http';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AralertComponent } from '../aralert/aralert.component';
import { AuthService } from 'src/app/services/auth.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormBuilder } from '@angular/forms';

declare var Fingerprint2: any;
declare var $ :any;
@Component({
  selector: 'app-ardash',
  templateUrl: './ardash.component.html', 
  styleUrls: ['./ardash.component.scss']
})
export class ArdashComponent implements OnInit {
 
  value = 90;
  dataSource;
  displayedColumns =[];
  getDeviceId;
  deviceinfo: deviceinfo;
  deviceInfo;
  dateonwhichcondition;
  financingproduct;
  arrangementfee;
  grossprofitmargin;
  dateofexchange;
    termofpayment;
    annualprofit;
    issuedbill;
    paidammount
    thecontractapproved;
    fundingamount;
    userdata;
    fundingnumber;
    ipNumber;
    smedash;
    paymenytdue;
  ipAddress;
  upcome;
  errmsg;
  errmsg1;
  mgdis1;
  mgdis;
  fundamm;
  dashboarddetails=[];
  
accesstoken:any;
  ismobilealert: boolean;
  isemailverified: boolean;
  msgdis1: boolean;
  msgdis: boolean;
  list: any;
  user: any;
  registrationid: any;
  fundpercent: any;
  fundstatus: any;
  constructor(private deviceinfoservice:DeviceinfoserviceService,private sme :SmeborrowerService,
    public dialog: MatDialog,private authService:AuthService,
    private spinnerfull: NgxSpinnerService,
    private deviceService:DeviceDetectorService,private http:HttpClient) { 


      this.user = JSON.parse(sessionStorage.getItem('currentUser'))
      console.log(  this.user )
   
      //  this.name=this.user.FirstName
       this.registrationid=this.user.id

      this.userdata =JSON.parse( sessionStorage.getItem('currentUser'));
      if(this.userdata!=null || this.userdata !=''){
      
        if(this.userdata.isMobileVerified =='No') {
         this.ismobilealert = true;
       }
       if(this.userdata.isMobileVerified =='Yes') {
         this.ismobilealert = false;
       }
   
       if(this.userdata.isEmailVerified == 'No'){
         this.isemailverified = true;
       }
   
      else if(this.userdata.isEmailVerified == 'Yes'){
         this.isemailverified = false;
       }
      }
this.accesstoken = this.userdata.accesstoken;
//console.log(this.accesstoken)
      this.detectDevice()
  }
  ngOnInit(){

   this. displayedColumns = ['SNo', 'FileType', 'FileName', 'Action'];


    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
      this.deviceinfo.ipAdress = (geoLocationResponse.ip);
    });
    
    this.deviceinfo = new deviceinfo();
    new Fingerprint2().get((components) => {
      this.getDeviceId = components;
      
       this.deviceinfo.deviceId = this.getDeviceId;
       
      this.getdashboarddetails( this.deviceinfo.deviceId);
      this. getsmedashfields( this.deviceinfo.deviceId);
    });
   
   
  }


  ngAfterViewInit(){
   
   }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  } 

  getdashboarddetails(deviceid){

    const object:any = {}
    object['deviceId'] = deviceid
    object['language'] = 'ar'

    this.sme.getsmedashboard(object,this.accesstoken).subscribe(response =>{


      if(response.Token_Status == '1119') {
        if(response.documents_status == '1126') {
        this.mgdis = true;
          this.dashboarddetails = response.documents;
          this.dataSource = this.dashboarddetails;
        }
        if(response.documents_status == '1011') {
          this.errmsg = 'حدث خطا ما'
       
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
        if(response.documents_status == '1012') {
          this.mgdis = true;
          this.errmsg = 'حدث خطا ما'
       
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
        if(response.documents_status == '1127') {
          this.mgdis = true;
          this.errmsg = 'لايوجد انترنت - البيانات غير متاحة ';
          this.dataSource = [];
      
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
      }


    })
  }

  getsmedashfields(deviceid) {
   
    const object: any = {}
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
     object['device_id'] = deviceid
  
     this.sme.getdashboardfeilds(object,this.accesstoken).subscribe(res =>{

       if(res.Token_Status == '1119') {
         if(res.sme_dashboard_status == '1000'){
          this.paidammount = res.paid_amount;
  this.paymenytdue= res.payments_due;
          this.fundamm = res.funding_amount;
          this.upcome = res.upcoming_payments;
                this.dateonwhichcondition=res.funding_details.date_on_which_conditions_were_accepted;
          this.financingproduct = res.funding_details.financing_product_renewal;
          this.arrangementfee = res.funding_details.arrangement_fee;
          this.grossprofitmargin = res.funding_details.gross_profit_margin_amount;
          this.dateofexchange = res.funding_details.date_of_exchange;
            this.termofpayment = res.funding_details.term_of_payment_of_the_funding_amounts;
            this.annualprofit =res.funding_details.annual_profit_margin_ratio;
            this.issuedbill =res.funding_details.issued_bill;
            this.thecontractapproved = res.funding_details.the_contract_has_been_approved_by;
            this.fundingamount = res.funding_details.funding_amount;
            this.fundingnumber = res.funding_details.funding_number;
            this.ipNumber = res.funding_details.ip_number;
            this.fundpercent = res.funding_details.fundingPercent;
            this.fundstatus = res.funding_details.status;
          
         }
         else if(res.sme_dashboard_status == '1002') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1003') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1004') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1005') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1006') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1007') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1008') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1009') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1010') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1011') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1012') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1015') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1016') {
          this.errmsg1 = 'حدث خطا ما'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         

       }

      else if(res.Token_Status == '1120') {
        this.errmsg1 = 'غير مصرح'
        this.mgdis1 = true;
        setTimeout(() => {
          this.mgdis1 = false;
        }, 3000);
       }

      else if(res.Token_Status == '1121') {
        this.errmsg1 = 'انتهت صلاحية الرمز '
        this.mgdis1 = true;
        setTimeout(() => {
          this.mgdis1 = false;
        }, 3000);
      }


 
     })



  }


  alertmsg(val){
    if(val == 'Mobile') {
  
      const obj:any ={}
  
  
   
  obj['ipAddress'] =this.deviceinfoservice.deviceinfo.ipAdress;
  obj['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
  obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  obj['countryCode'] = 'SA';
  obj['deviceType'] = 'Web';
  obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
  obj['language']= 'en';
  
  
  this.spinnerfull.show()
  
  this.authService.alertmobile(obj,this.userdata.accesstoken).subscribe(res=>{
    this.spinnerfull.hide()
    if(res.Token_Status =='1119'){
      if(res.Verify_Mobile_Otp_Response =='1000'){
        const dialogRef = this.dialog.open(AralertComponent,   {disableClose: true,
          width: '250px', 
          data:val
        
        });
  
        dialogRef.afterClosed().subscribe(result =>{
          this.list = result;
       if(this.list == '1000'){
         this.ismobilealert = false;
  
  
         const object:any ={} 
  
         object['FirstName']  = this.userdata.FirstName;
         object['LastName']     = this.userdata.LastName;
         object['LastLogin']    = this.userdata.LastLogin;
       
         object['isEmailVerified']   = this.userdata.isEmailVerified;
         object['accesstoken']   = this.userdata.accesstoken;
         object['ProfilePic'] =  this.userdata.ProfilePic;
         object['id']=this.userdata.id
         object['profileStatus']=this.userdata.profileStatus
         object['isInvestorInfoProvided']= this.userdata.isInvestorInfoProvided;
        object['isMobileVerified']  = "Yes"
        object['redirect'] = "arabicwebsmeapp";
         object['isPolicyAccepted']= this.userdata.isPolicyAccepted;
        object['isTermsAccepted'] = this.userdata.isTermsAccepted;
        object['profileStatus']  = this.userdata.profileStatus;
        sessionStorage.setItem('currentUser',JSON.stringify(object));
       }
  
        })
      
      }
    
     else if(res.Verify_Mobile_Otp_Response =='1011'){
       this.errmsg = 'حدث خطا ما';
       this.msgdis = true;
       setTimeout(() => {
        this.msgdis = false;
       }, 3000);
     }
     else if(res.Verify_Mobile_Otp_Response =='1012'){
      this.errmsg = 'حدث خطا ما';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
     }
      else if(res.Verify_Mobile_Otp_Response =='1015'){
        this.errmsg = 'حدث خطا ما';
        this.msgdis = true;
        setTimeout(() => {
         this.msgdis = false;
        }, 3000);
      }
      else if(res.Verify_Mobile_Otp_Response =='1016'){
        this.errmsg = 'حدث خطا ما';
        this.msgdis = true;
        setTimeout(() => {
         this.msgdis = false;
        }, 3000);
      }
      else if(res.Verify_Mobile_Otp_Response =='1001'){
        this.errmsg = 'فشل';
        this.msgdis = true;
        setTimeout(() => {
         this.msgdis = false;
        }, 3000);
      }
  
  
    }
  
   
    if(res.Token_Status =='1120'){
      this.errmsg = ' غير مصرح به ';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
    if(res.Token_Status =='1121'){
      this.errmsg = ' انتهت صلاحية التزكر';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
  
  
  })
   
   
    
  }
  
  
  if(val == 'email') {
  
    const obj:any ={}
  
  
  
  obj['ipAddress'] =this.deviceinfoservice.deviceinfo.ipAdress;
  obj['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
  obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  obj['countryCode'] = 'SA';
  obj['deviceType'] = 'Web';
  obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
  obj['language']= 'en';
  
  
  this.spinnerfull.show()
  
  this.authService.alertemail(obj,this.userdata.accesstoken).subscribe(res=>{
  this.spinnerfull.hide()
  if(res.Token_Status =='1119'){
    if(res.Verify_Email_Otp_Response =='1000'){
      const dialogRef = this.dialog.open(AralertComponent,  {disableClose: true,
        width: '250px',
        data:val
      
      });



      dialogRef.afterClosed().subscribe(result =>{
        this.list = result;
     if(this.list == '1000'){
       this.ismobilealert = false;


       const object:any ={}

       object['FirstName']  = this.userdata.FirstName;
       object['LastName']     = this.userdata.LastName;
       object['LastLogin']    = this.userdata.LastLogin;
       object['redirect'] = "arabicwebsmeapp";
       object['isEmailVerified']   = "Yes";
       object['accesstoken']   = this.userdata.accesstoken;
       object['ProfilePic'] =  this.userdata.ProfilePic;
       object['id']=this.userdata.id
       object['profileStatus']=this.userdata.profileStatus
       object['isInvestorInfoProvided']= this.userdata.isInvestorInfoProvided;
      object['isMobileVerified']  = this.userdata.isMobileVerified;
       object['isPolicyAccepted']= this.userdata.isPolicyAccepted;
      object['isTermsAccepted'] = this.userdata.isTermsAccepted;
      object['profileStatus']  = this.userdata.profileStatus;
      sessionStorage.setItem('currentUser',JSON.stringify(object));
     }

      })
     
    }
  
    else if(res.Verify_Email_Otp_Response =='1011'){
      this.errmsg1 = 'حدث خطا ما';
      this.msgdis1 = true;
      setTimeout(() => {
       this.msgdis1 = false;
      }, 3000);
    }
    else if(res.Verify_Email_Otp_Response =='1012'){
     this.errmsg1 = 'حدث خطا ما';
     this.msgdis1 = true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
    }
     else if(res.Verify_Email_Otp_Response =='1015'){
       this.errmsg1 = 'حدث خطا ما';
       this.msgdis1 = true;
       setTimeout(() => {
        this.msgdis1 = false;
       }, 3000);
     }
     else if(res.Verify_Email_Otp_Response =='1016'){
       this.errmsg1 = 'حدث خطا ما';
       this.msgdis1 = true;
       setTimeout(() => {
        this.msgdis1 = false;
       }, 3000);
     }
     else if(res.Verify_Email_Otp_Response =='1001'){
       this.errmsg1 = 'فشل';
       this.msgdis1= true;
       setTimeout(() => {
        this.msgdis1 = false;
       }, 3000);
     }
  
  }
  
  
  if(res.Token_Status =='1120'){
    this.errmsg1 = ' غير مصرح به ';
    this.msgdis1 = true;
    setTimeout(() => {
     this.msgdis1 = false;
    }, 3000);
  }
  if(res.Token_Status =='1121'){
    this.errmsg1 = ' انتهت صلاحية التزكر';
    this.msgdis1 = true;
    setTimeout(() => {
     this.msgdis1 = false;
    }, 3000);
  }
  
  
  })
  
  
  
  }
    }


    openinvestopp() {

      const dialogRef = this.dialog.open(DeleteComponent,  {disableClose: true,
        width: '450px',
      
    
      });


    }
   
  
  
}


@Component({
  
  selector: 'app-delete',
  template: `


  <i class="fa fa-times" aria-hidden="true"    style="margin-left: 98%; cursor:pointer;"  (click)="onNoClick()"></i>

<p   style="margin-left: 31%; font-family:Cairo
margin-top: 0%;"> لا يمكن معالجة حاليا!!</p>

  `
  




})
export class DeleteComponent implements OnInit {

  id;
  user: any;
  accessToken: any;
  investform:FormGroup;
  listError: boolean;
  sucessMessage: string;
  errorMessage: string;
  makercheckerlist: any;
  submittedinvest = false;
  ipAddress: any;
  geolocationPosition:object;
  data: any;
  latitude: any;
  longitude: any;
  btnammount: any;
  display: boolean;
  errdis: string;
  

  constructor(private fb:FormBuilder,private http:HttpClient,private auth:AuthService,
    public dialogRef: MatDialogRef<DeleteComponent>,
   
  ) {


  



    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accessToken= this.data.accesstoken;
  }

    

  }


  amount(val) {

    this.btnammount = val

  }


  get o(){return this.investform.controls}


  ngOnInit() {
    

  
}




  onNoClick() {
    this.dialogRef.close();
  }


 

 
}
 