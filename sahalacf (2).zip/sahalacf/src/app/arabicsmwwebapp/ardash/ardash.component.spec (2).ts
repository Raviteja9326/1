import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArdashComponent } from './ardash.component';

describe('ArdashComponent', () => {
  let component: ArdashComponent;
  let fixture: ComponentFixture<ArdashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArdashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArdashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
