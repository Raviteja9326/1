import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { deviceinfo } from 'src/app/shared/models/deviceinfo.model';
import { getMatIconNameNotFoundError } from '@angular/material/icon';
import { SmeborrowerService } from 'src/app/services/smeborrower.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from '@angular/common/http';
declare var Fingerprint2: any;

@Component({
  selector: 'app-ardash',
  templateUrl: './ardash.component.html',
  styleUrls: ['./ardash.component.scss'],
  encapsulation:ViewEncapsulation.Emulated
})
export class ArdashComponent implements OnInit {
 
  value = 90;
  dataSource;
  displayedColumns =[];
  getDeviceId;
  deviceinfo: deviceinfo;
  deviceInfo;
  dateonwhichcondition;
  financingproduct;
  arrangementfee;
  grossprofitmargin;
  dateofexchange;
    termofpayment;
    annualprofit;
    issuedbill;
    paidammount
    thecontractapproved;
    fundingamount;
    userdata;
    fundingnumber;
    ipNumber;
    smedash;
    paymenytdue;
  ipAddress;
  upcome;
  errmsg;
  errmsg1;
  mgdis1;
  mgdis;
  fundamm;
  dashboarddetails=[];
  
accesstoken:any;
  constructor(private deviceinfoservice:DeviceinfoserviceService,private sme :SmeborrowerService,
    private deviceService:DeviceDetectorService,private http:HttpClient) { 

      this.userdata =JSON.parse( sessionStorage.getItem('currentUser'))
//console.log(this.userdata.token)
this.accesstoken = this.userdata.accesstoken;
console.log(this.accesstoken)
      this.detectDevice()
  }
  ngOnInit(){

   this. displayedColumns = ['SNo', 'FileType', 'FileName', 'Action'];


    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
      console.log(geoLocationResponse.ip);
      this.deviceinfo.ipAdress = (geoLocationResponse.ip);
    });
    
    this.deviceinfo = new deviceinfo();
    new Fingerprint2().get((components) => {
      console.log((this));
      this.getDeviceId = components;
      console.log(typeof (this.getDeviceId));
      
       this.deviceinfo.deviceId = this.getDeviceId;
       
      this.getdashboarddetails( this.deviceinfo.deviceId);
      this. getsmedashfields( this.deviceinfo.deviceId);
    });
   
   
  }

  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    console.log(this.deviceInfo)
  }

  getdashboarddetails(deviceid){

    const object:any = {}
    object['deviceId'] = deviceid
    console.log(deviceid)

    this.sme.getsmedashboard(object,this.accesstoken).subscribe(response =>{
      console.log(response)


      if(response.Token_Status == '1119') {
        if(response.documents_status == '1126') {
        this.mgdis = true;
          this.dashboarddetails = response.documents;
          this.dataSource = this.dashboarddetails;
        }
        if(response.documents_status == '1011') {
          this.errmsg = 'SOMETHING WENT WRONG'
       
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
        if(response.documents_status == '1012') {
          this.mgdis = true;
          this.errmsg = 'SOMETHING WENT WRONG'
       
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
        if(response.documents_status == '1127') {
          this.mgdis = true;
          this.errmsg = 'LIST NOT AVAILABLE';
          this.dataSource = [];
      
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
      }


    })
  }

  getsmedashfields(deviceid) {
   
    const object: any = {}
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
     object['device_id'] = deviceid
     console.log(object)
  
     this.sme.getdashboardfeilds(object,this.accesstoken).subscribe(res =>{
       console.log(res);

       if(res.Token_Status == '1119') {
         if(res.sme_dashboard_status == '1000'){
          this.paidammount = res.paid_amount;
  this.paymenytdue= res.payments_due;
          this.fundamm = res.funding_amount;
          this.upcome = res.upcoming_payments;
                this.dateonwhichcondition=res.funding_details.date_on_which_conditions_were_accepted;
          this.financingproduct = res.funding_details.financing_product_renewal;
          this.arrangementfee = res.funding_details.arrangement_fee;
          this.grossprofitmargin = res.funding_details.gross_profit_margin_amount;
          this.dateofexchange = res.funding_details.date_of_exchange;
            this.termofpayment = res.funding_details.term_of_payment_of_the_funding_amounts;
            this.annualprofit =res.funding_details.annual_profit_margin_ratio;
            this.issuedbill =res.funding_details.issued_bill;
            this.thecontractapproved = res.funding_details.the_contract_has_been_approved_by;
            this.fundingamount = res.funding_details.funding_amount;
            this.fundingnumber = res.funding_details.funding_number;
            this.ipNumber = res.funding_details.ip_number;
          
         }
         else if(res.sme_dashboard_status == '1002') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1003') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1004') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1005') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1006') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1007') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1008') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1009') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1010') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1011') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1012') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1015') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         else if(res.sme_dashboard_status == '1016') {
          this.errmsg1 = 'SOMETHING WENT WRONG'
          this.mgdis1 = true;
          setTimeout(() => {
            this.mgdis1 = false;
          }, 3000);
         }
         

       }

      else if(res.Token_Status == '1120') {
        this.errmsg1 = 'UNAUTHORIZED'
        this.mgdis1 = true;
        setTimeout(() => {
          this.mgdis1 = false;
        }, 3000);
       }

      else if(res.Token_Status == '1121') {
        this.errmsg1 = 'TOKEN EXPIRED'
        this.mgdis1 = true;
        setTimeout(() => {
          this.mgdis1 = false;
        }, 3000);
      }


 
     })



  }
  
}
 