import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArmyloansComponent } from './armyloans.component';

describe('ArmyloansComponent', () => {
  let component: ArmyloansComponent;
  let fixture: ComponentFixture<ArmyloansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArmyloansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArmyloansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
