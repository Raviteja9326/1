import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { deviceinfo } from 'src/app/shared/models/deviceinfo.model';
import { getMatIconNameNotFoundError } from '@angular/material/icon';
import { SmeborrowerService } from 'src/app/services/smeborrower.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
declare var Fingerprint2: any;

@Component({
  selector: 'app-armyloans',
  templateUrl: './armyloans.component.html',
  styleUrls: ['./armyloans.component.scss']
})
export class ArmyloansComponent implements OnInit {

  deviceinfo;
  getDeviceId;
  errmsg;
  mgdis;
  accesstoken:any;
  userdata;
  table1 = true;
  exist = false;
  table = true;
  displayedColumns= [];
  loanresponse = [];
  dataSource;
  constructor(private sme :SmeborrowerService,
    private deviceService:DeviceDetectorService,private http:HttpClient,private router:Router)  {
      
      this.userdata = JSON.parse(sessionStorage.getItem('currentUser'))
      this.accesstoken  = this.userdata.accesstoken;

     }

  ngOnInit() {

    this.displayedColumns = ['FundingNumber', 'DateOfRequesting', 'FundingAmount', 'DurationOfFunding','Details'];

    this.deviceinfo = new deviceinfo();
    new Fingerprint2().get((components) => {
      this.getDeviceId = components;
      
       this.deviceinfo.deviceId = this.getDeviceId;
       this.getloantable(this.deviceinfo.deviceId)
    });
  } 


  existbtn() {
    this.table1 = false
    this.exist = true
  } 

  getloantable(deviceid){

    const obj:any ={}

    obj['deviceId'] = deviceid;
    obj['pageNumber'] = '0';
    obj['pageSize'] = '10000';


    this.sme.getloantable(obj,this.accesstoken).subscribe(response =>{
      if(response.Token_Status == '1119') {

         if(response.myloans_status == '1126') {

        this.loanresponse = response.myloans;
        this.dataSource =this.loanresponse;


         }
        
       if(response.myloans_status == '1127') {
  this.errmsg = 'القائمة غير متاحة';
  this.mgdis = true;
  this.table = false;
  setTimeout(() => {
    this.mgdis = false;
  }, 500000);
        this.loanresponse = [];
        this.dataSource =this.loanresponse;
      
       }
       
       else if(response.myloans_status == '1150') {
        this.errmsg = 'حدث خطا ما';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }
       else if(response.myloans_status == '1151') {
        this.errmsg = 'حدث خطا ما';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }
       else if(response.myloans_status == '1152') {
        this.errmsg = 'القائمة غير متاحة';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }

       else if(response.myloans_status == '1153') {
        this.errmsg = 'حدث خطا ما';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }
       else if(response.myloans_status == '1011') {
        this.errmsg = 'حدث خطا ما';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }
       else if(response.myloans_status == '1012') {
        this.errmsg = 'حدث خطا ما';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }
       else if(response.myloans_status == '1002') {
        this.errmsg = 'حدث خطا ما';
        this.mgdis = true;
        setTimeout(() => {
          this.mgdis = false;
        }, 3000);
       }
      
      
       }
     

      else if(response.Token_Status == '1120'){
        this.errmsg = ' غير مصرح به ';
  this.mgdis = true;
  setTimeout(() => {
    this.mgdis = false;
  }, 3000);
      }
      else if(response.Token_Status == '1121'){
        this.errmsg = 'انتهت صلاحية التزكر';
  this.mgdis = true;
  setTimeout(() => {
    this.mgdis = false;
  }, 3000);
      }
    

       
    })

  }


  FundingNumber(id) {
    this.router.navigate(['/arabicwebsmeapp/webappsmeloan',id])
  }

}
 