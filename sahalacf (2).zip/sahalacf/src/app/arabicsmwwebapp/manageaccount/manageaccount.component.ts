import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { HttpClient } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NgxSpinnerService } from 'ngx-spinner';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, changepasswordForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = changepasswordForm && changepasswordForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
} 

export const passwordMatchValidator: ValidatorFn = (changepasswordForm: FormGroup): ValidationErrors | null => {
  if (changepasswordForm.get('newapassword').value === changepasswordForm.get('reenternewPassword').value)
    return null;
  else
    return {passwordMismatch: true};   
}; 


@Component({
  selector: 'app-manageaccount',
  templateUrl: './manageaccount.component.html',
  styleUrls: ['./manageaccount.component.scss'],
  encapsulation:ViewEncapsulation.Emulated

})
export class ManageaccountComponent implements OnInit {

  changepasswordForm:FormGroup;
  hide = true;
  hide1 = true; 
  hide2 = true;
  hidePassword=true;
  uploadprofleForm:FormGroup
  ErrorMsg: string;
  msgError: boolean;
  responseMessgae: string;
  registError: boolean;
  acesstoken: any;
  deviceInfo: any;
  responseUpdatePasswordMessgae: string;
  otpForm:FormGroup
  otperror: string;
  otpShow: boolean;
  data: any;
  submitted: boolean;
  UpdatePassworderrMessgae: string;
  updtpassError: boolean;
  updtpasssucc: boolean;
  ImageuplodSucess: string;
  uplodimgsucc: boolean;
  uplodimgerr: boolean;
  profileimage: any;
  static: boolean;
  dynamic: boolean;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,

    private spinnerfull: NgxSpinnerService,
    private http: HttpClient, private deviceService: DeviceDetectorService) {
      this. detectDevice();

      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    
      if(this.data!=null || this.data !=''){
        this.acesstoken= this.data.accesstoken;
        this.profileimage=this.data.ProfilePic;

        if(this.profileimage != 'NA') {
          this.static = false;
          this.dynamic = true
        } else {
          this.static = true;
          this.dynamic = false;
        }



      }
   }



   get oldPassword() { return this.changepasswordForm.get('oldPassword'); }
   get newapassword() { return this.changepasswordForm.get('newapassword'); }
   get reenternewPassword() { return this.changepasswordForm.get('reenternewPassword'); }
   get o(){return this.otpForm.controls}
  ngOnInit() {

    this.changepasswordForm = this.fb.group({
      oldPassword :['',[Validators.required, Validators.minLength(8), Validators.maxLength(20)]],
      newapassword:['',[Validators.required, Validators.minLength(8), Validators.maxLength(20)]],
      reenternewPassword:['',[Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
    },
    {
      validator: passwordMatchValidator
    });
    this.uploadprofleForm=this.fb.group({
      uploadProfile: [''],
 });
 this.otpForm=this.fb.group({
  otp: ['',[Validators.required,Validators.minLength(6), Validators.maxLength(6), Validators.pattern("^[A-Za-z0-9]*$")]],
});
  }

  onPasswordInput() {
    if (this.changepasswordForm.hasError('passwordMismatch'))
      this.reenternewPassword.setErrors([{'passwordMismatch': true}]);
    else
      this.reenternewPassword.setErrors(null);
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadprofleForm.get('uploadProfile').setValue(file);
    }
  }
  UpdateProfile(){
    
    if(this.uploadprofleForm.value.uploadProfile != '' && this.uploadprofleForm.value.uploadProfile != '') {

      this.msgError = false;
      const formData = new FormData();
      formData.append('file',this.uploadprofleForm.get('uploadProfile').value);
      formData.append('attachement',this.uploadprofleForm.value.uploadProfile);
      formData.append('deviceid',this.deviceinfoservice.deviceinfo.deviceId);
      formData.append('devicetype',this.deviceinfoservice.deviceinfo.deviceType);
      formData.append('ipaddress',this.deviceinfoservice.deviceinfo.ipAdress),
      formData.append('latitude',this.deviceinfoservice.deviceinfo.latitude);
      formData.append('longitude',this.deviceinfoservice.deviceinfo.logintude);

     this.authService.UpadteProfile(formData,this.acesstoken).subscribe(response=>{
      this.updateProfileResponse(response)})
     

    }else{
      this.ErrorMsg="يرجي تحميل الصوره "
      this.msgError = true;
    }
  }
 
  updateProfileResponse(response){
    // console.log(response)
    if(response.Token_Status=='1119'){

      if(response.Upload_Image_Response=='1000'){
       this.profileimage=response.Profile_Pic

       this.static = false;
       this.dynamic = true;

       const object:any = {}
       object['FirstName']  = this.data.FirstName;
       object['LastName']     = this.data.LastName;
       object['LastLogin']    = this.data.LastLogin;
       object['isMobileVerified']   = this.data.isMobileVerified;
       object['isEmailVerified']   = this.data.isEmailVerified;
       object['accesstoken']   = this.data.accesstoken;
       object['ProfilePic'] =  this.profileimage
       object['id']=this.data.id
       object['profileStatus']=this.data.profileStatus
       object['ProfilePic'] = response.Profile_Pic;
       if(this.data.isInvestorInfoProvided !='' && this.data.isInvestorInfoProvided !=null){
        object['isPolicyAccepted']   = this.data.isPolicyAccepted;
        object['isBankInfoProvided']    = this.data.isBankInfoProvided;
        object['isInvestorInfoProvided']    = this.data.isInvestorInfoProvided;
        object['isTermsAccepted']  = this.data.isTermsAccepted;
       }else if(this.data.isCompnayInformationProvided !='' && this.data.isCompnayInformationProvided !=null){
        object['isBankInformationProvided']    = this.data.isBankInformationProvided;
        object['isCompnayInformationProvided']    = this.data.isCompnayInformationProvided;
        object['isDcoumentsInformationProvided']   = this.data.isDcoumentsInformationProvided;
        object['isShareHolderInformationProvided'] = this.data.isShareHolderInformationProvided;
       }
       sessionStorage.setItem('currentUser',JSON.stringify(object));
       //this.profileimage='https://images.sahlahcf.com/profile_images/96fb050f311b451aaa867da591be75c8.jpg'
        this.ImageuplodSucess="تم تحميل صوره الملف الشخصي بنجاح"
        this.uplodimgsucc = true;
        setTimeout(() => {
          this.uplodimgsucc = false;
        }, 3000)

      }else if(response.Upload_Image_Response=='1001'){
        this.responseMessgae = "فشل ";
      
        this.uplodimgerr = true;
        setTimeout(() => {
          this.uplodimgerr = false;
        }, 3000)
      }else{
        this.responseMessgae = "هنالك خطاً ";
      
        this.uplodimgerr = true;
        setTimeout(() => {
          this.uplodimgerr = false;
        }, 3000)
      }

    }else if(response.Token_Status=='1120'){
      this.responseMessgae = "غير مصرح ";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
      this.responseMessgae = "انتهت صلاحية الرمز ";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }
  UpdatePassword(){
    // this.otpShow=true;
    // this.hidePassword=false;
    this.changepasswordForm.get('reenternewPassword').markAsTouched();
    this.changepasswordForm.get('oldPassword').markAsTouched();
    this.changepasswordForm.get('newapassword').markAsTouched();
   
    if(this.changepasswordForm.valid) {
      this.detectDevice();
const object:any={}
object['browserType'] = this.deviceInfo.browser;
object['browserVersion'] = this.deviceInfo.browser_version;
object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
object['osVersion'] = this.deviceInfo.os_version;
object['osType'] = this.deviceInfo.os;
object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
object['language'] = 'en';
 object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
 object['oldPassword']=this.changepasswordForm.value.oldPassword
 object['newPassword']=this.changepasswordForm.value.newapassword
 object['conformPassword']=this.changepasswordForm.value.reenternewPassword
this.spinnerfull.show()
this.authService.updatePasswordOtp(object,this.acesstoken).subscribe(response=>
  this.updatePasswordOtpResponse(response))
    }
  }
  updatePasswordOtpResponse(response){
    // console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
if(response.Update_Password_Otp_Response=='1000'){
 
  this.hidePassword=false;
  this.otpShow=true;
}else if(response.update_password_status=='1089'){
  this.responseUpdatePasswordMessgae= "كلمة السر الجديدة و التاكيد غير متطابقة ";
  this.registError = true;
  setTimeout(() => {
    this.registError = false;
  }, 3000)
}else if(response.Update_Password_Otp_Response=='1001'){
  this.responseUpdatePasswordMessgae = "فشل";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
}else if(response.Update_Password_Otp_Response=='1002'){
  this.responseUpdatePasswordMessgae = "هنالك خطاً";
      
      this.registError = true;
      setTimeout(() => { 
        this.registError = false;
      }, 3000)
}



else if(response.Update_Password_Otp_Response=='1129'){
  this.responseUpdatePasswordMessgae = "كلمة سر قديمة ليست صحيحة";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
}
    
    }else if(response.Token_Status=='1120'){
      this.responseUpdatePasswordMessgae = "غير مصرح ";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
      this.responseUpdatePasswordMessgae = "انتهت صلاحية الرمز ";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }
  }
  VerifyOtp(){
    this.submitted=true;
    if(this.otpForm.valid){
      const object:any={}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
       object['oldPassword']=this.changepasswordForm.value.oldPassword
       object['newPassword']=this.changepasswordForm.value.newapassword
       object['conformPassword']=this.changepasswordForm.value.reenternewPassword
       object['otp'] = this.otpForm.value.otp;
       this.spinnerfull.show()
       this.authService.VerifyOtpUpdatePassword(object,this.acesstoken).subscribe(response=>
        this.verifyOtpPasswordResponse(response))
    }
  }
  verifyOtpPasswordResponse(response){
    // console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
if(response.update_password_status=='1000'){

  this.changepasswordForm.reset();
 // alert("Passowrd Update SucessFully")
  this.responseUpdatePasswordMessgae = "تم تحديث كلمة السر بنجاح";
      
  this.updtpasssucc = true;
  setTimeout(() => {
    this.otpForm.reset();
    this.hidePassword=true;
    this.otpShow=false;
    this.updtpasssucc = false;
  }, 3000)
}else if(response.update_password_status=='1089'){
  this.UpdatePassworderrMessgae= "كلمة السر الجديدة و التاكيد غير متطابقة ";
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1090'){
  this.UpdatePassworderrMessgae= "حقل كلمة المرور. المؤقتة فارغ "
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1091'){
  this.UpdatePassworderrMessgae= " كلمة المرور المؤقتة غير صالحة "
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1092'){
  this.UpdatePassworderrMessgae= " كلمة المرور المؤقتة غير صالحة "
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1093'){
  this.UpdatePassworderrMessgae= " كلمة المرور المؤقتة غير صالحة "
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}else if(response.update_password_status=='1094'){
  this.UpdatePassworderrMessgae= "انتهت صلاحية كلمة المرور المؤقتة "
  this.updtpassError = true;
  setTimeout(() => {
    this.updtpassError = false;
  }, 3000)
}

    }else if(response.Token_Status=='1120'){
      this.responseUpdatePasswordMessgae = "غير مصرح ";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
 this.responseUpdatePasswordMessgae = "انتهت صلاحية الرمز";
      
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }
  }
  otpBack(){
    this.hidePassword=true;
    this.otpShow=false;
  }

}
