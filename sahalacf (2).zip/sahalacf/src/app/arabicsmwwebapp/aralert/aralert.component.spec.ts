import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AralertComponent } from './aralert.component';

describe('AralertComponent', () => {
  let component: AralertComponent;
  let fixture: ComponentFixture<AralertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AralertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AralertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
