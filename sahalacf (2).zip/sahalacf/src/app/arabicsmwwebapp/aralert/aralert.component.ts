import { Component, OnInit ,Inject, Optional} from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';



import { FormBuilder, FormGroup,Validators, FormGroupDirective, FormControl, NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


export interface UsersData {
  val: string; 

}
@Component({
  selector: 'app-aralert',
  templateUrl: './aralert.component.html',
  styleUrls: ['./aralert.component.scss']
})
export class AralertComponent implements OnInit {
  mobileotpForm:FormGroup;
  hide = true;
  submitted: boolean;
  deviceInfo: any;
  data: any;
  accesstoken: any;
  val;
  mobile: boolean;
  email: boolean;
  ermsg: string;
  verify: boolean;
  storagedata;
  verifysuc: boolean;
  ermsgsuc: string;
  get o(){return this.mobileotpForm.controls}

  constructor(private fb:FormBuilder,private auth:AuthService,
    public dialogRef: MatDialogRef<AralertComponent>,private deviceinfoservice:DeviceinfoserviceService,
    private deviceService: DeviceDetectorService,
    @Optional() @Inject(MAT_DIALOG_DATA) public dataval: UsersData
   
   
  ) {
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    this.accesstoken = this.data.accesstoken;

    this.val = dataval;
    if(this.val == 'Mobile'){
      this.mobile = true;
    }
    if(this.val == 'email'){
      this.email = true;
    }
  }
  ngOnInit() {
    this.mobileotpForm=this.fb.group({
      otp:['',[Validators.required,Validators.minLength(6), Validators.maxLength(6),Validators.pattern("^[0-9a-zA-Z]*$")]],
    });

  }

  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }


  close() {
    this.dialogRef.close();
  }


  onNoClick() {
    this.submitted = true;
    if(this.val == 'Mobile'){
if(this.mobileotpForm.valid){
const obj:any = {};
obj['ipAddress']=this.deviceinfoservice.deviceinfo.ipAdress;
obj['latitude']=this.deviceinfoservice.deviceinfo.latitude;
obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
obj['countryCode']='SA';
obj['deviceType'] = 'Web';
obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
obj['language'] ='en'; 
obj['otp']= this.mobileotpForm.value.otp;


this.auth.alertotpverify(obj,this.accesstoken).subscribe(response =>{
 
  if(response.Token_Status == '1119'){
  if(response.Verify_Mobile_Response == '1000') {
    this.verifysuc = true;
    this.ermsgsuc = 'تم التحقق من رقم الجوال  بنجاح ';

    setTimeout(() => {
      this.verifysuc = false;
      this.dialogRef.close(response.Verify_Mobile_Response);
    }, 3000);
  }
   else if(response.Verify_Mobile_Response == '1011') {
      this.verify = true;
      this.ermsg = 'حدث خطا ما';
  
      setTimeout(() => {
        this.verify = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
   
    else if(response.Verify_Mobile_Response == '1012') {
      this.verify = true;
      this.ermsg = 'حدث خطا ما';
  
      setTimeout(() => {
        this.verify = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1015') {
      this.verify = true;
      this.ermsg = 'حدث خطا ما';
  
      setTimeout(() => {
        this.verify = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1016') {
      this.verify = true;
      this.ermsg = 'حدث خطا ما';
  
      setTimeout(() => {
        this.verify = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1094') {
      this.verify = true;
      this.ermsg = 'انتهت صلاحية كلمة المرور المؤقتة ';
  
      setTimeout(() => {
        this.verify = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1090') {
      this.verify = true;
      this.ermsg = 'حقل كلمة المرور. المؤقتة فارغ';
  
      setTimeout(() => {
        this.verify = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1091') {
      this.verify = true;
      this.ermsg = 'كلمة المرور المؤقتة غير صالحة ';
  
      setTimeout(() => {
        this.verify = false;
 
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1001') {
      this.verify = true;
      this.ermsg = 'فشل';
  
      setTimeout(() => {
        this.verify = false;
      
      }, 3000);
    }
    else if(response.Verify_Mobile_Response == '1093') {
      this.verify = true;
      this.ermsg = 'كلمة المرور المؤقتة غير صالحة ';
  
      setTimeout(() => {
        this.verify = false;
      }, 3000);
    }


  
    

  }


})
   
  }
}

  if(this.val == 'email'){
if(this.mobileotpForm.valid){
const obj:any = {};
obj['ipAddress']=this.deviceinfoservice.deviceinfo.ipAdress;
obj['latitude']=this.deviceinfoservice.deviceinfo.latitude;
obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
obj['countryCode']='SA';
obj['deviceType'] = 'Web';
obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
obj['language'] ='en';
obj['otp']= this.mobileotpForm.value.otp;


this.auth.alertotpverify(obj,this.accesstoken).subscribe(response =>{

  if(response.Token_Status == '1119'){
    if(response.Verify_Mobile_Response == '1000') {
      this.verifysuc = true;
      this.ermsgsuc = ' تم التحقق من البريد الإلكتروني بنجاح';
  
      setTimeout(() => {
        this.verifysuc = false;
        this.dialogRef.close(response.Verify_Mobile_Response);
      }, 3000);
    }
     else if(response.Verify_Mobile_Response == '1011') {
        this.verify = true;
        this.ermsg = 'حدث خطا ما';
     
        setTimeout(() => {
          this.verify = false;
          this.dialogRef.close(response.Verify_Mobile_Response);
        }, 3000);
      }
     
      else if(response.Verify_Mobile_Response == '1012') {
        this.verify = true;
        this.ermsg = 'حدث خطا ما';
    
        setTimeout(() => {
          this.verify = false;
          this.dialogRef.close(response.Verify_Mobile_Response);
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == '1015') {
        this.verify = true;
        this.ermsg = 'حدث خطا ما';
    
        setTimeout(() => {
          this.verify = false;
          this.dialogRef.close(response.Verify_Mobile_Response);
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == '1016') {
        this.verify = true;
        this.ermsg = 'حدث خطا ما';
    
        setTimeout(() => {
          this.verify = false;
          this.dialogRef.close(response.Verify_Mobile_Response);
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == '1094') {
        this.verify = true;
        this.ermsg = '   انتهت صلاحية  OTP  ';
    
        setTimeout(() => {
          this.verify = false;
          this.dialogRef.close(response.Verify_Mobile_Response);
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == ' 1090') {
        this.verify = true;
        this.ermsg = 'حقل كلمة المرور. المؤقتة فارغ';
    
        setTimeout(() => {
          this.verify = false;
         
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == '1091') {
        this.verify = true;
        this.ermsg = 'كلمة المرور المؤقتة غير صالحة ';
    
        setTimeout(() => {
          this.verify = false;
        
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == '1001') {
        this.verify = true;
        this.ermsg = 'فشل';
    
        setTimeout(() => {
          this.verify = false;
          this.dialogRef.close(response.Verify_Mobile_Response);
        }, 3000);
      }
      else if(response.Verify_Mobile_Response == '1093') {
        this.verify = true;
        this.ermsg = 'كلمة المرور المؤقتة غير صالحة ';
    
        setTimeout(() => {
          this.verify = false;
          
        }, 3000);
      }
  
  
    
      
  
    }
  
})
    
  }

}
  }
}
