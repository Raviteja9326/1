import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Arloan2Component } from './arloan2.component';

describe('Arloan2Component', () => {
  let component: Arloan2Component;
  let fixture: ComponentFixture<Arloan2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Arloan2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Arloan2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
