import { Component, OnInit ,ViewEncapsulation} from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import { ActivatedRoute } from '@angular/router';
import { DeviceDetectorService } from 'ngx-device-detector';
import { deviceinfo } from 'src/app/shared/models/deviceinfo.model';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { SmeborrowerService } from 'src/app/services/smeborrower.service';
declare var Fingerprint2: any;

export interface PeriodicElement1 {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  
 
} 


const ELEMENT_DATA: PeriodicElement1[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'}
  
  
];
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, personalForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = personalForm && personalForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-arloan2',
  templateUrl: './arloan2.component.html',
  styleUrls: ['./arloan2.component.scss'],
  encapsulation:ViewEncapsulation.Emulated
})
export class Arloan2Component implements OnInit {
id;
deviceInfo;
acesstoken;
dateonwhichcondition;
financingproduct;
arrangementfee;
grossprofitmargin;
dateofexchange;
  termofpayment;
  annualprofit;
  issuedbill;
  paidammount
  thecontractapproved;
  fundingamount;
  fundingnumber;
  ipNumber;
  smedash;
  paymenytdue;
  dataSource;
  displayedColumns =[];
ipAddress;
upcome;
errmsg;
errmsg1;
mgdis1;
mgdis;
fundamm;
dashboarddetails:any =[]
 
  userdata: any;
  accesstoken: any;
  fundstatus: any;
  constructor(private route:ActivatedRoute,private fb:FormBuilder, private deviceService:DeviceDetectorService,
    private deviceinfoservice:DeviceinfoserviceService,private sme:SmeborrowerService) {

      this.detectDevice();
this.id = this.route.snapshot.params['id'];
this.userdata = JSON.parse(sessionStorage.getItem('currentUser'))
this.accesstoken  = this.userdata.accesstoken;

this.getloaniddetails(this.id)




   }

  ngOnInit() {

    this. displayedColumns = ['SNo', 'FileType', 'FileName', 'Action'];
    this.getdashboarddetails()
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }
  getloaniddetails(id){
    const object: any = {}
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
 
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
     object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId;
object['loan_id'] = id;


this.sme.getloaniddetails(object,this.accesstoken).subscribe(res =>{

  if(res.Token_Status == '1119' ) {
    this.dateonwhichcondition=res.date_on_which_conditions_were_accepted;
    this.financingproduct = res.financing_product_renewal;
    this.arrangementfee = res.arrangement_fee;
    this.grossprofitmargin = res.gross_profit_margin_amount;
    this.dateofexchange = res.date_of_exchange;
      this.termofpayment = res.term_of_payment_of_the_funding_amounts;
      this.annualprofit =res.annual_profit_margin_ratio;
      this.issuedbill =res.issued_bill;
      this.thecontractapproved = res.the_contract_has_been_approved_by;
      this.fundingamount = res.funding_amount;
      this.fundingnumber = res.funding_number;
      this.fundstatus = res.status;
      this.ipNumber = res.ip_number;
  }
  else if(res.funding_details_status == '1002') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1003') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => { 
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1004') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1005') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1006') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.sme_dashboard_status == '1007') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1008') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.sme_dashboard_status == '1009') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1010') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1011') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1012') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1015') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1016') {
    this.errmsg1 = 'حدث خطا ما'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1108') {
    this.errmsg1 = 'جب أن يكون معرف القرض رقميًا '
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.funding_details_status == '1109') {
    this.errmsg1 = 'جب أن يكون معرف القرض رقميًا '
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }
   else if(res.Token_Status == '1120') {
    this.errmsg1 = 'غير مصرح'
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
   }

  else if(res.Token_Status == '1121') {
    this.errmsg1 = 'انتهت صلاحية الرمز '
    this.mgdis1 = true;
    setTimeout(() => {
      this.mgdis1 = false;
    }, 3000);
  }
})
  }

  getdashboarddetails(){

    const object:any = {}
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['language'] = 'ar'
 

    this.sme.getsmedashboard(object,this.accesstoken).subscribe(response =>{


      if(response.Token_Status == '1119') {
        if(response.documents_status == '1126') {
        this.mgdis = true;
          this.dashboarddetails = response.documents;
          this.dataSource = this.dashboarddetails;
        }
        if(response.documents_status == '1011') {
          this.errmsg = 'حدث خطا ما'
       
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
        if(response.documents_status == '1012') {
          this.mgdis = true;
          this.errmsg = 'حدث خطا ما'
       
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
        if(response.documents_status == '1127') {
          this.mgdis = true;
          this.errmsg = 'لايوجد انترنت - البيانات غير متاحة ';
          this.dataSource = [];
      
          setTimeout(() => {
            this.mgdis = false;
          }, 3000);
        }
      }


    })
  }

}
