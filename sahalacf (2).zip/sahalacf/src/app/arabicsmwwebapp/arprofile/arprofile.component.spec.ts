import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArprofileComponent } from './arprofile.component';

describe('ArprofileComponent', () => {
  let component: ArprofileComponent;
  let fixture: ComponentFixture<ArprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
