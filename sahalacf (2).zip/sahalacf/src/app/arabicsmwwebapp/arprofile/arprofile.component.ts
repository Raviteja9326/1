import { Component, OnInit ,ViewEncapsulation, ViewChild, ElementRef} from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { deviceinfo } from 'src/app/shared/models/deviceinfo.model';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { SmeborrowerService } from 'src/app/services/smeborrower.service';
import { AuthService } from 'src/app/services/auth.service';
import { NgxSpinnerService } from 'ngx-spinner';

declare var Fingerprint2: any;

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, personalForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = personalForm && personalForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-arprofile',
  templateUrl: './arprofile.component.html',
  styleUrls: ['./arprofile.component.scss'],
  encapsulation:ViewEncapsulation.Emulated
})
export class ArprofileComponent implements OnInit {

  basicotpShow = false;
  basicotpShow1 = false;
  compform = true;
  errmsg ;
  msgdis;
  errmsg1 ;
  msgdis1;
  basicForm:FormGroup;
  personalForm:FormGroup;
  bankForm:FormGroup;
  accesstoken:any;
  getDeviceId;
  deviceinfo: deviceinfo;
  deviceInfo;
  otpForm:FormGroup;
submitted = false;
submitted1 = false;
submitted2 = false;

profileError: boolean;
errorMessage: string;
BankDetailsForm:FormGroup
SucessError: boolean;
sucessMessage: string;
profilepage=true;
otpShow=false;
bankotpShow=false
userdata;
sucessinfo: boolean;
SucessMessage: string;
BasicProfile=true
data: any;
personalinfootpShow=false
uploadfileForm:FormGroup;
submitted5: boolean;

duration = [

  {value: 1, viewValue: 'شهرواحد' },
  {value: 2, viewValue: 'شهران'},
  {value: 3, viewValue: '3أشهر'},
  {value: 4, viewValue: ' 4أشهر'},
  {value: 5, viewValue: '5أشهر'},
  {value: 6, viewValue: '6أشهر'},
  {value: 7, viewValue: ' 7أشهر'},
  {value: 8, viewValue: '8أشهر'},
  {value: 9, viewValue: '9أشهر'},
  {value:10,viewValue:'10أشهر'},
  

];

noofclients = [
  {value: 'أقل من 5', viewValue: 'أقل من 5'},
  {value: '5 إلى 10', viewValue: '5 إلى 10'},


  {value: '11 إلى 20', viewValue: '11 إلى 20'},

  {value: '21 إلى 50', viewValue: '21 إلى 50'},

  {value: 'أكثر من 50', viewValue: 'أكثر من 50'},


  
 

];
// compnayactivity = [

//   { value: "Agriculture & fishing", viewValue: 'Agriculture & fishing' },
//   { value: "Oil & gas extraction / mining & quarrying", viewValue: 'Oil & gas ' },
//   { value: "Petrochemical & related industries", viewValue: 'Petrochemical & related industries' },
//   { value: "Logistics", viewValue: 'Logistics' },
//   { value: "Utilities (Electricity, Water, Gas, & Sanitary Services)", viewValue: 'Utilities ' },
//   { value: "Communication / IT", viewValue: 'Communication / IT' },
//   { value: "Construction-contractors/builders", viewValue: 'Construction-contractors' },
//   { value: "Construction-ancillary contractors (finishing)", viewValue: 'Construction-ancillary' },
//   { value: "Construction material (suppliers & manufacturers)", viewValue: 'Construction material' },
//   { value: "Primary metal manufacturing & heavy equipment", viewValue: 'Primary metal' },
//   { value: "Consumer products", viewValue: 'Consumer products' },
//   { value: "E-commerce", viewValue: 'E-commerce' },
//   { value: "Automobiles", viewValue: 'Automobiles' },
//   { value: "Drugs & pharmaceuticals", viewValue: 'Drugs' },
//   { value: "Food & beverages", viewValue: 'Food' },
//   { value: "Miscellaneous", viewValue: 'Miscellaneous' },
//   { value: "Services (other than financial)", viewValue: 'Services' }

// ]

compnayactivity = [
    
  {value:"الزراعة والصيد", viewValue:'الزراعة والصيد'},
  {value: "استخراج النفط والغاز / التعدين واستغلال المحاجر", viewValue:'استخراج النفط والغاز / التعدين واستغلال المحاجر '},
   {value:"البتروكيماويات والصناعات ذات الصلة",viewValue:'البتروكيماويات والصناعات ذات الصلة'},
    {value:"الخدمات اللوجستية",viewValue:'الخدمات اللوجستية'},
     {value:'المرافق (الكهرباء والمياه والغاز والخدمات الصحية)',viewValue:'المرافق (الكهرباء والمياه والغاز والخدمات الصحية)'},
     {value: "الاتصالات / تكنولوجيا المعلومات", viewValue:'الاتصالات / تكنولوجيا المعلومات'},
     {value:"البناء و المقولات ",viewValue:'البناء و المقولات '},
     {value: "البناء و المقولات (التشطيب)", viewValue:'البناء و المقولات (التشطيب)'},
     {value:"مواد البناء (الموردين والمصنعين)",viewValue:'مواد البناء (الموردين والمصنعين)'},
     {value: "تصنيع المعادن الأولية والمعدات الثقيلة",viewValue:'تصنيع المعادن الأولية والمعدات الثقيلة'},
     {value: "منتجات المستهلك",viewValue:'منتجات المستهلك'},
     {value: "التجارة الإلكترونية",viewValue:'التجارة الإلكترونية'},
     {value: "السيارات",viewValue:'السيارات'},
     {value: "الأدوية والمستحضرات الصيدلانية",viewValue:'الأدوية والمستحضرات الصيدلانية'},
     {value: "أطعمة ومشروبات",viewValue:'أطعمة ومشروبات'},
     {value: "متنوع",viewValue:'متنوع'},
     {value: "الخدمات (غير المالية)",viewValue:'الخدمات (غير المالية)'},
   
  
]

annualIncome = [


  { value: 'Less than 5أقل من 5', viewValue: 'Less than 5' },
  { value: '5 to 10', viewValue: ' 5 to 10' },
  { value: '11 to 20', viewValue: '11 to 20' },
  { value: '21 to 50', viewValue: '21 to 50' },
  { value: ' أكثر من 50', viewValue: ' أكثر من 50' },
]
companyturnover=[

  {value: 'أقل من 3 مليون ريال سعودي', viewValue: 'أقل من 3 مليون ريال سعودي'},
  
  {value: 'من 3 مليون إلى 10 مليون ريال سعودي', viewValue: 'من 3 مليون إلى 10 مليون ريال سعودي'},
  
  {value: 'من 11 مليون إلى 20 مليون ريال سعودي', viewValue: ' من 11 مليون إلى 20 مليون ريال سعودي'},
  
  {value: 'من 20 مليون إلى 40 مليون ريال سعودي', viewValue: 'من 20 مليون إلى 40 مليون ريال سعودي'},
  
  {value: 'فوق 40 مليون ريال', viewValue: 'فوق 40 مليون ريال'},

 

  
  ]
domains = [
  { value: 'أصفر / أحمر', viewValue: 'أصفر / أحمر' },
  { value: 'أخضر', viewValue: 'أخضر' },
  { value: 'بلاتنوم', viewValue: 'بلاتنوم' }
];

noofemployes = [
   
  {value: 'أقل من 5', viewValue: 'أقل من 5'},
  {value: '5 إلى 10', viewValue: '5 إلى 10'},


  {value: '11 إلى 20', viewValue: '11 إلى 20'},

  {value: '21 إلى 50', viewValue: '21 إلى 50'},

  {value: 'أكثر من 50', viewValue: 'أكثر من 50'},



 
  ];

ageofcompany=[
  {value:'أقل من سنتين', viewValue: 'أقل من سنتين'},
{value: 'من 2 إلى 5 سنوات', viewValue: 'من 2 إلى 5 سنوات'},

{value: ' من 6 إلى 10 سنوات', viewValue: ' من 6 إلى 10 سنوات'},

{value: 'أكثر من 10 سنوات', viewValue: 'أكثر من 10 سنوات'},





]

legalstatcompany= [
  {value: 'ملكية فردية', viewValue: 'ملكية فردية'},
  {value: ' شركه ذات مسئوليه محدوده', viewValue: ' شركه ذات مسئوليه محدوده'},
  {value: 'شركة مساهمة مقفلة', viewValue: 'شركة مساهمة مقفلة'},
  {value: 'شركة مستثمر أجنبي محدودة', viewValue: 'شركة مستثمر أجنبي محدودة'},


 

];
city= [
  {value: 'الرياض', viewValue: 'الرياض'},
  {value: 'جدة', viewValue: 'جدة'},
  {value: 'الدمام', viewValue: 'الدمام'},
  {value: 'الخبر', viewValue: 'الخبر'},
  {value: 'الظهران', viewValue: 'الظهران'},
  {value: 'الأحساء', viewValue: 'الأحساء'},
  {value: 'القطيف', viewValue: 'القطيف'},
  {value: 'الجبيل', viewValue: 'الجبيل'},
  {value: 'الطائف', viewValue: 'الطائف'}, 
  {value: 'تبوك', viewValue: 'تبوك'},
  {value: 'أبها', viewValue: 'أبها'},
  {value: 'الباحة', viewValue: 'الباحة'},
  {value: 'جيزان', viewValue: 'جيزان'},
  {value: 'نجران', viewValue: 'نجران'},
  {value: 'حائل', viewValue: 'حائل'},

  {value: 'مكة المكرمة', viewValue: 'مكة المكرمة'},
  {value: 'المدينة المنورة', viewValue: 'المدينة المنورة'},
  {value: 'القصيم', viewValue: 'القصيم'},
  {value: 'الجوف', viewValue: 'الجوف'},
  {value: 'ينبع', viewValue: 'ينبع'},


 
];
 banks = [
    {value: 'البنك الأول', viewValue: 'البنك الأول'},
    {value: 'البنك العربي الوطني', viewValue: 'البنك العربي الوطني'},
    {value: 'مصرف الراجحي.', viewValue: 'مصرف الراجحي.'}, 
    {value: ' البنك السعودي الفرنسي', viewValue: ' البنك السعودي الفرنسي'},
    {value: 'مصرف الإنماء ', viewValue: 'مصرف الإنماء '},

    {value: 'بنك البلاد', viewValue: 'بنك البلاد'},
    {value: ' بنك مسقط', viewValue: ' بنك مسقط'},
    {value: 'بنك الجزيرة ', viewValue: 'بنك الجزيرة '},
    {value: ' دويتشه بنك', viewValue: ' دويتشه بنك'},
    {value: 'بنك الإمارات', viewValue: 'بنك الإمارات'},
    {value: 'بنك الخليج الدولي', viewValue: 'بنك الخليج الدولي'},
    {value: ' البنك الأهلي التجاري', viewValue: ' البنك الأهلي التجاري'},

    {value: 'بنك البحرين الوطني', viewValue: 'بنك البحرين الوطني'},

    {value: 'بنك الكويت الوطني', viewValue: 'بنك الكويت الوطني'},

    {value: 'البنك الوطني الباكستاني', viewValue: 'البنك الوطني الباكستاني'},

     {value: 'بنك الرياض', viewValue: 'بنك الرياض'},
    {value: 'البنك السعودي للإستثمار', viewValue: 'البنك السعودي للإستثمار'},
    {value: '(البنك السعودي الأمريكي (سامبا ', viewValue: '(البنك السعودي الأمريكي (سامبا '},
    {value: 'مؤسسة النقد العربي السعودي ', viewValue: 'مؤسسة النقد العربي السعودي '},
    // {value: 'SAUDI AMERICAN BANK', viewValue: 'SAUDI AMERICAN BANK'},
     {value:'(البنك السعودي البريطاني(ساب', viewValue:'(البنك السعودي البريطاني(ساب'},
    // {value: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI', viewValue: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI'},

    
  ];
accounts = [
  { value: 'INDB12545545', viewValue: 'INDB12545545' },
  { value: 'ANDB12545545', viewValue: 'ANDB12545545' },
  { value: 'AXDB12545545', viewValue: 'AXDB12545545' }
];
ibans = [
  { value: 'DFG4W42342424', viewValue: 'DFG4W42342424' },
  { value: 'egG4W42342424', viewValue: 'egG4W42342424' },
  { value: 'hiG4W42342424', viewValue: 'hiG4W42342424' }
];
anualincome = [
  { value: '1-50,000', viewValue: '1-50,000' },
  { value: '50,000-100,000', viewValue: '50,000-100,000' },
  { value: '100,000-1,50,000', viewValue: '100,000-1,50,000' },
  { value: '1,50,000-2,50,000', viewValue: '1,50,000-2,50,000' },
  { value: '2,50,000-5,00,000', viewValue: '2,50,000-5,00,000' },
  { value: '5,00,000 Above', viewValue: '5,00,000 Above' }
];
sourceincome = [
  { value: 'Salary', viewValue: 'Salary' },
  { value: 'FreeLancer', viewValue: 'FreeLancer' },
  { value: 'Other', viewValue: 'Other' },
 
];
jobstatus = [
  { value: 'BusinessOwner', viewValue: 'BusinessOwner' },
  { value: 'Student', viewValue: 'Student' },
  { value: 'Other', viewValue: 'Other' }
];
idvaliddate: string;
  bacicprofilesucessbacicprofileError: boolean;
  bacicprofilesucess: boolean;
  bacicprofileError: boolean;
  basicinfo: string;
  companyInfoSucess: string;
  companysuc: boolean;
  bankformShow=true
  profilebankError: boolean;
  submittedo: boolean;
  companyceError: boolean;
  companyceFileError: string;
  SignedInvoiceError: boolean;
  signedinvoiceFileError: string;
  bankaccountError: boolean;
  bankaccountletterFileError: string;
  purchaseorderError: boolean;
  purchaseOrderFileError: string;
  bankstaatmentsError: boolean;
  bankstatementFileError: string;
  mobileEmaiError: boolean;
  mobileEmailFileError: string;
  responseMessgae: string;
  registError: boolean;
  registuploaddocError: boolean;
  responseUploadDocMessgae: string;
  msgError: boolean;
  responseMessgaeer: string;

  constructor(private fb:FormBuilder, private deviceService:DeviceDetectorService,
    private deviceinfoservice:DeviceinfoserviceService,private sme:SmeborrowerService,
    private spinnerfull: NgxSpinnerService,
    private authService:AuthService) { 

      this.userdata = JSON.parse(sessionStorage.getItem('currentUser'))
      this.accesstoken = this.userdata.accesstoken;
  
    this.detectDevice();
    this.GetbasicProfile();
  }

  get investeryourInfoControllers() { return this.basicForm.controls }
  get f() { return this.personalForm.controls }
  get b() { return this.bankForm.controls }
  get o(){return this.otpForm.controls}

  ngOnInit() {
  
    this.deviceinfo = new deviceinfo();
    new Fingerprint2().get((components) => {
      this.getDeviceId = components;
      
       this.deviceinfo.deviceId = this.getDeviceId;
     
    }); 

    this.basicForm = this.fb.group({
      firstName:['',[Validators.required,Validators.pattern("^[a-zA-Z ]*$")]],
      lastName:['',[Validators.required,Validators.pattern("^[a-zA-Z ]*$")]],
      mobileNo:['',[Validators.required,Validators.minLength(5), Validators.maxLength(12), Validators.pattern("^[0-9]*$")]],
      riyadName:[''],
      email:['',[Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),Validators.required]]

    })

    this.personalForm = this.fb.group({
      annualIncome: ['', [Validators.required]],
      tradeName: ['', [Validators.required]],
      taxNumber: ['', [Validators.required]],
      crNo: ['', [Validators.required]],
      legalstatus: ['', [Validators.required]],
      namear: ['', [Validators.required]],
      companyclient: ['', [Validators.required]],
      age: ['', [Validators.required]],
      domain: ['', [Validators.required]],
      companyActivity: ['', [Validators.required]],
      city: ['', [Validators.required]],
      website: ['', [Validators.required]],
      employ: ['', [Validators.required]]


    });
    this.bankForm = this.fb.group({ 
      bankName : ['',[Validators.required]],
      iban : ['',[Validators.required]],
      accName : ['',[Validators.required]]
    });
    this.uploadfileForm = this.fb.group({
      bank_account_letter: [''],
      monthbankstatement:[''],
      purchaseorder:[''],
      mobileEmail:[''],
      signedIncvoice:[''],
      companyCr:['']
    }),


    this.otpForm=this.fb.group({
      otp: ['',[Validators.required,Validators.minLength(6), Validators.maxLength(6), Validators.pattern("^[A-Za-z0-9]*$")]],
    })

  }
  onFileChange(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadfileForm.get('mobileEmail').setValue(file);
    }
  }else{
    this.mobileEmailFileError="يجب أن يكون حجم رسالة الهاتف المحمول والبريد الإلكتروني أقل من 5 ميجابايت";
    this.mobileEmaiError = true;
    setTimeout(() => {
      this.mobileEmaiError = false;
    }, 3000)
  }
  } 
  onFileChange2(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadfileForm.get('monthbankstatement').setValue(file);
    }
  }else{
    this.bankstatementFileError="يجب أن تكون كشوف الحساب أقل من 5 ميغابايت";
    this.bankstaatmentsError = true;
    setTimeout(() => {
      this.bankstaatmentsError = false;
    }, 3000)
  }
  }
  onFileChange3(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadfileForm.get('purchaseorder').setValue(file);
    }
  }else{
    this.purchaseOrderFileError="يجب أن يكون ملف أمر الشراء أقل من 5 ميغابايت";
    this.purchaseorderError = true;
    setTimeout(() => {
      this.purchaseorderError = false;
    }, 3000)
  }
  }
  onFileChange4(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadfileForm.get('bank_account_letter').setValue(file);
    }
  }else{
    this.bankaccountletterFileError="يجب أن يكون خطاب الحساب المصرفي أقل من 5 ميغابايت";
    this.bankaccountError = true;
    setTimeout(() => {
      this.bankaccountError = false;
    }, 3000)
  }
  }
  onFileChange5(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadfileForm.get('signedIncvoice').setValue(file);
    }
  }else{
    this.signedinvoiceFileError="يجب أن يكون ملف الفاتورة الموقعة أقل من 5 ميغابايت";
    this.SignedInvoiceError = true;
    setTimeout(() => {
      this.SignedInvoiceError = false;
    }, 3000)
  }
  }
  onFileChange6(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadfileForm.get('companyCr').setValue(file);
    }
  }else{
    this.companyceFileError="يجب أن يكون ملف CR للشركة أقل من 5 ميغابايت";
    this.companyceError = true;
    setTimeout(() => {
      this.companyceError = false;
    }, 3000)
  }
  }

  updatebasic() {
    this.submitted = true;
  }

  updateprofile() {
    this.submitted1 = true;
    this.personalForm.get('dob').markAsTouched();
    this.personalForm.get('idexpiryDate').markAsTouched();
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
   
  }

  GetProfiles(tab) {
    if (tab.index == '0') {
      this.GetbasicProfile()
      this.ngOnInit();
this.basicotpShow = false;
this.BasicProfile = true;
    } else if (tab.index == '1') {
      this. basicotpShow1 = false;
      this.compform = true;
      this.ngOnInit();
      this.GetcompanyInformation();
    
    } else if (tab.index == '2') {
     this.ngOnInit();
      this.bankformShow = true;
      this.bankotpShow = false;
      this.GetBankDetails();
    } else if (tab.index == '3') {
      //  this.GetBankDetails();
      //  this.bankformShow = true;
      //  this.bankotpShow = false;
    }
  }


GetcompanyInformation() {
  const object: any = {}
  object['deviceType'] = 'Web';
  object['language'] = 'en';
  object['browserType'] = 'Web';
  object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
  object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
  object['browserVersion'] = this.deviceInfo.browser_version;
  object['osVersion'] = this.deviceInfo.os_version;
  object['osType'] = this.deviceInfo.os;
this.spinnerfull.show()
  this.sme.getCompanyInformation(object,this.accesstoken).subscribe(response=>
    this.getcompantInfoResponse(response))
}
getcompantInfoResponse(response){
  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){
if(response.company_response=='1000'){
this.personalForm.patchValue({

  legalstatus:response.company_details.LegalSatus,
 annualIncome: response.company_details.AnnualIncome,
  tradeName: response.company_details.BrandName,
  taxNumber: response.company_details.TaxNumber,
  crNo: response.company_details.CR_Number,
  namear: response.company_details.CompanyName,
  companyclient: response.company_details.NumberOfClients,
  age: response.company_details.CompanyAge,
  domain: response.company_details.Domain,
  companyActivity: response.company_details.CompanyActivity,

  city: response.company_details.City,
  website: response.company_details.Website,
  employ: response.company_details.NumberOfEmployees,
})
}else if(response.company_response=='1175'){

this.profileError = true;
     this.errorMessage = 'معلومات الشركة غير متوفرة';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);
}
  }else if(response.Token_Status=='1120'){
    this.profileError = true;
     this.errorMessage = 'غير مصرح';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);


  }else if(response.Token_Status=='1121'){
    this.profileError = true;
    this.errorMessage = 'انتهت صلاحية الرمز';
     setTimeout(() => {
       this.profileError = false;
     }, 5000);


  }
}
GetBankDetails(){
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   this.spinnerfull.show()
   this.authService.GetBankDetails(object,this.accesstoken).subscribe(response=>
    this.bankdetailsResponse(response))
}
bankdetailsResponse(response){



  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){

    if(response.bank_info_status=='1172'){

     
      this.bankForm.patchValue({
        bankName:response.bank_name,
        accName:response.bank_account_holder_name,
        iban:response.bank_iban,
        // virtualaccountNum:response.virtual_account_number,
        
      })



    }else if(response.bank_info_status=='1173'){
      this.profileError = true;
      this.errorMessage = 'التفاصيل المصرفية غير متوفرة';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);
    }
  }else if(response.Token_Status=='1120'){
      this.profileError = true;
     this.errorMessage = 'غير مصرح';
    
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = 'انتهت صلاحية الرمز';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }
}


  GetbasicProfile(){
  
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
   //object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
   this.spinnerfull.show()
   this.authService.GetbasicProfile(object,this.accesstoken).subscribe(response=>
    this.basicprofileResponse(response))
  }
  basicprofileResponse(response){
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
    if(response.basic_profile_status=='1000'){
      this.basicForm.patchValue({
        firstName:response.first_name,
        lastName:response.last_name,
        mobileNo:response.mobile_number,
        riyadName:response.virtual_account_number,
        email:response.email,
      })
    }
  }else if(response.Token_Status=='1120'){
    this.profileError = true;
    this.errorMessage = '  غير مصرح';
   
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.profileError = true;
    this.errorMessage = 'انتهت صلاحية الرمز';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }
  }

  UpdateBasicDetails(){
    this.submitted=true;
    this.basicForm.get('mobileNo').markAsTouched();
    this.basicForm.get('firstName').markAsTouched();
    this.basicForm.get('lastName').markAsTouched();
  
  if(this.basicForm.valid){
    this.submitted=false;
    const object: any = {}
    object['mobileNumber'] = this.basicForm.value.mobileNo;
    object['firstName'] = this.basicForm.value.firstName;
    object['lastName'] = this.basicForm.value.lastName;
  
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
     this.spinnerfull.show()
     this.authService.updateBasicInfoOtp(object,this.accesstoken).subscribe(response=>
      this.updatebasicinfootpres(response))
     }
  
  }
  updatebasicinfootpres(response){
    
    // console.log(response)
    this.spinnerfull.hide()
    if(response.update_profile=='1000'){
      this.BasicProfile=false;
  this.basicotpShow=true;

    }else if(response.update_profile=='1017'){
      this.profileError = true;
      this.errorMessage = 'رقم الهاتف المحمول فارغ';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.update_profile=='1018'){
      this.profileError = true;
      this.errorMessage = 'رقم الجوال غير صالح';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.update_profile=='1019'){
      this.profileError = true;
      this.errorMessage = 'الاسم الأول فارغ';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.update_profile=='1020'){
      this.profileError = true;
      this.errorMessage = 'الاسم الأخير فارغ';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.update_profile=='1021'){
      this.profileError = true;
      this.errorMessage = 'لا يسمح باستخدام الأحرف الخاصة في الاسم الأول';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.update_profile=='1022'){
      this.profileError = true;
      this.errorMessage = 'الأحرف الخاصة لا يسمح باسم اسم';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }
  }
  BasicInfoOtpSubmit(){
    this.submittedo=true;
    if(this.otpForm.valid){
      const object: any = {}
      object['mobileNumber'] = this.basicForm.value.mobileNo;
      object['firstName'] = this.basicForm.value.firstName;
      object['lastName'] = this.basicForm.value.lastName;
        object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
       object['otp'] =this.otpForm.value.otp;
       this.spinnerfull.show()
       this.authService.basicInfoOtpSubmit(object,this.accesstoken).subscribe(response=>{
         this.basicInfoOtpSubmitResponse(response)
       }
        )
  
    }
    // else{
    //   this.profileError = true;
    //   this.errorMessage = 'OTP Required';
    //   setTimeout(() => {
    //     this.profileError = false;
    //   }, 3000);
    // }
  }
  
  basicInfoOtpSubmitResponse(response){
    // console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
      if(response.update_profile=='1000'){
        this.submitted=false
        this.bacicprofilesucess = true;
        this.basicinfo = 'تم تحديثها بنجاح';
        setTimeout(() => {
          this.otpForm.reset();
          this.BasicProfile=true;
        this.basicotpShow=false;
          this.bacicprofilesucess = false;
        }, 3000);
      }else  if(response.update_profile=='1001'){
        this.bacicprofileError = true;
            this.errorMessage = 'فشل';
            setTimeout(() => {
              this.bacicprofileError = false;
            }, 3000);
      }else  if(response.update_profile=='1090'){
        this.bacicprofileError = true;
            this.errorMessage = 'حقل كلمة المرور. المؤقتة فارغ';
            setTimeout(() => {
              this.bacicprofileError = false;
            }, 3000);
      }else  if(response.update_profile=='1091'){
        this.bacicprofileError = true;
        this.errorMessage = 'كلمة المرور المؤقتة غير صالحة';
        setTimeout(() => {
          this.bacicprofileError = false;
        }, 3000);
      }else  if(response.update_profile=='1092'){
        this.bacicprofileError = true;
        this.errorMessage = 'كلمة المرور المؤقتة غير صالحة';
        setTimeout(() => {
          this.bacicprofileError = false;
        }, 3000);
      }else  if(response.update_profile=='1093'){
        this.bacicprofileError = true;
        this.errorMessage = 'كلمة المرور المؤقتة غير صالحة';
        setTimeout(() => {
          this.bacicprofileError = false;
        }, 3000);
      }else  if(response.update_profile=='1094'){
        this.bacicprofileError = true;
        this.errorMessage = 'انتهت صلاحية كلمة المرور المؤقتة';
        setTimeout(() => {
          this.bacicprofileError = false;
        }, 3000);
      }
       }else if(response.Token_Status=='1120'){
        this.bacicprofileError = true;
        this.errorMessage = '  غير مصرح';
     
        setTimeout(() => {
          this.bacicprofileError = false;
        }, 3000);
      }else if(response.Token_Status=='1121'){
        this.bacicprofileError = true;
        this.errorMessage = 'انتهت صلاحية الرمز';
        setTimeout(() => {
          this.bacicprofileError = false;
        }, 3000);
      }
  }
  updatecompanyInfo() {
    this.submitted1 = true;
   // this.basicotpShow1 = true;
   // this.compform = false;
    if (this.personalForm.valid) {
      // alert("++++++++++++")
      const object: any = {}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['device_type'] = 'Web';
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
      object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId;
      object['company_Name'] = 'abcd';
      object['brand_Name'] = this.personalForm.value.tradeName;
      object['company_CR_Number'] = this.personalForm.value.crNo;
      object['company_VAT_Number'] = this.personalForm.value.taxNumber;
      object['company_Legal_Status'] = this.personalForm.value.legalstatus;
      object['company_Years_in_Business'] = this.personalForm.value.age;
      object['company_Number_of_Clients'] = this.personalForm.value.companyclient;
      object['company_Number_of_Employees'] = this.personalForm.value.employ;
      object['company_Activity'] = this.personalForm.value.companyActivity;
      object['annual_Income'] = this.personalForm.value.annualIncome;
      object['company_City'] = this.personalForm.value.city;
      object['company_Website'] = this.personalForm.value.website;
      object['domains'] = this.personalForm.value.domain;
      this.spinnerfull.show()
      this.sme.updatecompanyotp(object, this.accesstoken).subscribe(res => {
        // console.log(res)
        this.spinnerfull.hide()
        if (res.Token_Status == '1119') {
          if (res.update_company_info_otp_status == '1000') {
            // this.errmsg1 = 'SUCCESS';
            this.personalinfootpShow = true;
            this.compform = false;
          }

          else if (res.update_company_info_otp_status == '1002') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1003') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1004') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1005') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1006') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1007') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1008') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1009') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1010') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1011') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1012') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1015') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1016') {
            this.errmsg1 = 'حدث خطا ما';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1027') {
            this.errmsg1 = 'اسم العلامة التجارية فارغ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1028') {
            this.errmsg1 = 'اسم الشركة/المؤسسة فارغ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1029') {
            this.errmsg1 = 'رقم السجل التجاري فارغ ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1030') {
            this.errmsg1 = 'الرقم الضريبي فارغ ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1031') {
            this.errmsg1 = 'الوضع القانوني للشركة فارغ ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1032') {
            this.errmsg1 = ' سنوات الشركة/المؤسسة في الأعمال التجارية فارغة';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1033') {
            this.errmsg1 = ' عدد عملاء الشركة فارغ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1034') {
            this.errmsg1 = ' عدد الشركة من الموظفين فارغين';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1038') {
            this.errmsg1 = 'مدينة التي بها الشركة فارغة ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }
          else if (res.update_company_info_otp_status == '1039') {
            this.errmsg1 = 'موقع الشركة/المؤسسة  فارغ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }

          else if (res.update_company_info_otp_status == '1176') {
            this.errmsg1 = ' نشاط الشركة/المؤسسة فارغ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }

          else if (res.update_company_info_otp_status == '1132') {
            this.errmsg1 = ' الدخل السنوي فارغ';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }


          else if (res.update_company_info_otp_status == '1179') {
            this.errmsg1 = ' المجالات فارغة';
            this.msgdis1 = true;
            setTimeout(() => {
              this.msgdis1 = false;
            }, 3000);
          }


        }
        else if (res.Token_Status == '1120') {
          this.errmsg1 = ' غير مصرح';
         
          this.msgdis1 = true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if (res.Token_Status == '1121') {
          this.errmsg1 = 'انتهت صلاحية الرمز ';
          this.msgdis1 = true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }


      })


    }else{
      alert("------------")
    }

  }

  UpdatecompanyInfoOtpSubmit() {
    this.submitted=true
    if (this.otpForm.valid) {
      const object: any = {}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['device_type'] = 'Web';
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
      object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId;
      object['company_Name'] = 'abcd';
      object['brand_Name'] = this.personalForm.value.tradeName;
      object['company_CR_Number'] = this.personalForm.value.crNo;
      object['company_VAT_Number'] = this.personalForm.value.taxNumber;
      object['company_Legal_Status'] = this.personalForm.value.legalstatus;
      object['company_Years_in_Business'] = this.personalForm.value.age;
      object['company_Number_of_Clients'] = this.personalForm.value.companyclient;
      object['company_Number_of_Employees'] = this.personalForm.value.employ;
      object['company_Activity'] = this.personalForm.value.companyActivity;
      object['annual_Income'] = this.personalForm.value.annualIncome;
      object['company_City'] = this.personalForm.value.city;
      object['company_Website'] = this.personalForm.value.website;
      object['domains'] = this.personalForm.value.domain;
      object['otp'] = this.otpForm.value.otp;
      // console.log(object)
      this.spinnerfull.show()
      this.sme.updatecompanyotpverified(object, this.accesstoken).subscribe(res => {
        // console.log(res)
        this.spinnerfull.hide()
        if (res.Token_Status == '1119') {
          if (res.update_company_info_status == '1000') {
            
            this.companyInfoSucess = 'تم تحديث معلومات الشركة بنجاح';
            this.companysuc = true;
            setTimeout(() => {
              this.basicotpShow1=false
              this.compform=true
              this.submitted1=false
              this.submitted=false
              this.companysuc = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1002') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1003') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1004') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1005') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1006') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1007') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1008') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1009') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1010') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1011') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1012') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1015') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1016') {
            this.errmsg = 'حدث خطا ما';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1027') {
            this.errmsg = 'اسم العلامة التجارية فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1028') {
            this.errmsg = 'اسم الشركة فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1029') {
            this.errmsg = 'رقم السجل التجاري فارغ ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1030') {
            this.errmsg = 'الرقم الضريبي فارغ ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1031') {
            this.errmsg = 'الوضع القانوني للشركة فارغ ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1032') {
            this.errmsg = ' سنوات الشركة/المؤسسة في الأعمال التجارية فارغة';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1033') {
            this.errmsg = ' عدد عملاء الشركة فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1034') {
            this.errmsg = ' عدد الشركة من الموظفين فارغين';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1038') {
            this.errmsg = 'مدينة التي بها الشركة فارغة ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1039') {
            this.errmsg = 'موقع الشركة/المؤسسة  فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }

          else if (res.update_company_info_status == '1176') {
            this.errmsg = ' نشاط الشركة/المؤسسة فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }

          else if (res.update_company_info_status == '1132') {
            this.errmsg = ' الدخل السنوي فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }

          else if (res.update_company_info_status == '1090') {
            this.errmsg = 'حقل كلمة المرور. المؤقتة فارغ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1091') {
            this.errmsg = 'كلمة المرور المؤقتة غير صالحة ';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1092') {
            this.errmsg = ' كلمة المرور المؤقتة غير صالحة';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1093') {
            this.errmsg = ' كلمة المرور المؤقتة غير صالحة';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }
          else if (res.update_company_info_status == '1094') {
            this.errmsg = 'انتهت صلاحية كلمة المرور المؤقتة';
            this.msgdis = true;
            setTimeout(() => {
              this.msgdis = false;
            }, 3000);
          }



        }
        else if (res.Token_Status == '1120') {
          this.errmsg = 'غير مصرح';
     
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if (res.Token_Status == '1121') {
          this.errmsg = 'انتهت صلاحية الرمز ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
      })


    }
  }


  updatebank() {
    this.submitted2 = true;
    if(this.bankForm.valid){
      const object:any={}
        object['browserType'] = this.deviceInfo.browser;
        object['browserVersion'] = this.deviceInfo.browser_version;
        object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
        object['osVersion'] = this.deviceInfo.os_version;
        object['osType'] = this.deviceInfo.os;
        object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
        object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
        object['language'] = 'en';
        object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
        object['bankName'] = this.bankForm.value.bankName
        object['ibanNumber'] = this.bankForm.value.iban;
        object['acountName'] = this.bankForm.value.accName;
        object['deviceType']='Web'
        this.spinnerfull.show()
        this.authService.updateBankDetailsOtp(object,this.accesstoken).subscribe(response=>
          this.updatebankDertOtpResponse(response))


         

    }
  }

  updatebankDertOtpResponse(response){
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
    if(response.Bank_Info_Otp_Response=='1000'){
      this.bankformShow=false;
      this.bankotpShow=true;
  
    }else if(response.Bank_Info_Otp_Response=='1001'){
  
      this.profileError = true;
      this.errorMessage = 'فشل';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.Bank_Info_Otp_Response=='1054'){
  
      this.profileError = true;
      this.errorMessage = 'يجب ألا يكون اسم البنك فارغًا';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.Bank_Info_Otp_Response=='1055'){
      this.profileError = true;
      this.errorMessage = 'لا يجب أن يكون بنك IBAN فارغًا';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
  
    }else if(response.Bank_Info_Otp_Response=='1145'){
      this.profileError = true;
      this.errorMessage = 'اسم حساب البنك فارغ';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
  
    }else if(response.Bank_Info_Otp_Response=='1003'){
      this.profileError = true;
      this.errorMessage = 'حدث خطا ما';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
  
    }else if(response.Bank_Info_Otp_Response=='1004'){
      this.profileError = true;
      this.errorMessage = 'حدث خطا ما';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
  
    }else if(response.Bank_Info_Otp_Response=='1005'){
  
      this.profileError = true;
      this.errorMessage = 'حدث خطا ما';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }
    }else if(response.Token_Status=='1120'){
      this.profileError = true;
      this.errorMessage = ' غير مصرح';
    
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = 'انتهت صلاحية الرمز';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }
  }
  UpdatebankInfoOtpSubmit(){
    this.submitted=true
    if( this.otpForm.valid){
    const object:any={}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
      object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      object['bankName'] = this.bankForm.value.bankName
        object['ibanNumber'] = this.bankForm.value.iban;
        object['acountName'] = this.bankForm.value.accName;
      object['otp'] = this.otpForm.value.otp;
      object['deviceType']='Web'
      this.spinnerfull.show()
      this.authService.updateBankDetails(object,this.accesstoken).subscribe(response=>
        this.updatebankdetResponse(response))
      }
  }
  updatebankdetResponse(response){
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
      if(response.Bank_Info_Response=='1000'){
        //alert("Bank Details Updated SucessFully")
      
       
 
        // this.bankformShow=true
        // this.bankotpShow=false;
        this.submitted2 = false;
        this.SucessMessage = 'تمت إضافة معلومات البنك بنجاح';
     
        this.sucessinfo = true;
        setTimeout(() => {
          this.bankformShow=true
        this.bankotpShow=false;
        this.otpForm.reset();
        this.submitted=false;
          this.sucessinfo = false;
        }, 3000);
      }else  if(response.Bank_Info_Response=='1001'){
        this.profilebankError = true;
            this.errorMessage = 'فشل';
            setTimeout(() => {
              this.profilebankError = false;
            }, 3000);
      }else  if(response.Bank_Info_Response=='1090'){
        this.profilebankError = true;
            this.errorMessage = 'حقل كلمة المرور. المؤقتة فارغ';
            setTimeout(() => {
              this.profilebankError = false;
            }, 3000);
      }else  if(response.Bank_Info_Response=='1091'){
        this.profilebankError = true;
        this.errorMessage = 'كلمة المرور المؤقتة غير صالحة ';
        setTimeout(() => {
          this.profilebankError = false;
        }, 3000);
      }else  if(response.Bank_Info_Response=='1092'){
        this.profilebankError = true;
        this.errorMessage = ' كلمة المرور المؤقتة غير صالحة';
        setTimeout(() => {
          this.profilebankError = false;
        }, 3000);
      }else  if(response.Bank_Info_Response=='1093'){
        this.profilebankError = true;
        this.errorMessage = ' كلمة المرور المؤقتة غير صالحة';
        setTimeout(() => {
          this.profilebankError = false;
        }, 3000);
      }else  if(response.Bank_Info_Response=='1094'){
        this.profilebankError = true;
        this.errorMessage = 'انتهت صلاحية كلمة المرور المؤقتة';
        setTimeout(() => {
          this.profilebankError = false;
        }, 3000);
      }
       }else if(response.Token_Status=='1120'){
        this.profilebankError = true;
        this.errorMessage = 'غير مصرح';
    
        setTimeout(() => {
          this.profilebankError = false;
        }, 3000);
      }else if(response.Token_Status=='1121'){
        this.profilebankError = true;
        this.errorMessage = 'انتهت صلاحية الرمز';
        setTimeout(() => {
          this.profilebankError = false;
        }, 3000);
      }
  }

  otpBack2(){
    this.basicotpShow=false
    this.BasicProfile=true;
  }
  otpBack1(){
    this.personalinfootpShow=false;
    this.compform=true;
  }
  otpbankBack(){
    this.bankotpShow=false;
    this.bankformShow=true;
  }

  get u() {
    return this.uploadfileForm.controls;
  }

  @ViewChild('myInput')
  myInputVariable: ElementRef;
  @ViewChild('myInput1')
  myInputVariable1: ElementRef;
  @ViewChild('myInput2')
  myInputVariable2: ElementRef;
  @ViewChild('myInput3')
  myInputVariable3: ElementRef;
  @ViewChild('myInput4')
  myInputVariable4: ElementRef;
  @ViewChild('myInput5')
  myInputVariable5: ElementRef;
  
  
    uploadform() {
      this.submitted2 = true;
      this.submitted5=true;
     this.detectDevice();
   
     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
     if(this.data!=null || this.data !=''){
       this.accesstoken= this.data.accesstoken;
     }
  
  
     if(this.uploadfileForm.value.mobileEmail  !='' || this.uploadfileForm.value.monthbankstatement  !='' || this.uploadfileForm.value.purchaseorder  !=''
     || this.uploadfileForm.value.bank_account_letter  !='' || this.uploadfileForm.value.signedIncvoice  !='' || this.uploadfileForm.value.companyCr  !='' ) {
   

      this.responseMessgaeer = ''
        this.submitted5 = false;
        this.msgError = false;
        const formData = new FormData();
        // formData.append('file',this.uploadfileForm.get('mobileEmail').value);
  
        // formData.append('authorizedMobnEmailLetter',this.uploadfileForm.value.mobileEmail);
  
        // formData.append('file',this.uploadfileForm.get('monthbankstatement').value);
  
        // formData.append('threeMonthsBankStatements',this.uploadfileForm.value.monthbankstatement);
  
        // formData.append('file',this.uploadfileForm.get('purchaseorder').value);
  
        // formData.append('purchaseOrderrProjectContract',this.uploadfileForm.value.purchaseorder);
        // formData.append('file',this.uploadfileForm.get('bank_account_letter').value);
  
        // formData.append('bankAccountLetter',this.uploadfileForm.value.bank_account_letter);
  
        // formData.append('file',this.uploadfileForm.get('signedIncvoice').value);
  
        // formData.append('signedInvoice',this.uploadfileForm.value.signedIncvoice);
  
        // formData.append('file',this.uploadfileForm.get('companyCr').value);
  
        // formData.append('crCertificate',this.uploadfileForm.value.companyCr);





        var f = new File([""], "filename");
        
      
  
        if(this.uploadfileForm.value.mobileEmail ==''){
               formData.append('authorizedMobnEmailLetter',f);
              
            }else{
              formData.append('authorizedMobnEmailLetter',this.uploadfileForm.value.mobileEmail);
            }
  
            if(this.uploadfileForm.value.monthbankstatement ==''){
              formData.append('threeMonthsBankStatements',f);
             
           }else{
             formData.append('threeMonthsBankStatements',this.uploadfileForm.value.monthbankstatement);
           }
  
           if(this.uploadfileForm.value.purchaseorder ==''){
            formData.append('purchaseOrderrProjectContract',f);
           
         }else{
           formData.append('purchaseOrderrProjectContract',this.uploadfileForm.value.purchaseorder);
         }
  
  
  
         if(this.uploadfileForm.value.bank_account_letter ==''){
            
          formData.append('bankAccountLetter',f);
        }else{
         
        formData.append('bankAccountLetter',this.uploadfileForm.value.bank_account_letter);
        }
         
     
         if(this.uploadfileForm.value.signedIncvoice ==''){
            
              formData.append('signedInvoice',f);
            }else{
             
            formData.append('signedInvoice',this.uploadfileForm.value.signedIncvoice);
            }
  
  
  
            if(this.uploadfileForm.value.companyCr ==''){
            
              formData.append('crCertificate',f);
            }else{
             
            formData.append('crCertificate',this.uploadfileForm.value.companyCr);
            }
       
        formData.append('language','en');
     
        formData.append('deviceType',this.deviceinfoservice.deviceinfo.deviceType);
        formData.append('browserType',this.deviceinfoservice.deviceinfo.browserType);
        formData.append('browserVersion',this.deviceinfoservice.deviceinfo.browserVersion);
        formData.append('osType',this.deviceinfoservice.deviceinfo.osType);
  
        formData.append('osVersion',this.deviceinfoservice.deviceinfo.osVersion);
  
        formData.append('deviceId	',this.deviceinfoservice.deviceinfo.deviceId);
        formData.append('iPAddress	',this.deviceinfoservice.deviceinfo.ipAdress);
        formData.append('latitude	',this.deviceinfoservice.deviceinfo.latitude);
        formData.append('longitude	',this.deviceinfoservice.deviceinfo.logintude);
        
  
     // this.spinner = true;
         this.spinnerfull.show();
        this.authService.uploadsmeprofiledoc(formData,this.accesstoken).subscribe(response =>{
          this.spinnerfull.hide();
       
          if(response.upload_documents_response == 1000){
            this.submitted5=false;
            this.responseUploadDocMessgae = "تم تحميل المستند بنجاح";
            
                      this.registuploaddocError = true;
                      setTimeout(() => {
                       
                        this.registuploaddocError = false;
                        this.myInputVariable.nativeElement.value = "";
                        this.myInputVariable1.nativeElement.value = "";
                        this.myInputVariable2.nativeElement.value = "";
                        this.myInputVariable3.nativeElement.value = "";
                        this.myInputVariable4.nativeElement.value = "";
                        this.myInputVariable5.nativeElement.value = "";
  
                   
                      }, 3000)
          }else if(response.upload_documents_response== 1001){
            this.responseMessgae = "فشل";
           
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1002){
            this.responseMessgae = "حدث خطا ما";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
        
          else if(response.upload_documents_response== 1003){
            this.responseMessgae = "حدث خطا ما";
          
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1004){
            this.responseMessgae = "حدث خطا ما";
          
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1005){
        
             this.responseMessgae = "حدث خطا ما";
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1006){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1007){
            this.responseMessgae = "حدث خطا ما";
            this.spinnerfull.hide();
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1008){
            this.responseMessgae = "حدث خطا ما";
            this.spinnerfull.hide();
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1009){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1010){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1011){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1012){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1013){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1014){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1015){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response==1016){
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1040){
            this.spinnerfull.hide();
            this.responseMessgae = "معرف التسجيل فارغ";   
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1041){
            this.spinnerfull.hide();
            this.responseMessgae =  "يجب أن يكون معرف التسجيل رقميًا";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1042){
            this.spinnerfull.hide();
            this.responseMessgae = "معرف التسجيل غير صالح";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1074){
            this.spinnerfull.hide();
            this.responseMessgae = "ملف خطاب الحساب المصرفي فارغ";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
    
          else if(response.upload_documents_response== 1075){
            this.spinnerfull.hide();
            this.responseMessgae = "يجب أن يكون حجم ملف خطاب الحساب المصرفي أقل من 5 ميغابايت";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          } 
          else if(response.upload_documents_response== 1076){
            this.spinnerfull.hide();
            this.responseMessgae = "تنسيقات ملفات خطابات الحسابات المصرفية هي JPG و PNG و XLSX و XLS و PDF";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }

  
else if(response.upload_documents_response== 1077){
  this.spinnerfull.hide();
  this.responseMessgae = "ملف الفاتورة الموقع فارغ";

            this.registError = true;
            setTimeout(() => {
              this.registError = false;
            }, 3000)
}
else if(response.upload_documents_response== 1078){
  this.spinnerfull.hide();
  this.responseMessgae = "يجب أن يكون حجم ملف الفاتورة الموقع أقل من 5 ميغا بايت";

            this.registError = true;
            setTimeout(() => {
              this.registError = false;
            }, 3000)
}
else if(response.upload_documents_response== 1079){
  this.spinnerfull.hide();
  this.responseMessgae = "تنسيقات ملف الفاتورة الموقعة هي PNG JPG PDF XLS XLSX";

            this.registError = true;
            setTimeout(() => {
              this.registError = false;
            }, 3000)
}
else if(response.upload_documents_response== 1080){
  this.spinnerfull.hide();
  this.responseMessgae = "ملف شهادة التسجيل التجاري للشركة فارغ";

            this.registError = true;
            setTimeout(() => {
              this.registError = false;
            }, 3000)
}
else if(response.upload_documents_response== 1081){
  this.spinnerfull.hide();
  this.responseMessgae = "يجب أن يكون حجم ملف شهادة التسجيل التجاري للشركة أقل من 5 ميغا بايت";

            this.registError = true;
            setTimeout(() => {
              this.registError = false;
            }, 3000)
}
else if(response.upload_documents_response== 1082){
  this.spinnerfull.hide();
  this.responseMessgae = "تنسيقات ملف شهادة التسجيل التجاري للشركة هي PNG JPG PDF XLS XLSX";

            this.registError = true;
            setTimeout(() => {
              this.registError = false;
            }, 3000)
}
         


          else if(response.upload_documents_response== 1120){
            this.spinnerfull.hide();
            this.responseMessgae = "غير مصرح";   
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
          else if(response.upload_documents_response== 1121){
            this.spinnerfull.hide();
            this.responseMessgae = "انتهت صلاحية الرمز";   
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
          
  
        
          else {
            this.spinnerfull.hide();
            this.responseMessgae = "حدث خطا ما";   
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
        })
       
       
      
      // else{
      //   this.msg = 'PLEASE UPLOAD THE DOCUMENTS';
       
        
      //   this.msgError = true;
      // }
    }


    else {
      this.responseMessgaeer = 'اختر وثيقة واحدة على الأقل'
    }
  
  
  



  }








}