import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AraccmovComponent } from './araccmov/araccmov.component';
import { ArmyloansComponent } from './armyloans/armyloans.component';
import { ArprofileComponent } from './arprofile/arprofile.component';
import { Arloan2Component } from './arloan2/arloan2.component';
import { ArdashComponent } from './ardash/ardash.component';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';



const routes: Routes = [
  {path:'webappsmesettings',component:ManageaccountComponent},
  {path:'webappsmeaccmov',component:AraccmovComponent},
  {
path:'webappsmemyloans',component:ArmyloansComponent
  },
  {path:'webappsmeprofile',component:ArprofileComponent},
  {path:'webappsmeloan/:id',component:Arloan2Component},
  {path:'webappsmedashboard',component:ArdashComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ArabicsmwwebappRoutingModule { }
