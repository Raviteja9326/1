import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-artermsandconditions',
  templateUrl: './artermsandconditions.component.html',
  styleUrls: ['./artermsandconditions.component.scss']
})
export class ArtermsandconditionsComponent implements OnInit {
  list: any;
  accesstoken: any;
  acceptsuccess: boolean;
  acceptmsgsucc: string;
  accessfail: boolean;
  accmsgfail: string;

  constructor(private router:Router,public dialogRef: MatDialogRef<ArtermsandconditionsComponent>,
    private auth:AuthService,private spinnerfull: NgxSpinnerService) { }

  ngOnInit(): void {
  }
  closemark(){
    this.dialogRef.close();
    this.router.navigate(['/arhome']);
    sessionStorage.clear();
   
  }
  acceptterms() {

    this.list = JSON.parse(sessionStorage.getItem('currentUser'))

    if(this.list !=null){
      console.log(this.list.accesstoken);
      this.accesstoken = this.list.accesstoken
 
    }

    this.spinnerfull.show()

    this.auth.Accepttermsandpolicy(this.list.accesstoken).subscribe(res =>{
      console.log(res)
      this.spinnerfull.hide()


      if(res.Accept_Terms_And_Conditions_Response == '1000')
 {

  this.acceptsuccess = true;
   this.acceptmsgsucc = 'تم قبولها بنجاح'

   setTimeout(() => {
    this.acceptsuccess = false;

    this.dialogRef.close();
    const object:any ={}

    object['FirstName']  = this.list.FirstName;
    object['LastName']     = this.list.LastName;
    object['LastLogin']    = this.list.LastLogin;
    object['isMobileVerified']   = this.list.isMobileVerified;
    object['isEmailVerified']   = this.list.isEmailVerified;
    object['accesstoken']   = this.list.accesstoken;
    object['ProfilePic'] = this.list.ProfilePic;
    object['id']=this.list.id
    object['profileStatus']=this.list.profileStatus;
    if(this.list.isCompnayInformationProvided   &&  this.list.isDcoumentsInformationProvided) {
     object['redirect'] = this.list.redirect;
     object['isBankInformationProvided']    = this.list.isBankInformationProvided;
     object['isCompnayInformationProvided']    = this.list.isCompnayInformationProvided;
     object['isDcoumentsInformationProvided']   = this.list.isDcoumentsInformationProvided;
     object['isShareHolderInformationProvided'] = this.list.isShareHolderInformationProvided;
     object['isPolicyAccepted'] = 'Yes';
     object['isTermsAccepted'] = 'Yes';
    } 

    else {
     object['redirect'] = this.list.redirect;
     object['isPolicyAccepted']  = 'Yes';
     object['isBankInfoProvided']   = this.list.isBankInfoProvided;
     object['isInvestorInfoProvided']  = this.list.isInvestorInfoProvided;
     object['isTermsAccepted']  = 'Yes';
     object['isBankAccountLetterUploaded'] = this.list.isBankAccountLetterUploaded;
    }


    sessionStorage.setItem('currentUser',JSON.stringify(object))


   }, 3000);
 } 


 else if(res.Accept_Terms_And_Conditions_Response == '1001') {

  this.accessfail = true;
  
  this.accmsgfail = 'فشل';
  
  setTimeout(() => {
    
    
    this.accessfail = false;
  }, 3000);

 }

})

  }
}
