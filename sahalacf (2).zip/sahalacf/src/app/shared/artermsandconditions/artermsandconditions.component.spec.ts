import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtermsandconditionsComponent,  } from './artermsandconditions.component';

describe('TermsandconditionsComponent', () => {
  let component: ArtermsandconditionsComponent;
  let fixture: ComponentFixture<ArtermsandconditionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArtermsandconditionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtermsandconditionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
