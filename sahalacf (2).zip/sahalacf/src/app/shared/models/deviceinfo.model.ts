export class deviceinfo {
    deviceId: string;
    deviceType: string;
    deviceService: string;
    latitude: string;
    logintude: string;
    longitude: string;
    ipAdress: string;
    browserType:string;
    browserVersion:string;
    osType:string;
    osVersion:string;

    constructor(devicedata?) {
        this.deviceId = '';
        this.deviceType = 'Web';
        this.latitude = '';
        this.logintude = '';
        this.ipAdress = '';
       this. browserType ='';
       this. browserVersion = '';
       this. osType ='';
        this.osVersion = '';
    }
}

