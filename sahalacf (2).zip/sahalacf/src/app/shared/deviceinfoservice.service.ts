
import { Injectable } from '@angular/core';
import { deviceinfo } from './models/deviceinfo.model';
import { HttpClient } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';

declare var Fingerprint2: any;
@Injectable({
  providedIn: 'root'
})
export class DeviceinfoserviceService {
  getDeviceId;
  deviceInfo = null;
  deviceId;
  geolocationPosition: object;
  longitude: string;
  latitude: string;
  ipAddress: string;
  deviceinfo: deviceinfo;
  constructor(private http: HttpClient,private deviceService: DeviceDetectorService) {
    this.getInfo();
  }
  getInfo() {

    this.deviceinfo = new deviceinfo();

    setTimeout(() => {
      new Fingerprint2().get((components) => {
     
        this.getDeviceId = components;
       
     
        this.deviceinfo.deviceId = this.getDeviceId;
  
       
      });
    }, 1000);


    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
    
      this.deviceinfo.ipAdress = (geoLocationResponse.ip);
    });
    this.geolocationPosition = {};
    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
        position => {
          this.geolocationPosition = position;
          // console.log(this.geolocationPosition);
          this.showPosition(position);
        }
      ); 
    }

    this.epicFunction();
    // console.log(this.deviceInfo)
  }
  showPosition(position) {
    if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
      this.latitude = position.coords.latitude;
      this.longitude = position.coords.longitude;
      this.deviceinfo.latitude = String(position.coords.latitude);
      this.deviceinfo.logintude = String(position.coords.longitude);

    } else {

    }
  
  }


  epicFunction() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    const isMobile = this.deviceService.isMobile();
    const isTablet = this.deviceService.isTablet();
    const isDesktopDevice = this.deviceService.isDesktop();
    //  console.log(this.deviceInfo);
    // console.log(isMobile);  
    // console.log(isTablet); 
    // console.log(isDesktopDevice);
   

     this.deviceinfo.browserType = this.deviceService.browser;
    
     this.deviceinfo.browserVersion = this.deviceService.browser_version;
     this.deviceinfo.osType = this.deviceService.os;
     this.deviceinfo.osVersion = this.deviceService.os_version;
  }
  
}
