import { WhitespaceDirective } from './whitespace.directive';

describe('WhitespaceDirective', () => {
  it('should create an instance', () => {
    const directive = new WhitespaceDirective();
    expect(directive).toBeTruthy();
  });
});
