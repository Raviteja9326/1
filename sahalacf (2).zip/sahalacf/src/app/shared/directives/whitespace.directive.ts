import { Directive } from '@angular/core';
import { AbstractControl, ValidatorFn } from '@angular/forms';
@Directive({
  selector: '[appWhitespace]'
})
export class WhitespaceDirective {

  constructor() { 
    console.log('whitwspace')
  }

  trimValidator: ValidatorFn = (control: AbstractControl) => {
    if (control.value.startsWith(' ')) {
      return {
        'trimError': { value: 'control has leading whitespace' }
      };
    }
    if (control.value.endsWith(' ')) {
      return {
        'trimError': { value: 'control has trailing whitespace' }
      };
    }
  
    return null;
  };

}
