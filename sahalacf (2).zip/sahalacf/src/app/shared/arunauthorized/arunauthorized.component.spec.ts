import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArunauthorizedComponent } from './arunauthorized.component';

describe('ArunauthorizedComponent', () => {
  let component: ArunauthorizedComponent;
  let fixture: ComponentFixture<ArunauthorizedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArunauthorizedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArunauthorizedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
