import { Component, OnInit ,Inject} from '@angular/core';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { interval, Subscription } from 'rxjs';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { ArwithdrawdialogComponent } from 'src/app/arwithdrawdialog/arwithdrawdialog.component';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from '../deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';


@Component({
  selector: 'app-arunauthorized',
  templateUrl: './arunauthorized.component.html',
  styleUrls: ['./arunauthorized.component.scss']
})
export class ArunauthorizedComponent implements OnInit {
  loginbtn = false;
  continuebtn = true;
  continueok : boolean;
  subscription: Subscription;
  countDown: Subscription;
  // counter = 120;
  tick = 1000;
  deviceInfo: any;
  user: any;
  accesstoken: any;
  counter: any;
  timeout = 120;
  otpcount: number;
  constructor(public router:Router, public dialogRef: MatDialogRef<ArunauthorizedComponent>,
    private token:RefreshtokenService,private auth:AuthService,  private deviceinfoservice:DeviceinfoserviceService,private deviceService:DeviceDetectorService
    ) { 


// console.log('unsuthorize')



// const source = interval(200000);
// const text = 'Your Text Here';


// this.subscription = source.subscribe(val =>
                
            
//   this.getcontinue()


//   );


// this.countDown = timer(0, this.tick).subscribe(() => 
    


// this.counter --

 

//     )




//   const source = interval(120000);
// const text = 'Your Text Here';


// this.subscription = source.subscribe(val =>

//     //  console.log(val)     
//   this.stopsession()

// )





   
  }

  ngOnInit() {

    this.timer()

  }

  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    console.log(this.deviceInfo)
  }


  closemark(){
    this.dialogRef.close();
    this.token.getObservable(0).subscribe(val =>this.counter = val)
  }
  timer() {
    this.token.getObservable(this.timeout).subscribe(val =>
      {
        this.counter = val
        //console.log(this.counter)
        if(this.counter<=0){
          //console.log("2222222222")
          this.continuetologin();
        }else{
          //console.log("1111111111")
        }
      } );
    
  }
  

  continue() {
    this.continueok = true
    this.dialogRef.close();
   //  this.router.navigate(['/home'])
   // sessionStorage.clear();
   
   this.subscription.unsubscribe()
   
   
     }
     stayin(){
       this.dialogRef.close();
       this.token.getObservable(0).subscribe(val =>this.counter = val)
     }
   
     continuetologin() {
     
      this.dialogRef.close();
      this.token.getObservable(0).subscribe(val =>this.counter = val)
    //  this.router.navigateByUrl('https://dashboard.sahlahcf.com/#/auth/arlogin');
    
     this.user = JSON.parse(sessionStorage.getItem('currentUser'))
     this.accesstoken = this.user.accesstoken;
    
       // console.log("logout++++++++++++++")
       const obj :any ={}

       obj['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
       obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
       obj['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
       obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
       // console.log(obj)
       this.auth.logout(obj,this.accesstoken).subscribe(res =>{
       console.log(res)
         sessionStorage.clear();
         window.location.href = 'https://dashboard.sahlahcf.com/#/auth/arlogin'
     // this.router.navigate(['/arhome']);
      
        // this.router.navigate(['/home'])

         if(res.Token_Status =='1119'){
           if(res.logout_response == '1000') {
             sessionStorage.clear();
   
           //  this.router.navigate(['/home'])
           }
   
         }
   
        
        
   
   
   
   
       })
     }
   
   
   
     getcontinue() {
     this.token.getsession(true)
     this.loginbtn = true;
     this.continuebtn = false
     }

  signout() {
      
    this.user = JSON.parse(sessionStorage.getItem('currentUser'))
    this.accesstoken = this.user.accesstoken;
    
      // console.log("logout++++++++++++++")
      const obj :any ={}
      obj['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      obj['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
      // console.log(obj)
      this.auth.logout(obj,this.accesstoken).subscribe(res =>{
      console.log(res)
        sessionStorage.clear();
  
       // this.router.navigate(['/home'])
        if(res.Token_Status =='1119'){
          if(res.logout_response == '1000') {
            sessionStorage.clear();
  
          //  this.router.navigate(['/home'])
          }
  
        }
  
       
       
  
  
  
  
      })
   
    }



  }





