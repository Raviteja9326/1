import { TestBed } from '@angular/core/testing';

import { DeviceinfoserviceService } from './deviceinfoservice.service';

describe('DeviceinfoserviceService', () => {
  let service: DeviceinfoserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeviceinfoserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
