import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InvestorRegistrationComponent } from './investor-registration/investor-registration.component';
import { RegisterComponent } from './register/register.component';
import { SmeregistrationComponent } from './smeregistration/smeregistration.component';
import { ArsmeregistrationComponent } from './arsmeregistration/arsmeregistration.component';
import { LoginComponent } from './login/login.component';
import { ArloginComponent } from './arlogin/arlogin.component';


const routes: Routes = [
  {path:'investorRegister',component:InvestorRegistrationComponent},
  {path:'arinvestorRegister',component:RegisterComponent},
  {path:'smeregister',component:SmeregistrationComponent},
  {path:'arsmeregister',component:ArsmeregistrationComponent}, 
  {path:'login',component:LoginComponent},
  {path:'arlogin',component:ArloginComponent},
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
