import { Component, OnInit, Injectable, ComponentFactoryResolver, Renderer2 } from '@angular/core';
import { FormGroup,FormArray, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors, Form} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS, NativeDateAdapter} from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { HttpClient } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';

import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import * as moment from 'moment';
declare var $: any;
import {NgbDateStruct, NgbDatepickerI18n, NgbCalendarIslamicUmalqura, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import * as CryptoJS from 'crypto-js';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
// import { threadId } from 'worker_threads';
const WEEKDAYS = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];
const MONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال',
  'ذو القعدة', 'ذو الحجة'];

@Injectable()
export class IslamicI18n extends NgbDatepickerI18n {

  getWeekdayShortName(weekday: number) {
    return WEEKDAYS[weekday - 1];
  }

  getMonthShortName(month: number) {
    return MONTHS[month - 1];
  }

  getMonthFullName(month: number) {
    return MONTHS[month - 1];
  }

  getDayAriaLabel(date: NgbDateStruct): string {
    return `${date.day}-${date.month}-${date.year}`;
  }
}
 
interface Food {
  value: string;
  viewValue: string;
}

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'dd/MM/yyyy',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}


export const passwordMatchValidator: ValidatorFn = (registrationForm: FormGroup): ValidationErrors | null => {
  if (registrationForm.get('password').value === registrationForm.get('conformpassword').value)
    return null;
  else
    return {passwordMismatch: true};
};

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, investorInfoForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = investorInfoForm && investorInfoForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-smeregistration',
  templateUrl: './smeregistration.component.html',
  styleUrls: ['./smeregistration.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS},
    // {provide: NgbCalendar, useClass: NgbCalendarIslamicUmalqura},
    // {provide: NgbDatepickerI18n, useClass: IslamicI18n}
]
 
})

  export class SmeregistrationComponent implements OnInit {
    model: NgbDateStruct;
  value :any;
  first1:boolean=true;
  first2:boolean=false;
  first3:boolean=false;
  firstx:boolean=false;
  first4:boolean=false;
  first5:boolean=false;
  first6:boolean=false; 
  first7:boolean=false;

    hide = false;
    hide1 = false;
    maxDate = new Date()
    encryptSecretKey="sahlahcf";
    hidecaroselup1=false;
    successmsg = 'The information has been successfully verified';
    foods: Food[] = [
      {value: 'steak-0', viewValue: 'Steak'},
      {value: 'pizza-1', viewValue: 'Pizza'},
      {value: 'tacos-2', viewValue: 'Tacos'}
    ];
    duration = [
     
    // {value: 1, viewValue: '1 Month'},
    // {value: 2, viewValue: '2 Months'},
    // {value: 3, viewValue: '3 Months'},
    // {value: 4, viewValue: '4 Months'},
    // {value: 5, viewValue: '5 Months'},
    // {value: 6, viewValue: '6 Months'},
    // {value: 7, viewValue: '7 Months'},
    // {value: 8, viewValue: '8 Months'},
    // {value: 9, viewValue: '9 Months'},
    // {value: 10, viewValue: '10 Months'},
    // {value: 11, viewValue: '11 Months'},
    // {value: 12, viewValue: '12 Months'},
    // {value: 13, viewValue: '13 Months'},
    // {value: 14, viewValue: '14 Months'},
    // {value: 15, viewValue: '15 Months'},
    // {value: 16, viewValue: '16 Months'},
    // {value: 17, viewValue: '17 Months'},
    // {value: 18, viewValue: '18 Months'},
    // {value: 19, viewValue: '19 Months'},
    // {value: 20, viewValue: '20 Months'},
    // {value: 21, viewValue: '21 Months'},
    // {value: 22, viewValue: '22 Months'},
    // {value: 23, viewValue: '23 Months'},
    // {value: 24, viewValue: '24 Months'},
    // {value: 25, viewValue: '25 Months'},
    // {value: 26, viewValue: '26 Months'},
    // {value: 27, viewValue: '27 Months'},
    // {value: 28, viewValue: '28 Months'},
    // {value: 29, viewValue: '29 Months'},
    // {value: 30, viewValue: '30 Months'},
    // {value: 31, viewValue: '31 Months'},
    // {value: 32, viewValue: '32 Months'},
    // {value: 33, viewValue: '33 Months'},
    // {value: 34, viewValue: '34 Months'},
    // {value: 35, viewValue: '35 Months'},
    // {value: 36, viewValue: '36 Months'},
    // {value: 37, viewValue: '37 Months'},
    // {value: 38, viewValue: '38 Months'},
    // {value: 39, viewValue: '39 Months'},
    // {value: 40, viewValue: '40 Months'},
    // {value: 41, viewValue: '41 Months'},
    // {value: 42, viewValue: '42 Months'},
    // {value: 43, viewValue: '43 Months'},
    // {value: 44, viewValue: '44 Months'},
    // {value: 45, viewValue: '45 Months'},
    // {value: 46, viewValue: '46 Months'},
    // {value: 47, viewValue: '47 Months'},
    {value: 48, viewValue: '48 Months'}
    
   
    ];

    educationalqual= [
      {value: 'High School', viewValue: ' High School '},
      {value: 'Undergraduate', viewValue: ' Undergraduate '},
      {value: 'Graduate / Professional Degree', viewValue: ' Graduate / Professional Degree '},
      {value:' Post Graduate',viewValue:' Post Graduate'}
    ];
    personalnetwor  = [
      {value: 'Less than SAR 500K', viewValue: ' Less than SAR 500K '},
      {value: 'SR 500K to SR 2M', viewValue: ' SR 500K to SR 2M '},
      {value: 'SR 2M to SR 5M', viewValue: ' SR 2M to SR 5M '},
      {value: 'More than SR 5M', viewValue: ' More than SR 5M '},
     
      
    ];
    yearsofexp=[
      {value: 'Less than 3 years', viewValue: ' Less than 3 years '},
      {value: '3 to 5 years', viewValue: '  3 to 5 years  '},
      {value: '6 to 10 years', viewValue: ' 6 to 10 years '},
      {value: 'More than 10 years', viewValue: ' More than 10 years '},
      
    ];      

    noofclients = [
     
      {value: 'Less than 5', viewValue: 'Less than 5'},
      {value: '5 to 10', viewValue: '5 to 10'},
      {value: '11 to 20', viewValue: '11 to 20'},
      {value: '21 to 50', viewValue: '21 to 50'},
      {value: 'More than 50', viewValue: 'More than 50'},
     
      ];
      compnayactivity = [
      
        {value:"Agriculture & fishing", viewValue:'Agriculture & fishing'},
        {value: "Oil & gas extraction / mining & quarrying", viewValue:'Oil & gas '},
         {value:"Petrochemical & related industries",viewValue:'Petrochemical & related industries'},
          {value:"Logistics",viewValue:'Logistics'},
           {value:"Utilities (Electricity, Water, Gas, & Sanitary Services)",viewValue:'Utilities '},
           {value: "Communication / IT", viewValue:'Communication / IT'},
           {value:"Construction-contractors/builders",viewValue:'Construction-contractors'},
           {value: "Construction-ancillary contractors (finishing)", viewValue:'Construction-ancillary'},
           {value:"Construction material (suppliers & manufacturers)",viewValue:'Construction material'},
           {value: "Primary metal manufacturing & heavy equipment",viewValue:'Primary metal'},
           {value: "Consumer products",viewValue:'Consumer products'},
           {value: "E-commerce",viewValue:'E-commerce'},
           {value: "Automobiles",viewValue:'Automobiles'},
           {value: "Drugs & pharmaceuticals",viewValue:'Drugs'},
           {value: "Food & beverages",viewValue:'Food'},
           {value: "Miscellaneous",viewValue:'Miscellaneous'},
           {value: "Services (other than financial)",viewValue:'Services'}
        
      ]

annualIncome=[

  
  {value: 'Less than 50,000 SAR', viewValue: 'Less than 50,000 SAR'},
  {value: 'From 50,000 to 100,000', viewValue: 'From 50,000 to 100,000 SAR'},
  {value: 'From 101,000 to 250,000 SAR', viewValue: 'From 101,000 to 250,000 SAR'},
  {value: 'From 251,000 to 500,000 SAR', viewValue: 'From 251,000 to 500,000 SAR'},
  {value: 'From 500,000 to 1,000,000 SAR', viewValue: 'From 500,000 to 1,000,000 SAR'},
  {value: 'More than 1,000,000 SAR', viewValue: 'More than 1,000,000 SAR'}
]
companyturnover=[

  {value: 'Less than 3M SAR', viewValue: 'Less than 3M SAR'},
  {value: '3M to 10M SAR', viewValue: '3M to 10M SAR'},
  {value: '11M to 20M SAR', viewValue: '11M to 20M SAR'},
  {value: '20M to 40M SAR', viewValue: '20M to 40M SAR'},
  {value: 'Above 40M SAR', viewValue: 'Above 40M SAR'},
 
]
domains= [
  {value: 'Yellow / Red', viewValue: 'Yellow / Red'},
  {value: 'Green', viewValue: 'Green'},
  {value: 'Platinum', viewValue: 'Platinum'}
];

      noofemployes = [
     
        
      {value: 'Less than 5', viewValue: 'Less than 5'},
      {value: '5 to 10', viewValue: '5 to 10'},
      {value: '11 to 20', viewValue: '11 to 20'},
      {value: '21 to 50', viewValue: '21 to 50'},
      {value: 'More than 50', viewValue: 'More than 50'},
        ];

    ageofcompany=[
      {value:'Less than 2 Years', viewValue: 'Less than 2 Years'},
    {value: '2 to 5 Years', viewValue: '2 to 5 Years'},
    {value: '6 to 10 Years', viewValue: '6 to 10 Years'},
    {value: 'More than 10 Years', viewValue: 'More than 10 Years'},
  
    
    ]

    legalstatcompany= [
      {value: 'Sole Proprietorship', viewValue: 'Sole Proprietorship'},
      {value: 'Limited Liability Company', viewValue: 'Limited Liability Company'},
      {value: 'Closed Stock Company', viewValue: 'Closed Stock Company'},
      {value: 'Limited Of Foreign Investor Company', viewValue: 'Limited Liability of Foreign Investor company'},
   
    ];
    city= [
      {value: 'Riyadh', viewValue: 'Riyadh'},
      {value: 'Jeddah', viewValue: 'Jeddah'},
      {value: 'Dammam', viewValue: 'Dammam'},
      {value: 'Al-Khobar', viewValue: 'Al-Khobar'},
      {value: 'Dhahran', viewValue: 'Dhahran'},
      {value: 'Al-Ahsa', viewValue: 'Al-Ahsa'},
      {value: 'Qatif', viewValue: 'Qatif'},
      {value: 'Jubail', viewValue: 'Jubail'},
      {value: 'Taif', viewValue: 'Taif'}, 
      {value: 'Tabouk', viewValue: 'Tabouk'},
      {value: 'Abha', viewValue: 'Abha'},
      {value: 'Al Baha', viewValue: 'Al Baha'},
      {value: 'Jizan', viewValue: 'Jizan'},
      {value: 'Najran', viewValue: 'Najran'},
      {value: 'Hail', viewValue: 'Hail'},

      {value: 'Makkah AL-Mukkaramah', viewValue: 'Makkah AL-Mukkaramah'},
      {value: 'AL-Madinah Al-Munawarah', viewValue: 'AL-Madinah Al-Munawarah'},
      {value: '"Al Qaseem', viewValue: '"Al Qaseem'},
      {value: 'Jouff', viewValue: 'Jouff'},
      {value: 'Yanbu', viewValue: 'Yanbu'},
    ];
    banks = [
      {value: 'ALAWWAL Bank', viewValue: 'ALAWWAL Bank'},
      {value: 'ARAB NATIONAL BANK', viewValue: 'ARAB NATIONAL BANK'},
      {value: 'AL RAJHI BANKING AND INV.CORP.', viewValue: 'AL RAJHI BANKING AND INV.CORP.'}, 
      {value: 'AL BANK AL SAUDI AL FRANSI', viewValue: 'AL BANK AL SAUDI AL FRANSI'},
      {value: 'ALINMA BANK', viewValue: 'ALINMA BANK'},
      {value: 'BANK AlBILAD', viewValue: 'BANK AlBILAD'},
      {value: 'BANK MUSCAT', viewValue: 'BANK MUSCAT'},
      {value: 'BANK ALJAZIRA', viewValue: 'BANK ALJAZIRA'},
      {value: 'DEUTSHE BANK', viewValue: 'DEUTSHE BANK'},
      {value: 'Emirates Bank', viewValue: 'EMIRATES BANK'},
      {value: 'GULF INTERNATIONAL BANK', viewValue: 'GULF INTERNATIONAL BANK'},
      {value: 'NATIONAL COMMERCIAL BANK', viewValue: 'NATIONAL COMMERCIAL BANK'},
      {value: 'NATIONAL BANK OF BAHRAIN', viewValue: 'NATIONAL BANK OF BAHRAIN'},
      {value: 'National Bank of Kuwait', viewValue: 'NATIONAL BANK OF KUWAIT'},
      {value: 'National Bank of Pakistan', viewValue: 'NATIONAL BANK OF PAKISTAN'},
      {value: 'RIYAD BANK', viewValue: 'RIYAD BANK'},
    //  {value: 'Paryabas Bank', viewValue: 'PARYABAS BANK'},
      {value: 'SAUDI INVESTMENT BANK', viewValue: 'SAUDI INVESTMENT BANK'},
      // {value: 'SAUDI BRITISH BANK', viewValue: 'SAUDI BRITISH BANK'},
      {value: 'SABB BANK', viewValue: 'SABB BANK'},
      {value: 'SAUDI ARABIAN MONETARY AGENCY', viewValue: 'SAUDI ARABIAN MONETARY AGENCY'},
      {value: 'SAMBA BANK', viewValue: 'SAMBA BANK'},
     // {value: 'SAUDI AMERICAN BANK', viewValue: 'SAUDI AMERICAN BANK'},
     // {value:'SAUDI HOLLANDI BANK', viewValue:'SAUDI HOLLANDI BANK'},
    //  {value: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI', viewValue: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI'},
   
    ];
    accounts= [
      {value: 'INDB12545545', viewValue: 'INDB12545545'},
      {value: 'ANDB12545545', viewValue: 'ANDB12545545'},
      {value: 'AXDB12545545', viewValue: 'AXDB12545545'}
    ];
    ibans  = [
      {value: 'DFG4W42342424', viewValue: 'DFG4W42342424'},
      {value: 'egG4W42342424', viewValue: 'egG4W42342424'},
      {value: 'hiG4W42342424', viewValue: 'hiG4W42342424'}
    ];
    registrationForm:FormGroup;
    submitted=false;
    ipAddress: string; 
    geolocationPosition: object;
    latitude: any;
    longitude: any;
    deviceInfo: any;
    responseMessgae: string;
    registError: boolean;
    investorInfoForm:FormGroup;
    submitted1: boolean;
    submitted2:boolean;
    dateofbirth: any;
    otpForm:FormGroup;
    shareholderform:FormGroup;
    yourInfoForm:FormGroup;
    submitted3: boolean;
    investorInfoMessage: string;
    investorYourInfoMessage: string;
    invoiceinfoForm:FormGroup
    incomeInfoMessage: string;
    bankinginfoForm:FormGroup;
    companyinfoForm:FormGroup;
    uploadfileForm:FormGroup;
    msg: string;
    msgError: boolean;
  data: any;
  accesstoken: any;
  responseSucessMessgae: string;
  financingLimit: number;
  responseSucessInvoiceMessgae: string;
  responseBankSucessMessgae: string;
  regist1Error: boolean;
  registError1: boolean;
  registuploaddocError: boolean;
  responseUploadDocMessgae: string;
  countrycode: any;
  spinner: boolean;
  smeresponseMessgae: string;
  smeregistError: boolean;
  encriptdata: any;
  regstage: any;
  count=0; 
  count1=0;
  currdate = new Date()
  hidecoroseldown1: boolean;
  stage: any;
  decdata: any;
  mobileEmailFileError: string;
  bankstatementFileError: string;
  purchaseOrderFileError: string;
  bankaccountletterFileError: string;
  signedinvoiceFileError: string;
  companyceFileError: string;
  mobileEmaiError: boolean;
  bankstaatmentsError: boolean;
  purchaseorderError: boolean;
  bankaccountError: boolean;
  SignedInvoiceError: boolean;
  companyceError: boolean;
  registinvoicesucError: boolean;
  registbanksucess: boolean;
  registshareerr: boolean;
  shareholderr: string;
  registsharesuc: boolean;
  shareholdsucc: string;
  currentdate: string;
  todaydate: any;
  addressGroup:FormGroup;
  datdob: string;
  dobdatcurrent: boolean;
  doberrdis: boolean;
  doberr: string;
  addressarray: any;
  bobdattt: string;
  submitted5: boolean;
  submitted6: boolean;
  setDate: string;
  doberrdiseng: boolean;
  todat: string;
  title :any;
  checkansterms: string;
  firstcheck: any;
  firstcheckpolicy: any;
  checkanspolicy: string;
  termsprivacy: string;
  termsprivacyError: boolean;
    constructor(private spinnerfull: NgxSpinnerService,private calendar: NgbCalendar,private fb: FormBuilder,private authService:AuthService,private router:Router,private deviceinfoservice:DeviceinfoserviceService,
  
  
      private http: HttpClient, private deviceService: DeviceDetectorService,private renderer: Renderer2, private token:RefreshtokenService) { 

        if(token.first2){
          this.Fstbtn();
        }
  
       if(token.first3){
        this.first3 = true;
        this.firstx=true;
          this.first1 = false;
          this.first2 = false;
        }
        if(token.first4){
          this.first4 = true;
          this.firstx=true;
            this.first1 = false;
            this.first2 = false;
            this.first3 = false;
          }
          if(token.first5){
            this.first5 = true;
            this.firstx=true;
              this.first1 = false;
              this.first2 = false;
              this.first3 = false;
              this.first4 = false;
            }
            if(token.first6){
              this.first6 = true;
              this.firstx=true;
                this.first1 = false;
                this.first2 = false;
                this.first3 = false;
                this.first4 = false;
                this.first5 = false;
              }
              if(token.first7){
                this.first7 = true;
                this.firstx=true;
                  this.first1 = false;
                  this.first2 = false;
                  this.first3 = false;
                  this.first4 = false;
                  this.first5 = false;
                  this.first6 = false;
                }
  
       
        this.renderer.setStyle(document.body, 'background-color', '#f5f5f5');
        // console.log('=====')
        // console.log(this.deviceinfoservice.deviceinfo.deviceId)
        var date1=new Date();

this.getTodayDate();
        const momentDate = new Date(date1); 
        this. currentdate = moment(momentDate).format("YYYY-MM-DD");
        this.detectDevice();


        
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data !=null && this.data !=''){
        // for (let i = 0; i < parseInt(this.data.stage); i++) {
        //   console.log("+++++++++++++++++++++++++++++")
        //   $(".carousel").carousel("next");
        // }
        // console.log("*******************1111111111111")
        
      this.stage=  this.decryptData(this.data.allowosmerigen)
        if(parseInt(this.stage) >=1){
          // console.log("*******************222222222222")
          this.regstage= this.stage
        this. hidecoroseldown1=true;
        }else{
          this. hidecoroseldown1=false;
        }
      }
      }
      get o(){return this.uploadfileForm.controls}

      selectToday() {
        this.model = this.calendar.getToday();
     
    
        this.todaydate =  `${this.model.year}-${this.model.month}-${this.model.day}`
    
  
      }


    ngOnInit(): void {
      this.title ='عربى';
      this.  selectToday()
  
      this.registrationForm=this.fb.group({
        firstName:['',[Validators.required, Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
        lastName:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
        email:['',[Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),Validators.required]],
        mobileNo: ['', [Validators.required,Validators.minLength(9), Validators.maxLength(9), Validators.pattern("^(5)[0-9]{8}$")]],
        password:['', [Validators.required, Validators.minLength(8), Validators.maxLength(20),Validators.pattern('^[^ ].+[^ ]$')]],
        conformpassword:['', [Validators.required, Validators.minLength(8), Validators.maxLength(20),Validators.pattern('^[^ ].+[^ ]$')]],
         recaptchaReactive:['',Validators.required]
      },{
        validator: passwordMatchValidator
    });
    
   
  this.invoiceinfoForm = this.fb.group({
    finance:['',Validators.required],
    orginalinvoice:['',Validators.required],
    financelimit:[''],
    issuedbill:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
    DoI:['',Validators.required]
  }),

  this.companyinfoForm = this.fb.group({
    tradeName:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
    arabicName:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
    commercialReg:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10)]],
    taxNumber:['',[Validators.required,Validators.minLength(15), Validators.maxLength(15)]],
    legalForm:['',Validators.required],
    age:['',Validators.required],
    companyClient:['',Validators.required],
    employeenumber:['',Validators.required],
    domain:['',Validators.required],
    annualIncome:['',Validators.required],
    companyactivity:['',Validators.required],
    city:['',Validators.required],
    website:['',[Validators.required,Validators.pattern('(https?:\/\/)?(www\.)?[a-z0-9-]+\.(com|in)(\.[a-z]{2,3})?')]]


  })
  
  this.bankinginfoForm = this.fb.group({
    bankName:['',Validators.required],
    bankIBAN:['',[Validators.required,Validators.maxLength(30),Validators.pattern('^[A-Za-z0-9]*$')]],
    bankAccountHolderName: ['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],

  }),
  this.uploadfileForm = this.fb.group({
    bank_account_letter: ['',Validators.required],
    monthbankstatement:['',Validators.required],
    purchaseorder:['',Validators.required],
    mobileEmail:['',Validators.required],
    signedIncvoice:['',Validators.required],
    companyCr:['',Validators.required],
    terms_and_conditions:['',Validators.required],
    privacy_policy:['',Validators.required]
  }),
  this.shareholderform = this.fb.group({
    address: this.fb.array([
          
 ]),
 shName:['',[Validators.required,Validators.pattern("^[ ئ ا-ى   ؤ ء ي  ]*$")]],
 mobile:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9), Validators.pattern("^(5)[0-9]{8}$")]],
 shDob:['',Validators.required],
 shExperience:['',Validators.required],
 shEducation:['',Validators.required],
 shPersonalNetWorth:['',Validators.required],
})



  
      $('.carousel .vertical .item').each(function(){
        var next = $(this).next();
        if (!next.length) {
          next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));
        
        for (var i=1;i<2;i++) {
          next=next.next();
          if (!next.length) {
            next = $(this).siblings(':first');
          }
          
          next.children(':first-child').clone().appendTo($(this));
        }
      });
  
  
  
  
    
    }

    ngAfterViewInit(){
      this.addNewAddressGroup();
    }
    get registrationControllers() { return this.registrationForm.controls }
    get investerInfoOtpControllers() { return this.investorInfoForm.controls }
   
    get password() { return this.registrationForm.get('password'); }
    get conformpassword() { return this.registrationForm.get('conformpassword'); }
    
    getErrorEmail() {
      return this.investorInfoForm.get('nationalId').hasError('required') ? 'Field is required' :
        this.investorInfoForm.get('nationalId').hasError('pattern') ? 'Not a valid emailaddress' :'';
          // this.formGroup.get('email').hasError('alreadyInUse') ? 'This emailaddress is already in use' : '';
    }
    get f() {
      return this.uploadfileForm.controls;
    }
  next() {
   
  }

  get investeryourInfoControllers() { return this.addressGroup.controls }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  Fstbtn(){
    this.first1= false;
    this.first2= true;
    this.firstx=true;
  }
  onPasswordInput() {
    if (this.registrationForm.hasError('passwordMismatch'))
      this.conformpassword.setErrors([{'passwordMismatch': true}]);
    else
      this.conformpassword.setErrors(null);
  }
  calculatefinancingLimit(){
  
    this.financingLimit=parseInt(this.invoiceinfoForm.value.orginalinvoice)*0.8
    this.financingLimit=Math.round(this.financingLimit)
    if(this.invoiceinfoForm.value.orginalinvoice ==''){
      this.financingLimit=0
    }
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();

  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.investorInfoForm.controls[controlName].hasError(errorName);
  }
  RegistrationDetails(){
    this.countrycode = null;
    this.submitted=true; 
    this.registrationForm.markAllAsTouched();
   
    if(this.registrationForm.valid){
      this.countrycode = 966
      this.detectDevice();
      // this.showPosition(this.geolocationPosition);
      const object: any = {}
        object['browserType'] = this.deviceInfo.browser;
        object['browserVersion'] = this.deviceInfo.browser_version;
        object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
        object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
        object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
        object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
        object['language'] = 'en';
        object['countryCode'] = 'SA';
      //  object['email'] = this.registrationForm.value.email
        object['firstName'] = this.registrationForm.value.firstName
        object['lastName'] = this.registrationForm.value.lastName
      //  object['password'] = this.registrationForm.value.password
        object['osVersion'] = this.deviceInfo.os_version;
        object['osType'] = this.deviceInfo.os;
        object['mobile'] = this.countrycode + this.registrationForm.value.mobileNo
        object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
        object['registrationType'] = 'SME';
        object['recaptchaResponse'] = this.registrationForm.value.recaptchaReactive;
  
  
  
        
        
        this.spinner = true
        this.spinnerfull.show();
  this.authService.RegistrationDetails(object,this.registrationForm.value.email,this.registrationForm.value.password).subscribe(response =>
    this.registrationSmeDetailsSubmit(response)
   
    )
    this.spinner = false;
    }
   
  }

  encryptData(data) {

    try {
      
      // this.decryptData(CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString()) 
      this.encriptdata=CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString();
      return CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString();
     
    } catch (e) {
     
    }
  }
  
  
  decryptData(data) {
  
    try {
      const bytes = CryptoJS.AES.decrypt(data, this.encryptSecretKey);
      if (bytes.toString()) {
       // console.log(JSON.parse(bytes.toString(CryptoJS.enc.Utf8)))
        return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
      }
     // console.log(data)
      return data;
      
    } catch (e) {
     
    }
  }



skip() {
  this.first4=false;
  this.firstx=true;
  this.first5=true;
}

mymethod(){
  
}








  registrationSmeDetailsSubmit(response){
    
    this.registrationForm.controls['recaptchaReactive'].reset();
    if(response.Registration_Response == 1000){
      this.registrationForm.reset();
      this.responseSucessMessgae = "SME Registered SucessFully";
      
   
      this.encryptData(1)
      const object: any = {}
      object.allowosmerigen =  this.encriptdata
    this.hidecaroselup1=true;
      object.accesstoken = response.token;
      this.token.changeMessagereg(response); 
      sessionStorage.setItem('currentUser', JSON.stringify(object))
  
                this.regist1Error = true;
                setTimeout(() => {
                  this.spinnerfull.hide();
                  this.regist1Error = false;
                  this.first2=false;
                  this.first3=true;
                  this.firstx=true;
                },3000)
    }else if(response.Registration_Response== 1001){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "FAILURE";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1003){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "BROWSER TYPE IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1004){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1005){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1006){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1007){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1008){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1009){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1010){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1011){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1012){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1013){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1014){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1015){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1016){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1017){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "MOBILE NUMBER IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1018){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "MOBILE NUMBER IS NOT VALID";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1019){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "FIRST NAME IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1020){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "LAST NAME IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1021){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SPECIAL CHARACTERS ARE NOT ALLOWED IN FIRST NAME";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1022){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SPECIAL CHARACTERS ARE NOT ALLOWED IN lAST NAME";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1023){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "EMAIL ID IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1024){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "EMAIL ID IS NOT VALID";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1025){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "PASSWORD IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1026){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "PASSWORD SHOULD BE MINIMUM 8 AND MAXIMUM 20";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response==1027){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "BRAND NAME IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1044){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "REGISTRATION TYPE IS EMPTY";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1045){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "REGISTRATION TYPE SHOULD BE LENDER OR BARROWER";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1046){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "EMAIL ALREADY EXISTS";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else if(response.Registration_Response== 1047){
      this.spinnerfull.hide();
      this.smeresponseMessgae = "MOBILE NUMBER ALREADY EXTSTS";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }else {
      this.spinnerfull.hide();
      this.smeresponseMessgae = "SOMETHING WENT WRONG";
  
                this.smeregistError = true;
                setTimeout(() => {
                  this.smeregistError = false;
                }, 3000)
    }
  }
  
  InvoiceInformationSubmit(){
    //this.submitted1=true;
  this.invoiceinfoForm.markAllAsTouched();
   
    if(this.invoiceinfoForm.valid){
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      this.detectDevice();
      // const momentDate = new Date(this.invoiceinfoForm.value.DoI); 
      // const formattedDate = moment(momentDate).format("YYYY-MM-DD");
      // console.log(formattedDate);

var val = this.invoiceinfoForm.value.DoI;


      var d = new Date(val),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
      day = '0' + day;

      this.bobdattt = [year, month, day].join('-')
      const object: any = {}
        object['browserType'] = this.deviceInfo.browser;
        object['browserVersion'] = this.deviceInfo.browser_version;
        object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
        object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
        object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
        object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
        object['language'] = 'en';
        object['countryCode'] = 'SA';
      //  object['email'] = this.registrationForm.value.email
        object['invoiceAmount'] = this.invoiceinfoForm.value.orginalinvoice
        object['invoiceFundDuration'] = this.invoiceinfoForm.value.finance
      //  object['password'] = this.registrationForm.value.password
      object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
        object['osVersion'] = this.deviceInfo.os_version;
        object['osType'] = this.deviceInfo.os;
        object['invoiceFinancingAmount'] = this.financingLimit
        object['invoiceissuedFor'] = this.invoiceinfoForm.value.issuedbill;
        object['invoiceDate'] =    this.bobdattt 
this.spinner = true;
this.spinnerfull.show();
this.authService.investorInvoiceInformation(object,this.accesstoken).subscribe(response=>
  this.invstrInvoiceInfoRespone(response))

this.spinner = false;
    }
  
   
  }
  invstrInvoiceInfoRespone(response){
    
    if(response.invoiceInfo_response== 1000){
      this.invoiceinfoForm.reset()




      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      const object: any = {}
      this.encryptData(2)
      object.accesstoken = this.accesstoken;
      object.allowosmerigen =  this.encriptdata
      sessionStorage.setItem('currentUser', JSON.stringify(object))

      this.responseSucessInvoiceMessgae = "INVOICE INFORMATION SUBMITTED SUCESSFULLY";
  
                this.registinvoicesucError = true;
                setTimeout(() => {
                  this.registinvoicesucError = false;
                  this.first3=false;
                  this.firstx=true;
                  this.first4=true;
                  this.spinnerfull.hide();
                }, 3000)
    }else if(response.invoiceInfo_response== 1001){
      this.spinnerfull.hide();
      this.responseMessgae = "FAILURE";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1003){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1004){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1005){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1006){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1007){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1008){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1009){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1010){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1011){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1012){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1013){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1014){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1015){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response==1016){
      this.spinnerfull.hide();
      this.responseMessgae = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }
    else if(response.invoiceInfo_response== 1040){
      this.spinnerfull.hide();
      this.responseMessgae = "REGISTRATION ID IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1041){
      this.spinnerfull.hide();
      this.responseMessgae = "REGISTRAIION ID SHOULD BE NUMERIC";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response== 1140){
      this.spinnerfull.hide();
      this.responseMessgae = "DOB IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response==1142){
      this.spinnerfull.hide();
      this.responseMessgae = "DOB IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response==1146){
      this.spinnerfull.hide();
      this.responseMessgae = "NATIONAL ID IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.invoiceInfo_response==1147){
      this.spinnerfull.hide();
      this.responseMessgae = "NATIONALITY IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.invoiceInfo_response==1148){
      this.spinnerfull.hide();
      this.responseMessgae = "NATIONALITY SHOULD BE SAUDI OR NON SAUDI";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else {
      this.responseMessgae = "SOMETHING WENT WRONG";
      this.spinnerfull.hide();
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }
  }
  
  // InvoiceInformationSubmit(){
  //     console.log(this.invoiceinfoForm.value)
  
     
  //     this.invoiceinfoForm.markAllAsTouched();
  //     if(this.invoiceinfoForm.valid){
  //       this.detectDevice();   
  // console.log("+++++++++++++++++++++++")
  
  // const object: any = {}
  // object['browserType'] = this.deviceInfo.browser;
  // object['browserVersion'] = this.deviceInfo.browser_version;
  // object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  // object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  // object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  // object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
  // object['osVersion'] = this.deviceInfo.os_version;
  // object['osType'] = this.deviceInfo.os;
  // object['browserType'] = this.deviceInfo.browser;
  // object['browserVersion'] = this.deviceInfo.browser_version;
  // object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
  // object['language'] = 'en';
  // object['countryCode'] = 'SA';
  // object['registration_Id'] = '15'
  
  // object['annualIncome'] =this.incomeinfoForm.value.anualIncome ;
  // object['incomeSource'] = this.incomeinfoForm.value.sourceIncome;
  // object['jobStatus'] = this.incomeinfoForm.value.jobStatus
  
  // 
  // this.authService.incomeInformationSubmit(object).subscribe(response=>
  //   this.incomeInfoResponse(response))
  //     }
   // }
    // incomeInfoResponse(response){
    //   
    //   if(response.investor_response== 1000){
    //     this.incomeInfoMessage = "SUCESS";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000000000000)
    //   }else if(response.investor_response== 1001){
    //     this.incomeInfoMessage = "FAILURE";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1003){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1004){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1005){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1006){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1007){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1008){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1009){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1010){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1011){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1012){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1013){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1014){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response== 1015){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response==1016){
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //               this.registError = true;
    //               setTimeout(() => {
    //                 this.registError = false;
    //               }, 3000)
    //   }else if(response.investor_response ==1132){
    //     this.incomeInfoMessage = "ANNUAL INCOME IS EMPTY";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)
    //   }else if(response.investor_response ==1133){
    //     this.incomeInfoMessage = "SOURCE OF INCOME IS EMPTY";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)
    //   }else if(response.investor_response ==1134){
    //     this.incomeInfoMessage = "JOB STATUS IS EMPTY";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)
    //   }else if(response.investor_response ==1040){
    //     this.incomeInfoMessage = "REGISTRATION ID IS EMPTY";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)
    //   }else if(response.investor_response ==1041){
    //     this.incomeInfoMessage = "REGISTRAIION ID SHOULD BE NUMERIC";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)
    //   }else if(response.investor_response ==1042){
    //     this.incomeInfoMessage = "REGISTRATION ID NOT VALID";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)
    //   }else {
    //     this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
    //     this.registError = true;
    //     setTimeout(() => {
    //       this.registError = false;
    //     }, 3000)    }
  
    // }
  
    companyinfo() {
      this.companyinfoForm.markAllAsTouched();
     
      
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }

      const object: any = {}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
      object['language'] = 'en';
      object['countryCode'] = 'SA';
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      object['brand_Name'] = this.companyinfoForm.value.tradeName
      object['company_Name'] = this.companyinfoForm.value.arabicName
      object['company_CR_Number'] = this.companyinfoForm.value.commercialReg
     object['company_VAT_Number'] = this.companyinfoForm.value.taxNumber
          object['company_Legal_Status'] = this.companyinfoForm.value.legalForm
      object['company_Years_in_Business'] = this.companyinfoForm.value.age
      object['company_Number_of_Clients'] = this.companyinfoForm.value.companyClient
      object['company_Number_of_Employees'] = this.companyinfoForm.value.employeenumber
      object['company_Turnover'] = this.companyinfoForm.value.annualIncome
      object['company_Industry'] = this.companyinfoForm.value.companyactivity
     object['company_Nitaqat'] = this.companyinfoForm.value.domain
          object['company_City'] = this.companyinfoForm.value.city
      object['company_Website'] = this.companyinfoForm.value.website
      object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      this.spinner = true;
      this.spinnerfull.show();
this.authService.companyDetailsSubmit(object,this.accesstoken).subscribe(response=>
  this.companyDetailsResponse(response))
this.spinner = false;

    }
    companyDetailsResponse(response){
      

      if(response.token_staus=='1119'){

if(response.companyInfo_response=='1000'){




  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }
  const object: any = {}
  this.encryptData(4)
  object.accesstoken = this.accesstoken;
  object.allowosmerigen =  this.encriptdata
  sessionStorage.setItem('currentUser', JSON.stringify(object))


  this.responseSucessMessgae="Company Information Submitted SucessFully"
  this.companyinfoForm.reset();

  this.registError = true;
      setTimeout(() => {
        this.registError = false;
        this.spinnerfull.hide();
        this.first5=false;
  this.firstx=true;
  this.first6=true;
      }, 3000)  
}else if(response.companyInfo_response=='1000'){


}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else if(response.companyInfo_response=='1000'){

}else{
  this.spinnerfull.hide();
  this.incomeInfoMessage = "SOMETHING WENT WRONG";
    
      this.registError1 = true;
      setTimeout(() => {
        this.registError1 = false;
      }, 3000)   
}



      }else if(response.token_staus=='1120'){

      }else if(response.token_staus=='1121'){

      }
    }

    bankinfo2(){
      this.first4=false;
      this.firstx=true;
      this.first5=true;
    }

  
    bankinfo() {
     
      this.bankinginfoForm.markAllAsTouched();
   
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      if(this.bankinginfoForm.valid){
  
        const object = {... this.deviceinfoservice.deviceinfo, language:'en',registrationId:6,bankName:this.bankinginfoForm.value.bankName,
      bankIBAN:this.bankinginfoForm.value.bankIBAN,iPAddress:this.deviceinfoservice.deviceinfo.ipAdress, bankAccountHolderName:this.bankinginfoForm.value.bankAccountHolderName,
      registrationType:'SME' }   
      
      this.spinner = true;
      this.spinnerfull.show();
      this.authService.bankinformation(object,this.accesstoken).subscribe(response =>{
        
        this.spinner = false;
        if(response.bankinfo_response== 1000){
          this.data = JSON.parse(sessionStorage.getItem('currentUser'));
          if(this.data!=null || this.data !=''){
            this.accesstoken= this.data.accesstoken;
          }
          const object: any = {}
          this.encryptData(3)
          object.accesstoken = this.accesstoken;
          object.allowosmerigen =  this.encriptdata

          sessionStorage.setItem('currentUser', JSON.stringify(object))
          this.responseBankSucessMessgae = "BANK INFORMATION ADDED SUCESSFULLY";
      
                    this.registbanksucess = true;
                    setTimeout(() => {
                      this.spinnerfull.hide();
                      this.first4=false;
  this.firstx=true;
  this.first5=true;
                      this.registbanksucess = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1001){
          this.responseMessgae = "FAILURE";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1002){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
      
        else if(response.bankinfo_response== 1003){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1004){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1005){
           this.responseMessgae = "SOMETHING WENT WRONG";
           this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1006){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1007){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1008){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1009){
          this.responseMessgae = "SOMETHING WENT WRONG";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1010){
          this.responseMessgae = "SOMETHING WENT WRONG";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1011){
          this.responseMessgae = "SOMETHING WENT WRONG";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1012){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1013){
          this.responseMessgae = "SOMETHING WENT WRONG";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1014){
          this.responseMessgae = "SOMETHING WENT WRONG";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1015){
          this.responseMessgae = "SOMETHING WENT WRONG";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response==1016){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1040){
          this.responseMessgae = "REGISTRATION ID IS EMPTY";  
          this.spinnerfull.hide();  
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1041){
          this.responseMessgae = "REGISTRAIION ID SHOULD BE NUMERIC";
          this.spinnerfull.hide();
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.bankinfo_response== 1042){
          this.responseMessgae = "REGISTRATION ID NOT VALID";
          this.spinnerfull.hide();
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
  
        else if(response.bankinfo_response== 1055){
          this.responseMessgae = "BANK IBAN SHOULD NOT BE EMPTY";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.bankinfo_response== 1083){
          this.responseMessgae = "SOMETHING WENT WRONG";   
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.bankinfo_response== 1084){
          this.responseMessgae = "SOMETHING WENT WRONG";   
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.bankinfo_response== 1145){
          this.responseMessgae = "BANK ACCOUNT NAME IS EMPTY";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        } else {
          this.responseMessgae = "SOMETHING WENT WRONG";   
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
      
      })
       
      }
    }
  
    onFileChange(event) {
      if(event.target.files[0].size < 5000000){
      if (event.target.files.length > 0) {
            this.mobileEmaiError = false;
        const file = event.target.files[0];
        this.uploadfileForm.get('mobileEmail').setValue(file);
      }
    }else{
      this.mobileEmailFileError="Authorizes Mobile & Email Letter  Should Be Less Than 5 MB";
      this.mobileEmaiError = true;
      // setTimeout(() => {
      //   this.mobileEmaiError = false;
      // }, 3000)
    }
    }
    onFileChange2(event) {
      if(event.target.files[0].size < 5000000){
      if (event.target.files.length > 0) {
                this.bankstaatmentsError = false;

        const file = event.target.files[0];
        this.uploadfileForm.get('monthbankstatement').setValue(file);
      }
    }else{
      this.bankstatementFileError="Bank Statements  Should Be Less Than 5 MB";
      this.bankstaatmentsError = true;
      // setTimeout(() => {
      //   this.bankstaatmentsError = false;
      // }, 3000)
    }
    }
    onFileChange3(event) {
      if(event.target.files[0].size < 5000000){
      if (event.target.files.length > 0) {
        this.purchaseorderError = false;

        const file = event.target.files[0];
        this.uploadfileForm.get('purchaseorder').setValue(file);
      }
    }else{
      this.purchaseOrderFileError="Purchase Order File  Should Be Less Than 5 MB";
      this.purchaseorderError = true;
      // setTimeout(() => {
      //   this.purchaseorderError = false;
      // }, 3000)
    }
    }
    onFileChange4(event) {
      if(event.target.files[0].size < 5000000){
      if (event.target.files.length > 0) {
        this.bankaccountError = false;
        const file = event.target.files[0];
        this.uploadfileForm.get('bank_account_letter').setValue(file);
      }
    }else{
      this.bankaccountletterFileError="Bank Account Letter  Should Be Less Than 5 MB";
      this.bankaccountError = true;
      // setTimeout(() => {
      //   this.bankaccountError = false;
      // }, 3000)
    }
    }
    onFileChange5(event) {
      if(event.target.files[0].size < 5000000){
      if (event.target.files.length > 0) {
        this.SignedInvoiceError = false;

        const file = event.target.files[0];
        this.uploadfileForm.get('signedIncvoice').setValue(file);
      }
    }else{
      this.signedinvoiceFileError="Signed Invoice File Should Be Less Than 5 MB";
      this.SignedInvoiceError = true;
      // setTimeout(() => {
      // }, 3000)
    }
    }
    onFileChange6(event) {
      if(event.target.files[0].size < 5000000){
      if (event.target.files.length > 0) {
        this.companyceError = false;

        const file = event.target.files[0];
        this.uploadfileForm.get('companyCr').setValue(file);
      }
    }else{
      this.companyceFileError="Company CR File Should Be Less Than 5 MB";
      this.companyceError = true;
      // setTimeout(() => {
      //   this.companyceError = false;
      // }, 3000)
    }
    }
    
    
    uploadform() {
      
      this.submitted6 = true;
      this.submitted5=true;
    
     this.detectDevice();
   
     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
     if(this.data!=null || this.data !=''){
       this.accesstoken= this.data.accesstoken;
     }
     
        if(this.uploadfileForm.valid && this.uploadfileForm.get('terms_and_conditions').value !=false)
        {
          if( this.uploadfileForm.get('privacy_policy').value !=false){
         this.firstcheck = this.uploadfileForm.get('terms_and_conditions').value;
        //  (this.firstcheck)
         if(this.firstcheck == true) {
           this.checkansterms = 'Accepted';
          //  ('ghdfgsdf')
          //  (this.checkansterms)
         }
         this.firstcheckpolicy = this.uploadfileForm.get('privacy_policy').value;
         if(this.firstcheckpolicy == true) {
          this.checkanspolicy = 'Accepted';
          // ('ghdfgsdf')
          // (this.checkanspolicy)
        }
        this.submitted5 = false;
        this.msgError = false;
        const formData = new FormData();
        formData.append('file',this.uploadfileForm.get('mobileEmail').value);

        formData.append('authorizedMobnEmailLetter',this.uploadfileForm.value.mobileEmail);

        formData.append('file',this.uploadfileForm.get('monthbankstatement').value);

        formData.append('threeMonthsBankStatements',this.uploadfileForm.value.monthbankstatement);

        formData.append('file',this.uploadfileForm.get('purchaseorder').value);

        formData.append('purchaseOrderrProjectContract',this.uploadfileForm.value.purchaseorder);
        formData.append('file',this.uploadfileForm.get('bank_account_letter').value);

        formData.append('bankAccountLetter',this.uploadfileForm.value.bank_account_letter);

        formData.append('file',this.uploadfileForm.get('signedIncvoice').value);

        formData.append('signedInvoice',this.uploadfileForm.value.signedIncvoice);

        formData.append('file',this.uploadfileForm.get('companyCr').value);

        formData.append('isTermsnConditionsAccepted',this.checkansterms);

        formData.append('isPrivacyPolicyAccepted',this.checkanspolicy);
  

        formData.append('crCertificate',this.uploadfileForm.value.companyCr);
        formData.append('language','ar');
     
        formData.append('deviceType',this.deviceinfoservice.deviceinfo.deviceType);
        formData.append('browserType',this.deviceinfoservice.deviceinfo.browserType);
        formData.append('browserVersion',this.deviceinfoservice.deviceinfo.browserVersion);
        formData.append('osType',this.deviceinfoservice.deviceinfo.osType);
  
        formData.append('osVersion',this.deviceinfoservice.deviceinfo.osVersion);
  
        formData.append('deviceId	',this.deviceinfoservice.deviceinfo.deviceId);
        formData.append('iPAddress	',this.deviceinfoservice.deviceinfo.ipAdress);

        if(this.deviceinfoservice.deviceinfo.latitude =='') {
          formData.append('latitude	','NA');
          
        } else {
          formData.append('latitude	',this.deviceinfoservice.deviceinfo.latitude);
        }
  
  
        if(this.deviceinfoservice.deviceinfo.logintude =='') {
          formData.append('longitude	','NA');
          
        } else {
          formData.append('longitude	',this.deviceinfoservice.deviceinfo.logintude);
        }






        // formData.append('latitude	',this.deviceinfoservice.deviceinfo.latitude);
        // formData.append('longitude	',this.deviceinfoservice.deviceinfo.logintude);
  
  
     // this.spinner = true;
         this.spinnerfull.show();
        this.authService.smeuploadDocuments(formData,this.accesstoken).subscribe(response =>{
          
  
         this.spinner = false;
          if(response.upload_documents_response == 1000){
            this.submitted5=false;
            this.responseUploadDocMessgae = "Documents Uploaded SucessFully";
            this.data = JSON.parse(sessionStorage.getItem('currentUser'));
            if(this.data!=null || this.data !=''){
              this.accesstoken= this.data.accesstoken;
            }
                      this.registuploaddocError = true;
                      setTimeout(() => {
                        this.spinnerfull.hide();
                        this.registuploaddocError = false;
                        const object: any = {}
                        object['FirstName']  = response.FirstName;
                        object['LastName']     = response.LastName;
                        object['LastLogin']    = response.LastLogin;
                        object['isMobileVerified']   = response.isMobileVerified;
                        object['isEmailVerified']   = response.isEmailVerified;
                        object['accesstoken']   = this.accesstoken
                        object['isPolicyAccepted']   = response.isPolicyAccepted;
                        object['isBankInfoProvided']    = response.isBankInfoProvided;
                        object['isInvestorInfoProvided']    = response.isInvestorInfoProvided;
                        object['isTermsAccepted']  = response.isTermsAccepted;
                        object['isPolicyAccepted']  = response.isPolicyAccepted;
                        object['id']  = response.id;
                        // object['redirect'] = '/auth/smeregister';
                        object['redirect']="englishwebsmeapp";
                        sessionStorage.setItem('currentUser',JSON.stringify(object))
              
                        this.router.navigate(['/englishwebsmeapp/webappdashboard'])
                      }, 3000)
          }else if(response.upload_documents_response== 1001){
            this.responseMessgae = "FAILURE";
            this.spinnerfull.hide();
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1002){
            this.responseMessgae = "SOMETHING WENT WRONG";
            this.spinnerfull.hide();
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
        
          else if(response.upload_documents_response== 1003){
            this.responseMessgae = "SOMETHING WENT WRONG";
            this.spinnerfull.hide();
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1004){
            this.responseMessgae = "SOMETHING WENT WRONG";
            this.spinnerfull.hide();
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1005){
            this.spinnerfull.hide();
             this.responseMessgae = "SOMETHING WENT WRONG";
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1006){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1007){
            this.responseMessgae = "SOMETHING WENT WRONG";
            this.spinnerfull.hide();
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1008){
            this.responseMessgae = "SOMETHING WENT WRONG";
            this.spinnerfull.hide();
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1009){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1010){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1011){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1012){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1013){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1014){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1015){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response==1016){
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1040){
            this.spinnerfull.hide();
            this.responseMessgae = "REGISTRATION ID IS EMPTY";    
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1041){
            this.spinnerfull.hide();
            this.responseMessgae = "REGISTRAIION ID SHOULD BE NUMERIC";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1042){
            this.spinnerfull.hide();
            this.responseMessgae = "REGISTRATION ID NOT VALID";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }else if(response.upload_documents_response== 1074){
            this.spinnerfull.hide();
            this.responseMessgae = "BANK ACCOUNT LETTER FILE IS EMPTY";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
    
          else if(response.upload_documents_response== 1075){
            this.spinnerfull.hide();
            this.responseMessgae = "BANK ACCOUNT LETTER FILE SIZE SHOULD BE LESS THAN 5MB";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          } 
          else if(response.upload_documents_response== 1076){
            this.spinnerfull.hide();
            this.responseMessgae = "BANK ACCOUNT LETTER FILE FORMATS ARE,PNG,JPG,PDF,XLS,XLSX";
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
          else if(response.upload_documents_response== 1130){
            this.spinnerfull.hide();
            this.responseMessgae = "TERMS AND CONDITIONS SHOULD BE ACCEPTED";   
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
          else if(response.upload_documents_response== 1131){
            this.spinnerfull.hide();
            this.responseMessgae = "PRIVACY POLICY SHOULD BE ACCEPTED";   
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
         
          else {
            this.spinnerfull.hide();
            this.responseMessgae = "SOMETHING WENT WRONG";   
        
                      this.registError = true;
                      setTimeout(() => {
                        this.registError = false;
                      }, 3000)
          }
        })
       
       
      } else{
        this.termsprivacy=" Please accept Privacy Policy"
        this.termsprivacyError = true;
        setTimeout(() => {
          this.termsprivacyError = false;
        }, 3000)
      }
      } else{
   
        this.termsprivacy="Please accept Terms & Conditions"
        this.termsprivacyError = true;
        setTimeout(() => {
          this.termsprivacyError = false;
        }, 3000)
      }
      // else{
      //   this.msg = 'PLEASE UPLOAD THE DOCUMENTS';
       
        
      //   this.msgError = true;
      // }
    }


  //   getdobjj() {
  //     var age = 18;
  //     const formattedDate = this.investorInfoForm.value.Dob;
     
      
      
  //   if(formattedDate.day > 10) {
  
  //     this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
  //     console.log(this.datdob)
     
  //     var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;
  //     console.log(setDate)
  // var currdate = this.todaydate;
  // console.log(currdate);
  // console.log(currdate >= setDate)
  // if (currdate >= setDate) {
  //   this.dobdatcurrent = currdate >= setDate

  //   console.log("above18")
 
  // } else {
  //   console.log("below18")
  //   this.doberrdis = true;
  //   this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  //   setTimeout(() => {
  //     this.doberrdis = false;
  //   }, 3000);
  // }
  //     return this.datdob
  
  //   }
  //   else{
  //     this.datdob =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
  //     console.log(this.datdob)
  
  //     var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-0${formattedDate.day}` ;
  //     console.log(setDate)
  // var currdate = this.todaydate;
  // console.log(currdate);
  // console.log(currdate >= setDate)
  
  // if (currdate >= setDate) {
  //   this.dobdatcurrent = currdate >= setDate
  
  //   console.log("above18")
   
  // } else {
  //   console.log("below18")
  //   this.doberrdis = true;
  //   this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  //   setTimeout(() => {
  //     this.doberrdis = false;
  //   }, 3000);
  
 
  // }
  //     return this.datdob
  
  //   }
  //   }

  getTodayDate() {
    
    var d = new Date(this.currdate),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

if (month.length < 2) 
    month = '0' + month;
if (day.length < 2) 
    day = '0' + day;

    this.todat = [year, month, day].join('-')
    

    return this.todat
  }

  onDateChange(val) {
   


    var d = new Date(val),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

        this.bobdattt = [year, month, day].join('-')
     
this.setDate = [year+ 18, month, day].join('-');



if (this.todat >= this.setDate) {
this.dobdatcurrent = this.todat >= this.setDate

this.doberr = ''

} else {

this.doberrdiseng = true;
this.doberr = 'Date of Birth should be greater than 18 years'
// setTimeout(() => {
//   this.doberrdiseng = false;
// }, 3000);



}
return  this.bobdattt;
  }


    shareholderinfo(){
      this.submitted3 = true;
      this.shareholderform.markAllAsTouched();
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
if(this.dobdatcurrent  == true){
      if(this.shareholderform.get('address').valid){
  
       const object:any ={}
       object['browserType'] = this.deviceInfo.browser;
       object['browserVersion'] = this.deviceInfo.browser_version;
       object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
       object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
       object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
       object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
       object['language'] = 'EN';
       object['countryCode'] = 'SA';
       object['osVersion'] = this.deviceInfo.os_version;
       object['osType'] = this.deviceInfo.os;
       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
     

// this.addressarray =this.shareholderform.value.address;
// console.log(this.addressarray)

 
// console.log(this.addressarray.push(object))
          object['shareholderinfo']=this.shareholderform.value.address
     // console.log(this.accesstoken)
     this.spinnerfull.show();
       this.authService.submitShareHolderInfo(this.accesstoken,object).
       subscribe(response=>
        { this.shareholderinfoResponse(response);
        })
     }
    }
    }
    shareholderinfoResponse(response){
      console.log(response)

     // if(response.token_staus =='1119'){
      if(response.shareholder_response=='1000'){
        this.shareholdsucc = "ShareHolder Information Submitted SucesFully";
        this.shareholderform.get('address').reset();
        this.registsharesuc = true;
        setTimeout(() => {
          this.registsharesuc = false;
          this.first6=false;
  this.firstx=true;
  this.first7=true;
          this.spinnerfull.hide();
        }, 3000)   
      }else  if(response.shareholder_response=='1048'){
        this.shareholderr = "NAME IS EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1049'){
        this.shareholderr = "DATE_OF_BIRTH_IS_EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1050'){
        this.shareholderr = "YEARS OF EXPERIENCE IS EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1051'){
        this.shareholderr = "EDUCATION IS EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1052'){
        this.shareholderr = "PERSONAL NET WORTH IS EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1001'){
        this.shareholderr = "FAILURE";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1018'){
        this.shareholderr = "MOBILE_NUMBER_IS_NOT_VALID";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }else  if(response.shareholder_response=='1017'){
        this.shareholderr = "MOBILE_NUMBER_IS_EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 

      }


      else  if(response.shareholder_response=='1253'){
        this.shareholderr = "PLACE OF BIRTH IS EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }
      else  if(response.shareholder_response=='1254'){
        this.shareholderr = "CURRENT RESIDENT LOCATION IS EMPTY";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      } 
      
      else {
        this.shareholderr = "FAILURE";
  
        this.registshareerr = true;
        setTimeout(() => {
          this.registshareerr = false;
        }, 3000) 
      }
    // }else if(response.token_staus =='1120'){
    //   this.shareholderr = "UNAUTHORIZED";
  
    //   this.registshareerr = true;
    //   setTimeout(() => {
    //     this.registshareerr = false;
    //   }, 3000) 
    // }else if(response.token_staus =='1121'){
    //   this.shareholderr = "TOKEN_EXPIRED";
  
    //   this.registshareerr = true;
    //   setTimeout(() => {
    //     this.registshareerr = false;
    //   }, 3000) 
    // }
    }


    changeDate(val) {
     
   
    var age = 18;
    const formattedDate = val;
   
    
    
  if(formattedDate.day > 10 || formattedDate.month > 10) {
  
    this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
    
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;
  
  var currdate = this.todaydate;
  
  if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18
  
  // alert("above 18");
  } else {
 
  this.doberrdis = true;
  this.doberr = 'Date of Birth should be greater than 18 years'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);
  }
    return this.datdob
  
  }
  else{
    this.datdob =  `${formattedDate.year}-0${formattedDate.month}-0${formattedDate.day}`
    
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-0${formattedDate.month -1}-0${formattedDate.day}` ;
    
  var currdate = this.todaydate;
  
  if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18

  //alert("above 18");
  } else {
 
  this.doberrdis = true;
  this.doberr = 'Date of Birth should be greater than 18 years'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);
  
  // alert("below 18");
  }
    return this.datdob
  
  }
  }
  






     addNewAddressGroup() {
      this.countrycode = null;
      const add = this.shareholderform.get('address') as FormArray;
            
       add.push(this.fb.group({
       
        shName:['',[Validators.required,Validators.pattern("^[ ئ ا-ى   ؤ ء ي  ]*$")]],
        mobile:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9), Validators.pattern("^(5)[0-9]{8}$")]],
        shDob:['',Validators.required],
        shExperience:['',Validators.required],
        shEducation:['',Validators.required],
        shPersonalNetWorth:['',Validators.required],
        placeOfBirth:['',[Validators.required,Validators.pattern("^[a-zA-Z]*$")]],
        currentResidentLocation:['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]]
      }))
    } 
  

    deleteAddressGroup(index: number) {
      const add = this.shareholderform.get('address') as FormArray;
      add.removeAt(index)
    }

    navigatearabic(){


      if(this.first1){
        this.token.first1=true;
        this.firstx=false;
        this.router.navigate(['/auth/arsmeregister'])
      }

      

    if(this.first2){
        this.token.first1=false;
        this.token.first2=true;
        this.firstx=true;
        this.router.navigate(['/auth/arsmeregister'])
      }

    if(this.first3){
        this.token.first2=false;
        this.token.first3=true;
        this.firstx=true;
        this.router.navigate(['/auth/arsmeregister'])
      }

      if(this.first4){
        this.token.first3=false;
        this.token.first4=true;
        this.firstx=true;
        this.router.navigate(['/auth/arsmeregister'])
      }

      if(this.first5){
        this.token.first4=false;
        this.token.first5=true;
        this.firstx=true;
        this.router.navigate(['/auth/arsmeregister'])
      }

      if(this.first6){
        this.token.first5=false;
        this.token.first6=true;
        this.firstx=true;
        this.router.navigate(['/auth/arsmeregister'])
      }

      if(this.first7){
        this.token.first6=false;
        this.token.first7=true;
        this.firstx=true;
        this.router.navigate(['/auth/arsmeregister'])
      }


    }

    updrrow(){
      this.count1=this.count1+1;
  //  console.log(this.count)
  //  console.log(this.count1)
  
      if(this.count1 <this.count){
       this.hidecaroselup1=true
    }else{
      // alert("up")
       this.data = JSON.parse(sessionStorage.getItem('currentUser'));
     // if(this.data !=null && this.data !=''){
       this.decdata=this.decryptData(this.data.allowosmerigen);
        this.regstage=this.decdata;
    //   }
     
      if(this.count1 <this.regstage){
        // alert("up")
        this.hidecaroselup1=true;
     }else
    {
      this.hidecaroselup1=false
      this.hidecoroseldown1=true;
      this.count=0;
    }
    }
    }


    logoclear(){
      sessionStorage.clear();
    }



    downdrrow(){
    
      
      // $(".carousel").carousel("next"); 
      
      this.count=this.count+1;
    
      if(this.count <this.regstage){
     this.hidecoroseldown1=true;
     this.hidecaroselup1=true
      }else{
       // alert("down")
     this.hidecoroseldown1=false;
      this.hidecaroselup1=true
      this.count1=0;
      }
       }
  }
  
  
