import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeregistrationComponent } from './smeregistration.component';

describe('SmeregistrationComponent', () => {
  let component: SmeregistrationComponent;
  let fixture: ComponentFixture<SmeregistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeregistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeregistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
