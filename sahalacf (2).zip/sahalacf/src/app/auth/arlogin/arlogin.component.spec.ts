import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArloginComponent } from './arlogin.component';

describe('ArloginComponent', () => {
  let component: ArloginComponent;
  let fixture: ComponentFixture<ArloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
