import { Component, OnInit, ViewEncapsulation, Renderer2 } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidatorFn, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorStateMatcher } from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
// import { TestBed } from '@angular/core/testing';
import { NgxSpinnerService } from "ngx-spinner";

import { RefreshtokenService } from '../../services/refreshtoken.service';




export function MustMatch(controlName: string, matchingControlName: string) {
  return (otpForm: FormGroup) => {
    const control = otpForm.controls[controlName];
    const matchingControl = otpForm.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
           return;
    }
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  }
}


export function MustMatch1(controlName: string, matchingControlName: string) {
  return (forgotOtp: FormGroup) => {
    const control = forgotOtp.controls[controlName];
    const matchingControl = forgotOtp.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
           return;
    }
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  }
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

 
    forgot2Form = false;
    passwordhide = false;
    forgotdata=[];
    hide1 = false;
    hide3=false;
    hide = false;
    hide6 = false;
    submitted4 = false;
    otpsubmitted = false;
    forgot1Form = false;
    sign = false;
    errmsg;
    errmsg1;
    forgotOtp :FormGroup;
    loginResponse: any;
    submitted: boolean;
    forgotForm:FormGroup;
    otpsubmitted1 = false;
    submitted6 = false;
    errorMessage: string;
    loginError: boolean;
    login = true;
    otpform = false;
    deviceInfo = null;
  msgdis;
  msgdis1;
    spinner: boolean;
    passupdatesucc: boolean;
    passupdateSucess: string;
    otperr: boolean;
    otperrmessage: string;
  tokenmsg: any;
  tokener: boolean;
    constructor(private fb: FormBuilder, private router: Router, private http: HttpClient,private token:RefreshtokenService,
      private auth:AuthService,private devicedetect:DeviceDetectorService,private spinnerfull: NgxSpinnerService,
      private deviceservice:DeviceinfoserviceService,private renderer: Renderer2) {
  
        this.renderer.setStyle(document.body, 'background-color', 'white');
  
      this.token.unauthmsg.subscribe(message =>{
        console.log(message)
        

        if(message != 'default token') {
          
      this.tokener = true;
      this.tokenmsg = message
      setTimeout(() => {
        this.tokener = false;
      }, 9000); 

        }
        else { 
          this.tokenmsg = ''
        }
      })
  
    }
    loginForm: FormGroup;
    otpForm: FormGroup;
    geolocationPosition: object;
    longitude: string;
    latitude: string;
    ipAddress: string;
  
  
    ngOnInit() {
  
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
          history.go(1);
      };
      
  
      this.http.get<{ ip: string }>('https://jsonip.com/')
        .subscribe(geoLocationResponse => {
          this.ipAddress = geoLocationResponse.ip;
        });
      //     this.authService.getIp().subscribe(response=>{
      // response
  
      //     })
      this.geolocationPosition = {};
      if (window.navigator && window.navigator.geolocation) {
        window.navigator.geolocation.getCurrentPosition(
          position => {
            this.geolocationPosition = position;
          }
        );
      } else {
  
      }
      this.loginForm = this.fb.group({
        useremail: ['', [Validators.required,Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
      });
  
  
  
      this.otpForm = this.fb.group({
        otp: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(6), Validators.pattern("^[0-9]*$")]],
  
      });
  
      this.forgotForm = this.fb.group({
        email: ['', [Validators.required, Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")]],
    
      });
  
      this.forgotOtp = this.fb.group({
        otp: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(6), Validators.pattern("^[0-9]*$")]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]],
        confirmpassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
      },{
        validator: MustMatch1('password', 'confirmpassword')
        });
  
  
    }
    // get password() { return this.forgotOtp.get('password'); }
    // get confirmpassword() { return this.forgotOtp.get('confirmpassword'); }
  
    get loginControllers() { return this.loginForm.controls }
  
    get Otpcontrol() { return this.otpForm.controls }
  
    get e() {
      return this.forgotForm.controls
    }
    get o() {
      return this.forgotOtp.controls
    }
     onPasswordInput() {
    //   if (this.forgotOtp.hasError('passwordMismatch'))
    //     this.confirmpassword.setErrors([{'passwordMismatch': true}]);
    //   else
    //     this.confirmpassword.setErrors(null);
     }
  
  
    showPosition(position) {
      if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
      } else {
  
      }
    }
  
  
  
  
    
  
  
    isUserAuthenticated() {
      //this.loginForm.markAllAsTouched();
      //console.log("_____________________________--------------------------")
      console.log(this.loginForm.valid)
      this.submitted = true;
  if(this.loginForm.valid) {
    
  const obj:any = {}
  
  //obj['email'] = this.loginForm.value.useremail;
  //obj['password'] = this.loginForm.value.password;
    
    obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
    obj['deviceType'] = 'Web';
    obj['iPAddress'] = this.deviceservice.deviceinfo.ipAdress;
    obj['longitude'] = this.deviceservice.deviceinfo.logintude;
    obj['latitude'] = this.deviceservice.deviceinfo.latitude;
    obj['browserType'] = this.deviceservice.deviceinfo.browserType;
    obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
    obj['osType'] = this.deviceservice.deviceinfo.osType;
    obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
    obj['language'] ='en';
  
  
   //this.spinner = true;
  this.spinnerfull.show();
  this.auth.isauthenticated(obj, this.loginForm.value.useremail,this.loginForm.value.password).subscribe(res =>{
    // console.log(res)
    //this.spinner = false;
    this.spinnerfull.hide();
    const object:any = {}
    if(res.login_status =='1000'){
    
      object['FirstName']  = res.FirstName;
      object['LastName']     = res.LastName;
      object['LastLogin']    = res.LastLogin;
      object['isMobileVerified']   = res.isMobileVerified;
      object['isEmailVerified']   = res.isEmailVerified;
      object['accesstoken']   = res.token;
      object['ProfilePic'] = res.ProfilePic;
      object['id']=res.id
      object['profileStatus']=res.profileStatus
      if(res.UserType == 'SME') {
        this.router.navigate(['/englishwebsmeapp/webappdashboard'])
        object['redirect'] = "englishwebsmeapp";
        object['isBankInformationProvided']    = res.isBankInformationProvided;
        object['isCompnayInformationProvided']    = res.isCompnayInformationProvided;
        object['isDcoumentsInformationProvided']   = res.isDcoumentsInformationProvided;
        object['isShareHolderInformationProvided'] = res.isShareHolderInformationProvided;
        object['isPolicyAccepted'] = res.isPolicyAccepted;
        object['isTermsAccepted'] = res.isTermsAccepted;
      } 
      else { 
   
        this.router.navigate(['/englishwebapp/webappdashboard'])
        object['redirect'] = "englishwebapp";
        object['isPolicyAccepted']  = res.isPolicyAccepted;
        object['isBankInfoProvided']   = res.isBankInfoProvided;
        object['isInvestorInfoProvided']  = res.isInvestorInfoProvided;
        object['isTermsAccepted']  = res.isTermsAccepted;
        object['isBankAccountLetterUploaded'] = res.isBankAccountLetterUploaded;
      }
  
      sessionStorage.setItem('currentUser',JSON.stringify(object))
      this.token.changeMessage(res);
    }
  
    else if(res.login_status == '1002') {
    
      this.msgdis = true;
      this.errmsg = 'SOME THING WENT WRONG';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1023') {
    
      this.msgdis = true;
      this.errmsg = 'EMAIL ID IS EMPTY';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    } 
    else if(res.login_status == '1024') {
    
      this.msgdis = true;
      this.errmsg = 'EMAIL ID IS NOT VALID';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1025') {
     
      this.msgdis = true;
      this.errmsg = 'PASSWORD IS EMPTY';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
    else if(res.login_status == '1026') {
   
      this.msgdis = true;
      this.errmsg = 'PASSWORD SHOULD BE MIN 8 AND MAX 20';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1013') {
   
      this.msgdis = true;
      this.errmsg = 'SOME THING WENT WRONG';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1014') {
    
      this.msgdis = true;
      this.errmsg = 'SOME THING WENT WRONG';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1011') {
     
      this.msgdis = true;
      this.errmsg = 'SOME THING WENT WRONG';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1012') {
   
      this.msgdis = true;
      this.errmsg = 'SOME THING WENT WRONG';
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
      else if(res.login_status == '1003') {
       
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1004') {
       
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1005') {
      
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1006') {
        
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1007') {
    
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
  
      else if(res.login_status == '1009') {
     
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1010') {
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
  
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1008') {
       
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1015') {
      
        this.msgdis = true;
        this.errmsg = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
        else if(res.login_status == '1016') {
         
          this.msgdis = true;
          this.errmsg = 'SOME THING WENT WRONG';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1090') {
        
          this.msgdis = true;
          this.errmsg = 'SOME THING WENT WRONG';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1091') {
       
          this.msgdis = true;
          this.errmsg = 'SOME THING WENT WRONG';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1092') {
        
          this.msgdis = true;
          this.errmsg = 'SOME THING WENT WRONG';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
        else if(res.login_status == '1095') {
        
          this.msgdis = true;
          this.errmsg = 'EMAIL OR PASSWORD INVALID';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1099') {
        
          this.msgdis = true;
          this.errmsg = 'YOUR ACCOUNT IS TEMPORARILY SUSPENDED, PLEASE CONTACT CUSTOMER SUPPORT AT +920092 OR WRITE TO US AT support@sahlahcf.com FROM YOUR REGISTERED EMAIL ADDRESS ';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1093') {
      
          this.msgdis = true;
          this.errmsg = 'SOME THING WENT WRONG';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1097') {
          this.errmsg = 'OTP SENT';
          // this.msgdis = true;
          // setTimeout(() => {
          //   this.msgdis = false;
          // }, 3000);
          this.otpform = true;
          this.login = false;
  
  
        }
        else if(res.login_status == '1096') {
        
          this.msgdis = true;
          this.errmsg = 'EMAIL OR PASSWORD INVALID';
          setTimeout(() => {
            this.msgdis = false;
          }, 300000);
        }
  
        else if(res.login_status == '1098') {
        
          this.msgdis = true;
          this.errmsg = 'OTP NOT SENT ';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1094') {
       
          this.msgdis = true;
          this.errmsg = 'SOME THING WENT WRONG';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1001') {
    
          this.msgdis = true;
          this.errmsg = 'FAILURE';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
  
        else if(res.login_status == '1100') {
    
          this.msgdis = true;
          this.errmsg = 'ACCOUNT BLOCKED TRY AFTER SOME TIME';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
  
  })
  }
  
    }
  
    signup() {
      this.sign = !this.sign;
      if(this.sign){
      this.sign = true;
      } else {
        this.sign = false;
      }
    }
  
   
  
  
    isOtpVerified() {
      this.otpsubmitted = true;
      if(this.otpForm.valid) {
        const obj:any = []
        obj['email'] = this.loginForm.value.useremail;
  obj['password'] = this.loginForm.value.password;
    
    obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
    obj['deviceType'] = 'Web';
    obj['iPAddress'] = this.deviceservice.deviceinfo.ipAdress;
    obj['longitude'] = this.deviceservice.deviceinfo.logintude;
    obj['latitude'] = this.deviceservice.deviceinfo.latitude;
    obj['browserType'] = this.deviceservice.deviceinfo.browserType;
    obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
    obj['osType'] = this.deviceservice.deviceinfo.osType;
    obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
    obj['language'] ='en'
    obj['otp'] = this.otpForm.value.otp;
  
    // console.log(obj)
    //this.spinner = true;
    this.spinnerfull.show();
  this.auth.loginotpverified(obj).subscribe(res =>{
    this.spinnerfull.hide();
     console.log(res)
    const object:any  = {}
    if(res.login_status =='1000'){
      object['FirstName']  = res.FirstName;
      object['LastName']     = res.LastName;
      object['LastLogin']    = res.LastLogin;
      object['isMobileVerified']   = res.isMobileVerified;
      object['isEmailVerified']   = res.isEmailVerified;
      object['accesstoken']   = res.token;
      object['ProfilePic'] = res.ProfilePic;
      object['id']=res.id
      object['profileStatus']=res.profileStatus
      if(res.UserType == 'SME') {
        this.router.navigate(['/englishwebsmeapp/webappdashboard'])
        object['redirect'] = "englishwebsmeapp";
        object['isBankInformationProvided']    = res.isBankInformationProvided;
        object['isCompnayInformationProvided']    = res.isCompnayInformationProvided;
        object['isDcoumentsInformationProvided']   = res.isDcoumentsInformationProvided;
        object['isShareHolderInformationProvided'] = res.isShareHolderInformationProvided;
        object['isPolicyAccepted'] = res.isPolicyAccepted;
        object['isTermsAccepted'] = res.isTermsAccepted;
      } 
      else { 
   
        this.router.navigate(['/englishwebapp/webappdashboard'])
        object['redirect'] = "englishwebapp";
        object['isPolicyAccepted']  = res.isPolicyAccepted;
        object['isBankInfoProvided']   = res.isBankInfoProvided;
        object['isInvestorInfoProvided']  = res.isInvestorInfoProvided;
        object['isTermsAccepted']  = res.isTermsAccepted;
        object['isBankAccountLetterUploaded'] = res.isBankAccountLetterUploaded;
      }
  
      sessionStorage.setItem('currentUser',JSON.stringify(object))
      this.token.changeMessage(res);
    }
    
    else if(res.login_status == '1002') {
      this.errmsg = 'SOME THING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1023') {
      this.errmsg = 'EMAIL ID IS EMPTY';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1024') {
      this.errmsg = 'EMAIL ID IS NOT VALID';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1025') {
      this.errmsg = 'PASSWORD IS EMPTY';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
    else if(res.login_status == '1026') {
      this.errmsg = 'PASSWORD SHOULD BE MIN 8 AND MAX 20';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1013') {
      this.errmsg = 'SOME THING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1014') {
      this.errmsg = 'SOME THING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1011') {
      this.errmsg = 'SOME THING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
    else if(res.login_status == '1012') {
      this.errmsg = 'SOME THING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
        this.msgdis = false;
      }, 3000);
    }
  
      else if(res.login_status == '1003') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1004') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1005') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1006') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1007') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
  
      else if(res.login_status == '1009') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1010') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1008') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
      else if(res.login_status == '1015') {
        this.errmsg = 'SOME THING WENT WRONG';
        this.msgdis = true;
        setTimeout(() => {
          this.msgdis = false;
        }, 3000);
      }
        else if(res.login_status == '1016') {
          this.errmsg = 'SOME THING WENT WRONG';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1090') {
          this.errmsg = 'OTP IS EMPTY';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1091') {
          this.errmsg = 'OTP SHOULD BE NUMERIC';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1092') {
          this.errmsg = 'OTP LENGTH SHOULD BE 4 DIGITS';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
        else if(res.login_status == '1095') {
          this.errmsg = 'ACCOUNT DOES NOT EXIST';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1099') {
          this.errmsg = 'YOUR ACCOUNT IS TEMPORARILY SUSPENDED, PLEASE CONTACT CUSTOMER SUPPORT AT +920092 OR WRITE TO US AT support@sahlahcf.com FROM YOUR REGISTERED EMAIL ADDRESS ';

          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1093') {
          this.errmsg = 'SOME THING WENT WRONG';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
       
        else if(res.login_status == '1096') {
          this.errmsg = 'INVALID CREDENTIALS ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
        else if(res.login_status == '1098') {
          this.errmsg = 'OTP NOT SENT ';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1099') {
          this.errmsg = 'YOUR ACCOUNT IS TEMPORARILY SUSPENDED, PLEASE CONTACT CUSTOMER SUPPORT AT +920092 OR WRITE TO US AT support@sahlahcf.com FROM YOUR REGISTERED EMAIL ADDRESS ';

          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1094') {
          this.errmsg = 'SOME THING WENT WRONG';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1095') {
          this.errmsg = 'ACCOUNT DOES NOT EXIST';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
        else if(res.login_status == '1001') {
          this.errmsg = 'FAILURE';
          this.msgdis = true;
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  
  
  
        else if(res.login_status == '1100') {
    
          this.msgdis = true;
          this.errmsg = 'ACCOUNT BLOCKED TRY AFTER SOME TIME';
          setTimeout(() => {
            this.msgdis = false;
          }, 3000);
        }
  })
      }
  
     
  
    }
  
    forgot() {
      this.forgot1Form = true;
      this.login = false;
    
    }
    forgetBack(){
   
      this.forgot1Form = false;
      this.login = true;
    }
  
    forgot1(){
      this.submitted4 = true;
    
      this.login = false;
      if(this.forgotForm.valid) {
        const obj :any ={}
        obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
        obj['deviceType'] = 'Web';
        obj['ipAddress'] = this.deviceservice.deviceinfo.ipAdress;
        obj['longitude'] = this.deviceservice.deviceinfo.logintude;
        obj['latitude'] = this.deviceservice.deviceinfo.latitude;
        obj['browserType'] = this.deviceservice.deviceinfo.browserType;
        obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
        obj['osType'] = this.deviceservice.deviceinfo.osType;
        obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
        obj['language'] ='en'
        obj['email'] = this.forgotForm.value.email;
        obj['countryCode'] = 'SA';
        
      
  
  // this.spinner = true;
  this.spinnerfull.show();
  this.auth.forgotpassword(obj).subscribe(res =>{
  
    this.spinnerfull.hide();
  
    if(res.forgetpwd_response =='1000'){
      this.forgot2Form = true;
      this.forgot1Form = false;
    }
   else if(res.forgetpwd_response == '1001'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if (res.forgetpwd_response == '1002'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1003'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1004'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
  
    else if(res.forgetpwd_response == '1005'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1006'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1007'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1008'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1009'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1010'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1011'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1012'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1013'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
      else if(res.forgetpwd_response == '1014'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1015'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1016'){
      this.errmsg1 ='SOME THING WENT WRONG';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    }
    else if(res.forgetpwd_response == '1023'){
      this.errmsg1 ='EMAIL ID IS EMPTY';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
    } 
    else if(res.forgetpwd_response == '1024'){
      this.errmsg1 ='EMAIL ID IS NOT VALID';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
     }
    else if(res.forgetpwd_response == '1095'){
      this.errmsg1 ='ACCOUNT DOES NOT EXIST';
      this.msgdis1=true;
      setTimeout(() => {
        this.msgdis1 = false;
      }, 3000);
     }
  
  
  
      })
      
    }
  }
  
  passwordpage(){
   if(this.forgotOtp.value.otp.length >= 6){
    this.otperrmessage='';
    this.forgot1Form = false;
    this.login = false;
    this.forgot2Form = true;
    this.passwordhide = true;
   }
   else {
    this.passwordhide = false;
    this.otperrmessage="Enter Valid OTP to Proceed Further"
    // this.otperr=true;
    // setTimeout(() => {
    //   this.otperr = false;
    // }, 3000);
   }
  }
  
    otpsave() {
      this.submitted6 = true;
      this.forgot1Form = false;
      this.login = false;
    if(this.forgotOtp.valid) {
      const obj :any ={}
      obj['deviceId'] = this.deviceservice.deviceinfo.deviceId;
      obj['deviceType'] = 'Web';
      obj['ipAddress'] = this.deviceservice.deviceinfo.ipAdress;
      obj['longitude'] = this.deviceservice.deviceinfo.logintude;
      obj['latitude'] = this.deviceservice.deviceinfo.latitude;
      obj['browserType'] = this.deviceservice.deviceinfo.browserType;
      obj['browserVersion'] = this.deviceservice.deviceinfo.browserVersion;
      obj['osType'] = this.deviceservice.deviceinfo.osType;
      obj['osVersion'] = this.deviceservice.deviceinfo.osVersion;
      obj['language'] ='en'
      obj['email'] = this.forgotForm.value.email;
      obj['countryCode'] = 'SA';
      obj['otp'] = this.forgotOtp.value.otp;
      obj['newPassword'] = this.forgotOtp.value.password;
      obj['conformPassword'] = this.forgotOtp.value.confirmpassword;
  
      // console.log(obj)
      this.spinnerfull.show();
      this.auth.forgotpasswordotp(obj).subscribe(res =>{
        this.spinnerfull.hide();
        this.spinner = false;
        if(res.forgetpwd_response =='1000'){
          this.forgotOtp.reset();
          this.forgotForm.reset();
          this.submitted6 = false;
         this.passupdateSucess="Passoword Updated SucessFully";
         this.passupdatesucc=true;
         setTimeout(() => {
           this.passupdatesucc = false;
           this.login=true;
           this.forgot2Form=false;
         }, 3000);
        }
       else if(res.forgetpwd_response == '1001'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if (res.forgetpwd_response == '1002'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1003'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1004'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
      
        else if(res.forgetpwd_response == '1005'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1006'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1007'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1008'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1009'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1010'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1011'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1012'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1013'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
          else if(res.forgetpwd_response == '1014'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1015'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1016'){
          this.errmsg1 ='SOME THING WENT WRONG';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        }
        else if(res.forgetpwd_response == '1023'){
          this.errmsg1 ='EMAIL ID IS EMPTY';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
        } 
        else if(res.forgetpwd_response == '1024'){
          this.errmsg1 ='EMAIL ID IS NOT VALID';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
        else if(res.forgetpwd_response == '1093'){
          this.errmsg1 ='OTP IS INVALID';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1085'){
          this.errmsg1 ='NEW PASSWORD IS EMPTY';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1086'){
          this.errmsg1 ='CONFORM PASSWORD IS EMPTY';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
  
         else if(res.forgetpwd_response == '1087'){
          this.errmsg1 ='NEW PASSWORD LEANGTH SHOULD BE MIN 8 AND MAX 16';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1088'){
          this.errmsg1 ='CONFIRM PASSWORD LEANGTH SHOULD BE MIN 8 AND MAX 16';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1089'){
          this.errmsg1 ='NEW PASSOWRD AND CONFORM PASSWORD ARE NOT SAME';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1090'){
          this.errmsg1 ='Email Or Password Invalid';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1090'){
          this.errmsg1 ='OTP IS EMPTY';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1091'){
          this.errmsg1 ='OTP SHOULD BE NUMERIC';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1092'){
          this.errmsg1 ='OTP LEANGTH SHOULD BE 4 DIGITS';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1042'){
          this.errmsg1 ='Email Or Password Invalid';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
         else if(res.forgetpwd_response == '1094'){
          this.errmsg1 ='OTP Expired';
          this.msgdis1=true;
          setTimeout(() => {
            this.msgdis1 = false;
          }, 3000);
         }
      })
  
    }
  
     
    } 
  
    
    navigatearabic(){
      this.router.navigate(['/arhome'])
    }
    otpBack(){
      this.forgot2Form=false
      this.forgot1Form=true;
    }
    
  }
  
