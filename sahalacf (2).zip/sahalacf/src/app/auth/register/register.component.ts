import { Component, OnInit, Injectable } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import { DeviceDetectorService } from 'ngx-device-detector';
import * as CryptoJS from 'crypto-js';
import { NgxSpinnerService } from "ngx-spinner";
import * as moment from 'moment';
declare var $: any;
import {NgbDateStruct, NgbDatepickerConfig} from '@ng-bootstrap/ng-bootstrap';
import {ErrorStateMatcher, NativeDateAdapter, MAT_DATE_FORMATS, DateAdapter} from '@angular/material/core';


import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { DateType } from 'ngx-hijri-gregorian-datepicker';
import { formatDate, CurrencyPipe } from '@angular/common';
import {
   NgbCalendar, NgbCalendarIslamicUmalqura, NgbDatepickerI18n
} from '@ng-bootstrap/ng-bootstrap';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';

// const WEEKDAYS = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];
// const MONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال',
//   'ذو القعدة', 'ذو الحجة'];

// @Injectable()
// export class IslamicI18n extends NgbDatepickerI18n {

//   getWeekdayShortName(weekday: number) {
//     return WEEKDAYS[weekday - 1];
//   }

//   getMonthShortName(month: number) {
//     return MONTHS[month - 1];
//   }

//   getMonthFullName(month: number) {
//     return MONTHS[month - 1];
//   }

//   getDayAriaLabel(date: NgbDateStruct): string {
//     return `${date.day}-${date.month}-${date.year}`;
//   }
// }

interface Food {
  value: string;
  viewValue: string;
} 

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'dd/MM/yyyy',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}




export const passwordMatchValidator: ValidatorFn = (registrationForm: FormGroup): ValidationErrors | null => {
  if (registrationForm.get('password').value === registrationForm.get('conformpassword').value)
    return null;
  else
    return {passwordMismatch: true};
};

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, registrationForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = registrationForm && registrationForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}




@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS},
    // {provide: NgbCalendar, useClass: NgbCalendarIslamicUmalqura},
    // {provide: NgbDatepickerI18n, useClass: IslamicI18n}
]
})
export class RegisterComponent implements OnInit {
  model: NgbDateStruct;
  model1: NgbDateStruct;
  date:  NgbDate;
selectedDateType  =  DateType.Hijri;  // or DateType.Gregorian

  secondnext = true;
  hide = true;
  hide1 = true;
  hide3 = true;

  minDate: { year: number; month: number; day: number; };
  registrationForm:FormGroup;
  submitted=false;
  first1:boolean=true;
  first2:boolean=false;
  first3:boolean=false;
  first4:boolean=false;
  first5:boolean=false;
  ipAddress: string;
  geolocationPosition: object;
  latitude: any;
  longitude: any;
  deviceInfo: any;
  responseMessgae: string;
  registError: boolean;
  investorInfoForm:FormGroup;
  submitted1: boolean;
  submitted2:boolean;
  dateofbirth: any;
  otpForm:FormGroup
  yourInfoForm:FormGroup;
  submitted3: boolean;
  investorInfoMessage: string;
  investorYourInfoMessage: string;
  incomeinfoForm:FormGroup
  incomeInfoMessage: string;
  bankinginfoForm:FormGroup;
  uploadfileForm:FormGroup;
  msg: string;
  msgError: boolean;
  verifyotp=true;
  timeout = 120;
  sendotp: boolean;
  hidetimer: boolean;
saudi =true;
nonsaudi:boolean;


  successmsg = 'تم التحقق من المعلومات بنجاح';
  foods: Food[] = [
    {value: '1-50,000', viewValue: '1-50,000'},
    {value: '50,000-100,000', viewValue: '50,000-100,000'},
    {value: '100,000-1,50,000', viewValue: '100,000-1,50,000'},
    {value: '1,50,000-2,50,000', viewValue: '1,50,000-2,50,000'},
    {value: '2,50,000-5,00,000', viewValue: '2,50,000-5,00,000'},
    {value: '5,00,000 Above', viewValue: '5,00,000 Above'}
  ];
  anualincome: Food[] = [
    {value: 'من 1 إلى 50,000', viewValue: 'من 1 إلى 50,000'},

    {value: 'من 500,000 إلى 100,000', viewValue: 'من 500,000 إلى 100,000'},

    {value: 'من 100,000 إلى 150,000', viewValue: 'من 100,000 إلى 150,000'},

    {value: 'من 150,000 إلى 250,000', viewValue: 'من 150,000 إلى 250,000'},

    {value: 'من  2,50,000 إلى 5,00,000', viewValue: 'من  2,50,000 إلى 5,00,000'},

    {value: 'اكتر من 5,00,000', viewValue: ' اكتر من 5,00,000'}
  ];
  sourceincome: Food[] = [
    {value: 'راتب', viewValue: 'راتب'},
    {value: 'مستقل', viewValue: 'مستقل'},
    {value:'موظف قطاع خاص',viewValue:'موظف قطاع خاص'},
    {value:'موظف حكومي',viewValue:'موظف حكومي'},
    {value: 'آخر', viewValue: 'آخر'},
         
  ];
  jobstatus = [
    {value: 'صاحب العمل', viewValue: 'صاحب العمل'},
    {value: 'طالب', viewValue: 'طالب'},
    {value: 'آخر', viewValue: 'آخر'}
  ];


  banks = [
    {value: 'البنك الأول', viewValue: 'البنك الأول'},
    {value: 'البنك العربي الوطني', viewValue: 'البنك العربي الوطني'},
    {value: 'مصرف الراجحي', viewValue: 'مصرف الراجحي'}, 
    {value: 'البنك السعودي الفرنسي', viewValue: 'البنك السعودي الفرنسي'},
    {value: 'مصرف الإنماء ', viewValue: 'مصرف الإنماء '},

    {value: 'بنك البلاد', viewValue: 'بنك البلاد'},
    {value: 'بنك مسقط', viewValue: 'بنك مسقط'},
    {value: 'بنك الجزيرة ', viewValue: 'بنك الجزيرة '},
    {value: 'دويتشه بنك', viewValue: ' دويتشه بنك'},
    {value: 'بنك الإمارات', viewValue: 'بنك الإمارات'},
    {value: 'بنك الخليج الدولي', viewValue: 'بنك الخليج الدولي'},
    {value: 'البنك الأهلي التجاري', viewValue: 'البنك الأهلي التجاري'},

    {value: 'بنك البحرين الوطني', viewValue: 'بنك البحرين الوطني'},

    {value: 'بنك الكويت الوطني', viewValue: 'بنك الكويت الوطني'},

    {value: 'البنك الوطني الباكستاني', viewValue: 'البنك الوطني الباكستاني'},

     {value: 'بنك الرياض', viewValue: 'بنك الرياض'},
    {value: 'البنك السعودي للإستثمار', viewValue: 'البنك السعودي للإستثمار'},
    {value: '(البنك السعودي الأمريكي (سامبا ', viewValue: '(البنك السعودي الأمريكي (سامبا '},
    {value: 'مؤسسة النقد العربي السعودي ', viewValue: 'مؤسسة النقد العربي السعودي '},
    // {value: 'SAUDI AMERICAN BANK', viewValue: 'SAUDI AMERICAN BANK'},
     {value:'(البنك السعودي البريطاني(ساب', viewValue:'(البنك السعودي البريطاني(ساب'},
    // {value: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI', viewValue: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI'},
    
  ];
  accounts= [
    {value: 'INDB12545545', viewValue: 'INDB12545545'},
    {value: 'ANDB12545545', viewValue: 'ANDB12545545'},
    {value: 'AXDB12545545', viewValue: 'AXDB12545545'}
  ];
  ibans  = [
    {value: 'DFG4W42342424', viewValue: 'DFG4W42342424'},
    {value: 'egG4W42342424', viewValue: 'egG4W42342424'},
    {value: 'hiG4W42342424', viewValue: 'hiG4W42342424'}
  ];
  accesstoken: any;
  data: any;
  registSucessError: boolean;
  responseSucessMessgae: string;
  selectErrorMsg: string;
  registotpsuceError: boolean;
  responseOtpSucessMessgae: string;
  investotpsucesstError: boolean;
  investorInfootpSucessMessage: string;
  investorSucessYourInfoMessage: string;
  investorsucesError: boolean;
  ivesyourinfoError: boolean;
  incomeError: boolean;
  incomeInfoSucessMessage: string;
  responseBankSucessMessgae: string;
  uploadError: boolean;
  responseuploadsucessMessgae: string;
  countrycode: number;
  registResponseError: boolean;
  hidecoroseldown: boolean;
  regstage: any;
  count=0; 
  count1=0;
  hidecaroselup=false;
  firstcheck: any;
  checkansterms: string;
  yourInfononForm:FormGroup;
  firstcheckpolicy: any;
  checkanspolicy: string;
  stage: any;
  encryptSecretKey="sahlahcf";
  encriptdata: any;
  decdata: any;
  responseInvesregerrMessgae: string;
  otpcount: number;
  counter: any;
  uploadfilesize: any;
  fileerror: string;
  fileError: boolean;
  termsprivacy: string;
  termsprivacyError: boolean;
  dataaaaae: string;
  datdob: any;
  maxDate: Date;
  dateerr: string;
  todaydate: any;
  doberr: string;
  dobdatcurrent: boolean;
  doberrdis: boolean;
  nationdis: boolean;
  doberrdiseng: boolean;
  currdate: any;
  setDate: any;
  finalengcurrentdat: any;
  bobdattt: string;
  datewchange: string | number | Date;
  bobdatttexpire: any;
  currentengdob: string | number | Date;
  submitted9: boolean;
  doberreng: string;
  submittedu: boolean;
  resendotpbutton: boolean;
  bankresponseMessgae: string;

  constructor(private fb: FormBuilder,private calendar: NgbCalendar,private config: NgbDatepickerConfig,
    private deviceinfoservice:DeviceinfoserviceService,private router:Router ,private authService:AuthService,
    private deviceService: DeviceDetectorService,private spinnerfull: NgxSpinnerService,
    private token:RefreshtokenService


   ) {
 


    if(token.first2){
      this.first1=false;
      this.first2=true;
    }

   if(token.first3){
    this.first3 = true;
      this.first1 = false;
      this.first2 = false;
    }
    if(token.first4){
      this.first4 = true;
        this.first1 = false;
        this.first2 = false;
        this.first3 = false;
      }
      if(token.first5){
        this.first5 = true;
          this.first1 = false;
          this.first2 = false;
          this.first3 = false;
          this.first4 = false;
        }

    const current = new Date();
   
    const hijridate = new Intl.DateTimeFormat('ar-FR-u-ca-islamic', {day: 'numeric', month: 'numeric',year : 'numeric'}).format(Date.now());
    
    this.minDate = {
    year: current.getFullYear(),
    month: current.getMonth() + 1,
    day: current.getDate()
    };





    this.responseMessgae='';

    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data !=null && this.data !=''){
     
      // console.log(this.data.alloworigen)
    this.stage=  this.decryptData(this.data.alloworigen)
      if(parseInt(this.stage) >=1){
      
        this.regstage= this.stage
      this. hidecoroseldown=true;
      }else{
        this. hidecoroseldown=false;
      }
    }
 
    }




  ngOnInit(): void {

   this. selectToday();


   
this.maxDate = new Date();
    this.registrationForm=this.fb.group({
      firstName: ['', [Validators.required, Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      lastName: ['', [Validators.required,  Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
    
     
      email:['',[Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),Validators.required]],
      mobileNo: ['', [Validators.required,Validators.minLength(9), Validators.maxLength(9), Validators.pattern("^(5)[0-9]{8}$")]],
      password:['', [Validators.required, Validators.minLength(8), Validators.maxLength(20), Validators.pattern('^[^ ].+[^ ]$')]],
      conformpassword:['', [Validators.required, Validators.minLength(8), Validators.maxLength(20), Validators.pattern('^[^ ].+[^ ]$')]],
      recaptchaReactive:['',Validators.required],
    },{
      validator: passwordMatchValidator
    });
    this.investorInfoForm=this.fb.group({
      nationality:['',[Validators.required]],
      nationalId:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),]],
      Dob:['',[Validators.required]],
      placeOfBirth:['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]],
      currentResidentLocation:['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]]
     
    });
  
  this.otpForm=this.fb.group({
    otp:['',[Validators.required,Validators.minLength(6), Validators.maxLength(6),Validators.pattern("^[0-9]*$")]],
  });
  
  
  // this.yourInfononForm=this.fb.group({
  //   nameen:['',[Validators.required,Validators.pattern("^[a-zA-Z ]*$")]],
  //   namear:['',[Validators.required,Validators.pattern("^[ ئ ا-ى   ؤ ء ي  ]*$")]],
    
  //     gender:['',[Validators.required]],
  //     idexpirationdateeng:['',[Validators.required]]
  // });
 
  this.yourInfoForm=this.fb.group({
    nameen:['',[Validators.required,Validators.pattern("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$")]],
    namear:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF\ ]*$')]],

      idexpirationdate:['',[Validators.required]],
      gender:['',[Validators.required]],
  
  });
 
    this.incomeinfoForm = this.fb.group({
      anualIncome:['',Validators.required],
      sourceIncome:['',Validators.required],
      jobStatus:['',Validators.required]
    }),
    this.bankinginfoForm = this.fb.group({
      bankName:['',Validators.required],
      bankIBAN:['',[Validators.required, Validators.maxLength(30),Validators.pattern('^[A-Za-z0-9]*$')]],
      bankAccountHolderName: ['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],

    }),
    this.uploadfileForm = this.fb.group({
      bank_account_letter: ['',Validators.required],
      terms_and_conditions:['',Validators.required],
      privacy_policy:['',Validators.required]
    })





    $('.carousel .vertical .item').each(function(){
      var next = $(this).next();
      if (!next.length) {
        next = $(this).siblings(':first');
      }
      next.children(':first-child').clone().appendTo($(this));
      
      for (var i=1;i<2;i++) {
        next=next.next();
        if (!next.length) {
          next = $(this).siblings(':first');
        }
        
        next.children(':first-child').clone().appendTo($(this));
      }
    });

  
  }
  encryptData(data) {

    try {
    
      // this.decryptData(CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString()) 
      this.encriptdata=CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString();
      return CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString();
     
    } catch (e) {
      // console.log(e);
    }
  }

  onPasswordInput() {
    if (this.registrationForm.hasError('passwordMismatch'))
      this.conformpassword.setErrors([{'passwordMismatch': true}]);
    else
      this.conformpassword.setErrors(null);
  }
  

  selectToday() {
    this.model = this.calendar.getToday();
  

    this.todaydate =  `${this.model.year}-${this.model.month}-${this.model.day}`

 
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  decryptData(data) {
  
    try {
      const bytes = CryptoJS.AES.decrypt(data, this.encryptSecretKey);
      if (bytes.toString()) {
       // console.log(JSON.parse(bytes.toString(CryptoJS.enc.Utf8)))
        return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
      }
     // console.log(data)
      return data;
      
    } catch (e) {
      // console.log(e);
    }
  }
  get password() { return this.registrationForm.get('password'); }
  get conformpassword() { return this.registrationForm.get('conformpassword'); }
  get f() {
    return this.uploadfileForm.controls;
  }

  get o(){
    return this.uploadfileForm.controls;
  }
  get registrationControllers() { return this.registrationForm.controls }
  get investerInfoOtpControllers() { return this.investorInfoForm.controls }
  get investeryourInfoControllers() { return this.yourInfoForm.controls }
  get investeryourInfononControllers() { return this.yourInfononForm.controls }
  
  
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();

    // console.log(this.deviceInfo)
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.investorInfoForm.controls[controlName].hasError(errorName);
  }
  


  RegistrationDetails(){
  this.countrycode = null;
    this.submitted=true; 
    this.registrationForm.markAllAsTouched();
    // console.log(this.registrationForm.value)
    if(this.registrationForm.valid){
      this.countrycode = 966
      this.detectDevice();
      // this.showPosition(this.geolocationPosition);
      const object: any = {}
        object['browserType'] = this.deviceInfo.browser;
        object['browserVersion'] = this.deviceInfo.browser_version;
        object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
        object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
        object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
        object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
        object['language'] = 'ar';
        object['countryCode'] = 'SA';
        //object['email'] = this.registrationForm.value.email
        object['firstName'] = this.registrationForm.value.firstName
        object['lastName'] = this.registrationForm.value.lastName
       // object['password'] = this.registrationForm.value.password
        object['osVersion'] = this.deviceInfo.os_version;
        object['osType'] = this.deviceInfo.os;
        object['mobile'] = this.countrycode + this.registrationForm.value.mobileNo
        object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
        object['registrationType'] = 'Investor';
        object['recaptchaResponse'] = this.registrationForm.value.recaptchaReactive;
      
        
        // 
        this.spinnerfull.show();
  this.authService.RegistrationDetails(object, this.registrationForm.value.email,this.registrationForm.value.password).subscribe(response =>
    this.registrationDetailsSubmit(response)
    )
    }
  }


  registrationDetailsSubmit(response){
    
    this.registrationForm.controls['recaptchaReactive'].reset();
    if(response.Registration_Response== 1000){
      const object: any = {}
      this.encryptData(1)
      object.accesstoken = response.token;
      object.alloworigen =  this.encriptdata
      this.hidecaroselup=true;
      this.token.changeMessagereg(response); 
      sessionStorage.setItem('currentUser', JSON.stringify(object))
      this.responseSucessMessgae = " المستثمر مسجل بنجاح";
      this.registrationForm.reset();
  
                this.registSucessError = true;
                setTimeout(() => {
                  this.registSucessError = false;
                  this.spinnerfull.hide();
               
                  this.first1=false;
                  this.first2=true;
                }, 3000)

               
    }
    else if(response.Registration_Response == 1194){
      this.responseInvesregerrMessgae = "كلمة التحقق فارغة";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                  this.spinnerfull.hide();
                }, 3000)
    }else if(response.Registration_Response == 1195){
      this.responseInvesregerrMessgae = "كلمة التحقق غير صالحة";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                  this.spinnerfull.hide();
                }, 3000)
    }
    
    
    
    
    else if(response.Registration_Response == 1001){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "فشل";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1003){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1004){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1005){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1006){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1007){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1008){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1009){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1010){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1011){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1012){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1013){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1014){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1015){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1016){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1017){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "رقم الجوال فارغ ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1018){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "رقم الجوال غير صحيح ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1019){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "الاسم الأول فارغ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1020){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "اسم العائلة فارغ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1021){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "يمنع استعمال الرموز";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1022){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "يمنع استعمال الرموز";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1023){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "البريد الإلكتروني فارغ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1024){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "البريد الإلكتروني غير صالح";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1025){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "كلمة السر فارغة ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1026){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "الحد الادني لكمة السر 8 حروف الحد الاقصي 20 حرف";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response==1027){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1044){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "نوع التسجيل فارغ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1045){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "يجب أن يكون نوع التسجيل مقترضًا أو مقرضًا";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== 1046){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "البريد الالكتروني موجود بالفعل";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else if(response.Registration_Response== '1047'){
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "رقم الاتصال موجود بالفعل";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }else {
      this.spinnerfull.hide();
      this.responseInvesregerrMessgae = "حدث خطا حاول مره اخري ";
  
                this.registResponseError = true;
                setTimeout(() => {
                  this.registResponseError = false;
                }, 3000)
    }
  }


  getdobjj() {
    var age = 18;
    const formattedDate = this.investorInfoForm.value.Dob;
   
    
    
  if(formattedDate.day > 10) {

    this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
   
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;
    
var currdate = this.todaydate;

if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18
 
 // alert("above 18");
} else {
  
  this.doberrdis = true;
  this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);
}
    return this.datdob

  }
  else{
    this.datdob =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
    
    // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
    var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-0${formattedDate.day}` ;
   
var currdate = this.todaydate;

if (currdate >= setDate) {
  this.dobdatcurrent = currdate >= setDate
  // you are above 18
  
  //alert("above 18");
} else {
 
  this.doberrdis = true;
  this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
  setTimeout(() => {
    this.doberrdis = false;
  }, 3000);

 // alert("below 18");
}
    return this.datdob

  }
  }



  


  
  
//   checkInvesterIfor(){
//     this.getdobjj()
   

//     this.investorInfoForm.markAllAsTouched();
   
//     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
//     if(this.data!=null || this.data !=''){
//       this.accesstoken= this.data.accesstoken;
//     }


    

//     if(this.investorInfoForm.value.nationality !=null && this.investorInfoForm.value.nationality !='') {
//       this.selectErrorMsg ='';
//     }

//     else  {
//       console.log("+++++++++++++++")
//       this.nationdis = true;
//        this.selectErrorMsg = "يرجى تحديد الجنسية";
     
                   
//                    setTimeout(() => {
//                     this.nationdis = false;
//                    }, 3000)
//       }



//       if(this.investorInfoForm.value.nationality =='SAUDI'){

//         if( this.dobdatcurrent ==true){
      
//           if(this.investorInfoForm.valid){
//             this.detectDevice();
//             const momentDate = new Date(this.investorInfoForm.value.Dob); 
//             const formattedDate = moment(momentDate).format("YYYY-MM-DD");
//              console.log(formattedDate);
//             const object: any = {}
//             object['browserType'] = this.deviceInfo.browser;
//             object['browserVersion'] = this.deviceInfo.browser_version;
//             object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//             object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//             object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//             object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//             object['language'] = 'en';
//             object['countryCode'] = 'SA';
//             object['nationality'] = this.investorInfoForm.value.nationality
        
           
//             if(this.investorInfoForm.value.nationality =='SAUDI') {
//               object['dob'] = this.datdob
//             }
           
//             object['id'] = this.investorInfoForm.value.nationalId
//             object['registrationId'] = '15'
//             object['osVersion'] = this.deviceInfo.os_version;
//             object['osType'] = this.deviceInfo.os;
            
//             object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
            
            
//              
    
      
        
        
//         this.spinnerfull.show();
//         this.authService.submitInvesterInfo(object,this.accesstoken).subscribe(response=>
//           this.submitInvestorResponse(response))
        
          
//           };
//         }
      
//       }
      

      
// if(this.investorInfoForm.value.nationality =='NON_SAUDI'){
//       if( this.dobdatcurrent  == true){
      
      
        
      
      
//         console.log('djfhsdk')
//       console.log(this.bobdattt)
//         console.log(this.investorInfoForm.valid)
        
//             this.detectDevice();
          
//             const object: any = {}
//             object['browserType'] = this.deviceInfo.browser;
//             object['browserVersion'] = this.deviceInfo.browser_version;
//             object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//             object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//             object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//             object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//             object['language'] = 'en';
//             object['countryCode'] = 'SA';
//             object['nationality'] = this.investorInfoForm.value.nationality
        
            
//               object['dob'] = this.bobdattt
          
           
//             object['id'] = this.investorInfoForm.value.nationalId
//             object['registrationId'] = '15'
//             object['osVersion'] = this.deviceInfo.os_version;
//             object['osType'] = this.deviceInfo.os;
            
//             object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
            
            
//              
     
      
        
        
//         this.spinnerfull.show();
//         this.authService.submitInvesterInfo(object,this.accesstoken).subscribe(response=>
//           this.submitInvestorResponse(response))
      
          
//           };
      
 
 
//         }
 

//   }

checkInvesterIfor(){
  //this.submitted1=true;
this.investorInfoForm.markAllAsTouched();
  // console.log(this.investorInfoForm.value)
  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }

  if(this.investorInfoForm.value.nationality !=null && this.investorInfoForm.value.nationality !='') {
    this.selectErrorMsg ='';
  }

  else  {
 
    this.nationdis = true;
    this.selectErrorMsg = "Please Select Nationality";
   
                 
                 setTimeout(() => {
                  this.nationdis = false;
                 }, 3000)
    }



  if( this.dobdatcurrent ==true){
  if(this.investorInfoForm.valid){
    this.detectDevice();
    const momentDate = new Date(this.investorInfoForm.value.Dob); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    
    const object: any = {}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
    object['language'] = 'en';
    object['countryCode'] = 'SA';
    object['nationality'] = this.investorInfoForm.value.nationality
    object['dob'] = this.bobdattt
    object['id'] = this.investorInfoForm.value.nationalId
    object['registrationId'] = '15'
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['currentResidentLocation']  = this.investorInfoForm.value.currentResidentLocation;
    object['placeOfBirth'] = this.investorInfoForm.value.placeOfBirth;
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    
    
    // 

// this.spinnerfull.show();

this.spinnerfull.show();
this.authService.submitInvesterInfo(object,this.accesstoken).subscribe(response=>
  this.submitInvestorResponse(response))

  
  };
}
// }else{
 
//   this.selectErrorMsg = "Please Select Nationality";

              
           
//  }
}











  nationalityhide(){ 
    this.selectErrorMsg='';
  }




  radioselect(val) {


if(val == 'NON_SAUDI') {

  this.nonsaudi = true;
  this.saudi = false;
}

if(val == 'SAUDI') {

  this.nonsaudi = false;
  this.saudi = true;
}

  }


  getcurrentengdob() {
    this.currentengdob = this.maxDate
    var d = new Date(this.currentengdob ),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
    
    if (month.length < 2) 
    month = '0' + month;
    if (day.length < 2) 
    day = '0' + day;
    
    this.finalengcurrentdat = [year, month, day].join('-');
    
    return this.finalengcurrentdat
    
    }
    
    
    
    onDateChangeexpire(){

      var val = this.yourInfononForm.value.idexpirationdateeng
      var d = new Date(val),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
            this.bobdatttexpire = [year, month, day].join('-')
 
    
            return this.bobdatttexpire
    }
    
    onDateChange(val) {
    
      this.getcurrentengdob();
      
      this.datewchange = val;
    
      
       // Replace event.value with your date value
       var d = new Date(val),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
            this.bobdattt = [year, month, day].join('-')
         
    this.setDate = [year+ 18, month, day].join('-');
            var currdate = this.finalengcurrentdat;
    
        
            if (currdate >= this.setDate) {
            this.dobdatcurrent = currdate >= this.setDate
    
            this.doberreng = ''
           
            } else {
            
            this.doberrdiseng = true;
            this.doberreng = ' تاريخ الميلاد لا يقل عن  18 سنة'
            // setTimeout(() => {
            //   this.doberrdiseng = false;
            // }, 3000);
            
     
            
            }
        return  this.bobdattt;
    
    }
    
    
    // getenggdateee() {
     
    
      
      
    //   var d = new Date(this.datewchange),
    //        month = '' + (d.getMonth() + 1),
    //        day = '' + d.getDate(),
    //        year = d.getFullYear();
    
    //    if (month.length < 2) 
    //        month = '0' + month;
    //    if (day.length < 2) 
    //        day = '0' + day;
    
    //        this.bobdattt = [year, month, day].join('-')
        
    // this.setDate = [year+ 18, month, day].join('-');
    //        this.currdate = this.finalengcurrentdat;
    
    //        console.log(this.currdate);
    //        console.log(this.setDate)
    
    //        console.log(this.currdate >= this.setDate)
    
    //        if (this.currdate >= this.setDate) {
    //        this.dobdatcurrent = this.currdate >= this.setDate
    //        console.log("above18")
            
    //        } else {
    //        console.log("below18")
    //        this.doberrdiseng = true;
    //        this.doberr = ' تاريخ الميلاد لا يقل عن  18 سنة'
    //        setTimeout(() => {
    //          this.doberrdiseng = false;
    //        }, 3000);
           
    
           
    //        }
    //    return  this.bobdattt;
    // }
    


  timer() {
    this.authService.getObservable(this.timeout).subscribe(val => this.counter = val);
   
    this.resendotpbutton = false;
  
    if (this.otpcount == 0) {
      setTimeout(() => { 
     
        this.hidetimer = false;
      }, 120000)
    } else {
      setTimeout(() => {
      
        this.sendotp=false;
        //this.successotp = false;
        this.hidetimer = false
      }, 120000)
    }
  
  }



  submitInvestorResponse(response){
    

    this.spinnerfull.hide()
    if(response.investor_info_otp_response== '1097'){
      this.selectErrorMsg='';
      this.verifyotp=false;
      this.timer();
      this.hidetimer = true;
      this.sendotp = true;
      this.responseOtpSucessMessgae = "إرسال OTP إلى رقم هاتفك المحمول";
  
                this.registotpsuceError = true;
                setTimeout(() => {
                  this.registotpsuceError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1001){
      this.responseMessgae = "فشل";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1003){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1004){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1005){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1006){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1007){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1008){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1009){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1010){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1011){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1012){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1013){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1014){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1015){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.Investor_Info_Otp_Response==1016){
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }
    else if(response.investor_info_otp_response== 1040){
      this.responseMessgae = "معرف التسجيل فارغ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1041){
      this.responseMessgae = "يجب أن يكون معرف التسجيل رقميًا";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response== 1140){
      this.responseMessgae = "تاريخ الميلاد فارغ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response==1142){
      this.responseMessgae = "تاريخ الميلاد غير صالح";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response==1146){
      this.responseMessgae = "الهوية الوطنية فارغة";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_otp_response==1147){
      this.responseMessgae = "الجنسية فارغة";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_info_otp_response==1148){
      this.responseMessgae = "يجب أن تكون الجنسية سعودية أو غير سعودية";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     
     
     else if(response.investor_info_otp_response==1253){
      this.responseMessgae = "مكان الميلاد فارغ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     else if(response.investor_info_otp_response==1254){
      this.responseMessgae = "الاقامة الحالية فارغة";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     
     
     
     else {
      this.responseMessgae = "حدث خطا حاول مره اخري ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }






  }
 
  otpSubmit(){
    this.otpForm.markAllAsTouched();
    // console.log(this.otpForm.value)
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    if(this.otpForm.valid){
      this.detectDevice();
      const momentDate = new Date(this.investorInfoForm.value.Dob); // Replace event.value with your date value
      const formattedDate = moment(momentDate).format("YYYY-MM-DD");
      // console.log(formattedDate);
      const object: any = {}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
      object['language'] = 'ar';
      object['countryCode'] = 'SA';
      object['nationality'] = this.investorInfoForm.value.nationality
      object['dob'] =this.bobdattt
      object['id'] = this.investorInfoForm.value.nationalId
      object['registrationId'] = '15'
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      object['currentResidentLocation']  = this.investorInfoForm.value.currentResidentLocation;
      object['placeOfBirth'] = this.investorInfoForm.value.placeOfBirth;
      object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      object['otp'] = this.otpForm.value.otp;
      
      // 
      this.authService.submitInvesterInfoOtp(object,this.accesstoken).subscribe(response=>
        this.submitInvestorotpResponse(response))
        };
    }


    submitInvestorotpResponse(response){
      // 
     
      if(response.investor_info_response== 1000){
        this.hidetimer = false;
        this.investorInfootpSucessMessage = "معلومات المستثمر المقدمة بنجاح";
        this.secondnext = false;
        this.sendotp=true
       
        this.verifyotp=true;
                  this.investotpsucesstError = true;
                  setTimeout(() => {
                    this.investotpsucesstError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1001){
        this.investorInfoMessage = "فشل";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 300000000)
      }else if(response.investor_info_response== 1003){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1004){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1005){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1006){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1007){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1008){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1009){
        this.investorInfoMessage ="حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1010){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1011){
        this.investorInfoMessage ="حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1012){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1013){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1014){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1015){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response==1016){
        this.investorInfoMessage = "حدث خطا حاول مره اخري ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.investor_info_response== 1040){
        this.investorInfoMessage = "معرف التسجيل فارغ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1041){
        this.investorInfoMessage = "يجب أن يكون معرف التسجيل رقميًا";
    
                  this.registError = true;
                  setTimeout(() => { 
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response== 1140){
        this.investorInfoMessage = "تاريخ الميلاد فارغ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response==1142){
        this.investorInfoMessage = "تاريخ الميلاد غير صالح";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response==1146){
        this.investorInfoMessage = "الهوية الوطنية فارغة";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_info_response==1147){
        this.investorInfoMessage = "الجنسية فارغة";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }else if(response.investor_info_response==1148){
        this.investorInfoMessage =  "يجب أن تكون الجنسية سعودية أو غير سعودية";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }else if(response.investor_info_response==1090){
        this.investorInfoMessage = "otp فارغ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }else if(response.investor_info_response==1091){
        this.investorInfoMessage = "يجب أن يكون بروتوكول otp رقميًا";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }else if(response.investor_info_response==1092){
        this.investorInfoMessage = " OTP يتكون من اربعة ارقام ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }else if(response.investor_info_response==1093){
        this.investorInfoMessage = "OTP غير صحيح";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }else if(response.investor_info_response==1094){
        this.investorInfoMessage = "OTP انتهت صلاحية ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }


       else if(response.investor_info_response==1253){
        this.investorInfoMessage = "مكان الميلاد فارغ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }
       else if(response.investor_info_response==1254){
        this.investorInfoMessage = "الاقامة الحالية فارغة";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
       }
       else {
        this.investorInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
  
    }

   
    getdateeee() {
      const formattedDate = this.yourInfoForm.value.idexpirationdate;
  
      if(formattedDate.day < 10  && formattedDate.month < 10 ) {
        this.dataaaaae =  `${formattedDate.year}-0${formattedDate.month}-0${formattedDate.day}`
      //  console.log(this.dataaaaae)
        return this.dataaaaae
      }
  
  
      else if(formattedDate.month < 10 ) {
        this.dataaaaae =  `${formattedDate.year}-0${formattedDate.month}-${formattedDate.day}`
        return this.dataaaaae
      }
  
      else if(formattedDate.day < 10 ) {
        this.dataaaaae =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
        return this.dataaaaae
      }
      else {
        this.dataaaaae =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
      //  console.log(this.dataaaaae)
        return this.dataaaaae
      }
  
    }
    
  //   InvesterYourInfoSubmit(){

  //     this.getdateeee();
  //     this.onDateChangeexpire()
  //     this.submitted3=true;
  //     this.submitted9 = true;
  //      console.log(this.yourInfoForm.value)
  //      console.log(this.yourInfononForm.value)
  //     if(this.investorInfoForm.value.nationality =='SAUDI') {


   
   
  //       this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  //       if(this.data!=null || this.data !=''){
  //         this.accesstoken= this.data.accesstoken;
  //       }
  //       this.detectDevice();
  //       const formattedDate = moment(this.yourInfoForm.value.idexpirationdate).format("YYYY-MM-DD");
 
  
  
  //       const object: any = {}
  //       object['browserType'] = this.deviceInfo.browser;
  //       object['browserVersion'] = this.deviceInfo.browser_version;
  //       object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  //       object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  //       object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  //       object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
  //       object['language'] = 'en';
  //       object['countryCode'] = 'SA';
        
  //       object['registrationId'] = '15'
  //       object['osVersion'] = this.deviceInfo.os_version;
  //       object['osType'] = this.deviceInfo.os;
        
  //       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
  //       object['nameAr'] = this.yourInfoForm.value.namear;
  //       object['nameEn'] = this.yourInfoForm.value.nameen
  
    
  //     if(this.investorInfoForm.value.nationality =='SAUDI') {
  //       object['idExpirationDate'] = this.dataaaaae
  //     }
      
  //       object['gender'] = this.yourInfoForm.value.gender
  //       object['otp'] = this.otpForm.value.otp;
  //        
  
  //       this.authService.investorYourInfo(object,this.accesstoken).subscribe(response=>
  //         this.investorYourInfoResponse(response))
  //         this.spinnerfull.show();
      
  
  
  //   }
  
  //   if(this.investorInfoForm.value.nationality =='NON_SAUDI') {
    
  //     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  //     if(this.data!=null || this.data !=''){
  //       this.accesstoken= this.data.accesstoken;
  //     }
  //     this.detectDevice();
  //     const formattedDate = moment(this.yourInfoForm.value.idexpirationdate).format("YYYY-MM-DD");
      
  
  // console.log(this.bobdatttexpire)
  //     const object: any = {}
  //     object['browserType'] = this.deviceInfo.browser;
  //     object['browserVersion'] = this.deviceInfo.browser_version;
  //     object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  //     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  //     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  //     object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
  //     object['language'] = 'en';
  //     object['countryCode'] = 'SA';
      
  //     object['registrationId'] = '15'
  //     object['osVersion'] = this.deviceInfo.os_version;
  //     object['osType'] = this.deviceInfo.os;
      
  //     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
  //     object['nameAr'] = this.yourInfononForm.value.namear;
  //     object['nameEn'] = this.yourInfononForm.value.nameen
  
  
  
  //     object['idExpirationDate'] = this.bobdatttexpire
    
    
  //     object['gender'] = this.yourInfononForm.value.gender
  //     object['otp'] = this.otpForm.value.otp;
  //      
  
  //     this.authService.investorYourInfo(object,this.accesstoken).subscribe(response=>
  //       this.investorYourInfoResponse(response))
  //       this.spinnerfull.show();
    
  
  //     }
      
  //   }

  
  InvesterYourInfoSubmit(){
    this.getdateeee();
    this.submitted3=true;
    // console.log(this.yourInfoForm.value)
    if(this.yourInfoForm.valid){
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      this.detectDevice();
     // const momentDate = new Date(this.yourInfoForm.value.idexpirationdate); // Replace event.value with your date value
      const formattedDate = moment(this.yourInfoForm.value.idexpirationdate).format("YYYY-MM-DD");
      // console.log(formattedDate);


      const object: any = {}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
      object['language'] = 'en';
      object['countryCode'] = 'SA';
      
      object['registrationId'] = '15'
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      
      object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      object['nameAr'] = this.yourInfoForm.value.namear;
      object['nameEn'] = this.yourInfoForm.value.nameen
      object['idExpirationDate'] = this.dataaaaae
      object['gender'] = this.yourInfoForm.value.gender
      object['otp'] = this.otpForm.value.otp;
       
      this.spinnerfull.show();
      this.authService.investorYourInfo(object,this.accesstoken).subscribe(response=>
        this.investorYourInfoResponse(response))
    }
  }









    investorYourInfoResponse(response){
       
      if(response.investor_yourInfo_response== 1000){
        this.otpForm.reset();
        this.investorInfoForm.reset();
        const object: any = {}
      this.encryptData(2)
      object.accesstoken = this.accesstoken;
      object.alloworigen =  this.encriptdata
        sessionStorage.setItem('currentUser', JSON.stringify(object))
        this.submitted3=false;
       // this.spinnerfull.hide();
        this.investorSucessYourInfoMessage = "معلومات المخترع المقدمة بنجاح";
    
                  this.investorsucesError = true;
                  setTimeout(() => {
                    this.investorsucesError = false;
                    this.spinnerfull.hide();
                   // $(".carousel").carousel("next");
                   this.first2=false;
                   this.first3=true;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1001){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "فشل";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1003){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1004){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1005){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1006){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1007){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1008){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1009){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1010){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1011){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1012){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1013){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1014){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1015){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response==1016){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }
      else if(response.investor_yourInfo_response== 1040){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "معرف التسجيل فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1041){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "يجب أن يكون معرف التسجيل رقميًا";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response== 1140){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "تاريخ الميلاد فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response==1142){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "تاريخ الميلاد غير صالح";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response==1146){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "الهوية الوطنية فارغة";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }else if(response.investor_yourInfo_response==1147){
        this.spinnerfull.hide();
        this.investorYourInfoMessage ="الجنسية فارغة";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1148){
        this.spinnerfull.hide();
        this.investorYourInfoMessage =  "يجب أن تكون الجنسية سعودية أو غير سعودية";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1090){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "otp فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1091){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "يجب أن يكون بروتوكول otp رقميًا";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1092){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = " OTP يتكون من اربعة ارقام ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1093){
        this.spinnerfull.hide();
        this.investorYourInfoMessage =  "OTP غير صحيح";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1094){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "OTP انتهت صلاحية";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1136){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "اسم الانجليزية فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1137){
        this.spinnerfull.hide();

        this.investorYourInfoMessage = "الاسم العربي فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1139){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "الجنس فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1141){    this.spinnerfull.hide();
        this.investorYourInfoMessage = "تاريخ انتهاء صلاحية المعرف فارغ";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1143){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "الاسم الانجليزي غير صالح";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1144){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "الاسم العربي غير صالح";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }else if(response.investor_yourInfo_response==1149){
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "تاريخ انتهاء صلاحية المعرف غير صالح";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
       }
       else {
        this.spinnerfull.hide();
        this.investorYourInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.ivesyourinfoError = true;
                  setTimeout(() => {
                    this.ivesyourinfoError = false;
                  }, 3000)
      }
  
    }
    IncomeInformationSubmit(){
      // console.log(this.incomeinfoForm.value)
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
      this.incomeinfoForm.markAllAsTouched();
      if(this.incomeinfoForm.valid){
        this.detectDevice();   
  // console.log("+++++++++++++++++++++++")
  
  const object: any = {}
object['browserType'] = this.deviceInfo.browser;
object['browserVersion'] = this.deviceInfo.browser_version;
object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
object['osVersion'] = this.deviceInfo.os_version;
object['osType'] = this.deviceInfo.os;
object['browserType'] = this.deviceInfo.browser;
object['browserVersion'] = this.deviceInfo.browser_version;
object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
object['language'] = 'en';
object['countryCode'] = 'SA';
object['registration_Id'] = '15'

object['annualIncome'] =this.incomeinfoForm.value.anualIncome ;
object['incomeSource'] = this.incomeinfoForm.value.sourceIncome;
object['jobStatus'] = this.incomeinfoForm.value.jobStatus
  
  // 
  this.spinnerfull.show();
  this.authService.incomeInformationSubmit(object,this.accesstoken).subscribe(response=>
    this.incomeInfoResponse(response))
      }
    }
    incomeInfoResponse(response){
      // 
      if(response.investor_income_response== 1000){

        this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      const object: any = {}
      this.encryptData(3)
      object.accesstoken = this.accesstoken;
      object.alloworigen =  this.encriptdata
      sessionStorage.setItem('currentUser', JSON.stringify(object))
        this.incomeInfoSucessMessage = "معلومات الدخل المقدمة تم بنجاح";
        this.incomeinfoForm.reset();
       // this.next3 = false;
                  this.incomeError = true;
                  setTimeout(() => {
                    this.incomeError = false;
                    this.spinnerfull.hide();
                   // $(".carousel").carousel("next");
                   this.first3=false;
                   this.first4=true;
                  }, 3000)
      }else if(response.investor_income_response== 1001){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "فشل";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1003){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1004){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1005){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1006){
        this.spinnerfull.hide();
        this.incomeInfoMessage ="حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1007){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1008){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1009){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1010){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1011){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1012){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1013){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1014){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response== 1015){
        this.spinnerfull.hide();
        this.incomeInfoMessage ="حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response==1016){
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
        this.spinnerfull.hide();
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.investor_income_response ==1132){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "الدخل السنوي فارغ";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)
      }else if(response.investor_income_response ==1133){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "مصدر الدخل فارغ";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)
      }else if(response.investor_income_response ==1134){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حالة الوظيفة فارغة";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)
      }else if(response.investor_income_response ==1040){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "معرف التسجيل فارغ";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)
      }else if(response.investor_income_response ==1041){
        this.spinnerfull.hide();
        this.incomeInfoMessage =  "يجب أن يكون معرف التسجيل رقميًا";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)
      }else if(response.investor_income_response ==1042){
        this.spinnerfull.hide();
        this.incomeInfoMessage = "معرف التسجيل غير صالح";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)
      }else {
        this.spinnerfull.hide();
        this.incomeInfoMessage = "حدث خطا حاول مره اخري";
    
        this.registError = true;
        setTimeout(() => {
          this.registError = false;
        }, 3000)    }
  
    }
  bankinfo() {
    this.bankinginfoForm.markAllAsTouched();
    // console.log(this.bankinginfoForm.value)
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    if(this.bankinginfoForm.valid){

      const object = {... this.deviceinfoservice.deviceinfo, language:'en',registrationId:6,bankName:this.bankinginfoForm.value.bankName,
    bankIBAN:this.bankinginfoForm.value.bankIBAN,iPAddress:this.deviceinfoservice.deviceinfo.ipAdress,registrationType:'Investor', bankAccountHolderName:this.bankinginfoForm.value.bankAccountHolderName }   
    // 
    this.spinnerfull.show();
    this.authService.bankinformation(object,this.accesstoken).subscribe(response =>{
      // 
      if(response.bankinfo_response== 1000){
        this.bankinginfoForm.reset();
        this.hidecoroseldown=false;
        this.data = JSON.parse(sessionStorage.getItem('currentUser'));
        if(this.data!=null || this.data !=''){
          this.accesstoken= this.data.accesstoken;
        }
        const object: any = {}
      
        object['FirstName']  = response.FirstName;
        object['LastName']     = response.LastName;
        object['LastLogin']    = response.LastLogin;
        object['isMobileVerified']   = response.isMobileVerified;
        object['isEmailVerified']   = response.isEmailVerified;
        object['accesstoken']   =  this.accesstoken;
        object['isPolicyAccepted']   = response.isPolicyAccepted;
        object['isBankInfoProvided']    = response.isBankInfoProvided;
        object['isInvestorInfoProvided']    = response.isInvestorInfoProvided;
        object['isTermsAccepted']  = response.isTermsAccepted;
        object['id']=response.id;
        object['iqamaId'] = response.iqamaId;
        object['redirect'] = 'arabicwebapp';
        object['isBankAccountLetterUploaded'] = response.isBankAccountLetterUploaded;
     
        sessionStorage.setItem('currentUser', JSON.stringify(object))
        this.responseBankSucessMessgae = "تمت إضافة معلومات البنك بنجاح ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                    this.spinnerfull.hide();
                   // $(".carousel").carousel("next");
                   this.first4=false;
                   this.first5=true;
                  }, 3000)
      }else if(response.bankinfo_response== 1001){
        this.bankresponseMessgae = "فشل";
        this.spinnerfull.hide();
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1002){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
    
      else if(response.bankinfo_response == 1003){
        this.spinnerfull.hide();
        this.bankresponseMessgae ="حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1004){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1005){
        this.spinnerfull.hide();
         this.bankresponseMessgae = "حدث خطا حاول مره اخري";
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1006){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1007){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1008){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1009){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1010){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري"; 
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1011){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري"; 
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1012){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";  
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1013){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";  
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1014){
        this.spinnerfull.hide();
        this.bankresponseMessgae ="حدث خطا حاول مره اخري";   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1015){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري"; 
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response==1016){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1040){
        this.spinnerfull.hide();
        this.bankresponseMessgae =  "معرف التسجيل فارغ"; 
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1041){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "يجب أن يكون معرف التسجيل رقميًا";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1042){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "معرف التسجيل غير صالح";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1054){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "يجب ألا يكون اسم البنك فارغًا";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }

      else if(response.bankinfo_response== 1055){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "يجب ألا يكون بنك إيبان فارغًا";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.bankinfo_response== 1083){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";  
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.bankinfo_response== 1084){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.bankinfo_response== 1145){
        this.spinnerfull.hide();
        this.bankresponseMessgae = "اسم الحساب المصرفي فارغ";
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      } else {
        this.bankresponseMessgae = "حدث خطا حاول مره اخري";  
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
    
    })
     
    }
  }

  onFileChange(event) {
  
    this.uploadfilesize=event.target.files[0].size
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.fileError = false;
      this.uploadfileForm.get('bank_account_letter').setValue(file);
    }
  }else{
    this.fileerror="يجب ان يكون حجم ملف التجميل اقل 5 ميجابايت"
    
    this.fileError = true;
    // setTimeout(() => {
    //   this.fileError = false;
    // }, 3000)
  }
  }
 
  

   
  docskip() {
    this.router.navigate(['/arabicwebapp/webappmaindashboard'])
  }
  
  uploadform() { 
    this.submitted2 = true;
  //  console.log(this.uploadfileForm.value)
  //  if(this.uploadfileForm.value.bank_account_letter == '' && this.uploadfileForm.value.bank_account_letter == '') {
    
  //    this.msg = 'PLEASE UPLOAD THE DOCUMENTS';
     
      
  //    this.msgError = true;
  
      
  //  }
  if(this.uploadfilesize < 5000000){
   this.data = JSON.parse(sessionStorage.getItem('currentUser'));
   if(this.data!=null || this.data !=''){
     this.accesstoken= this.data.accesstoken;
   }
    if(this.uploadfileForm.valid && this.uploadfileForm.get('terms_and_conditions').value !=false) {

      if( this.uploadfileForm.get('privacy_policy').value !=false){
      this.firstcheck = this.uploadfileForm.get('terms_and_conditions').value;
  
      if(this.firstcheck == true) {
        this.checkansterms = 'Accepted';
       
      }
      this.firstcheckpolicy = this.uploadfileForm.get('privacy_policy').value;
      if(this.firstcheckpolicy == true) {
       this.checkanspolicy = 'Accepted';
    
     }



      this.submitted2 = false;
      this.msgError = false;
      const formData = new FormData();
      formData.append('file',this.uploadfileForm.get('bank_account_letter').value);
      formData.append('bank_account_letter',this.uploadfileForm.value.bank_account_letter);
      formData.append('language','ar');
      formData.append('terms_and_conditions',this.checkansterms);
      formData.append('registration_id','9'),
      formData.append('privacy_policy',this.checkanspolicy);
      formData.append('deviceType',this.deviceinfoservice.deviceinfo.deviceType);
      formData.append('browserType',this.deviceinfoservice.deviceinfo.browserType);
      formData.append('browserVersion',this.deviceinfoservice.deviceinfo.browserVersion);
      formData.append('osType',this.deviceinfoservice.deviceinfo.osType);

      formData.append('osVersion',this.deviceinfoservice.deviceinfo.osVersion);

      formData.append('deviceId	',this.deviceinfoservice.deviceinfo.deviceId);
      formData.append('iPAddress	',this.deviceinfoservice.deviceinfo.ipAdress);



      if(this.deviceinfoservice.deviceinfo.latitude =='') {
        formData.append('latitude	','NA');
        
      } else {
        formData.append('latitude	',this.deviceinfoservice.deviceinfo.latitude);
      }


      if(this.deviceinfoservice.deviceinfo.logintude =='') {
        formData.append('longitude	','NA');
        
      } else {
        formData.append('longitude	',this.deviceinfoservice.deviceinfo.logintude);
      }

      // formData.append('latitude	',this.deviceinfoservice.deviceinfo.latitude);
      // formData.append('longitude	',this.deviceinfoservice.deviceinfo.logintude);


      // const obj ={...this.deviceinfoservice.deviceinfo,language:'ar',
      //  terms_and_conditions:this.uploadfileForm.value.terms_and_conditions,privacy_policy:this.uploadfileForm.value.privacy_policy,registration_id:9 }
        //  console.log(formData)
         this.spinnerfull.show();
      this.authService.uploadbankletter(formData,this.accesstoken).subscribe(response =>{
        // 

        if(response.upload_documents_response == 1000){
          this.uploadfileForm.reset();
          this.data = JSON.parse(sessionStorage.getItem('currentUser'));
          if(this.data!=null || this.data !=''){
            this.accesstoken= this.data.accesstoken;
          }
          this.uploadError = true;
          this.responseuploadsucessMessgae = "تم تحميل المستند بنجاحy";
          // setTimeout(() => {
           
          //   this.uploadError = false;
          //   const object: any = {}
          //   object['FirstName']  = response.FirstName;
          //   object['LastName']     = response.LastName;
          //   object['LastLogin']    = response.LastLogin;
          //   object['isMobileVerified']   = response.isMobileVerified;
          //   object['isEmailVerified']   = response.isEmailVerified;
          //   object['token']   = this.accesstoken
          //   object['isPolicyAccepted']   = response.isPolicyAccepted;
          //   object['isBankInfoProvided']    = response.isBankInfoProvided;
          //   object['isInvestorInfoProvided']    = response.isInvestorInfoProvided;
          //   object['isTermsAccepted']  = response.isTermsAccepted;
          //   object['redirect'] = '/auth/investorRegister';
          //   sessionStorage.setItem('registeruser',JSON.stringify(object))
  
          //   this.router.navigate(['/arabicwebapp/webappdashboard'])
          // }, 3000)




          setTimeout(() => {
           
            this.uploadError = false;
            const object: any = {}
            object['FirstName']  = response.FirstName;
            object['LastName']     = response.LastName;
            object['LastLogin']    = response.LastLogin;
            object['isMobileVerified']   = response.isMobileVerified;
            object['isEmailVerified']   = response.isEmailVerified;
            object['accesstoken']   =  this.accesstoken;
            object['isPolicyAccepted']   = response.isPolicyAccepted;
            object['isBankInfoProvided']    = response.isBankInfoProvided;
            object['isInvestorInfoProvided']    = response.isInvestorInfoProvided;
            object['isTermsAccepted']  = response.isTermsAccepted;
            object['id']=response.id;
            object['iqamaId'] = response.iqamaId;
            object['redirect'] = 'arabicwebapp';
            object['isBankAccountLetterUploaded'] = response.isBankAccountLetterUploaded;
            sessionStorage.setItem('currentUser',JSON.stringify(object))
           // this.token.changeMessage(object); 
            this.router.navigate(['/arabicwebapp/webappmaindashboard'])
           // this.spinnerfull.hide();
           this.spinnerfull.hide();
          }, 3000)

        
        }else if(response.upload_documents_response== 1001){
          this.spinnerfull.hide();
          this.responseMessgae = "فشل";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1002){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري"; 
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
      
        else if(response.upload_documents_response== 1003){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";       
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1004){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";       
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1005){
              this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري"; 
                              this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1006){
              this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";       
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1007){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";       
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1008){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";       
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1009){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري"; 
                              this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1010){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري"; 
                              this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1011){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1012){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";    
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1013){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1014){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";    
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1015){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response==1016){
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";     
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1040){
          this.spinnerfull.hide();
          this.responseMessgae = "معرف التسجيل فارغ";    
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1041){
          this.spinnerfull.hide();
          this.responseMessgae =  "يجب أن يكون معرف التسجيل رقميًا";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1042){
          this.spinnerfull.hide();
          this.responseMessgae = "معرف التسجيل غير صالح";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1074){
          this.spinnerfull.hide();
          this.responseMessgae = "ملف خطاب الحساب المصرفي فارغ";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
  
        else if(response.upload_documents_response== 1075){
          this.spinnerfull.hide();
          this.responseMessgae = "يجب أن يكون حجم ملف خطاب الحساب المصرفي أقل من 5 ميغابايت";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        } 
        else if(response.upload_documents_response== 1076){
          this.spinnerfull.hide();
          this.responseMessgae = "تنسيقات ملفات خطابات الحسابات المصرفية هي JPG و PNG و XLSX و XLS و PDF";
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.upload_documents_response== 1130){
          this.spinnerfull.hide();
          this.responseMessgae = "يجب قبول الشروط والأحكام";   
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.upload_documents_response== 1131){
          this.spinnerfull.hide();
          this.responseMessgae = "يجب قبول سياسة الخصوصية";   
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else {
          this.spinnerfull.hide();
          this.responseMessgae = "حدث خطا حاول مره اخري";  
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
      })
    }else{
      this.termsprivacy="سياسة الخصوصية مطلوبة"
      this.termsprivacyError = true;
      setTimeout(() => {
        this.termsprivacyError = false;
      }, 3000)
    }
     
    } else{
      this.termsprivacy="لشروط والأحكام مطلوية ؟"
      this.termsprivacyError = true;
      setTimeout(() => {
        this.termsprivacyError = false;
      }, 3000)
    }
  }else{
    this.fileerror="يجب ان يكون حجم ملف التجميل اقل 5 ميجابايت"
    
    this.fileError = true;
    setTimeout(() => {
      this.fileError = false;
    }, 3000)
  }
  }

  navigatearabic() {
    if(this.first1){
      this.token.first1=true;
      this.router.navigate(['/auth/investorRegister'])
    }


  if(this.first2){
      this.token.first1=false;
      this.token.first2=true;
      this.router.navigate(['/auth/investorRegister'])
    }

  if(this.first3){
      this.token.first2=false;
      this.token.first3=true;
      this.router.navigate(['/auth/investorRegister'])
    }

    if(this.first4){
      this.token.first3=false;
      this.token.first4=true;
      this.router.navigate(['/auth/investorRegister'])
    }

    if(this.first5){
      this.token.first4=false;
      this.token.first5=true;
      this.router.navigate(['/auth/investorRegister'])
    }
    
  }
  updrrow(){
    this.count1=this.count1+1;
//  console.log(this.count)
//  console.log(this.count1)
   // console.log(this.regstage)
    if(this.count1 <this.count){
     this.hidecaroselup=true
  }else{
    // alert("up")
     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
   // if(this.data !=null && this.data !=''){
     this.decdata=this.decryptData(this.data.alloworigen);
      this.regstage=this.decdata;
  //   }
    //  console.log(this.count1)
    //  console.log(this.regstage)
    if(this.count1 <this.regstage){
      // alert("up")
      this.hidecaroselup=true;
   }else
  {
    this.hidecaroselup=false
    this.hidecoroseldown=true;
    this.count=0;
  }
  }
  }

  logoclear(){
    sessionStorage.clear();
  }

  downdrrow(){
    
    // console.log("+++++++++++++++")
    // $(".carousel").carousel("next"); 
    
    this.count=this.count+1;
    // console.log(this.count)
    // console.log(this.regstage)
    if(this.count <this.regstage){
   this.hidecoroseldown=true;
   this.hidecaroselup=true
    }else{
     // alert("down")
   this.hidecoroseldown=false;
    this.hidecaroselup=true
    this.count1=0;
    }
     }

}
