import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArsmeregistrationComponent } from './arsmeregistration.component';

describe('ArsmeregistrationComponent', () => {
  let component: ArsmeregistrationComponent;
  let fixture: ComponentFixture<ArsmeregistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArsmeregistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArsmeregistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
