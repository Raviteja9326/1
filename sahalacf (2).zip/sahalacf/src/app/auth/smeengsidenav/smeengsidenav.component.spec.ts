import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeengsidenavComponent } from './smeengsidenav.component';

describe('SmeengsidenavComponent', () => {
  let component: SmeengsidenavComponent;
  let fixture: ComponentFixture<SmeengsidenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeengsidenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeengsidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
