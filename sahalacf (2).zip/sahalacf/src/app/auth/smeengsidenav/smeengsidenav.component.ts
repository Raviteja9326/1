import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var $ : any;
@Component({
  selector: 'app-smeengsidenav',
  templateUrl: './smeengsidenav.component.html',
  styleUrls: ['./smeengsidenav.component.scss']
})
export class SmeengsidenavComponent implements OnInit {
  name(name: any) {
    throw new Error("Method not implemented.");
  }
  user: any;

  constructor(private router:Router) { 
    this.user = JSON.parse(sessionStorage.getItem('currentUser'))
   

    this.name=this.user.FirstName
   
   
  }

//   ngOnInit(): void {

//     $('.menu-icon').click(function () {
     
//       $('.nav-section').toggleClass('expand');
//       $('.main-section').toggleClass('expand');
//     });
//     $('.nav-section ul li a').on('click', function () {
//       $('.nav-section ul .active').removeClass('active');
//      $(this).addClass('active');
//  });
//   }
ngOnInit(): void {

  $('.nav-section').addClass('expand');
   $('.nav-section ul li a').on('click', function () {
          $('.nav-section ul .active').removeClass('active');
         $(this).addClass('active');
   });
  $('.menu-icon').click(function () {
   
    $('.nav-section').addClass('expand');
    $('.main-section').toggleClass('expand');

  });
}
  // ngAfterViewInit(){
  //   $('.nav-section').toggleClass('expand');
  //     $('.main-section').toggleClass('expand');
  // }
  logout(){
    sessionStorage.clear();
    this.router.navigate(['/home'])
  }
  }


  