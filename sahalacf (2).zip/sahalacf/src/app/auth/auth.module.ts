import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ngfModule, ngf } from "angular-file"


import { NgxHijriGregorianDatepickerModule } from 'ngx-hijri-gregorian-datepicker';

 

import { AuthRoutingModule } from './auth-routing.module';
import { InvestorRegistrationComponent } from './investor-registration/investor-registration.component';
import {MatCardModule} from '@angular/material/card';
import {MatDividerModule} from '@angular/material/divider';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatRadioModule} from '@angular/material/radio';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { RECAPTCHA_V3_SITE_KEY, RecaptchaV3Module } from 'ng-recaptcha';
import { RecaptchaModule,RecaptchaFormsModule, RECAPTCHA_SETTINGS, RecaptchaSettings } from 'ng-recaptcha';
import { NgbModule,NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../services/auth.service';
import { HttpClientModule } from '@angular/common/http';
import { DeviceinfoserviceService } from '../shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { SmeregistrationComponent } from './smeregistration/smeregistration.component';
import { ArsmeregistrationComponent } from './arsmeregistration/arsmeregistration.component';
import { LoginComponent } from './login/login.component';
import { ArloginComponent } from './arlogin/arlogin.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { RegisterComponent } from './register/register.component';
 

@NgModule({
  declarations: [InvestorRegistrationComponent,RegisterComponent, SmeregistrationComponent, ArsmeregistrationComponent, LoginComponent, ArloginComponent],
  imports: [
    CommonModule,
    AuthRoutingModule,
    MatDividerModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    
 ngfModule,
 NgxSpinnerModule,

    MatDatepickerModule,
    MatRadioModule,
    MatCardModule,MatNativeDateModule,
    MatSelectModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    ReactiveFormsModule,
    NgbModule,
    NgbDatepickerModule,
HttpClientModule,
RecaptchaV3Module,
NgxHijriGregorianDatepickerModule
    

  ],
  providers:[ {
    provide:RECAPTCHA_SETTINGS,
    useValue:{siteKey:'6LelwQEVAAAAAC68fhOTVRpxdw4wf5ZVWE2NOT1-'} as RecaptchaSettings
  },{ provide: RECAPTCHA_V3_SITE_KEY, useValue: '6LfGwAEVAAAAAC9jll57Tftj6n832OyEwj62ocqV' },
AuthService,
DeviceinfoserviceService,
DeviceDetectorService]
})
export class AuthModule { }
