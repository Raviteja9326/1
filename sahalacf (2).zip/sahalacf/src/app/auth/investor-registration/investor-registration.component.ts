import { Component, OnInit, Injectable ,ViewEncapsulation, Renderer2} from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors, AbstractControl} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS, NativeDateAdapter} from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { HttpClient } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import * as moment from 'moment';
declare var $: any;
import {NgbDateStruct, NgbDatepickerI18n, NgbCalendarIslamicUmalqura, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';
import * as CryptoJS from 'crypto-js';
import { NgxSpinnerService } from "ngx-spinner";
import { RefreshtokenService } from '../../services/refreshtoken.service';



// const WEEKDAYS = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];
// const MONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال',
//   'ذو القعدة', 'ذو الحجة'];

// @Injectable()
// export class IslamicI18n extends NgbDatepickerI18n {

//   getWeekdayShortName(weekday: number) {
//     return WEEKDAYS[weekday - 1];
//   }

//   getMonthShortName(month: number) {
//     return MONTHS[month - 1];
//   }

//   getMonthFullName(month: number) {
//     return MONTHS[month - 1];
//   }

//   getDayAriaLabel(date: NgbDateStruct): string {
//     return `${date.day}-${date.month}-${date.year}`;
//   }
// }






interface Food {
  value: string;  
  viewValue: string;
}

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
}; 

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'dd/MM/yyyy',this.locale);;
      } else {
          return date.toDateString();
      }
  } 
}

export const passwordMatchValidator: ValidatorFn = (registrationForm: FormGroup): ValidationErrors | null => {
  if (registrationForm.get('password').value === registrationForm.get('conformpassword').value)
    return null;
  else
    return {passwordMismatch: true};
};

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, investorInfoForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = investorInfoForm && investorInfoForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}


const trimValidator: ValidatorFn = (control: AbstractControl | null) => {
  if (control.value.startsWith(' ') ) {
    console.log('trim')
    return {
      'trimError': { value: 'control has trailing whitespace' }
    };
  }

  else if (control.value.startsWith(' ')  == ''   && control.value.startsWith(' ')  == null){
    return null
  }


  // if (control.value.endsWith(' ')) {
  //   return {
  //     'trimError': { value: 'control has trailing whitespace' }
  //   };
  // }

  // return null;
};


@Component({
  selector: 'app-investor-registration',
  templateUrl: './investor-registration.component.html',
  styleUrls: ['./investor-registration.component.scss'],
//   template: `
//   <button style="margin-left:10%" (click)="executeImportantAction()">Important action</button>
// `,
  providers: [
    {provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS},
    // {provide: NgbCalendar, useClass: NgbCalendarIslamicUmalqura},
    // {provide: NgbDatepickerI18n, useClass: IslamicI18n}
],
})
export class InvestorRegistrationComponent implements OnInit {
  model: NgbDateStruct;
  fileToUpload: File = null;
  secondnext = true;
  nextfirst= true;
  encryptSecretKey="sahlahcf";
  maxDate = new Date();
spinner = false;
spinner2 = false;
  hide = true;
  hide1 = true;
  hide3 = true;
  verifyotp=true;
first1:boolean=true;
first2:boolean=false;
first3:boolean=false;
first4:boolean=false;
first5:boolean=false;
  successmsg = 'The information has been successfully verified';
  foods: Food[] = [
    {value: '1-50,000', viewValue: '1-50,000'},
    {value: '50,000-100,000', viewValue: '50,000-100,000'},
    {value: '100,000-1,50,000', viewValue: '100,000-1,50,000'},
    {value: '1,50,000-2,50,000', viewValue: '1,50,000-2,50,000'},
    {value: '2,50,000-5,00,000', viewValue: '2,50,000-5,00,000'},
    {value: '5,00,000 Above', viewValue: '5,00,000 Above'}
  ];




  anualincome: Food[] = [
    {value: 'Less than 50,000 SAR', viewValue: 'Less than 50,000 SAR'},
    {value: 'From 50,000 to 100,000', viewValue: 'From 50,000 to 100,000 SAR'},
    {value: 'From 101,000 to 250,000 SAR', viewValue: 'From 101,000 to 250,000 SAR'},
    {value: 'From 251,000 to 500,000 SAR', viewValue: 'From 251,000 to 500,000 SAR'},
    {value: 'From 500,000 to 1,000,000 SAR', viewValue: 'From 500,000 to 1,000,000 SAR'},
    {value: 'More than 1,000,000 SAR', viewValue: 'More than 1,000,000 SAR'}
  ];

  
 
 
  sourceincome: Food[] = [
    {value: 'Business Owner', viewValue: 'Business Owner'},
    {value: 'Retired', viewValue: 'Retired'},
    {value:'Private Employee',viewValue:'Private Employee'},
    {value:'Government Employee',viewValue:'Government Employee'},
    {value:'Student',viewValue:'Student'},
    {value: 'Other', viewValue: 'Other'},

    
  ];
  jobstatus = [
    {value: 'BusinessOwner', viewValue: 'Business Owner'},
    {value: 'Student', viewValue: 'Student'},
    {value: 'Other', viewValue: 'Other'}
  ];
  banks = [
    {value: 'ALAWWAL Bank', viewValue: 'ALAWWAL Bank'},
      {value: 'ARAB NATIONAL BANK', viewValue: 'ARAB NATIONAL BANK'},
      {value: 'AL RAJHI BANKING AND INV.CORP.', viewValue: 'AL RAJHI BANKING AND INV.CORP.'}, 
      {value: 'AL BANK AL SAUDI AL FRANSI', viewValue: 'AL BANK AL SAUDI AL FRANSI'},
      {value: 'ALINMA BANK', viewValue: 'ALINMA BANK'},
      {value: 'BANK AlBILAD', viewValue: 'BANK AlBILAD'},
      {value: 'BANK MUSCAT', viewValue: 'BANK MUSCAT'},
      {value: 'BANK ALJAZIRA', viewValue: 'BANK ALJAZIRA'},
      {value: 'DEUTSHE BANK', viewValue: 'DEUTSHE BANK'},
      {value: 'Emirates Bank', viewValue: 'EMIRATES BANK'},
      {value: 'GULF INTERNATIONAL BANK', viewValue: 'GULF INTERNATIONAL BANK'},
      {value: 'NATIONAL COMMERCIAL BANK', viewValue: 'NATIONAL COMMERCIAL BANK'},
      {value: 'NATIONAL BANK OF BAHRAIN', viewValue: 'NATIONAL BANK OF BAHRAIN'},
      {value: 'National Bank of Kuwait', viewValue: 'NATIONAL BANK OF KUWAIT'},
      {value: 'National Bank of Pakistan', viewValue: 'NATIONAL BANK OF PAKISTAN'},
      {value: 'RIYAD BANK', viewValue: 'RIYAD BANK'},
    //  {value: 'Paryabas Bank', viewValue: 'PARYABAS BANK'},
      {value: 'SAUDI INVESTMENT BANK', viewValue: 'SAUDI INVESTMENT BANK'},
      // {value: 'SAUDI BRITISH BANK', viewValue: 'SAUDI BRITISH BANK'},
      {value: 'SABB BANK', viewValue: 'SABB BANK'},
      {value: 'SAUDI ARABIAN MONETARY AGENCY', viewValue: 'SAUDI ARABIAN MONETARY AGENCY'},
      {value: 'SAMBA BANK', viewValue: 'SAMBA BANK'},
     // {value: 'SAUDI AMERICAN BANK', viewValue: 'SAUDI AMERICAN BANK'},
     // {value:'SAUDI HOLLANDI BANK', viewValue:'SAUDI HOLLANDI BANK'},
    //  {value: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI', viewValue: 'TURKIYE CUMHURIYETI ZIRAAT BANKASI'},
    
  ];
  accounts= [
    {value: 'INDB12545545', viewValue: 'INDB12545545'}, 
    {value: 'ANDB12545545', viewValue: 'ANDB12545545'},
    {value: 'AXDB12545545', viewValue: 'AXDB12545545'}
  ];
  ibans  = [
    {value: 'DFG4W42342424', viewValue: 'DFG4W42342424'},
    {value: 'egG4W42342424', viewValue: 'egG4W42342424'},
    {value: 'hiG4W42342424', viewValue: 'hiG4W42342424'}
  ];
  registrationForm:FormGroup;
  submitted: boolean;
  ipAddress: string;
  geolocationPosition: object;
  latitude: any;
  longitude: any;
  deviceInfo: any;

  responseMessgae: string;
  registError: boolean;
  investorInfoForm:FormGroup;
  submitted1: boolean;
  submitted2:boolean;
  dateofbirth: any;
  otpForm:FormGroup
  yourInfoForm:FormGroup;
  yourInfoFormnon:FormGroup;
  submitted3: boolean;
  investorInfoMessage: string;
  investorYourInfoMessage: string;
  incomeinfoForm:FormGroup
  incomeInfoMessage: string;
  bankinginfoForm:FormGroup;
  uploadfileForm:FormGroup;
  msg: string;
  msgError: boolean;
  responseSucessMessgae: string;
  data: any;
  accesstoken: any;
  incomeInfoSucessMessage: string;
  selectErrorMsg: string;
  selectrror: boolean;
  SucessresponseMessgae: string;
  investorSucessInfoMessage: string;
  registSucessError: boolean;
  responseuploadsucessMessgae: string;
  uploadError: boolean;
  timeout = 120;
  minDate: { year: number; month: number; day: number; };
  countrycode: number;
  investorYourSucessInfoMessage: string;
  investSucesstError: boolean;
  otpverifyError: boolean;
  responseRegMessgae: string;
  spinner3: boolean;
  spinner4: boolean;
  registResponseError: boolean;
  successotp: boolean;
  next3 =  true;
  next4 = true;
  next5 =   true;
  spinner5: boolean;
  spinner6: boolean;
  spinner7: boolean;
  spinner8: boolean;
  firstcheck: any;
  checkans1: string;
  checkansterms: string;
  firstcheckpolicy: any;
  checkanspolicy: string;
  hidecoroseldown: boolean;
  regstage: any;
  count=0; 
  count1=0;
  hidecaroselup=false;
  counter: any;
  resendotpbutton: boolean;
  otpcount: number;
  hidetimer: boolean;
  sendotp: boolean;
  uploadfilesize: any;
  fileerror: string;
  fileError: boolean;
  termsprivacyError: boolean;
  termsprivacy: string;
  encriptdata: any;
  stage: any;
  decdata: any;
  ismobilealert: boolean;
  dataaaaae: string;
  datdob: any;
  saudi =true;
nonsaudi:boolean;
  dateerr: string;
  todaydate: any;
  doberr: string;
  dobdatcurrent: boolean;
  doberrdis: boolean;
  nationdis: boolean;
  formattedDategreg: string;
  bobdattt: any;
  setDate:any;
  currentengdob: Date;
  finalengcurrentdat: string;
  datewchange: any;
  currdate: string;
  doberrdiseng: boolean;
  bobdatttexpire: string;
  submitted9: boolean;
  responseSucessMessgaebank: string;
  bankresponseMessgae: string;
  constructor(private fb: FormBuilder,private router:Router,private calendar: NgbCalendar,private authService:AuthService,  private spinnerfull: NgxSpinnerService, private deviceinfoservice:DeviceinfoserviceService,
private token:RefreshtokenService,

    private http: HttpClient, private deviceService: DeviceDetectorService, private renderer: Renderer2) { 

      if(token.first2){
        this.first1=false;
        this.first2=true;
      }

     if(token.first3){
      this.first3 = true;
        this.first1 = false;
        this.first2 = false;
      }
      if(token.first4){
        this.first4 = true;
          this.first1 = false;
          this.first2 = false;
          this.first3 = false;
        }
        if(token.first5){
          this.first5 = true;
            this.first1 = false;
            this.first2 = false;
            this.first3 = false;
            this.first4 = false;
          }
         
       
      this.renderer.setStyle(document.body, 'background-color', '#f5f5f5');
     
      this.responseMessgae='';

      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
   
      if(this.data !=null && this.data !=''){
         
       
        // (this.data.alloworigen)
      this.stage=  this.decryptData(this.data.alloworigen)
        if(parseInt(this.stage) >=1){
        
          this.regstage= this.stage
        this. hidecoroseldown=true;
        }else{
          this. hidecoroseldown=false;
        }
      }
     
     
      //this.yourInfoForm.controls['nameen'].disable();
    }

  ngOnInit(): void {

    this.selectToday()

    const current = new Date();
    this.minDate = {
      year: current.getFullYear(),
      month: current.getMonth() + 1,
      day: current.getDate()
    };

    this.registrationForm=this.fb.group({
      firstName:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      lastName:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      email:['',[Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),Validators.required,Validators.maxLength(35)]],
      mobileNo: ['', [Validators.required,Validators.minLength(9), Validators.maxLength(9),  Validators.pattern("^(5)[0-9]{8}$")]],
      password:['', [Validators.required, Validators.minLength(8), Validators.maxLength(20),Validators.pattern('^[^ ].+[^ ]$')]],
      conformpassword:['', [Validators.required, Validators.minLength(8), Validators.maxLength(20),Validators.pattern('^[^ ].+[^ ]$')]],
     recaptchaReactive:['',Validators.required]
    },{
      validator: passwordMatchValidator
  });

  this.investorInfoForm=this.fb.group({
    nationality:[''],
    nationalId:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10), ]],
    Dob:['',[Validators.required ]],
    placeOfBirth:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
    currentResidentLocation:['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]]


  });

this.otpForm=this.fb.group({
  otp:['',[Validators.required,Validators.minLength(6), Validators.maxLength(6),]],
});


this.yourInfoForm=this.fb.group({
  nameen:['',[Validators.required,Validators.pattern("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$")]],
  namear:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF\ ]*$')]],
    idexpirationdate:['',[Validators.required]],
    gender:['',[Validators.required]],
    
});
// this.yourInfoFormnon=this.fb.group({
//   nameen:['',[Validators.required,Validators.pattern("^[a-zA-Z ]*$")]],
//   namear:['',[Validators.required,Validators.pattern("^[ ئ ا-ى   ؤ ء ي  ]*$")]],
//     // idexpirationdate:['',[Validators.required]],
//     gender:['',[Validators.required]],
//     idexpirationdateeng:['',[Validators.required]]
// });

this.incomeinfoForm = this.fb.group({
  anualIncome:['',Validators.required],
  sourceIncome:['',Validators.required],
  jobStatus:['',Validators.required]
}),

this.bankinginfoForm = this.fb.group({
  bankName:['',Validators.required],
  bankIBAN:['',[Validators.required,Validators.maxLength(28),Validators.pattern('^[A-Za-z0-9]*$')]],
  bankAccountHolderName: ['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
}),
this.uploadfileForm = this.fb.group({
  bank_account_letter: ['',Validators.required],
  terms_and_conditions:['',Validators.required],
  privacy_policy:['',Validators.required]
})

    $('.carousel .vertical .item').each(function(){
      var next = $(this).next();
      if (!next.length) {
        next = $(this).siblings(':first');
      }
      next.children(':first-child').clone().appendTo($(this));
      
      for (var i=1;i<2;i++) {
        next=next.next();
        if (!next.length) {
          next = $(this).siblings(':first');
        }
        
        next.children(':first-child').clone().appendTo($(this));
      }
    });




  
  }
  get registrationControllers() { return this.registrationForm.controls }
  get investerInfoOtpControllers() { return this.investorInfoForm.controls }
  get investeryourInfoControllers() { return this.yourInfoForm.controls }
  get password() { return this.registrationForm.get('password'); }
  get conformpassword() { return this.registrationForm.get('conformpassword'); }
  

  get investeryourInfononControllers() { return this.yourInfoFormnon.controls }
//   checkonstop(){
//     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
//     if(this.data !=null && this.data !=''){
//  for (let i = 0; i < parseInt(this.data.stage); i++) {
//           ("+++++++++++++++++++++++++++++")
//           $(".carousel").carousel("next");
//         }
//     }
   
//   }


noWhitespaceValidator(control: FormControl) {
  const isWhitespace = (control.value || "").trim().length === 0;
  const isValid = !isWhitespace;
  return (isValid ? null : { "whitespace": true });
}


numberOnly(event): boolean {
  const charCode = event.which ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}
  getErrorEmail() {
    return this.investorInfoForm.get('nationalId').hasError('required') ? 'Field is required' :
      this.investorInfoForm.get('nationalId').hasError('pattern') ? 'Not a valid emailaddress' :'';
        // this.formGroup.get('email').hasError('alreadyInUse') ? 'This emailaddress is already in use' : '';
  }
  get f() {
    return this.uploadfileForm.controls;
  }

  get o(){
    return this.uploadfileForm.controls;
  }
next() {
 
}

logoclear(){
  sessionStorage.clear();
}

getcurrentengdob() {
this.currentengdob = this.maxDate
var d = new Date(this.currentengdob ),
month = '' + (d.getMonth() + 1),
day = '' + d.getDate(),
year = d



.getFullYear();

if (month.length < 2) 
month = '0' + month;
if (day.length < 2) 
day = '0' + day;

this.finalengcurrentdat = [year, month, day].join('-');

return this.finalengcurrentdat

}



onDateChangeexpire(){
  var val = this.yourInfoFormnon.value.idexpirationdateeng
  

  var d = new Date(val),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

        this.bobdatttexpire = [year, month, day].join('-')


        return this.bobdatttexpire
}

onDateChange(val) {

  this.getcurrentengdob();
 
  this.datewchange = val;

  
   // Replace event.value with your date value
   var d = new Date(val),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

        this.bobdattt = [year, month, day].join('-')
     
this.setDate = [year+ 18, month, day].join('-');
        var currdate = this.finalengcurrentdat;

        if (currdate >= this.setDate) {
        this.dobdatcurrent = currdate >= this.setDate
       
        this.doberr = ''
       
        } else {
      
        this.doberrdiseng = true;
        this.doberr = 'Date of Birth should be greater than 18 years'
        // setTimeout(() => {
        //   this.doberrdiseng = false;
        // }, 3000);
        
 
        
        }
    return  this.bobdattt;

}


getenggdateee() {
 

  
  // Replace event.value with your date value
  var d = new Date(this.datewchange),
       month = '' + (d.getMonth() + 1),
       day = '' + d.getDate(),
       year = d.getFullYear();

   if (month.length < 2) 
       month = '0' + month;
   if (day.length < 2) 
       day = '0' + day;

       this.bobdattt = [year, month, day].join('-')
    
this.setDate = [year+ 18, month, day].join('-');
       this.currdate = this.finalengcurrentdat;

    
       if (this.currdate >= this.setDate) {
       this.dobdatcurrent = this.currdate >= this.setDate
     
      
       } else {
   
       this.doberrdiseng = true;
       this.doberr = 'Date of Birth should be greater than 18 years'
       setTimeout(() => {
         this.doberrdiseng = false;
       }, 3000);
       

       
       }
   return  this.bobdattt;
}



onPasswordInput() {
  if (this.registrationForm.hasError('passwordMismatch'))
    this.conformpassword.setErrors([{'passwordMismatch': true}]);
  else
    this.conformpassword.setErrors(null);
}
public detectDevice() {
  this.deviceInfo = this.deviceService.getDeviceInfo();
  // (this.deviceInfo)
}
public hasError = (controlName: string, errorName: string) =>{
  return this.investorInfoForm.controls[controlName].hasError(errorName);
}


timer() {
  this.authService.getObservable(this.timeout).subscribe(val => this.counter = val);
 
  this.resendotpbutton = false;

  if (this.otpcount == 0) {
    setTimeout(() => {
   
      this.hidetimer = false;
    }, 120000)
  } else {
    setTimeout(() => {
    
      this.sendotp=false;
      this.successotp = false;
      this.hidetimer = false
    }, 120000)
  }

}
// public executeImportantAction(): void {
//   this.recaptchaV3Service.execute('importantAction')
//     .subscribe((token) => this.handleToken(token));
// }
handleToken(token){
  // (token)
}
RegistrationDetails(){
  this.countrycode = null;
  this.submitted=true;  
  this.registrationForm.markAllAsTouched();
  // (this.registrationForm.value.recaptchaReactive)
  // (this.registrationForm.value)
  
  if(this.registrationForm.valid){
 
    this.countrycode = 966
    this.detectDevice();
    // this.showPosition(this.geolocationPosition);
    const object: any = {}
      object['browserType'] = this.deviceInfo.browser;
      object['browserVersion'] = this.deviceInfo.browser_version;
      object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
      object['language'] = 'en';
      object['countryCode'] = 'SA';
    //  object['email'] = this.registrationForm.value.email
      object['firstName'] = this.registrationForm.value.firstName
      object['lastName'] = this.registrationForm.value.lastName
    //  object['password'] = this.registrationForm.value.password
      object['osVersion'] = this.deviceInfo.os_version;
      object['osType'] = this.deviceInfo.os;
      object['mobile'] = this.countrycode + this.registrationForm.value.mobileNo
      object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      object['registrationType'] = 'Investor';
      object['recaptchaResponse'] = this.registrationForm.value.recaptchaReactive;
      


      
    //  (object)
this.spinner = true;
 
this.spinnerfull.show();
this.authService.RegistrationDetails(object,this.registrationForm.value.email,this.registrationForm.value.password).subscribe(response =>
  this.registrationDetailsSubmit(response)
 
  )
  
  }
}
encryptData(data) {

  try {
    // ()
    // this.decryptData(CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString()) 
    this.encriptdata=CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString();
    return CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptSecretKey).toString();
   
  } catch (e) {
    // (e);
  }
}


decryptData(data) {

  try {
    const bytes = CryptoJS.AES.decrypt(data, this.encryptSecretKey);
    if (bytes.toString()) {
     // (JSON.parse(bytes.toString(CryptoJS.enc.Utf8)))
      return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    }
   // (data)
    return data;
    
  } catch (e) {
    // (e);
  }
}

registrationDetailsSubmit(response){
  // (response)
  this.registrationForm.controls['recaptchaReactive'].reset();
  this.submitted=false;  
  if(response.Registration_Response== 1000){
   
    this.registrationForm.reset();
    
    this.responseSucessMessgae = "Investor Registered SucessFully";
    const object: any = {}
    this.encryptData(1)
    object.accesstoken = response.token;
    object.alloworigen =  this.encriptdata
    this.hidecaroselup=true;
    this.token.changeMessagereg(response); 
    sessionStorage.setItem('currentUser', JSON.stringify(object))

              this.registSucessError = true;
              setTimeout(() => {
                this.registSucessError = false;
                this.first1=false;
this.first2=true;
                this.spinner = false;
                 
this.spinnerfull.hide();
              
              },3000)
  }
  else if(response.Registration_Response == 1194){
    this.spinnerfull.hide();
    this.responseRegMessgae = "CAPTCHA_EMPTY";

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
                this.spinnerfull.hide();
              }, 3000)
  }else if(response.Registration_Response == 1195){
    this.spinnerfull.hide();
    this.responseRegMessgae = "INVALID_CAPTCHA";

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
                this.spinnerfull.hide();
              }, 3000)
  }
  
  
  
  
  
  
  else if(response.Registration_Response== 1001){
    this.responseRegMessgae = "FAILURE";
    this.spinnerfull.hide();

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
                this.spinnerfull.hide();
              }, 3000)
  }else if(response.Registration_Response== 1003){
    this.responseRegMessgae = "BROWSER TYPE IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
                this.spinnerfull.hide();
              }, 3000)
  }else if(response.Registration_Response== 1004){
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
                this.spinnerfull.hide();
              }, 3000)
  }else if(response.Registration_Response== 1005){
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();
              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
    
              }, 3000)
  }else if(response.Registration_Response== 1006){
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();
              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
             
              }, 3000)
  }else if(response.Registration_Response== 1007){
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();
              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
      
              }, 3000)
  }else if(response.Registration_Response== 1008){
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();
              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
        
              }, 3000)
  }else if(response.Registration_Response== 1009){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1010){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1011){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1012){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1013){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1014){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1015){
    this.responseRegMessgae = "SOMETHING WENT WRONG";

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1016){
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();

              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1017){
    this.responseRegMessgae = "MOBILE NUMBER IS EMPTY";


              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
           
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1018){
    this.responseRegMessgae = "MOBILE NUMBER IS NOT VALID";

              this.registResponseError = true;
              this.spinnerfull.hide();
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1019){
    this.responseRegMessgae = "FIRST NAME IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1020){
    this.responseRegMessgae = "LAST NAME IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1021){
    this.responseRegMessgae = "SPECIAL CHARACTERS ARE NOT ALLOWED IN FIRST NAME";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1022){
    this.responseRegMessgae = "SPECIAL CHARACTERS ARE NOT ALLOWED IN lAST NAME";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1023){
    this.responseRegMessgae = "EMAIL ID IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1024){
    this.responseRegMessgae = "EMAIL ID IS NOT VALID";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1025){
    this.responseRegMessgae = "PASSWORD IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1026){
    this.responseRegMessgae = "PASSWORD SHOULD BE MINIMUM 8 AND MAXIMUM 20";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response==1027){
    this.responseRegMessgae = "BRAND NAME IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1044){
    this.responseRegMessgae = "REGISTRATION TYPE IS EMPTY";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1045){
    this.responseRegMessgae = "REGISTRATION TYPE SHOULD BE LENDER OR BARROWER";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1046){
    this.responseRegMessgae = "EMAIL ALREADY EXISTS";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else if(response.Registration_Response== 1047){
    this.responseRegMessgae = "MOBILE NUMBER ALREADY EXTSTS";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }else {
    this.responseRegMessgae = "SOMETHING WENT WRONG";
    this.spinnerfull.hide();
              this.registResponseError = true;
              setTimeout(() => {
                this.registResponseError = false;
              }, 3000)
  }
}









radioselect(val) {

  
  if(val == 'NON_SAUDI') {
  
    this.nonsaudi = true;
    this.saudi = false;
  }
  
  if(val == 'SAUDI') {
  
    this.nonsaudi = false;
    this.saudi = true;
  }
  
    }

selectToday() {
  this.model = this.calendar.getToday();
  

  this.todaydate =  `${this.model.year}-${this.model.month}-${this.model.day}`


}

getdobjj() {
  var age = 18;
  if(this.investorInfoForm.value.nationality =='SAUDI') {
  const formattedDate = this.investorInfoForm.value.Dob;
 
  
  
if(formattedDate.day > 10) {

  this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
  
 
  var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;

var currdate = this.todaydate;

if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate



} else {

this.doberrdis = true;
this.doberr = 'Date of Birth should be greater than 18 years'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);
}
  return this.datdob

}
else{
  this.datdob =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
  
  // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
  var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-0${formattedDate.day}` ;
 
var currdate = this.todaydate;


if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate
// you are above 18

//alert("above 18");
} else {

this.doberrdis = true;
this.doberr = 'Date of Birth should be greater than 18 years'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);

// alert("below 18");
}
  return this.datdob

}
}
}


getdobgreg() {
  var age = 18;
  (this.investorInfoForm.value.Dob)
  const momentDate = new Date(this.investorInfoForm.value.Dob); // Replace event.value with your date value
    this. formattedDategreg = moment(momentDate).format("YYYY-MM-DD");
     
     
  


//   this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
//   (this.datdob)
//   // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
//   var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;
//   (setDate)
// var currdate = this.todaydate;
// (currdate);
// (currdate >= setDate)
// if (currdate >= setDate) {
// this.dobdatcurrent = currdate >= setDate
// // you are above 18
// ("above18")
// // alert("above 18");
// } else {
// ("below18")
// this.doberrdis = true;
// this.doberr = 'Date of Birth should be greater than 18 years'
// setTimeout(() => {
//   this.doberrdis = false;
// }, 3000);
// }
//   return this.datdob

// }

}

// checkInvesterIfor(){
   
      

// this.getdobjj();
   
    

// this.investorInfoForm.markAllAsTouched();
 
//   this.data = JSON.parse(sessionStorage.getItem('currentUser'));
//   if(this.data!=null || this.data !=''){
//     this.accesstoken= this.data.accesstoken;
//   }




//   if(this.investorInfoForm.value.nationality !=null && this.investorInfoForm.value.nationality !='') {
//     this.selectErrorMsg ='';
//   }

//   else  {
//     ("+++++++++++++++")
//     this.nationdis = true;
//     this.selectErrorMsg = "Please Select Nationality";
   
                 
//                  setTimeout(() => {
//                   this.nationdis = false;
//                  }, 3000)
//     }




// if(this.investorInfoForm.value.nationality =='SAUDI'){

//   if( this.dobdatcurrent ==true){

//     if(this.investorInfoForm.valid){
//       this.detectDevice();
//       const momentDate = new Date(this.investorInfoForm.value.Dob); 
//       const formattedDate = moment(momentDate).format("YYYY-MM-DD");
//        (formattedDate);
//       const object: any = {}
//       object['browserType'] = this.deviceInfo.browser;
//       object['browserVersion'] = this.deviceInfo.browser_version;
//       object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//       object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//       object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//       object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//       object['language'] = 'en';
//       object['countryCode'] = 'SA';
//       object['nationality'] = this.investorInfoForm.value.nationality
  
     
//       if(this.investorInfoForm.value.nationality =='SAUDI') {
//         object['dob'] = this.datdob
//       }
     
//       object['id'] = this.investorInfoForm.value.nationalId
//       object['registrationId'] = '15'
//       object['osVersion'] = this.deviceInfo.os_version;
//       object['osType'] = this.deviceInfo.os;
      
//       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      
      
//        (object)
//   this.spinner3=true;
  
  
  
//   this.spinnerfull.show();
//   this.authService.submitInvesterInfo(object,this.accesstoken).subscribe(response=>
//     this.submitInvestorResponse(response))
  
    
//     };
//   }

// }

// if(this.investorInfoForm.value.nationality =='NON_SAUDI'){

// if( this.dobdatcurrent  == true){


  


//   ('djfhsdk')
// (this.bobdattt)
//   (this.investorInfoForm.valid)
  
//       this.detectDevice();
    
//       const object: any = {}
//       object['browserType'] = this.deviceInfo.browser;
//       object['browserVersion'] = this.deviceInfo.browser_version;
//       object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//       object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//       object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//       object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//       object['language'] = 'en';
//       object['countryCode'] = 'SA';
//       object['nationality'] = this.investorInfoForm.value.nationality
  
      
//         object['dob'] = this.bobdattt
    
     
//       object['id'] = this.investorInfoForm.value.nationalId
//       object['registrationId'] = '15'
//       object['osVersion'] = this.deviceInfo.os_version;
//       object['osType'] = this.deviceInfo.os;
      
//       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
      
      
//        (object)
//   this.spinner3=true;
  
  
  
//   this.spinnerfull.show();
//   this.authService.submitInvesterInfo(object,this.accesstoken).subscribe(response=>
//     this.submitInvestorResponse(response))

    
//     };

//   }

//   }





checkInvesterIfor(){
  //this.submitted1=true;
this.investorInfoForm.markAllAsTouched();
  // (this.investorInfoForm.value)
  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
 
    this.accesstoken= this.data.accesstoken;
    console.log(this.accesstoken)
  }

  if(this.investorInfoForm.value.nationality !=null && this.investorInfoForm.value.nationality !='') {
    this.selectErrorMsg ='';
  }

  else  {
    ("+++++++++++++++")
    this.nationdis = true;
    this.selectErrorMsg = "Please Select Nationality";
   
                 
                 setTimeout(() => {
                  this.nationdis = false;
                 }, 3000)
    }



  if( this.dobdatcurrent ==true){
  if(this.investorInfoForm.valid){
    this.detectDevice();
    const momentDate = new Date(this.investorInfoForm.value.Dob); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    
    const object: any = {}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
    object['language'] = 'en';
    object['countryCode'] = 'SA';
    object['nationality'] = this.investorInfoForm.value.nationality
    object['dob'] = this.bobdattt
    object['id'] = this.investorInfoForm.value.nationalId
    object['currentResidentLocation']  = this.investorInfoForm.value.currentResidentLocation;
    object['placeOfBirth'] = this.investorInfoForm.value.placeOfBirth;
    object['registrationId'] = '15'
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    
    
    console.log(object)
this.spinner3=true;
// this.spinnerfull.show();

this.spinnerfull.show();
this.authService.submitInvesterInfo(object,this.accesstoken).subscribe(response=>
  this.submitInvestorResponse(response))

  
  };
}
// }else{
 
//   this.selectErrorMsg = "Please Select Nationality";

              
           
//  }
}


submitInvestorResponse(response){
  console.log(response)
  this.spinner3 = false;
  this.spinnerfull.hide();
  if(response.investor_info_otp_response== '1097'){
    this.verifyotp=false;
    this.SucessresponseMessgae = "OTP SEND TO YOUR MOBILE NUMBER";
    this.timer();
    this.hidetimer = true;
this.successotp = true;
this.sendotp = true;
setTimeout(() => {
  this.successotp = false;
  // this.spinnerfull.hide();
},3000 );
   
              // this.registError = true;
              // setTimeout(() => {
              //   this.registError = false;
              // }, 3000000000000000000000000)
  }else if(response.investor_info_otp_response== '1001'){
    this.responseMessgae = "FAILURE";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== '1003'){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== '1097'){
    this.responseMessgae = "OTP_NOT_SENT";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== '1005'){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1006){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1007){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1008){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1009){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1010){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1011){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1012){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1013){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1014){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1015){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response==1016){
    this.responseMessgae = "SOMETHING WENT WRONG";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }
  else if(response.investor_info_otp_response== 1040){
    this.responseMessgae = "REGISTRATION ID IS EMPTY";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1041){
    this.responseMessgae = "REGISTRAIION ID SHOULD BE NUMERIC";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }
  
  else if(response.Token_Status== 1120){
    this.responseMessgae = "UNAUTHORIZED";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response== 1140){
    this.responseMessgae = "DOB IS EMPTY";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response=='1142'){
    this.responseMessgae = "DOB IS INVALID";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response=='1146'){
    this.responseMessgae = "NATIONAL ID IS EMPTY";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
  }else if(response.investor_info_otp_response=='1147'){
    this.responseMessgae = "NATIONALITY IS EMPTY";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
   }else if(response.investor_info_otp_response=='1148'){
    this.responseMessgae = "NATIONALITY SHOULD BE SAUDI OR NON SAUDI";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
   }


   else if(response.investor_info_otp_response=='1253'){
    this.responseMessgae = "PLACE OF BIRTH IS EMPTY";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
   }

   else if(response.investor_info_otp_response=='1254'){
    this.responseMessgae = "CURRENT RESIDENT LOCATION IS EMPTY";

              this.registError = true;
              setTimeout(() => {
                this.registError = false;
              }, 3000)
   }
}
// otpSubmit(){
//   this.otpForm.markAllAsTouched();
 
//   if(this.otpForm.valid){
//     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
//     if(this.data!=null || this.data !=''){
//       this.accesstoken= this.data.accesstoken;
//     }
//     this.detectDevice();
//     const momentDate = new Date(this.investorInfoForm.value.Dob); 
//     const formattedDate = moment(momentDate).format("YYYY-MM-DD");
  
//     const object: any = {}
//     object['browserType'] = this.deviceInfo.browser;
//     object['browserVersion'] = this.deviceInfo.browser_version;
//     object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//     object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//     object['language'] = 'en';
//     object['countryCode'] = 'SA';
//     object['nationality'] = this.investorInfoForm.value.nationality
    
//     if(this.investorInfoForm.value.nationality =='NON_SAUDI') {
//       object['dob'] = this.bobdattt
//     }
//     if(this.investorInfoForm.value.nationality =='SAUDI') {
//       object['dob'] = this.datdob
//     }
   
//     object['id'] = this.investorInfoForm.value.nationalId
//     object['registrationId'] = '15'
//     object['osVersion'] = this.deviceInfo.os_version;
//     object['osType'] = this.deviceInfo.os;
    
//     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//     object['otp'] = this.otpForm.value.otp;
//     this.spinnerfull.show();

//     this.spinner4 = true;
//     this.authService.submitInvesterInfoOtp(object,this.accesstoken).subscribe(response=>
//       this.submitInvestorotpResponse(response))
//       this.spinnerfull.show();
   
//       };
//   }


otpSubmit(){
  this.otpForm.markAllAsTouched();
  // (this.otpForm.value)
  if(this.otpForm.valid){
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    this.detectDevice();
    const momentDate = new Date(this.investorInfoForm.value.Dob); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    // (formattedDate);
    const object: any = {}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
    object['language'] = 'en';
    object['countryCode'] = 'SA';
    object['nationality'] = this.investorInfoForm.value.nationality
    object['dob'] = this.bobdattt
    object['currentResidentLocation']  = this.investorInfoForm.value.currentResidentLocation;
    object['placeOfBirth'] = this.investorInfoForm.value.placeOfBirth;
    object['id'] = this.investorInfoForm.value.nationalId
    object['registrationId'] = '15'
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['otp'] = this.otpForm.value.otp;
    this.spinnerfull.show();
    console.log(object)
    this.spinner4 = true;
    this.authService.submitInvesterInfoOtp(object,this.accesstoken).subscribe(response=>
      this.submitInvestorotpResponse(response))
      this.spinnerfull.show();
   
      };
  }








  submitInvestorotpResponse(response){
   
    this.spinnerfull.hide();
    this.hidetimer = false;
    this.spinner4 = false;
    this.spinnerfull.hide();
    if(response.investor_info_response == '1000'){
      this.sendotp=true;
      this.verifyotp=true;
      this.investorSucessInfoMessage = "Otp Verified SucessFully";
  this.secondnext = false;
                this.otpverifyError = true;
                setTimeout(() => {
                  this.otpverifyError = false;
                 
                 
                }, 3000)
    }else if(response.investor_info_response== '1001'){
      this.investorInfoMessage = "FAILURE";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1003'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1004'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1005'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1006'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1007'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1008'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1009'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1010'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1011'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1012'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1013'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1014'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1015'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response=='1016'){
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }
    else if(response.investor_info_response== '1040'){
      this.investorInfoMessage = "REGISTRATION ID IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1041'){
      this.investorInfoMessage = "REGISTRAIION ID SHOULD BE NUMERIC";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response== '1140'){
      this.investorInfoMessage = "DOB IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response=='1142'){
      this.investorInfoMessage = "DOB IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response=='1146'){
      this.investorInfoMessage = "NATIONAL ID IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_info_response=='1147'){
      this.investorInfoMessage = "NATIONALITY IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     
     else if(response.token_staus=='1120'){
      this.investorInfoMessage = "UNAUTHORIZED ";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     
     
     
     else if(response.investor_info_response=='1148'){
      this.investorInfoMessage = "NATIONALITY SHOULD BE SAUDI OR NON SAUDI";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_info_response=='1090'){
      this.investorInfoMessage = "OTP IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_info_response=='1091'){
      this.investorInfoMessage = "OTP SHOULD BE NUMERIC";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_info_response=='1092'){
      this.investorInfoMessage = "OTP LEANGTH SHOULD BE 4 DIGITS";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_info_response=='1093'){
      this.investorInfoMessage = "OTP IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_info_response=='1094'){
      this.investorInfoMessage = "OTP EXPIRED";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }

     else if(response.investor_info_response=='1253'){
      this.investorInfoMessage = "PLACE OF BIRTH IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     else if(response.investor_info_response=='1254'){
      this.investorInfoMessage = "CURRENT RESIDENT LOCATION IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     else {
      this.investorInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                },3000)
    }

  }


  getdateeee() {
    const formattedDate = this.yourInfoForm.value.idexpirationdate;

    if(formattedDate.day < 10  && formattedDate.month < 10 ) {
      this.dataaaaae =  `${formattedDate.year}-0${formattedDate.month}-0${formattedDate.day}`
    //  (this.dataaaaae)
      return this.dataaaaae
    }


    else if(formattedDate.month < 10 ) {
      this.dataaaaae =  `${formattedDate.year}-0${formattedDate.month}-${formattedDate.day}`
      return this.dataaaaae
    }

    else if(formattedDate.day < 10 ) {
      this.dataaaaae =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
      return this.dataaaaae
    }
    else {
      this.dataaaaae =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`
    //  (this.dataaaaae)
      return this.dataaaaae
    }

  }
  


//   InvesterYourInfoSubmit(){

//     this.getdateeee();
//     (this.bobdatttexpire)
//     this.onDateChangeexpire();
    
//     this.submitted3=true;
//     this.submitted9 = true;

//     (this.yourInfoForm.valid)
//     (this.yourInfoFormnon.valid)
   

// if(this.investorInfoForm.value.nationality =='SAUDI') {


   
   
//       this.data = JSON.parse(sessionStorage.getItem('currentUser'));
//       if(this.data!=null || this.data !=''){
//         this.accesstoken= this.data.accesstoken;
//       }
//       this.detectDevice();
//       const formattedDate = moment(this.yourInfoForm.value.idexpirationdate).format("YYYY-MM-DD");
      


//       const object: any = {}
//       object['browserType'] = this.deviceInfo.browser;
//       object['browserVersion'] = this.deviceInfo.browser_version;
//       object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//       object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//       object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//       object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//       object['language'] = 'en';
//       object['countryCode'] = 'SA';
      
//       object['registrationId'] = '15'
//       object['osVersion'] = this.deviceInfo.os_version;
//       object['osType'] = this.deviceInfo.os;
      
//       object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//       object['nameAr'] = this.yourInfoForm.value.namear;
//       object['nameEn'] = this.yourInfoForm.value.nameen

  
//     if(this.investorInfoForm.value.nationality =='SAUDI') {
//       object['idExpirationDate'] = this.dataaaaae
//     }
    
//       object['gender'] = this.yourInfoForm.value.gender
//       object['otp'] = this.otpForm.value.otp;
//        (object)
// this.spinner5 = true;
//       this.authService.investorYourInfo(object,this.accesstoken).subscribe(response=>
//         this.investorYourInfoResponse(response))
//         this.spinnerfull.show();
    


//   }

//   if(this.investorInfoForm.value.nationality =='NON_SAUDI') {
  
//     this.data = JSON.parse(sessionStorage.getItem('currentUser'));
//     if(this.data!=null || this.data !=''){
//       this.accesstoken= this.data.accesstoken;
//     }
//     this.detectDevice();
   
//     const formattedDate = moment(this.yourInfoForm.value.idexpirationdate).format("YYYY-MM-DD");
   

//     const object: any = {}
//     object['browserType'] = this.deviceInfo.browser;
//     object['browserVersion'] = this.deviceInfo.browser_version;
//     object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//     object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
//     object['language'] = 'en';
//     object['countryCode'] = 'SA';
    
//     object['registrationId'] = '15'
//     object['osVersion'] = this.deviceInfo.os_version;
//     object['osType'] = this.deviceInfo.os;
    
//     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//     object['nameAr'] = this.yourInfoFormnon.value.namear;
//     object['nameEn'] = this.yourInfoFormnon.value.nameen



//     object['idExpirationDate'] = this.bobdatttexpire
  
  
//     object['gender'] = this.yourInfoFormnon.value.gender
//     object['otp'] = this.otpForm.value.otp;
//      (object)
// this.spinner5 = true;
//     this.authService.investorYourInfo(object,this.accesstoken).subscribe(response=>
//       this.investorYourInfoResponse(response))
//       this.spinnerfull.show();
  

//     }








//   }


InvesterYourInfoSubmit(){

  this.getdateeee();
  this.submitted3=true;
  // (this.yourInfoForm.value)
  if(this.yourInfoForm.valid){
  
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    this.detectDevice();
   // const momentDate = new Date(this.yourInfoForm.value.idexpirationdate); // Replace event.value with your date value
    const formattedDate = moment(this.yourInfoForm.value.idexpirationdate).format("YYYY-MM-DD");
    // (formattedDate);


    const object: any = {}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
    object['language'] = 'en';
    object['countryCode'] = 'SA';
    
    object['registrationId'] = '15'
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['nameAr'] = this.yourInfoForm.value.namear;
    object['nameEn'] = this.yourInfoForm.value.nameen
    object['idExpirationDate'] = this.dataaaaae
    object['gender'] = this.yourInfoForm.value.gender
    object['otp'] = this.otpForm.value.otp;
  // console.log(object)
this.spinner5 = true;
    this.authService.investorYourInfo(object,this.accesstoken).subscribe(response=>
      this.investorYourInfoResponse(response))
      this.spinnerfull.show();
  }
}









  investorYourInfoResponse(response){
   // console.log(response)
    this.spinner5 = false;
    // (response.investor_yourInfo_response)
    if(response.investor_yourInfo_response == '1000'){
      this.hidecoroseldown=false;
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      const object: any = {}
      this.encryptData(2)
      object.accesstoken = this.accesstoken;
      object.alloworigen =  this.encriptdata
      // object.accesstoken =  this.accesstoken
      // object.stage = '2';
      sessionStorage.setItem('currentUser', JSON.stringify(object))
      this.submitted3=false;
      this.investorYourSucessInfoMessage = "Investor Information Submitted SucessFully";
  this.yourInfoForm.reset();
  this.investorInfoForm.reset();
 
                this.investSucesstError = true;
                setTimeout(() => {
                  this.investSucesstError = false;
                  this.otpForm.reset();
                  this.first2=false;
                  this.first3=true;
                  this.spinnerfull.hide();
                }, 3000)
    }else if(response.investor_yourInfo_response == '1001'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "FAILURE";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response == '1003'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1093'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "OTP INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1005'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1006'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1007'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1008'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1009'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1010'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1011'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1012'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1013'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1014'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1015'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response=='1016'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }
    else if(response.investor_yourInfo_response== '1040'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "REGISTRATION ID IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1041'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "REGISTRAIION ID SHOULD BE NUMERIC";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response== '1140'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "DOB IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response=='1142'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "DOB IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response=='1146'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "NATIONAL ID IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_yourInfo_response=='1147'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "NATIONALITY IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1148'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "NATIONALITY SHOULD BE SAUDI OR NON SAUDI";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1090'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "OTP IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1091'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "OTP SHOULD BE NUMERIC";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1092'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "OTP LENGTH SHOULD BE 4 DIGITS";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1093'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "OTP IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1094'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "OTP EXPIRED";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response=='1136'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "ENGLISH NAME IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response=='1137'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "ARABIC NAME IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response=='1139'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "GENDER IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response=='1141'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "ID EXPIRY DATE IS EMPTY";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1143'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "ENGLISH NAME IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1144'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "ARABIC NAME IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }else if(response.investor_yourInfo_response =='1149'){
      this.spinnerfull.hide();
      this.investorYourInfoMessage = "ID EXPIRATION DATE IS INVALID";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
     }
     else {
      this.investorYourInfoMessage = "SOMETHING WENT WRONG";
      this.spinnerfull.hide();
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000000000000000)
    }

  }
  IncomeInformationSubmit(){

    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    // (this.accesstoken)
    // (this.incomeinfoForm.value)

   
    this.incomeinfoForm.markAllAsTouched();
    if(this.incomeinfoForm.valid){
    
      this.detectDevice();   
// ("+++++++++++++++++++++++")

const object: any = {}
object['browserType'] = this.deviceInfo.browser;
object['browserVersion'] = this.deviceInfo.browser_version;
object['ipAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
object['deviceType'] = this.deviceinfoservice.deviceinfo.deviceType;
object['osVersion'] = this.deviceInfo.os_version;
object['osType'] = this.deviceInfo.os;
object['browserType'] = this.deviceInfo.browser;
object['browserVersion'] = this.deviceInfo.browser_version;
object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
object['language'] = 'en';
object['countryCode'] = 'SA';
object['registration_Id'] = '15'

object['annualIncome'] =this.incomeinfoForm.value.anualIncome ;
object['incomeSource'] = this.incomeinfoForm.value.sourceIncome;
object['jobStatus'] = this.incomeinfoForm.value.jobStatus

// (object)
this.spinner6= true;
this.authService.incomeInformationSubmit(object,this.accesstoken).subscribe(response=>
  this.incomeInfoResponse(response))
  this.spinnerfull.show();

    }
  }
  incomeInfoResponse(response){
    // (response)
    this.spinner6= false;
    if(response.investor_income_response== 1000){



      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
      const object: any = {}
      this.encryptData(3)
      object.accesstoken = this.accesstoken;
      object.alloworigen =  this.encriptdata
      // object.accesstoken =  this.accesstoken
      // object.stage = '3';
      sessionStorage.setItem('currentUser', JSON.stringify(object))
      this.incomeInfoSucessMessage = "Income Information Submited SucessFully";
  this.incomeinfoForm.reset();
  this.next3 = false;
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                  this.first3=false;
                  this.first4=true;
                  this.spinnerfull.hide();
                }, 3000)
    }else if(response.investor_income_response== 1001){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "FAILURE";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1003){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1004){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_response== 1005){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1006){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1007){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1008){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1009){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1010){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1011){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1012){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1013){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1014){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response== 1015){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response==1016){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
                this.registError = true;
                setTimeout(() => {
                  this.registError = false;
                }, 3000)
    }else if(response.investor_income_response ==1132){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "ANNUAL INCOME IS EMPTY";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.investor_income_response ==1133){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOURCE OF INCOME IS EMPTY";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.investor_income_response ==1134){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "JOB STATUS IS EMPTY";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.investor_income_response ==1040){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "REGISTRATION ID IS EMPTY";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.investor_income_response ==1041){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "REGISTRAIION ID SHOULD BE NUMERIC";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else if(response.investor_income_response ==1042){
      this.spinnerfull.hide();
      this.incomeInfoMessage = "REGISTRATION ID NOT VALID";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)
    }else {
      this.spinnerfull.hide();
      this.incomeInfoMessage = "SOMETHING WENT WRONG";
  
      this.registError = true;
      setTimeout(() => {
        this.registError = false;
      }, 3000)    }

  }


  bankinfo() {
    this.bankinginfoForm.markAllAsTouched();
    // (this.bankinginfoForm.value)
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }
    if(this.bankinginfoForm.valid){
 

      const object = {... this.deviceinfoservice.deviceinfo, language:'en',registrationId:6,bankName:this.bankinginfoForm.value.bankName,
    bankIBAN:this.bankinginfoForm.value.bankIBAN,iPAddress:this.deviceinfoservice.deviceinfo.ipAdress, bankAccountHolderName:this.bankinginfoForm.value.bankAccountHolderName,
    registrationType:'Investor' }   
    // (object)
    this.spinner7 = true;
    this.authService.bankinformation(object,this.accesstoken).subscribe(response =>{
     console.log(response)
      this.spinnerfull.show();
      this.spinner7 = false;
      if(response.bankinfo_response== 1000){



        this.hidecoroseldown=false;
        this.data = JSON.parse(sessionStorage.getItem('currentUser'));
        if(this.data!=null || this.data !=''){
          this.accesstoken= this.data.accesstoken;
        }
        // const object: any = {}
        // this.encryptData(4)
        // object.accesstoken = this.accesstoken;
        // object.alloworigen =  this.encriptdata
      
        // sessionStorage.setItem('currentUser', JSON.stringify(object))
        this.next4= false;
        this.responseSucessMessgaebank = "BANK INFORMATION ADDED SUCESSFULLY";
    this.bankinginfoForm.reset();
                  this.registError = true;

                  const object: any = {}
                  object['FirstName']  = response.FirstName;
                  object['LastName']     = response.LastName;
                  object['LastLogin']    = response.LastLogin;
                  object['isMobileVerified']   = response.isMobileVerified;
                  object['profileStatus'] = response.profileStatus;
                  object['isEmailVerified']   = response.isEmailVerified;
                  object['accesstoken']   =  this.accesstoken;
                  object['isPolicyAccepted']   = response.isPolicyAccepted;
                  object['isBankInfoProvided']    = response.isBankInfoProvided;
                  object['isInvestorInfoProvided']    = response.isInvestorInfoProvided;
                  object['isTermsAccepted']  = response.isTermsAccepted;
                  object['id'] = response.id 
                 
                  object['iqamaId'] = response.iqamaId
                  object['isBankAccountLetterUploaded'] = response.isBankAccountLetterUploaded;
                  // object['redirect'] = '/auth/investorRegister';
                  object['redirect']="englishwebapp";
                  sessionStorage.setItem('currentUser',JSON.stringify(object))
                  setTimeout(() => {
                    this.registError = false;
                    this.first4=false;
this.first5=true;
                    this.spinnerfull.hide();

                   



                  }, 3000)
      }else if(response.bankinfo_response== 1001){
        this.bankresponseMessgae = "FAILURE";
        this.spinnerfull.hide();
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1002){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
    
      else if(response.bankinfo_response== 1003){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1004){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1005){
         this.bankresponseMessgae = "SOMETHING WENT WRONG";
         this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1006){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1007){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1008){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1009){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1010){
        this.bankresponseMessgae = "SOMETHING WENT WRONG"; 
        this.spinnerfull.hide();   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1011){
        this.bankresponseMessgae = "SOMETHING WENT WRONG"; 
        this.spinnerfull.hide();   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1012){
        this.bankresponseMessgae = "SOMETHING WENT WRONG"; 
        this.spinnerfull.hide();   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1013){
        this.bankresponseMessgae = "SOMETHING WENT WRONG"; 
        this.spinnerfull.hide();   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1014){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1015){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";
        this.spinnerfull.hide();    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response==1016){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";  
        this.spinnerfull.hide();  
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1040){
        this.bankresponseMessgae = "REGISTRATION ID IS EMPTY"; 
        this.spinnerfull.hide();   
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1041){
        this.bankresponseMessgae = "REGISTRAIION ID SHOULD BE NUMERIC";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }else if(response.bankinfo_response== 1042){
        this.bankresponseMessgae = "REGISTRATION ID NOT VALID";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }

      else if(response.bankinfo_response== 1055){
        this.bankresponseMessgae = "BANK IBAN SHOULD NOT BE EMPTY";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.bankinfo_response== 1083){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";   
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.bankinfo_response== 1084){
        this.bankresponseMessgae = "SOMETHING WENT WRONG";   
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
      else if(response.bankinfo_response== 1145){
        this.bankresponseMessgae = "BANK ACCOUNT NAME IS EMPTY";
        this.spinnerfull.hide();
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      } else {
        this.bankresponseMessgae = "SOMETHING WENT WRONG";   
    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
    
    })
     
    }
  }

  onFileChange(event) {
    this.uploadfilesize=event.target.files[0].size
    if(event.target.files[0].size < 5000000){
  
    if (event.target.files.length > 0) {
      
      const file = event.target.files[0];
      this.fileError = false;
      this.uploadfileForm.get('bank_account_letter').setValue(file);
    
    }
  }else{
    this.fileerror="Upload File Should Be Less Than 5 MB"
    
    this.fileError = true;
    // setTimeout(() => {
    //   this.fileError = false;
    // }, 3000)
  }
  }

  
  docskip() {
    this.router.navigate(['/englishwebapp/webappmaindashboard'])
  }

  uploadform() {
    this.submitted = true;
    
    this.submitted2 = true;
  //  (this.uploadfileForm.value)
   this.data = JSON.parse(sessionStorage.getItem('currentUser'));
   if(this.data!=null || this.data !=''){
     this.accesstoken= this.data.accesstoken;
   }
 if(this.uploadfilesize < 5000000){
  //  (this.uploadfileForm.get('terms_and_conditions').value)
    if(this.uploadfileForm.valid && this.uploadfileForm.get('terms_and_conditions').value !=false)
    {
      if( this.uploadfileForm.get('privacy_policy').value !=false){
     this.firstcheck = this.uploadfileForm.get('terms_and_conditions').value;
    //  (this.firstcheck)
     if(this.firstcheck == true) {
       this.checkansterms = 'Accepted';
      //  ('ghdfgsdf')
      //  (this.checkansterms)
     }
     this.firstcheckpolicy = this.uploadfileForm.get('privacy_policy').value;
     if(this.firstcheckpolicy == true) {
      this.checkanspolicy = 'Accepted';
      // ('ghdfgsdf')
      // (this.checkanspolicy)
    }
      this.submitted2 = false;
      this.msgError = false;
      const formData = new FormData();
      formData.append('file',this.uploadfileForm.get('bank_account_letter').value);
      formData.append('bank_account_letter',this.uploadfileForm.value.bank_account_letter);
      formData.append('language','ar');
      formData.append('terms_and_conditions',this.checkansterms);
      formData.append('registration_id','9'),
      formData.append('privacy_policy',this.checkanspolicy);
      formData.append('deviceType',this.deviceinfoservice.deviceinfo.deviceType);
      formData.append('browserType',this.deviceinfoservice.deviceinfo.browserType);
      formData.append('browserVersion',this.deviceinfoservice.deviceinfo.browserVersion);
      formData.append('osType',this.deviceinfoservice.deviceinfo.osType);

      formData.append('osVersion',this.deviceinfoservice.deviceinfo.osVersion);

      formData.append('deviceId	',this.deviceinfoservice.deviceinfo.deviceId);
      formData.append('iPAddress	',this.deviceinfoservice.deviceinfo.ipAdress);

      if(this.deviceinfoservice.deviceinfo.latitude =='') {
        formData.append('latitude	','NA');
        
      } else {
        formData.append('latitude	',this.deviceinfoservice.deviceinfo.latitude);
      }


      if(this.deviceinfoservice.deviceinfo.logintude =='') {
        formData.append('longitude	','NA');
        
      } else {
        formData.append('longitude	',this.deviceinfoservice.deviceinfo.logintude);
      }


    
  


      // const obj ={...this.deviceinfoservice.deviceinfo,language:'ar',
      //  terms_and_conditions:this.uploadfileForm.value.terms_and_conditions,privacy_policy:this.uploadfileForm.value.privacy_policy,registration_id:9 }
        //  (formData)
         this.spinner8 = true;
         this.spinnerfull.show();
      this.authService.uploadbankletter(formData,this.accesstoken).subscribe(response =>{
      console.log(response)

        this.data = JSON.parse(sessionStorage.getItem('currentUser'));
        if(this.data!=null || this.data !=''){
          this.accesstoken= this.data.accesstoken;
        }
       this.spinner8 = false;
        if(response.upload_documents_response == 1000){
          this.next5 = false;
          this.uploadError = true;
          this.responseuploadsucessMessgae = "Document Uploaded successfully";
          setTimeout(() => {
           
            this.uploadError = false;
            const object: any = {}
            object['FirstName']  = response.FirstName;
            object['LastName']     = response.LastName;
            object['LastLogin']    = response.LastLogin;
            object['isMobileVerified']   = response.isMobileVerified;
            object['profileStatus'] = response.profileStatus;
            object['isEmailVerified']   = response.isEmailVerified;
            object['accesstoken']   =  this.accesstoken;
            object['isPolicyAccepted']   = response.isPolicyAccepted;
            object['isBankInfoProvided']    = response.isBankInfoProvided;
            object['isInvestorInfoProvided']    = response.isInvestorInfoProvided;
            object['isTermsAccepted']  = response.isTermsAccepted;
            object['id'] = response.id
            object['iqamaId'] = response.iqamaId
            object['isBankAccountLetterUploaded'] = response.isBankAccountLetterUploaded;
            // object['redirect'] = '/auth/investorRegister';
            object['redirect']="englishwebapp";
            sessionStorage.setItem('currentUser',JSON.stringify(object))
      
            this.router.navigate(['/englishwebapp/webappmaindashboard'])
            this.spinnerfull.hide();
          }, 3000) 
        
         
      
                
        }else if(response.upload_documents_response== 1001){
          this.responseMessgae = "FAILURE";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1002){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
      
        else if(response.upload_documents_response== 1003){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1004){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1005){
           this.responseMessgae = "SOMETHING WENT WRONG";
           this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1006){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1007){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1008){
          this.responseMessgae = "SOMETHING WENT WRONG";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1009){
          this.responseMessgae = "SOMETHING WENT WRONG";    
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1010){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1011){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1012){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1013){
          this.responseMessgae = "SOMETHING WENT WRONG";   
          this.spinnerfull.hide(); 
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1014){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1015){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response==1016){
          this.responseMessgae = "SOMETHING WENT WRONG"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1040){
          this.responseMessgae = "REGISTRATION ID IS EMPTY"; 
          this.spinnerfull.hide();   
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1041){
          this.responseMessgae = "REGISTRAIION ID SHOULD BE NUMERIC";
          this.spinnerfull.hide();
      
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1042){
          this.responseMessgae = "REGISTRATION ID NOT VALID";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }else if(response.upload_documents_response== 1074){
          this.responseMessgae = "BANK ACCOUNT LETTER FILE IS EMPTY";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
  
        else if(response.upload_documents_response== 1075){
          this.responseMessgae = "BANK ACCOUNT LETTER FILE SIZE SHOULD BE LESS THAN 5MB";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        } 
        else if(response.upload_documents_response== 1076){
          this.responseMessgae = "BANK ACCOUNT LETTER FILE FORMATS ARE,PNG,JPG,PDF,XLS,XLSX";
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.upload_documents_response== 1130){
          this.responseMessgae = "TERMS AND CONDITIONS SHOULD BE ACCEPTED";   
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else if(response.upload_documents_response== 1131){
          this.responseMessgae = "PRIVACY POLICY SHOULD BE ACCEPTED";   
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
        else {
          this.responseMessgae = "SOMETHING WENT WRONG";   
          this.spinnerfull.hide();
                    this.registError = true;
                    setTimeout(() => {
                      this.registError = false;
                    }, 3000)
        }
      })
     
    }else{
      this.termsprivacy=" Please accept Privacy Policy"
      this.termsprivacyError = true;
      setTimeout(() => {
        this.termsprivacyError = false;
      }, 3000)
    }
    } else{
 
      this.termsprivacy="Please accept Terms & Conditions"
      this.termsprivacyError = true;
      setTimeout(() => {
        this.termsprivacyError = false;
      }, 3000)
    }
  }else{
    this.fileerror="Upload File Should Be Less Than 5 MB"
    
    this.fileError = true;
    setTimeout(() => {
      this.fileError = false;
    }, 3000)
  }
  }

  navigatearabic() {
    if(this.first1){
      this.token.first1=true;
      this.router.navigate(['/auth/arinvestorRegister'])
    }


  if(this.first2){
      this.token.first1=false;
      this.token.first2=true;
      this.router.navigate(['/auth/arinvestorRegister'])
    }

  if(this.first3){
      this.token.first2=false;
      this.token.first3=true;
      this.router.navigate(['/auth/arinvestorRegister'])
    }

    if(this.first4){
      this.token.first3=false;
      this.token.first4=true;
      this.router.navigate(['/auth/arinvestorRegister'])
    }

    if(this.first5){
      this.token.first4=false;
      this.token.first5=true;
      this.router.navigate(['/auth/arinvestorRegister'])
    }


  }

  downdrrow(){
    
    // ("+++++++++++++++")
    // $(".carousel").carousel("next");
    
    this.count=this.count+1;
    // (this.count)
    // (this.regstage)
    if(this.count <this.regstage){
   this.hidecoroseldown=true;
   this.hidecaroselup=true
    }else{
     // alert("down")
   this.hidecoroseldown=false;
    this.hidecaroselup=true
    this.count1=0;
    }
     }

    //  updrrow(){
    //    this.count1=this.count1+1;
    // (this.count)
    // (this.count1)
    //    (this.regstage)
    //    if(this.count1 <this.count){
    //     this.hidecaroselup=true
    //  }else{
      
    //    this.hidecaroselup=false
    //    this.hidecoroseldown=true;
    //    this.count=0;
    //  }
    //  }
    updrrow(){
      this.count1=this.count1+1;
  //  (this.count)
  //  (this.count1)
      // (this.regstage)
      if(this.count1 <this.count){
       this.hidecaroselup=true
    }else{
      // alert("up")
       this.data = JSON.parse(sessionStorage.getItem('currentUser'));
     // if(this.data !=null && this.data !=''){
       this.decdata=this.decryptData(this.data.alloworigen);
        this.regstage=this.decdata;
    //   }
      //  (this.count1)
      //  (this.regstage)
      if(this.count1 <this.regstage){
        // alert("up")
        this.hidecaroselup=true;
     }else
    {
      this.hidecaroselup=false
      this.hidecoroseldown=true;
      this.count=0;
    }
    }
    }
     resolved(captchaResponse: string) {
      // (`Resolved response token: ${captchaResponse}`);
     
    }

}
