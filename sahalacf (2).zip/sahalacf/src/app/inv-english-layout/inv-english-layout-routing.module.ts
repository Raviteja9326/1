import { Routes, RouterModule } from "@angular/router";
import { NgModule } from "@angular/core";
import { InvEnglishLayoutComponent } from './inv-english-layout.component';
import { AuthguardGuard } from '../services/authguard.guard';
import { EnwebappComponent } from '../invenglish/enwebappinvestor/enwebapp.component';
import { DashboardComponent } from '../invenglish/enwebappinvestor/dashboard/dashboard.component';

const routes: Routes = [
  {
    path: "englishwebapp",
    component: InvEnglishLayoutComponent,
    children: [
      { path: "webappdashboard", component: DashboardComponent },
        {path:'',component:EnwebappComponent,
        loadChildren:() =>import('../invenglish/enwebappinvestor/enwebapp.module').then(s=>s.EnwebappModule),}, 
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InvEnglishLayoutRoutingModule { }
