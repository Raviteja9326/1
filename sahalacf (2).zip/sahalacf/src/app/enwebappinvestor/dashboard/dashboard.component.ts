import { Component, OnInit,Inject, Optional } from '@angular/core';
import { StickyDirection } from '@angular/cdk/table';
import { DeviceDetectorService } from 'ngx-device-detector';
import { FormBuilder, FormGroup,Validators, FormGroupDirective, FormControl, NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ErrorStateMatcher } from '@angular/material/core';
import { AlertComponent } from '../alert/alert.component';
import { EventListenerFocusTrapInertStrategy } from '@angular/cdk/a11y';
import { NgxSpinnerService } from 'ngx-spinner';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, investorInfoForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = investorInfoForm && investorInfoForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol', 'status'];
 
  displayedColumns1: string[] = ['position', 'name', 'weight', 'symbol', 'status', 'product'];
  
  deviceInfo: any;
  token:any;
  recentOportunitiesList: any;
  recentOportunitiesStatus: any;
  recentOptList: any;
  loanStatusInFundingcount: any;
  loanStatusInFundingcountsum: any;
  completedLoanCount: any;
  completedLoanSum: any;
  Fundedcount: any;
  FundedSum: any;
  defaultedCount: any;
  defaultedSum: any;
  investementsEarnings: any;
  investementAmountInvested: any;
  investementsAmountReceived: any;
  investementsExpertedEarnings: any;
  investAmountAnnualROI: any;
  earnings: any;
  amountInvested: any;
  amount_Received: any;
  expectedEarnings: any;
  dashBordError: boolean;
  errorMessage: string;
  errorRecentClosedOportMessage: string;
  dashBordrecentClosedError: boolean;
  dashBordrecentOportError: boolean;
  errorRecentOpertMessage: string;
  data: any;
  ismobilealert = false;
  accesstoken: any;
  isemailverified: boolean;
  list: any;
  errmsg: string;
  msgdis: boolean;
  errmsg1: string;
  msgdis1: boolean;
  latepayment: any;
  latepaymentsum: any;
  payablecount: any;
  payablecountsum: any;
  financefullcount: any;
  financefullcountsum: any;
  constructor(private fb: FormBuilder,public dialog: MatDialog,private spinnerfull: NgxSpinnerService,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private deviceService: DeviceDetectorService) {
   
      this.detectDevice();
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      this.accesstoken = this.data.accesstoken;
   if(this.data!=null || this.data !=''){
     this.token= this.data.accesstoken;
     if(this.data.isMobileVerified =='No') {
      this.ismobilealert = true;
    }
    if(this.data.isMobileVerified =='Yes') {
      this.ismobilealert = false;
    }

    if(this.data.isEmailVerified == 'No'){
      this.isemailverified = true;
    }

   else if(this.data.isEmailVerified == 'Yes'){
      this.isemailverified = false;
    }
   }
      this.dashboardDetails();
      this.recenetClosedOpportunities();
    this.recentOportunitites();
     }

  ngOnInit(): void {
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
 
  }

dashboardDetails(){
  this.detectDevice();
  const object: any = {}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
       object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
    
     this.spinnerfull.show()
this.authService.dashBoardDetails(object,this.token).subscribe(response=>
 this.dashboardDetSubmit(response))

}
dashboardDetSubmit(response){
 
  this.spinnerfull.hide()

  if(response.Token_Status=='1119'){
   
if(response.investor_dashboard_status=='1000'){
  


  this.earnings=response.earnings;
this.amountInvested=response.amount_invested;


this.amount_Received=response.amount_received;
this.expectedEarnings=response.expected_earnings;
this.investementsEarnings=response.investments.earnings
this.investementAmountInvested=response.investments.amount_invested
this.investementsAmountReceived=response.investments.amount_received
this.investementsExpertedEarnings=response.investments.expected_earnings
this.investAmountAnnualROI=response.investments.amount_annual_roi


this.loanStatusInFundingcount=response.loan_status.In_Funding.count  
this.loanStatusInFundingcountsum=response.loan_status.In_Funding.sum

this.latepayment=response.loan_status.Late_Payment.count

this.latepaymentsum=response.loan_status.Late_Payment.sum

this.Fundedcount=response.loan_status.Acceptable.count
this.FundedSum=response.loan_status.Acceptable.sum

this.defaultedCount=response.loan_status.Stumbled_Financing.count
this.defaultedSum=response.loan_status.Stumbled_Financing.sum

this.payablecount=response.loan_status.Payable.count
this.payablecountsum=response.loan_status.Payable.sum




this.financefullcount=response.loan_status.Finances_paid_full.count
this.financefullcountsum=response.loan_status.Finances_paid_full.sum



}else if(response.investor_dashboard_status=='1002'){
  this.dashBordError = true;
  this.errorMessage = 'SOMETHING_WENT_WRONG';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1003'){
  this.dashBordError = true;
  this.errorMessage = 'BROWSER_TYPE_IS_EMPTY';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1004'){
  this.dashBordError = true;
  this.errorMessage = 'BROWSER_TYPE_LENGTH_SHOULD_BE_MAX_30';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1005'){
  this.dashBordError = true;
  this.errorMessage = 'BROWSER_VERSION_IS_EMPTY';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1006'){
  this.dashBordError = true;
  this.errorMessage = 'BROWSER_VERSION_LENGTH_SHOULD_BE_MAX_30';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1007'){
  this.dashBordError = true;
  this.errorMessage = 'OS_VERSION_IS_EMPTY';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1008'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1009'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1010'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1011'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1012'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1015'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.investor_dashboard_status=='1016'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}
  }else if(response.Token_Status=='1120'){
    this.dashBordError = true;
    this.errorMessage = 'UNAUTHORIZED';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.dashBordError = true;
    this.errorMessage = 'TOKEN_EXPIRED';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }
}

recentOportunitites(){
  const object: any = {}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
      // object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
       object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
       object['page_number'] = '0';
       object['page_size'] = '120'
this.spinnerfull.show()
       this.authService.recentOportunitiesSubmit(object,this.token).subscribe(response=>
        this.recentOportunititesSubmit(response))
}
recentOportunititesSubmit(response){
 
  this.spinnerfull.hide()
if(response.Token_Status=='1119'){

  if(response.recent_opportunities_status=='1126'){
    this.recentOptList=response.recent_opportunities_list;

  }else if(response.recent_opportunities_status=='1127'){
    this.dashBordrecentOportError = true;
    this.errorRecentOpertMessage = 'No Data Avaliable';
    setTimeout(() => {
      this.dashBordrecentOportError = false;
    }, 700000);
  }else if(response.recent_opportunities_status=='1002'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1003'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1004'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1005'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1006'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1007'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1008'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1009'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1010'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1011'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1012'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1015'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1016'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1150'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1151'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1152'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }else if(response.recent_opportunities_status=='1153'){
    this.dashBordError = true;
    this.errorMessage = '';
    setTimeout(() => {
      this.dashBordError = false;
    }, 3000);
  }
}else if(response.Token_Status=='1120'){
  this.dashBordrecentOportError = true;
  this.errorRecentOpertMessage = 'UNAUTHORIZED';
  setTimeout(() => {
    this.dashBordrecentOportError = false;
  }, 3000);
}else if(response.Token_Status=='1121'){
  this.dashBordrecentOportError = true;
  this.errorRecentOpertMessage = 'TOKEN_EXPIRED';
  setTimeout(() => {
    this.dashBordrecentOportError = false;
  }, 3000);
}








}
recenetClosedOpportunities(){
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
  object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
//   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   object['page_number'] = '0';
   object['page_size'] = '120'

this.spinnerfull.show();
   this.authService.recentClosedOportunites(object,this.token).subscribe(response=>
    this.recenetClosedOpportunitiesSubmit(response))
}
recenetClosedOpportunitiesSubmit(response){
  
  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){
if(response.recent_closed_opportunities_status=='1126'){
this.recentOportunitiesList=response.recent_closed_opportunities_list
}else if(response.recent_closed_opportunities_status=='1127'){
  this.dashBordrecentClosedError = true;
  this.errorRecentClosedOportMessage = 'No Data Avaliable';
  setTimeout(() => {
    this.dashBordrecentClosedError = false;
  }, 700000);
}else if(response.recent_closed_opportunities_status=='1002'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1003'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1004'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1005'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1006'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1007'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1008'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1009'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1010'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1011'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1012'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1015'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1016'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1150'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1151'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1152'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}else if(response.recent_closed_opportunities_status=='1153'){
  this.dashBordError = true;
  this.errorMessage = '';
  setTimeout(() => {
    this.dashBordError = false;
  }, 3000);
}
  }else if(response.Token_Status=='1120'){
    this.dashBordrecentClosedError = true;
    this.errorRecentClosedOportMessage = 'UNAUTHORIZED';
    setTimeout(() => {
      this.dashBordrecentClosedError = false;
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.dashBordrecentClosedError = true;
    this.errorRecentClosedOportMessage = 'TOKEN_EXPIRED';
    setTimeout(() => {
      this.dashBordrecentClosedError = false;
    }, 3000);
  }
}






alertmsg(val){
 
  if(val == 'Mobile') {

    const obj:any ={}



 
obj['ipAddress'] =this.deviceinfoservice.deviceinfo.ipAdress;
obj['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
obj['countryCode'] = 'SA';
obj['deviceType'] = 'Web';
obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
obj['language']= 'en';



this.spinnerfull.show();

this.authService.alertinvesmobile(obj,this.data.accesstoken).subscribe(res=>{
  
  this.spinnerfull.hide(); 
  if(res.Token_Status =='1119'){
    if(res.Verify_Mobile_Otp_Response =='1000'){
      const dialogRef = this.dialog.open(AlertComponent,   {disableClose: true,
        width: '250px', 
        data:val
      
      });

      dialogRef.afterClosed().subscribe(result =>{
      
        this.list = result;
     if(this.list == '1000'){
       this.ismobilealert = false;


       const object:any ={}

       object['FirstName']  = this.data.FirstName;
       object['LastName']     = this.data.LastName;
       object['LastLogin']    = this.data.LastLogin;
       object['redirect'] = "englishwebapp";
       object['isEmailVerified']   = this.data.isEmailVerified;
       object['accesstoken']   = this.data.accesstoken;
       object['ProfilePic'] =  this.data.ProfilePic;
       object['id']=this.data.id
       object['profileStatus']=this.data.profileStatus
       object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;
      object['isMobileVerified']  = "Yes"
       object['isPolicyAccepted']= this.data.isPolicyAccepted;
      object['isTermsAccepted'] = this.data.isTermsAccepted;
      object['profileStatus']  = this.data.profileStatus;
     
      sessionStorage.setItem('currentUser',JSON.stringify(object));
     }

      })
    
    }
  
   else if(res.Verify_Mobile_Otp_Response =='1011'){
     this.errmsg = 'SOMETHING WENT WRONG';
     this.msgdis = true;
     setTimeout(() => {
      this.msgdis = false;
     }, 3000);
   }
   else if(res.Verify_Mobile_Otp_Response =='1012'){
    this.errmsg = 'SOMETHING WENT WRONG';
    this.msgdis = true;
    setTimeout(() => {
     this.msgdis = false;
    }, 3000);
   }
    else if(res.Verify_Mobile_Otp_Response =='1015'){
      this.errmsg = 'SOMETHING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
    else if(res.Verify_Mobile_Otp_Response =='1016'){
      this.errmsg = 'SOMETHING WENT WRONG';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }
    else if(res.Verify_Mobile_Otp_Response =='1001'){
      this.errmsg = 'FAILURE';
      this.msgdis = true;
      setTimeout(() => {
       this.msgdis = false;
      }, 3000);
    }


  }

 
  if(res.Token_Status =='1120'){
    this.errmsg = 'UNAUTHORIZED';
    this.msgdis = true;
    setTimeout(() => {
     this.msgdis = false;
    }, 3000);
  }
  if(res.Token_Status =='1121'){
    this.errmsg = 'TOKEN_EXPIRED';
    this.msgdis = true;
    setTimeout(() => {
     this.msgdis = false;
    }, 3000);
  }


})
 
 
  
}


if(val == 'email') {

  const obj:any ={}




obj['ipAddress'] =this.deviceinfoservice.deviceinfo.ipAdress;
obj['latitude'] = this.deviceinfoservice.deviceinfo.latitude;
obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
obj['countryCode'] = 'SA';
obj['deviceType'] = 'Web';
obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
obj['language']= 'en';



this.spinnerfull.show();

this.authService.alertemail(obj,this.data.accesstoken).subscribe(res=>{

this.spinnerfull.hide();
if(res.Token_Status =='1119'){
  if(res.Verify_Email_Otp_Response =='1000'){
    const dialogRef = this.dialog.open(AlertComponent, { disableClose: true,
      width: '250px',
      data:val
    
    });

  dialogRef.afterClosed().subscribe(result =>{
      
        this.list = result;
     if(this.list == '1000'){
       this.isemailverified = false;


       const object:any ={}

       object['FirstName']  = this.data.FirstName;
       object['LastName']     = this.data.LastName;
       object['LastLogin']    = this.data.LastLogin;
       object['isMobileVerified']   = this.data.isMobileVerified;
       object['isEmailVerified']   = "Yes";
       object['redirect'] = "englishwebapp";
       object['accesstoken']   = this.data.accesstoken;
       object['ProfilePic'] =  this.data.ProfilePic;
       object['id']=this.data.id
       object['profileStatus']=this.data.profileStatus
       object['isInvestorInfoProvided']= this.data.isInvestorInfoProvided;
      
       object['isPolicyAccepted']= this.data.isPolicyAccepted;
      object['isTermsAccepted'] = this.data.isTermsAccepted;
      object['profileStatus']  = this.data.profileStatus;
     
      sessionStorage.setItem('currentUser',JSON.stringify(object));
     }

      })
    


  
  }


  else if(res.Verify_Email_Otp_Response =='1011'){
    this.errmsg1 = 'SOMETHING WENT WRONG';
    this.msgdis1 = true;
    setTimeout(() => {
     this.msgdis1 = false;
    }, 3000);
  }
  else if(res.Verify_Email_Otp_Response =='1012'){
   this.errmsg1 = 'SOMETHING WENT WRONG';
   this.msgdis1 = true;
   setTimeout(() => {
    this.msgdis1 = false;
   }, 3000);
  }
   else if(res.Verify_Email_Otp_Response =='1015'){
     this.errmsg1 = 'SOMETHING WENT WRONG';
     this.msgdis1 = true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
   }
   else if(res.Verify_Email_Otp_Response =='1016'){
     this.errmsg1 = 'SOMETHING WENT WRONG';
     this.msgdis1 = true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
   }
   else if(res.Verify_Email_Otp_Response =='1001'){
     this.errmsg1 = 'FAILURE';
     this.msgdis1= true;
     setTimeout(() => {
      this.msgdis1 = false;
     }, 3000);
   }

}


if(res.Token_Status =='1120'){
  this.errmsg = 'UNAUTHORIZED';
  this.msgdis = true;
  setTimeout(() => {
   this.msgdis = false;
  }, 3000);
}
if(res.Token_Status =='1121'){
  this.errmsg = 'TOKEN_EXPIRED';
  this.msgdis = true;
  setTimeout(() => {
   this.msgdis = false;
  }, 3000);
}


})



}
  }
 

}


 






 
 
  
  
 



