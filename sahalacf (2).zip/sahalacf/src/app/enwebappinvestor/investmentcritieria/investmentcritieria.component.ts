import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-investmentcritieria',
  templateUrl: './investmentcritieria.component.html',
  styleUrls: ['./investmentcritieria.component.scss']
})
export class InvestmentcritieriaComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol', 'risk', 'status1', 'action'];
  InvestementCretairaForm:FormGroup
  submitted1: boolean;
  deviceInfo: any;
  data: any;
  acesstoken: any;
  investError: boolean;
  responseMessgae: string;
  investementcretiaraList: any;
  investementCretiara: string;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,


    private http: HttpClient, private deviceService: DeviceDetectorService) {
      this.detectDevice();

      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.acesstoken= this.data.accesstoken;
      }
     }
    get g(){return this.InvestementCretairaForm.controls}
  ngOnInit(): void {
    
    this.InvestementCretairaForm=this.fb.group({
      minloantenure: ['',[Validators.required]],
      maxloantenure: ['',[Validators.required]],
 });
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    
  }
  GetInvestementCritiera(){
    this.submitted1=true;
    if(this.InvestementCretairaForm.valid){
   
      const object:any={}
      object['browser_type'] = this.deviceInfo.browser;
      object['browser_version'] = this.deviceInfo.browser_version;
      object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
      object['os_version'] = this.deviceInfo.os_version;
      object['os_type'] = this.deviceInfo.os;
      object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
      object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
      object['language'] = 'en';
       object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
       object['maxLoanTenure']=this.InvestementCretairaForm.value.maxloantenure
       object['minLoanTenure']=this.InvestementCretairaForm.value.minloantenure
       object['pageSize']='20'
       object['pageNumber'] = '0';

       this.authService.GetInvestementCrituera(object,this.acesstoken).subscribe(response=>
        this.getinvestementCriteriaResponse(response))
    }
  }
  getinvestementCriteriaResponse(response){
    
    if(response.Token_Status=='1119'){
if(response.investments_response=='1000'){
  this.InvestementCretairaForm.reset();
this.investementcretiaraList=response.investments_criteria;

}else if(response.investments_response=='1127'){
 this.investementCretiara="List Not Avaliable"
 this.investError = true;
 setTimeout(() => {
   this.investError = false;
 }, 3000)
}else if(response.investments_response=='1151'){

}else if(response.investments_response=='1152'){

}else if(response.investments_response=='1153'){

}else if(response.investments_response=='1120'){

}else if(response.investments_response=='1002'){

}else if(response.investments_response=='1003'){

}else if(response.investments_response=='1004'){

}else if(response.investments_response=='1005'){

}else if(response.investments_response=='1006'){

}else if(response.investments_response=='1007'){

}else if(response.investments_response=='1008'){

}else if(response.investments_response=='1009'){

}else if(response.investments_response=='1010'){

}else if(response.investments_response=='1011'){

}else if(response.investments_response=='1012'){

}
    }else if(response.Token_Status=='1120'){
      this.responseMessgae = "UNAUTHORIZED";
      
      this.investError = true;
      setTimeout(() => {
        this.investError = false;
      }, 3000)
    }else if(response.Token_Status=='1121'){
      this.responseMessgae = "TOKEN_EXPIRED";
      
      this.investError = true;
      setTimeout(() => {
        this.investError = false;
      }, 3000)
    }
  }
}
