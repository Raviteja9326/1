import { Component, OnInit, Inject, Optional } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { ProgressBarMode } from '@angular/material/progress-bar';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from '@angular/common/http';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { style } from '@angular/animations';
declare var Fingerprint2: any;








@Component({
  selector: 'app-opportunitieslist',
  templateUrl: './opportunitieslist.component.html',
  styleUrls: ['./opportunitieslist.component.scss']
})


export class OpportunitieslistComponent implements OnInit {

  displayedColumns:any = [];
  dataSource:any  = []
  color: ThemePalette = 'primary';
  mode: ProgressBarMode = 'determinate';
  value = 50;
  oppdata = [];
  bufferValue = 75;
  data: any;
  acesstoken: any;
  deviceInfo: any;
  getDeviceId: any;
  deviceId: any;
  ipAddress: any;
  investform:FormGroup;
  geolocationPosition: object;
  longitude: any;
  latitude: any;
  tablepage = true;
  idpage = false;
  tabledata: any;
  errdis: string;
  display: boolean;
  loanid: any;
  loanAmount: any;
  fundedAmount: any;
  loandate: any;
  loantenure: any;
  issueInvoice: any;
  invoiceDate: any;
  industryType: any;
  companyName: any;
  compyoe: any;
  noEmp: any;
  compTurn: any;
  city: any;
  website: any;
  singleId: any;
  fundpercent: any;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private deviceService: DeviceDetectorService, private http:HttpClient, public dialog: MatDialog) {



    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.acesstoken= this.data.accesstoken;
    }


   


  }

  showPosition(position) {
    if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
      this.latitude = position.coords.latitude;
      this.longitude = position.coords.longitude;
     
    }
  }

  ngOnInit(): void {

    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
    
    this.getallopportunities();
    });

this.displayedColumns =['loan_id','amount','tenure','annual_roi','loan_status']




    new Fingerprint2().get((components) => {

     
     
    this.deviceId = components
    this.getallopportunities();
    
    });


    this.geolocationPosition = {};
    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
        position => {
          this.geolocationPosition = position;
     
          this.showPosition(position);
        }
      );
    }


  
    this.detectDevice();
  
    
  }


  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
   
  }

getallopportunities() {

//  console.log(this.data.accesstoken)

const object:any = {}

  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = "183.82.100.179";
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.longitude;
  object['latitude'] =  this.latitude;
  object['language'] = 'en';
  object['device_id'] =  this.deviceId
 // object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
  object['page_number'] = '0'
  object['page_size'] = '1000'
   

    
   

this.authService.getallopportunities(this.data.accesstoken,object).subscribe(res =>{
  

  
if(res.Token_Status == '1119') {

  if(res.all_opportunities_status == '1126') {
    this.tabledata = res.all_opportunities_list
    this.dataSource = this.tabledata
  } 

  if(res.all_opportunities_status == '1127') {
    this.tabledata = []
    this.dataSource = this.tabledata

this.display  = true
    this.errdis = 'No Data Available'
    setTimeout(() => {
      this.display = false
    }, 5000000);
  }
  
  else if(res.all_opportunities_status == '1002') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }
  else if(res.all_opportunities_status == '1003') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1004') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1005') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1006') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1007') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1008') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1009') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1010') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1011') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1012') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1013') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1014') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1015') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1016') {

    this.display = true
    this.errdis ='SOME THING WENT WRONG'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1150') {

    this.display = true
    this.errdis ='PAGE NUMBER IS EMPTY'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1151') {

    this.display = true
    this.errdis ='PAGE NUMBER SHOULD BE DIGITS'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }

  else if(res.all_opportunities_status == '1152') {

    this.display = true
    this.errdis ='PAGE SIZE IS EMPTY'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }
  
  else if(res.all_opportunities_status == '1153') {

    this.display = true
    this.errdis ='PAGE SIZE SHOULD BE DIGITS'
    setTimeout(() => {
      this.display = false
    }, 3000);
  }


}


else if(res.Token_Status == '1120') {


  this.display = true
     this.errdis ='UNAUTHORIZED'
     setTimeout(() => {
       this.display = false
     }, 3000);
   }
   else if(res.Token_Status == '1121') {


    this.display = true
       this.errdis ='TOKEN EXPIRED'
       setTimeout(() => {
         this.display = false
       }, 3000);
     }

     else  {


      this.display = true
         this.errdis ='SOME THING WENT WRONG'
         setTimeout(() => {
           this.display = false
         }, 3000);
       }

})



}

back() {
  this.tablepage = true;
  this.idpage = false;
}






getparticulardata(val) {


  this.tablepage = false;
  this.idpage = true;

  

  this.loanid = val.loan_id
   


  
  

  this.loanAmount = val.amount
   

  this.fundedAmount = val.funded_amount
   
this.fundpercent = val.fundingPercent

  this.loandate = val.loan_published_date
  

  this.loantenure = val.tenure

  this.issueInvoice =val.issued_invoice_for
  this.invoiceDate = val.invoice_date
  

  this.industryType = val.industry_type

  
this.companyName = val.company_name

this.compyoe = val.company_years_of_exp

this.noEmp = val.number_of_employees

this.compTurn = val.company_turnover

this.city = val.company_city

this.website = val.company_website




}

invest() {

 
  const dialogRef = this.dialog.open(DeleteComponent,  {disableClose: true,
    width: '450px',
    data: this.loanid 

  });
  dialogRef.afterClosed().subscribe(result => {
    
    


  });
 
}

}



/////////////invest dialog


@Component({
  
  selector: 'app-delete',
  template: `

<form [formGroup]="investform">

  <div class="row">
  <div class="col-lg-12">
<div class="row amountrow" style="padding-left: 15px;">
<div class="col-lg-6">
Enter the invest Amount
</div>
<div class="col-lg-6 amount">
<input class="form-control form-control-sm"  formControlName="investamount"  (input)="amount($event.target.value)"   type="text" placeholder="Enter the Amount" 
[ngClass]="{ 'is-invalid': submittedinvest && o.investamount.errors }">
<div *ngIf="submittedinvest && o.investamount.errors" class="invalid-feedback marginrequired">
<div *ngIf="o.investamount.errors.required"> Invest Amount  is
  Required</div>
  </div>
</div>
</div>
<div class="error"  *ngIf="display"> {{errdis}}</div>
<div class="row" style="margin-top: 11%;">
<div class="col-lg-4">

</div>
<div class="col-lg-4">
<button type="button" class="btn btn-success"  (click)="investammount()" >Invest&nbsp;&nbsp;{{btnammount}}</button>
</div>
<div class="col-lg-4">

</div>
</div>
</div>
</div>

</form>

  `,
  styleUrls: ['./opportunitieslist.component.scss']




})
export class DeleteComponent implements OnInit {

  id;
  user: any;
  accessToken: any;
  investform:FormGroup;
  listError: boolean;
  sucessMessage: string;
  errorMessage: string;
  makercheckerlist: any;
  submittedinvest = false;
  ipAddress: any;
  geolocationPosition:object;
  data: any;
  latitude: any;
  longitude: any;
  btnammount: any;
  display: boolean;
  errdis: string;
  loanid: UsersData;

  constructor(private fb:FormBuilder,private http:HttpClient,private auth:AuthService,
    public dialogRef: MatDialogRef<DeleteComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA)  public dat: UsersData
  ) {


    this.loanid = dat



    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accessToken= this.data.accesstoken;
  }

    

  }


  amount(val) {
    

    this.btnammount = val

  }


  get o(){return this.investform.controls}


  ngOnInit() {
    

    this.http.get('https://jsonip.com').subscribe((geoLocationResponse: any) => {
      this.ipAddress = geoLocationResponse.ip;
   
   
    });



    this.geolocationPosition = {};
    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
        position => {
          this.geolocationPosition = position;
    //  this.  investammount();
          this.showPosition(position);
        }
      );
    }

    
   this.investform = this.fb.group({
    investamount:['',Validators.required]
   })

  }

showPosition(position) {
  if (!(Object.entries(position).length === 0 && position.constructor === Object)) {
    this.latitude = position.coords.latitude;
    this.longitude = position.coords.longitude;
   
  }
}




  onNoClick() {
    this.dialogRef.close();
  }


  investammount() {
    this.submittedinvest = true;

    if(this.investform.valid){

const obj:any = {}


obj['amount'] =this.investform.value.investamount;
obj['iPAddress'] = this.ipAddress;
obj['longitude'] = this.longitude;
obj['latitude'] = this.latitude;
obj['loanId'] = this.loanid



this.auth.investamount(this.data.accesstoken,obj).subscribe(res =>{
  


  if(res.Token_Status == '1119') {
    if(res.profile_status == '1197') {
      if(res.investment_response == '1001') {

        this.display = true;
        this.errdis ='PROFILE STATUS PENDING'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
      }
    }
    if(res.profile_status == '1196') {

      if(res.balance_status == '1199') {
      if(res.investment_response == '1001') {

        this.display = true;
        this.errdis ='FAILURE'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
        }
      }
    }

   
    if(res.profile_status == '1196') {

      if(res.balance_status == '1199') {
      if(res.investment_response == '1000') {

const obj :any = {}

obj['FirstName'] = this.data.FirstName;
obj['LastName'] = this.data.LastName;
obj['LastLogin'] = this.data.LastLogin;
obj['accesstoken'] = this.data.accesstoken;
obj['id'] = this.data.id;
obj['isBankInfoProvided'] = this.data.isBankInfoProvided;
obj['isEmailVerified'] = this.data.isEmailVerified;
obj['isInvestorInfoProvided'] = this.data.isInvestorInfoProvided;
obj['isMobileVerified'] = this.data.isMobileVerified;
obj['isPolicyAccepted'] = this.data.isPolicyAccepted;
obj['isTermsAccepted'] = this.data.isTermsAccepted;
obj['profileStatus'] = this.data.profileStatus;
obj['redirect'] = this.data.redirect;
obj['balanceAmount'] = this.investform.value.investamount


sessionStorage.setItem('currentUser',JSON.stringify(obj))


        this.display = true;
        this.errdis ='SUCCESSFULLY AMOUNT INVESTED'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
        }

      






      }
    }

    
   
      if(res.investment_response == '1203') {
  
  
  
        this.display = true;
        this.errdis ='BALANCE SHOULD BE LESS THAN 10000 SAR'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
      }
  
      
  
      if(res.investment_response == '1211') {
  
  
  
        this.display = true;
        this.errdis ='INVEST AMOUNT IS LESS THAN OR EQUAL TO 10 PERCENT OF LOAN AMOUNT UPTO 10000SAR'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
      }
  
  
    
 




    if(res.profile_status == '1196') {

      if(res.balance_status == '1198') {


      if(res.investment_response == '1001') {

        this.display = true;
        this.errdis ='INSUFFICIENT BALANCE'
        setTimeout(() => {
          this.display = false
          this.dialogRef.close()
        }, 3000);
        }
      }
    }


  }



  else if(res.Token_Status == '1120') {


    this.display = true
       this.errdis ='UNAUTHORIZED'
       setTimeout(() => {
         this.display = false
         this.dialogRef.close()
       }, 3000);
     }
     else if(res.Token_Status == '1121') {
  
  
      this.display = true
         this.errdis ='TOKEN EXPIRED'
         setTimeout(() => {
           this.display = false
           this.dialogRef.close()
         }, 3000);
       }
  
       else  {
  
  
        this.display = true
           this.errdis ='حدث خطا ما'
           setTimeout(() => {
             this.display = false
             this.dialogRef.close()
           }, 3000);
         }
  
})
     
    }
  }

 
}




export interface UsersData {
 
  id: number;
}
