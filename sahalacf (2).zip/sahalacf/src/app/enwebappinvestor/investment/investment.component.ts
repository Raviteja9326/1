import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-investment',
  templateUrl: './investment.component.html',
  styleUrls: ['./investment.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class InvestmentComponent implements OnInit {
  displayedColumns: any = []
  dataSource;
  deviceInfo: any;
  investementsError: boolean;
  errorMessage: string;
  investorsList: any;
  data: any;
  acesstoken: any;
  investementError: boolean;
  accesstoken: any;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private spinnerfull: NgxSpinnerService,
    private deviceService: DeviceDetectorService) {

      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      this.accesstoken = this.data.accesstoken;
   if(this.data!=null || this.data !=''){
     this.accesstoken = this.data.accesstoken;
   }
      this.GetInvestements();
     } 

  ngOnInit(): void {

    this.displayedColumns = ['LoanApplication', 'Date', 'Amount', 'LoanTensure', 'ROI', 'LoanStatus'];
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    
    
  }

 
  GetInvestements(){
    this. detectDevice();
    const object: any = {}
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
    object['pageNumber'] = '0'
    object['pageSize'] = '100'
 
  this.spinnerfull.show()
   this.authService.getInvestements(object,this.accesstoken ).subscribe(response=>
    this.getInvestementsResponse(response)
    )
  }
  
  getInvestementsResponse(response){
   
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){


this.investorsList=response.investers_list;

this.dataSource = this.investorsList
      }
      
      if(response.Token_Status=='1119'){
      
       if(response.investers_response=='1127'){
        this.investorsList = [];
        this.dataSource = this.investorsList

        this.investementError = true;
        this.errorMessage = 'No Data Available';
        setTimeout(() => {
          this.investementError = false;
        }, 3000000);
      }else if(response.investers_response=='1002'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1003'){
        
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

      }else if(response.investers_response=='1004'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1005'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1006'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1007'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1008'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1009'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1010'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1011'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1012'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1013'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1015'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1016'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1150'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }else if(response.investers_response=='1151'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }else if(response.investers_response=='1152'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }else if(response.investers_response=='1153'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

      }
      
    }else if(response.Token_Status=='1120'){
       this.investementsError = true;
      this.errorMessage = 'UNAUTHORIZED';
      setTimeout(() => {
        this.investementsError = false;
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.investementsError = true;
      this.errorMessage = 'TOKEN_EXPIRED';
      setTimeout(() => {
        this.investementsError = false;
      }, 3000);
    }
  }

}
