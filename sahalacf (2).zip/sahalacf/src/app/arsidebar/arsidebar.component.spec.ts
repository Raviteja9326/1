import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArsidebarComponent } from './arsidebar.component';

describe('ArsidebarComponent', () => {
  let component: ArsidebarComponent;
  let fixture: ComponentFixture<ArsidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArsidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArsidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
