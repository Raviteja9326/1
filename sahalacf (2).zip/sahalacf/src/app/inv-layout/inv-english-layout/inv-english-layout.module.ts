import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InvEnglishLayoutComponent } from './inv-english-layout.component';
import { InvEnglishLayoutRoutingModule } from './inv-english-layout-routing.module';
import { MatIconModule } from '@angular/material/icon';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatTableModule } from '@angular/material/table';
import { HttpClientModule } from '@angular/common/http'; 
import { MatCardModule } from '@angular/material/card';
import { MatRadioModule } from '@angular/material/radio';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { NgxHijriGregorianDatepickerModule } from 'ngx-hijri-gregorian-datepicker';
import { InvengsidenavComponent } from 'src/app/invenglish/invengsidenav/invengsidenav.component';
import { InvengheaderComponent } from 'src/app/invenglish/invengheader/invengheader.component';
import { DashboardComponent } from 'src/app/invenglish/enwebappinvestor/dashboard/dashboard.component';
import { EnwebappComponent } from 'src/app/invenglish/enwebappinvestor/enwebapp.component';
import { AlertComponent } from 'src/app/invenglish/enwebappinvestor/alert/alert.component';
import { UserIdleModule } from 'angular-user-idle';

@NgModule({
  declarations: [
    InvengsidenavComponent,
    InvengheaderComponent,
    DashboardComponent,
    InvEnglishLayoutComponent,
    EnwebappComponent
    
  ],
  imports: [
    InvEnglishLayoutRoutingModule,
    NgbModule,
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule, 
    NgxSpinnerModule,
    MatTableModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatCardModule,
    MatRadioModule,
    UserIdleModule.forRoot({idle: 180, timeout: 3}),
FormsModule,
MatDividerModule,
MatFormFieldModule,
MatInputModule ,
FormsModule,
MatIconModule,
MatDialogModule,
MatButtonModule,
    NgxHijriGregorianDatepickerModule
,
   
   
    NgbModule
  ],
  providers: [],
  entryComponents:[
    AlertComponent,
    // DeleteComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class InvEnglishLayoutModule { }
