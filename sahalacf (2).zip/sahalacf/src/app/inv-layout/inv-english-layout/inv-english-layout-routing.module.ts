import { Routes, RouterModule } from "@angular/router";
import { NgModule } from "@angular/core";
import { InvEnglishLayoutComponent } from './inv-english-layout.component';
import { DashboardComponent } from 'src/app/invenglish/enwebappinvestor/dashboard/dashboard.component';
import { EnwebappComponent } from 'src/app/invenglish/enwebappinvestor/enwebapp.component';

const routes: Routes = [
  {
    path: "englishwebapp",
    component: InvEnglishLayoutComponent,
    children: [
      { path: "webappdashboard", component: DashboardComponent },
        {path:'',component:EnwebappComponent,
        loadChildren:() =>import('src/app/invenglish/enwebappinvestor/enwebapp.module').then(s=>s.EnwebappModule),}, 
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InvEnglishLayoutRoutingModule { }
