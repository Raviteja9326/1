import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatIconModule } from '@angular/material/icon'; 
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatTableModule } from '@angular/material/table';
import { HttpClientModule } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatRadioModule } from '@angular/material/radio';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { NgxHijriGregorianDatepickerModule } from 'ngx-hijri-gregorian-datepicker';
import { ArwithdrawdialogComponent } from '../../arwithdrawdialog/arwithdrawdialog.component';
import { AuthService } from '../../services/auth.service';
import { DeviceinfoserviceService } from '../../shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AuthguardGuard } from '../../services/authguard.guard';
import {  DeleteComponent } from 'src/app/smearabic/arabicsmwwebapp/ardash/ardash.component';
import { AralertComponent } from 'src/app/smearabic/arabicsmwwebapp/aralert/aralert.component';
import { InvarabicsidenavComponent } from 'src/app/invarabic/invarabicsidenav/invarabicsidenav.component';
import { HeaderarbicComponent } from 'src/app/invarabic/headerarbic/headerarbic.component';
import { DashboardComponent } from 'src/app/invarabic/arabicWebapp/dashboard/dashboard.component';
import { InvArabicLayoutComponent } from './inv-arabic-layout.component';
import { InvArabicLayoutRoutingModule } from './inv-arabic-layout-routing.module';
import { UserIdleModule } from 'angular-user-idle';

@NgModule({
  declarations: [
    InvarabicsidenavComponent,
    HeaderarbicComponent,
    DashboardComponent,
    InvArabicLayoutComponent
  ],
  imports: [
    InvArabicLayoutRoutingModule,
    NgbModule,
    CommonModule,
    RouterModule, 
    FormsModule,
    ReactiveFormsModule,
    MatIconModule, 
    NgxSpinnerModule,
    MatTableModule,
    HttpClientModule,
    ReactiveFormsModule,
    UserIdleModule.forRoot({idle: 180, timeout: 3}),
    MatCardModule,
    MatRadioModule,    
    FormsModule,
    MatDividerModule,
    MatFormFieldModule,
    MatInputModule ,
    FormsModule,
    MatIconModule,
    MatDialogModule,
    MatButtonModule,
    NgxHijriGregorianDatepickerModule,
    NgbModule
  ],

  providers: [
    AuthguardGuard,
    AuthService,
    DeviceinfoserviceService,
    DeviceDetectorService
  ],

  entryComponents:[
    ArwithdrawdialogComponent,
    AralertComponent,
    DeleteComponent
  ],
  
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class InvArabicLayoutModule { }
