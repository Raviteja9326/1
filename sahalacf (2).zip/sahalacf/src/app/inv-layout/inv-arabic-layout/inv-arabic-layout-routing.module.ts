import { Routes, RouterModule } from "@angular/router";
import { NgModule } from "@angular/core";
import {  InvArabicLayoutComponent } from './inv-arabic-layout.component';
import { DashboardComponent } from 'src/app/invarabic/arabicWebapp/dashboard/dashboard.component';
import { ArabicComponent } from 'src/app/invarabic/arabicWebapp/arabic.component';

const routes: Routes = [
  {
    path: "arabicwebapp",
    component: InvArabicLayoutComponent,
    children: [
      {path:'webappdashboard',component:DashboardComponent},
        {path:'',component:ArabicComponent,
        loadChildren:() =>import('src/app/invarabic/arabicWebapp/arabic.module').then(a=>a.ArabicModule)}, 
    ]
  },
];




@NgModule({
  imports: [RouterModule.forChild(routes),],
  exports: [RouterModule],
})
export class InvArabicLayoutRoutingModule { }
