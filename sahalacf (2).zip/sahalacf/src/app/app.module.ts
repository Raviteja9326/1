import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatTableComponent } from './mat-table/mat-table.component';
import {MatTableModule} from '@angular/material/table';
import { MaindashboardComponent } from './maindashboard/maindashboard.component';
import { MatIconModule } from '@angular/material/icon';
import { WildcardComponent } from './wildcard/wildcard.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { AuthguardGuard } from './services/authguard.guard';
import { AuthService } from './services/auth.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DeviceinfoserviceService } from './shared/deviceinfoservice.service';
import { HttpClientModule } from '@angular/common/http';
import { NgxHijriGregorianDatepickerModule } from 'ngx-hijri-gregorian-datepicker';
import { MainloginComponent } from './mainlogin/mainlogin.component';
import { MainarloginComponent } from './mainarlogin/mainarlogin.component';
import {MatCardModule} from '@angular/material/card';
import {MatDividerModule} from '@angular/material/divider';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';
import {MatRadioModule} from '@angular/material/radio';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { WithrawdialogeComponent } from './withrawdialoge/withrawdialoge.component';
import { ArwithdrawdialogComponent } from './arwithdrawdialog/arwithdrawdialog.component';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { EnglishLayoutModule } from './sme-layout/english/english-layout.module';
import { ArabicLayoutModule } from './sme-layout/arabic/arabic-layout.module';
import { InvEnglishLayoutModule } from './inv-layout/inv-english-layout/inv-english-layout.module';
import { InvArabicLayoutModule } from './inv-layout/inv-arabic-layout/inv-arabic-layout.module';




@NgModule({
  declarations: [
    AppComponent,
    MatTableComponent,
    WithrawdialogeComponent,
    ArwithdrawdialogComponent,
    MaindashboardComponent,
    WildcardComponent,
    MainloginComponent,
    MainarloginComponent,
    
    
  ],
  imports: [
    ArabicLayoutModule,
    InvEnglishLayoutModule,
    InvArabicLayoutModule,
    EnglishLayoutModule,
    BrowserModule,
    AppRoutingModule,
    MatIconModule, 
    NgxSpinnerModule,
    MatTableModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatRadioModule, 
    FormsModule,
    MatDividerModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    FormsModule,
    MatIconModule,
    MatDialogModule,
    MatButtonModule,
    NgxHijriGregorianDatepickerModule,
    NgbModule
  ],


  entryComponents: [
    WithrawdialogeComponent,
    ArwithdrawdialogComponent,
  ],

  providers: [
    AuthguardGuard,
    AuthService,
    DeviceinfoserviceService,
    DeviceDetectorService
  ],

  bootstrap: [AppComponent],

  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
