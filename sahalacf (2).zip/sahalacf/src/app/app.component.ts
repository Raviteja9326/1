import { Component } from '@angular/core';
import { Router, RouteConfigLoadStart, RouteReuseStrategy, RoutesRecognized, RouteConfigLoadEnd, ActivatedRoute, NavigationEnd } from '@angular/router';
import { BnNgIdleService } from 'bn-ng-idle'; // import it to your component

import { MatDialog } from '@angular/material/dialog';
import { UnauthorizedComponent } from './shared/unauthorized/unauthorized.component';
import { SmeborrowerService } from './services/smeborrower.service';
import { interval, Subscription } from 'rxjs';
import { map } from 'rxjs/operators'
import { RefreshtokenService } from './services/refreshtoken.service';
import { TermsandconditionsComponent } from './shared/termsandconditions/termsandconditions.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'sahlahcf';
  data: any;
  accesstoken: any;
   subscription:Subscription;
  user: any;
  urlnavigate: any;
  stopsess: any;
  time:any;
  sesstop: any;
  list: any;
  constructor(private router: Router,private bnIdle: BnNgIdleService, public dialog: MatDialog,private token:RefreshtokenService,
    private sme :SmeborrowerService,
    route:ActivatedRoute) {

// this.dialog.open(TermsandconditionsComponent,{ disableClose: true,
//           width: '450px',
         
        
        
//         })
      
      const source = interval(300000);
      const text = 'Your Text Here';
     
     console.log('refreshcalll')
      
       
          this.subscription = source.subscribe(val =>{
                
            
            this.list = JSON.parse(sessionStorage.getItem('currentUser'))
            if(this.list !=null){
              console.log(this.list.accesstoken);
              this.accesstoken = this.list.accesstoken
             this.callingrefreshtoken();
            }
            
         console.log('refreshtoken')
          }
            );
  

          this.token.currentMessage
          .subscribe(mesaage =>{
           
            this.data = mesaage
            console.log(this.data)

            if(this.data != 'default message') {
              console.log('going inside')
             // this.getsessiontime()
            
                 this.accesstoken = this.data.token
                  
                        console.log(this.accesstoken) 
  
  
                   
  
                    
            }
          })


       


       



          // this.token.sessiontime.subscribe(r =>{
          //   this.time = r
          //   if(this.time == true) {
          //     console.log('refresh should not called')
  
            
  
          //   }
          // })
      



    }
  

  ngOnInit() {




//this.scroll()
console.log("+++++++++++++++++wwww")



//     this.user = JSON.parse(sessionStorage.getItem('currentUser'))
// if(this.user !='' && this.user !=null){
//    if(this.user.accesstoken != null){

    //this.getsessiontime()
      
  //  }
  // }
  }
 
 
  

  callingrefreshtoken(){
     console.log('mansarefresh')
     
    this.user = JSON.parse(sessionStorage.getItem('currentUser'))

 

     this.sme.refreshToken(this.accesstoken).subscribe(response=>{
       console.log(response)

       const object:any ={}

       object['FirstName']  = this.user.FirstName;
       object['LastName']     = this.user.LastName;
       object['LastLogin']    = this.user.LastLogin;
       object['isMobileVerified']   = this.user.isMobileVerified;
       object['isEmailVerified']   = this.user.isEmailVerified;
       object['accesstoken']   = response.token;
       object['ProfilePic'] = this.user.ProfilePic;
       object['id']=this.user.id
       object['profileStatus']=this.user.profileStatus;
       if(this.user.isCompnayInformationProvided   &&  this.user.isDcoumentsInformationProvided) {
        object['redirect'] = this.user.redirect;
        object['isBankInformationProvided']    = this.user.isBankInformationProvided;
        object['isCompnayInformationProvided']    = this.user.isCompnayInformationProvided;
        object['isDcoumentsInformationProvided']   = this.user.isDcoumentsInformationProvided;
        object['isShareHolderInformationProvided'] = this.user.isShareHolderInformationProvided;
        object['isPolicyAccepted'] = this.user.isPolicyAccepted;
        object['isTermsAccepted'] = this.user.isTermsAccepted;
       }
 
       else {
        object['redirect'] = this.user.redirect;
        object['isPolicyAccepted']  = this.user.isPolicyAccepted;
        object['isBankInfoProvided']   = this.user.isBankInfoProvided;
        object['isInvestorInfoProvided']  = this.user.isInvestorInfoProvided;
        object['isTermsAccepted']  = this.user.isTermsAccepted;
        object['isBankAccountLetterUploaded'] = this.user.isBankAccountLetterUploaded;
       }


       sessionStorage.setItem('currentUser',JSON.stringify(object))

       this.token.changeMessage(response)

       
       this.token.changeMessagereg(response)

     })
   }


// getsessiontime() {
 
//  this.sesstop =  this.bnIdle.startWatching(60).subscribe(res=> {
//     if (res) {

//       if(res == true) {
//        this.subscription.unsubscribe();
//       console.log('navyaidle');
//      this.dialog.openDialogs.pop();
//      this.dialog.openDialogs.length==0
//      console.log(this.dialog.openDialogs.length==0)
//     if(this.dialog.openDialogs.length==0){
//       const dialogRef = this.dialog.open(UnauthorizedComponent,{ disableClose: true,
//         width: '250px',
//         backdropClass: 'backdropBackground'
      
//       });
//     }
//       }
//     }
//   });

// } 
}