import { Component, OnInit, ElementRef, Inject } from '@angular/core';
import { ROUTES } from "../invengsidenav/invengsidenav.component";
import {
  Location,
  LocationStrategy,
  PathLocationStrategy
} from "@angular/common";
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { WithrawdialogeComponent } from 'src/app/withrawdialoge/withrawdialoge.component';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { DocumentComponent } from '../enwebappinvestor/dashboard/dashboard.component';
declare var $ : any
@Component({
  selector: 'app-invengheader',
  templateUrl: './invengheader.component.html',
  styleUrls: ['./invengheader.component.scss']
})
export class InvengheaderComponent implements OnInit { 
  panelOpenState = false;
  user: any;
  name: any;
  data:any;
  registrationid: any;
  profileStatus: string;
  balance: any;
  withdrawUser: any;
  profilestatuserrmsg:any
  mobile_menu_visible: number;
  sidebarVisible: boolean;
  listTitles: any[];
  toggleButton: Element;
  userbalance: any;
  balanceprofile :any
  accesstoken: any;
  deviceInfo: any;
  errormsg: string;
  sessiondata: any;
  constructor(public dialog: MatDialog,private router:Router,private auth:AuthService, private element: ElementRef,
    private token:RefreshtokenService,
    private deviceinfoservice:DeviceinfoserviceService,private deviceService:DeviceDetectorService) {
   this.user = JSON.parse(sessionStorage.getItem('currentUser'))
   
   this.accesstoken = this.user.accesstoken;
    this.name=this.user.FirstName
    this.registrationid=this.user.id

    this.detectDevice()
    // if( this.user.profileStatus=='1197'){
    //   this.profileStatus="Pending for Approval"
    //    }else if( this.user.profileStatus=='1196'){
    //     this.profileStatus="Approved"
    //      }

    this.token.balanceammount.subscribe(balancedetails =>{
      console.log(balancedetails)
      sessionStorage.setItem('currentUserbalance',JSON.stringify(balancedetails))
      this.balanceprofile = balancedetails
      this.balance = this.balanceprofile.balance

 if( this.balanceprofile.profile_status=='1197'){
      this.profileStatus="Pending for Approval"
       }else if( this.balanceprofile.profile_status=='1196'){
        this.profileStatus="Approved"
         }
       
    })
   
 
   } 

   ngOnInit(): void {

    this.listTitles = ROUTES.filter(listTitle => listTitle);
    const navbar: HTMLElement = this.element.nativeElement;
    this.toggleButton = navbar.getElementsByClassName("navbar-toggler")[0];
    this.router.events.subscribe(() => {
      this.sidebarClose();
      // tslint:disable-next-line:prefer-const
      var $layer: any = document.getElementsByClassName("close-layer")[0];
      if ($layer) {
        $layer.remove();
        this.mobile_menu_visible = 0;
      }
    });
   
        $('.nav-section').addClass('expand');
         $('.nav-section ul li a').on('click', function () {
                $('.nav-section ul .active').removeClass('active');
               $(this).addClass('active');
         });
        $('.menu-icon').click(function () {
         
          $('.nav-section').addClass('expand');
          $('.main-section').toggleClass('expand');
    
        });
         $('.nav-section ul li a').on('click', function () {
          $('.nav-section ul .active').removeClass('active');
         $(this).addClass('active');
      });
    
      $("#menu-close").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    
      });
      $("#sidebar-wrapper .dashboard ").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    
      });
    
    
      $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
      });
    
      
      } 

      
      
  sidebarOpen() {
    const toggleButton = this.toggleButton;
    const body = document.getElementsByTagName("body")[0];
    setTimeout(function () {
      toggleButton.classList.add("toggled");
    }, 500);

    body.classList.add("nav-open");

    this.sidebarVisible = true;
  }
  sidebarClose() {
    const body = document.getElementsByTagName("body")[0];
    this.toggleButton.classList.remove("toggled");
    this.sidebarVisible = false;
    body.classList.remove("nav-open");
  }
  sidebarToggle() {
    // const toggleButton = this.toggleButton;
    // const body = document.getElementsByTagName('body')[0];
    // tslint:disable-next-line:prefer-const
    var $toggle = document.getElementsByClassName("navbar-toggler")[0];

    if (this.sidebarVisible === false) {
      this.sidebarOpen();
    } else {
      this.sidebarClose();
    }
    const body = document.getElementsByTagName("body")[0];

    if (this.mobile_menu_visible === 1) {
      // $('html').removeClass('nav-open');
      body.classList.remove("nav-open");
      // tslint:disable-next-line: no-use-before-declare
      if ($layer) {
        // tslint:disable-next-line: no-use-before-declare
        $layer.remove();
      }
      setTimeout(function () {
        $toggle.classList.remove("toggled");
      }, 400);

      this.mobile_menu_visible = 0;
    } else {
      setTimeout(function () {
        $toggle.classList.add("toggled");
      }, 430);

      // tslint:disable-next-line:prefer-const
      var $layer = document.createElement("div");
      $layer.setAttribute("class", "close-layer");

      if (body.querySelectorAll(".main-panel")) {
        document.getElementsByClassName("main-panel")[0].appendChild($layer);
      } else if (body.classList.contains("off-canvas-sidebar")) {
        document
          .getElementsByClassName("wrapper-full-page")[0]
          .appendChild($layer);
      }

      setTimeout(function () {
        $layer.classList.add("visible");
      }, 100);

      $layer.onclick = function () {
        // asign a function
        body.classList.remove("nav-open");
        this.mobile_menu_visible = 0;
        $layer.classList.remove("visible");
        setTimeout(function () {
          $layer.remove();
          $toggle.classList.remove("toggled");
        }, 400);
      }.bind(this);

      body.classList.add("nav-open");
      this.mobile_menu_visible = 1;
    }
  }




  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    console.log(this.deviceInfo)
  }


      reqwrdialogfun(){

        this.withdrawUser =JSON.parse(sessionStorage.getItem('currentUserbalance'))

        this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))


        if(this.sessiondata.isBankAccountLetterUploaded == 'No') {
      
          const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
            width: '650px',
            height:'auto',
        
        
        
          }); 
        
      }
      
      else {
       










      
        
          if(this.withdrawUser.profileStatus === "1197"){
            this.profilestatuserrmsg ="Profile Status is Pending"
            const dialogRef = this.dialog.open(ProfilestatusComponent, {
              width: '250px',
              data:this.profilestatuserrmsg
        
        
            });
            dialogRef.afterClosed().subscribe(result => {
              
        
            })
           
      
          }
          else  if (this.withdrawUser.balance === "0.0"){
            this.profilestatuserrmsg ="Balance is not available to  withdraw."
          
            const dialogRef = this.dialog.open(ProfilestatusComponent, {
              width: '250px',
              data:this.profilestatuserrmsg
        
        
            });
            dialogRef.afterClosed().subscribe(result => {
              
        
            })
          }
      
          else  { 
            
      
          
          const dialogRef = this.dialog.open(WithrawdialogeComponent, {
            panelClass: 'custom-dialog-container',
            disableClose: true,
            width: '60%',
            height:'500px',
            data:this.withdrawUser
      
       
          });
      
          dialogRef.afterClosed().subscribe(result => {
           console.log(result)

           if(result == 1000) {
             this.grtbalancedetails()
           }
          
      
          });
        }
        } 

      }
        grtbalancedetails() {
          console.log('navya')
             this.auth.getbalanceinfo(this.user.accesstoken,this.data).subscribe(res =>{
              
          
               if(res.Token_Status == '1119') {
                 this.balance = res.balance; 
                 if(  res.profile_status=='1197'){
                  this.profileStatus="Pending For Approval"
                   }else if( res.profile_status=='1196'){
                    this.profileStatus="Approved"
                     }
               }
          
              
          
                //  const object2: any = {}
                //  object2['profileStatus']=  res.profile_status
                //  object2['balance'] = res.balance
        
                
                //  sessionStorage.setItem('currentUserbalance',JSON.stringify(object2))
          


                 this.token.changebalance(res)
          
             })
          
             
           }
       ngAfterViewinit() {
         $('.nav-section').addClass('expand');
      
      
      
         $('.nav-section').addClass('expand');
         $('.nav-section ul li a').on('click', function () {
                $('.nav-section ul .active').removeClass('active');
               $(this).addClass('active');
         });
        $('.menu-icon').click(function () {
         
          $('.nav-section').addClass('expand');
          $('.main-section').toggleClass('expand');
      
        });
         $('.nav-section ul li a').on('click', function () {
          $('.nav-section ul .active').removeClass('active');
         $(this).addClass('active');
      });
      
      $("#menu-close").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
      
      });
      $("#sidebar-wrapper .dashboard ").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
      
      });
      
      
      $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
      });
      
       }
      
       
      
      
          
    
      
       logout(){
        // console.log("logout++++++++++++++")
        const obj :any ={}
        obj['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
        obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
        obj['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
        obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
        // console.log(obj)
        this.auth.logout(obj,this.accesstoken).subscribe(res =>{
        console.log(res)
          sessionStorage.clear();
    
         // this.router.navigate(['/home'])
          if(res.Token_Status =='1119'){
            if(res.logout_response == '1000') {
              sessionStorage.clear();
    
            //  this.router.navigate(['/home'])
            }
    
            else if(res.logout_response == '1001'){
              this.errormsg = 'SOMETHING WENT WRONG'
            }
            else if(res.logout_response == '1011'){
    this.errormsg = 'SOMETHING WENT WRONG'
            }
            else if(res.logout_response == '1012'){
    
              this.errormsg = 'SOMETHING WENT WRONG'
            }
          }
    
          else if(res.Token_Status =='1120'){
            this.errormsg = 'UNAUTHORIZED'
          }
          else if(res.Token_Status =='1121'){
            this.errormsg = 'TOKEN EXPIRED'
          }
         
    
    
    
    
        })
     
      }
    
      
        menuopen() {
      
          
          $('.nav-section').addClass('expand');
           $('.nav-section ul li a').on('click', function () {
                  $('.nav-section ul .active').removeClass('active');
                 $(this).addClass('active');
           });
          $('.menu-icon').click(function () {
           
            $('.nav-section').addClass('expand');
            $('.main-section').toggleClass('expand');
      
          });
           $('.nav-section ul li a').on('click', function () {
            $('.nav-section ul .active').removeClass('active');
           $(this).addClass('active');
        });
      
        $("#menu-close").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
      
        });
        $("#sidebar-wrapper .dashboard ").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
      
        });
      
      
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
        });
      
        }
      
        close() {
          $("#menu-close").click(function(e) {
            e.preventDefault();
            $("#sidebar-wrapper").toggleClass("active");
        
          });
        }
      
      
        closenav(){
          
          $("#sidebar-wrapper .dashboard ").click(function(e) {
            e.preventDefault();
            $("#sidebar-wrapper").toggleClass("active");
        
          });
        }

        getit(){
          this.router.navigate(['/arabicwebapp/webappdashboard'])
  .then(() => {
    window.location.reload();
  });
  
      }      }
      
      
      @Component({
        selector: 'app-profilestatus',
        template: `
        <div style="display: flex;justify-content: space-between; curser:pointer;">
          <h2></h2>
      <div>
      <i class="fa fa-times" aria-hidden="true" (click)="onNoClick()"></i>
      </div>
          </div>
        <div class="row">
        <div class="col-lg-12">
      <div class="row" style="padding-left: 15px;">
      {{profilestatuserrmsg}}
      </div>
      
      
      
      
      
      
      </div>
      
      
      
        `
      })
      export class ProfilestatusComponent implements OnInit {
        profilestatuserrmsg: any;
      
       
      
        constructor(
          public dialogRef: MatDialogRef<ProfilestatusComponent>,@Inject(MAT_DIALOG_DATA) public data: any
         
         
          // @Optional() @Inject(MAT_DIALOG_DATA) public data: dataSource
        ) {
          
          this.profilestatuserrmsg=data
        }
      
      
        ngOnInit() {
          
      
        }
        onNoClick() {
         
          this.dialogRef.close();
        }
      
        
      
        
      }