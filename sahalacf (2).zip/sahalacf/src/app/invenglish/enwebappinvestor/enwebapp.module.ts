import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaindashboardComponent } from './maindashboard/maindashboard.component';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent, DocumentComponent } from './dashboard/dashboard.component';
import {MatCardModule} from '@angular/material/card';
import { OpportunitieslistComponent, DeleteComponent } from './opportunitieslist/opportunitieslist.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ReceivableComponent } from './receivable/receivable.component';
import { TransactionComponent } from './transaction/transaction.component';
import { InvestmentComponent } from './investment/investment.component';
import { InvestmentcritieriaComponent } from './investmentcritieria/investmentcritieria.component';
import {MatTableModule} from '@angular/material/table';
import { AllFundsComponent } from './all-funds/all-funds.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatButtonModule} from '@angular/material/button';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { ProfileComponent } from './profile/profile.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';   
import { MatNativeDateModule } from '@angular/material/core';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';
import { MatIconModule } from '@angular/material/icon';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClientModule } from '@angular/common/http';
import { AlertComponent } from './alert/alert.component';
import { NgbModule,NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/shared/shared.module';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { EngwebappRoutingModule } from './enwebapp-routing.module';




@NgModule({
  declarations: [MaindashboardComponent, AllFundsComponent,OpportunitieslistComponent,AlertComponent,DeleteComponent,DocumentComponent,
  ReceivableComponent,TransactionComponent,InvestmentComponent,InvestmentcritieriaComponent, ProfileComponent, ManageaccountComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    HttpClientModule,
    MatTableModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    NgbModule,
    NgbDatepickerModule,
 
    MatNativeDateModule,
    MatDatepickerModule,
    MatDividerModule,
    MatCardModule,
    MatTabsModule,
    ReactiveFormsModule,
    MatProgressBarModule,
    EngwebappRoutingModule
  ],
   providers:[AuthService,
    DeviceinfoserviceService,

  DeviceDetectorService],
  entryComponents:[
    AlertComponent,
    DeleteComponent,DocumentComponent
  ]
})
export class EnwebappModule { }