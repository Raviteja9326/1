import { Component, OnInit ,ViewEncapsulation, Injectable, ViewChild, ElementRef} from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormControl,FormGroupDirective, NgForm ,ValidatorFn,ValidationErrors} from '@angular/forms';
import {ErrorStateMatcher, DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgbDatepickerI18n, NgbDateStruct, NgbCalendar, NgbCalendarIslamicUmalqura } from '@ng-bootstrap/ng-bootstrap';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { Router } from '@angular/router';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, personalForm: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = personalForm && personalForm.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

const WEEKDAYS = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];
const MONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال',
  'ذو القعدة', 'ذو الحجة'];
 
@Injectable()
export class IslamicI18n extends NgbDatepickerI18n {

  getWeekdayShortName(weekday: number) {
    return WEEKDAYS[weekday - 1];
  }

  getMonthShortName(month: number) {
    return MONTHS[month - 1];
  }

  getMonthFullName(month: number) {
    return MONTHS[month - 1];
  }

  getDayAriaLabel(date: NgbDateStruct): string {
    return `${date.day}-${date.month}-${date.year}`;
  }
}






@Component({  
  selector: 'app-profile', 
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  providers: [
   
    {provide: NgbCalendar, useClass: NgbCalendarIslamicUmalqura},
    {provide: NgbDatepickerI18n, useClass: IslamicI18n}
],
  encapsulation: ViewEncapsulation.Emulated
})
export class ProfileComponent implements OnInit {

  BankDetHide=true;
  basicForm:FormGroup;
  personalForm:FormGroup;
submitted = false;
submitted1 = false;
tokenmessage = 'Your Session Has Expired, Please Login Here';

fileinput = false;
fileinput1 = false;
  deviceInfo: any;
  accesstoken: any;
  profileError: boolean;
  errorMessage: string;
  BankDetailsForm:FormGroup
  otpForm:FormGroup
  SucessError: boolean;
  sucessMessage: string;
  profilepage=true;
  otpShow=false;
  bankotpShow=false
  basicotpShow=false
  sucessinfo: boolean;
  SucessMessage: string;
  data: any;
  PersonalFormHide=true;
  BasicInfoHide=true
hide = false;
hide1 = false;
hide2 = false;


  anualincome = [
     {value: 'Less than 50,000 SAR', viewValue: 'Less than 50,000 SAR'},
    {value: 'From 50,000 to 100,000', viewValue: 'From 50,000 to 100,000 SAR'},
    {value: 'From 101,000 to 250,000 SAR', viewValue: 'From 101,000 to 250,000 SAR'},
    {value: 'From 251,000 to 500,000 SAR', viewValue: 'From 251,000 to 500,000 SAR'},
    {value: 'From 500,000 to 1,000,000 SAR', viewValue: 'From 500,000 to 1,000,000 SAR'},
    {value: 'More than 1,000,000 SAR', viewValue: 'More than 1,000,000 SAR'}
  ];
  sourceincome = [
    {value: 'Business Owner', viewValue: 'Business Owner'},
    {value: 'Retired', viewValue: 'Retired'}, 
    {value:'Private Employee',viewValue:'Private Employee'},
    {value:'Government Employee',viewValue:'Government Employee'},
    {value:'Student',viewValue:'Student'},
    {value: 'Other', viewValue: 'Other'},

    
  ];
  jobstatus = [
    {value: 'BusinessOwner', viewValue: 'Business Owner'},
    {value: 'Student', viewValue: 'Student'},
    {value: 'Other', viewValue: 'Other'}
  ];

  banks = [
    {value: 'ALAWWAL Bank', viewValue: 'ALAWWAL Bank'},
      {value: 'ARAB NATIONAL BANK', viewValue: 'ARAB NATIONAL BANK'},
      {value: 'AL RAJHI BANKING AND INV.CORP.', viewValue: 'AL RAJHI BANKING AND INV.CORP.'}, 
      {value: 'AL BANK AL SAUDI AL FRANSI', viewValue: 'AL BANK AL SAUDI AL FRANSI'},
      {value: 'ALINMA BANK', viewValue: 'ALINMA BANK'},
      {value: 'BANK AlBILAD', viewValue: 'BANK AlBILAD'},
      {value: 'BANK MUSCAT', viewValue: 'BANK MUSCAT'},
      {value: 'BANK ALJAZIRA', viewValue: 'BANK ALJAZIRA'},
      {value: 'DEUTSHE BANK', viewValue: 'DEUTSHE BANK'},
      {value: 'Emirates Bank', viewValue: 'EMIRATES BANK'},
      {value: 'GULF INTERNATIONAL BANK', viewValue: 'GULF INTERNATIONAL BANK'},
      {value: 'NATIONAL COMMERCIAL BANK', viewValue: 'NATIONAL COMMERCIAL BANK'},
      {value: 'NATIONAL BANK OF BAHRAIN', viewValue: 'NATIONAL BANK OF BAHRAIN'},
      {value: 'National Bank of Kuwait', viewValue: 'NATIONAL BANK OF KUWAIT'},
      {value: 'National Bank of Pakistan', viewValue: 'NATIONAL BANK OF PAKISTAN'},
      {value: 'RIYAD BANK', viewValue: 'RIYAD BANK'},
 
      {value: 'SAUDI INVESTMENT BANK', viewValue: 'SAUDI INVESTMENT BANK'},
     
      {value: 'SABB BANK', viewValue: 'SABB BANK'},
      {value: 'SAUDI ARABIAN MONETARY AGENCY', viewValue: 'SAUDI ARABIAN MONETARY AGENCY'},
      {value: 'SAMBA BANK', viewValue: 'SAMBA BANK'},
   
    
  ];

  iqama :boolean;
  iqamaNA: boolean;
  idvaliddate: string; 
  bankdeterr: boolean;
  BankDetailsUpdatedSuces: string;
  updatepersonalInformation: string; 
  updateprosucMessage: boolean;
  personalInfoprofileError: boolean;
  bacicprofilesucess: boolean;
  basicinfo: string;
  bacicprofileError: boolean;
  dataaaaae: string;
  idexpire: any;
  saudi: boolean;
  nonsaudi: boolean;
  dobdatcurrent: boolean;
  datdob: string;
  todaydate: any;
  doberrdis: boolean;
  doberr: string;
  model: NgbDateStruct;
  currentengdob: Date;
  finalengcurrentdat: any;
  bobdattt: string;
  setDate: string;
  doberrdiseng: boolean;
  changeenablenational: any;
  dobcahnge: any;
  backendnationality: any;
  submittedo: boolean;
  idattt: string;
  submittedp: boolean;
  submittedb: boolean;
  elsedate: any;
  bobdatttid: string;
  basicprofileresponse: any;
  personalresponse: any;
  uploadfileForm:FormGroup;
  mobileEmailFileError: string;
  mobileEmaiError: boolean;
  bankstatementFileError: string;
  bankstaatmentsError: boolean;
  responseMessgaeer: string;
  responseMessgae: string;
  registError: boolean;
  submitted2: boolean;
  submitted5: boolean;
  msgError: boolean;
  responseUploadDocMessgae: string;
  registuploaddocError: boolean;
  genvalue: boolean;
  genna: boolean;



  constructor(private fb: FormBuilder,private authService:AuthService,private calendar: NgbCalendar,private deviceinfoservice:DeviceinfoserviceService,
    private deviceService: DeviceDetectorService,private spinnerfull: NgxSpinnerService,
    private refresh:RefreshtokenService,private router:Router) { 


      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }

      this.detectDevice();
      this.GetbasicProfile();
  }

  get investeryourInfoControllers() { return this.basicForm.controls }
  get f() { return this.personalForm.controls }
  get g() { return this.BankDetailsForm.controls }
get o(){return this.otpForm.controls}


selectToday() {
  this.model = this.calendar.getToday();
 

  this.todaydate =  `${this.model.year}-${this.model.month}-${this.model.day}`


}



  ngOnInit(): void {

this.selectToday();

    this.basicForm = this.fb.group({
      firstName:['',[Validators.required]],
      lastName:['',[Validators.required]],
      mobileNo:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),  Validators.pattern("^(5)[0-9]{8}$")]],
      riyadName:[''],
      email:['']
      // email:['',[Validators.pattern( "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      // + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"),Validators.required]]

    })
 
    this.personalForm = this.fb.group({
      annualIncome : ['',[Validators.required]],
      sourceIncome : ['',[Validators.required]],
      jobstatus : ['',[Validators.required]],
      iqama : ['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),]],
      nameen : ['',[Validators.required,Validators.pattern("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$")]],
      namear:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF\ ]*$')]],
      placeOfBirth:['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      currentResidentLocation:['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]],
      nationality : ['',[Validators.required]],
      gender : ['',[Validators.required]],
      dob : ['',[Validators.required]],
      idexpiryDate : ['',[Validators.required]],
      // dobnon : ['',[Validators.required]], 
      // idexpiryDatenon : ['',[Validators.required]]

 
    })
    this.BankDetailsForm= this.fb.group({
      bankname : ['',[Validators.required]],
      accountholder : ['',[Validators.required,Validators.pattern('^[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z]+[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FFa-zA-Z-_\ ]*$')]],
      baniban : ['',[Validators.required,Validators.pattern('^[^ ].+[^ ]$')]],

    })
    this.otpForm=this.fb.group({
      otp: ['',[Validators.required,Validators.minLength(6), Validators.maxLength(6), Validators.pattern("^[0-9]*$")]],
    })
    this.uploadfileForm = this.fb.group({
      mobileEmail: [''],
      monthbankstatement:[''],
      docName1:[''],
      docName2:['']

    })
  }

  updatebasic() {
    this.submitted = true;
    (this.basicForm.value)
  }

  // updateprofile() {
  //   this.submitted1 = true;
  //   this.personalForm.get('dob').markAsTouched();
  //   this.personalForm.get('idexpiryDate').markAsTouched();
  //   (this.personalForm.value)
  // }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
   
  }
  get u() {
    return this.uploadfileForm.controls;
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  onFileChange(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.fileinput = true
      this.mobileEmaiError = false;
      this.uploadfileForm.get('mobileEmail').setValue(file);
    }
  }else{
    this.mobileEmailFileError="Document1  Should Be Less Than 5 MB";
    this.mobileEmaiError = true;
    // setTimeout(() => {
    //   this.mobileEmaiError = false;
    // }, 5000)
  }
  }
  onFileChange2(event) {
    if(event.target.files[0].size < 5000000){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.fileinput1 = true
      this.bankstaatmentsError = false;
      this.uploadfileForm.get('monthbankstatement').setValue(file);
    }
  }else{
    this.bankstatementFileError="Document2  Should Be Less Than 5 MB";
    this.bankstaatmentsError = true;
    // setTimeout(() => {
    //   this.bankstaatmentsError = false;
    // }, 5000)
  }
  }
  @ViewChild('myInput')
  myInputVariable: ElementRef;
  @ViewChild('myInput1')
  myInputVariable1: ElementRef;
  uploadform() {


    console.log(this.uploadfileForm.value.docName1)
   this.submitted2 = true;
   this.submitted5=true;
 //  console.log(this.uploadfileForm.value)
  this.detectDevice();

  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }


if(this.uploadfileForm.value.mobileEmail  !='' || this.uploadfileForm.value.monthbankstatement  !='' ) {

this.responseMessgaeer = ''
     this.submitted5 = false; 
     this.msgError = false;
     var formData = new FormData();
    


     var f = new File([""], "filename");

     if(this.uploadfileForm.value.mobileEmail =='' || this.uploadfileForm.value.mobileEmail == null){ 
       console.log('doc1')
            formData.append('document1',f);
           
         }else{
           formData.append('document1',this.uploadfileForm.value.mobileEmail);
         }

         if(this.uploadfileForm.value.monthbankstatement ==''  || this.uploadfileForm.value.monthbankstatement == null){

           console.log('doc2')
           formData.append('document2',f);
          
        }else{
          formData.append('document2',this.uploadfileForm.value.monthbankstatement);
        }
     // formData.append('document1',this.uploadfileForm.value.mobileEmail);

     // formData.append('document2',this.uploadfileForm.value.monthbankstatement);

     if(this.uploadfileForm.value.docName1 == '') {

       formData.append('docName1','NA');
     }
     else{
       formData.append('docName1',this.uploadfileForm.value.docName1);
     }
    

     if(this.uploadfileForm.value.docName2 == '') {

       formData.append('docName2','NA');
     }
     else {
       formData.append('docName2',this.uploadfileForm.value.docName2);
     }
    
     formData.append('deviceType',this.deviceinfoservice.deviceinfo.deviceType);
     formData.append('deviceId	',this.deviceinfoservice.deviceinfo.deviceId);
     formData.append('iPAddress	',this.deviceinfoservice.deviceinfo.ipAdress);
     
     console.log( formData.has('document1'))
     console.log( formData.has('document2')) 
     
     console.log( formData.has('iPAddress')) 
     console.log(this.deviceinfoservice.deviceinfo.deviceId)
     console.log(this.uploadfileForm.value.mobileEmail)
     console.log(this.uploadfileForm.value.monthbankstatement)
  
   

  // this.spinner = true;
      this.spinnerfull.show();
      console.log(formData)
     this.authService.uploadinvestorprofiledocuments(formData,this.accesstoken).subscribe(response =>{
      console.log(response)
       this.spinnerfull.hide();
    
       if(response.upload_documents_response == 1000){
         this.submitted5=false;
         this.responseUploadDocMessgae = "Documents Uploaded SucessFully";
         
                   this.registuploaddocError = true;
                   setTimeout(() => {
                    
                     this.registuploaddocError = false;
                     this.myInputVariable.nativeElement.value = "";
                     this.myInputVariable1.nativeElement.value = "";
                
this.fileinput = false;
this.fileinput1 = false;
this.uploadfileForm.reset()
const object:any = {}
  
   object['FirstName']  = this.data.FirstName;
   object['LastName']     = this.data.LastName;
   object['LastLogin']    = this.data.LastLogin;
   object['isMobileVerified']   = this.data.isMobileVerified;
   object['isEmailVerified']   = this.data.isEmailVerified;
   object['accesstoken']   = this.accesstoken;
   object['ProfilePic'] = this.data.ProfilePic;
   object['id']=this.data.id
   object['profileStatus']=this.data.profileStatus
   object['redirect'] = "englishwebapp";
   object['isPolicyAccepted']  = this.data.isPolicyAccepted;
   object['isBankInfoProvided']   = this.data.isBankInfoProvided;
   object['isInvestorInfoProvided']  = this.data.isInvestorInfoProvided;
   object['isTermsAccepted']  = this.data.isTermsAccepted;
   object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;
   sessionStorage.setItem('currentUser',JSON.stringify(object))
                
                   }, 3000)
       }else if(response.upload_documents_response== 1001){
         this.responseMessgae = "FAILURE";
        
                   this.registError = true;
                   setTimeout(() => { 
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1002){
         this.responseMessgae = "SOMETHING WENT WRONG";
     
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }
     
       else if(response.upload_documents_response== 1011){
         this.responseMessgae = "SOMETHING WENT WRONG";
       
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1012){
         this.responseMessgae = "SOMETHING WENT WRONG";
       
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1013){
     
          this.responseMessgae = "SOMETHING WENT WRONG";
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1014){
         this.spinnerfull.hide();
         this.responseMessgae = "SOMETHING WENT WRONG";
     
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1255){
         this.responseMessgae = "DOCUMENT1 SHOULD NOT BE EMPTY";
         this.spinnerfull.hide();
     
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1256){
         this.responseMessgae = "DOCUMENT2 SHOULD NOT BE EMPTY";
         this.spinnerfull.hide();
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1257){
         this.spinnerfull.hide();
         this.responseMessgae = "DOCUMENT1 SIZE SHOULD BE LESS THAN 5MB";    
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1258){
         this.spinnerfull.hide();
         this.responseMessgae = "DOCUMENT 2 SIZE SHOULD BE LESS THAN 5MB";    
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1259){
         this.spinnerfull.hide();
         this.responseMessgae = "DOCUMENT1 ALLOWED FILE FORMATS ARE PNG ,JPG, PDF, XLS, XLSX";    
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }else if(response.upload_documents_response== 1260){
         this.spinnerfull.hide();
         this.responseMessgae = "DOCUMENT2 ALLOWED FILE FORMATS ARE PNG ,JPG ,PDF ,XLS ,XLSX";    
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }
       else if(response.upload_documents_response== 1225){
        this.spinnerfull.hide();
        this.responseMessgae = "FILE SHOULD NOT BE  EMPTY";    
                  this.registError = true;
                  setTimeout(() => {
                    this.registError = false;
                  }, 3000)
      }
       

       else {

         this.spinnerfull.hide();
         this.responseMessgae = "SOMETHING WENT WRONG";   
     
                   this.registError = true;
                   setTimeout(() => {
                     this.registError = false;
                   }, 3000)
       }
     })
    
   }
 
//   }

// else {
//   this.responseMessgaeer = 'Upload Atleast One Document'
// }



 }


  GetProfiles(tab){
    if(tab.index=='0'){
  
      this.BasicInfoHide = true;
      this.basicotpShow = false;
      this.GetbasicProfile()
      this.ngOnInit();
    }else if(tab.index=='1'){
  
      this.PersonalFormHide = true;
      this.otpShow = false;
      this.ngOnInit();
      this.GetPersonalProfile();
     
    }else if(tab.index=='2'){
      this.BankDetHide = true;
      this.bankotpShow = false;
      this.ngOnInit();
      this.GetBankDetails();
    }else if(tab.index=='3'){
     // this.GetBankDetails();
    }
  }


  GetbasicProfile(){
  
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
   //object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
   this.spinnerfull.show()
   this.authService.GetbasicProfile(object,this.accesstoken).subscribe(response=>
    this.basicprofileResponse(response))
  }
  basicprofileResponse(response){
   this.basicprofileresponse = response
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
    if(response.basic_profile_status=='1000'){
   
      this.basicForm.patchValue({
        firstName:response.first_name,
        lastName:response.last_name,
        mobileNo:response.mobile_number,
        riyadName:response.virtual_account_number,
        email:response.email,
      })
    }
  }else if(response.Token_Status=='1120'){
    this.profileError = true;
   
    this.errorMessage = '';
   
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorize(this.tokenmessage)
      this.router.navigate(['/home'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.profileError = true;
    this.errorMessage = '';
   
   
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorize(this.tokenmessage)
      this.router.navigate(['/home'])
      sessionStorage.clear()
    }, 3000);
  }
  }

  GetPersonalProfile(){
    const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
   this.spinnerfull.show()
   this.authService.GetPersonalProfile(object,this.accesstoken).subscribe(response=>
    this.basicpersonalprofResponse(response))
  }
  basicpersonalprofResponse(response){
    console.log(response)
this.personalresponse = response
    if(response.nationality_number == 'NA') {

      this.iqamaNA = true;
      this.iqama = false;
    }

    else{
      console.log('navya')
      this.iqamaNA = false;
      this.iqama = true;
      console.log('navya')
     
    }
    if(response.gender == 'NA') {

      this.genvalue = true;
      this.genna = false;
    }

    else{
      
      console.log('navya')
      this.genvalue = false;
      this.genna = true;
    }
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){

if(response.personal_profile_status=='1168'){
  // const formattedDat = moment(response.id_expiry_date).format("MM-DD-YYYY");
  // (formattedDat);
  // this.idvaliddate=formattedDat

  (response.is_saudi_resident)
  this.backendnationality = response.is_saudi_resident
  // if(response.is_saudi_resident == "Non-Saudi") {

  //   this.nonsaudi = true;
  //   this.saudi = false;

  // }
  // if(response.is_saudi_resident == "Saudi") {

  //   this.nonsaudi = false;
  //   this.saudi  = true;

  // }
  if(response.annual_income != "NA" || response.job_status != "NA" || response.source_of_income != "NA"){
this.personalForm.patchValue({
  annualIncome:response.annual_income,
  sourceIncome:response.source_of_income,
  jobstatus:response.job_status,

})
  }
  
  
  this.personalForm.patchValue({
    // annualIncome:response.annual_income,

    // sourceIncome:response.source_of_income,
    // jobstatus:response.job_status,

    iqama:response.nationality_number,

    placeOfBirth:response.placeOfBirth,
    currentResidentLocation:response.currentResidentLocation,
    nameen:response.full_name_en,
        namear:response.full_name_ar,
    nationality:response.is_saudi_resident,
    gender:response.gender,
    dob:response.dob,
    // dobnon:response.dob,
    // idexpiryDatenon:response.id_expiry_date,
    idexpiryDate:response.id_expiry_date
  })

}else if(response.personal_profile_status=='1169'){
  this.profileError = true;
      this.errorMessage = 'PERSONAL PROFILE DETAILS NOT AVALIABLE';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);
}


    }else if(response.Token_Status=='1120'){ 
      this.profileError = true;
     
      this.errorMessage = '';
    
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
      // const dialogRef = this.dialog.open(Component,{ disableClose: true,
      //   width: '250px',
      //   backdropClass: 'backdropBackground'
       
      // });
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = '';
     
     
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
      // const dialogRef = this.dialog.open(Component,{ disableClose: true,
      //   width: '250px',
      //   backdropClass: 'backdropBackground'
       
      // });
    }
  }
  nationalitychange(val) {
    (val)
    this.changeenablenational = val;
//     if(val == 'Saudi') {
// this.saudi = true;
// this.nonsaudi = false;
//     }
//     if(val == 'Non-Saudi') {
//       this.saudi = false;
//       this.nonsaudi = true;
//           }


  }




GetBankDetails(){
  const object: any = {}
  object['browser_type'] = this.deviceInfo.browser;
  object['browser_version'] = this.deviceInfo.browser_version;
  object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['os_version'] = this.deviceInfo.os_version;
  object['os_type'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
   object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
 
   this.spinnerfull.show()
   this.authService.GetBankDetails(object,this.accesstoken).subscribe(response=>
    this.bankdetailsResponse(response))
}
bankdetailsResponse(response){
 // console.log(response)
this.spinnerfull.hide()



  if(response.Token_Status=='1119'){

    if(response.bank_info_status=='1172'){
if(response.bank_name !="NA"){
  this.BankDetailsForm.patchValue({
    bankname:response.bank_name,

  })
}
      this.BankDetailsForm.patchValue({
        // bankname:response.bank_name,
        accountholder:response.bank_account_holder_name,
        baniban:response.bank_iban,
        virtualaccountNum:response.virtual_account_number,
        
      })



    }else if(response.bank_info_status=='1173'){
      this.profileError = true;
     // this.errorMessage = 'Bank Details Not Avaliable';
      setTimeout(() => {
        this.profileError = false;
      }, 5000);
    }
  }else if(response.Token_Status=='1120'){
      this.profileError = true;
      this.errorMessage = '';
     
   
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }
}




  changeDate(val) {
  
 this.dobcahnge = val;
  var age = 18;
  const formattedDate = val;
 
 
  
if(formattedDate.day < 10  && formattedDate.month < 10 ) {

 
  this.datdob =  `${formattedDate.year}-0${formattedDate.month}-0${formattedDate.day}`
  
  // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
  var setDate =`${formattedDate.year +age}-0${formattedDate.month -1}-0${formattedDate.day}` ;
 
var currdate = this.todaydate;

if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate
// you are above 18

// alert("above 18");
} else {

this.doberrdis = true;
this.doberr = 'Date of Birth should be greater than 18 years'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);
}
  return this.datdob

}
else if(formattedDate.month < 10 ) {

 
  this.datdob =  `${formattedDate.year}-0${formattedDate.month}-${formattedDate.day}`

  // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
  var setDate =`${formattedDate.year +age}-0${formattedDate.month -1}-${formattedDate.day}` ;
  
var currdate = this.todaydate;

if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate
// you are above 18

// alert("above 18");
} else {

this.doberrdis = true;
this.doberr = 'Date of Birth should be greater than 18 years'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);
}
  return this.datdob

}
else if(formattedDate.day < 10 ) {

 
  this.datdob =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
 
  // new Date(formattedDate.year + age, formattedDate.month - 1, formattedDate.day)
  var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-0${formattedDate.day}` ;
 
var currdate = this.todaydate;

if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate
// you are above 18

// alert("above 18");
} else {

this.doberrdis = true;
this.doberr = 'Date of Birth should be greater than 18 years'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);
}
  return this.datdob

}
else  {
  this.datdob =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`

 
  var setDate =`${formattedDate.year +age}-${formattedDate.month -1}-${formattedDate.day}` ;

var currdate = this.todaydate;


if (currdate >= setDate) {
this.dobdatcurrent = currdate >= setDate
// you are above 18

//alert("above 18");
} else {

this.doberrdis = true;
this.doberr = 'Date of Birth should be greater than 18 years'
setTimeout(() => {
  this.doberrdis = false;
}, 3000);

// alert("below 18");
}
  return this.datdob

}
}


changeidDate(val) {

  const formattedDate = val;

  if(formattedDate.day < 10){
    this.idexpire =  `${formattedDate.year}-${formattedDate.month}-0${formattedDate.day}`
  //  (this.dataaaaae)
  
    return this.idexpire
  }
  else {
    this.idexpire =  `${formattedDate.year}-${formattedDate.month}-${formattedDate.day}`

    return this.idexpire
  }

}




//   UpdatePersonalProfile(){
  
  
    
//     this.submitted1=true;
//     this.personalForm.get('annualIncome').markAsTouched();
//     this.personalForm.get('sourceIncome').markAsTouched();
//     this.personalForm.get('jobstatus').markAsTouched();
//     this.personalForm.get('iqama').markAsTouched();
//     this.personalForm.get('nameen').markAsTouched();
//     this.personalForm.get('namear').markAsTouched();
//     this.personalForm.get('nationality').markAsTouched();
//     this.personalForm.get('gender').markAsTouched();
//     this.personalForm.get('dob').markAsTouched();
//     this.personalForm.get('idexpiryDate').markAsTouched();


    
//     if(this.changeenablenational  == 'Saudi') {
//       ('navysdfdf')
// if(this.dobdatcurrent == true){
// if(this.personalForm.valid){

//     const object:any={}
//     object['browserType'] = this.deviceInfo.browser;
//     object['browserVersion'] = this.deviceInfo.browser_version;
//     object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//     object['osVersion'] = this.deviceInfo.os_version;
//     object['osType'] = this.deviceInfo.os;
//     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//     object['language'] = 'en';
//     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//     object['anualIncome'] = this.personalForm.value.annualIncome
//     object['sourceIncome'] = this.personalForm.value.sourceIncome
//      object['jobStatus'] = this.personalForm.value.jobstatus;
//      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//      object['nameEn'] = this.personalForm.value.nameen;
//      object['nameAr'] = this.personalForm.value.namear;
//      if(this.personalForm.value.nationality=='Saudi'){
//       object['isSauthiResident'] = '1';
     
//      }else if(this.personalForm.value.nationality=='Non-Saudi'){
//       object['isSauthiResident'] =  '0';
//      }
//     object['deviceType']='Web'
//      object['gender'] = this.personalForm.value.gender;


//      if(this.backendnationality == "Saudi") {

//       (this.personalForm.value.dobnon)
//       this.changeDate(this.personalForm.value.dob);
//       object['dob'] =this.datdob;
//       this.changeidDate(this.personalForm.value.idexpiryDate);
//       (this.personalForm.value.idexpiryDate)
//       object['idExpiryDate'] =this.personalForm.value.idexpiryDatenon;
      
//      }
//      else {
//        ('connn')
      
//        object['idExpiryDate'] =this.idexpire;

//        object['dob'] = this.datdob
      
//      }

   
//      (object)
//       this.spinnerfull.show()
//       this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//         this.updateProfileresponse(response))

// }

// }
//     }


//    else if(this.changeenablenational  == 'Non-Saudi')  {
//      ('manasa')
//      (this.personalForm.valid)
// (this.bobdattt)
// this.getcurrentengdob()
//   const object:any={}
//   object['browserType'] = this.deviceInfo.browser;
//   object['browserVersion'] = this.deviceInfo.browser_version;
//   object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//   object['osVersion'] = this.deviceInfo.os_version;
//   object['osType'] = this.deviceInfo.os;
//   object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//   object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//   object['language'] = 'en';
//   object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//   object['anualIncome'] = this.personalForm.value.annualIncome
//   object['sourceIncome'] = this.personalForm.value.sourceIncome
//    object['jobStatus'] = this.personalForm.value.jobstatus;
//    object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//    object['nameEn'] = this.personalForm.value.nameen;
//    object['nameAr'] = this.personalForm.value.namear;

//    (this.personalForm.value.dob)
//    if(this.personalForm.value.nationality =='Saudi'){
//     object['isSauthiResident'] = '1';
 
//    }else if(this.personalForm.value.nationality=='Non-Saudi'){
//     object['isSauthiResident'] =  '0';
   
//    }

   
//    if(this.backendnationality == "Non-Saudi") {

//     (this.personalForm.value.dobnon)
//     this.onDateChange(this.personalForm.value.dobnon);
//     object['dob'] =this.bobdattt;
//     this.changeidDate(this.personalForm.value.idexpiryDate);
//     (this.personalForm.value.idexpiryDate)
//     object['idExpiryDate'] =this.personalForm.value.idexpiryDatenon;
    
//    }
//    else {
//      ('connn')
    
//     object['dob'] = this.bobdattt
//     object['idExpiryDate'] = this.idattt;
//    }

 
 
//   object['deviceType']='Web'
//    object['gender'] = this.personalForm.value.gender;

   

//     (object)
//     this.spinnerfull.show()

//     this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//       this.updateProfileresponse(response))


// }

// else {
//   if(this.personalForm.valid){

//     const object:any={}
//     object['browserType'] = this.deviceInfo.browser;
//     object['browserVersion'] = this.deviceInfo.browser_version;
//     object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//     object['osVersion'] = this.deviceInfo.os_version;
//     object['osType'] = this.deviceInfo.os;
//     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//     object['language'] = 'en';
//     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//     object['anualIncome'] = this.personalForm.value.annualIncome
//     object['sourceIncome'] = this.personalForm.value.sourceIncome
//      object['jobStatus'] = this.personalForm.value.jobstatus;
//      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//      object['nameEn'] = this.personalForm.value.nameen;
//      object['nameAr'] = this.personalForm.value.namear;
  
  
  
  
//      (this.personalForm.value.dob)
//      if(this.personalForm.value.nationality =='Saudi'){
//       object['isSauthiResident'] = '1';
   
//      }else if(this.personalForm.value.nationality=='Non-Saudi'){
//       object['isSauthiResident'] =  '0';
     
//      }
  
  
  
     
  
      
  
//      if(this.backendnationality == "Non-Saudi") {
    

//        let dateerr = (this.dobdatcurrent == true)
//        (dateerr)
//        if(dateerr == false){
//          ('djhfksdjfh')
      
//          this.onDateChange(this.personalForm.value.dob);
//          object['dob'] =this.personalForm.value.dob;
//          object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//        }
//      else if(this.dobdatcurrent == true){

//         ('trueeee')
//       this.onDateChange(this.elsedate);
      
//       object['dob'] =this.bobdattt;
//       object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//       object['deviceType']='Web'
//       object['gender'] = this.personalForm.value.gender;
   
       
   
//        (object)
//        this.spinnerfull.show()
   
//        this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//          this.updateProfileresponse(response))
   
//       }


// else {
//   this.onDateChange(this.personalForm.value.dob);
//   object['dob'] =this.bobdattt;
//   object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//   object['deviceType']='Web'
//   object['gender'] = this.personalForm.value.gender;

   

//    (object)
//    this.spinnerfull.show()

//    this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//      this.updateProfileresponse(response))

// }

      
//      }
  
     
//      if(this.backendnationality == "Saudi") {
//       this.changeDate(this.personalForm.value.dob);
//       object['dob'] =this.datdob;
//       object['idExpiryDate'] =this.idexpire;
//       object['deviceType']='Web'
//       object['gender'] = this.personalForm.value.gender;
   
       
   
//        (object)
//        this.spinnerfull.show()
   
//        this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//          this.updateProfileresponse(response))
   
      
//      }
  
  
  
     
   
  
//   }
// }



//   }






UpdatePersonalProfile(){
  // this.profilepage=false;
  // this.otpShow=true;
  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }
  this.submitted1=true;
  // this.personalForm.get('annualIncome').markAsTouched();
  // this.personalForm.get('sourceIncome').markAsTouched();
  // this.personalForm.get('jobstatus').markAsTouched();
  // this.personalForm.get('iqama').markAsTouched();
  // this.personalForm.get('nameen').markAsTouched();
  // this.personalForm.get('namear').markAsTouched();
  // this.personalForm.get('nationality').markAsTouched();
  // this.personalForm.get('gender').markAsTouched();
  this.personalForm.get('dob').markAsTouched();
  this.personalForm.get('idexpiryDate').markAsTouched();
 
if(this.dobdatcurrent  == true){
if(this.personalForm.valid){

  const object:any={}
  object['browserType'] = this.deviceInfo.browser;
  object['browserVersion'] = this.deviceInfo.browser_version;
  object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['osVersion'] = this.deviceInfo.os_version;
  object['osType'] = this.deviceInfo.os;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
  object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
  object['anualIncome'] = this.personalForm.value.annualIncome
  object['sourceIncome'] = this.personalForm.value.sourceIncome
   object['jobStatus'] = this.personalForm.value.jobstatus;
   object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
   object['placeOfBirth'] = this.personalForm.value.placeOfBirth

   if(this.personalresponse.nationality_number =='NA'){
    object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
    
   if(this.personalForm.value.nationality=='Saudi'){
    object['isSauthiResident'] = '1';
   }else if(this.personalForm.value.nationality=='Non-Saudi'){
    object['isSauthiResident'] =  '0';
   }
   }
   else{
    object['nationalNumberiqamaNumber'] = this.personalresponse.nationality_number;
    if(this.personalresponse.is_saudi_resident=='Saudi'){
      object['isSauthiResident'] = '1';
     }else if(this.personalresponse.is_saudi_resident=='Non-Saudi'){
      object['isSauthiResident'] =  '0';
     }
   }
   object['nameEn'] = this.personalForm.value.nameen;
   object['nameAr'] = this.personalForm.value.namear;

  object['deviceType']='Web'
   object['gender'] = this.personalForm.value.gender;
   const momentDate1 = new Date(this.personalForm.value.dob); 
const formattedDate = moment(momentDate1).format("YYYY-MM-DD");



var d = new Date(this.personalForm.value.dob),
month = '' + (d.getMonth() + 1),
day = '' + d.getDate(),
year = d.getFullYear();

if (month.length < 2) 
month = '0' + month;
if (day.length < 2) 
day = '0' + day;

this.bobdattt = [year, month, day].join('-')


    object['dob'] = this.bobdattt
    const momentDate= new Date(this.personalForm.value.idexpiryDate); 
    const formattedDat = moment(momentDate).format("MM-DD-YYYY");
    


    var d = new Date(this.personalForm.value.dob),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
    
    if (month.length < 2) 
    month = '0' + month;
    if (day.length < 2) 
    day = '0' + day;
    
    this.bobdatttid = [year, month, day].join('-')

    object['idExpiryDate'] = this.bobdatttid 
console.log(object)
    this.spinnerfull.show()
    this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
      this.updateProfileresponse(response))

}
}

else if(this.dobdatcurrent  == false) {
  if(this.personalForm.valid){

    const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['anualIncome'] = this.personalForm.value.annualIncome
    object['sourceIncome'] = this.personalForm.value.sourceIncome
     object['jobStatus'] = this.personalForm.value.jobstatus;
     object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
     object['placeOfBirth'] = this.personalForm.value.placeOfBirth
  
    //  object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
     object['nameEn'] = this.personalForm.value.nameen;
     object['nameAr'] = this.personalForm.value.namear;
     if(this.personalresponse.nationality_number =='NA'){
      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
      
     if(this.personalForm.value.nationality=='Saudi'){
      object['isSauthiResident'] = '1';
     }else if(this.personalForm.value.nationality=='Non-Saudi'){
      object['isSauthiResident'] =  '0';
     }
     }
     else{
      object['nationalNumberiqamaNumber'] = this.personalresponse.nationality_number;
      if(this.personalresponse.is_saudi_resident=='Saudi'){
        object['isSauthiResident'] = '1';
       }else if(this.personalresponse.is_saudi_resident=='Non-Saudi'){
        object['isSauthiResident'] =  '0';
       }
     }
    object['deviceType']='Web'
     object['gender'] = this.personalForm.value.gender;
     const momentDate1 = new Date(this.personalForm.value.dob); 
  const formattedDate = moment(momentDate1).format("YYYY-MM-DD");
 
  
  
  var d = new Date(this.personalForm.value.dob),
  month = '' + (d.getMonth() + 1),
  day = '' + d.getDate(),
  year = d.getFullYear();
  
  if (month.length < 2) 
  month = '0' + month;
  if (day.length < 2) 
  day = '0' + day;
  
  this.bobdattt = [year, month, day].join('-')
  
  
      object['dob'] = this.bobdattt
      const momentDate= new Date(this.personalForm.value.idexpiryDate); 
      const formattedDat = moment(momentDate).format("MM-DD-YYYY");
   
  
  
      var d = new Date(this.personalForm.value.dob),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
      
      if (month.length < 2) 
      month = '0' + month;
      if (day.length < 2) 
      day = '0' + day;
      
      this.bobdatttid = [year, month, day].join('-')
  
      object['idExpiryDate'] = this.bobdatttid 
      console.log(object)
      this.spinnerfull.show()
      this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
        this.updateProfileresponse(response))
  
  }


}

else {
  if(this.personalForm.valid){

    const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['anualIncome'] = this.personalForm.value.annualIncome
    object['sourceIncome'] = this.personalForm.value.sourceIncome
     object['jobStatus'] = this.personalForm.value.jobstatus;
     object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
     object['nameEn'] = this.personalForm.value.nameen;
     object['nameAr'] = this.personalForm.value.namear;
     object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
     object['placeOfBirth'] = this.personalForm.value.placeOfBirth
  
     if(this.personalresponse.nationality_number =='NA'){
      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
      
     if(this.personalForm.value.nationality=='Saudi'){
      object['isSauthiResident'] = '1';
     }else if(this.personalForm.value.nationality=='Non-Saudi'){
      object['isSauthiResident'] =  '0';
     }
     }
     else{
      object['nationalNumberiqamaNumber'] = this.personalresponse.nationality_number;
      if(this.personalresponse.is_saudi_resident=='Saudi'){
        object['isSauthiResident'] = '1';
       }else if(this.personalresponse.is_saudi_resident=='Non-Saudi'){
        object['isSauthiResident'] =  '0';
       }
     }
    object['deviceType']='Web'
     object['gender'] = this.personalForm.value.gender;
     const momentDate1 = new Date(this.personalForm.value.dob); 
  const formattedDate = moment(momentDate1).format("YYYY-MM-DD");

  
  
  var d = new Date(this.personalForm.value.dob),
  month = '' + (d.getMonth() + 1),
  day = '' + d.getDate(),
  year = d.getFullYear();
  
  if (month.length < 2) 
  month = '0' + month;
  if (day.length < 2) 
  day = '0' + day;
  
  this.bobdattt = [year, month, day].join('-')
  
  
      object['dob'] = this.bobdattt
      const momentDate= new Date(this.personalForm.value.idexpiryDate); 
      const formattedDat = moment(momentDate).format("MM-DD-YYYY");
    
  
  
      var d = new Date(this.personalForm.value.dob),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
      
      if (month.length < 2) 
      month = '0' + month;
      if (day.length < 2) 
      day = '0' + day;
      
      this.bobdatttid = [year, month, day].join('-')
  
      object['idExpiryDate'] = this.bobdatttid 
      console.log(object)
      this.spinnerfull.show()
      this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
        this.updateProfileresponse(response))
  
  }
}

  
}

  getcurrentengdob() {
    this.currentengdob =new Date()

    var d = new Date(this.currentengdob),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
    
    if (month.length < 2) 
    month = '0' + month;
    if (day.length < 2) 
    day = '0' + day;
    
    this.finalengcurrentdat = [year, month, day].join('-');
    
    return this.finalengcurrentdat
    
    }
    
    
    onidDateChange(val) {
    
      
        (val)
   
      
        
         // Replace event.value with your date value
         var d = new Date(val),
              month = '' + (d.getMonth() + 1),
              day = '' + d.getDate(),
              year = d.getFullYear();
      
          if (month.length < 2) 
              month = '0' + month;
          if (day.length < 2) 
              day = '0' + day;
      
              this.idattt = [year, month, day].join('-')
    
    }
    onDateChange(val) {

      this.elsedate = val;
    
    this. getcurrentengdob()
      
 
    
      
       // Replace event.value with your date value
       var d = new Date(val),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
            this.bobdattt = [year, month, day].join('-')
         
    this.setDate = [year+ 18, month, day].join('-');
            var currdate = this.finalengcurrentdat;
    
          
    
            if (currdate >= this.setDate) {
            this.dobdatcurrent = currdate >= this.setDate
           
            this.doberr = ''
           
            } else {
          
            this.doberrdiseng = true;
            this.doberr = 'Date of Birth should be greater than 18 years'
            // setTimeout(() => {
            //   this.doberrdiseng = false;
            // }, 3000);
            
     
            
            }
        return  this.bobdattt;
    
    }






  updateProfileresponse(response){
   console.log(response)
    this.spinnerfull.hide()
    this.submitted1=false;
    if(response.Token_Status=='1119'){

      if(response.Update_Personal_ProfileOtp_Response=='1000'){
        this.PersonalFormHide=false;
        this.otpShow=true;

      //   this.SucessError = true;
      // this.sucessMessage = 'Update';
      // setTimeout(() => {
      //   this.SucessError = false;
      // }, 3000);
      }else  if(response.Update_Personal_ProfileOtp_Response=='1001'){
        this.profileError = true;
        this.errorMessage = 'FAILURE';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1132'){
        this.profileError = true;
        this.errorMessage = 'ANNUAL_INCOME_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1133'){
        this.profileError = true;
        this.errorMessage = 'SOURCE_OF_INCOME_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1134'){
        this.profileError = true;
        this.errorMessage = 'JOB_STATUS_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1135'){
        this.profileError = true;
        this.errorMessage = 'NATIONAL_NUMBER_IQAMA_NUMBER_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1136'){
        this.profileError = true;
        this.errorMessage = 'ENGLISH_NAME_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1137'){
        this.profileError = true;
        this.errorMessage = 'ARABIC_NAME_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1138'){
        this.profileError = true;
        this.errorMessage = 'IS_SAUDHI_RESIDENT_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1139'){
        this.profileError = true;
        this.errorMessage = 'GENDER_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1140'){
        this.profileError = true;
        this.errorMessage = 'DOB_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1141'){
        this.profileError = true;
        this.errorMessage = 'ID_EXPIRY_DATE_IS_EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      } if(response.Update_Personal_ProfileOtp_Response=='1142'){
        this.profileError = true;
        this.errorMessage = 'DOB_IS_INVALID';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }if(response.Update_Personal_ProfileOtp_Response=='1143'){
        this.profileError = true;
        this.errorMessage = 'ENGLISH_NAME_IS_INVALID';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }if(response.Update_Personal_ProfileOtp_Response=='1144'){
        this.profileError = true;
        this.errorMessage = 'ARABIC_NAME_IS_INVALID';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }

      if(response.Update_Personal_ProfileOtp_Response=='1253'){
        this.profileError = true;
        this.errorMessage = 'PLACE OF BIRTH IS EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }if(response.Update_Personal_ProfileOtp_Response=='1254'){
        this.profileError = true;
        this.errorMessage = 'CURRENT RESIDENT LOCATION IS EMPTY';
        setTimeout(() => {
          this.profileError = false;
        }, 3000);
      }
    }else if(response.Token_Status=='1120'){
      this.profileError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }
  }


//   VerifyOtp(){
//     this.submittedp=true;

//     if(this.changeenablenational  == 'Saudi') {
//       ('navysdfdf')
// if(this.dobdatcurrent == true){
// if(this.otpForm.valid){

//     const object:any={}
//     object['browserType'] = this.deviceInfo.browser;
//     object['browserVersion'] = this.deviceInfo.browser_version;
//     object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//     object['osVersion'] = this.deviceInfo.os_version;
//     object['osType'] = this.deviceInfo.os;
//     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//     object['language'] = 'en';
//     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//     object['anualIncome'] = this.personalForm.value.annualIncome
//     object['sourceIncome'] = this.personalForm.value.sourceIncome
//      object['jobStatus'] = this.personalForm.value.jobstatus;
//      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//      object['nameEn'] = this.personalForm.value.nameen;
//      object['nameAr'] = this.personalForm.value.namear;
//      object['otp'] =this.otpForm.value.otp
//      if(this.personalForm.value.nationality=='Saudi'){
//       object['isSauthiResident'] = '1';
     
//      }else if(this.personalForm.value.nationality=='Non-Saudi'){
//       object['isSauthiResident'] =  '0';
//      }
//     object['deviceType']='Web'
//      object['gender'] = this.personalForm.value.gender;


//      if(this.backendnationality == "Saudi") {

//       (this.personalForm.value.dobnon)
//       this.changeDate(this.personalForm.value.dob);
//       object['dob'] =this.datdob;
//       this.changeidDate(this.personalForm.value.idexpiryDate);
//       (this.personalForm.value.idexpiryDate)
//       object['idExpiryDate'] =this.personalForm.value.idexpiryDatenon;
      
//      }
//      else {
//        ('connn')
      
//        object['idExpiryDate'] =this.idexpire;

//        object['dob'] = this.datdob
      
//      }


//      this.authService.updateprofile(object,this.accesstoken).subscribe(response=>
//       this.updatepersonalprofileotp(response))
//     }

     
//       }
//     }

//     else if(this.changeenablenational  == 'Non-Saudi')  {
//       ('manasa')
//       (this.otpForm.valid)
//  (this.bobdattt)
//  this.getcurrentengdob()
//    const object:any={}
//    object['browserType'] = this.deviceInfo.browser;
//    object['browserVersion'] = this.deviceInfo.browser_version;
//    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//    object['osVersion'] = this.deviceInfo.os_version;
//    object['osType'] = this.deviceInfo.os;
//    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//    object['language'] = 'en';
//    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//    object['anualIncome'] = this.personalForm.value.annualIncome
//    object['sourceIncome'] = this.personalForm.value.sourceIncome
//     object['jobStatus'] = this.personalForm.value.jobstatus;
//     object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//     object['nameEn'] = this.personalForm.value.nameen;
//     object['nameAr'] = this.personalForm.value.namear;
//     object['otp'] =this.otpForm.value.otp
 
//     (this.personalForm.value.dob)
//     if(this.personalForm.value.nationality =='Saudi'){
//      object['isSauthiResident'] = '1';
  
//     }else if(this.personalForm.value.nationality=='Non-Saudi'){
//      object['isSauthiResident'] =  '0';
    
//     }
 
    
//     if(this.backendnationality == "Non-Saudi") {
 
//      (this.personalForm.value.dobnon)
//      this.onDateChange(this.personalForm.value.dobnon);
//      object['dob'] =this.bobdattt;
//      this.changeidDate(this.personalForm.value.idexpiryDate);
//      (this.personalForm.value.idexpiryDate)
//      object['idExpiryDate'] =this.personalForm.value.idexpiryDatenon;
     
//     }
//     else {
//       ('connn')
     
//      object['dob'] = this.bobdattt
//      object['idExpiryDate'] = this.idattt;
//     }
 
  
  
//    object['deviceType']='Web'
//     object['gender'] = this.personalForm.value.gender;
 
    
 
//      (object)
//      this.spinnerfull.show()
//      this.authService.updateprofile(object,this.accesstoken).subscribe(response=>
//               this.updatepersonalprofileotp(response))
            
 
 
//  }


//  else {
//   if(this.otpForm.valid){

//     const object:any={}
//     object['browserType'] = this.deviceInfo.browser;
//     object['browserVersion'] = this.deviceInfo.browser_version;
//     object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
//     object['osVersion'] = this.deviceInfo.os_version;
//     object['osType'] = this.deviceInfo.os;
//     object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
//     object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
//     object['language'] = 'en';
//     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
//     object['anualIncome'] = this.personalForm.value.annualIncome
//     object['sourceIncome'] = this.personalForm.value.sourceIncome
//      object['jobStatus'] = this.personalForm.value.jobstatus;
//      object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
//      object['nameEn'] = this.personalForm.value.nameen;
//      object['nameAr'] = this.personalForm.value.namear;
//      object['otp'] =this.otpForm.value.otp
  
  
  
  
//      (this.personalForm.value.dob)
//      if(this.personalForm.value.nationality =='Saudi'){
//       object['isSauthiResident'] = '1';
   
//      }else if(this.personalForm.value.nationality=='Non-Saudi'){
//       object['isSauthiResident'] =  '0';
     
//      }
  
  
  
     
  
      
  
//      if(this.backendnationality == "Non-Saudi") {
    

//        let dateerr = (this.dobdatcurrent == true)
//        (dateerr)
//        if(dateerr == false){
//          ('djhfksdjfh')
      
//          this.onDateChange(this.personalForm.value.dob);
//          object['dob'] =this.personalForm.value.dob;
//          object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//        }
//      else if(this.dobdatcurrent == true){

//         ('trueeee')
//       this.onDateChange(this.elsedate);
      
//       object['dob'] =this.bobdattt;
//       object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//       object['deviceType']='Web'
//       object['gender'] = this.personalForm.value.gender;
   
       
   
//        (object)
//        this.spinnerfull.show()
   
//        this.authService.UpdatePersonalProfile(object,this.accesstoken).subscribe(response=>
//          this.updateProfileresponse(response))
   
//       }


// else {
//   this.onDateChange(this.personalForm.value.dob);
//   object['dob'] =this.bobdattt;
//   object['idExpiryDate'] =this.personalForm.value.idexpiryDate;
//   object['deviceType']='Web'
//   object['gender'] = this.personalForm.value.gender;

   

//    (object)
//    this.spinnerfull.show()

//    this.authService.updateprofile(object,this.accesstoken).subscribe(response=>
//             this.updatepersonalprofileotp(response))

// }

      
//      }
  
     
//      if(this.backendnationality == "Saudi") {
//       this.changeDate(this.personalForm.value.dob);
//       object['dob'] =this.datdob;
//       object['idExpiryDate'] =this.idexpire;
//       object['deviceType']='Web'
//       object['gender'] = this.personalForm.value.gender;
   
       
   
//        (object)
//        this.spinnerfull.show()
   
//        this.authService.updateprofile(object,this.accesstoken).subscribe(response=>
//         this.updatepersonalprofileotp(response))

   
      
//      }
  
  
  
     
   
  
//   }
// }

    

//   }

  VerifyOtp(){
    this.submitted=true;

    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.data!=null || this.data !=''){
      this.accesstoken= this.data.accesstoken;
    }


    if(this.otpForm.valid){
    const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['anualIncome'] = this.personalForm.value.annualIncome
    object['sourceIncome'] = this.personalForm.value.sourceIncome
     object['jobStatus'] = this.personalForm.value.jobstatus;
     object['nationalNumberiqamaNumber'] = this.personalForm.value.iqama;
     object['nameEn'] = this.personalForm.value.nameen;
     object['nameAr'] = this.personalForm.value.namear;
     object['currentResidentLocation'] = this.personalForm.value.currentResidentLocation
     object['placeOfBirth'] = this.personalForm.value.placeOfBirth
  
     if(this.personalForm.value.nationality=='Saudi'){
      object['isSauthiResident'] = '1';
     }else if(this.personalForm.value.nationality=='Non-Saudi'){
      object['isSauthiResident'] =  '0';
     }
     object['deviceType']='Web'
     object['gender'] = this.personalForm.value.gender;
     const momentDate1 = new Date(this.personalForm.value.dob); 
const formattedDate = moment(momentDate1).format("YYYY-MM-DD");

      object['dob'] = this.bobdattt
      const momentDate= new Date(this.personalForm.value.idexpiryDate); 
      //MM-DD-YYYY
      const formattedDat = moment(momentDate).format("YYYY-MM-DD");
      
      object['idExpiryDate'] =this.bobdatttid
      object['otp'] =this.otpForm.value.otp
     
      this.spinnerfull.show()
      this.authService.updateprofile(object,this.accesstoken).subscribe(response=>
        this.updatepersonalprofileotp(response))
      }
  }

  updatepersonalprofileotp(response){
 console.log(response)
    this.spinnerfull.hide()
    this.submitted=false;
if(response.Token_Status=='1119'){
  if(response.Update_Personal_Profile_Response=='1000'){
    this.updateprosucMessage = true;
      this.updatepersonalInformation="Personal Information Updated SucessFully"
      this.GetPersonalProfile();
       setTimeout(() => {
      this.PersonalFormHide=true;
      this.otpShow=false;
      this.otpForm.reset();
      this.updateprosucMessage = false;
    }, 3000);


    const object:any =  {}

    object['FirstName']  = this.data.FirstName;
    object['LastName']     = this.data.LastName;
    object['LastLogin']    = this.data.LastLogin;
    object['isMobileVerified']   = this.data.isMobileVerified;
    object['isEmailVerified']   = this.data.isEmailVerified;
    object['accesstoken']   = this.accesstoken;
    object['ProfilePic'] = this.data.ProfilePic;
    object['id']=this.data.id
    object['profileStatus']=this.data.profileStatus
    object['redirect'] = "englishwebapp";
    object['isPolicyAccepted']  = this.data.isPolicyAccepted;
    object['isBankInfoProvided']   = this.data.isBankInfoProvided;
    object['isInvestorInfoProvided']  = "Yes";
    object['isTermsAccepted']  = this.data.isTermsAccepted;
    object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;

    sessionStorage.setItem('currentUser',JSON.stringify(object))



  }else  if(response.Update_Personal_Profile_Response=='1001'){
    this.personalInfoprofileError = true;
        this.errorMessage = 'FAILURE';
        setTimeout(() => {
          this.personalInfoprofileError = false;
        }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1090'){
    this.personalInfoprofileError = true;
        this.errorMessage = 'OTP_IS_EMPTY';
        setTimeout(() => {
          this.personalInfoprofileError = false;
        }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1091'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'OTP_SHOULD_BE_NUMERIC';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1092'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'OTP_LEANGTH_SHOULD_BE_4_DIGITS';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1093'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'OTP_IS_INVALID';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }else  if(response.Update_Personal_Profile_Response=='1094'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'OTP_EXPIRED';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }
   }
   
   else  if(response.Update_Personal_Profile_Response=='1253'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'PLACE OF BIRTH IS EMPTY';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }
   
  else  if(response.Update_Personal_Profile_Response=='1254'){
    this.personalInfoprofileError = true;
    this.errorMessage = 'CURRENT RESIDENT LOCATION IS EMPTY';
    setTimeout(() => {
      this.personalInfoprofileError = false;
    }, 3000);
  }
   


   
   
   
   else if(response.Token_Status=='1120'){
    this.personalInfoprofileError = true;
    this.errorMessage = '';
   
    setTimeout(() => {
      this.personalInfoprofileError = false;
      this.refresh.unAuthorize(this.tokenmessage)
      this.router.navigate(['/home'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.personalInfoprofileError = true;
    this.errorMessage = '';
   
    setTimeout(() => {
      this.personalInfoprofileError = false;
      this.refresh.unAuthorize(this.tokenmessage)
      this.router.navigate(['/home'])
      sessionStorage.clear()
    }, 3000);
  }
}



updateBankInfo(){
  this.submitted1=true;
  console.log(this.BankDetailsForm.valid)
  console.log(this.BankDetailsForm.value.bankname)
  console.log(this.BankDetailsForm.value.baniban)
  console.log(this.BankDetailsForm.value.accountholder)
  // this.BankDetailsForm.get('bankname').markAsTouched();
  // this.BankDetailsForm.get('baniban').markAsTouched();
  // this.BankDetailsForm.get('accountholder').markAsTouched();
 
if(this.BankDetailsForm.valid){
  const object:any={} 
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['bankName'] = this.BankDetailsForm.value.bankname
    object['ibanNumber'] = this.BankDetailsForm.value.baniban;
    object['acountName'] = this.BankDetailsForm.value.accountholder;
    object['deviceType']='Web'
    this.spinnerfull.show()
    this.authService.updateBankDetailsOtp(object,this.accesstoken).subscribe(response=>
      this.updatebankDertOtpResponse(response))
}
    
}
updatebankDertOtpResponse(response){
  this.submitted1=false;
  (response)
  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){
  if(response.Bank_Info_Otp_Response=='1000'){
  //  this.profilepage=false;
  this.BankDetHide=false;
    this.bankotpShow=true;

  }else if(response.Bank_Info_Otp_Response=='1001'){

    this.profileError = true;
    this.errorMessage = 'FAILURE';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.Bank_Info_Otp_Response=='1054'){

    this.profileError = true;
    this.errorMessage = 'BANK_NAME_SHOULD_NOT_BE_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.Bank_Info_Otp_Response=='1055'){
    this.profileError = true;
    this.errorMessage = 'BANK_IBAN_SHOULD_NOT_BE_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1145'){
    this.profileError = true;
    this.errorMessage = 'BANK_ACCOUNT_NAME_IS_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1003'){
    this.profileError = true;
    this.errorMessage = 'BROWSER_TYPE_IS_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1004'){
    this.profileError = true;
    this.errorMessage = 'BROWSER_TYPE_LENGTH_SHOULD_BE_MAX_30';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);

  }else if(response.Bank_Info_Otp_Response=='1005'){

    this.profileError = true;
    this.errorMessage = 'BROWSER_VERSION_IS_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }
  }else if(response.Token_Status=='1120'){
    this.profileError = true;
    this.errorMessage = '';
  
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorize(this.tokenmessage)
      this.router.navigate(['/home'])
      sessionStorage.clear()
    }, 3000);
  }else if(response.Token_Status=='1121'){
    this.profileError = true;
    this.errorMessage = '';
    
    setTimeout(() => {
      this.profileError = false;
      this.refresh.unAuthorize(this.tokenmessage)
    this.router.navigate(['/home'])
    sessionStorage.clear()
    }, 3000);
  }
}
 
UpdatebankInfoOtpSubmit(){
  this.submittedb=true

  
  this.data = JSON.parse(sessionStorage.getItem('currentUser'));
  if(this.data!=null || this.data !=''){
    this.accesstoken= this.data.accesstoken;
  }
  
  if( this.otpForm.valid){
  const object:any={}
    object['browserType'] = this.deviceInfo.browser;
    object['browserVersion'] = this.deviceInfo.browser_version;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['osVersion'] = this.deviceInfo.os_version;
    object['osType'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
    object['bankName'] = this.BankDetailsForm.value.bankname
    object['ibanNumber'] = this.BankDetailsForm.value.baniban;
    object['acountName'] = this.BankDetailsForm.value.accountholder;
    object['otp'] = this.otpForm.value.otp;
    object['deviceType']='Web'
    this.spinnerfull.show()
    this.authService.updateBankDetails(object,this.accesstoken).subscribe(response=>
      this.updatebankdetResponse(response))
    }
}
updatebankdetResponse(response){
  (response)
  this.spinnerfull.hide()
  this.submitted=false
  if(response.Token_Status=='1119'){
    if(response.Bank_Info_Response=='1000'){
   //   alert("Bank Details Updated SucessFully")
   this.BankDetailsForm.reset();
  // this.otpForm.reset();
  //  this.profilepage=true;
  //  this.bankotpShow=false;
  //  this.sucessinfo = true;
      this.BankDetailsUpdatedSuces="Bank Information Updated SucessFully"
      this.bankdeterr = true;
      this.GetBankDetails();
      setTimeout(() => {
        //  this.profilepage=true;
        this.BankDetHide=true;
   this.bankotpShow=false;
   this.sucessinfo = true;
               this.bankdeterr = false;
               this.otpForm.reset();
      }, 3000);


      
    const object:any =  {}

    object['FirstName']  = this.data.FirstName;
    object['LastName']     = this.data.LastName;
    object['LastLogin']    = this.data.LastLogin;
    object['isMobileVerified']   = this.data.isMobileVerified;
    object['isEmailVerified']   = this.data.isEmailVerified;
    object['accesstoken']   = this.data.accesstoken;
    object['ProfilePic'] = this.data.ProfilePic;
    object['id']=this.data.id
    object['profileStatus']=this.data.profileStatus
    object['redirect'] = "englishwebapp";
    object['isPolicyAccepted']  = this.data.isPolicyAccepted;
    object['isBankInfoProvided']   = "Yes";
    object['isInvestorInfoProvided']  = this.data.isInvestorInfoProvided;
    object['isTermsAccepted']  = this.data.isTermsAccepted;
    object['isBankAccountLetterUploaded'] = this.data.isBankAccountLetterUploaded;

    sessionStorage.setItem('currentUser',JSON.stringify(object))
     
      // this.SucessMessage = 'SUCCESS';
      // setTimeout(() => {
      //   this.sucessinfo = false;
      // }, 3000);
    }else  if(response.Bank_Info_Response=='1001'){
      this.profileError = true;
          this.errorMessage = 'FAILURE';
          setTimeout(() => {
            this.profileError = false;
          }, 3000);
    }else  if(response.Bank_Info_Response=='1090'){
      this.profileError = true;
          this.errorMessage = 'OTP_IS_EMPTY';
          setTimeout(() => {
            this.profileError = false;
          }, 3000);
    }else  if(response.Bank_Info_Response=='1091'){
      this.profileError = true;
      this.errorMessage = 'OTP_SHOULD_BE_NUMERIC';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else  if(response.Bank_Info_Response=='1092'){
      this.profileError = true;
      this.errorMessage = 'OTP_LEANGTH_SHOULD_BE_4_DIGITS';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else  if(response.Bank_Info_Response=='1093'){
      this.profileError = true;
      this.errorMessage = 'OTP_IS_INVALID';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }else  if(response.Bank_Info_Response=='1094'){
      this.profileError = true;
      this.errorMessage = 'OTP_EXPIRED';
      setTimeout(() => {
        this.profileError = false;
      }, 3000);
    }
     }else if(response.Token_Status=='1120'){
      this.profileError = true;
      this.errorMessage = '';
    
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.profileError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.profileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }
}

UpdateBasicDetails(){
  this.basicForm.get('mobileNo').markAsTouched();
  this.basicForm.get('firstName').markAsTouched();
  this.basicForm.get('lastName').markAsTouched();
  this.submitted  = true

if(this.basicForm.valid){
  const object: any = {}
  object['mobileNumber'] = this.basicForm.value.mobileNo;
  object['firstName'] = this.basicprofileresponse.first_name;
  object['lastName'] = this.basicprofileresponse.last_name;

  object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
  object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
  object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
  object['language'] = 'en';
   object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
this.spinnerfull.show()
   this.authService.updateBasicInfoOtp(object,this.accesstoken).subscribe(response=>
    this.updatebasicinfootpres(response))
   }

}
updatebasicinfootpres(response){

  this.spinnerfull.hide()
  if(response.update_profile=='1000'){
    this.BasicInfoHide=false
this.basicotpShow=true;
  }else if(response.update_profile=='1017'){
    this.profileError = true;
    this.errorMessage = 'MOBILE_NUMBER_IS_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1018'){
    this.profileError = true;
    this.errorMessage = 'MOBILE_NUMBER_IS_NOT_VALID';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1019'){
    this.profileError = true;
    this.errorMessage = 'FIRST_NAME_IS_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1020'){
    this.profileError = true;
    this.errorMessage = 'LAST_NAME_IS_EMPTY';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1021'){
    this.profileError = true;
    this.errorMessage = 'SPECIAL_CHARACTERS_ARE_NOT_ALLOWED_IN_FIRST_NAME';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }else if(response.update_profile=='1022'){
    this.profileError = true;
    this.errorMessage = 'SPECIAL_CHARACTERS_ARE_NOT_ALLOWED_IN_lAST_NAME';
    setTimeout(() => {
      this.profileError = false;
    }, 3000);
  }
}
BasicInfoOtpSubmit(){
  this.submittedo=true;
  if(this.otpForm.valid){
    const object: any = {}
    object['mobileNumber'] = this.basicForm.value.mobileNo;
    object['firstName'] = this.basicForm.value.firstName;
    object['lastName'] = this.basicForm.value.lastName;
    object['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
     object['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId
     object['otp'] =this.otpForm.value.otp;
     this.spinnerfull.show()
     this.authService.basicInfoOtpSubmit(object,this.accesstoken).subscribe(response=>{
       this.basicInfoOtpSubmitResponse(response)
     }
      )

  }
  // else{
  //   this.profileError = true;
  //   this.errorMessage = 'OTP Required';
  //   setTimeout(() => {
  //     this.profileError = false;
  //   }, 3000);
  // }
}

basicInfoOtpSubmitResponse(response){
  (response)
  this.spinnerfull.hide()
  if(response.Token_Status=='1119'){
    if(response.update_profile=='1000'){
      this.basicinfo="Updated SucessFully"
      this.bacicprofilesucess = true;
      this.GetbasicProfile();
      setTimeout(() => {
        this.otpForm.reset();
        this.bacicprofilesucess= false;
        this.BasicInfoHide=true
        this.basicotpShow=false;
      }, 3000);


    
    }else  if(response.update_profile=='1001'){
      this.bacicprofileError = true;
          this.errorMessage = 'FAILURE';
          setTimeout(() => {
            this.bacicprofileError = false;
          }, 3000);
    }else  if(response.update_profile=='1090'){
      this.bacicprofileError = true;
          this.errorMessage = 'OTP_IS_EMPTY';
          setTimeout(() => {
            this.bacicprofileError = false;
          }, 3000);
    }else  if(response.update_profile=='1091'){
      this.bacicprofileError = true;
      this.errorMessage = 'OTP_SHOULD_BE_NUMERIC';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }else  if(response.update_profile=='1092'){
      this.bacicprofileError = true;
      this.errorMessage = 'OTP_LEANGTH_SHOULD_BE_4_DIGITS';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }else  if(response.update_profile=='1093'){
      this.bacicprofileError = true;
      this.errorMessage = 'OTP_IS_INVALID';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }else  if(response.update_profile=='1094'){
      this.bacicprofileError = true;
      this.errorMessage = 'OTP_EXPIRED';
      setTimeout(() => {
        this.bacicprofileError = false;
      }, 3000);
    }
     }else if(response.Token_Status=='1120'){
      this.bacicprofileError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.bacicprofileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.bacicprofileError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.bacicprofileError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);

    }
}
otpBack(){
  this.PersonalFormHide=true;
  this.otpShow=false;
}
otpBack1(){
  this.BankDetHide=true;
  this.bankotpShow=false;
}

otpBack2(){
  this.BasicInfoHide=true;
  this.basicotpShow=false;
}


}
