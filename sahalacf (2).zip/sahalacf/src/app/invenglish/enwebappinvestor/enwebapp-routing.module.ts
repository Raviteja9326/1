import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';
import { MaindashboardComponent } from './maindashboard/maindashboard.component';
import { OpportunitieslistComponent } from './opportunitieslist/opportunitieslist.component';
import { ReceivableComponent } from './receivable/receivable.component';
import { TransactionComponent } from './transaction/transaction.component';
import { InvestmentComponent } from './investment/investment.component';
import { InvestmentcritieriaComponent } from './investmentcritieria/investmentcritieria.component';
import { AllFundsComponent } from './all-funds/all-funds.component';
import { ProfileComponent } from './profile/profile.component';
import { EnwebappComponent } from './enwebapp.component';


const routes: Routes = [
    { path: 'webappmaindashboard', component: MaindashboardComponent },
  { path: 'webappopportunities', component: OpportunitieslistComponent },
  { path: 'webappreceivable', component: ReceivableComponent },
  { path: 'webapptransaction', component: TransactionComponent },
  { path: 'webappinvestment', component: InvestmentComponent },
  { path: 'webappinvestmentcritireia', component: InvestmentcritieriaComponent },
  {path:'webappallfunds',component:AllFundsComponent},
  { path: 'profile', component: ProfileComponent },
  { path: 'manageAccount', component: ManageaccountComponent },]









 
@NgModule({ 
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EngwebappRoutingModule { }
