import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NgxSpinnerService } from 'ngx-spinner';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { Router } from '@angular/router';
declare var Fingerprint2: any;
@Component({
  selector: 'app-receivable',
  templateUrl: './receivable.component.html',
  styleUrls: ['./receivable.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ReceivableComponent implements OnInit {

  displayedColumns: any = []
  dataSource;
  deviceInfo: any;
  investementsError: boolean;
  errorMessage: string;
  investorsList: any;
  data: any;
  acesstoken: any;
  tokenmessage = 'Your Session Has Expired, Please Login Here';

  investementError: boolean;
  accesstoken: any;
  getDeviceId: any;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private spinnerfull: NgxSpinnerService,private refresh:RefreshtokenService,private router:Router,
    private deviceService: DeviceDetectorService) {
      this. detectDevice();
      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      this.accesstoken = this.data.accesstoken;
   if(this.data!=null || this.data !=''){
     this.accesstoken = this.data.accesstoken;
   }
      
     } 

   

  ngOnInit(): void {

    new Fingerprint2().get((components) => {
     
      this.getDeviceId = components;
     
      this.getreceivables(this.getDeviceId);
     
    })
    console.log(this.getDeviceId)
   

    this.displayedColumns = ['LoanApplication', 'Date', 'InvestedAmount', 'ProfitAmount','LoanTensure', 'ROI', 'LoanStatus'];
  }
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    
  }

 
  getreceivables(getDeviceId){
    this. detectDevice();
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    this.accesstoken = this.data.accesstoken;
 if(this.data!=null || this.data !=''){
   this.accesstoken = this.data.accesstoken;
 }
    const object: any = {}
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    object['device_id'] = getDeviceId
    object['pageNumber'] = '0'
    object['pageSize'] = '100'
    //  object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'

this.spinnerfull.show()
   this.authService.getreceivables(this.accesstoken,object).subscribe(response=>
    this.getInvestementsResponse(response)
    )
  }
  
  getInvestementsResponse(response){
   console.log(response)
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){

      if(response.investers_response=='1126'){

this.investorsList=response.receivable_list;

this.dataSource = this.investorsList
      }
    }
      
      
      if(response.Token_Status=='1119'){
      
       if(response.investers_response=='1127'){ 
        this.investorsList = [];
        this.dataSource = this.investorsList

        this.investementError = true;
        this.errorMessage = 'No Data Available';
        setTimeout(() => {
          this.investementError = false;
        }, 3000000);
      }else if(response.investers_response=='1002'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1003'){
        
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

      }else if(response.investers_response=='1004'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1005'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1006'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1007'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1008'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1009'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1010'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1011'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1012'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1013'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1015'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1016'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);

        
      }else if(response.investers_response=='1150'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }else if(response.investers_response=='1151'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }else if(response.investers_response=='1152'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }else if(response.investers_response=='1153'){
        this.investementError = true;
        this.errorMessage = 'SOME THING WENT WRONG';
        setTimeout(() => {
          this.investementError = false;
        }, 3000);
      }
    }else if(response.Token_Status=='1120'){
       this.investementsError = true;
      this.errorMessage = '';
    
      
      setTimeout(() => {
        this.investementsError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }else if(response.Token_Status=='1121'){
      this.investementsError = true;
      this.errorMessage = '';
     
      setTimeout(() => {
        this.investementsError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }
  }

}
