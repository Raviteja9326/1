import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';



@Component({
  selector: 'app-all-funds',
  templateUrl: './all-funds.component.html',
  styleUrls: ['./all-funds.component.scss'],
  encapsulation: ViewEncapsulation.Emulated

})
export class AllFundsComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol','status','product'];

  displayedColumns1: string[] = ['position', 'name', 'weight', 'symbol','status','product'];
 
  displayedColumns2: string[] = ['position', 'name', 'weight', 'symbol','status','product'];

  deviceInfo: any;
  accesstoken: any;
  FundsList: any;
  errorMessage: string;
  tokenmessage = 'Your Session Has Expired, Please Login Here';
  fundsError: boolean;
  data: any;
  constructor(private fb: FormBuilder,private authService:AuthService,private deviceinfoservice:DeviceinfoserviceService,
    private spinnerfull: NgxSpinnerService,private router:Router,private refresh:RefreshtokenService,
    private deviceService: DeviceDetectorService) {

      this.data = JSON.parse(sessionStorage.getItem('currentUser'));
      if(this.data!=null || this.data !=''){
        this.accesstoken= this.data.accesstoken;
      }
     const object1:any={}
     object1['index']='0'
     this. GetActiveFunds(object1);
     }

  ngOnInit(): void {
  
  }

 
  public detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  
  }
  GetActiveFunds(tab){
   
    this.detectDevice();

const object: any = {}
if(tab.index=='0'){
  object['fund_type']='ActiveFunds'
}else if(tab.index=='1'){
  object['fund_type']='SuccessfulFunds'
}else if(tab.index=='2'){
  object['fund_type']='RejectedFunds'
}

   
    object['browser_type'] = this.deviceInfo.browser;
    object['browser_version'] = this.deviceInfo.browser_version;
    object['ip_address'] = this.deviceinfoservice.deviceinfo.ipAdress;
    object['os_version'] = this.deviceInfo.os_version;
    object['os_type'] = this.deviceInfo.os;
    object['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
    object['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
    object['language'] = 'en';
    //object['device_id'] = this.deviceinfoservice.deviceinfo.deviceId
    object['page_number'] = '0'
    object['page_size'] = '20';
   
    object['device_id'] = '7b5014df8e2f845e671d4dc8af3614e4'
 
   this.spinnerfull.show()
    this.authService.getactiveFunds(object,this.accesstoken).subscribe(response=>
      this.getActiveFundsRes(response))
  }
  
  getActiveFundsRes(response){
  
    this.spinnerfull.hide()
    if(response.Token_Status=='1119'){
      if(response.all_funds_status=='1126'){
        this.FundsList=response.all_funds_list;

      }else if(response.all_funds_status=='1127'){
        this.fundsError = true;
        this.errorMessage = 'No Data Available';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1002'){
        this.fundsError = true;
  this.errorMessage = 'SOMETHING_WENT_WRONG';
  setTimeout(() => {
    this.fundsError = false;
  }, 3000);
      }else if(response.all_funds_status=='1003'){
        
      }else if(response.all_funds_status=='1004'){
        
      }else if(response.all_funds_status=='1005'){
        
      }else if(response.all_funds_status=='1006'){
        
      }else if(response.all_funds_status=='1007'){
        
      }else if(response.all_funds_status=='1008'){
        
      }else if(response.all_funds_status=='1009'){
        
      }else if(response.all_funds_status=='1010'){
        
      }else if(response.all_funds_status=='1011'){
        
      }else if(response.all_funds_status=='1012'){
        
      }else if(response.all_funds_status=='1015'){
        
      }else if(response.all_funds_status=='1016'){
        this.fundsError = true;
      this.errorMessage = '';
      setTimeout(() => {
        this.fundsError = false;
      }, 3000);
      }else if(response.all_funds_status=='1150'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1151'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1152'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1153'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1154'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }else if(response.all_funds_status=='1155'){
        this.fundsError = true;
        this.errorMessage = '';
        setTimeout(() => {
          this.fundsError = false;
        }, 3000);
      }
    }else  if(response.Token_Status=='1120'){
      this.fundsError = true;
     // this.errorMessage = 'UNAUTHORIZED';
     
      setTimeout(() => {
        this.fundsError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }else  if(response.Token_Status=='1121'){
      this.fundsError = true;
     // this.errorMessage = 'TOKEN_EXPIRED';
     
      setTimeout(() => {
        this.fundsError = false;
        this.refresh.unAuthorize(this.tokenmessage)
        this.router.navigate(['/home'])
        sessionStorage.clear()
      }, 3000);
    }
  }
}
