import { Component, OnInit, Inject } from '@angular/core';
import { Router} from '@angular/router';
import * as $ from "jquery";
import { DeviceinfoserviceService } from 'src/app/shared/deviceinfoservice.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AuthService } from 'src/app/services/auth.service';
import { WithrawdialogeComponent } from 'src/app/withrawdialoge/withrawdialoge.component';
import PerfectScrollbar from 'perfect-scrollbar';
import { RefreshtokenService } from 'src/app/services/refreshtoken.service';
import { DocumentComponent } from '../enwebappinvestor/dashboard/dashboard.component';
declare var $ : any
declare interface ROUTES {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const ROUTES = [];

@Component({
  selector: 'app-invengsidenav',
  templateUrl: './invengsidenav.component.html',
  styleUrls: ['./invengsidenav.component.scss']
})
export class InvengsidenavComponent implements OnInit {
  panelOpenState = false;
  user: any;
  name: any;
  data:any;
  registrationid: any;
  profileStatus: string;
  balance: any;
  withdrawUser: any;
  profilestatuserrmsg:any
  accesstoken: any;
  deviceInfo: any;
  errormsg: string;
  isEnabled: boolean;
  disabled = false;
  sessiondata: any;

  constructor(public dialog: MatDialog,private router:Router,private auth:AuthService,
    private deviceinfoservice:DeviceinfoserviceService,private deviceService:DeviceDetectorService,
    private token:RefreshtokenService) {

      this.user = JSON.parse(sessionStorage.getItem('currentUser'))

      this.accesstoken = this.user.accesstoken;


     
      this.detectDevice()
  
      this.name=this.user.FirstName 
      this.registrationid=this.user.id
   


      // if(this.user.isBankAccountLetterUploaded == 'No') {
      //   this.disabled = true;
      // }
      // if(this.user.isBankAccountLetterUploaded == 'Yes') { 
      //   console.log('enable')
      //   this.disabled = false;
      // }

      // if(this.user.isBankAccountLetterUploaded = 'Yes') {
      //   this.disabled = false
      // }




    this.detectDevice()
     // if( this.user.profileStatus=='1197'){
     //   this.profileStatus="Pending for Approval"
     //    }else if( this.user.profileStatus=='1196'){
     //     this.profileStatus="Approved"
     //      }
    
  
// this.routerallfundsgetbalance();
// this.routerdashboardgetbalance();
// this.routerinvestgetbalance();
// this.routermanage()
// this.routeropeergetbalance()
// this.routerprofile();
// this.routertransgetbalance();
// this.routeropeergetbalance();


    }
 


    ngOnInit(): void {
      this.grtbalancedetails()
          
          history.pushState(null, null, location.href);
          window.onpopstate = function () {
              history.go(1);
          };
          $(".nav li").click(function(){ $(".collapse").collapse('hide'); });
          
          $('.nav-container').addClass('expand');
          
           $('.nav-container ul li a').on('click', function () {
                  $('.nav-container ul .active').removeClass('active');
                 $(this).addClass('active');
           });
          $('.menu-icon').click(function () {
           
            $('.nav-section').addClass('expand');
            $('.main-section').toggleClass('expand');
      
          });
           $('.nav-section ul li a').on('click', function () {
            $('.nav-section ul .active').removeClass('active');
           $(this).addClass('active');
        });
      
        $("#menu-close").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
      
        });
        $("#sidebar-wrapper .dashboard ").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
      
        });
      
      
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
        });

        
      
        
        }



        public detectDevice() {
          this.deviceInfo = this.deviceService.getDeviceInfo();
          console.log(this.deviceInfo)
        }





        routerdashboardgetbalance() {

          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))


  if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

    const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
      width: '650px',
      height:'auto',
  
  
  
    }); 
  
}

else {
  this.router.navigate(['/englishwebapp/webappdashboard'])
}



          this.grtbalancedetails();

        }

 
        routeropeergetbalance() {

          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

  const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
    width: '650px',
    height:'auto',



  }); 

 

}

else {

  console.log('routeeeeeee')
  this.router.navigate(['/englishwebapp/webappopportunities'])
}



          this.grtbalancedetails();

        }
        

        routerreceivegetbalance() {

          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

  const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
    width: '650px',
    height:'auto',



  });

}

else {

  console.log('routeeeeeee')
  this.router.navigate(['/englishwebapp/webappreceivable'])
}



          this.grtbalancedetails();

        }
        
        routertransgetbalance() {

          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

  const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
    width: '650px',
    height:'auto',



  });

}

else {

  console.log('routeeeeeee')
  this.router.navigate(['/englishwebapp/webapptransaction'])
}



          this.grtbalancedetails();

        }
        
        routerinvestgetbalance() {

          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

  const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
    width: '650px',
    height:'auto',



  });

}

else {

  console.log('routeeeeeee')
  this.router.navigate(['/englishwebapp/webappinvestment'])
}



          this.grtbalancedetails();

        }
        

        routerallfundsgetbalance() {

          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

if(this.sessiondata.isBankAccountLetterUploaded == 'No') {

  const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
    width: '650px',
    height:'auto',



  });

}

else {

  console.log('routeeeeeee')
  this.router.navigate(['/englishwebapp/webappallfunds'])
}



          this.grtbalancedetails();

        }
        

        routerprofile() {
          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

          if(this.sessiondata.isBankAccountLetterUploaded == 'No') {
          
            const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
              width: '650px',
              height:'auto',
          
          
          
            });
          
          }
          
          else {
          
            console.log('routeeeeeee')
            this.router.navigate(['/englishwebapp/profile'])
          }

        }



        routermanage() {
          this.sessiondata = JSON.parse(sessionStorage.getItem('currentUser'))

          if(this.sessiondata.isBankAccountLetterUploaded == 'No') {
          
            const dialogRef = this.dialog.open(DocumentComponent,  {disableClose: true,
              width: '650px',
              height:'auto',
          
          
          
            });
          
          }
          
          else {
          
            console.log('routeeeeeee')
            this.router.navigate(['/englishwebapp/manageAccount'])
          }

        }
        
        reqwrdialogfun(){

          this.withdrawUser =JSON.parse(sessionStorage.getItem('currentUserbalance'))
          
            if(this.withdrawUser.profileStatus === "1197"){
              this.profilestatuserrmsg ="Profile Status is Pending"
              const dialogRef = this.dialog.open(ProfilestatusComponent, {
                width: '250px',
                data:this.profilestatuserrmsg
          
          
              });
              dialogRef.afterClosed().subscribe(result => {
                
          
              })
             
        
            }
            else  if (this.withdrawUser.balance === "0.0"){
              this.profilestatuserrmsg ="Balance is not available to  withdraw."
            
              const dialogRef = this.dialog.open(ProfilestatusComponent, {
                width: '250px',
                data:this.profilestatuserrmsg
          
          
              });
              dialogRef.afterClosed().subscribe(result => {
                
          
              })
            }
        
            else  {
              
        
            
            const dialogRef = this.dialog.open(WithrawdialogeComponent, {
              panelClass: 'custom-dialog-container',
              disableClose: true,
              width: '60%',
              height:'500px',
              data:this.withdrawUser
        
        
            });
        
            dialogRef.afterClosed().subscribe(result => {
        
        
            });
          }
          }
         ngAfterViewinit() {
           $('.nav-section').addClass('expand');
        
        
        
           $('.nav-container').addClass('expand');
           $('.nav-container ul li a').on('click', function () {
                  $('.nav-container ul .dash').removeClass('active');
                 $(this).addClass('active');
           });
          $('.menu-icon').click(function () {
           
            $('.nav-section').addClass('expand');
            $('.main-section').toggleClass('expand');
        
          });
           $('.nav-section ul li a').on('click', function () {
            $('.nav-section ul .active').removeClass('active');
           $(this).addClass('active');
        });
        
        $("#menu-close").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
        
        });
        $("#sidebar-wrapper .dashboard ").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
        
        });
        
        
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#sidebar-wrapper").toggleClass("active");
        });
        
         }
        
         
        
        
            
          // const dialogRef = this.dialog.open(DeleteComponent, {
          //   width: '250px',
          //   data:{id:id,dataSource:this.merchantRulesList}
        
        
          // });
          // dialogRef.afterClosed().subscribe(result => {
          //   this.merchantRulesdata()
        
          // });
        
        
        //  grtbalancedetails() {
        // console.log('navya')
        //    this.auth.getbalanceinfo(this.user.accesstoken,this.data).subscribe(res =>{
        //      console.log(res)
        
        //      if(res.Token_Status == '1119') {
        //        this.balance = res.balance; 
        //        if(  res.profile_status=='1197'){
        //         this.profileStatus="Pending for Approval"
        //          }else if( res.profile_status=='1196'){
        //           this.profileStatus="Approved"
        //            }
        //      }
        
        //    })
        //  }
        grtbalancedetails() {
          console.log('navya')


          this.user = JSON.parse(sessionStorage.getItem('currentUser'))
    
          this.accesstoken = this.user.accesstoken;
          this.name=this.user.FirstName
          this.registrationid=this.user.id
          console.log(this.user.accesstoken)

             this.auth.getbalanceinfo(this.user.accesstoken,this.data).subscribe(res =>{
              
          
               if(res.Token_Status == '1119') {
                 this.balance = res.balance;  
                 if(  res.profile_status=='1197'){
                  this.profileStatus="Pending For Approval"
                   }else if( res.profile_status=='1196'){
                    this.profileStatus="Approved"
                     }
               }
          
              
          
                //  const object2: any = {}
                //  object2['profileStatus']=  res.profile_status
                //  object2['balance'] = res.balance
        
                
                //  sessionStorage.setItem('currentUserbalance',JSON.stringify(object2))
          


                 this.token.changebalance(res)
          
             })
          
             
           }
        
           
           logout(){
            // console.log("logout++++++++++++++")
            const obj :any ={}
            obj['iPAddress'] = this.deviceinfoservice.deviceinfo.ipAdress;
            obj['longitude'] = this.deviceinfoservice.deviceinfo.logintude;
            obj['latitude'] =  this.deviceinfoservice.deviceinfo.latitude;
            obj['deviceId'] = this.deviceinfoservice.deviceinfo.deviceId;
            // console.log(obj)
            this.auth.logout(obj,this.accesstoken).subscribe(res =>{
            console.log(res)
              sessionStorage.clear();
        
             // this.router.navigate(['/home'])
              if(res.Token_Status =='1119'){
                if(res.logout_response == '1000') {
                  sessionStorage.clear();
        
                //  this.router.navigate(['/home'])
                }
        
                else if(res.logout_response == '1001'){
                  this.errormsg = 'SOMETHING WENT WRONG'
                }
                else if(res.logout_response == '1011'){
        this.errormsg = 'SOMETHING WENT WRONG'
                }
                else if(res.logout_response == '1012'){
        
                  this.errormsg = 'SOMETHING WENT WRONG'
                }
              }
        
              else if(res.Token_Status =='1120'){
                this.errormsg = 'UNAUTHORIZED'
              }
              else if(res.Token_Status =='1121'){
                this.errormsg = 'TOKEN EXPIRED'
              }
             
        
        
        
        
            })
         
          }
        
          
        
          menuopen() {
        
            
            $('.nav-section').addClass('expand');
             $('.nav-section ul li a').on('click', function () {
                    $('.nav-section ul .active').removeClass('active');
                   $(this).addClass('active');
             });
            $('.menu-icon').click(function () {
             
              $('.nav-section').addClass('expand');
              $('.main-section').toggleClass('expand');
        
            });
             $('.nav-section ul li a').on('click', function () {
              $('.nav-section ul .active').removeClass('active');
             $(this).addClass('active');
          });
        
          $("#menu-close").click(function(e) {
            e.preventDefault();
            $("#sidebar-wrapper").toggleClass("active");
        
          });
          $("#sidebar-wrapper .dashboard ").click(function(e) {
            e.preventDefault();
            $("#sidebar-wrapper").toggleClass("active");
        
          });
        
        
          $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar-wrapper").toggleClass("active");
          });
        
          }
        
          close() {
            $("#menu-close").click(function(e) {
              e.preventDefault();
              $("#sidebar-wrapper").toggleClass("active");
          
            });
          }
        
        
          closenav(){
            
            $("#sidebar-wrapper .dashboard ").click(function(e) {
              e.preventDefault();
              $("#sidebar-wrapper").toggleClass("active");
          
            });
        
        
          }
        }
        
        
        @Component({
          selector: 'app-profilestatus',
          template: `
          <div style="display: flex;justify-content: space-between;">
            <h2></h2>
        <div  style="cursor:pointer;">
        <i class="fa fa-times" aria-hidden="true"   (click)="onNoClick()"></i>
        </div>
            </div>
          <div class="row">
          <div class="col-lg-12">
        <div class="row" style="padding-left: 15px;">
        {{profilestatuserrmsg}}
        </div>
        
        
        
        
        
        
        </div>
        
        
        
          `
        })
        export class ProfilestatusComponent implements OnInit {
          profilestatuserrmsg: any;
        
         
        
          constructor(
            public dialogRef: MatDialogRef<ProfilestatusComponent>,@Inject(MAT_DIALOG_DATA) public data: any
           
           
            // @Optional() @Inject(MAT_DIALOG_DATA) public data: dataSource
          ) {
            
            this.profilestatuserrmsg=data
          }
        
        
          ngOnInit() {
            
        
          }
          onNoClick() {
           
            this.dialogRef.close(); 
          }
        
          
        
          
        }
 

 










  

 


  


 