import { Component, OnInit } from '@angular/core';
import { style } from '@angular/animations';
declare var $: any;
@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.scss']
})
export class AboutusComponent implements OnInit {
  sign: boolean;

  constructor() {


   }

  ngOnInit(): void { 
    
    $('.menu-icon').click(function () {
     
      $('.nav-section').addClass('expand');
      $('.main-section').toggleClass('expand');

    });
    $('.nav-section ul li a').on('click', function () {
      $('.nav-section ul .active').removeClass('active');
     $(this).addClass('active');
 });

  }
link() {
  console.log('fjklsdjfkl')
  $("#but").on("click",function() {
    $("#foo").scrollTop(0);
  })
  
}
  
  signup(){
    this.sign = !this.sign;   
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }

  
   openNav() {
    document.getElementById("mySidenav").style.width = "450px";
  }
  
   closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }
 
}
