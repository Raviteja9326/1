import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.scss']
})
export class TermsComponent implements OnInit {
  sign: any;

  constructor() { }

  ngOnInit(): void {
  }

  signup(){
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }
}
