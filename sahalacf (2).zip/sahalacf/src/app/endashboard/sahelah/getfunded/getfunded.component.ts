import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getfunded',
  templateUrl: './getfunded.component.html',
  styleUrls: ['./getfunded.component.scss']
})
export class GetfundedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
