import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { CreditComponent } from './credit/credit.component';
import { ExploreComponent } from './explore/explore.component';
import { FaqComponent } from './faq/faq.component';
import { GetfundedComponent } from './getfunded/getfunded.component';
import { PolicyComponent } from './policy/policy.component';
import { TermsComponent } from './terms/terms.component';
import {MatExpansionModule} from '@angular/material/expansion';

import { FooterComponent } from './footer/footer.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { GetfinancingComponent } from './getfinancing/getfinancing.component';

 
const routes: Routes = [
 // { path: '', redirectTo: 'endashboard', pathMatch: 'full ' },
  // { path: 'dashboard', component: DashboardComponent },
  // {path:'aboutus',component:AboutusComponent},
  // {path:'contacts',component:ContactusComponent},
  // {path:'credits',component:CreditComponent},
  // {path:'exploring',component:ExploreComponent},
  // {path:'frequently',component:FaqComponent},
  // {path:'getfunded',component:GetfundedComponent},
  // {path:'policy',component:PolicyComponent},
  // {path:'termsandcon',component:TermsComponent},
  // {path:'getfinancing',component:GetfinancingComponent}
];
 
@NgModule({
  declarations: [DashboardComponent, 
    AboutusComponent,
    ContactusComponent, 
    
    CreditComponent,
    ExploreComponent,
    FaqComponent,
    GetfundedComponent,
    PolicyComponent,
    TermsComponent,
    FooterComponent,
    GetfinancingComponent],
  imports: [
    CommonModule,
    MatFormFieldModule ,
    MatInputModule,
    MatExpansionModule,
    RouterModule.forChild(routes)
  ]
})
export class EndashboardModule { }
