import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.scss']
})
export class ContactusComponent implements OnInit {
  sign: boolean;

  constructor() { }

  ngOnInit(): void {
  } 

  signup(){
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }
  
  openNav() {
    document.getElementById("mySidenav").style.width = "450px";
  }
  
   closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }
}
