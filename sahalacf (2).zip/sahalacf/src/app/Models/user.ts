export interface User {
    email: string;
    password: string;
    deviceId: string;
    deviceType: string;
    deviceService: string;
    latitude: string;
    logintude: string;
    longitude: string;
    ipAdress: string;
    browserType:string;
    browserVersion:string;
    osType:string;
    osVersion:string;
    iPAddress:string;
    language:string;
    otp:string;
  
  }
  export interface ForgotUser {
    email: string;
  
    deviceId: string;
    deviceType: string;
    deviceService: string;
    latitude: string;
    otp:string;
    longitude: string;
    ipAddress: string;
    browserType:string;
    browserVersion:string;
    osType:string;
    osVersion:string;
    countryCode:string;
    language:string;
    newPassword:string;
    conformPassword:string;
  
  
  }