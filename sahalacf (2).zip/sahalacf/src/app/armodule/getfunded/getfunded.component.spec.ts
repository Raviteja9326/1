import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetfundedComponent } from './getfunded.component';

describe('GetfundedComponent', () => {
  let component: GetfundedComponent;
  let fixture: ComponentFixture<GetfundedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetfundedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetfundedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
