import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {
  panelOpenState = false;
  sign: any;
  constructor() { }

  ngOnInit(): void {
  }

  signup(){
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }

}
