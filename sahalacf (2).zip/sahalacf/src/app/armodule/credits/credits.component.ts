import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credits',
  templateUrl: './credits.component.html',
  styleUrls: ['./credits.component.scss']
})
export class CreditsComponent implements OnInit {
  sign: any;

  constructor() { }

  ngOnInit(): void {
  }

  signup(){
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }

}
 