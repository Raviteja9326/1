import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CreditsComponent } from './credits/credits.component';
import { PolicyComponent } from './policy/policy.component';
import { ExploreComponent } from './explore/explore.component';
import { GetfundedComponent } from './getfunded/getfunded.component';
import { TermsComponent } from './terms/terms.component';
import { FaqComponent } from './faq/faq.component';
import { FooterComponent } from './footer/footer.component';
import { ContactusComponent } from './contactus/contactus.component';
import {MatExpansionModule} from '@angular/material/expansion';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { GetfinancingComponent } from './getfinancing/getfinancing.component';


const routes: Routes = [
 // { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  // {path:'aboutus',component:AboutusComponent},
  // {path:'credits',component:CreditsComponent}, 
  // {path:'privacypolicy',component:PolicyComponent},
  // {path:'explore',component:ExploreComponent},
  // {path:'getfund',component:GetfundedComponent},   
  // {path:'termsandcon',component:TermsComponent},
  // {path:'faq',component:FaqComponent},
  // {path:'contactus',component:ContactusComponent},
  // {path:'getfinance',component:GetfinancingComponent}
 // { path: 'dashboard', loadChildren: () => import('../armodule/dashboard/dashboard.module').then(m => m.DashboardModule) }
];

@NgModule({
  declarations: [FooterComponent,AboutusComponent,
    CreditsComponent,
    PolicyComponent,
    ExploreComponent,
    GetfundedComponent,
    FaqComponent,
    TermsComponent,
    ContactusComponent,
    GetfinancingComponent




   ],
  imports: [
    CommonModule,
    MatFormFieldModule ,
    MatInputModule,
    MatExpansionModule,
    RouterModule.forChild(routes)
  ]
})
export class ArmoduleModule { }
