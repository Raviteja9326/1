import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getfinancing',
  templateUrl: './getfinancing.component.html',
  styleUrls: ['./getfinancing.component.scss']
})
export class GetfinancingComponent implements OnInit {
  panelOpenState = false;
  sign: any;
  constructor() { }

  ngOnInit(): void {
  }

  signup(){
    this.sign = !this.sign;
    if(this.sign){
    this.sign = true;
    } else {
      this.sign = false;
    }
  }

}
