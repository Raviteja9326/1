import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetfinancingComponent } from './getfinancing.component';

describe('GetfinancingComponent', () => {
  let component: GetfinancingComponent;
  let fixture: ComponentFixture<GetfinancingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetfinancingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetfinancingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
