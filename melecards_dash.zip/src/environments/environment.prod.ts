export const environment = {
  production: true,
  baseUrl:"https://apigw.melecards.com"
};
