import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgxPageScrollCoreModule } from 'ngx-page-scroll-core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxUiLoaderConfig, NgxUiLoaderModule, SPINNER, POSITION,PB_DIRECTION, NgxUiLoaderRouterModule, NgxUiLoaderService } from 'ngx-ui-loader';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';
import { NgOtpInputModule } from  'ng-otp-input';
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import { UserIdleModule } from 'angular-user-idle';
import { ConfirmDialogModule } from './english/general/dialgoue/confirm-dialog.module';
import { LoginComponent } from './english/general/login/login.component';
import { RegisterComponent } from './english/general/register/register.component';
import { ForgotComponent } from './english/general/forgot/forgot.component';
import { UserComponent } from './english/user/user.component';
import { GeneralModule } from './english/general/general.module';
import { ErrorInterceptor } from './services/error.interceptors';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ToastrModule, ToastrService } from "ngx-toastr";
import { ArLoginComponent } from './arabic/general/login/arlogin.component';
import { ArRegisterComponent } from './arabic/general/register/arregister.component';
import { ArUserComponent } from './arabic/user/aruser.component';
import { ArGeneralModule } from './arabic/general/argeneral.module';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { PrivacyComponent } from './english/general/privacy/privacy.component';
import { RiskComponent } from './english/general/risk/risk.component';
import { TermsComponent } from './english/general/terms/terms.component';
import { AmlComponent } from './english/general/aml/aml.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
}

const ngxUiLoaderConfig: NgxUiLoaderConfig =
{
  "bgsColor": "#a36328",
  "bgsOpacity": 0.5,
  "bgsPosition": "center-center",
  "bgsSize": 60,
  "bgsType": "cube-grid",
  "blur": 5,
  "delay": 0,
  "fastFadeOut": true,
  "fgsColor": "#a36328",
  "fgsPosition": "center-center",
  "fgsSize": 60,
  "fgsType": "cube-grid",
  "gap": 24,
  "logoPosition": "center-center",
  "logoSize": 120,
  "logoUrl": "",
  "masterLoaderId": "master",
  "overlayBorderRadius": "0",
  "overlayColor": "rgba(40, 40, 40, 0.8)",
  "pbColor": "#a36328",
  "pbDirection": "ltr",
  "pbThickness": 3,
  "hasProgressBar": true,
  "text": "",
  "textColor": "#FFFFFF",
  "textPosition": "center-center",
  "maxTime": -1,
  "minTime": 300
}

@NgModule({
  declarations: [
    PrivacyComponent,
    RiskComponent,
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ForgotComponent,
    UserComponent,
    ArLoginComponent,
    ArRegisterComponent,
    ArUserComponent,
    TermsComponent,
    AmlComponent
  ],
  imports: [
    InfiniteScrollModule,
    
    NgOtpInputModule,
    NgxIntlTelInputModule,
    ConfirmDialogModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgxUiLoaderRouterModule,
    NgxPageScrollCoreModule.forRoot({ duration: 1600 }),
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    ArGeneralModule,
    GeneralModule,
    UserIdleModule.forRoot({idle: 180,timeout: 3}),
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: "toast-top-right",
      preventDuplicates: true,
      closeButton: false,
      newestOnTop: true,
      extendedTimeOut: 1000
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [ToastrService,{
    provide: HTTP_INTERCEPTORS,
    useClass: ErrorInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
