import { Component, OnInit, ElementRef } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-aruser',
  templateUrl: './aruser.component.html',
  styleUrls: ['./aruser.component.scss']
})
export class ArUserComponent implements OnInit {
  better:any;
  balance:any=[];
  constructor(private elementRef: ElementRef,private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private user:UserService) {this.getbalance()}

  ngOnInit(): void {
    var s1 = document.createElement("script");
    s1.type = "text/javascript";
    s1.src = "../assets/js/scripts.js";
    this.elementRef.nativeElement.appendChild(s1);
  }

  getbalance(){
    this.ngxLoader.start();
    this.user.userbalance()
    .pipe(first())
    .subscribe((res:any) => {
      //console.log(res)
      if(res['status']=='1001' ){
         this.apis.balance= res.totalBalance;
        
      }
      else if(res['status']){
        this.apis.getallres = res['status'] ;
         this.better = this.apis.allrespnse();
         this.confirmDialogService.confirmThis(this.better)  
         //console.log(this.better)
         this.ngxLoader.stop()
      }
    })
    .add(() => this.ngxLoader.stop());
  }

}
