import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ArUserDashboardModule } from './dashboard/ardashboard.module';
import { Aruserroutes } from './aruser-routing.module';
import { ArHomeComponent } from '../general/home/arhome.component';
import { ConfirmDialogModule } from 'src/app/english/general/dialgoue/confirm-dialog.module';


@NgModule({
  imports: [
    CommonModule,
    ConfirmDialogModule,
    ArUserDashboardModule,

    RouterModule.forChild(Aruserroutes)
  ],
  declarations: [ArHomeComponent]
})
export class ArUserModule { }
