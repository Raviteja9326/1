import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Aruserdashboardroutes } from './ardashboard-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ArGeneralModule } from '../../general/argeneral.module';
import { ArHistoryComponent } from './history/arhistory.component';
import { ArProfiledetailsComponent } from './profiledetails/arprofiledetails.component';
import { ArRedeemComponent } from './redeem/arredeem.component';
import { ArDashboardComponent } from './ardashboard.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ConfirmDialogModule } from 'src/app/english/general/dialgoue/confirm-dialog.module';
import { NgxMaskModule } from 'ngx-mask';


@NgModule({
  imports: [
    NgxMaskModule.forRoot({
      showMaskTyped : false,
      // clearIfNotMatch : true
    }),
    InfiniteScrollModule,
    FormsModule,
    ConfirmDialogModule,
    ReactiveFormsModule,
    HttpClientModule,
    CommonModule,
    ArGeneralModule,
    RouterModule.forChild(Aruserdashboardroutes)
  ],
  declarations: [ArDashboardComponent,ArHistoryComponent,ArProfiledetailsComponent,ArRedeemComponent ]
})
export class ArUserDashboardModule { }
