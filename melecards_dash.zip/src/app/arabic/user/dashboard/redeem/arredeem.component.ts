import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { ResponseService } from 'src/app/services/response.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { BalanceService } from 'src/app/services/balance.service';
import { ToastrService } from 'ngx-toastr';
declare var $:any;

@Component({
  selector: 'app-arredeem',
  templateUrl: './arredeem.component.html',
  styleUrls: ['./arredeem.component.scss']
})
export class ArRedeemComponent implements OnInit {
  submitted = false;
  better: any;
  balance: any;
  converstion:any=[];
  public customPatterns = { '0': { pattern: new RegExp('\[a-zA-Z0-9\]')} };
  constructor(private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private userbala:BalanceService, private toastr:ToastrService) { 
this.GetconverstionData()
  }

  @ViewChild("myinput3") myInputField: ElementRef;
ngAfterViewInit() {
this.myInputField.nativeElement.focus();
window.scrollTo(0, 0)
}

  ngOnInit(): void 
   {
   }
 
  UserRedeemForm = this.formBuilder.group({
    redeemCode: ['',[Validators.required,Validators.minLength(16), Validators.maxLength(16),]]
  })

  get reedmeControllers() 
  { return this.UserRedeemForm.controls }

  changlagar(){
    this.apis.catchlang = 'en'
  }

  createredeem(){

    if (!this.UserRedeemForm.valid) {
      Object.keys(this.UserRedeemForm.controls).forEach(field => {
        const control:any = this.UserRedeemForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }
   
 else {   
          this.ngxLoader.start();
          this.userService.userRedeem(this.UserRedeemForm.value)
          .pipe(first())
          .subscribe((res:any) => {
            //console.log("asdsa",res.meleCoins)
            if(res['status']=='1001' && res['tokenStatus']=='1039'){
              //console.log("asdsa",res.meleCoins)
              this.confirmDialogService.confirmThis("بنجاح"+'\n'+res.meleCoins+'\n'+"تمت إضافة Melecoins");
              this.apis.setTitless(res.meleCoins); 
              this.UserRedeemForm.reset();
            }
           else if(res['status']=='1040' || res['tokenStatus']=='1040'){
              this.better = "Your Session Has Expired";
              this.apis.nextMessage("default message")
              this.toastr.error('مرحبًا ، انتهت جلستك');
              this.ngxLoader.stop();
              this.router.navigate(['/ArLogin'])
            }
            else if(res['status']=='1047'){
               this.ngxLoader.stop()
            }
            else if(res['status']){
              this.apis.getallres = res['status'] ;
               this.better = this.apis.allrespnsear();
               this.confirmDialogService.confirmThis(this.better)  
               //console.log(this.better)
               this.ngxLoader.stop();
            }
          })
          .add(() => this.ngxLoader.stop());
  
        }
      }

        GetconverstionData(){
          this.userService.userconvestion()
          .pipe(first())
          .subscribe((res:any) => {
            console.log(res);
            if(res['status']=='1001' && res['tokenStatus']=='1039'){
              this.converstion= res; 
            }
            else if(res['status']=='1040' || res['tokenStatus']=='1040'){
              this.better = "Your Session Has Expired";
              this.apis.nextMessage("default message")
              this.toastr.error('Your Session Expired');
              this.ngxLoader.stop();
              this.router.navigate(['/Login'])
            }
            else if(res['status']=='1047'){
               this.ngxLoader.stop()
            }
            else if(res['status']){
              this.apis.getallres = res['status'] ;
               this.better = this.apis.allrespnse();
               this.confirmDialogService.confirmThis(this.better)  
               //console.log(this.better)
               this.ngxLoader.stop();
            }
         
          })
          .add(() => this.ngxLoader.stop());
      }
}
