import { Routes } from '@angular/router';
import { ArDashboardComponent } from './ardashboard.component';
import { ArHistoryComponent } from './history/arhistory.component';
import { ArProfiledetailsComponent } from './profiledetails/arprofiledetails.component';
import { ArRedeemComponent } from './redeem/arredeem.component';

export const Aruserdashboardroutes: Routes = 
[
  { path: '', component: ArDashboardComponent,
  children: [
  { path: 'ArRedeemCoupon', component: ArRedeemComponent },
  { path: 'ArProfile', component: ArProfiledetailsComponent },
  { path: 'ArHistory', component: ArHistoryComponent },
  ]}
];

