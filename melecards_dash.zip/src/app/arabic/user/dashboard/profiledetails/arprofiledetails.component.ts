import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchCountryField, CountryISO } from 'ngx-intl-tel-input';
import { UserService } from 'src/app/services/user.service';
import { ResponseService } from 'src/app/services/response.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ToastrService } from 'ngx-toastr';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
      const control = updateforgotpasswordform.controls[controlName];
      const matchingControl = updateforgotpasswordform.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}
export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-arprofiledetails',
  templateUrl: './arprofiledetails.component.html',
  styleUrls: ['./arprofiledetails.component.scss']
})
export class ArProfiledetailsComponent implements OnInit {
  profiledata:any=[];
  submitted = false;
  better: any;
  hidedetails:boolean = true;
  showdetails:boolean=false;
  pwddetails:boolean=false;
  showdetailss:boolean=false;
  sendetls: any;
  submitpass:boolean
  fieldTextType: any;
  fieldTextType1: any;
  fieldTextType2: any;
  constructor(private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private toastr:ToastrService) { this.GetProfile()}

  UserprofileForm = this.formBuilder.group({
    firstName: ['', [Validators.required, spaceValidator,
     Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$')]],
      lastName: ['', [Validators.required, spaceValidator,
     Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$')]],
      email : ['', [Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"), Validators.required,spaceValidator]]
  })

  updateforgotpasswordform = this.formBuilder.group({ 
    
    oldCred: ['', [Validators.required,spaceValidator]],
    newCred: ['', [Validators.required,spaceValidator, Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
    conformCred: ['', [Validators.required,spaceValidator,Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
  },{
    validator: MustMatch('newCred', 'conformCred')
  });

get forgotpasswordControllers() { return this.updateforgotpasswordform.controls }
get profileControllers() 
{ return this.UserprofileForm.controls }

  ngOnInit(): void {
  }
  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }
  toggleFieldTextType1() {
    this.fieldTextType1 = !this.fieldTextType1;
  }
  toggleFieldTextType2() {
    this.fieldTextType2 = !this.fieldTextType2;
  }
  GetProfile(){
    this.submitted = true;
      this.ngxLoader.start();
      this.userService.userprofiles()
      .pipe(first())
      .subscribe((res:any) => {
        //console.log(res);
        if(res['status']=='1047' && res['tokenStatus']=='1039'){
          this.profiledata= res;
          //console.log(this.profiledata)
        }
        if(res['status']=='1040' || res['tokenStatus']=='1040'){
          this.better = "Your Session Has Expired";
          this.apis.nextMessage("default message")
          this.toastr.error('مرحبًا ، انتهت جلستك');
          this.ngxLoader.stop();
          this.router.navigate(['/ArLogin'])
        }
        else if(res['status']=='1047'){
           this.ngxLoader.stop()
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnsear();
           this.confirmDialogService.confirmThis(this.better)  
           //console.log(this.better)
           this.ngxLoader.stop()
        }
      })
      .add(() => this.ngxLoader.stop());
  }


  updateprofdetails(){
    this.hidedetails = true;
  this.showdetails=false;
  this.showdetailss=false;
  this.pwddetails=false
  }

  updatedetails(getobjData:any){
    this.hidedetails = false;
  this.showdetails=true;
  this.showdetailss=true;
     this.sendetls = getobjData;
  this.UserprofileForm.setValue({
    firstName: this.sendetls.fistName,
    lastName: this.sendetls.lastName,
    email : this.sendetls.EmailId
  });
  }

  changlagar(){
    this.apis.catchlang = 'en'
  }

  Userupddetls(){
    this.submitted = true;
    //console.log(this.UserprofileForm.value)

    // stop here if form is invalid
    if (this.UserprofileForm.invalid ) {
     return;
 }

 this.ngxLoader.start();
 this.userService.userprofileUpdt(this.UserprofileForm.value)
 .pipe(first())
 .subscribe((res:any) => {
  if(res['status']=='1001' && res['tokenStatus']=='1039'){
    //console.log(res)
    this.GetProfile(); 
    this.hidedetails = true;
  this.showdetails=false; 
  this.showdetailss=false;
  this.confirmDialogService.confirmThis("التغييرات الخاصة بك ستنعكس عند تسجيل الدخول التالي")
  }
  else if(res['status']=='1040' || res['tokenStatus']=='1040'){
    this.better = "Your Session Has Expired";
    this.apis.nextMessage("default message")
    this.toastr.error('مرحبًا ، انتهت جلستك');
    this.ngxLoader.stop();
    this.router.navigate(['/ArLogin'])
  }
  else if(res['status']=='1047'){
     this.ngxLoader.stop()
  }
  else if(res['status']){
    this.apis.getallres = res['status'] ;
     this.better = this.apis.allrespnsear();
     this.confirmDialogService.confirmThis(this.better)  
     //console.log(this.better)
     this.ngxLoader.stop()
  }
 
  })
  .add(() => this.ngxLoader.stop());
}

updatepwd(){
  this.pwddetails=true;
  this.hidedetails = false;
  this.showdetails=false; 
  this.showdetailss=true
}

Userupwds(){
  if (!this.updateforgotpasswordform.valid) {
    Object.keys(this.updateforgotpasswordform.controls).forEach(field => {
      const control:any = this.updateforgotpasswordform.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    this.submitpass = true;
  }


 else{

  if(this.updateforgotpasswordform.value.newCred == this.updateforgotpasswordform.value.oldCred)
  {
    this.toastr.success("يجب ألا تكون كلمة المرور القديمة وكلمة المرور الجديدة متماثلتين");
  }

  else
  {


this.ngxLoader.start();
this.userService.userprofileUpdtpwd(this.updateforgotpasswordform.value)
.pipe(first())
.subscribe((res:any) => {
  //console.log(res)
  if(res['status']=='1001' && res['tokenStatus']=='1039'){
    this.toastr.success("تم تحديث كلمة المرور الخاصة بك بنجاح");
    this.updateforgotpasswordform.reset();
    this.updateprofdetails();
  }
  else if(res['status']=='1028' && res['tokenStatus']=='1039'){
    this.GetProfile();
    this.confirmDialogService.confirmThis("يرجى الانتظار لمدة 48 ساعة لتحديث كلمة المرور التالية")
    this.updateforgotpasswordform.reset();
    this.hidedetails = true;
    this.showdetails=false;
    this.showdetailss=false;
    this.pwddetails=false
  }
  else if(res['status']=='1040' || res['tokenStatus']=='1040'){
    this.better = "Your Session Has Expired";
    this.apis.nextMessage("default message")
    this.toastr.error('مرحبًا ، انتهت جلستك');
    this.ngxLoader.stop();
    this.router.navigate(['/ArLogin'])
  }
  else if(res['status']=='1047'){
     this.ngxLoader.stop()
  }
  else if(res['status']){
    this.apis.getallres = res['status'] ;
     this.better = this.apis.allrespnsear();
     this.confirmDialogService.confirmThis(this.better)  
     //console.log(this.better)
     this.ngxLoader.stop();
  }
})
.add(() => this.ngxLoader.stop());
}
 }
}
  
}
