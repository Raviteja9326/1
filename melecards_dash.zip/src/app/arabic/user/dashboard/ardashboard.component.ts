import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ardashboard',
  templateUrl: './ardashboard.component.html'
})
export class ArDashboardComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {
  }



}
