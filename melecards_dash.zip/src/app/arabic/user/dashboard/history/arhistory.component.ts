import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';
@Component({
  selector: 'app-arhistory',
  templateUrl: './arhistory.component.html',
  styleUrls: ['./arhistory.component.scss']
})
export class ArHistoryComponent implements OnInit {
  gethistrydata:any=[];
  better:any;
  page1 = 0;
  hidden = false;
  trans=false;
  pattern = { 0: { pattern: new RegExp('\[a-zA-Z0-9\\d]'), symbol: '*' } }
  constructor(private userService: UserService, private ngxLoader: NgxUiLoaderService, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private router:Router, private toastr:ToastrService) { this.history()}

  ngOnInit(): void {
  }
  onScroll() {
    //console.log('scrolled!!');
  
    //console.log('filterdatascroll')
  this.page1 = this.page1 + 1
  //console.log(this.page1)
  
  // this.getscrollmerchntlist();
  }

  onPlusClick(items:any) {
    console.log(items)
    items.isEdit = !items.isEdit;
  }

  changlagar(){
    this.apis.catchlang = 'en'
  }

  history(){
    const obj:any={}

   obj['pageNumber'] = this.page1.toString();
   obj['pageSize'] = '100';

    this.ngxLoader.start();
    this.userService.userHistory(obj)
    .pipe(first())
    .subscribe((res:any) => {
      if(res['status']=='1047' && res['tokenStatus']=='1039'){
        this.gethistrydata=res['transactions']
        //console.log(this.gethistrydata)
      }
      if(res['status']=='1040' || res['tokenStatus']=='1040'){
        this.better = "Your Session Has Expired";
        this.apis.nextMessage("default message")
        this.toastr.error('مرحبًا ، انتهت جلستك');
        this.ngxLoader.stop();
        this.router.navigate(['/ArLogin'])
      }
      else if(res['status']=='1047'){
         this.ngxLoader.stop()
      }
      else if(res['status']=='1048'){
        this.trans = true;
      }
      else if(res['status']){
        this.apis.getallres = res['status'] ;
         this.better = this.apis.allrespnsear();
         this.confirmDialogService.confirmThis(this.better)  
         //console.log(this.better)
         this.ngxLoader.stop();
      }
          })
    .add(() => this.ngxLoader.stop());
  }
}
