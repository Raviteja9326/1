import { Routes } from '@angular/router';
import { ArHomeComponent } from '../general/home/arhome.component';

export const Aruserroutes: Routes = 
[
  { path: 'ArHome', component: ArHomeComponent },
  { 
    path: 'ArUser', 
    loadChildren: () => import(`./dashboard/ardashboard.module`).then(
      module => module.ArUserDashboardModule
    )
  },
   
];
