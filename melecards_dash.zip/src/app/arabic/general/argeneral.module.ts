import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ArFooterComponent } from './footer/arfooter.component';
import { ArHeaderComponent } from './header/arheader.component';
import { ArSidebarComponent } from './sidebar/arsidebar.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  declarations: [
    ArFooterComponent,
    ArHeaderComponent,
    ArSidebarComponent
  ],
  exports: [
    ArFooterComponent,
    ArHeaderComponent,
    ArSidebarComponent
  ]
})
export class ArGeneralModule { }
