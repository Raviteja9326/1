import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponseService } from 'src/app/services/response.service';

@Component({
  selector: 'app-arhome',
  templateUrl: './arhome.component.html',
  styleUrls: ['./arhome.component.scss']
})
export class ArHomeComponent implements OnInit {
  
  username:any;
  constructor(private router: Router,private apis:ResponseService) { }

  ngOnInit(): void { 
  }

  validRedeem(){
    //console.log(this.apis.nameUser)
    if(this.apis.nameUser == undefined){
      this.apis.check = true;
      this.router.navigate(['/ArLogin'])
    }
    else{
      this.router.navigate(['/ArUser/ArRedeemCoupon'])
    }
  }

  changlagar(){
    this.apis.catchlang = 'en'
  }
}
