import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { BalanceService } from 'src/app/services/balance.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-arsidebar',
  templateUrl: './arsidebar.component.html',
  styleUrls: ['./arsidebar.component.scss']
})
export class ArSidebarComponent implements OnInit {
  public isMobile = false;
  better:any;
  username:any;
  balance:any=[];
  constructor(private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private userbala:UserService, private userlog:BalanceService, private toastr:ToastrService) {
    this.balance=this.apis.balance;
    this.loaddata();
    this.username =this.apis.nameUser;
    this.apis.titless.subscribe(title => {
      this.balance = title+ +this.balance;
      console.log(title)
    });
    }

  ngOnInit(): void {
    this.isMobile = this.getIsMobile();
    window.onresize = () => {
      this.isMobile = this.getIsMobile();
    };
  }

  logout(){
    this.userlog.getlogoutar();
  }
  loaddata(){
      this.ngxLoader.start();
      this.userbala.userbalance()
      .pipe(first())
      .subscribe((res:any) => {
        //console.log(res)
        if(res['status']=='1001' ){
          this.balance= res.totalBalance;
        }
        if(res['status']=='1040' || res['tokenStatus']=='1040'){
          this.better = "Your Session Has Expired";
          this.apis.nextMessage("default message")
          this.toastr.error('مرحبًا ، انتهت جلستك');
          this.ngxLoader.stop();
          this.router.navigate(['/ArLogin'])
        }
        else if(res['status']=='1047'){
           this.ngxLoader.stop()
        }
      })
      .add(() => this.ngxLoader.stop());
    
  }

  onChanges(event:any) {
    //console.log(event);
    this.balance = event;
  }

  getIsMobile(): boolean {
    const w = document.documentElement.clientWidth;
    const breakpoint = 990;
    //console.log(w);
    if (w >= breakpoint) {
      return true;
    } else {
      return false;
    }
  }
}