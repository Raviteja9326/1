import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchCountryField, CountryISO } from 'ngx-intl-tel-input';
import { LanguageService } from 'src/app/services/language.service';
import { UserService } from 'src/app/services/user.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-arlogin',
  templateUrl: './arlogin.component.html',
  styleUrls: ['./arlogin.component.scss']
})
export class ArLoginComponent implements OnInit {
  submitted = false;
  defaultlang:any = "English";
  better: any;
  separateDialCode = true;
	CountryISO = CountryISO;
  mutilpleobj:any;
  mutilplesobj:any;
  hidelogin:boolean = false;
  showlogin:boolean = true;
  hideforg:boolean = false;
  showforg:boolean = true;
  otp: any;
  fieldTextType: boolean;
  repeatFieldTextType: boolean;
  tokener: boolean;
  tokenmsg: string;
  submitpass: boolean;
  submittedph: boolean;

  constructor(private lang:LanguageService,private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService,private token:ResponseService, private toastr:ToastrService ) { 


    this.token.unauthmsg.subscribe(message =>{
      //console.log(message)
      

      if(message != 'default token') {
        
    this.tokener = true;
    this.tokenmsg = message
    setTimeout(() => {
      this.tokener = false;
     }, 3000);

      }
      else { 
        this.tokenmsg = ''
      }
    })

  }

  ngOnInit(): void {}

  UserLoginForm = this.formBuilder.group({
    cred: ['', [Validators.required,]]
  })

  phoneForm = new FormGroup({
		mobileNumbers: new FormControl(undefined, [Validators.required],)
	});
  get phoneControllers() { return this.phoneForm.controls }

  mobileForm = new FormGroup({
		mobileNumber: new FormControl(undefined, [Validators.required])
	});
  get credControllers() { return this.UserLoginForm.controls }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  changeen(lang:string)
  {
  this.defaultlang = lang
   this.lang.changeLangage(lang)
  }

  numberOnly(event:any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
 

  LoginUser(){

    if (!this.phoneForm.valid) {
      Object.keys(this.phoneForm.controls).forEach(field => {
        const control:any = this.phoneForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
        this.submittedph=true;
    }

    else if (!this.UserLoginForm.valid) {
        Object.keys(this.UserLoginForm.controls).forEach(field => {
          const control:any = this.UserLoginForm.get(field);
          control.markAsTouched({ onlySelf: true });
        });
        this.submitpass = true;
  }

  else{
    this.mutilpleobj = this.phoneForm.value.mobileNumbers.dialCode.replace("+", ""); 
    var removespace = this.phoneForm.value.mobileNumbers.number.replace(/\s/g, '');

  
//console.log(this.UserLoginForm.value.mobileNumber, this.UserLoginForm.value.cred)
var mobileobj=this.mutilpleobj + removespace;
var credobj=this.UserLoginForm.value.cred
//console.log(mobileobj,credobj)

      this.ngxLoader.start();
      this.userService.userLogin(mobileobj,credobj)
      .pipe(first())
      .subscribe((res:any) => {
        //console.log(res)
        if(res['status']=='1001' && this.apis.check==true){
          this.apis.hidemenu = true;
          this.apis.showmenu = false;
          this.apis.nameUser=res.customerName
          this.apis.changeMessages(res);
          this.apis.nextMessage(res);
          this.toastr.success('مرحبا ، مرحبا بكم في Melecards');
          this.router.navigate(['/ArUser/ArRedeemCoupon']);
        }
       else if(res['status']=='1001'){
          this.apis.hidemenu = true;
          this.apis.showmenu = false;
          this.apis.nameUser=res.customerName
          this.apis.changeMessages(res);
          this.apis.nextMessage(res);
          var todaydate = new Date();

        var hour = todaydate.getHours();
        
        var greet;
        var greets;
        
        if(hour < 12) {
          greet = 'صباح الخير';
          greets = 'مرحبا بكم في بطاقة ميلي';
          this.toastr.success('أهلا' +'\n'+res.customerName+','+'\n'+ greet +"\n"+ greets);
        }
        
        else if(hour >=12 && hour <= 17) {
          greet = 'مساء الخير';
          greets = 'مرحبا بكم في بطاقة ميلي';
          this.toastr.success('أهلا' +'\n'+res.customerName+','+'\n'+ greet +"\n"+ greets);
        }
        
        else if(hour >= 17 && hour <= 24){
          greet = 'مساء الخير';
          greets = 'مرحبا بكم في بطاقة ميلي';
          this.toastr.success('أهلا' +'\n'+res.customerName+','+'\n'+ greet +"\n"+ greets);
        }
          this.router.navigate(['/ArHome']);
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnsear();
           this.confirmDialogService.confirmThis(this.better)  
           //console.log(this.better)
           this.ngxLoader.stop()
        }
      })
      .add(() => this.ngxLoader.stop());
  }
}

  changlagar(){
    this.apis.catchlang = 'en'
  }

  showforgot(){
    this.hideforg=true;
    this.showforg =false;
  }

  goforgot(){
    this.hideforg=false;
    this.showforg =true;
  }

  forgotUser(){

    if (!this.mobileForm.valid) {
      Object.keys(this.mobileForm.controls).forEach(field => {
        const control:any = this.mobileForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }

    else {

    this.mutilpleobj = this.mobileForm.value.mobileNumber.dialCode.replace("+", ""); 
    var removespace = this.mobileForm.value.mobileNumber.number.replace(/\s/g, '');
    var mobileobj=this.mutilpleobj + removespace;
    


      this.ngxLoader.start();
      this.userService.userpaswd(mobileobj)
      .pipe(first())
      .subscribe((res:any) => {
        //console.log(res)
        if(res['status']=='1001'){
          this.confirmDialogService.confirmThis("نرسل رابط إعادة التعيين إلى معرف البريد المسجل الخاص بك");
          this.hideforg=false;
          this.showforg =true;
          this.mobileForm.reset() 
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnsear();
           this.confirmDialogService.confirmThis(this.better)  
           //console.log(this.better)
           this.ngxLoader.stop()
           this.hideforg=false;
           this.showforg =true;
           this.mobileForm.reset()
        }
      
      })
      .add(() => this.ngxLoader.stop());
  }
}


}