import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchCountryField, CountryISO } from 'ngx-intl-tel-input';
import { LanguageService } from 'src/app/services/language.service';
import { UserService } from 'src/app/services/user.service';
import { ResponseService } from 'src/app/services/response.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ToastrService } from 'ngx-toastr';


export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }
@Component({
  selector: 'app-arregister',
  templateUrl: './arregister.component.html',
  styleUrls: ['./arregister.component.scss']
})
export class ArRegisterComponent implements OnInit {
  defaultlang:any = "English";
  submitted = false;
  better: any;
  separateDialCode = true;
	CountryISO = CountryISO;
  mutilpleobj:any;
  mutilplesobj:any;
  hidelogin:boolean = false;
  showlogin:boolean = true;
  otp: any;
  submitpass: boolean;
  fieldTextType: any;
  timeout =120
  counter: any;
  otpcount:Number
  hidetimer: boolean;
  resendotpbutton: boolean;
  otpSubmit: boolean = true
  submittedph: boolean;


  constructor(private lang:LanguageService,private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private toastr:ToastrService) { }

  ngOnInit(): void {}

  UserCreateForm = this.formBuilder.group({
    firstName: ['', [Validators.required,spaceValidator, 
     Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$')]],
      lastName: ['', [Validators.required,spaceValidator,
     Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$')]],
      emailId : ['',  [Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"), Validators.required,spaceValidator]],
    cred: ['', [Validators.required,spaceValidator, Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
  })
  get registerControllers() { return this.UserCreateForm.controls }

  phoneForm = new FormGroup({
		mobileNumber: new FormControl(undefined, [Validators.required])
	});
  get phoneControllers() { return this.phoneForm.controls }


  OtpForm = this.formBuilder.group({
    otp: [''],
  })
 
  numberOnly(event:any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  timer() {
    this.apis.getObservable(this.timeout).subscribe((val: any) => this.counter = val);
   
    this.resendotpbutton = false;

    if (this.otpcount == 0) {
      this.hidetimer = false;

      setTimeout(() => {
        this.hidetimer = false
        this.otpSubmit = false
        this.resendotpbutton = true
       
      }, 120000)
      //console.log("timerstop")

     
    } else {
      setTimeout(() => {

        
      this.hidetimer = false
      this.otpSubmit = false
      this.resendotpbutton = true

      }, 120000)
      //console.log("timerstoping")

    }
  
  }
  changlagar(){
    this.apis.catchlang = 'en'
  }
  createUser(){

  
    if (!this.UserCreateForm.valid) {
      Object.keys(this.UserCreateForm.controls).forEach(field => {
        const controlk:any = this.UserCreateForm.get(field);
        controlk.markAsTouched({ onlySelf: true });
      });
        this.submitted = true;
    }

   else if (!this.phoneForm.valid) {
      Object.keys(this.phoneForm.controls).forEach(field => {
        const control:any = this.phoneForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submittedph = true;
    }
    
    else{

    this.otpSubmit = true
    this.resendotpbutton = false
  this.mutilpleobj = this.phoneForm.value.mobileNumber.dialCode.replace("+", ""); 
  var removespace = this.phoneForm.value.mobileNumber.number.replace(/\s/g, '');
  const obj:any={}
  obj["mobileNumber"]= this.mutilpleobj + removespace;
  obj["countryCode"]=this.phoneForm.value.mobileNumber.countryCode;

  this.mutilplesobj = Object.assign({}, obj, this.UserCreateForm.value);

      this.ngxLoader.start();
      this.userService.userregistration(this.mutilplesobj)
      .pipe(first())
      .subscribe((res:any) => {
        //console.log(res)
        if(res['status']=='1051'){
          this.confirmDialogService.confirmThis("تم إرسال OTP بنجاح") 
          this.timer();
          this.hidetimer = true; 
          this.hidelogin =true;
          this.showlogin =false;
          this.ngxLoader.stop();
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse();
           this.confirmDialogService.confirmThis(this.better)  
           //console.log(this.better)
           this.ngxLoader.stop()
        }
      })
      .add(() => this.ngxLoader.stop());
    }     
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }
  onOtpChange($event:any){
    //console.log($event)
    this.otp =$event
  }

  changeen(lang:string)
  {
  this.defaultlang = lang
   this.lang.changeLangage(lang)
  }

  OtpUser(){
    this.hidetimer = false

    //console.log(this.otp)
    const objotp:any={}
    objotp["otp"]= this.otp;
    this.ngxLoader.start();
    this.userService.UserOtp(objotp,this.mutilplesobj)
    .pipe(first())
    .subscribe((res:any) => {
      //console.log(res)
      if(res['status']=='1001' && res['tokenStatus']=='1039'){
        //console.log(res.name)
        this.apis.nameUser=res.name;
        this.apis.nextMessage(res)
        this.apis.changeMessages(res);
        this.apis.hidemenu=true;
        this.apis.showmenu=false;
        var todaydate = new Date();

        var hour = todaydate.getHours();
        
        var greet;
        var greets;
        
        if(hour < 12) {
          greet = 'صباح الخير';
          greets = 'مرحبا بكم في بطاقة ميلي';
          this.toastr.success('أهلا' +'\n'+res.name+','+'\n'+ greet +"\n"+ greets);
        }
        
        else if(hour >=12 && hour <= 17) {
          greet = 'مساء الخير';
          greets = 'مرحبا بكم في بطاقة ميلي';
          this.toastr.success('أهلا' +'\n'+res.name+','+'\n'+ greet +"\n"+ greets);
        }
        
        else if(hour >= 17 && hour <= 24){
          greet = 'مساء الخير';
          greets = 'مرحبا بكم في بطاقة ميلي';
          this.toastr.success('أهلا' +'\n'+res.name+','+'\n'+ greet +"\n"+ greets);
        }
        this.router.navigate(['/ArHome'])
      }
      else if(res['status']=='1040' || res['tokenStatus']=='1040'){
        this.better = "Your Session Has Expired";
        this.apis.nextMessage("default message")
        this.toastr.error('مرحبًا ، انتهت جلستك');
        this.ngxLoader.stop();
        this.router.navigate(['/ArLogin'])
      }
      else if(res['status']=='1047'){
         this.ngxLoader.stop()
      }
      else if(res['status']){
        this.apis.getallres = res['status'] ;
         this.better = this.apis.allrespnsear();
         this.confirmDialogService.confirmThis(this.better)  
         //console.log(this.better)
         this.ngxLoader.stop();
      }
    })
    .add(() => this.ngxLoader.stop());
  }
  resendotp()
  {
    this.hidelogin =false;
    this.showlogin =true;
  }
}