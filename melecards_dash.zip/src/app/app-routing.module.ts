import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { ArLoginComponent } from './arabic/general/login/arlogin.component';
import { ArRegisterComponent } from './arabic/general/register/arregister.component';
import { ArUserComponent } from './arabic/user/aruser.component';
import { AmlComponent } from './english/general/aml/aml.component';
import { ForgotComponent } from './english/general/forgot/forgot.component';
import { LoginComponent } from './english/general/login/login.component';
import { PrivacyComponent } from './english/general/privacy/privacy.component';
import { RegisterComponent } from './english/general/register/register.component';
import { RiskComponent } from './english/general/risk/risk.component';
import { TermsComponent } from './english/general/terms/terms.component';
import { UserComponent } from './english/user/user.component';

const routes: Routes = [
  { path: "Login", component: LoginComponent},
  { path: "Register", component: RegisterComponent},
  {path:'Forgot/:id',component:ForgotComponent},
  { path: "ArLogin", component: ArLoginComponent},
  { path: "ArRegister", component: ArRegisterComponent},
  { path: "TermsConditions", component: TermsComponent},
  { path: "PrivacyPolicy", component: PrivacyComponent},
  { path: "AmlPolicy", component: AmlComponent},
  { path: "RiskWarning", component: RiskComponent},
  {path:'',redirectTo:'ArHome',pathMatch:'full'},
  {
    path: '',
    component: ArUserComponent,
    children: [
        {
           path: '', 
            loadChildren: () => import(`./arabic/user/aruser.module`).then(
              module => module.ArUserModule
            )
          }]},
          {
            path: '',
            component: UserComponent,
            children: [
                {
                   path: '', 
                    loadChildren: () => import(`./english/user/user.module`).then(
                      module => module.UserModule
                    )
                  }]},
];

@NgModule({
  imports: [CommonModule,BrowserModule,RouterModule.forRoot((routes),{ useHash: true,scrollPositionRestoration: 'enabled' })],
  exports: []
})
export class AppRoutingModule { }