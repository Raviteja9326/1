import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { interval } from 'rxjs';
import { UserIdleService } from 'angular-user-idle';
import { ResponseService } from './services/response.service';
import { UserService } from './services/user.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  name = 'Angular';
  title = 'MeleCards';
  datamsg: string;
  sub:any;
  message: any;
  data:any;

constructor(private router: Router,private service:ResponseService, private user:UserService,private userIdle: UserIdleService, private translateService: TranslateService){
  translateService.addLangs(['en','ar']);
  translateService.setDefaultLang('en');

  const source = interval(220000);
const text = 'Your Text Here';
const subscription = source.subscribe(val =>
  {
   // this.list = JSON.parse(sessionStorage.getItem('currentUser'))
   //console.log(this.data)
     if(this.data != 'default message'){
       //console.log("***********")
      this.automatic(); 
   
     }

     
 
  });

  this.service.currentMessage.subscribe(message =>{
    //console.log(message);
    this.data=message;
    
  
    
   })



  this.service.currentMessage.subscribe(message =>{
    //console.log(message);
    this.datamsg=message;
    if(this.datamsg != 'default message') {
      this.getsessiontime();
    }

  })


}

useLanguage(language:any) { 
  this.translateService.use(language).toPromise()
}


 ngOnInit()
 {
  this.router.events.subscribe((evt) => {
    if (!(evt instanceof NavigationEnd)) {
        return;
    }
    window.scrollTo(0, 0)
});
 }

 
automatic() {
  this.user.userRefreshtoken().subscribe(response=> {
    //console.log("sdassssssss", response)
    this.refreshTokenResponse(response)
})

  
}

refreshTokenResponse(response:any){
   //console.log(response)
  if(response.tokenStatus=='1039'){
    const obj:any={};
    obj['token']=response.token;
  this.service.changeMessages(obj)
  //console.log("dsmmmmmmmmmmmmmmmadsa",response.token)
  }
}


restart() {
  this.userIdle.resetTimer();
}
startWatching() {
  //console.log("watcing")
  this.userIdle.startWatching();
}
stop() {
   
  this.userIdle.stopTimer();
}
stopWatching() {
    
  this.userIdle.stopWatching();
}

getsessiontime() {
  
  //console.log("watcing")

  this.userIdle.startWatching();
      
  
  } 
  

}
