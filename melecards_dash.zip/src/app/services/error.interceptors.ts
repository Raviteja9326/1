import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ConfirmDialogService } from './confirm-dialog.service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private confirmDialogService: ConfirmDialogService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            const error = err.error?.message || err.statusText;
            this.confirmDialogService.confirmThis("Looks Like our Servers are busy! Please try again later!")  
            console.error(err);
            return throwError(error);
        }))
    }
}