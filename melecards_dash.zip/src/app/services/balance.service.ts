import { Component, Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ConfirmDialogService } from './confirm-dialog.service';
import { ResponseService } from './response.service';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})

export class BalanceService implements OnInit {
  better:any;
  balance:any=[];
  show :boolean = false
  betters: string;
  constructor(private ngxLoader: NgxUiLoaderService, private user:UserService,private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private route:Router,private router:Router, private toastr:ToastrService ) {this.getbalance()}

  ngOnInit(): void {  }

  getbalance(){
    this.ngxLoader.start();
    this.user.userbalance()
    .pipe(first())
    .subscribe((res:any) => {
      //console.log(res)
      if(res['status']=='1001' ){
         this.apis.balance= res.totalBalance;
        //console.log(this.apis.balance)
      }
    })
    .add(() => this.ngxLoader.stop());
  }

  getlogout(){
    this.ngxLoader.start();
    this.user.userlogout()
    .pipe(first())
    .subscribe((res:any) => {
      //console.log(res)
      if(res['status']=='1001' && res['tokenStatus']=='1039'){
        this.apis.showmenu = true;
        this.apis.hidemenu = false;
        this.apis.nameUser = undefined;
        this.apis.nextMessage("default message");
        this.toastr.success('Logout Sucessfully');
       this.route.navigate(['/Login'])
       this.ngxLoader.stop();  
     }
     else if(res['status']){
      this.apis.getallres = res['status'] ;
       this.better = this.apis.allrespnse();
       this.confirmDialogService.confirmThis(this.better)  
       //console.log(this.better)
       this.ngxLoader.stop()
    }
    })
    .add(() => this.ngxLoader.stop());
  }
  getlogoutar(){
    this.ngxLoader.start();
    this.user.userlogout()
    .pipe(first())
    .subscribe((res:any) => {
      //console.log(res)
      if(res['status']=='1001' && res['tokenStatus']=='1039'){
        this.apis.showmenu = true;
        this.apis.hidemenu = false;
        this.apis.nameUser = undefined;
        this.apis.nextMessage("default message");
        this.toastr.success('مرحبًا ، انتهت جلستك');
       this.route.navigate(['/ArLogin'])
       this.ngxLoader.stop();  
     }
     else if(res['status']){
      this.apis.getallres = res['status'] ;
       this.better = this.apis.allrespnsear();
       this.confirmDialogService.confirmThis(this.better)  
       //console.log(this.better)
       this.ngxLoader.stop()
    }
    })
    .add(() => this.ngxLoader.stop());
  }
}
