import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ResponseService } from './response.service';
const baseUrl = `${environment.baseUrl}/v1`;

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl:any;
  datas:any

  constructor(private http:HttpClient, private api:ResponseService) {}

    userregistration(params: any):Observable<any[]> {
      const obj2 = Object.assign({}, params, this.api.getResponse());
      return this.http.post<any>(baseUrl+'/register',obj2);
  }

  UserOtp(otp:any,params:any):Observable<any[]> {
    const obj2 = Object.assign({},otp, params, this.api.getResponse());
    return this.http.post<any>(baseUrl+'/verifyotp',obj2);
}

userLogin(mobileNumber:number,cred:any){
  console.log(mobileNumber,cred)
  let authorizationData = 'Basic ' + btoa(mobileNumber + ':' + cred);
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': authorizationData
    })
  }
return this.http.post<any>(baseUrl+'/login/credentials',this.api.getResponse(),httpOptions)
}





userprofiles() :Observable<any>{
  const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
return this.http.post<any>(baseUrl+'/profile/profileDetails',this.datas,httpOptions)
}

userconvestion() :Observable<any>{
  const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
return this.http.post<any>(baseUrl+'/wallet/conversionRate',this.datas,httpOptions)
}

userbalance() :Observable<any>{
  const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
return this.http.post<any>(baseUrl+'/profile/getbalance',this.datas,httpOptions)
}

userprofileUpdt(obj:any):Observable<any>{
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (this.api.accesstoken)
    })
  }
  //console.log(this.api.accesstoken)
return this.http.post<any>(baseUrl+'/profile/updateProfileDetails',obj,httpOptions)
}

userprofileUpdtpwd(obj:any){
  const obj2 = Object.assign({}, obj, this.api.getResponse());
  //console.log(obj2)
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (this.api.accesstoken)
    })
  }
  //console.log(this.api.accesstoken)
return this.http.post<any>(baseUrl+'/profile/changeCred',obj2,httpOptions)
}

userRedeem(obj:any){
  //console.log(this.api.accesstoken)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    //console.log(this.api.accesstoken)
return this.http.post<any>(baseUrl+'/wallet/redeemCode',obj,httpOptions)
}
userHistory(obj:any){
  //console.log(obj)
  //console.log(this.api.accesstoken)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + (this.api.accesstoken)
      })
    }
    //console.log(httpOptions)
return this.http.post<any>(baseUrl+'/profile/melecardstransactions',obj,httpOptions)
}
userRefreshtoken(){
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (this.api.accesstoken)
    })
  }
  //console.log("werrrrrrr",this.api.accesstoken)
return this.http.post<any>(baseUrl+'/refresh/token',this.datas,httpOptions)
}

userlogout(){
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (this.api.accesstoken)
    })
  }
return this.http.post<any>(baseUrl+'/profile/logout',this.datas,httpOptions)
}

userpaswd(object:any){
  let authorizationDatas = 'Basic ' + btoa(object);
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': authorizationDatas
    })
  }
return this.http.post<any>(baseUrl+'/forget/cred/link',this.api.getResponse(),httpOptions)
}

userpwdupdate(object:any,cred:any){
  const obj2 = Object.assign({},object, cred, this.api.getResponse());
  //console.log(obj2)
return this.http.post<any>(baseUrl+'/forget/cred/updateCred',obj2)
}


}
