import {Injectable,OnInit} from '@angular/core';
import {DeviceDetectorService,DeviceInfo} from 'ngx-device-detector';
import {HttpClient} from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
	providedIn: 'root'
})

export class ResponseService implements OnInit {
	public deviceInfo: DeviceInfo | undefined;
	public titless = new BehaviorSubject('0');
	public isMobilevar = false;
	public isTabletvar = false;
	public isDesktopvar = false;
	public check:boolean;
	public getallres: any;
	public readdy: any;
	public ipAddress: string;
	public longitude: any;
	public latitude: any;
	public getcouncode:any;
	public accesstoken:string;
	public nameUser:any;
	public hidemenu:boolean;
    public showmenu:boolean;
	public catchlang:any='ar';
	source$: any;
    totalcount=0;
	private message = new BehaviorSubject('First Message');
	private messageSource = new BehaviorSubject('default message');
	private dropdownSorce =new  BehaviorSubject('default message');
	currentMessage = this.messageSource.asObservable();
	balance:any=[];
	


	constructor(private deviceService: DeviceDetectorService, private http: HttpClient, private route:Router) {
		this.detectDevice();
		this.isMobile();
		this.isTablet();
		this.isDesktop();
	}

	setTitless(titless:any) {
		this.titless.next(titless);
	  }

	changeMessages(message:any) {
		this.messageSource.next(message)
		console.log("newwww",this.accesstoken)
		return this.accesstoken = message.token;
	}


	
	nextMessage(message:any) 
	{
		this.messageSource.next(message.token)
	}
	  

	  private unauthirize = new BehaviorSubject('default token');
     unauthmsg = this.unauthirize.asObservable();

     


	ngOnInit() {this.loadIp();}

	public loadIp() {
		 this.http.get('https://jsonip.com').subscribe(
			(value: any) => {
			 this.ipAddress = value.ip;
			 console.log(this.ipAddress)
			},
			(error) => {
				console.log(error);
			}
		);
		console.log(this.ipAddress)
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition((position) => {
				this.longitude = position.coords.longitude;
				this.latitude = position.coords.latitude;
				
				console.log(this.latitude,this.longitude)
			});
		} else {
			alert("Please enable Your Location")
		}
		console.log(this.latitude,this.longitude)
	}




	public detectDevice() {
		this.deviceInfo = this.deviceService.getDeviceInfo();
	}

	public isMobile() {
		this.isMobilevar = this.deviceService.isMobile();
	}

	public isTablet() {
		this.isTabletvar = this.deviceService.isTablet();
	}

	public isDesktop() {
		this.isDesktopvar = this.deviceService.isDesktop();
	}

	public getObservable(value:any) {
		this.source$ = new BehaviorSubject < number > (value);
		this.totalcount = this.totalcount + 1;
   
		if (this.totalcount == 1) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
					//  //console.log(newVal)
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				1000);
		}
		if (this.totalcount == 2) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				132000);
		}
		if (this.totalcount == 3) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				176000);
		}
		if (this.totalcount == 4) {
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				220000);
		}
		if (this.totalcount == 5) {
   
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				32000);
		}
		if (this.totalcount == 6) {
   
			setInterval(() => {
					const newVal = this.source$.getValue() - 1;
   
					if (newVal > -1) {
						this.source$.next(newVal);
   
					}
				},
   
				42000);
		}
		return this.source$.asObservable();
	}


	getResponse() {
		const obj: any = {}
		obj["browserType"] = this.deviceInfo?.browser;
		obj["browserVersion"] = this.deviceInfo?.browser_version;
		obj["deviceId"] = "f6f1d0e2c1fcc8e72af497068f807a90";
    obj['devicetype']=this.deviceInfo?.deviceType;
		obj["osType"] = this.deviceInfo?.os;
		obj["osVersion"] = this.deviceInfo?.os_version;
		obj['language'] = this.catchlang;
    obj['macAddress'] ="NA";
		obj['iPAddress'] = '183.82.100.179';
		obj['latitude'] = '17.490532899999998';
		obj['longitude'] = '78.57683089999999'
		return obj;
	}


	allrespnse() {

		if (this.getallres == '1002') {
			this.readdy = "Failure"
			return this.readdy;

		}
		if (this.getallres == '1003') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1004') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1005') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
    if (this.getallres == '1006') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1007') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1008') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1009') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1010') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1011') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1012') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1013') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1014') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1015') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1016') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1017') {
			this.readdy = "Mobile Number is required"
			return this.readdy
		}
		if (this.getallres == '1018') {
			this.readdy = "Please enter valid mobile number"
			return this.readdy
		}
		if (this.getallres == '1019') {
			this.readdy = "Mobile Number already registered"
			return this.readdy
		}
		if (this.getallres == '1020') {
			this.readdy = "Invalid Mobile Number or Password"
			return this.readdy
		}
		if (this.getallres == '1021') {
			this.readdy = "Your session expired"
			return this.readdy
		}
		if (this.getallres == '1022') {
			this.readdy = "Please contact customer care at +966-xxxxxxxxx or write to info@melecards.com"
			return this.readdy
		}

		if (this.getallres == '1023') {
			this.readdy = "Password is required"
			return this.readdy
		}

	if (this.getallres == '1024') {
			this.readdy = "Password length should be between 8-20"
			return this.readdy
		}

		if (this.getallres == '1025') {
			this.readdy = "Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
			return this.readdy
		}
		if (this.getallres == '1026') {
			this.readdy = "Please try again after 30 minutes or write to info@melecards.com"
			return this.readdy
		}
		if (this.getallres == '1027') {
			this.readdy = "Invalid Mobile Number or Password"
			return this.readdy
		}
		if (this.getallres == '1028') {
			this.readdy = "Please try again after 2 days or write to info@melecards.com"
			return this.readdy
		}
		if (this.getallres == '1029') {
			this.readdy = "The link has expired!"
			return this.readdy
		}
		if (this.getallres == '1030') {
			this.readdy = "The link has expired!"
			return this.readdy
		}
		if (this.getallres == '1031') {
			this.readdy = "New Password is required"
			return this.readdy
		}
		if (this.getallres == '1032') {
			this.readdy = "Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
			return this.readdy
		}
		if (this.getallres == '1033') {
			this.readdy = "Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
			return this.readdy
		}
		if (this.getallres == '1034') {
			this.readdy = "Conform Password is required"
			return this.readdy
		}
		if (this.getallres == '1035') {
			this.readdy = "Conform Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
			return this.readdy
		}
		if (this.getallres == '1036') {
			this.readdy = "Conform Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
			return this.readdy
		}

		if (this.getallres == '1037') {
			this.readdy = "New Password And Confirm Password Are Not Equal"
			return this.readdy
		}
		if (this.getallres == '1038') {
			this.readdy = "Looks Like our Servers are busy! Please try again later!"
			return this.readdy
		}
		if (this.getallres == '1042') {
			this.readdy = "Email already registered"
			return this.readdy
		}
		if (this.getallres == '1043') {
			this.readdy = "Invalid Old Password"
			return this.readdy
		}
		if (this.getallres == '1044') {
			this.readdy = "Old Password is required"
			return this.readdy
		}
		if (this.getallres == '1045') {
			this.readdy = "Invalid Old Password"
			return this.readdy
		}
		if (this.getallres == '1046') {
			this.readdy = "Invalid Old Password"
			return this.readdy
		}
		if (this.getallres == '1049') {
			this.readdy = "OTP is not valid"
			return this.readdy
		}
		if (this.getallres == '1050') {
			this.readdy = "OTP is not valid"
			return this.readdy
		}
		if (this.getallres == '1051') {
			this.readdy = "OTP sent to registered mobile number"
			return this.readdy
		}
		if (this.getallres == '1052') {
			this.readdy = "First name is required"
			return this.readdy
		}
		if (this.getallres == '1053') {
			this.readdy = "Last name is required"
			return this.readdy
		}
		if (this.getallres == '1054') {
			this.readdy = "OTP is required"
			return this.readdy
		}
		if (this.getallres == '1055') {
			this.readdy = "Email is required"
			return this.readdy
		}
    if (this.getallres == '1056') {
			this.readdy = "Please enter valid Email Address"
			return this.readdy
		}
		if (this.getallres == '1057') {
			this.readdy = "Please enter valid First Name"
			return this.readdy
		}
		if (this.getallres == '1058') {
			this.readdy = "Please enter valid Last Name"
			return this.readdy
		}
		if (this.getallres == '1059') {
			this.readdy = "Attachment is required"
			return this.readdy
		}
		if (this.getallres == '1060') {
			this.readdy = "Redeem Code is Required"
			return this.readdy
		}
		if (this.getallres == '1061') {
			this.readdy = "Invalid Redeem Code"
			return this.readdy
		}
		if (this.getallres == '1062') {
			this.readdy = "Invalid Redeem Code"
			return this.readdy
		}
	}

	allrespnsear() {

		if (this.getallres == '1002') {
			this.readdy = "فشل"
			return this.readdy;

		}
		if (this.getallres == '1003') {
			this.readdy = "حدث خطأ "
			return this.readdy
		}
		if (this.getallres == '1004') {
			this.readdy = "نوع المتصفح فارغ"
			return this.readdy
		}
		if (this.getallres == '1005') {
			this.readdy = "نوع المتصفح غير صالح"
			return this.readdy
		}
    if (this.getallres == '1006') {
			this.readdy = "نسخة المتصفح فارغة"
			return this.readdy
		}
		if (this.getallres == '1007') {
			this.readdy = "نسخة المتصفح غير صالحة"
			return this.readdy
		}
		if (this.getallres == '1008') {
			this.readdy = "نوع نظام التشغيل هو فارغ"
			return this.readdy
		}
		if (this.getallres == '1009') {
			this.readdy = "نوع نظام التشغيل غير صالح"
			return this.readdy
		}
		if (this.getallres == '1010') {
			this.readdy = "إصدار نظام التشغيل فارغ"
			return this.readdy
		}
		if (this.getallres == '1011') {
			this.readdy = "إصدار نظام التشغيل غير صالح"
			return this.readdy
		}
		if (this.getallres == '1012') {
			this.readdy = "معرف الجهاز فارغ"
			return this.readdy
		}
		if (this.getallres == '1013') {
			this.readdy = "معرف الجهاز غير صالح"
			return this.readdy
		}
		if (this.getallres == '1014') {
			this.readdy = "اللغة فارغة"
			return this.readdy
		}
		if (this.getallres == '1015') {
			this.readdy = "اللغة غير صالحة"
			return this.readdy
		}
		if (this.getallres == '1016') {
			this.readdy = "عنوان الانترنت فارغ"
			return this.readdy
		}
		if (this.getallres == '1017') {
			this.readdy = "رقم الجوال فارغ"
			return this.readdy
		}
		if (this.getallres == '1018') {
			this.readdy = "الجوال غير صالح"
			return this.readdy
		}
		if (this.getallres == '1019') {
			this.readdy = "رقم الجوال مسجل"
			return this.readdy
		}
		if (this.getallres == '1020') {
			this.readdy = "الحساب غير مسجل "
			return this.readdy
		}
		if (this.getallres == '1021') {
			this.readdy = "مستخدم غير مصرح به"
			return this.readdy
		}
		if (this.getallres == '1022') {
			this.readdy = "مستخدم محظور أو مريب"
			return this.readdy
		}

		if (this.getallres == '1023') {
			this.readdy = "يجب ألا تكون كلمة المرور فارغة"
			return this.readdy
		}

	if (this.getallres == '1024') {
			this.readdy = "يجب أن تكون  كلمة المرور بين 8 الي 20 حرفًا"
			return this.readdy
		}

		if (this.getallres == '1025') {
			this.readdy = "يجب أن تحتوي كلمة المرور على حرف كبيرواحد وحرف صغير واحد ورقم واحد حرف خاص"
			return this.readdy
		}
		if (this.getallres == '1026') {
			this.readdy = "محظور  لمدة 30 دقيقة"
			return this.readdy
		}
		if (this.getallres == '1027') {
			this.readdy = "اثبات الهوية  غير صالحة"
			return this.readdy
		}
		if (this.getallres == '1028') {
			this.readdy = "يرجى الانتظار 48 ساعة لتحديث كلمة المرور التالية"
			return this.readdy
		}
		if (this.getallres == '1029') {
			this.readdy = "الرابط غير صالح"
			return this.readdy
		}
		if (this.getallres == '1030') {
			this.readdy = "الرابط تسجيل الدخول  انتهت صلاحيته"
			return this.readdy
		}
		if (this.getallres == '1031') {
			this.readdy = "لا يمكن تسجيل الدخول  ان تكون فارغًا"
			return this.readdy
		}
		if (this.getallres == '1032') {
			this.readdy = "يجب أن يكون التسجيل على الأقل 8 وحد أقصى 20"
			return this.readdy
		}
		if (this.getallres == '1033') {
			this.readdy = "يجب أن يحتوي تسجيل الدخول على حرف كبير واحد وحرف صغير واحد رقم واحد حرف خاص"
			return this.readdy
		}
		if (this.getallres == '1034') {
			this.readdy = "يجب ألا يكون التوافق مع تسجيل"
			return this.readdy
		}
		if (this.getallres == '1035') {
			this.readdy = "يجب أن يكون الكارت المطابق 8 كحد أدنى و 20 كحد أقصى"
			return this.readdy
		}
		if (this.getallres == '1036') {
			this.readdy = "يجب أن يحتوي تسجيل الدخول  على حرف كبير واحد وحرف صغير واحد ورقم واحد خاص"
			return this.readdy
		}

		if (this.getallres == '1037') {
			this.readdy = "كلمة المرور  وتأكيد وتاكيد كلمة المرور غير متطابقين"
			return this.readdy
		}
		if (this.getallres == '1038') {
			this.readdy = "يجب ألا تكون كلمة التحقق  فارغًا"
			return this.readdy
		}
		if (this.getallres == '1042') {
			this.readdy = "إرسال بريد إلكتروني بالفعل"
			return this.readdy
		}
		if (this.getallres == '1043') {
			this.readdy = "كلمة المرور القديمة غير صحيحة"
			return this.readdy
		}
		if (this.getallres == '1044') {
			this.readdy = "لا يجب أن يكون كلمة المرور القديمة  فارغًا"
			return this.readdy
		}
		if (this.getallres == '1045') {
			this.readdy = "يجب أن يحتوي تسجيل الدخول القديم على حرف كبير واحد وحرف صغير واحد ورقم واحد حرف خاص"
			return this.readdy
		}
		if (this.getallres == '1046') {
			this.readdy = "يجب أن يكون تسجيل الدخول القديم من 8 كحد أدنى و 20 كحد أقصى"
			return this.readdy
		}
		if (this.getallres == '1049') {
			this.readdy = "كلمة المرور لمرة واحدة غير صالحة"
			return this.readdy
		}
		if (this.getallres == '1050') {
			this.readdy = "انتهت صلاحية OTP"
			return this.readdy
		}
		if (this.getallres == '1051') {
			this.readdy = "Oإرسال OTP"
			return this.readdy
		}
		if (this.getallres == '1052') {
			this.readdy = "الاسم الأول فارغ"
			return this.readdy
		}
		if (this.getallres == '1053') {
			this.readdy = "الاسم الأخير فارغ"
			return this.readdy
		}
		if (this.getallres == '1054') {
			this.readdy = "لا يجب أن يكون OTP فارغًا"
			return this.readdy
		}
		if (this.getallres == '1055') {
			this.readdy = "البريد الإلكتروني فارغ"
			return this.readdy
		}
    if (this.getallres == '1056') {
			this.readdy = "البريد الإلكتروني غير صالح"
			return this.readdy
		}
		if (this.getallres == '1057') {
			this.readdy = "الاسم الأول غير صالح"
			return this.readdy
		}
		if (this.getallres == '1058') {
			this.readdy = "الاسم الأخير غير صالح"
			return this.readdy
		}
		if (this.getallres == '1059') {
			this.readdy = "يجب ألا يكون المرفق فارغًا"
			return this.readdy
		}
		if (this.getallres == '1060') {
			this.readdy = "كود الاسترداد فارغ"
			return this.readdy
		}
		if (this.getallres == '1061') {
			this.readdy = "كود الاسترداد غير صالح"
			return this.readdy
		}
		if (this.getallres == '1062') {
			this.readdy = "كود مستبدل بالفعل"
			return this.readdy
		}
	}

}