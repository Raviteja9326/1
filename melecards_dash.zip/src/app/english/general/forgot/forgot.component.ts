import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
      const control = updateforgotpasswordform.controls[controlName];
      const matchingControl = updateforgotpasswordform.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit {

  submitpass:boolean;
  fieldTextType: any;
  id: any;
  better: any;
  constructor(private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private toastr:ToastrService) {  this.id = this.route.snapshot.params['id']; }

  updateforgotpassworduserform = this.formBuilder.group({ 
    newCred: ['', [Validators.required, Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
    conformCred: ['', [Validators.required,Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
  },{
    validator: MustMatch('newCred', 'conformCred')
  });

get forgotpasswordControllers() { return this.updateforgotpassworduserform.controls }


  ngOnInit(): void {
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  Userupwdsid(){
//console.log(this.id)

    this.submitpass = true;

    //console.log(this.updateforgotpassworduserform.value)
  
    // stop here if form is invalid
    if (this.updateforgotpassworduserform.invalid ) {
     return;
  }
  //console.log(this.id)
  
  const obj:any={}

  obj['verifyKey'] = this.id;

  this.ngxLoader.start();
  this.userService.userpwdupdate(this.updateforgotpassworduserform.value, obj)
  .pipe(first())
  .subscribe((res:any) => {
    //console.log(res)
    if(res['status']=='1001'){
      this.toastr.success('Hi, Sucessfuly Updated');
      this.router.navigate(['/Login']);
    }
   
    else if(res['status']){
      this.apis.getallres = res['status'] ;
       this.better = this.apis.allrespnse();
       this.confirmDialogService.confirmThis(this.better)  
       //console.log(this.better)
       this.ngxLoader.stop();
    }
        })
  .add(() => this.ngxLoader.stop());
  }
}
