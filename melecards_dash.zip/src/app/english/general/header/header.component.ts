import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { BalanceService } from 'src/app/services/balance.service';
import { LanguageService } from 'src/app/services/language.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public isMobile = false;
  public isMobiles = false;
  hidemenu:boolean=false;
  showmenu:boolean=true;
  defaultlang:any = "English";
  username:any;
  default:any;
  better:any;
  balance:any=[];
  
  constructor(private ngxLoader: NgxUiLoaderService,private apis:ResponseService,private lang:LanguageService,private router: Router, private elementRef: ElementRef, @Inject(DOCUMENT) private document: Document, private userbala:UserService, private userlog:BalanceService, private toastr:ToastrService) {
    this.hidefunc();
   this.username =this.apis.nameUser;
   console.log(this.username)
   this.loaddata();
   this.apis.titless.subscribe(res => {
    this.balance = res+ +this.balance;
    console.log(res)
  });
  }

 
  
  hidefunc()
  {
   if(this.apis.hidemenu==false)
   {
     if(this.apis.showmenu == true){
     this.hidemenu = false;
     this.showmenu = true;
   }
  }
  else if(this.apis.hidemenu==true)
  {
    if(this.apis.showmenu == false){
    this.hidemenu = true;
    this.showmenu = false;
  }
 }
   }

   changeen(lang:string)
   {
   this.defaultlang = lang
    this.lang.changeLangage(lang)
   }

  ngOnInit(): void {
    this.isMobile = this.getIsMobile();
    this.isMobiles = this.getIsMobiles();
    window.onresize = () => {
      this.isMobile = this.getIsMobile();
      this.isMobiles = this.getIsMobiles();
    };
  }


  getIsMobile(): boolean {
    const w = document.documentElement.clientWidth;
    const breakpoint = 990;
    //console.log(w);
    if (w >= breakpoint) {
      return true;
    } else {
      return false;
    }
  }

  getIsMobiles(): boolean {
    const w = document.documentElement.clientWidth;
    const breakpoint = 991;
    //console.log(w);
    if (w <= breakpoint) {
      return true;
    } else {
      return false;
    }
  }
  changlagen(){
    this.apis.catchlang = "ar";
  }
  validRedeem(){
    //console.log(this.apis.nameUser)
    if(this.apis.nameUser == undefined){
      this.apis.check = true;
      this.router.navigate(['/Login'])
    }
    else{
      this.router.navigate(['/User/RedeemCoupon'])
    }
  }
  logout(){
    this.userlog.getlogout();
  }

  loaddata(){
    this.ngxLoader.start();
    this.userbala.userbalance()
    .pipe(first())
    .subscribe((res:any) => {
      //console.log(res)
      if(res['status']=='1001' ){
        this.balance= res.totalBalance;
      }
    })
    .add(() => this.ngxLoader.stop());
  
}

}


