import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponseService } from 'src/app/services/response.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  
  username:any;
  constructor(private router: Router,private apis:ResponseService,) { }

  ngOnInit(): void { 
  }

  changlagen(){
    this.apis.catchlang = "ar";
  }

  validRedeem(){
    //console.log(this.apis.nameUser)
    if(this.apis.nameUser == undefined){
      this.apis.check=true;
      this.router.navigate(['/Login'])
    }
    else{
      this.router.navigate(['/User/RedeemCoupon'])
    }
  }
}
