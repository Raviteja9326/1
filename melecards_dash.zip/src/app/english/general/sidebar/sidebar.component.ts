import { Component, OnInit, resolveForwardRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { BalanceService } from 'src/app/services/balance.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  public isMobile = false;
  better:any;
  username:any;
  balance:any=[];
  preventSimpleClick:any;
  timer:any;
  constructor(private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private userbala:UserService, private userlog:BalanceService, private toastr:ToastrService) {
    this.loaddata();
    this.username =this.apis.nameUser;
    this.apis.titless.subscribe(res => {
      this.balance = res+ +this.balance;
      console.log(res)
    });
    }

  ngOnInit(): void {
    this.isMobile = this.getIsMobile();
    window.onresize = () => {
      this.isMobile = this.getIsMobile();
    };
  }

  logout(){
    this.userlog.getlogout();
  }

  // singleClick(): void{
  //   this.timer = 0;
  //   this.preventSimpleClick = false;
  //   let delay = 200;

  //   this.timer = setTimeout(() => {
  //     if(!this.preventSimpleClick){
  //       this.toastr.success('Sucessfully Logout');
  //     }
  //   }, delay);

  // }

  // doubleClick(): void{
  //   this.preventSimpleClick = true;
  //   clearTimeout(this.timer);
  //   this.logout()
  // }

  loaddata(){
      this.ngxLoader.start();
      this.userbala.userbalance()
      .pipe(first())
      .subscribe((res:any) => {
        //console.log(res)
        if(res['status']=='1001' ){
          this.balance= res.totalBalance;
        }
        if(res['status']=='1040' || res['tokenStatus']=='1040'){
          this.better = "Your Session Has Expired";
          this.apis.nextMessage("default message")
          this.toastr.error('Your Session Expired');
          this.ngxLoader.stop();
          this.router.navigate(['/Login'])
        }
        else if(res['status']=='1047'){
           this.ngxLoader.stop()
        }
      })
      .add(() => this.ngxLoader.stop());
    
  }

  onChanges(event:any) {
    //console.log(event);
    this.balance = event;
  }

  getIsMobile(): boolean {
    const w = document.documentElement.clientWidth;
    const breakpoint = 990;
    //console.log(w);
    if (w >= breakpoint) {
      return true;
    } else {
      return false;
    }
  }

}
