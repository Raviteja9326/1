import { Routes } from '@angular/router';
import { HomeComponent } from '../general/home/home.component';

export const userroutes: Routes = 
[
  { path: 'Home', component: HomeComponent },
  { 
    path: 'User', 
    loadChildren: () => import(`./dashboard/dashboard.module`).then(
      module => module.UserDashboardModule
    )
  },
   
];

