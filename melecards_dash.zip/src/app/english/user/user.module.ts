import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { userroutes } from './user-routing.module';
import { HomeComponent } from '../general/home/home.component';
import { UserDashboardModule } from './dashboard/dashboard.module';


@NgModule({
  imports: [
    CommonModule,
    UserDashboardModule,
    RouterModule.forChild(userroutes)
  ],
  declarations: [HomeComponent]
})
export class UserModule { }
