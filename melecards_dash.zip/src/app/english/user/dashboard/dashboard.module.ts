import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { userdashboardroutes } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ConfirmDialogModule } from '../../general/dialgoue/confirm-dialog.module';
import { GeneralModule } from '../../general/general.module';
import { HistoryComponent } from './history/history.component';
import { ProfiledetailsComponent } from './profiledetails/profiledetails.component';
import { RedeemComponent } from './redeem/redeem.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import {NgxMaskModule} from 'ngx-mask'



@NgModule({
  imports: [
    NgxMaskModule.forRoot({
      showMaskTyped : false,
      // clearIfNotMatch : true
    }),
    FormsModule,
    InfiniteScrollModule,
    ConfirmDialogModule,
    ReactiveFormsModule,
    HttpClientModule,
    CommonModule,
    GeneralModule,
    RouterModule.forChild(userdashboardroutes)
  ],
  declarations: [DashboardComponent,HistoryComponent,ProfiledetailsComponent,RedeemComponent ]
})
export class UserDashboardModule { }
