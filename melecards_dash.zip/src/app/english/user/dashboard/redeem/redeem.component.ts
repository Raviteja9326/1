import { Component, ElementRef, EventEmitter, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { UserService } from 'src/app/services/user.service';
import { first } from 'rxjs/operators';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ResponseService } from 'src/app/services/response.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { Output } from '@angular/core';
import { BalanceService } from 'src/app/services/balance.service';
import { ToastrService } from 'ngx-toastr';
declare var $:any;


@Component({
  selector: 'app-redeem',
  templateUrl: './redeem.component.html',
  styleUrls: ['./redeem.component.scss']
})
export class RedeemComponent implements OnInit {
  submitted = false;
  better: any;
  converstion:any=[];
  balance: any;
  public customPatterns = { '0': { pattern: new RegExp('\[a-zA-Z0-9\]')} };
  constructor(private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private userbala:UserService, private toastr:ToastrService) { 
    this.GetconverstionData();
  }
  get reedmeControllers() 
  { return this.UserRedeemForm.controls }

  ngOnInit(): void 
  {
  }

  @ViewChild("myinput") myInputField: ElementRef;
ngAfterViewInit() {
this.myInputField.nativeElement.focus();
window.scrollTo(0, 0)
}

  changlagen(){
    this.apis.catchlang = "ar";
  }
 
  UserRedeemForm = this.formBuilder.group({
    redeemCode: ['',[Validators.required,Validators.minLength(16), Validators.maxLength(16)]]
  })



  createredeem(){
    if (!this.UserRedeemForm.valid) {
      Object.keys(this.UserRedeemForm.controls).forEach(field => {
        const control:any = this.UserRedeemForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }
    
   else {
    
          this.ngxLoader.start();
          this.userService.userRedeem(this.UserRedeemForm.value)
          .pipe(first())
          .subscribe((res:any) => {
            //console.log("asdsa",res.meleCoins)
            if(res['status']=='1001' && res['tokenStatus']=='1039'){
            this.confirmDialogService.confirmThis("Sucessfully"+'\n'+res.meleCoins+'\n'+"Melecoins Added"); 
            this.apis.setTitless(res.meleCoins);
            this.UserRedeemForm.reset();
            }
           else if(res['status']=='1040' || res['tokenStatus']=='1040'){
              this.better = "Your Session Has Expired";
              this.apis.nextMessage("default message")
              this.toastr.error('Your Session Expired');
              this.ngxLoader.stop();
              this.router.navigate(['/Login'])
            }
            else if(res['status']=='1047'){
               this.ngxLoader.stop()
            }
            else if(res['status']){
              this.apis.getallres = res['status'] ;
               this.better = this.apis.allrespnse();
               this.confirmDialogService.confirmThis(this.better)  
               //console.log(this.better)
               this.ngxLoader.stop();
            }
          })
          .add(() => this.ngxLoader.stop());
  
        }
      }

        GetconverstionData(){
            this.userService.userconvestion()
            .pipe(first())
            .subscribe((res:any) => {
              console.log(res);
              if(res['status']=='1001' && res['tokenStatus']=='1039'){
                this.converstion= res; 
              }
              else if(res['status']=='1040' || res['tokenStatus']=='1040'){
                this.better = "Your Session Has Expired";
                this.apis.nextMessage("default message")
                this.toastr.error('Your Session Expired');
                this.ngxLoader.stop();
                this.router.navigate(['/Login'])
              }
              else if(res['status']=='1047'){
                 this.ngxLoader.stop()
              }
              else if(res['status']){
                this.apis.getallres = res['status'] ;
                 this.better = this.apis.allrespnse();
                 this.confirmDialogService.confirmThis(this.better)  
                 //console.log(this.better)
                 this.ngxLoader.stop();
              }
           
            })
            .add(() => "");
        }
}
