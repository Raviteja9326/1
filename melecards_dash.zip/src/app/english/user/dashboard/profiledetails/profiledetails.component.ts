import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { UserService } from 'src/app/services/user.service';
import { first } from 'rxjs/operators';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ResponseService } from 'src/app/services/response.service';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { SearchCountryField, CountryISO } from 'ngx-intl-tel-input';
import { ToastrService } from 'ngx-toastr';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
      const control = updateforgotpasswordform.controls[controlName];
      const matchingControl = updateforgotpasswordform.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-profiledetails',
  templateUrl: './profiledetails.component.html',
  styleUrls: ['./profiledetails.component.scss']
})
export class ProfiledetailsComponent implements OnInit {
  profiledata:any=[];
  submitted = false;
  better: any;
  hidedetails:boolean = true;
  showdetails:boolean=false;
  pwddetails:boolean=false;
  showdetailss:boolean=false;
  sendetls: any;
  submitpass:boolean;
  fieldTextType: any;
  fieldTextType1: any;
  fieldTextType2: any;
  oldpass: any;
  oldpasshow : boolean = false
  constructor(private formBuilder: FormBuilder,private userService: UserService, private ngxLoader: NgxUiLoaderService,private route: ActivatedRoute,private router: Router, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private toastr:ToastrService) { this.GetProfile()}

  UserprofileForm = this.formBuilder.group({
    firstName: ['', [Validators.required,spaceValidator, 
     Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$')]],
      lastName: ['', [Validators.required, spaceValidator,
     Validators.pattern('^[a-zA-Z\u0600-\u06FF][\sa-zA-Z\u0600-\u06FF]*$')]],
      email : ['', [Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
      + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"), Validators.required,spaceValidator]]
  })

  updateforgotpasswordform = this.formBuilder.group({ 
    
    oldCred: ['', [Validators.required,spaceValidator]],
    newCred: ['', [Validators.required, spaceValidator,Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
    conformCred: ['', [Validators.required,spaceValidator,Validators.pattern(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!%*#?&{}/[\]<>()~`"'^_+=,.;:\|]).*$/)]],
  },{
    validator: MustMatch('newCred', 'conformCred')
  });

get forgotpasswordControllers() { return this.updateforgotpasswordform.controls }
get profileControllers() 
{ return this.UserprofileForm.controls }

  ngOnInit(): void {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
          return;
      }
      window.scrollTo(0, 0)
  });
  }
  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }
  toggleFieldTextType1() {
    this.fieldTextType1 = !this.fieldTextType1;
  }
  toggleFieldTextType2() {
    this.fieldTextType2 = !this.fieldTextType2;
  }
  GetProfile(){
    this.submitted = true;
      this.ngxLoader.start();
      this.userService.userprofiles()
      .pipe(first())
      .subscribe((res:any) => {
        console.log(res);
        if(res['status']=='1047' && res['tokenStatus']=='1039'){
          this.profiledata= res;
          //console.log(this.profiledata)
        
          
        }
        if(res['status']=='1040' || res['tokenStatus']=='1040'){
          this.better = "Your Session Has Expired";
          this.apis.nextMessage("default message")
          this.toastr.error('Your Session Expired');
          this.ngxLoader.stop();
          this.router.navigate(['/Login'])
        }
        else if(res['status']=='1047'){
           this.ngxLoader.stop()
        }
        else if(res['status']){
          this.apis.getallres = res['status'] ;
           this.better = this.apis.allrespnse();
           this.confirmDialogService.confirmThis(this.better)  
           //console.log(this.better)
           this.ngxLoader.stop()
        }
      })
      .add(() => this.ngxLoader.stop());
  }


  updateprofdetails(){
    this.hidedetails = true;
  this.showdetails=false;
  this.showdetailss=false;
  this.pwddetails=false
  }

  changlagen(){
    this.apis.catchlang = "ar";
  }

  updatedetails(getobjData:any){
    this.hidedetails = false;
  this.showdetails=true;
  this.showdetailss=true;
     this.sendetls = getobjData;
  this.UserprofileForm.setValue({
    firstName: this.sendetls.fistName,
    lastName: this.sendetls.lastName,
    email : this.sendetls.EmailId
  });
  }

  Userupddetls(){

    if (!this.UserprofileForm.valid) {
      Object.keys(this.UserprofileForm.controls).forEach(field => {
        const control:any = this.UserprofileForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }

else {
 this.ngxLoader.start();
 this.userService.userprofileUpdt(this.UserprofileForm.value)
 .pipe(first())
 .subscribe((res:any) => {
  if(res['status']=='1001' && res['tokenStatus']=='1039'){
    //console.log(res)
    this.GetProfile(); 
    this.hidedetails = true;
  this.showdetails=false; 
  this.showdetailss=false;
  this.confirmDialogService.confirmThis("Your Changes Will Reflect On Next Login");
  this.apis.nameUser = res.firstName;
  }
 else if(res['status']=='1040' || res['tokenStatus']=='1040'){
    this.better = "Your Session Has Expired";
    this.apis.nextMessage("default message")
    this.toastr.error('Your Session Expired');
    this.ngxLoader.stop();
    this.router.navigate(['/Login'])
  }
  else if(res['status']=='1047'){
     this.ngxLoader.stop()
  }
  else if(res['status']){
    this.apis.getallres = res['status'] ;
     this.better = this.apis.allrespnse();
     this.confirmDialogService.confirmThis(this.better)  
     //console.log(this.better)
     this.ngxLoader.stop()
  }
 
  })
  .add(() => this.ngxLoader.stop());
}
  }

updatepwd(){
  this.pwddetails=true;
  this.hidedetails = false;
  this.showdetails=false; 
  this.showdetailss=true;
  this.updateforgotpasswordform.reset();
}

Userupwds(){

  if (!this.updateforgotpasswordform.valid) {
    Object.keys(this.updateforgotpasswordform.controls).forEach(field => {
      const control:any = this.updateforgotpasswordform.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    this.submitpass = true;
  }

else {

  if(this.updateforgotpasswordform.value.newCred == this.updateforgotpasswordform.value.oldCred)
  {
    this.toastr.success("Old Password And New Password Should Not be Same");
  }

  else
  {

this.ngxLoader.start();
this.userService.userprofileUpdtpwd(this.updateforgotpasswordform.value)
.pipe(first())
.subscribe((res:any) => {
  console.log(res)
  if(res['status']=='1001' && res['tokenStatus']=='1039'){
    this.toastr.success("Your password Sucessfully Updated");
    this.updateforgotpasswordform.reset();
    this.updateprofdetails();
  }
  else if(res['status']=='1028' && res['tokenStatus']=='1039'){ 
    this.GetProfile();
    this.confirmDialogService.confirmThis("Please Wait For 48Hrs For Next Password Update")
    this.updateforgotpasswordform.reset();
    this.hidedetails = true;
    this.showdetails=false;
    this.showdetailss=false;
    this.pwddetails=false
  }
  else if(res['status']=='1040' || res['tokenStatus']=='1040'){
    this.better = "Your Session Has Expired";
    this.apis.nextMessage("default message")
    this.toastr.error('Your Session Expired');
    this.ngxLoader.stop();
    this.router.navigate(['/Login'])
  }
  else if(res['status']=='1047'){
     this.ngxLoader.stop()
  }
  else if(res['status']){
    this.apis.getallres = res['status'] ;
     this.better = this.apis.allrespnse();
     this.confirmDialogService.confirmThis(this.better)  
     //console.log(this.better)
     this.ngxLoader.stop();
  }


})
.add(() => this.ngxLoader.stop());
}
}
}
  
}
