import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { first } from 'rxjs/operators';
import { ConfirmDialogService } from 'src/app/services/confirm-dialog.service';
import { ResponseService } from 'src/app/services/response.service';
import { UserService } from 'src/app/services/user.service';




@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {
  gethistrydata:any=[];
  better:any;
  trans:boolean=false;
  hidden = false;
  page1 = 0;
  pattern = { 0: { pattern: new RegExp('\[a-zA-Z0-9\\d]'), symbol: '*' } }
  constructor(private userService: UserService, private ngxLoader: NgxUiLoaderService, private apis:ResponseService,private confirmDialogService: ConfirmDialogService, private router:Router, private toastr:ToastrService) 
  {
    this.history();
  }


  onPlusClick(items:any) {
    console.log(items)
    items.isEdit = !items.isEdit;
  }

  ngOnInit(): void {
  }
  onScroll() {
    //console.log('scrolled!!');
  
    //console.log('filterdatascroll')
  this.page1 = this.page1 + 1
  //console.log(this.page1)
  
  // this.getscrollmerchntlist();

  }

  changlagen(){
    this.apis.catchlang = "ar";
  }

  history(){
    const obj:any={}

   obj['pageNumber'] = this.page1.toString();
   obj['pageSize'] = '100';

    this.ngxLoader.start();
    this.userService.userHistory(obj)
    .pipe(first())
    .subscribe((res:any) => {
if(res['status']=='1047' && res['tokenStatus']=='1039'){
  this.gethistrydata=res['transactions']
}
if(res['status']=='1040' || res['tokenStatus']=='1040'){
  this.better = "Your Session Has Expired";
  this.apis.nextMessage("default message")
  this.toastr.error('Your Session Expired');
  this.ngxLoader.stop();
  this.router.navigate(['/Login'])
}
else if(res['status']=='1047'){
   this.ngxLoader.stop()
}
else if(res['status']=='1048'){
  this.trans = true;
}
else if(res['status']){
  this.apis.getallres = res['status'] ;
   this.better = this.apis.allrespnse();
   this.confirmDialogService.confirmThis(this.better)  
   //console.log(this.better)
   this.ngxLoader.stop();
}
    })
    .add(() => this.ngxLoader.stop());
  }
}
