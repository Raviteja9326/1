import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { HistoryComponent } from './history/history.component';
import { ProfiledetailsComponent } from './profiledetails/profiledetails.component';
import { RedeemComponent } from './redeem/redeem.component';

export const userdashboardroutes: Routes = 
[
  { path: '', component: DashboardComponent,
  children: [
  { path: 'RedeemCoupon', component: RedeemComponent },
  { path: 'Profile', component: ProfiledetailsComponent },
  { path: 'History', component: HistoryComponent },
  ]}
];

