import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import {switchMap} from 'rxjs/operators';
import Swal from 'sweetalert2';
import { AllinoneService } from './services/allinone.service';
import { LoginService } from './services/login.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'fixitdashboard';
  userIP = '';
  constructor(private router: Router, private httpClient: HttpClient, private useservice:AllinoneService,private ngxLoader: NgxUiLoaderService, private login:LoginService)
  {
  }

  ngOnInit()
  {
    this.loadIp();
   this.router.events.subscribe((evt) => {
     if (!(evt instanceof NavigationEnd)) {
         return;
     }
     window.scrollTo(0, 0)
 });
  }


  loadIp() {
    this.httpClient.get('https://jsonip.com')
    .pipe(
      switchMap((value:any) => {
      this.userIP = value.ip;
      this.useservice.setTitless(value.ip);
      let url = `https://api.ipify.org/?format=json`
      return this.httpClient.get(url);
      })
    ).subscribe(
      (value:any) => {
      this.useservice.setTitless2(value.latitude);
      this.useservice.setTitless3(value.longitude);
      },
      err => {
      console.log(err);
      }
    );
    }
    
}


