import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './commonshare/dashboard/dashboard.component';
import { Dashboard2Component } from './commonshare/dashboard2/dashboard2.component';
import { Dashboard3Component } from './commonshare/dashboard3/dashboard3.component';
import { ErrorComponent } from './commonshare/error/error.component';
import { ErrordashComponent } from './commonshare/errordash/errordash.component';
import { SearchComponent } from './commonshare/search/search.component';
import { LoginComponent } from './secure/login/login.component';

const routes: Routes = [

  {path:'login', component:LoginComponent},
  {path:'',redirectTo:'login',pathMatch:'full'},
  {path:'error', component:ErrorComponent},
  { path: "search", component: SearchComponent},
  {
    path: "",
    component: DashboardComponent,
    children: [
      { path: "errors", component: ErrordashComponent},
      {
        path: "admin",
        loadChildren:()=>  import('./admin/admin.module').then(m => m.AdminModule)
      }
    ]
  },
  {
    path: "",
    component: Dashboard2Component,
    children: [
      { path: "errors", component: ErrordashComponent},
      {
        path: "superadmin",
        loadChildren:()=>  import('./superadmin/superadmin.module').then(m => m.SuperadminModule),
      }
    ]
  },
  {
    path: "",
    component: Dashboard3Component,
    children: [
      { path: "errors", component: ErrordashComponent},
      {
        path: "masteradmin",
        loadChildren:()=>  import('./masteradmin/masteradmin.module').then(m => m.MasteradminModule),
      },
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true,preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
