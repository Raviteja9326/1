import {Component,DoCheck,OnInit} from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { Router } from "@angular/router";
import { NgxUiLoaderService } from "ngx-ui-loader";
import { of, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { SearchComponent } from "src/app/commonshare/search/search.component";
import { AllinoneService } from "src/app/services/allinone.service";
import { LoginService } from "src/app/services/login.service";
import { SuperadminService } from "src/app/services/superadmin.service";
import Swal from "sweetalert2";
declare var $: any;

@Component({
  selector: "app-bannerslist",
  templateUrl: "./bannerslist.component.html",
  styleUrls: ["./bannerslist.component.scss"],
})
export class BannerslistComponent implements OnInit {
  type: any;
  destroy$: Subject<boolean> = new Subject<boolean>();
  bannerLists: any;
  better: boolean = false;
  betters: boolean = false;
  list: any;
  showfirst: boolean = true;
  showaddbann: boolean = false;
  showupdbann: boolean = false;
  showdelebann: boolean = false;
  showaddoffer: boolean = false;
  showupdoffer: boolean = false;
  showdeleoffer: boolean = false;
  acceptprof: boolean = false;
  rejectprof: boolean = false;
  showblock: boolean = false;
  unblockss: boolean = false;
  cities: boolean = false;
  updatecities: boolean = false;
  deletecities: boolean = false;
  deleteaccounts: boolean = false;
  upstat: boolean = false;
  viewcats: boolean = false;
  updacats: boolean = false;
  delecats: boolean = false;
  viewsubcats: boolean = false;
  updasubcats: boolean = false;
  delesubcats: boolean = false;
  viewsubcatstyp: boolean = false;
  updasubcatstyp: boolean = false;
  delesubcatstyp: boolean = false;
  upsts = [];
  addban = [];
  deleaccount = [];
  updban = [];
  deleban = [];
  showblocks = [];
  unblocks = [];
  acceptpf = [];
  rejectpf = [];
  addcits = [];
  updcits = [];
  delecits = [];
  addoffers = [];
  updoffers = [];
  deleoffers = [];
  err: boolean = false;
  baseUrl: any = "https://images.mrmusllaha.com/categories/";
  baseUrl2: any = "https://images.mrmusllaha.com/subcategories/";
  baseUrl4: any = "https://images.mrmusllaha.com/banners/";
  baseUrl5: any = "https://images.mrmusllaha.com/subcategorytypes/";
  baseurl6 = "https://documents.mrmusllaha.com/"
  objectKeys = Object.values;
  var1: any;
  var2: any;
  var3: any;
  var4: any;
  var5: any;
  var6: any;
  var7: any;
  var8: any;
  var9: any;
  banners: any;
  addvideos: boolean;
  addvide: any;
  delevideos: boolean;
  delevide: any;
    acceptdocums: boolean;
    var11: any;
    updatedocums: boolean;
    deledocums: boolean;
    var12: any;
    var13: any;

  constructor(
    private formBuilder: FormBuilder,
    private login: SuperadminService,
    private logins: LoginService,
    private ngxLoader: NgxUiLoaderService,
    private useservice: AllinoneService,
    private router: Router,
    public dialog: MatDialog
  ) {
    this.getservice();
    if (this.useservice.type == undefined || this.useservice.type == "NA") {
      this.type = "";
    } else {
      this.type = this.useservice.type;
    }
  }

  getservice() {
    this.ngxLoader.start();
    this.useservice.showaddbann.subscribe((res) => {
      if (res == "Addbanner") {
        this.addbanners();
        this.ngxLoader.stop();
      } else if (res == "updatebanner") {
        this.updbanners();
        this.ngxLoader.stop();
      } else if (res == "deletebanner") {
        this.delebanners();
        this.ngxLoader.stop();
      } else if (res == "addoffer") {
        this.addoffer();
        this.ngxLoader.stop();
      } else if (res == "updateoffer") {
        this.uptoffer();
        this.ngxLoader.stop();
      } else if (res == "deleteoffer") {
        this.deleoffer();
      } else if (res == "block") {
        this.block();
        this.ngxLoader.stop();
      } else if (res == "unblock") {
        this.unblock();
        this.ngxLoader.stop();
      } else if (res == "deleteaccount") {
        this.deleteaccount();
        this.ngxLoader.stop();
      } else if (res == "addcities") {
        this.addcites();
        this.ngxLoader.stop();
      } else if (res == "updatecites") {
        this.uptcites();
        this.ngxLoader.stop();
      } else if (res == "deletecities") {
        this.delecites();
        this.ngxLoader.stop();
      } else if (res == "accept") {
        this.acptprof();
        this.ngxLoader.stop();
      } else if (res == "reject") {
        this.rejtprof();
        this.ngxLoader.stop();
      } else if (res == "bookingstatus") {
        this.updstus();
        this.ngxLoader.stop();
      } else if (res == "addcat") {
        this.viewcatstus();
        this.ngxLoader.stop();
      } else if (res == "updcat") {
        this.updcatstus();
        this.ngxLoader.stop();
      } else if (res == "delecat") {
        this.delecatstus();
        this.ngxLoader.stop();
      } else if (res == "addsubcat") {
        this.addcatsubstus();
        this.ngxLoader.stop();
      } else if (res == "updsubcat") {
        this.updcatsubstus();
        this.ngxLoader.stop();
      } else if (res == "delesubcat") {
        this.delecatsubstus();
        this.ngxLoader.stop();
      } else if (res == "addsubcattyp") {
        this.viewcatsubtypstus();
        this.ngxLoader.stop();
      } else if (res == "updsubcattyp") {
        this.updcatsubtypsstus();
        this.ngxLoader.stop();
      } else if (res == "delesubcattyp") {
        this.delecatsubtypstus();
        this.ngxLoader.stop();
      } else if (res == "addvideo") {
        this.addvideo();
        this.ngxLoader.stop();
      } else if (res == "deletevideo") {
        this.deletevideo();
        this.ngxLoader.stop();
      }
      else if (res == "acceptdocum") {
        this.acceptdocum();
        this.ngxLoader.stop();
      }
      else if (res == "updatedocum") {
        this.updatedocum();
        this.ngxLoader.stop();
      }
      else if (res == "rejctdocum") {
        this.rejctdocum();
        this.ngxLoader.stop();
      }
      this.ngxLoader.stop();
    });
  }

  selectform = this.formBuilder.group({
    resetselect: [""],
  });

  acceptdocum()
  {
    this.getBanners();
    this.upstat = false;
    this.rejectprof = false;
    this.showaddbann = false;
    this.showfirst = false;
    this.showdelebann = false;
    this.showupdbann = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.acceptprof = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    this.addvideos = false;
    this.delevideos = false;
    this.acceptdocums=true;
    this.updatedocums=false;
    this.deledocums=false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.acceptdocums = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDPROFESSIONALDOC";
      });
      console.log(this.banners);
      if (
        this.banners == "" ||
        this.banners == [] ||
        this.banners == undefined
      ) {
        this.err = true;
        this.acceptdocums = false;
      } else {
        this.err = false;
        this.var11 = this.banners;
      }
    }
  }

  updatedocum()
  {
    this.getBanners();
    this.upstat = false;
    this.rejectprof = false;
    this.showaddbann = false;
    this.showfirst = false;
    this.showdelebann = false;
    this.showupdbann = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.acceptprof = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    this.addvideos = false;
    this.delevideos = false;
    this.acceptdocums=false;
    this.updatedocums=true;
    this.deledocums=false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.updatedocums = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATEPROFESSIONALDOC";
      });
      console.log(this.banners);
      if (
        this.banners == "" ||
        this.banners == [] ||
        this.banners == undefined
      ) {
        this.err = true;
        this.updatedocums = false;
      } else {
        this.err = false;
        this.var12 = this.banners;
      }
    }
  }

  rejctdocum()
  {
    this.getBanners();
    this.upstat = false;
    this.rejectprof = false;
    this.showaddbann = false;
    this.showfirst = false;
    this.showdelebann = false;
    this.showupdbann = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.acceptprof = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    this.addvideos = false;
    this.delevideos = false;
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=true;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.deledocums = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETEPROFESSIONALDOC";
      });
      console.log(this.banners);
      if (
        this.banners == "" ||
        this.banners == [] ||
        this.banners == undefined
      ) {
        this.err = true;
        this.deledocums = false;
      } else {
        this.err = false;
        this.var13 = this.banners;
      }
    }
  }

  ngOnInit(): void {
    this.getBanners();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  getBanners() {
    this.login.GetList().subscribe((data: any) => {
      if (data["status"] == "1069" && data["tokenStatus"] == "1008") {
        this.list = data.pendingList;
        console.log(this.list);
      } else if (data["status"] == "1009" || data["tokenStatus"] == "1009") {
        this.useservice.sendlanguage.subscribe((res) => {
          this.logins.data = res;
        });
        this.logins.usersession();
      } else if (data["tokenStatus"] == "1187") {
        this.useservice.sendlanguage.subscribe((res) => {
          this.logins.data = res;
        });
        this.logins.usersession5();
      } else if (data["status"] == "1070" || data["tokenStatus"] == "1008") {
        this.list = [];
        this.ngxLoader.stop();
      } else if (data["status"]) {
        this.useservice.getallres = data["status"];
        this.better = this.useservice.allrespnse();
        const Toast = Swal.mixin({
          toast: true,
          position: "top-end",
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener("mouseenter", Swal.stopTimer);
            toast.addEventListener("mouseleave", Swal.resumeTimer);
          },
        });

        Toast.fire({
          icon: "error",
          html: `${this.better}`,
        });

        this.ngxLoader.stop();
      }
    });
  }

  addvideo() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.upstat = false;
    this.rejectprof = false;
    this.showaddbann = false;
    this.showfirst = false;
    this.showdelebann = false;
    this.showupdbann = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.acceptprof = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    this.addvideos = true;
    this.delevideos = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.addvideos = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDVIDEO";
      });
      console.log(this.banners);
      if (
        this.banners == "" ||
        this.banners == [] ||
        this.banners == undefined
      ) {
        this.err = true;
        this.addvideos = false;
      } else {
        this.err = false;
        this.addvide = this.banners;
      }
    }
  }

  deletevideo() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.upstat = false;
    this.rejectprof = false;
    this.showaddbann = false;
    this.showfirst = false;
    this.showdelebann = false;
    this.showupdbann = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.acceptprof = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    this.addvideos = false;
    this.delevideos = true;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.delevideos = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETEVIDEO";
      });
      console.log(this.banners);
      if (
        this.banners == "" ||
        this.banners == [] ||
        this.banners == undefined
      ) {
        this.err = true;
        this.delevideos = false;
      } else {
        this.err = false;
        this.delevide = this.banners;
      }
    }
  }

  addbanners() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.showaddbann = true;
    this.showfirst = false;
    this.showdelebann = false;
    this.showupdbann = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.acceptprof = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showaddbann = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDBANNER";
      });
      console.log(this.banners);
      if (
        this.banners == "" ||
        this.banners == [] ||
        this.banners == undefined
      ) {
        this.err = true;
        this.showaddbann = false;
      } else {
        this.err = false;
        this.addban = this.banners;
      }
    }
  }

  updbanners() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = true;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deletecities = false;
    this.deleteaccounts = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showupdbann = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATEBANNER";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.showupdbann = false;
      } else {
        this.err = false;
        this.updban = this.banners;
      }
    }
  }

  delebanners() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = true;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deletecities = false;
    this.deleteaccounts = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showdelebann = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETEBANNER";
      });
      console.log(this.list, this.banners);
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.showdelebann = false;
      } else {
        this.err = false;
        this.deleban = this.banners;
      }
    }
  }

  block() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = true;
    this.unblockss = false;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deletecities = false;
    this.deleteaccounts = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showblock = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "BLOCK";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.showblock = false;
      } else {
        this.err = false;
        this.showblocks = this.banners;
        console.log(this.showblocks);
      }
    }
  }

  unblock() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = true;
    this.cities = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.unblockss = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UNBLOCK";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.unblockss = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.unblocks = this.banners;
        console.log(this.unblocks);
      }
    }
  }

  addcites() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.cities = true;
    this.deleteaccounts = false;
    this.updatecities = false;
    this.deletecities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.cities = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDCITY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.cities = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.addcits = this.banners;
        console.log(this.addcits);
      }
    }
  }

  uptcites() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.cities = false;
    this.deleteaccounts = false;
    this.updatecities = true;
    this.deletecities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.updatecities = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATECITY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.updatecities = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.updcits = this.banners;
        console.log(this.updcits);
      }
    }
  }

  delecites() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.cities = false;
    this.updatecities = false;
    this.deleteaccounts = false;
    this.deletecities = true;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.deletecities = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETECITY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.deletecities = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.delecits = this.banners;
        console.log(this.delecits);
      }
    }
  }

  addoffer() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = true;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showaddoffer = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDOFFER";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.showaddoffer = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.addoffers = this.banners;
        console.log(this.addoffers);
      }
    }
  }

  uptoffer() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = true;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showupdoffer = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATEOFFER";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.showupdoffer = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.updoffers = this.banners;
        console.log(this.updoffers);
      }
    }
  }

  deleoffer() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = true;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.showdeleoffer = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETEOFFER";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.showdeleoffer = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.deleoffers = this.banners;
        console.log(this.deleoffers);
      }
    }
  }

  deleteaccount() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = true;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.deleteaccounts = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATESUPPORTISSUESTATUS";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.deleteaccounts = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.deleaccount = this.banners;
        console.log(this.deleaccount);
      }
    }
  }

  acptprof() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = true;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.acceptprof = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "AcceptProfessional";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.acceptprof = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.acceptpf = this.banners;
        console.log(this.acceptpf);
      }
    }
  }

  rejtprof() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = true;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.rejectprof = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "RejectProfessional";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.rejectprof = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.rejectpf = this.banners;
        console.log(this.acceptpf);
      }
    }
  }

  updstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = true;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.upstat = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATEBOOKINGSTATUS";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.upstat = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.upsts = this.banners;
        console.log(this.upsts);
      }
    }
  }

  viewcatstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = true;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.viewcats = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDCATEGORY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.viewcats = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var1 = this.banners;
        console.log(this.var1);
      }
    }
  }

  updcatstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = true;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.updacats = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATECATEGORY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.updacats = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var2 = this.banners;
        console.log(this.var2);
      }
    }
  }

  delecatstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = true;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.delecats = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETECATEGORY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.delecats = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var3 = this.banners;
        console.log(this.var3);
      }
    }
  }

  addcatsubstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = true;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.viewsubcats = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDSUBCATEGORY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.viewsubcats = false;
      } else {
        this.err = false;
        this.var4 = this.banners;
        console.log(this.var4);
      }
    }
  }

  updcatsubstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = true;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.updasubcats = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATESUBCATEGORY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.updasubcats = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var5 = this.banners;
        console.log(this.var5);
      }
    }
  }

  delecatsubstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = true;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.delesubcats = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETESUBCATEGORY";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.delesubcats = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var6 = this.banners;
        console.log(this.var6);
      }
    }
  }

  viewcatsubtypstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = true;
    this.updasubcatstyp = false;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.viewsubcatstyp = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "ADDSUBCATEGORYTYPE";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.viewsubcatstyp = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var7 = this.banners;
        console.log(this.var7);
      }
    }
  }

  updcatsubtypsstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = true;
    this.delesubcatstyp = false;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.updasubcatstyp = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "UPDATESUBCATEGORYTYPE";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.updasubcatstyp = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var9 = this.banners;
        console.log(this.upsts);
      }
    }
  }

  delecatsubtypstus() {
    this.getBanners();
    this.acceptdocums=false;
    this.updatedocums=false;
    this.deledocums=false;
    this.addvideos = false;
    this.delevideos = false;
    this.upstat = false;
    this.rejectprof = false;
    this.acceptprof = false;
    this.showaddbann = false;
    this.showupdbann = false;
    this.showdelebann = false;
    this.showfirst = false;
    this.showblock = false;
    this.unblockss = false;
    this.showaddoffer = false;
    this.showupdoffer = false;
    this.showdeleoffer = false;
    this.deleteaccounts = false;
    this.deletecities = false;
    this.cities = false;
    this.viewcats = false;
    this.updacats = false;
    this.delecats = false;
    this.viewsubcats = false;
    this.updasubcats = false;
    this.delesubcats = false;
    this.viewsubcatstyp = false;
    this.updasubcatstyp = false;
    this.delesubcatstyp = true;
    if (this.list === undefined || this.list == "" || this.list == []) {
      this.err = true;
      this.delesubcatstyp = false;
    } else {
      this.banners = this.list.filter((element) => {
        return element.type == "DELETESUBCATEGORYTYPE";
      });
      if (this.banners == "" || this.banners == []) {
        this.err = true;
        this.delesubcatstyp = false;
        console.log(this.banners);
      } else {
        this.err = false;
        this.var8 = this.banners;
        console.log(this.var8);
      }
    }
  }

  async selectmethod(val, id) {
    console.log(id, val);
    if (val == "Accepted" || val == "Rejected") {
      if (this.useservice.chooselanguage == "en") {
        const { value: accept } = await Swal.fire({
          title: "Are you sure? You want to change status",
          input: "textarea",
          html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
          showClass: {
            popup: "animate__animated animate__fadeInDown",
          },
          hideClass: {
            popup: "animate__animated animate__fadeOutUp",
          },
          confirmButtonText: "Submit",
          inputValidator: (result) => {
            return !result && "You need to comment";
          },
          showCancelButton: true,
        });

        if (accept) {
          const keys: any = {};
          keys["id"] = id;
          keys["status"] = val;
          keys["comments"] = `${accept}`;

          console.log(accept);

          this.login
            .updateList(keys)
            .pipe(takeUntil(this.destroy$))
            .subscribe((data: any) => {
              console.log(data);
              this.ngxLoader.start();
              if (data["status"] == "1005" && data["tokenStatus"] == "1008") {
                this.getBanners();
                setTimeout(() => {
                  if (this.showaddbann == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.addbanners();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.showupdbann == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updbanners();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  }
                  else if (this.acceptdocums == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.acceptdocum();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } 

                  else if (this.updatedocums == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updatedocum();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } 

                  else if (this.deledocums == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.rejctdocum();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } 
                  else if (this.showdelebann == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.delebanners();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.showblock == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.block();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.unblockss == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.unblock();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.cities == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.addcites();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.updatecities == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.uptcites();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.deletecities == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.delecites();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.showaddoffer == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.addoffer();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.showupdoffer == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.uptoffer();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.showdeleoffer == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.deleoffer();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.deleteaccounts == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.deleteaccount();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.acceptprof == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.acptprof();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.rejectprof == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.rejtprof();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.upstat == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.viewcats == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.viewcatstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.updacats == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updcatstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.delecats == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.delecatstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.viewsubcats == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.addcatsubstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.updasubcats == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updcatsubstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.delesubcats == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.delecatsubstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.viewsubcatstyp == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.viewcatsubtypstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.updasubcatstyp == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updcatsubtypsstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.delesubcatstyp == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.delecatsubtypstus();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.addvideos == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.addvideo();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  } else if (this.delevideos == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.deletevideo();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "Successfully changed",
                      });
                    }, 2500);
                  }
                }, 2500);
              } else if (
                data["status"] == "1009" ||
                data["tokenStatus"] == "1009"
              ) {
                this.useservice.sendlanguage.subscribe((res) => {
                  this.logins.data = res;
                });
                this.logins.usersession();
              } else if (data["tokenStatus"] == "1187") {
                this.useservice.sendlanguage.subscribe((res) => {
                  this.logins.data = res;
                });
                this.logins.usersession5();
              } else if (data["status"]) {
                this.useservice.getallres = data["status"];
                this.better = this.useservice.allrespnse();
                const Toast = Swal.mixin({
                  toast: true,
                  position: "top-end",
                  showConfirmButton: false,
                  timer: 3000,
                  timerProgressBar: true,
                  didOpen: (toast) => {
                    toast.addEventListener("mouseenter", Swal.stopTimer);
                    toast.addEventListener("mouseleave", Swal.resumeTimer);
                  },
                });

                Toast.fire({
                  icon: "error",
                  html: `${this.better}`,
                });
                this.ngxLoader.stop();
              }
            });
        } else {
          this.selectform.controls.resetselect.patchValue("Select");
        }
      } else if (this.useservice.chooselanguage == "ar") {
        const { value: accept } = await Swal.fire({
          title: "هل أنت واثق؟ تريد تغيير الوضع",
          input: "textarea",
          html: `<div style=" padding-top: 25px; direction: rtl; text-align: right;">يرجى التعليق أدناه :</div>`,
          showClass: {
            popup: "animate__animated animate__fadeInDown",
          },
          hideClass: {
            popup: "animate__animated animate__fadeOutUp",
          },
          confirmButtonText: "إرسال",
          inputValidator: (result) => {
            return !result && "تحتاج إلى التعليق";
          },
          cancelButtonText: "إلغاء",
          showCancelButton: true,
        });

        if (accept) {
          const keys: any = {};
          keys["id"] = id;
          keys["status"] = val;
          keys["comments"] = `${accept}`;

          console.log(accept);
          this.ngxLoader.start();
          this.login
            .updateList(keys)
            .pipe(takeUntil(this.destroy$))
            .subscribe((data: any) => {
              if (data["status"] == "1005" && data["tokenStatus"] == "1008") {
                this.getBanners();
                if (this.showaddbann == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.addbanners();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.addvideos == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.addvideo();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.showupdbann == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.updbanners();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.showdelebann == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.delebanners();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.showblock == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.block();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.unblockss == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.unblock();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);

                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.cities == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.addcites();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.updatecities == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.uptcites();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.deletecities == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.delecites();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.showaddoffer == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.addoffer();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.showupdoffer == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.uptoffer();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.showdeleoffer == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.deleoffer();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.deleteaccounts == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.deleteaccount();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.acceptprof == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.acptprof();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.rejectprof == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.rejtprof();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.upstat == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.updstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.viewcats == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.viewcatstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.updacats == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.updcatstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.delecats == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.delecatstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.viewsubcats == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.addcatsubstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.updasubcats == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.updcatsubstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.delesubcats == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.delecatsubstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                }
                else if (this.acceptdocums == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.acceptdocum();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "تغيرت بنجاح",
                      });
                    }, 2500);
                  } 

                  else if (this.updatedocums == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.updatedocum();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                        html: "تغيرت بنجاح",
                      });
                    }, 2500);
                  } 

                  else if (this.deledocums == true) {
                    this.ngxLoader.start();
                    setTimeout(() => {
                      this.rejctdocum();
                      this.selectform.controls.resetselect.patchValue("Select");
                      this.ngxLoader.stop();
                      const Toast = Swal.mixin({
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener("mouseenter", Swal.stopTimer);
                          toast.addEventListener(
                            "mouseleave",
                            Swal.resumeTimer
                          );
                        },
                      });

                      Toast.fire({
                        icon: "success",
                    html: "تغيرت بنجاح",
                      });
                    }, 2500);
                  } 
                
                else if (this.viewsubcatstyp == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.viewcatsubtypstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.updasubcatstyp == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.updcatsubtypsstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                } else if (this.delesubcatstyp == true) {
                  this.ngxLoader.start();
                  setTimeout(() => {
                    this.delecatsubtypstus();
                    this.selectform.controls.resetselect.patchValue("Select");
                    this.ngxLoader.stop();
                  }, 2500);
                  const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener("mouseenter", Swal.stopTimer);
                      toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                  });

                  Toast.fire({
                    icon: "success",
                    html: "تغيرت بنجاح",
                  });
                }
              } else if (
                data["status"] == "1009" ||
                data["tokenStatus"] == "1009"
              ) {
                this.useservice.sendlanguage.subscribe((res) => {
                  this.logins.data = res;
                });
                this.logins.usersession();
              } else if (data["tokenStatus"] == "1187") {
                this.useservice.sendlanguage.subscribe((res) => {
                  this.logins.data = res;
                });
                this.logins.usersession5();
              } else if (data["status"]) {
                this.useservice.getallres = data["status"];
                this.better = this.useservice.allrespnse();
                const Toast = Swal.mixin({
                  toast: true,
                  position: "top-end",
                  showConfirmButton: false,
                  timer: 3000,
                  timerProgressBar: true,
                  didOpen: (toast) => {
                    toast.addEventListener("mouseenter", Swal.stopTimer);
                    toast.addEventListener("mouseleave", Swal.resumeTimer);
                  },
                });

                Toast.fire({
                  icon: "error",
                  html: `${this.better}`,
                });
                this.ngxLoader.stop();
              }
            });
        } else {
          this.selectform.controls.resetselect.patchValue("Select");
        }
      }
    }
  }

  openCompaniesModalview(item: any): void {
    var data51 = true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: "500px",
      data: { data50: item, name51: data51 },
      disableClose: true,
      position: {
        top: "20px",
      },
    });
  }
}
