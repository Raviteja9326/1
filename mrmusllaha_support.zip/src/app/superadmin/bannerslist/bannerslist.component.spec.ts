import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BannerslistComponent } from './bannerslist.component';

describe('BannerslistComponent', () => {
  let component: BannerslistComponent;
  let fixture: ComponentFixture<BannerslistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BannerslistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BannerslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
