import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';


export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
      const control = updateforgotpasswordform.controls[controlName];
      const matchingControl = updateforgotpasswordform.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  fieldTextType: boolean = false;
  fieldTextType2: boolean = false;
  fieldTextType3: boolean = false;
  betters:boolean=false;
  better:boolean=false;
  destroy$: Subject<boolean> = new Subject<boolean>();

  constructor(private ngxLoader: NgxUiLoaderService, private formBuilder: FormBuilder, private router:Router, private details:AllinoneService, private login:AdminService, private logins:LoginService) { if(this.details.accesstoken==undefined){
    this.details.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession();
    } }

  ngOnInit(): void {
  }

  updateforgotpasswordform = this.formBuilder.group({ 
    
    oldCred: ['', [Validators.required,spaceValidator]],
    newCred: ['', [Validators.required,Validators.pattern(/^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/)]],
    conformCred: ['', [Validators.required,Validators.pattern(/^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/)]],
  },{
    validator: MustMatch('newCred', 'conformCred')
  });

  get forgotpasswordControllers() { return this.updateforgotpasswordform.controls }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }
  toggleFieldTextType2() {
    this.fieldTextType2 = !this.fieldTextType2;
  }
  toggleFieldTextType3() {
    this.fieldTextType3 = !this.fieldTextType3;
  }

  changepwd()
  {
    if(this.updateforgotpasswordform.value.newCred == this.updateforgotpasswordform.value.oldCred)
    {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer)
          toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
      })
     
      if(this.details.chooselanguage=="en"){
        Toast.fire({
          icon: 'warning',
          html: `Old password and new password should not be same`
        })
      }
      else if(this.details.chooselanguage=="ar"){
        Toast.fire({
          icon: 'warning',
          html: `<div class="text-right" dir="rtl">يجب ألا تكون كلمة المرور القديمة وكلمة المرور الجديدة متماثلتين</div>`
        })
      }
    }

    else
    {
  this.ngxLoader.start();
  this.login.updatepwd(this.updateforgotpasswordform.value).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        if(this.details.chooselanguage=="en")
       {
        this.updateforgotpasswordform.reset();
        Swal.fire('sucessfully updated', '', 'success')
      }
        else if(this.details.chooselanguage=="ar")
        {
          this.updateforgotpasswordform.reset();
          Swal.fire('تم التحديث بنجاح', '', 'success')
        }
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.details.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.details.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.details.getallres = data['status'] ;
         this.better = this.details.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    })
  }
}

}
