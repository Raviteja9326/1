import { Component, ElementRef, OnInit } from '@angular/core';

@Component({
  selector: 'app-superadmin',
  template: `<router-outlet></router-outlet>`
})
export class SuperadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
