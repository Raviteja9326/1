import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuperadminComponent } from './superadmin.component';
import { SuperadminRoutingModule } from './superadmin-routing.module';
import { UserslistComponent } from './userslist/userslist.component';
import { BannerslistComponent } from './bannerslist/bannerslist.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { ProfileComponent } from './profile/profile.component';


const components = [SuperadminComponent,ProfileComponent,UserslistComponent,BannerslistComponent];


@NgModule({
  declarations: [ ...components],
  imports: [CommonModule,SuperadminRoutingModule,FormsModule,ReactiveFormsModule,TranslateModule]
})
export class SuperadminModule { }
