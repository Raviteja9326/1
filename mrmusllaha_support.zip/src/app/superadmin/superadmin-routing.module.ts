import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BannerslistComponent } from './bannerslist/bannerslist.component';
import { ProfileComponent } from './profile/profile.component';
import { SuperadminComponent } from './superadmin.component';
import { UserslistComponent } from './userslist/userslist.component';


const superadminroutes: Routes = [{
    path: '',
    component: SuperadminComponent,
    children: 
    [
        
{
    path:'userslist',
    component:UserslistComponent
},
{
    path:'profile',
    component:ProfileComponent
},
{
    path:'requestlist',
    component:BannerslistComponent
}
    ],
        
},

];

@NgModule({
    imports: [RouterModule.forChild(superadminroutes)],
    exports: [RouterModule],
})
export class SuperadminRoutingModule { }
