import { Component, DoCheck, HostListener, OnInit } from '@angular/core';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
declare let $:any;
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-dashboard3',
  templateUrl: './dashboard3.component.html',
  styleUrls: ['./dashboard3.component.scss']
})
export class Dashboard3Component implements OnInit{

	names:any;
	type:any;
	showmenu:boolean;
	hggssdsg = true;
	showmenu1:boolean;
	showmenu2:boolean;
	lang:any;
		

  constructor(private useservice:AllinoneService, private loginout:LoginService,private translateService: TranslateService) 
   {
	this.getmenulist()
	this.mylang();
	if( this.useservice.nameUser == 'NA' || this.useservice.nameUser == undefined || this.useservice.type == undefined  || this.useservice.type == 'NA') 
	{
	this.names = "welcome";
	this.type = ""
	}
	else
	{
	  this.names = this.useservice.nameUser;
	  this.type = this.useservice.type
	}
   }

   mylang()
   {
	this.useservice.sendlanguage.subscribe(res => {
		console.log(res)
if(res=="en")
{
	this.lang = 'en';
	this.translateService.use("en").toPromise();
	this.translateService.setDefaultLang('en');
}
else if(res=="ar")
{
	this.lang = 'ar';
	this.translateService.use("ar").toPromise()
	this.translateService.setDefaultLang('ar');
}
	  });
   }

   useLanguage(language) 
{	
	this.lang=language;
	this.useservice.changlang(language);
	this.useservice.chooselanguage = language;
    this.translateService.use(language).toPromise();	
	
}

   getmenulist()
   {
	   if(this.useservice.showmenu == true)
	   {
             this.showmenu=true;
			 this.showmenu1=false;
			 this.showmenu2=false;
	   }
	   else if(this.useservice.showmenu1 == true)
	   {
		this.showmenu1=true;
		this.showmenu=false;
		this.showmenu2=false;
	   }
	   else if(this.useservice.showmenu2 == true)
	   {
		this.showmenu2=true;
		this.showmenu1=false;
		this.showmenu=false;
	   }
   }

  ngOnInit(): void 
  {
    this.jquremethod();
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event:any) {
  	if (window.pageYOffset > 1) {
      $('.top-navbar').addClass("is-sticky");
    } else {
      $('.top-navbar').removeClass("is-sticky");
    }
  }

  jquremethod()
  {
	
    $('.burger-menu').on('click',  () => {
			$(this).toggleClass('active');
			$('.main-content').toggleClass('hide-sidemenu-area');
			$('.sidemenu-area').toggleClass('toggle-sidemenu-area');
			$('.top-navbar').toggleClass('toggle-navbar-area');
		});
		$('.responsive-burger-menu').on('click', function () {
			$('.responsive-burger-menu').toggleClass('active');
			$('.sidemenu-area').toggleClass('active-sidemenu-area');
		});
		$(function () {
			$('[data-toggle="tooltip"]').tooltip();
		});
		$(function () {
			$('[data-toggle="popover"]').popover()
		});
		$(function () {
			$('#sidemenu-nav').metisMenu();
		});
		$('.bx-fullscreen-btn').on('click',  () => {
			$(this).toggleClass('active');
		});
		$(function() {
            $('.accordion').find('.accordion-title').on('click', function() {
                $(this).toggleClass('active');
                $(this).next().slideToggle('fast');
                $('.accordion-content').not($(this).next()).slideUp('fast');
                $('.accordion-title').not($(this)).removeClass('active');
            });
        });
		(function($) {
            $('.tab ul.tabs').addClass('active').find('> li:eq(0)').addClass('current');
            $('.tab ul.tabs li a').on('click', function(g) {
                var tab = $(this).closest('.tab'),
                    index = $(this).closest('li').index();
                tab.find('ul.tabs > li').removeClass('current');
                $(this).closest('li').addClass('current');
                tab.find('.tab_content').find('div.tabs_item').not('div.tabs_item:eq(' + index + ')').slideUp();
                tab.find('.tab_content').find('div.tabs_item:eq(' + index + ')').slideDown();
                g.preventDefault();
            });
        })
  }

  logout()
  {
	this.loginout.usersession2();
  }

}
