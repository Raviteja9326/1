import { Component, DoCheck, HostListener, OnInit } from '@angular/core';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
declare let $:any;
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard2',
  templateUrl: './dashboard2.component.html',
  styleUrls: ['./dashboard2.component.scss']
})
export class Dashboard2Component implements OnInit{

	names:any;
	type:any;
	showmenu:boolean;
	hggssdsg = true;
	showmenu1:boolean;
	showmenu2:boolean;
	lang:any;
		

  constructor(private useservice:AllinoneService, private loginout:LoginService,private translateService: TranslateService, private router:Router) 
   {
	this.getmenulist()
	this.mylang();
	if( this.useservice.nameUser == 'NA' || this.useservice.nameUser == undefined || this.useservice.type == undefined  || this.useservice.type == 'NA') 
	{
	this.names = "welcome";
	this.type = ""
	}
	else
	{
	  this.names = this.useservice.nameUser;
	  this.type = this.useservice.type
	}
   }

   mylang()
   {
	this.useservice.sendlanguage.subscribe(res => {
		console.log(res)
if(res=="en")
{
	this.lang = 'en';
	this.translateService.use("en").toPromise();
	this.translateService.setDefaultLang('en');
}
else if(res=="ar")
{
	this.lang = 'ar';
	this.translateService.use("ar").toPromise()
	this.translateService.setDefaultLang('ar');
}
	  });
   }

   useLanguage(language) 
{	
	this.lang=language;
	this.useservice.changlang(language);
	this.useservice.chooselanguage = language;
    this.translateService.use(language).toPromise();	
	
}

   getmenulist()
   {
	   if(this.useservice.showmenu == true)
	   {
             this.showmenu=true;
			 this.showmenu1=false;
			 this.showmenu2=false;
	   }
	   else if(this.useservice.showmenu1 == true)
	   {
		this.showmenu1=true;
		this.showmenu=false;
		this.showmenu2=false;
	   }
	   else if(this.useservice.showmenu2 == true)
	   {
		this.showmenu2=true;
		this.showmenu1=false;
		this.showmenu=false;
	   }
   }

  ngOnInit(): void 
  {
    this.jquremethod();
  }

  @HostListener('window:scroll', ['$event'])

  getScrollHeight(event:any) {
  	if (window.pageYOffset > 1) {
      $('.top-navbar').addClass("is-sticky");
    } else {
      $('.top-navbar').removeClass("is-sticky");
    }
  }

  jquremethod()
  {
	
    $('.burger-menu').on('click',  () => {
			$(this).toggleClass('active');
			$('.main-content').toggleClass('hide-sidemenu-area');
			$('.sidemenu-area').toggleClass('toggle-sidemenu-area');
			$('.top-navbar').toggleClass('toggle-navbar-area');
		});
		$('.responsive-burger-menu').on('click', function () {
			$('.responsive-burger-menu').toggleClass('active');
			$('.sidemenu-area').toggleClass('active-sidemenu-area');
		});
		$(function () {
			$('[data-toggle="tooltip"]').tooltip();
		});
		$(function () {
			$('[data-toggle="popover"]').popover()
		});
		$(function () {
			$('#sidemenu-nav').metisMenu();
		});
		$('.bx-fullscreen-btn').on('click',  () => {
			$(this).toggleClass('active');
		});
		$(function() {
            $('.accordion').find('.accordion-title').on('click', function() {
                $(this).toggleClass('active');
                $(this).next().slideToggle('fast');
                $('.accordion-content').not($(this).next()).slideUp('fast');
                $('.accordion-title').not($(this)).removeClass('active');
            });
        });
		(function($) {
            $('.tab ul.tabs').addClass('active').find('> li:eq(0)').addClass('current');
            $('.tab ul.tabs li a').on('click', function(g) {
                var tab = $(this).closest('.tab'),
                    index = $(this).closest('li').index();
                tab.find('ul.tabs > li').removeClass('current');
                $(this).closest('li').addClass('current');
                tab.find('.tab_content').find('div.tabs_item').not('div.tabs_item:eq(' + index + ')').slideUp();
                tab.find('.tab_content').find('div.tabs_item:eq(' + index + ')').slideDown();
                g.preventDefault();
            });
        })
  }

  logout()
  {
	this.loginout.usersession2();
  }

  addbanner()
  {
	  this.useservice.setdata('Addbanner');
	  this.router.navigate(['/superadmin/requestlist'])
  }

  updatebanner()
  {
	  this.useservice.setdata('updatebanner');
	  this.router.navigate(['/superadmin/requestlist'])
  }

  deletebanner()
  {
	  this.useservice.setdata('deletebanner');
	  this.router.navigate(['/superadmin/requestlist'])
  }
  addoffer()
  {
	this.useservice.setdata('addoffer');
	this.router.navigate(['/superadmin/requestlist'])
  }
  uptoffer()
  {
	this.useservice.setdata('updateoffer');
	this.router.navigate(['/superadmin/requestlist'])
  }
  deleoffer()
  {
	this.useservice.setdata('deleteoffer');
	this.router.navigate(['/superadmin/requestlist'])
  }
  block()
  {
	this.useservice.setdata('block');
	this.router.navigate(['/superadmin/requestlist'])
  }
  unblock()
  {
	this.useservice.setdata('unblock');
	this.router.navigate(['/superadmin/requestlist'])
  }
  deleteaccount()
  {
	this.useservice.setdata('deleteaccount');
	this.router.navigate(['/superadmin/requestlist'])
  }
  addcites()
  {
	this.useservice.setdata('addcities');
	this.router.navigate(['/superadmin/requestlist'])
  }
  uptcites()
  {
	this.useservice.setdata('updatecites');
	this.router.navigate(['/superadmin/requestlist'])
  }
  delecites()
  {
	this.useservice.setdata('deletecities');
	this.router.navigate(['/superadmin/requestlist'])
  }
  acptprof()
  {
	this.useservice.setdata('accept');
	this.router.navigate(['/superadmin/requestlist'])
  }
  rejtprof()
  {
	this.useservice.setdata('reject');
	this.router.navigate(['/superadmin/requestlist'])
  }
  updstus()
  {
	this.useservice.setdata('bookingstatus');
	this.router.navigate(['/superadmin/requestlist'])
  }
  viewcatstus()
  {
	this.useservice.setdata('addcat');
	this.router.navigate(['/superadmin/requestlist'])
  }
  updcatstus()
  {
	this.useservice.setdata('updcat');
	this.router.navigate(['/superadmin/requestlist'])
  }
  delecatstus()
  {
	this.useservice.setdata('delecat');
	this.router.navigate(['/superadmin/requestlist'])
  }
  addcatsubstus()
  {
	this.useservice.setdata('addsubcat');
	this.router.navigate(['/superadmin/requestlist'])
  }
  updcatsubstus()
  {
	this.useservice.setdata('updsubcat');
	this.router.navigate(['/superadmin/requestlist'])
  }
  delecatsubstus()
  {
	this.useservice.setdata('delesubcat');
	this.router.navigate(['/superadmin/requestlist'])
  }
  viewcatsubtypstus()
  {
	this.useservice.setdata('addsubcattyp');
	this.router.navigate(['/superadmin/requestlist'])
  }
  updcatsubtypsstus()
  {
	this.useservice.setdata('updsubcattyp');
	this.router.navigate(['/superadmin/requestlist'])
  }
  delecatsubtypstus()
  {
	this.useservice.setdata('delesubcattyp');
	this.router.navigate(['/superadmin/requestlist'])
  }
  addvideo()
  {
    this.useservice.setdata('addvideo');
    this.router.navigate(['/superadmin/requestlist'])
  }
  deletevideo()
  {
    this.useservice.setdata('deletevideo');
    this.router.navigate(['/superadmin/requestlist'])
  }

  acptdocum()
  {
    this.useservice.setdata('acceptdocum');
    this.router.navigate(['/superadmin/requestlist'])
  }

  updatedocum()
  {
    this.useservice.setdata('updatedocum');
    this.router.navigate(['/superadmin/requestlist'])
  }

  rejtdocum()
  {
    this.useservice.setdata('rejctdocum');
    this.router.navigate(['/superadmin/requestlist'])
  }

}
