import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit {

  constructor(private login:LoginService,private useservice:AllinoneService) {	}

  ngOnInit(): void 
  {
    if(this.useservice.accesstoken==undefined){
      this.login.usersession();
      }
  }

}
