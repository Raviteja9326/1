import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-errordash',
  templateUrl: './errordash.component.html',
  styleUrls: ['./errordash.component.scss']
})
export class ErrordashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
