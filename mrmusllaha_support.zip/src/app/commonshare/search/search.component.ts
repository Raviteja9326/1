import { ChangeDetectorRef, Component, ElementRef, HostListener, Inject, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AllinoneService } from 'src/app/services/allinone.service';
import {ENTER, COMMA, F} from '@angular/cdk/keycodes';
import Swal from 'sweetalert2';
import { MatChipInputEvent } from '@angular/material/chips';
import { AdminService } from 'src/app/services/admin.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';



@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  cat: any;
  viewcat: any;
  addcat: boolean = false;
  viewcatbol: boolean = false;
  updtcatbol: boolean = false;
  showfirstform: boolean = true;
  showsecondform: boolean = false;
  betters: boolean = false;
  better: boolean = false;
  f: File;
  f2: File;
  baseUrl: any = "https://images.mrmusllaha.com/subcategories/";
  baseUrl2: any = "https://images.mrmusllaha.com/categories/";
  baseUrl3: any = "https://images.mrmusllaha.com/profile/";
  baseUrl4: any = "https://images.mrmusllaha.com/banners/";
  baseUrl5: any = "https://images.mrmusllaha.com/subcategorytypes/";
  baseUrl6: any = "https://videos.mrmusllaha.com/";
  objectKeys = Object.keys;
  fileData: any;
  editFile: boolean = true;
  removeUpload: boolean = false;
  imageUrl: any;
  @ViewChild('fileInput') fileUploader: ElementRef;
  destroy$: Subject < boolean > = new Subject < boolean > ();
  fileData2: any;
  editFile2: boolean = true;
  removeUpload2: boolean = false;
  addsubcat: boolean = false;
  imageUrl2: any;
  @ViewChild('fileInput2') fileUploader2: ElementRef;
  
  fileData3: any;
  editFile3: boolean = true;
  removeUpload3: boolean = false;
  @ViewChild('fileInput3') fileUploader3: ElementRef;
  
  selectable2: boolean = true;
  removable2: boolean = true;
  addOnBlur2: boolean = true;
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = true;
  submitted: boolean = false;
  selectable3: boolean = true;
  removable3: boolean = true;
  addOnBlur3: boolean = true;
  selectable4: boolean = true;
  removable4: boolean = true;
  addOnBlur4: boolean = true;
  subcatid: any;
  subcatview: any;
  viewsubcat:boolean=false;
  subcatupd:any;
  updsubcat:boolean=false;
  viewsubcattyp:boolean=false;
  subcattypview:any;
  addsubcattyp:boolean=false;
  addsubcattype1:boolean=false;
  addsubcattype2:boolean=false;
  getsearchdetailss:any;
  viewvideo2:boolean = false;
  
  // Enter, comma
  separatorKeysCodes = [ENTER, COMMA];
  
  fruits: any;
  getcities: any;
  steadyfisrt: boolean=false;
  subcattypupda: any;
  citydats: any;
  cattypeen: any;
  cattypear: any;
  catgnamear: any;
  catgnameeb: any;
  typeviewcat: any;
  metadataen: any;
  metadataar: any;
  subcatgnameeb: any;
  subcatgnamear: any;
  data1: boolean;
  ingredients: any;
  viewvideo:boolean=false
  viewdata: any;
  nextdata: any;
  subcatid2: any;
  data120: any;
  data121: any;
  viewdata2: any;
  newusergroup: FormGroup;
  
  add(event: MatChipInputEvent): void
  {
    const input = event.input;
    const value = event.value;
  
    // Add our fruit
    if ((value || '').trim())
    {
      this.fruits.push(value.trim());
      console.log(this.fruits)
    }
  
    // Reset the input value
    if (input)
    {
      input.value = '';
    }
  }
  
  remove(fruit): void
  {
    const index = this.fruits.indexOf(fruit);
  
    if (index >= 0)
    {
      this.fruits.splice(index, 1);
    }
  }
  
  
  fruits2: any;
  
  add2(event: MatChipInputEvent): void
  {
    const input = event.input;
    const value = event.value;
  
    // Add our fruit
    if ((value || '').trim())
    {
      this.fruits2.push(value.trim());
    }
  
    // Reset the input value
    if (input)
    {
      input.value = '';
    }
  }
  
  remove2(fruit): void
  {
    const index = this.fruits2.indexOf(fruit);
  
    if (index >= 0)
    {
      this.fruits2.splice(index, 1);
    }
  }
  
  fruits3: any = [];
  
  add3(event: MatChipInputEvent): void
  {
    const input = event.input;
    const value = event.value;
  
    // Add our fruit
    if ((value || '').trim())
    {
      this.fruits3.push(value.trim());
      console.log(this.fruits)
    }
  
    // Reset the input value
    if (input)
    {
      input.value = '';
    }
  }
  
  remove3(fruit): void
  {
    const index = this.fruits3.indexOf(fruit);
  
    if (index >= 0)
    {
      this.fruits3.splice(index, 1);
    }
  }
  
  fruits4: any = [];
  
  add4(event: MatChipInputEvent): void
  {
    const input = event.input;
    const value = event.value;
  
    // Add our fruit
    if ((value || '').trim())
    {
      this.fruits4.push(value.trim());
      console.log(this.fruits)
    }
  
    // Reset the input value
    if (input)
    {
      input.value = '';
    }
  }
  
  remove4(fruit): void
  {
    const index = this.fruits4.indexOf(fruit);
  
    if (index >= 0)
    {
      this.fruits4.splice(index, 1);
    }
  }
  
  
  constructor(private ngxLoader: NgxUiLoaderService, private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router, private useservice: AllinoneService,private logins:LoginService, private admin: AdminService, public dialogRef: MatDialogRef < SearchComponent > , @Inject(MAT_DIALOG_DATA) public data: any = [], private cd: ChangeDetectorRef)
  {
  }
  
  offersform = this.formBuilder.group(
  {
    categoryNameEn: new FormControl('', [Validators.required,
      Validators.pattern('^[a-zA-Z\\s&]+$')
    ]),
    categoryNameAr: new FormControl('', [Validators.required,
      Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$'), Validators.maxLength(40)
    ]),
    categoryimage: [''],
    bannerPath: [''],
  })
  
  get offerControllers()
  {
    return this.offersform.controls
  }

  offers9form = this.formBuilder.group(
    {
      categoryNameEn: new FormControl('', [Validators.required,
        Validators.pattern('^[a-zA-Z\\s&]+$')
      ]),
      categoryNameAr: new FormControl('', [Validators.required,
        Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$'), Validators.maxLength(40)
      ]),
      categoryimage: ['',Validators.required],
      bannerPath: ['',Validators.required],
    })
    
    get offer9Controllers()
    {
      return this.offers9form.controls
    }
  
  
  offers2form = this.formBuilder.group(
  {
    categoryTypesEn: new FormControl('', [Validators.required,
      Validators.pattern('^[a-zA-Z\\s]+$')
    ]),
    categoryTypesAr: new FormControl('', [Validators.required,
      Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$'), Validators.maxLength(40)
    ]),
  })
  
  get offer2Controllers()
  {
    return this.offers2form.controls
  }
  
  
  offers3form = this.formBuilder.group(
  {
    subCategoryNameEn: new FormControl('', [Validators.required,
      Validators.pattern('^[a-zA-Z\\s&]+$')
    ]),
    subCategoryNameAr: new FormControl('', [Validators.required,
      Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$')
    ]),
    descriptionEn: new FormControl('', [Validators.required
    ]),
    descriptionAr: new FormControl('', [Validators.required
    ]),
    subCategoryImage: [''],
  })
  
  get offer3Controllers()
  {
    return this.offers3form.controls
  }

  offersaddform = this.formBuilder.group(
    {
      subCategoryNameEn: new FormControl('', [Validators.required,
        Validators.pattern('^[a-zA-Z\\s&]+$')
      ]),
      subCategoryNameAr: new FormControl('', [Validators.required,
        Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$')
      ]),
      descriptionEn: new FormControl('', [Validators.required
      ]),
      descriptionAr: new FormControl('', [Validators.required
      ]),
      subCategoryImage: ['',Validators.required],
    })
    
    get offeraddControllers()
    {
      return this.offersaddform.controls
    }
  

  
  uploadFile(event)
  {
    let reader = new FileReader();
    this.fileData = event.target.files[0];
    //console.log(this.fileData)
    let img = new Image()
    img.src = window.URL.createObjectURL(event.target.files[0])
    img.onload = () =>
    {
      if (img.width === 800 && img.height === 400)
      {
        if (event.target.files && event.target.files[0])
        {
  
          reader.readAsDataURL(this.fileData);
          // When file uploads set it to file formcontrol
          reader.onload = () =>
          {
            this.editFile = false;
            this.removeUpload = true;
          }
          // ChangeDetectorRef since file is loading outside the zone
          this.cd.markForCheck();
        }
        // upload logic here
      }
      else
      {
        const Toast = Swal.mixin(
        {
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 4000,
          timerProgressBar: true,
          didOpen: (toast) =>
          {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        if (this.useservice.chooselanguage == "en")
        {
          Toast.fire(
          {
            icon: 'error',
            html: `Sorry, this image doesn't look like the size we wanted. <br/> It's
                    ${img.width} x ${img.height}.`
          })
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Toast.fire(
          {
            icon: 'error',
            html: `عذرًا ، هذه الصورة لا تبدو بالحجم الذي أردناه. <br/>
                      ${img.width} x ${img.height}.`
          })
        }
  
        this.fileUploader.nativeElement.value = "";
        this.fileData = [];
        this.offers9form.controls.bannerPath.patchValue('');
      }
    }
  }
  
  
  uploadFile2(event)
  {
    let reader = new FileReader();
    this.fileData2 = event.target.files[0];
    //console.log(this.fileData)
    let img = new Image()
    img.src = window.URL.createObjectURL(event.target.files[0])
    img.onload = () =>
    {
      if (img.width === 100 && img.height === 100)
      {
        if (event.target.files && event.target.files[0])
        {
  
          reader.readAsDataURL(this.fileData2);
          // When file uploads set it to file formcontrol
          reader.onload = () =>
          {
            this.editFile2 = false;
            this.removeUpload2 = true;
          }
          // ChangeDetectorRef since file is loading outside the zone
          this.cd.markForCheck();
        }
        // upload logic here
      }
      else
      {
        const Toast = Swal.mixin(
        {
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 4000,
          timerProgressBar: true,
          didOpen: (toast) =>
          {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        if (this.useservice.chooselanguage == "en")
        {
          Toast.fire(
          {
            icon: 'error',
            html: `Sorry, this image doesn't look like the size we wanted. <br/> It's
                    ${img.width} x ${img.height}.`
          })
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Toast.fire(
          {
            icon: 'error',
            html: `عذرًا ، هذه الصورة لا تبدو بالحجم الذي أردناه. <br/>
                      ${img.width} x ${img.height}.`
          })
        }
  
        this.fileUploader2.nativeElement.value = "";
        this.fileData2 = [];
        this.offers9form.controls.categoryimage.patchValue('');
      }
    }
  }
  
  uploadFile3(event)
  {
    let reader = new FileReader();
    this.fileData3 = event.target.files[0];
    //console.log(this.fileData)
    let img = new Image()
    img.src = window.URL.createObjectURL(event.target.files[0])
    img.onload = () =>
    {
      if (img.width === 120 && img.height === 120)
      {
        if (event.target.files && event.target.files[0])
        {
  
          reader.readAsDataURL(this.fileData3);
          // When file uploads set it to file formcontrol
          reader.onload = () =>
          {
            this.editFile3 = false;
            this.removeUpload3 = true;
          }
          // ChangeDetectorRef since file is loading outside the zone
          this.cd.markForCheck();
        }
        // upload logic here
      }
      else
      {
        const Toast = Swal.mixin(
        {
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 4000,
          timerProgressBar: true,
          didOpen: (toast) =>
          {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        if (this.useservice.chooselanguage == "en")
        {
          Toast.fire(
          {
            icon: 'error',
            html: `Sorry, this image doesn't look like the size we wanted. <br/> It's
                    ${img.width} x ${img.height}.`
          })
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Toast.fire(
          {
            icon: 'error',
            html: `عذرًا ، هذه الصورة لا تبدو بالحجم الذي أردناه. <br/>
                      ${img.width} x ${img.height}.`
          })
        }
  
        this.fileUploader3.nativeElement.value = "";
        this.fileData3 = [];
        this.offers3form.controls.subCategoryImage.patchValue('');
        this.offersaddform.controls.subCategoryImage.patchValue('');
        this.addmore.controls.bannerImage.patchValue('')
      }
    }
  }
  
  
  ngOnInit(): void
  {
    this.cat = this.data.name;
    if (this.data.name1 === true || this.data.name2 === true)
    {
      this.categviewupdate();
    }
    else if (this.data.name3 === true)
    {
      this.addcateg();
    }
    else if (this.data.name4 === true)
    {
      this.subcatid = this.data.id.categoryId
      this.cattypeen = this.data.id.categoryTypesEn
      this.cattypear = this.data.id.categoryTypesAr
      this.catgnamear = this.data.id.categoryNameAr
      this.catgnameeb = this.data.id.categoryNameEn
      console.log(this.data.id)
      this.addsubcateg();
    }
    else if (this.data.name5 === true)
    {
      this.subcatview = this.data.dat
      this.viewsubcateg();
    }
    else if (this.data.name6 === true)
    {
      this.subcatupd = this.data.dat
      this.updsubcateg();
    }
    else if (this.data.name7 === true)
    {
      this.subcattypview = this.data.dat1
      console.log(this.subcattypview.citiesPrices)
      this.subcategtyp();
    }
    else if (this.data.name8 === true)
    {
      this.subcatid = this.data.dat2.subCategoryId
      this.addsubcategtyp();
      this.countrysubmit();
    }
    else if (this.data.name9 === true)
    {
      this.subcatid = this.data.dat9.subCategoryId;
      this.subcatid2 = this.data.dat9.subCategoryTypeId;
      console.log(this.subcatid)
      this.subcattypupda = this.data.dat9
      console.log(this.subcattypupda)
      this.updsubcategtyp();
      this.countrysubmit();
    }
    else if(this.data.name59 == true)
    {
      this.viewvideo2 = true;
      this.viewdata2 = this.data.data59;
      console.log(this.viewdata)
    }
    else if(this.data.name51 == true)
    {
      this.viewvideo = true;
      this.viewdata = this.data.data50;
      console.log(this.viewdata)
    }
   
  }

 addmore = this.formBuilder.group({
    subCategoryTypeNameEn:['',Validators.required],
    subCategoryTypeNameAr:['',Validators.required],
    descriptionEn:['',Validators.required],
    descriptionAr:['',Validators.required],
    bannerImage:['',Validators.required],
  });

  get fx() { return this.addmore.controls; }


 updatemore = this.formBuilder.group({
    subCategoryTypeNameEn:['',Validators.required],
    subCategoryTypeNameAr:['',Validators.required],
    descriptionEn:['',Validators.required],
    descriptionAr:['',Validators.required],
  });

  get fxup() { return this.updatemore.controls; }

 
  
  categviewupdate()
  {
  
    for (let item of this.objectKeys(this.cat))
    {
      if (item == "categoryId" && this.data.name1 === true)
      {
        this.viewcatbol = true;
        this.updtcatbol = false;
        this.viewcat = this.cat
        console.log(this.viewcat)
      }
      else if (item == "categoryId" && this.data.name2 === true)
      {
        this.viewcatbol = false;
        this.updtcatbol = true;
        this.viewcat = this.cat
        console.log(this.viewcat)
        this.fruits = this.viewcat.categoryTypesAr,
          this.fruits2 = this.viewcat.categoryTypesEn
        this.offersform.setValue(
        {
          categoryNameEn: this.viewcat.categoryNameEn,
          categoryNameAr: this.viewcat.categoryNameAr,
          categoryimage: "",
          bannerPath: ""
        });
      }
    }
  }
  
  addcateg()
  {
    if (this.data.name3 === true)
    {
      this.viewcatbol = false;
      this.updtcatbol = false;
      this.addcat = true
    }
  }
  
  addsubcateg()
  {
    this.viewcatbol = false;
    this.updtcatbol = false;
    this.addcat = false;
    this.addsubcat = true;
  }
  
  viewsubcateg()
  {
    this.viewcatbol = false;
    this.updtcatbol = false;
    this.addcat = false;
    this.addsubcat = false;
    this.viewsubcat = true;
  }
  
  updsubcateg()
  {
    this.viewcatbol = false;
    this.updtcatbol = false;
    this.addcat = false;
    this.addsubcat = false;
    this.viewsubcat = false;
    this.updsubcat= true;
    this.offers3form.setValue(
      {
        subCategoryNameEn: this.subcatupd.subCategoryNameEn,
        subCategoryNameAr: this.subcatupd.subCategoryNameAr,
        descriptionEn: this.subcatupd.subCategoryNameEn,
        descriptionAr: this.subcatupd.subCategoryNameAr,
        subCategoryImage: ""
      });
  }

  subcategtyp()
  {
    this.viewcatbol = false;
    this.updtcatbol = false;
    this.addcat = false;
    this.addsubcat = false;
    this.viewsubcat = false;
    this.updsubcat= false;
    this.viewsubcattyp=true;
  }

  addsubcategtyp()
  {
    console.log(this.data.dat2)
    this.catgnameeb = this.data.dat2.categoryNameEn
    this.catgnamear = this.data.dat2.categoryNameAr
    this.subcatgnameeb = this.data.dat2.subCategoryNameEn
    this.subcatgnamear = this.data.dat2.subCategoryNameAr
    this.viewcatbol = false;
    this.updtcatbol = false;
    this.addcat = false;
    this.addsubcat = false;
    this.viewsubcat = false;
    this.updsubcat= false;
    this.viewsubcattyp=false;
    this.addsubcattyp=true;
    this.addsubcattype1=true;
    this.addsubcattype2=false;
    this.data1=false
  }

  updsubcategtyp()
  {
    this.catgnameeb = this.subcattypupda.categoryNameEn
    this.catgnamear = this.subcattypupda.categoryNameAr
    this.subcatgnameeb = this.subcattypupda.subCategoryNameEn
    this.subcatgnamear = this.subcattypupda.subCategoryNameAr
    this.viewcatbol = false;
    this.updtcatbol = false;
    this.addcat = false;
    this.addsubcat = false;
    this.viewsubcat = false;
    this.updsubcat= false;
    this.viewsubcattyp=false;
    this.addsubcattyp=false;
    this.addsubcattype1=true;
    this.addsubcattype2=true;
    this.data1=false
    this.updatemore.setValue(
      {
        subCategoryTypeNameEn: this.subcattypupda.subCategoryTypeNameEn,
        subCategoryTypeNameAr: this.subcattypupda.subCategoryTypeNameAr,
        descriptionEn: this.subcattypupda.descriptionEn,
        descriptionAr: this.subcattypupda.descriptionAr
      });
  }

  subcatssubmit()
  {
    var formData = new FormData();
    if (this.fileData3 == null || this.fileData3 == 0 || this.fileData3 == undefined || this.fileData3 == "")
    {
      this.f = new File([""], "filename");
      formData.append("subCategoryImage", this.f);
    }
    else
    {
      this.f = this.fileData3;
      formData.append("subCategoryImage", this.f);
    }
    formData.append("subCategoryNameEn", this.offers3form.value.subCategoryNameEn);
    formData.append("subCategoryNameAr", this.offers3form.value.subCategoryNameAr);
    formData.append("categoryId", this.subcatupd.categoryId);
    formData.append("subCategoryId", this.subcatupd.subCategoryId);
    formData.append("descriptionEn", this.offers3form.value.descriptionEn);
    formData.append("descriptionAr", this.offers3form.value.descriptionAr);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.admin.upsubcat(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any) =>
    {
      console.log(data)
      if (data['status'] == '1005' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('sucessfully updated, Please wait for superadmin acceptance', '', 'success')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.offers3form.reset();
        setTimeout(() =>
        {
          this.addsubcateg();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1117' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        setTimeout(() =>
        {
          this.addcateg();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
      else if (data['status'] == '1069')
      {
        this.ngxLoader.stop()
      }
  
      else if (data['status'])
      {
        this.useservice.getallres = data['status'];
        this.better = this.useservice.allrespnse();
        this.betters = true
        setTimeout(() =>
        {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }

  subcatupsubmit()
  {
    var formData = new FormData();
    if (this.fileData3 == null || this.fileData3 == 0 || this.fileData3 == undefined || this.fileData3 == "")
    {
      this.f = new File([""], "filename");
      formData.append("subCategoryImage", this.f);
    }
    else
    {
      this.f = this.fileData3;
      formData.append("subCategoryImage", this.f);
    }
    formData.append("subCategoryNameEn", this.offersaddform.value.subCategoryNameEn);
    formData.append("subCategoryNameAr", this.offersaddform.value.subCategoryNameAr);
    formData.append("categoryId", this.subcatid);
    formData.append("descriptionEn", this.offersaddform.value.descriptionEn);
    formData.append("descriptionAr", this.offersaddform.value.descriptionAr);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.admin.addsubcat(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any) =>
    {
      console.log(data)
      if (data['status'] == '1005' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.offers3form.reset();
        setTimeout(() =>
        {
          this.addsubcateg();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1117' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        setTimeout(() =>
        {
          this.addcateg();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
      else if (data['status'] == '1069')
      {
        this.ngxLoader.stop()
      }
  
      else if (data['status'])
      {
        this.useservice.getallres = data['status'];
        this.better = this.useservice.allrespnse();
        this.betters = true
        setTimeout(() =>
        {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }
  
  @HostListener('document:keyup.escape') onClose()
  {
    this.onCancel();
  }
  
  onCancel()
  {
    this.dialogRef.close();
  }
  
  catupsubmit()
  {
    this.showfirstform = false;
    this.showsecondform = true;
    this.metadataen=this.offers9form.value.categoryNameEn
    this.metadataar=this.offers9form.value.categoryNameAr
  }
  
  addsubmit2()
  {
    if (!this.offers2form.valid) {
      Object.keys(this.offers2form.controls).forEach(field => {
        const controlk:any = this.offers2form.get(field);
        controlk.markAsTouched({ onlySelf: true });
      });
        this.submitted = true;
    }
    else {
    var formData = new FormData();
    if (this.fileData == null || this.fileData == 0 || this.fileData == undefined || this.fileData == "" || this.fileData2 == null || this.fileData2 == 0 || this.fileData2 == undefined || this.fileData2 == "")
    {
      this.f = new File([""], "filename");
      formData.append("categoryimage", this.f);
      formData.append("bannerPath", this.f);
    }
    else
    {
      this.f = this.fileData;
      this.f2 = this.fileData2;
      formData.append("categoryimage", this.f2);
      formData.append("bannerPath", this.f);
    }
    formData.append("categoryNameEn", this.offers9form.value.categoryNameEn);
    formData.append("categoryNameAr", this.offers9form.value.categoryNameAr);
    formData.append("categoryTypesEn", this.fruits3);
    formData.append("categoryTypesAr", this.fruits4);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.admin.addcat(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any) =>
    {
      console.log(data)
      if (data['status'] == '1005' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.offersform.reset();
        setTimeout(() =>
        {
          this.addcateg();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1117' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        { 
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        setTimeout(() =>
        {
          this.addcateg();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1070' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          this.viewsubcat=false;
          Swal.fire('No record available', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          this.viewsubcat=false;
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
      else if (data['status'] == '1069')
      {
        this.ngxLoader.stop()
      }
  
      else if (data['status'])
      {
        this.useservice.getallres = data['status'];
        this.better = this.useservice.allrespnse();
        this.betters = true
        setTimeout(() =>
        {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }
  }
  
  catupsubmit2()
  {
    
    var formData = new FormData();
    if (this.fileData2 == null || this.fileData2 == 0 || this.fileData2 == undefined || this.fileData2 == "")
    {
      this.f = new File([""], "filename");
      formData.append("categoryimage", this.f);
    }
    if(this.fileData == null || this.fileData == 0 || this.fileData == undefined || this.fileData == "")
    {
      this.f = new File([""], "filename");
      formData.append("bannerPath", this.f);
    }
    if (this.fileData2 !== null || this.fileData2 !== 0 || this.fileData2 !== undefined || this.fileData2 !== "")
    {
      this.f2 = this.fileData2;
      formData.append("categoryimage", this.f2);
    }
    if(this.fileData !== null || this.fileData !== 0 || this.fileData !== undefined || this.fileData !== "")
    {
      this.f = this.fileData;
      formData.append("bannerPath", this.f);
    }
    formData.append("categoryNameEn", this.offersform.value.categoryNameEn);
    formData.append("categoryNameAr", this.offersform.value.categoryNameAr);
    formData.append("categoryId", this.viewcat.categoryId);
    formData.append("categoryTypesEn", this.fruits2);
    formData.append("categoryTypesAr", this.fruits);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.admin.updcat(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any) =>
    {
      console.log(data)
      if (data['status'] == '1005' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('sucessfully updated, Please wait for superadmin acceptance', '', 'success')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.offersform.reset();
        setTimeout(() =>
        {
          this.categviewupdate();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1117' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        setTimeout(() =>
        {
          this.categviewupdate();
        }, 1500);
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
      else if (data['status'] == '1069')
      {
        this.ngxLoader.stop()
      }
  
      else if (data['status'])
      {
        this.useservice.getallres = data['status'];
        this.better = this.useservice.allrespnse();
        this.betters = true
        setTimeout(() =>
        {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }
  
  ngOnDestroy()
  {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  countrysubmit()
  {
       
    const keys:any={}


    
    keys['type'] = 'GETCITES';
    keys['countryName'] = "SaudiArabia";

    this.admin.getcities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
      if(data['status']=='1069' && data['tokenStatus']=="1008")
      {   
          this.getsearchdetailss=data.cites_list
        console.log( this.getsearchdetailss)
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
    
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
       }
    }) 
  }

  subcatstypssubmit()
  {
    const jar=JSON.stringify(this.addForm.value.rows)
    console.log(jar,this.addForm.value.rows)
    var formData = new FormData();
    if (this.fileData3 == null || this.fileData3 == 0 || this.fileData3 == undefined || this.fileData3 == "")
    {
      this.f = new File([""], "filename");
      formData.append("subCategoryTypeImage", this.f);
    }
    else
    {
      this.f = this.fileData3;
      formData.append("subCategoryTypeImage", this.f);
    }
    formData.append("subCategoryTypeNameEn", this.addmore.value.subCategoryTypeNameEn);
    formData.append("subCategoryTypeNameAr", this.addmore.value.subCategoryTypeNameAr);
    formData.append("subCategoryId", this.subcatid);
    formData.append("descriptionEn", this.addmore.value.descriptionEn);
    formData.append("descriptionAr", this.addmore.value.descriptionAr);
    formData.append("cityAndPrices", jar);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.admin.addcattyp(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any) =>
    {
      console.log(data)
      if (data['status'] == '1005' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.addmore.reset();
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1117' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
      else if (data['status'] == '1069')
      {
        this.ngxLoader.stop()
      }
  
      else if (data['status'])
      {
        this.useservice.getallres = data['status'];
        this.better = this.useservice.allrespnse();
        this.betters = true
        setTimeout(() =>
        {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  datas()
  {
    this.data120 = this.addmore.value.subCategoryTypeNameEn;
    this.data121 = this.addmore.value.subCategoryTypeNameAr
    this.data1=true;
    this.addForm = this.formBuilder.group({
      rows: this.formBuilder.array([this.initGroup()])
    });
  }

  datas2(item:any)  {
    console.log(item)
    this.initGroup();
    this.data120 = item.subCategoryTypeNameEn;
    this.data121 = item.subCategoryTypeNameAr 

    for(let dtas of item.citiesPrices)
    {
      console.log(dtas)
      this.newusergroup = this.formBuilder.group({
       cityar:  dtas.cityar,
       price: dtas.price,
       cityen: dtas.cityen,
      })
      this.formArr.push(this.newusergroup)
    }
    
       this.data1=true;
   
   
  }

  addForm:FormGroup = this.formBuilder.group({
    rows: this.formBuilder.array([])
  });

  get fxs() { return this.addForm.controls;}

  get formArr() {
    return this.addForm.get('rows') as FormArray;
  }
  

  addNewRow() {
    this.formArr.push(this.initGroup());
  }


  onDeleteRow(rowIndex) {
    this.formArr.removeAt(rowIndex);
    this.disableRows(this.formArr);
  }

  onDeleteRow2(rowIndex) {
    this.formArr.removeAt(rowIndex);
  }

  initGroup() {
    return this.formBuilder.group({
      cityen: ['', Validators.required],
      cityar: ['',Validators.required],
      price: ['', Validators.required],
    })
  }

  disableRows(rows){
    rows.controls.forEach((control, index) => {
      if(index !== rows.controls.length - 1){
        control.controls['cityen'].disable();
        control.controls['price'].disable();
      }else{
        control.controls['cityen'].enable();
        control.controls['price'].enable();
      }
    })
  }

  disableRows2(rows){
    rows.controls.forEach((control, index) => {
        control.controls['cityen'].disable();
    })
  }

  patchValues(id,i) {
    console.log(id,i)
    let x = (<FormArray>this.addForm.controls['rows']).at(i);
    console.log(x)
    for(let data of this.getsearchdetailss)
    {
      if(data.cityNameEn == id)
      {
       this.nextdata = data
      }
    }
    x.patchValue({
      cityar: this.nextdata.cityNameAr,
    });
   
  }

  onSelectIngredient(event,i): void {
    console.log(event)
    const formData = {
      cityId: event.target.value
    }
    console.log(formData,i);
    this.patchValues(event.target.value,i);
  }

  subcatstypsupsubmit()
  {
    const jar=JSON.stringify(this.addForm.value.rows)
    var formData = new FormData();
    if (this.fileData3 == null || this.fileData3 == 0 || this.fileData3 == undefined || this.fileData3 == "")
    {
      this.f = new File([""], "filename");
      formData.append("subCategoryTypeImage", this.f);
    }
    else
    {
      this.f = this.fileData3;
      formData.append("subCategoryTypeImage", this.f);
    }
    formData.append("subCategoryTypeNameEn", this.updatemore.value.subCategoryTypeNameEn);
    formData.append("subCategoryTypeNameAr", this.updatemore.value.subCategoryTypeNameAr);
    formData.append("subCategoryId", this.subcatid);
    formData.append("subCategoryTypeId", this.subcatid2);
    formData.append("descriptionEn", this.updatemore.value.descriptionEn);
    formData.append("descriptionAr", this.updatemore.value.descriptionAr);
    formData.append("cityAndPrices", jar);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.admin.addcattyp2(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any) =>
    {
      console.log(data)
      if (data['status'] == '1005' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('sucessfully updated, Please wait for superadmin acceptance', '', 'success')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.addmore.reset();
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1117' && data['tokenStatus'] == "1008")
      {
        if (this.useservice.chooselanguage == "en")
        {
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        }
        else if (this.useservice.chooselanguage == "ar")
        {
          Swal.fire('يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
        this.offersform.reset();
        this.onCancel();
        this.ngxLoader.stop();
      }
      else if (data['status'] == '1009' || data['tokenStatus'] == '1009')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession()
      }
      else if (data['tokenStatus']=='1187')
      {
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.onCancel();
        this.logins.usersession5()
      }
      else if (data['status'] == '1069')
      {
        this.ngxLoader.stop()
      }
  
      else if (data['status'])
      {
        this.useservice.getallres = data['status'];
        this.better = this.useservice.allrespnse();
        this.betters = true
        setTimeout(() =>
        {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }
  
  
  }