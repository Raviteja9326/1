import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-professionalcategories',
  templateUrl: './professionalcategories.component.html',
  styleUrls: ['./professionalcategories.component.scss']
})
export class ProfessionalcategoriesComponent implements OnInit {

  type:any;
  viewprofessional:boolean=false;
  updateprofessional:boolean=false;
  searchprofessional:boolean=true;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  getsearchdetails:any;
  viewsubcat:boolean=false
  viewtable:any;
  subviewcat:any;
  viewsubcatattr:boolean=false;
  subviewcatattr:any;
  viewtypsub:boolean=false;
  subviewcattpye:any;
  viewtypsubattr:boolean=false;
  subviewcattpyeattr:any;
  viewtypsubtyps:boolean=false;
  subviewcattpyes:any;
  get1:boolean=false;
  get12:boolean=false;
  get13:boolean=false;
  get134:boolean=false;
  get1345:boolean=false;
  baseUrl="https://images.mrmusllaha.com/categories/"


  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef,private logins:LoginService) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  searchform = this.formBuilder.group({
    mobileNumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]]
  })

  get searchsingle(){
    return this.searchform.controls;
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  block1()
  {
    this.get1=false;
    this.get12=false;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.viewprofessional=false;
    this.viewsubcat=false;
    this.viewsubcatattr=false;
    this.viewtypsub=false;
    this.viewtypsubattr=false;
    this.viewtypsubtyps=false;
    this.updateprofessional=false;
    this.searchprofessional=true;
    this.searchform.reset();
   
  }
  
  block2()
  {
    this.updateprofessional=false;
    this.viewprofessional=true;
    this.searchprofessional=false;
    this.viewtable=this.getsearchdetails.getCatSubCat_list
    console.log(this.viewtable)
  }

  ngOnInit(): void {
  }

  searchUser()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['type'] = 'PROFESSIONALCATEGORYES';
    keys['mobileNumber'] = '966'+this.searchform.value.mobileNumber;

    this.login.getprofessionals(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data,data.area)
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        this.getsearchdetails=data;
        console.log(this.getsearchdetails)
        this.block2();
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }

  alerts()
  {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 4000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    Toast.fire({
      icon: 'warning',
      html: `No Record found`
    })
  }

  subcata(keys)
  {
    console.log(keys)
    if(keys.subcategories===undefined || keys.subcategories==="" || keys.subcategories===[])
    {
      this.alerts()
      this.viewsubcat=false;
    }
    else
    {
      this.viewprofessional=false;
      this.viewsubcat=true;
      this.get1=true;
      this.get12=false;
      this.get13=false;
      this.get134=false;
      this.get1345=false;
      this.subviewcat =keys.subcategories;
    }
  
  }

  getattrsub(keys)
  {
    console.log(keys)
    if(keys.scAttributes===undefined || keys.scAttributes==="" || keys.scAttributes===[])
    {
      this.alerts()
      this.viewsubcatattr=false;
    }
    else
    {
      this.get1=true;
      this.get12=true;
      this.get13=false;
      this.get134=false;
      this.get1345=false;
      this.viewprofessional=false;
      this.viewsubcatattr=true;
      this.viewsubcat=false;
      this.subviewcatattr =keys.scAttributes;
    }
    console.log(keys.scAttributes)
  }

  gettypsub(item)
  {
    if(item.subcategorytypes===undefined || item.subcategorytypes==="" || item.subcategorytypes===[])
    {
      this.alerts()
      this.viewtypsub=false;
    }
    else
    {
      this.get1=true;
      this.get12=false;
      this.get13=true;
      this.get134=false;
      this.get1345=false;
      this.viewprofessional=false;
      this.viewsubcat=false;
      this.viewsubcatattr=false;
      this.viewtypsub=true;
      this.subviewcattpye =item.subcategorytypes;
    }
   console.log(item.subcategorytypes)
  }

  gettypsubatt(item)
  {
    if(item.SctAtrributes===undefined || item.SctAtrributes==="" || item.SctAtrributes===[])
    {
      this.alerts()
      this.viewtypsubattr=false;
    }
    else
    {
      this.get1=true;
      this.get12=false;
      this.get13=true;
      this.get134=true;
      this.get1345=false;
      this.viewprofessional=false;
      this.viewsubcat=false;
      this.viewsubcatattr=false;
      this.viewtypsub=false;
      this.viewtypsubattr=true;
      this.subviewcattpyeattr =item.SctAtrributes;
    }
   console.log(item.SctAtrributes)
  }

  gettypsubtyps(item)
  {
    if(item.SctpAttributes===undefined || item.SctpAttributes==="" || item.SctpAttributes===[])
    {
      this.alerts()
      this.viewtypsubtyps=false;
    }
    else
    {
      this.get1=true;
      this.get12=false;
      this.get13=true;
      this.get134=false;
      this.get1345=true;
      this.viewprofessional=false;
      this.viewsubcat=false;
      this.viewsubcatattr=false;
      this.viewtypsub=false;
      this.viewtypsubattr=false;
      this.viewtypsubtyps=true;
      this.subviewcattpyes =item.SctpAttributes;
    }
   console.log(item.SctpAttributes)
  }

getback()
{
      this.get1=true;
      this.get12=false;
      this.get13=true;
      this.get134=false;
      this.get1345=false;
      this.viewprofessional=false;
      this.viewsubcat=false;
      this.viewsubcatattr=false;
      this.viewtypsub=true;
      this.viewtypsubattr=false;
      this.viewtypsubtyps=false;
}

getback2()
{
      this.get1=true;
      this.get12=false;
      this.get13=false;
      this.get134=false;
      this.get1345=false;
      this.viewprofessional=false;
      this.viewsubcat=true;
      this.viewsubcatattr=false;
      this.viewtypsub=false;
      this.viewtypsubattr=false;
      this.viewtypsubtyps=false;
}

getback3()
{
      this.get1=false;
      this.get12=false;
      this.get13=false;
      this.get134=false;
      this.get1345=false;
      this.viewprofessional=true;
      this.viewsubcat=false;
      this.viewsubcatattr=false;
      this.viewtypsub=false;
      this.viewtypsubattr=false;
      this.viewtypsubtyps=false;
}

}
