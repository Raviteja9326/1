import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionalcategoriesComponent } from './professionalcategories.component';

describe('ProfessionalcategoriesComponent', () => {
  let component: ProfessionalcategoriesComponent;
  let fixture: ComponentFixture<ProfessionalcategoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfessionalcategoriesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfessionalcategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
