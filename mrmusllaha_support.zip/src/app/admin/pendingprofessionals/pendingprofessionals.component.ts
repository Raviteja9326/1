import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pendingprofessionals',
  templateUrl: './pendingprofessionals.component.html',
  styleUrls: ['./pendingprofessionals.component.scss']
})
export class PendingprofessionalsComponent implements OnInit {

  type:any;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  offerlist:any;
  yesdata:boolean=true;
  nodata:boolean=false;
  showinput: boolean = false;
  dataid: any;
  submitted:boolean=false;

  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef,private logins:LoginService) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  selectform = this.formBuilder.group({
    resetselect: ['']
  })

  offersform = this.formBuilder.group({
    commission:new FormControl('', [Validators.required]),
  })
  get offerControllers() { return this.offersform.controls }

  ngOnInit(): void 
  {
    this.getoffers()
  }


  async submitdata()
  {
    if (!this.offersform.valid) {
      Object.keys(this.offersform.controls).forEach(field => {
        const control:any = this.offersform.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      this.submitted = true;
    }
    else
    {
    const { value: accept } = await Swal.fire({
      title: `Are you sure? You want to change`,
      input: 'textarea',
      html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
      showClass: {
        popup: 'animate__animated animate__fadeInDown'
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp'
      },
      confirmButtonText:
        'Submit',
      inputValidator: (result) => {
        return !result && 'You need to comment'
      },
      showCancelButton: true,
    })
    
    if (accept) {

      const keys:any={}
      keys['customerId'] = this.dataid;
      keys['type'] = 'ACCEPTPROFESSIONAL';
      keys['comments'] = `${accept}`;
      keys['commission'] = this.offersform.value.commission;
  
      console.log(accept)
  
      this.login.professionalaccept(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
      {
        console.log(data)
        if(data['status']=='1005' && data['tokenStatus']=="1008")
        {
          this.goback();
          this.getoffers();
          Swal.fire('sucessfully changed Please wait for superadmin acceptance', '', 'success')
          this.selectform.controls.resetselect.patchValue("Select");
          this.ngxLoader.stop();
        }
        else if(data['status']=='1009' || data['tokenStatus']=='1009'){
          this.useservice.sendlanguage.subscribe(res=>
            {
              this.logins.data = res
            })
          this.logins.usersession()
        }
        else if(data['tokenStatus']=='1187'){
          this.useservice.sendlanguage.subscribe(res=>
            {
              this.logins.data = res
            })
          this.logins.usersession5()
        }
         else if(data['status'])
         {
           this.useservice.getallres = data['status'] ;
           this.better = this.useservice.allrespnse();
           const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          Toast.fire({
            icon: 'warning',
            html: `${this.better}`
          })
          this.goback();
          this.selectform.controls.resetselect.patchValue("Select");
           this.ngxLoader.stop();
         }
      })
    }
  
  else
  {
    this.goback();
    this.selectform.controls.resetselect.patchValue("Select");
  }
}
  }

  getoffers()
  {
     this.ngxLoader.start();
    const keys:any={}

    keys['type'] = 'PROFESSIONALPENDINGDETAILS';
   
    this.login.professionalpending(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
       this.yesdata=true;
       this.nodata=false;
       this.offerlist=data.pending_professional_list;
       console.log(this.offerlist)
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
      else if(data['status']=='1070'){
      this.yesdata=false;
      this.nodata=true;
      this.ngxLoader.stop()
   }
 
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }) 
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  goback()
  {
    this.getoffers();
    this.offersform.reset();
    this.showinput=false
    this.selectform.controls.resetselect.patchValue("Select");
  }

  async selectmethod(val,id) 
  {
    if(val=="ACCEPTPROFESSIONAL"){
for(let data of this.offerlist)
{
 if(data.customerId==id)
 {
  this.dataid = data.customerId
  this.showinput=true
 }
}
    }
  if(val=="REJECTPROFESSIONAL"){
    this.showinput=false
    if(this.useservice.chooselanguage=="en"){  
  const { value: accept } = await Swal.fire({
    title: `Are you sure? You want to ${val}`,
    input: 'textarea',
    html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
    showClass: {
      popup: 'animate__animated animate__fadeInDown'
    },
    hideClass: {
      popup: 'animate__animated animate__fadeOutUp'
    },
    confirmButtonText:
      'Submit',
    inputValidator: (result) => {
      return !result && 'You need to comment'
    },
    showCancelButton: true,
  })
  
  if (accept) {
    const keys:any={}
    keys['customerId'] = id;
    keys['type'] = val;
    keys['comments'] = `${accept}`;

    console.log(accept)

    this.login.professionalaccept(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        this.getoffers();
        Swal.fire('sucessfully changed Please wait for superadmin acceptance', '', 'success')
        this.selectform.controls.resetselect.patchValue("Select");
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        
        Toast.fire({
          icon: 'warning',
          html: `${this.better}`
        })
        this.selectform.controls.resetselect.patchValue("Select");
         this.ngxLoader.stop();
       }
    })
  }

else
{
  this.selectform.controls.resetselect.patchValue("Select");
}
}
else if(this.useservice.chooselanguage=="ar")
{
const { value: accept } = await Swal.fire({
  title: 'هل أنت واثق؟ تريد تغيير الوضع',
  input: 'textarea',
  html: `<div style=" padding-top: 25px; direction: rtl; text-align: right;">يرجى التعليق أدناه :</div>`,
  showClass: {
    popup: 'animate__animated animate__fadeInDown'
  },
  hideClass: {
    popup: 'animate__animated animate__fadeOutUp'
  },
  confirmButtonText:
    'إرسال',
  inputValidator: (result) => {
    return !result && 'تحتاج إلى التعليق'
  },
  cancelButtonText: 'إلغاء',
  showCancelButton: true,
})

if (accept) {
  const keys:any={}
  keys['customerId'] = id;
  keys['type'] = val;
  keys['comments'] = `${accept}`;

  console.log(accept)

  this.login.professionalaccept(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
  {
    console.log(data)
    if(data['status']=='1005' && data['tokenStatus']=="1008")
    {
      this.getoffers();
      if(this.useservice.chooselanguage=="en"){
        Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
      this.selectform.controls.resetselect.patchValue("Select");
      this.ngxLoader.stop();
    }
    else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
     else if(data['status'])
     {
       this.useservice.getallres = data['status'] ;
       this.better = this.useservice.allrespnse();
       const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer)
          toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
      })
      
      Toast.fire({
        icon: 'warning',
        html: `${this.better}`
      })
      this.selectform.controls.resetselect.patchValue("تحديد");
       this.ngxLoader.stop();
     }
  })
}

else
{
this.selectform.controls.resetselect.patchValue("تحديد");
}
}
}
}
}
