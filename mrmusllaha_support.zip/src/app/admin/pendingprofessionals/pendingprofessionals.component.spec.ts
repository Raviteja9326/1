import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingprofessionalsComponent } from './pendingprofessionals.component';

describe('PendingprofessionalsComponent', () => {
  let component: PendingprofessionalsComponent;
  let fixture: ComponentFixture<PendingprofessionalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendingprofessionalsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingprofessionalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
