import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-supportissuses',
  templateUrl: './supportissuses.component.html',
  styleUrls: ['./supportissuses.component.scss']
})
export class SupportissusesComponent implements OnInit {

  type:any;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  offerlist:any;
  nodata:boolean=false;
  yesdata:boolean=true;

  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef, private logins:LoginService) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  ngOnInit(): void 
  {
    this.getoffers()
  }

  getoffers()
  {
     this.ngxLoader.start();
    const keys:any={}

    keys['type'] = 'SUPPORTISSUES';
   
    this.login.support(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
       this.offerlist=data.supportIssues_list;
       console.log(this.offerlist)
       this.ngxLoader.stop();
     }
     else if(data['status']=='1070'){
      this.nodata = true;
      this.yesdata=false
      this.ngxLoader.stop();
    }
    else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }) 
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  async selectmethod(val,id) 
  {
    console.log(id,val)
    if(this.useservice.chooselanguage=="en"){
    const { value: accept } = await Swal.fire({
      title: 'Are you sure? You want to change status',
      input: 'textarea',
      html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
      showClass: {
        popup: 'animate__animated animate__fadeInDown'
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp'
      },
      confirmButtonText:
        'Submit',
      inputValidator: (result) => {
        return !result && 'You need to comment'
      },
      showCancelButton: true,
    })
    
    if (accept) {
      const keys:any={}
      keys['type'] = 'UPDATESUPPORTISSUESTATUS';
      keys['ticketId'] = id;
      keys['ticketStatus'] = val;
      keys['comments'] = `${accept}`;

      console.log(accept)

      this.login.updatesupportstatus(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
      {
        console.log(data)
        if(data['status']=='1005' && data['tokenStatus']=="1008")
        {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          Toast.fire({
            icon: 'success',
            html: `Your Ticket Has been Raised`
          })
          this.ngxLoader.stop();
        }
        else if(data['status']=='1009' || data['tokenStatus']=='1009'){
          this.useservice.sendlanguage.subscribe(res=>
            {
              this.logins.data = res
            })
          this.logins.usersession()
        }
        else if(data['tokenStatus']=='1187'){
          this.useservice.sendlanguage.subscribe(res=>
            {
              this.logins.data = res
            })
          this.logins.usersession5()
        }
       else if(data['status']=='1070'){
         this.betters = true;
       }
         else if(data['status'])
         {
           this.useservice.getallres = data['status'] ;
           this.better = this.useservice.allrespnse();
           const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          Toast.fire({
            icon: 'error',
            html: `${this.better}`
          })
           this.ngxLoader.stop();
         }
      
      })
    }

  else
  {
    this.getoffers()
  }
}
else if(this.useservice.chooselanguage=="ar"){
  const { value: accept } = await Swal.fire({
    title: 'هل أنت واثق؟ تريد تغيير الوضع',
    input: 'textarea',
    html: `<div style=" padding-top: 25px; direction: rtl; text-align: right;">يرجى التعليق أدناه :</div>`,
    showClass: {
      popup: 'animate__animated animate__fadeInDown'
    },
    hideClass: {
      popup: 'animate__animated animate__fadeOutUp'
    },
    confirmButtonText:
      'إرسال',
    inputValidator: (result) => {
      return !result && 'تحتاج إلى التعليق'
    },
    cancelButtonText: 'إلغاء',
    showCancelButton: true,
  })
  
  if (accept) {
    const keys:any={}
    keys['type'] = 'UPDATESUPPORTISSUESTATUS';
    keys['ticketId'] = id;
    keys['ticketStatus'] = val;
    keys['comments'] = `${accept}`;

    console.log(accept)

    this.login.updatesupportstatus(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        if(this.useservice.chooselanguage=="en"){
        Toast.fire({
          icon: 'success',
          html: `Your Ticket Has been Raised`
        })
      }
      else if(this.useservice.chooselanguage=="ar"){
        Toast.fire({
          icon: 'success',
          html: `<div style="direction: rtl; text-align: right;">تم رفع تذكرتك</div>`
        })
      }
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
     else if(data['status']=='1070'){
       this.betters = true;
     }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        
        Toast.fire({
          icon: 'error',
          html: `${this.better}`
        })
         this.ngxLoader.stop();
       }
    
    })
  }

else
{
  this.getoffers()
}
}
  }

}
