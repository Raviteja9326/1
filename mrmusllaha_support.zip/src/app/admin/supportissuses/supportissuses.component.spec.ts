import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportissusesComponent } from './supportissuses.component';

describe('SupportissusesComponent', () => {
  let component: SupportissusesComponent;
  let fixture: ComponentFixture<SupportissusesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupportissusesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportissusesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
