import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { BannersComponent } from './banners/banners.component';
import { CategoryComponent } from './category/category.component';
import { BlockunblockComponent } from './blockunblock/blockunblock.component';
import { ProfessionalcategoriesComponent } from './professionalcategories/professionalcategories.component';
import { OfferComponent } from './offer/offer.component';
import { CityComponent } from './city/city.component';
import { PendingprofessionalsComponent } from './pendingprofessionals/pendingprofessionals.component';
import { SupportissusesComponent } from './supportissuses/supportissuses.component';
import { BookingdetailsComponent } from './bookingdetails/bookingdetails.component';
import { UserprofessionalComponent } from './userprofessional/userprofessional.component';
import { WelcomeComponent } from '../commonshare/welcome/welcome.component';
import { ProfileComponent } from './profile/profile.component';
import { TrainingvideoComponent } from './trainingvideo/trainingvideo.component';
import { DocumentComponent } from './document/document.component';


const adminroutes: Routes = [{
    path: '',
    component: AdminComponent,
    children: 
    [ { 
        path: "profile", 
        component: ProfileComponent
    },
        { 
            path: "welcome", 
            component: WelcomeComponent
        }, 
        {
            path:'userandprofessional',
            component:UserprofessionalComponent
        },
        
        
        {
            path:'alldetails',
            component:BookingdetailsComponent
        },
        {
            path:'support',
            component:SupportissusesComponent
        },
        {
            path:'pendingprofessionals',
            component:PendingprofessionalsComponent
        },
        {
            path:'cities',
            component:CityComponent
        },
        {
            path:'offers',
            component:OfferComponent
        },
        {
            path:'professionalcategories',
            component:ProfessionalcategoriesComponent
        },
        {
            path:'blockUnblock',
            component:BlockunblockComponent
        },
        {
            path:'banners',
            component:BannersComponent
        },
        {
            path:'category',
            component:CategoryComponent
        },
        {
            path:'trainingvideos',
            component:TrainingvideoComponent
        }
        ,
        {
            path:'professionaldocuments',
            component:DocumentComponent
        }
    ],
        
},

];

@NgModule({
    imports: [RouterModule.forChild(adminroutes)],
    exports: [RouterModule],
})
export class AdminRoutingModule { }
