import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-blockunblock',
  templateUrl: './blockunblock.component.html',
  styleUrls: ['./blockunblock.component.scss']
})
export class BlockunblockComponent implements OnInit {

  type:any;
  blockunblock:boolean=true;
  block:boolean=false;
  unblock:boolean=false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;

  constructor(private formBuilder: FormBuilder, private login:AdminService,private logins:LoginService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router,private cd: ChangeDetectorRef) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  blockform = this.formBuilder.group({
    mobileNumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]]
  })

  get blockingsingle(){
    return this.blockform.controls;
  }

  block1()
  {
    this.block = false;
    this.blockunblock=true;
    this.unblock=false;
    this.blockform.reset()
  }

  block2()
  {
    this.block = false;
    this.blockunblock=true;
  }

  blocking()
  {
    this.blockunblock=false;
    this.block=true;
    this.unblock=false
  }

  unblocking()
  {
    this.blockunblock=false;
    this.block=false;
    this.unblock=true
  }

  ngOnInit(): void {
  }
  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  blockUser()
  {
       this.ngxLoader.start();
       
      const keys:any={}
  
      keys['type'] = 'BLOCK';
      keys['mobileNumber'] = '966'+this.blockform.value.mobileNumber;
  
      this.login.block(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
      {
        if(data['status']=='1005' && data['tokenStatus']=="1008")
     {
      if(this.useservice.chooselanguage=="en"){
        Swal.fire({
          title: 'we send request to superadmin, please wait for acceptance',
          icon: 'warning',
          showConfirmButton: false,
          showCancelButton: false,
          timer: 1500
        })
      }
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire({
            title: 'نرسل طلبًا إلى المشرف المتميز ، يرجى انتظار القبول',
            icon: 'warning',
            showConfirmButton: false,
            showCancelButton: false,
            timer: 1500
          })
        }
       this.block1();
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
      }) 
  }

  unblockUser()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['type'] = 'UNBLOCK';
    keys['mobileNumber'] = '966'+this.blockform.value.mobileNumber;

    this.login.block(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['tokenStatus']=="1008")
   {
    if(this.useservice.chooselanguage=="en"){
      Swal.fire({
        title: 'we send request to superadmin, please wait for acceptance',
        icon: 'warning',
        showConfirmButton: false,
        showCancelButton: false,
        timer: 1500
      })
    }
      else if(this.useservice.chooselanguage=="ar")
      {
        Swal.fire({
          title: 'نرسل طلبًا إلى المشرف المتميز ، يرجى انتظار القبول',
          icon: 'warning',
          showConfirmButton: false,
          showCancelButton: false,
          timer: 1500
        })
      }
     this.ngxLoader.stop();
   }
   else if(data['status']=='1009' || data['tokenStatus']=='1009'){
    this.useservice.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession()
  }
  else if(data['tokenStatus']=='1187'){
    this.useservice.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession5()
  }

    else if(data['status'])
    {
      this.useservice.getallres = data['status'] ;
      this.better = this.useservice.allrespnse();
      this.betters=true
      setTimeout(() => {
        this.betters = false;
      }, 3000);
      this.ngxLoader.stop();
    }
    }
) 
  }

}
