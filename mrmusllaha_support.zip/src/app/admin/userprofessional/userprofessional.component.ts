import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-userprofessional',
  templateUrl: './userprofessional.component.html',
  styleUrls: ['./userprofessional.component.scss']
})
export class UserprofessionalComponent implements OnInit {
  type:any;
  viewprofessional:boolean=false;
  updateprofessional:boolean=false;
  searchprofessional:boolean=true;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  getsearchdetails:any;
  viewtable:boolean=false;
  bookings:any;
  currentbookings:any;
  getsearchproff:any;
  updateoffer:any;
  err:boolean=false;
  viewprofs:boolean=false;
  professionalbookings:boolean=false;
  profeesionalCurrentbooking:boolean=false;
  baseUrl: any =  "https://images.mrmusllaha.com/subcategories/";
  baseUrl2: any =  "https://images.mrmusllaha.com/profile/";

  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef, private logins:LoginService) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  searchform = this.formBuilder.group({
    mobileNumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]]
  })

  get searchsingle(){
    return this.searchform.controls;
  }

  selectform = this.formBuilder.group({
    resetselect: ['']
  })

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  block1()
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=true;
    this.viewtable=false;
    this.err=false;
    this.searchform.reset();
   
  }
  
  block2()
  {
    this.updateprofessional=false;
    this.viewprofessional=true;
    this.searchprofessional=false;
  }

block3()
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=false;
    this.viewtable=true;
    this.viewprofs=false;
  }

  getdatasback()
  {

  }

  ngOnInit(): void {
  }

  searchUser()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['type'] = 'GETBOOKINGS';
    keys['mobileNumber'] = '966'+this.searchform.value.mobileNumber;

    this.login.getbookinguserprofessional(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data);
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        this.getsearchdetails=data;
        console.log(this.getsearchdetails)
        this.block2();
        this.ngxLoader.stop();
      }
      if(data['status']=='1069' && data['tokenStatus']=="1008")
      {
      if(data.professionalworkHistoryList=="" || data.professionalworkHistoryList == undefined)
        {
         this.err= true;
         this.viewtable=false;
         this.ngxLoader.stop();
        }
        else
        {
          this.err= false;
          this.getsearchproff=data.professionalworkHistoryList;
          this.block3();
          this.ngxLoader.stop();
        }
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }

  booking()
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=false;
    this.viewtable=false;
    this.viewprofs=false;
    this.professionalbookings=true; 
    if(this.getsearchdetails.BookingHistoryList=="" || this.getsearchdetails.BookingHistoryList == undefined)
    {
      this.err= true;
      this.professionalbookings=false;
    }
    else
    {
      this.err= false;
      this.bookings = this.getsearchdetails.BookingHistoryList
    }
    console.log(this.bookings)
  }

  Currentbooking()
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=false;
    this.viewtable=false;
    this.viewprofs=false;
    this.professionalbookings=false; 
    this.profeesionalCurrentbooking=true;
    if(this.getsearchdetails.currentBookingsList=="" || this.getsearchdetails.currentBookingsList == undefined)
    {
      this.err= true;
      this.profeesionalCurrentbooking=false;
    }
    else
    {
      this.err= false;
      this.currentbookings = this.getsearchdetails.currentBookingsList
    }
   console.log(this.currentbookings)
  }

  getdatadet()
  {
    this.professionalbookings = false;
    this.profeesionalCurrentbooking=false;
    this.viewprofessional=true;
    this.selectform.reset();
  }

  viewdata(keys)
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=false;
    this.viewtable=false;
    this.viewprofs=true;
    this.updateoffer=keys
  }

  editdata(keys)
  {

  }

  async selectmethod(val,id,items) 
  {
    console.log(id,val)
    if(this.useservice.chooselanguage=="en"){
    const { value: accept } = await Swal.fire({
      title: 'Are you sure? You want to change status',
      input: 'textarea',
      html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
      showClass: {
        popup: 'animate__animated animate__fadeInDown'
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp'
      },
      confirmButtonText:
        'Submit',
      inputValidator: (result) => {
        return !result && 'You need to comment'
      },
      showCancelButton: true,
    })
    
    if (accept) {
      const keys:any={}
      keys['type'] = 'UPDATEBOOKINGSTATUS';
      keys['bookingId'] = id.toString();
      keys['bookingStatus'] = val;
      keys['comments'] = `${accept}`;

      console.log(accept)

      this.login.updatebookingstatus(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
      {
        console.log(data)
        if(data['status']=='1005' && data['tokenStatus']=="1008")
        {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          Toast.fire({
            icon: 'success',
            html: `Your Ticket Has been Raised`
          })
          this.ngxLoader.stop();
        }
        else if(data['status']=='1009' || data['tokenStatus']=='1009'){
          this.useservice.sendlanguage.subscribe(res=>
            {
              this.logins.data = res
            })
          this.logins.usersession()
        }
        else if(data['tokenStatus']=='1187'){
          this.useservice.sendlanguage.subscribe(res=>
            {
              this.logins.data = res
            })
          this.logins.usersession5()
        }
         else if(data['status'])
         {
           this.useservice.getallres = data['status'] ;
           this.better = this.useservice.allrespnse();
           const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          Toast.fire({
            icon: 'error',
            html: `${this.better}`
          })
           this.ngxLoader.stop();
         }
      
      })
    }

  else
  {
    this.selectform.setValue({
      resetselect: items

    })
  }
}
else if(this.useservice.chooselanguage=="ar")
{
  const { value: accept } = await Swal.fire({
    title: 'هل أنت واثق؟ تريد تغيير الوضع',
    input: 'textarea',
    html: `<div style=" padding-top: 25px; direction: rtl; text-align: right;">يرجى التعليق أدناه :</div>`,
    showClass: {
      popup: 'animate__animated animate__fadeInDown'
    },
    hideClass: {
      popup: 'animate__animated animate__fadeOutUp'
    },
    confirmButtonText:
      'إرسال',
    inputValidator: (result) => {
      return !result && 'تحتاج إلى التعليق'
    },
    cancelButtonText: 'إلغاء',
    showCancelButton: true,
  })
  
  if (accept) {
    const keys:any={}
    keys['type'] = 'UPDATEBOOKINGSTATUS';
    keys['bookingId'] = id.toString();
    keys['bookingStatus'] = val;
    keys['comments'] = `${accept}`;

    console.log(accept)

    this.login.updatebookingstatus(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        
        Toast.fire({
          icon: 'success',
          html: `<div style="direction: rtl; text-align: right;">تم رفع تذكرتك</div>`
        })
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        
        Toast.fire({
          icon: 'error',
          html: `${this.better}`
        })
         this.ngxLoader.stop();
       }
    
    })
  }

else
{
  this.selectform.setValue({
    resetselect: items

  })
}
}
  }


}
