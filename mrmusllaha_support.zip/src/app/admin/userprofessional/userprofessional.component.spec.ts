import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserprofessionalComponent } from './userprofessional.component';

describe('UserprofessionalComponent', () => {
  let component: UserprofessionalComponent;
  let fixture: ComponentFixture<UserprofessionalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserprofessionalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserprofessionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
