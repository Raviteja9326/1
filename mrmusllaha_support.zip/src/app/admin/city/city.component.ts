import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import Swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from 'src/app/services/login.service';

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.scss']
})
export class CityComponent implements OnInit {

  type:any;
  viewprofessional:boolean=false;
  updateprofessional:boolean=false;
  searchprofessional:boolean=true;
  addprofessional:boolean=false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  getsearchdetailss:any;
  mydata:any;

  constructor(private translateService: TranslateService,private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private logins:LoginService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  cityform = this.formBuilder.group({
    countryName: ['SaudiArabia',[Validators.required, 
      Validators.pattern('^[a-zA-Z\u0600-\u06FF\\s][\sa-zA-Z\u0600-\u06FF\\s -]*$'), Validators.maxLength(25)]],
  })

  cityaddform = this.formBuilder.group({
    countryEnName: ['',[Validators.required, 
      Validators.pattern('^[a-zA-Z\\s -]+$'), Validators.maxLength(25)]],
      countryArName: ['',[Validators.required, 
        Validators.pattern('^[\u0621-\u064A\u0660-\u0669 ]+$'), Validators.maxLength(40)]],
        cityEnName: ['',[Validators.required, 
          Validators.pattern('^[a-zA-Z\\s -]+$'), Validators.maxLength(20)]],
          cityArName: ['',[Validators.required, 
            Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$'), Validators.maxLength(25)]],
  })

  cityaddform2 = this.formBuilder.group({
        cityEnName: ['',[Validators.required, 
          Validators.pattern('^[a-zA-Z\\s -]+$'), Validators.maxLength(20)]],
          cityArName: ['',[Validators.required, 
            Validators.pattern('^[\u0621-\u064A\u0660-\u0669 -]+$'), Validators.maxLength(40)]],
  })

  get cityControllers() { return this.cityform.controls }
  get city2Controllers() { return this.cityaddform2.controls }
  get countryControllers() { return this.cityaddform.controls }

  ngOnInit(): void 
  {
  }

  
  block1()
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=true;
    this.addprofessional=false;
    this.cityaddform.reset();
   
  }
  
  block2()
  {
    this.updateprofessional=false;
    this.viewprofessional=true;
    this.searchprofessional=false;
    this.addprofessional=false;
  }


  block3()
  {
    this.updateprofessional=false;
    this.viewprofessional=false;
    this.searchprofessional=false;
    this.addprofessional=true;
  }

  block4(obj)
  {
    this.mydata = obj
    this.updateprofessional=true;
    this.viewprofessional=false;
    this.searchprofessional=false;
    this.addprofessional=false;
    this.cityaddform2.setValue({
      cityEnName:  obj.cityNameEn,
      cityArName:  obj.cityNameAr
    });
  }
 

  cityupdatesubmit()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['type'] = 'UPDATECITY';
    keys['cityEnName'] = this.cityaddform2.value.cityEnName;
    keys['cityArName'] = this.cityaddform2.value.cityArName;
    keys['id']=this.mydata.cityId.toString();

    this.login.updatecities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        if(this.useservice.chooselanguage=="en")
       {
        Swal.fire('sucessfully updated, Please wait for superadmin acceptance', '', 'success')
      }
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تم التحديث بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
        this.block1();
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    })
  }

  citysubmit()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['type'] = 'GETCITES';
    keys['countryName'] = this.cityform.value.countryName;

    this.login.getcities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
      if(data['status']=='1069' && data['tokenStatus']=="1008")
      {
        this.getsearchdetailss=data.cites_list;
        this.block2();
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  cityaddsubmit()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['type'] = 'ADDCITY';
    keys['cityEnName'] = this.cityaddform.value.cityEnName;
    keys['cityArName'] = this.cityaddform.value.cityArName;
    keys['countryEnName'] = this.cityaddform.value.countryEnName;
    keys['countryArName'] = this.cityaddform.value.countryArName;

    this.login.addcities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        if(this.useservice.chooselanguage=="en"){
          Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')}
          else if(this.useservice.chooselanguage=="ar")
          {
            Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
          }
        this.block1();
        this.cityaddform.reset();
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
     else if(data['status']=='1117' && data['tokenStatus']=='1008'){
      this.block1();
        this.cityaddform.reset();
       this.ngxLoader.stop();
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
    }
   
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    })
  }

  deletecities(offobj:any)
  {
    console.log(offobj)
    const keys:any={}

    keys['id'] = offobj.cityId.toString();
    keys['type'] = "DELETECITY";
    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the city?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.deletecities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        })
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف المدينة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.deletecities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
          Swal.fire({
            title: 'من فضلك انتظر قبول المشرف المتميز',
            icon: 'warning',
            showConfirmButton: false,
            showCancelButton: false,
            timer: 1500
          })
        })
      } 
    })
  }
  }

}
