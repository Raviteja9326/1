import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchComponent } from 'src/app/commonshare/search/search.component';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
declare var $:any

@Component({
  selector: 'app-trainingvideo',
  templateUrl: './trainingvideo.component.html',
  styleUrls: ['./trainingvideo.component.scss']
})
export class TrainingvideoComponent implements OnInit {
  
  better2:boolean=true;
  type: string;
  bannerLists: any;
  better: any;
  betters: boolean;
  destroy$: Subject<boolean> = new Subject<boolean>();
  thumbnailData: string;
  viewvideo:boolean=true;
  @ViewChild('fileInput') fileUploader: ElementRef;
  f: File;
  fileData: any;
  editFile: boolean = true;
	removeUpload: boolean = false;

  constructor(private formBuilder: FormBuilder, private dp: DatePipe, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private logins:LoginService, private router:Router, private cd: ChangeDetectorRef,public dialog: MatDialog) 
  {
    console.log(this.useservice.chooselanguage)
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  bannerform = this.formBuilder.group({
      bannerImage:['',Validators.required]
  })

  get bannerControllers() { return this.bannerform.controls }

  ngOnInit(): void 
  {
    this.getvideos()
  }

  getvideos()
  {
     this.ngxLoader.start();
    const keys:any={}

    keys['deviceId'] = this.useservice.visitorId;
   

    this.login.Gettraningvideos(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
       console.log(data)
      this.bannerLists= data.videoList;
    for(let dataleak of Object.values(this.bannerLists))
    {
      console.log(dataleak)
    }
      this.better2=true;
       this.ngxLoader.stop();
     }
    else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1070'){
      this.better2=false;
      this.ngxLoader.stop()
   }
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }) 
  }

  openCompaniesModalview(item:any): void {
    var data59 = true
    const dialogRef = this.dialog.open(SearchComponent, {
      width: '500px',
      data: {data59:item,name59:data59}, disableClose: true,
      position: {
        top: '20px'
      }
    });
    
    

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  deletebanner(item:any)
  {
    const keys:any={}

    keys['videoName'] = item;
    keys['deviceId'] = this.useservice.visitorId;

    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the video?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.videodelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
       
          if(data['status']=='1005' && data['tokenStatus']=="1008")
          {
            Swal.fire('Sucessfully Deleted,Please wait for superadmin acceptance', '', 'success')
            this.getvideos();
            this.ngxLoader.stop();
          }
          else if(data['status']=='1117' && data['tokenStatus']=="1008")
          {
            Swal.fire('Please wait for superadmin acceptance', '', 'warning')
            this.getvideos();
            this.ngxLoader.stop();
          }
         else if(data['status']=='1009' || data['tokenStatus']=='1009'){
           this.useservice.sendlanguage.subscribe(res=>
             {
               this.logins.data = res
             })
           this.logins.usersession()
         }
         else if(data['status'])
         {
           this.useservice.getallres = data['status'] ;
           this.better = this.useservice.allrespnse();
           this.betters=true
           setTimeout(() => {
             this.betters = false;
           }, 3000);
           this.ngxLoader.stop();
         }
         else if(data['tokenStatus']=='1187'){
           this.useservice.sendlanguage.subscribe(res=>
             {
               this.logins.data = res
             })
           this.logins.usersession5()
         }
         else if(data['status']=='1070'){
           this.better2=false;
           this.ngxLoader.stop()
        }
       
        
        })
      
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف اللافتة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.Bannersdelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
            Swal.fire({
              title: 'من فضلك انتظر قبول المشرف المتميز',
              icon: 'warning',
              showConfirmButton: false,
              showCancelButton: false,
              timer: 1500
            })
        })
      
      } 
    })
  }
  }

  goback()
  {
    this.viewvideo = true;
    this.bannerform.reset()
  }

  addvideo()
  {
    this.viewvideo = false
  }

  bannerssubmit()
  {
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("video", this.f);
    }
    else
    {
      this.f = this.fileData;
      formData.append("video", this.f);
    }
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.login.addvideo(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          if(data['status']=='1005' && data['tokenStatus']=="1008")
     {
      if(this.useservice.chooselanguage=="en"){
      Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success',)}
      else if(this.useservice.chooselanguage=="ar")
      {
        Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
      }
      this.bannerform.reset();
      this.getvideos();
      this.goback();
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['status'])
    {
      this.useservice.getallres = data['status'] ;
      this.better = this.useservice.allrespnse();
      this.betters=true
      setTimeout(() => {
        this.betters = false;
      }, 3000);
      this.ngxLoader.stop();
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
    else if(data['status']=='1117' && data['tokenStatus']=='1008'){
      this.bannerform.reset();
      this.getvideos();
      this.goback();
       this.ngxLoader.stop();
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
    }
     
        })
  }



  uploadFile(event) {
    let reader = new FileReader();
		this.fileData = event.target.files[0];
if(this.fileData == undefined)
{
  this.fileUploader.nativeElement.value = "";
  this.fileData=[];
  this.bannerform.controls.bannerImage.patchValue(''); 
}	
else if(this.fileData !== undefined) {	
if(this.fileData.size > 104857600)
{
  this.fileUploader.nativeElement.value = "";
              this.fileData=[];
              this.bannerform.controls.bannerImage.patchValue('');  
  this.better = "Please contact support@mrmusllah.com for more than 100mb size"
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
}

else if(this.fileData.size <= 104857600)
{
  if (event.target.files && event.target.files[0]) {
    reader.readAsDataURL(this.fileData);

    // When file uploads set it to file formcontrol
    reader.onload = () => {
      this.editFile = false;
      this.removeUpload = true;
    }
    // ChangeDetectorRef since file is loading outside the zone
    this.cd.markForCheck();
  }
}
}

	
    
     
	}


}
