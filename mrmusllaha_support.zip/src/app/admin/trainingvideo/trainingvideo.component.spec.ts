import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingvideoComponent } from './trainingvideo.component';

describe('TrainingvideoComponent', () => {
  let component: TrainingvideoComponent;
  let fixture: ComponentFixture<TrainingvideoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainingvideoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
