import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AdminComponent } from './admin.component';
import { AdminRoutingModule } from './admin-routing.module';
import { BannersComponent } from './banners/banners.component';
import { CategoryComponent } from './category/category.component';
import { MatDialogModule } from '@angular/material/dialog';
import { SweetAlert2Module } from "@sweetalert2/ngx-sweetalert2";
import { MaterialModule } from '../commonshare/material.module';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BlockunblockComponent } from './blockunblock/blockunblock.component';
import { ProfessionalcategoriesComponent } from './professionalcategories/professionalcategories.component';
import { OfferComponent } from './offer/offer.component';
import { CityComponent } from './city/city.component';
import { PendingprofessionalsComponent } from './pendingprofessionals/pendingprofessionals.component';
import { SupportissusesComponent } from './supportissuses/supportissuses.component';
import { BookingdetailsComponent } from './bookingdetails/bookingdetails.component';
import { UserprofessionalComponent } from './userprofessional/userprofessional.component';
import { WelcomeComponent } from '../commonshare/welcome/welcome.component';
import { TwoDigitDecimaNumberDirective } from '../commonshare/TwoDigitDecimaNumber.directive';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { ProfileComponent } from './profile/profile.component';
import { TrainingvideoComponent } from './trainingvideo/trainingvideo.component';
import { DocumentComponent } from './document/document.component';


const components = [AdminComponent, BannersComponent, CategoryComponent,BlockunblockComponent, ProfessionalcategoriesComponent, OfferComponent, CityComponent, PendingprofessionalsComponent, SupportissusesComponent, BookingdetailsComponent,UserprofessionalComponent,WelcomeComponent];


@NgModule({
  declarations: [ ...components,TwoDigitDecimaNumberDirective, ProfileComponent, TrainingvideoComponent, DocumentComponent],
  imports: [CommonModule,AdminRoutingModule,MatDialogModule,FormsModule,ReactiveFormsModule,MaterialModule,NgxMatMomentModule,SweetAlert2Module.forRoot(), TranslateModule],
  providers:[DatePipe]
})
export class AdminModule { }
 