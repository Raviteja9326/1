import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.scss']
})
export class DocumentComponent implements OnInit {

  type:any;
  viewprofessional:boolean=false;
  updateprofessional:boolean=false;
  searchprofessional:boolean=true;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  getsearchdetails:any;
  better2:boolean=true;
  baseurl = "https://documents.mrmusllaha.com/"
  thumbnailData: string;
  viewvideo:boolean=true;
  @ViewChild('fileInput') fileUploader: ElementRef;
  f: File;
  fileData: any;
  editFile: boolean = true;
	removeUpload: boolean = false;
  searchprofessional2: boolean = false;
  searchprofessional3: boolean = false;
  searchprofessional4:boolean=false
  id: any;
  better21: boolean;
  workshop: any;
  workshop2: any;
  readyone: boolean;

  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef,private logins:LoginService) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  searchform = this.formBuilder.group({
    mobileNumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]]
  })

  get searchsingle(){
    return this.searchform.controls;
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  bannerform = this.formBuilder.group({
    documentName:['',[Validators.required, 
      Validators.pattern('^[a-zA-Z0-9\u0600-\u06FF ][\sa-zA-Z0-9\u0600-\u06FF ]*$'), Validators.maxLength(25),Validators.required,]],
    bannerImage:['',Validators.required]
})

get bannerControllers() { return this.bannerform.controls }


uploadFile(event) {
  let reader = new FileReader();
  this.fileData = event.target.files[0];
  //console.log(this.fileData)
  if (event.target.files && event.target.files[0]) {
    reader.readAsDataURL(this.fileData);

    // When file uploads set it to file formcontrol
    reader.onload = () => {
      this.editFile = false;
      this.removeUpload = true;
    }
    // ChangeDetectorRef since file is loading outside the zone
    this.cd.markForCheck();
  }
  
   
}

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  ngOnInit(): void {
  }

  goback()
  {
    this.searchprofessional=false
    this.searchprofessional2=false
    this.searchprofessional3=true
  }

  searchUser()
  {
    this.ngxLoader.start();
       
    const keys:any={}

    keys['mobile'] = '966'+this.searchform.value.mobileNumber;

    this.login.getprofessionalsdocuments(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data,data.area)
      if(data['status']=='1069' && data['tokenStatus']=="1008")
      {
        this.getsearchdetails=data.documents;
        for(let data of this.getsearchdetails)
        {
          this.id=data.professionalId
          if(data.docType == "WORKSHOP")
          {
            this.workshop = data
            console.log(this.workshop)
          }
        }
        
        console.log(this.id)
        this.better2=true
        this.searchprofessional=false;
        this.searchprofessional2=true;
        this.searchprofessional3=false;
        this.searchprofessional4=false
        console.log(this.getsearchdetails)
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
      else if(data['status']=='1070'){
        this.id=data.professionalId
        this.better21=true;
        setTimeout(() => {
          this.better2 = false;
        }, 3000);
        this.ngxLoader.stop()
     }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }

  gobacks()
  {
    this.searchprofessional=true
    this.searchprofessional2=false
    this.searchprofessional3=false
    this.searchprofessional4=false
    this.searchform.reset()
  }

  documentsubmit()
  {
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("document", this.f);
    }
    else
    {
      this.f = this.fileData;
      formData.append("document", this.f);
    }
    formData.append("documentName", this.bannerform.value.documentName);
    formData.append("professionalId",  this.id);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.login.adddocument(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          if(data['status']=='1005' && data['tokenStatus']=="1008")
     {
      if(this.useservice.chooselanguage=="en"){
      Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success',)}
      else if(this.useservice.chooselanguage=="ar")
      {
        Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
      }
      this.bannerform.reset();
      this.searchUser();
      this.getback2();
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
    else if(data['status']=='1117' && data['tokenStatus']=='1008'){
      this.bannerform.reset();
       this.ngxLoader.stop();
       this.getback2();
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
    }
    else if(data['status'])
    {
      this.useservice.getallres = data['status'] ;
      this.better = this.useservice.allrespnse();
      this.betters=true
      setTimeout(() => {
        this.betters = false;
      }, 3000);
      this.ngxLoader.stop();
    }
        }) 
  }

  documentsubmit2()
  {
    console.log(this.bannerform.value.documentName)
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("document", this.f);
    }
    else
    {
      this.f = this.fileData;
      formData.append("document", this.f);
    }
    formData.append("documentName", this.bannerform.value.documentName);
    formData.append("professionalId",  this.id);
    formData.append("docType",  this.workshop2);
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.login.upddocument(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          if(data['status']=='1005' && data['tokenStatus']=="1008")
     {
      if(this.useservice.chooselanguage=="en"){
      Swal.fire('sucessfully updated, Please wait for superadmin acceptance', '', 'success',)}
      else if(this.useservice.chooselanguage=="ar")
      {
        Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
      }
      this.bannerform.reset();
      this.searchUser();
      this.getback2();
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['status']=='1117' && data['tokenStatus']=='1008'){
      this.bannerform.reset();
      this.searchUser();
      this.getback2();
       this.ngxLoader.stop();
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
    }
    else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
    else if(data['status']=='1117' && data['tokenStatus']=='1008'){
      this.bannerform.reset();
       this.ngxLoader.stop();
       this.getback2();
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
    }
        }) 
  }

  getback2()
  {
    this.searchprofessional2 = true
    this.searchprofessional = false
    this.searchprofessional3 = false
    this.searchprofessional4=false
    this.searchUser()
  }

  deletedocument(item)
  {
    const keys:any={}

    keys['professionalId'] = this.id;
    keys['docType'] = item.docType;
    keys['docName'] = item.docName;
    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the document?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.documentdelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
       
          if(data['status']=='1005' && data['tokenStatus']=="1008")
          {
            Swal.fire('Sucessfully Deleted,Please wait for superadmin acceptance', '', 'success')
            this.searchUser();
            this.ngxLoader.stop();
          }
          else if(data['status']=='1117' && data['tokenStatus']=="1008")
          {
            Swal.fire('Please wait for superadmin acceptance', '', 'warning')
            this.searchUser();
            this.ngxLoader.stop();
          }
         else if(data['status']=='1009' || data['tokenStatus']=='1009'){
           this.useservice.sendlanguage.subscribe(res=>
             {
               this.logins.data = res
             })
           this.logins.usersession()
         }
         else if(data['tokenStatus']=='1187'){
           this.useservice.sendlanguage.subscribe(res=>
             {
               this.logins.data = res
             })
           this.logins.usersession5()
         }
         else if(data['status']=='1070'){
           this.better2=false;
           this.ngxLoader.stop()
        }
        else if(data['status']=='1117' && data['tokenStatus']=='1008'){
           if(this.useservice.chooselanguage=="en"){
            Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
            else if(this.useservice.chooselanguage=="ar")
            {
              Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
            }
        }
       
           else if(data['status'])
           {
             this.useservice.getallres = data['status'] ;
             this.better = this.useservice.allrespnse();
             this.betters=true
             setTimeout(() => {
               this.betters = false;
             }, 3000);
             this.ngxLoader.stop();
           }
        })
      
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف اللافتة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.Bannersdelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
            Swal.fire({
              title: 'من فضلك انتظر قبول المشرف المتميز',
              icon: 'warning',
              showConfirmButton: false,
              showCancelButton: false,
              timer: 1500
            })
        })
      
      } 
    })
  }
  }

  editdocument(item)
  {
    console.log(item)
    this.workshop2 = item.docType
    this.searchprofessional=false
    this.searchprofessional2=false
    this.searchprofessional3=false
    this.searchprofessional4=true
    this.bannerform.setValue(
      {
        documentName:  item.docName,
        bannerImage:  ""
      });
  }

  getback3()
  {
    this.searchprofessional=false
    this.searchprofessional2=true
    this.searchprofessional3=false
    this.searchprofessional4=false
    this.bannerform.reset()
  }

}
