import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import Swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from 'src/app/services/login.service';

export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }

@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.scss']
})
export class OfferComponent implements OnInit {

  type:any;
  destroy$: Subject<boolean> = new Subject<boolean>();
  betters:boolean=false;
  better:boolean=false;
  offerlist:any;
  addoff:boolean=false;
  f: File;
  offer:boolean=true;
  updoff:boolean=false;
  updateoffer:any;
  viewoff:boolean=false;
  fileData: any;
  editFile: boolean = true;
	removeUpload: boolean = false;
  imageUrl: any;
  @ViewChild('fileInput') fileUploader: ElementRef;
  baseUrl: any =  "https://images.mrmusllaha.com/banners/";
  better2: boolean;

  constructor(private translateService: TranslateService,private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef,private logins:LoginService,) 
  {
    
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  ngOnInit(): void 
  {
    this.getoffers()
  }

  offersform = this.formBuilder.group({
    offername:new FormControl('', [Validators.required, 
      Validators.pattern('^[a-zA-Z\\s]+$')]),
      discountPercentage:new FormControl('', [Validators.required]),
      offerdesc:new FormControl('', [Validators.required,Validators.minLength(12)]),
      couponCode:new FormControl('', [Validators.required,Validators.minLength(3)]),
      minimumOrderValue:new FormControl('', [Validators.required]),
      maximumDiscountAmount:new FormControl('', [Validators.required]),
  })

  get offerControllers() { return this.offersform.controls }

  offers2form = this.formBuilder.group({
    offername:new FormControl('', [Validators.required, 
      Validators.pattern('^[a-zA-Z\\s]+$')]),
      discountPercentage:new FormControl('', [Validators.required]),
      offerdesc:new FormControl('', [Validators.required,Validators.minLength(12)]),
      couponCode:new FormControl('', [Validators.required,Validators.minLength(3)]),
      minimumOrderValue:new FormControl('', [Validators.required]),
      maximumDiscountAmount:new FormControl('', [Validators.required]),
      bannerImage:new FormControl('', [Validators.required]),
  })

  get offer2Controllers() { return this.offers2form.controls }

  uploadFile(event) {
	  let reader = new FileReader();
    this.fileData = event.target.files[0];
		//console.log(this.fileData)
    let img = new Image()
    img.src = window.URL.createObjectURL(event.target.files[0])
    img.onload = () => {
       if(img.width === 800 && img.height === 400){
        if (event.target.files && event.target.files[0]) {
        
          reader.readAsDataURL(this.fileData);
          // When file uploads set it to file formcontrol
          reader.onload = () => {
            this.editFile = false;
            this.removeUpload = true;
          }
          // ChangeDetectorRef since file is loading outside the zone
          this.cd.markForCheck();
        }
            // upload logic here
            } else {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
              })
              if(this.useservice.chooselanguage=="en"){
                Toast.fire({
                  icon: 'error',
                  html: `Sorry, this image doesn't look like the size we wanted. <br/> It's
                  ${img.width} x ${img.height}.`
                })
                }
                else if(this.useservice.chooselanguage=="ar")
                {
                  Toast.fire({
                    icon: 'error',
                    html: `عذرًا ، هذه الصورة لا تبدو بالحجم الذي أردناه. <br/>
                    ${img.width} x ${img.height}.`
                  })
                }
             
              this.fileUploader.nativeElement.value = "";
              this.fileData=[];  
              this.offers2form.controls.bannerImage.patchValue('');  
       }                
    } 
    
     
	}


  getoffers()
  {
     this.ngxLoader.start();
    const keys:any={}

    keys['type'] = 'GETOFFERS';
   
    this.login.getoffers(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
      this.better2=true;
       this.offerlist=data.offers_list;
       console.log(this.offerlist)
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1070'){
      this.better2=false;
      this.ngxLoader.stop()
   }
  
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }) 
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  addoffer()
  {
    this.getoffers()
this.addoff=true;
this.offer=false;
this.updoff=false;
this.viewoff=false
  }

  updoffer(offerlist)
  {
    this.getoffers()
this.updateoffer = offerlist
console.log(this.updateoffer)
this.addoff=false;
this.offer=false;
this.updoff=true;
this.viewoff=false
this.offersform.setValue({
  offername:  this.updateoffer.offerName,
  discountPercentage:  this.updateoffer.discountPercentage,
  offerdesc:  this.updateoffer.offerDescription,
  couponCode:  this.updateoffer.couponCode,
  minimumOrderValue:  this.updateoffer.minimumOrderValue,
  maximumDiscountAmount:  this.updateoffer.maximumDiscountAmount
});
  }

  offers()
  {
    this.getoffers()
    this.addoff=false;
    this.offer=true
    this.updoff=false;
    this.viewoff=false;
    this.offersform.reset();
  }

  numberOnly(event:any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  offersubmit()
  {
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("attachment", this.f);
    }
    else
    {
      this.f = this.fileData;
      formData.append("attachment", this.f);
    }
    formData.append("offername", this.offers2form.value.offername);
    formData.append("discountPercentage", this.offers2form.value.discountPercentage);
    formData.append("offerdesc", this.offers2form.value.offerdesc);
    formData.append("couponCode", this.offers2form.value.couponCode);
    formData.append("minimumOrderValue", this.offers2form.value.minimumOrderValue);
    formData.append("maximumDiscountAmount", this.offers2form.value.maximumDiscountAmount);
    formData.append("deviceId", this.useservice.visitorId);

    this.ngxLoader.start();
    this.login.addoffers(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        if(this.useservice.chooselanguage=="en"){
          Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')}
          else if(this.useservice.chooselanguage=="ar")
          {
            Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
          }
       this.offersform.reset();
       this.offers();
       this.getoffers();
      this.ngxLoader.stop();
      }
      else if(data['status']=='1117' && data['tokenStatus']=='1008'){
        this.offersform.reset();
        this.offers();
        this.getoffers();
       this.ngxLoader.stop();
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
     else if(data['status']=='1069'){
        this.ngxLoader.stop()
     }
   
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }


  offerupdate()
  {
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("attachment", this.f);
    }
    else
    {
      this.f = this.fileData;
      formData.append("attachment", this.f);
    }
    formData.append("offername", this.offersform.value.offername);
    formData.append("discountPercentage", this.offersform.value.discountPercentage);
    formData.append("offerdesc", this.offersform.value.offerdesc);
    formData.append("couponCode", this.offersform.value.couponCode);
    formData.append("minimumOrderValue", this.offersform.value.minimumOrderValue);
    formData.append("maximumDiscountAmount", this.offersform.value.maximumDiscountAmount);
    formData.append("offerId", this.updateoffer.offerId);
    formData.append("deviceId", this.useservice.visitorId);

    this.ngxLoader.start();
    this.login.updateoffers(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['tokenStatus']=="1008")
      {
        if(this.useservice.chooselanguage=="en"){
          Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success')}
          else if(this.useservice.chooselanguage=="ar")
          {
            Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
          }
       this.offersform.reset();
       this.offers();
       this.getoffers();
      this.ngxLoader.stop();
      }
     else if(data['status']=='1117' && data['tokenStatus']=="1008")
     {
       console.log(data)
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
      this.offersform.reset();
      this.offers();
      this.getoffers();
     this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
     else if(data['status']=='1069'){
        this.ngxLoader.stop()
     }
    
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }

  viewoffer(item)
  {
    this.updateoffer = item;
    this.viewoff=true;
    this.addoff=false;
    this.offer=false;
    this.updoff=false;

  }

  deletebanner(offobj:any)
  {
    const keys:any={}

    keys['offerId'] = offobj.offerId.toString();
    keys['type'] = "DELETEOFFER";

    if(this.useservice.chooselanguage=="en"){
    Swal.fire({
      title: 'Do you want to delete the offer?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.deleteoffers(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        })
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    Swal.fire({
      title: 'هل تريد حذف العرض؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.deleteoffers(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
          Swal.fire({
            title: 'من فضلك انتظر قبول المشرف المتميز',
            icon: 'warning',
            showConfirmButton: false,
            showCancelButton: false,
            timer: 1500
          })
        })
      } 
    })
  }
  }

}
