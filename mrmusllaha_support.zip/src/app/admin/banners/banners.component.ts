import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import Swal from 'sweetalert2';
import { MAT_DATE_LOCALE, ThemePalette } from '@angular/material/core';
import { NgxMatDateAdapter, NgxMatDateFormats, NGX_MAT_DATE_FORMATS } from '@angular-material-components/datetime-picker';
import { DatePipe } from '@angular/common';
import { CustomNgxDatetimeAdapter } from 'src/app/commonshare/CustomNgxDatetimeAdapter';
import { NGX_MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular-material-components/moment-adapter';
import moment, { Moment } from 'moment';
import { LoginService } from 'src/app/services/login.service';
const CUSTOM_DATE_FORMATS: NgxMatDateFormats = {
  parse: {
    dateInput: 'l, LTS'
  },
  display: {
    dateInput: 'DD-MM-YYYY HH:mm:ss a',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  }
};

  @Component({
    selector: 'app-banners',
    templateUrl: './banners.component.html',
    styleUrls: ['./banners.component.scss'],
    providers: [{provide: NgxMatDateAdapter,useClass: CustomNgxDatetimeAdapter,deps: [MAT_DATE_LOCALE, NGX_MAT_MOMENT_DATE_ADAPTER_OPTIONS]},
    { provide: NGX_MAT_DATE_FORMATS, useValue: CUSTOM_DATE_FORMATS }
    ],
  })
export class BannersComponent implements OnInit {

  @ViewChild('picker') picker: any;
  bannerupate:boolean=false;
  banneradd:boolean=false;
  bannerview:boolean=false;
  banner1:boolean=true;
  betters:boolean=false;
  better:boolean=false;
  bannershow:any;
  f: File;
  fileData: any;
  editFile: boolean = true;
	removeUpload: boolean = false;
  imageUrl: any;
  destroy$: Subject<boolean> = new Subject<boolean>();
  bannerLists:any;
  type:any;
  updban:any;
  public date:any;
  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public touchUi = false;
  public enableMeridian = true;
  public minDate = new Date();
  public maxDate!: Moment;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  public color: ThemePalette = 'accent';
  baseUrl: any =  "https://images.mrmusllaha.com/banners/";
  public dateControl = new FormControl(new Date(2021,9,4,5,6,7));
  public dateControlMinMax = new FormControl(new Date());
  public listColors = ['primary', 'accent', 'warn'];
  public stepHours = [1, 2, 3, 4, 5];
  public stepMinutes = [1, 5, 10, 15, 20, 25];
  public stepSeconds = [1, 5, 10, 15, 20, 25];
  
  @ViewChild('fileInput') fileUploader: ElementRef;


  public myValidator = (ctrl: FormControl): ValidationErrors | null => {
    const myDate = new Date(ctrl.value);
    return !ctrl.value || isNaN(myDate.getTime()) || myDate.getFullYear() > 9999 ? { dateInvalid: true } : null;
  }
    better2: boolean;

  constructor(private formBuilder: FormBuilder, private dp: DatePipe, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService,private logins:LoginService, private router:Router,private cd: ChangeDetectorRef) 
  {
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }


  
  bannerform = this.formBuilder.group({
    startDate: ['',this.myValidator],
    expDate: ['',this.myValidator],
    purpose:new FormControl('', [Validators.required, 
      Validators.pattern('^[a-zA-Z\u0600-\u06FF ][\sa-zA-Z\u0600-\u06FF ]*$'), Validators.maxLength(25),Validators.required,]),
      bannerImage:['',Validators.required]
  })

  get bannerControllers() { return this.bannerform.controls }

  bannerupdateform = this.formBuilder.group({
    startDate: ['',this.myValidator],
    expDate: ['',this.myValidator],
    purpose:new FormControl('', [Validators.required, 
      Validators.pattern('^[a-zA-Z\u0600-\u06FF ][\sa-zA-Z\u0600-\u06FF ]*$'), Validators.maxLength(25),Validators.required,]),
  })

  get bannerupdateControllers() { return this.bannerupdateform.controls }

 

  ngOnInit(): void 
  {
    this.getBanners(); 
    this.date = new Date(Date.now());
    const currentYear = moment().year();
    this.maxDate = moment([currentYear + 1, 8, 20]); 
  }


  getBanners()
  {
     this.ngxLoader.start();
    const keys:any={}

    keys['type'] = 'BANNERS';
   

    this.login.GetBannersList(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
      this.bannerLists= data.bannerList;
      this.better2=true;
       this.ngxLoader.stop();
     }
    else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1070'){
      this.better2=false;
      this.ngxLoader.stop()
   }
  
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }) 
  }

  uploadFile(event) {
	  let reader = new FileReader();
    this.fileData = event.target.files[0];
		//console.log(this.fileData)
    let img = new Image()
    img.src = window.URL.createObjectURL(event.target.files[0])
    img.onload = () => {
       if(img.width === 800 && img.height === 400){
        if (event.target.files && event.target.files[0]) {
        
          reader.readAsDataURL(this.fileData);
          // When file uploads set it to file formcontrol
          reader.onload = () => {
            this.editFile = false;
            this.removeUpload = true;
          }
          // ChangeDetectorRef since file is loading outside the zone
          this.cd.markForCheck();
        }
            // upload logic here
            } else {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
              })
              if(this.useservice.chooselanguage=="en"){
                Toast.fire({
                  icon: 'error',
                  html: `Sorry, this image doesn't look like the size we wanted. <br/> It's
                  ${img.width} x ${img.height}.`
                })
                }
                else if(this.useservice.chooselanguage=="ar")
                {
                  Toast.fire({
                    icon: 'error',
                    html: `عذرًا ، هذه الصورة لا تبدو بالحجم الذي أردناه. <br/>
                    ${img.width} x ${img.height}.`
                  })
                }
              this.fileUploader.nativeElement.value = "";
              this.fileData=[];
              this.bannerform.controls.bannerImage.patchValue('');  
       }                
    } 
    
     
	}

banners1()
{
    this.banner1=true;
    this.bannerview=false;
    this.bannerupate=false;
    this.banneradd=false;
    this.bannerform.reset();
    this.getBanners()
}

  addbanners()
  {
    this.getBanners()
    this.banner1=false;
    this.bannerview=false;
    this.bannerupate=false;
    this.banneradd=true;
  }

  viewbanners(bannersobj:any)
  {
    this.getBanners()
    this.banner1=false;
    this.bannerview=true;
    this.bannerupate=false;
    this.banneradd=false;
    this.bannershow = bannersobj;
  }

  updatebanners(obj)
  {
    this.getBanners()
    this.banner1=false;
    this.bannerview=false;
    this.bannerupate=true;
    this.banneradd=false;
    this.updban=obj;
    console.log(this.updban)
    this.imageUrl= this.updban.bannerImgpath
    this.bannerupdateform.setValue({
      purpose:  this.updban.purpose,
      startDate:   this.updban.startDate,
      expDate:  this.updban.expDate
    });
  }


  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  deletebanner(bannersobj:any)
  {
    const keys:any={}

    keys['bannerId'] = bannersobj.bannerId.toString();
    keys['type'] = "DELETEBANNER";

    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the banner?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.Bannersdelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
       
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        })
      
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف اللافتة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.Bannersdelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
            Swal.fire({
              title: 'من فضلك انتظر قبول المشرف المتميز',
              icon: 'warning',
              showConfirmButton: false,
              showCancelButton: false,
              timer: 1500
            })
        })
      
      } 
    })
  }
  }

  bannerssubmit()
  {
    console.log(this.bannerform.value.expDate.format('YYYY:MM:DD hh:mm:ss'))
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("attachment", this.f);
    }
    else
    {
      this.f = this.fileData;
      formData.append("attachment", this.f);
    }
    formData.append("purpose", this.bannerform.value.purpose);
    formData.append("expDate", this.bannerform.value.expDate.format('YYYY-MM-DD hh:mm:ss'));
    formData.append("startDate", this.bannerform.value.startDate.format('YYYY-MM-DD hh:mm:ss'));
    formData.append("deviceId", this.useservice.visitorId);
    this.ngxLoader.start();
    this.login.addbanners(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          if(data['status']=='1005' && data['tokenStatus']=="1008")
     {
      if(this.useservice.chooselanguage=="en"){
      Swal.fire('sucessfully added, Please wait for superadmin acceptance', '', 'success',)}
      else if(this.useservice.chooselanguage=="ar")
      {
        Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
      }
      this.bannerform.reset();
      this.banners1();
      this.getBanners(); 
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
    else if(data['status']=='1117' && data['tokenStatus']=='1008'){
      this.bannerform.reset();
      this.banners1();
      this.getBanners(); 
       this.ngxLoader.stop();
       if(this.useservice.chooselanguage=="en"){
        Swal.fire('Please wait for superadmin acceptance', '', 'warning')}
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تمت الإضافة بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'warning')
        }
    }
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
        })
    
  }

  bannerupdatesubmit()
  {
    var formData = new FormData();
    if (this.fileData == null  || this.fileData == 0 || this.fileData==undefined || this.fileData=="") {
      this.f = new File([""], "filename");
      formData.append("attachment", this.f);
      formData.append("oldBannerName", this.updban.bannerImgpath);
    }
    else
    {
      this.f = this.fileData;
      formData.append("attachment", this.f);
      formData.append("oldBannerName", '');
    }
    formData.append("bannerId", this.updban.bannerId);
    formData.append("purpose", this.bannerupdateform.value.purpose);
    formData.append("deviceId", this.useservice.visitorId);
    if(this.bannerupdateform.value.expDate == this.updban.expDate)
    {
      formData.append("expDate", this.updban.expDate);
    }
    if(this.bannerupdateform.value.startDate == this.updban.startDate)
    {
      formData.append("startDate", this.updban.startDate);
    }
    if(this.bannerupdateform.value.startDate !== this.updban.startDate)
    {
      formData.append("startDate", this.bannerupdateform.value.startDate.format('YYYY-MM-DD hh:mm:ss'));
    }
    if(this.bannerupdateform.value.expDate !== this.updban.expDate)
    {
      formData.append("expDate", this.bannerupdateform.value.expDate.format('YYYY-MM-DD hh:mm:ss'));
    }
    this.ngxLoader.start();
    this.login.updatebanners(formData).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          if(data['status']=='1117' && data['tokenStatus']=="1008")
     {
       if(this.useservice.chooselanguage=="en")
       {
        Swal.fire('Please wait, your request is processing', '', 'warning')
      }
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire({
            title: 'يرجى الانتظار ، طلبك قيد المعالجة',
            icon: 'warning',
            showConfirmButton: false,
            showCancelButton: false,
            timer: 1500
          })
        }
     
      this.bannerform.reset();
      this.banners1();
      this.getBanners();
       this.ngxLoader.stop();
     }
     else if(data['status']=='1005' && data['tokenStatus']=="1008")
     {
       if(this.useservice.chooselanguage=="en")
       {
        Swal.fire('sucessfully updated, Please wait for superadmin acceptance', '', 'success')
      }
        else if(this.useservice.chooselanguage=="ar")
        {
          Swal.fire('تم التحديث بنجاح ، يرجى انتظار قبول المشرف المتميز', '', 'success')
        }
      this.bannerform.reset();
      this.banners1();
      this.getBanners();
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
  
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
        })
  }

}
