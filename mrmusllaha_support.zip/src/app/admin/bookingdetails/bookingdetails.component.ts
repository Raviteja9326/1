import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-bookingdetails',
  templateUrl: './bookingdetails.component.html',
  styleUrls: ['./bookingdetails.component.scss']
})
export class BookingdetailsComponent implements OnInit {

  type:any;
  banner1:boolean=true;
  betters:boolean=false;
  better:boolean=false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  allLists:any;
  searchdetails:boolean=true;
  viewdetails:boolean=false;
  showfirst:boolean=false;
  user1:any
  user12:any
  viewuserdetails:boolean=false;
  Currentbooking:boolean=false;
  transations:boolean=false;
  prCurrentbooking1:boolean=false;
  prCurrentbooking2:boolean=false
  pruser21:any;
  pruser23:any;
  pruser24:any;
  user2:any;
  user3:any;
  user4:any;
  user5:any;
  user6:any;
  wallet:any;
  pruser22:any;
  bookinghistory:boolean=false;
  carthistory:boolean=false;
  addreshistory:boolean=false;
  prviewdetails:boolean=false;
  pruser1:any
  pruser12:any
  prviewuserdetails:boolean=false;
  prCurrentbooking:boolean=false;
  prtransations:boolean=false;
  prCurrentbooking3:boolean=false;
  pruser2:any;
  pruser3:any;
  pruser4:any;
  pruser5:any;
  pruser6:any;
  prwallet:any;
  prbookinghistory:boolean=false;
  prcarthistory:boolean=false;
  praddreshistory:boolean=false;
  prviewdetails1:boolean=false;
  prviewdetails2:boolean=false;
  prviewdetails23:boolean=false;
  baseUrl: any =  "https://images.mrmusllaha.com/subcategories/";
  baseUrl2: any =  "https://images.mrmusllaha.com/categories/";
  baseUrl3: any =  "https://images.mrmusllaha.com/profile/";
  baseUrl4: any =  "https://images.mrmusllaha.com/banners/";
  baseUrl5: any =  "https://images.mrmusllaha.com/subcategorytypes/";

  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router, private cd: ChangeDetectorRef, private logins:LoginService) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }

  ngOnInit(): void 
  {
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  searchform = this.formBuilder.group({
    mobileNumber:['',[Validators.required,Validators.minLength(9), Validators.maxLength(9),Validators.pattern(/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/)]]
  })

  get searchsingle(){
    return this.searchform.controls;
  }

getalldetails()
{
  this.ngxLoader.start();
  const keys:any={}

  keys['type'] = 'GETDETAILS';
  keys['mobileNumber'] = '966'+this.searchform.value.mobileNumber;
  

  this.login.GetallList(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
  {
    console.log(data)
   if(data['status']=='1005' && data['tokenStatus']=="1008")
   {
     if(data.userType=="PROFESSIONAL"){
      this.allLists= data;
      this.wallet = data.professionalBalance;
      this.showdetails3();
      console.log(this.allLists)
       this.ngxLoader.stop();
     }
     else if(data.userType=="USER"){
      this.allLists= data;
      this.wallet = data.UserBalance;
      this.showdetails2();
      console.log(this.allLists)
       this.ngxLoader.stop();
     }
     
   }
   else if(data['status']=='1009' || data['tokenStatus']=='1009'){
    this.useservice.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession()
  }
  else if(data['tokenStatus']=='1187'){
    this.useservice.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession5()
  }
    else if(data['status'])
    {
      this.useservice.getallres = data['status'] ;
      this.better = this.useservice.allrespnse();
      this.betters=true
      setTimeout(() => {
        this.betters = false;
      }, 3000);
      this.ngxLoader.stop();
    }
  })
}

ngOnDestroy() {
  this.destroy$.next(true);
  this.destroy$.unsubscribe();
}

showdetails()
{
  this.searchdetails = true;
  this.viewdetails = false;
  this.viewuserdetails=false;
  this.Currentbooking=false;
  this.transations=false;
  this.bookinghistory=false;
  this.carthistory=false;
  this.addreshistory=false;
  this.praddreshistory=false;
  this.prbookinghistory=false;
  this.prtransations=false;
  this.prCurrentbooking=false;
  this.prviewuserdetails=false;
  this.prviewdetails=false;
}

showdetails2()
{
  this.searchdetails = true;
  this.viewdetails = false;
  this.viewuserdetails=false;
  this.Currentbooking=false;
  this.transations=false;
  this.bookinghistory=false;
  this.carthistory=false;
  this.addreshistory=false
  this.usde();
}

showdetails3()
{
  this.searchdetails = true;
  this.prviewdetails = false;
  this.prviewuserdetails=false;
  this.prCurrentbooking=false;
  this.prtransations=false;
  this.prbookinghistory=false;
  this.prcarthistory=false;
  this.praddreshistory=false
  this.prusde();
}

showdetails5()
{

}

alerts()
  {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 4000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    if(this.useservice.chooselanguage=="en"){
    Toast.fire({
      icon: 'warning',
      html: `No Record found`
    })
  }
  else if(this.useservice.chooselanguage=="ar"){
    Toast.fire({
      icon: 'warning',
      html: `<div style="direction: rtl;">لا يوجد سجلات</div>`
    })
  }
  }

usde()
{
    if(this.allLists.Userdetails =="" || this.allLists.Userdetails ==undefined || this.allLists.Userdetails ==[])
    {
      this.alerts();
    }
    else
    {
      this.searchdetails = false;
      this.viewdetails = true;
      this.showfirst=false;
      this.viewuserdetails=true;
      this.Currentbooking=false;
      this.transations=false;
      this.bookinghistory=false;
      this.carthistory=false
      this.addreshistory=false
      this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
      this.user1=this.allLists.Userdetails;
      this.user12 = this.user1.customerName
      console.log(this.user1)
    }
}

uscurde()
{
  if(this.allLists.UsercurrentBookingsList =="" || this.allLists.UsercurrentBookingsList ==undefined || this.allLists.UsercurrentBookingsList ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.viewdetails = true;
    this.showfirst=false;
    this.viewuserdetails=false;
    this.Currentbooking=true;
    this.transations=false;
    this.bookinghistory=false;
    this.carthistory=false
    this.addreshistory=false
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.user2=this.allLists.UsercurrentBookingsList;
    console.log(this.user1)
  }
}

ustransde()
{
  if(this.allLists.UserTransactionsList =="" || this.allLists.UserTransactionsList ==undefined || this.allLists.UserTransactionsList ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.viewdetails = true;
    this.showfirst=false;
    this.viewuserdetails=false;
    this.Currentbooking=false;
    this.transations=true;
    this.bookinghistory=false;
    this.carthistory=false
    this.addreshistory=false
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.user3=this.allLists.UserTransactionsList;
    console.log(this.user1)
  }
}

usbookdet()
{
  if(this.allLists.UserBookingHistoryList =="" || this.allLists.UserBookingHistoryList ==undefined || this.allLists.UserBookingHistoryList ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.viewdetails = true;
    this.showfirst=false;
    this.viewuserdetails=false;
    this.Currentbooking=false;
    this.transations=false;
    this.bookinghistory=true;
    this.carthistory=false
    this.addreshistory=false
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.user4=this.allLists.UserBookingHistoryList;
    console.log(this.user1)
  }
}

uscardet()
{
  if(this.allLists.UserCartDetails =="" || this.allLists.UserCartDetails ==undefined || this.allLists.UserCartDetails ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.viewdetails = true;
    this.showfirst=false;
    this.viewuserdetails=false;
    this.Currentbooking=false;
    this.transations=false;
    this.bookinghistory=false;
    this.carthistory=true;
    this.addreshistory=false
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.user5=this.allLists.UserCartDetails;
    console.log(this.user1)
  }
}

usadddet()
{
  if(this.allLists.UserAddress =="" || this.allLists.UserAddress ==undefined || this.allLists.UserAddress ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.viewdetails = true;
    this.showfirst=false;
    this.viewuserdetails=false;
    this.Currentbooking=false;
    this.transations=false;
    this.bookinghistory=false;
    this.carthistory=false
    this.addreshistory=true
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.user6=this.allLists.UserAddress;
    console.log(this.user1)
  }
}



prusde()
{
    if(this.allLists.professionaldetails =="" || this.allLists.professionaldetails ==undefined || this.allLists.professionaldetails ==[])
    {
      this.alerts();
    }
    else
    {
      this.searchdetails = false;
      this.prviewdetails = true;
      this.showfirst=false;
      this.prviewuserdetails=true;
      this.prCurrentbooking=false;
      this.prtransations=false;
      this.prbookinghistory=false;
      this.prcarthistory=false
      this.praddreshistory=false
      this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
      this.pruser1=this.allLists.professionaldetails;
      this.pruser12 = this.pruser1.professionalName
      console.log(this.pruser1 , this.pruser12)
    }
}

pruscurde()
{
  if(this.allLists.professionalCategoryandSubcategoriesdetails =="" || this.allLists.professionalCategoryandSubcategoriesdetails ==undefined || this.allLists.professionalCategoryandSubcategoriesdetails ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=true;
    this.prtransations=false;
    this.prbookinghistory=false;
    this.prcarthistory=false
    this.praddreshistory=false
    this.prCurrentbooking3=false;
    this.pruser2=this.allLists.professionalCategoryandSubcategoriesdetails;
    console.log(this.pruser1)
  }
}

prustransde()
{
  if(this.allLists.professionalTransactionsList =="" || this.allLists.professionalTransactionsList ==undefined || this.allLists.professionalTransactionsList ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=false;
    this.prtransations=true;
    this.prbookinghistory=false;
    this.prcarthistory=false
    this.praddreshistory=false
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.pruser3=this.allLists.professionalTransactionsList;
    console.log(this.user1)
  }
}

prusbookdet()
{
  if(this.allLists.professionalworkHistoryList =="" || this.allLists.professionalworkHistoryList ==undefined || this.allLists.professionalworkHistoryList ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=false;
    this.prtransations=false;
    this.prbookinghistory=true;
    this.prcarthistory=false
    this.praddreshistory=false
    this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.pruser4=this.allLists.professionalworkHistoryList;
    console.log(this.pruser1)
  }
}



prusadddet()
{
  if(this.allLists.professionalAddress =="" || this.allLists.professionalAddress ==undefined || this.allLists.professionalAddress ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=false;
    this.prtransations=false;
    this.prbookinghistory=false;
    this.prcarthistory=false
    this.praddreshistory=true
    this.prCurrentbooking2=false;
this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=false;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
    this.pruser6=this.allLists.professionalAddress;
    console.log(this.pruser1)
  }
}

cat1(item:any)
{
  if(item.categories =="" || item.categories ==undefined || item.categories ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=false;
    this.prtransations=false;
    this.prbookinghistory=false;
    this.prcarthistory=false;
    this.praddreshistory=false;
    this.prCurrentbooking1=true;
    this.prviewdetails1=true;
    this.pruser21=item.categories;
    this.pruser22=this.pruser21.cAttributes;
    console.log(this.pruser22)
  
  }
}

subcat1(item)
{
  if(item.subcategories =="" || item.subcategories ==undefined || item.subcategories ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=false;
    this.prtransations=false;
    this.prbookinghistory=false;
    this.prcarthistory=false;
    this.praddreshistory=false;
    this.prCurrentbooking1=false;
    this.prCurrentbooking2=true;
    this.prviewdetails1=false;
    this.prviewdetails2=true;
    this.pruser23=item.subcategories;
    console.log(this.pruser22)
  
  }
}

subcatabb(item)
{
  if(item.scAttributes =="" || item.scAttributes ==undefined || item.scAttributes ==[])
  {
    this.alerts();
  }
  else
  {
    this.searchdetails = false;
    this.prviewdetails = true;
    this.showfirst=false;
    this.prviewuserdetails=false;
    this.prCurrentbooking=false;
    this.prtransations=false;
    this.prbookinghistory=false;
    this.prcarthistory=false;
    this.praddreshistory=false;
    this.prCurrentbooking1=false;
    this.prCurrentbooking2=false;
    this.prCurrentbooking3=true;
    this.prviewdetails1=false;
    this.prviewdetails2=true;
    this.prviewdetails23=true;
    this.pruser24=item.scAttributes;
    console.log(this.pruser22)
  }
}

getback1()
{
this.prCurrentbooking2=true;
this.prCurrentbooking3=false;
this.prviewdetails1=false;
this.prviewdetails2=true;
this.prviewdetails23=false;
}

getback2()
{
this.prCurrentbooking2=false;
this.prCurrentbooking3=false;
this.prCurrentbooking1=false;
this.prCurrentbooking=true;
this.prviewdetails1=false;
this.prviewdetails2=false;
this.prviewdetails23=false;
}

}
