import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchComponent } from 'src/app/commonshare/search/search.component';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})

export class CategoryComponent implements OnInit {

  categoryupate:boolean=false;
  categoryadd:boolean=false;
  categoryview:boolean=false;
  betters:boolean=false;
  better:boolean=false;
  subcat:any;
  subcategories:boolean=false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  categoryLists:any;
  subcategoryLists:any;
  viewcategories:boolean=false;
  categorylist:boolean=false;
  viewsubtypattr:boolean=false;
  viewsubtypplace:boolean=false;
  subattb:any;
  viewsubattr:boolean=false;
  subtypes:boolean=false;
  typesview:any;
  type:any;
  getsearchdetailss:any;
  typesattr:any;
  typesplaces:any;
  get1:boolean=false;
  get12:boolean=false;
  get13:boolean=false;
  get134:boolean=false;
  get1345:boolean=false;
  err:boolean=false;
  getcountries:boolean=true;
  subcatypeid:any;
  universalid:any;
  baseUrl: any =  "https://images.mrmusllaha.com/categories/";
  baseUrl2: any =  "https://images.mrmusllaha.com/subcategories/";
  baseUrl4: any = "https://images.mrmusllaha.com/banners/";
  baseUrl5: any = "https://images.mrmusllaha.com/subcategorytypes/";
  better2: boolean;
  nodatas: boolean = false;
  getdatas: any;

  constructor(private formBuilder: FormBuilder, private login:AdminService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService,private logins:LoginService, private router:Router, public dialog: MatDialog) 
  {
    if(this.useservice.accesstoken==undefined){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession();
      }
    if( this.useservice.type == undefined  || this.useservice.type == 'NA') 
    {
    this.type = ""
    }
    else
    {
      this.type = this.useservice.type
    }
  }
  cityformadd = this.formBuilder.group({
    countryName: ['SaudiArabia',[Validators.required, 
      Validators.pattern('^[a-zA-Z\u0600-\u06FF\\s][\sa-zA-Z\u0600-\u06FF\\s-]*$'), Validators.maxLength(25)]],
  })

  cityform = this.formBuilder.group({
    city: ['Select',[Validators.required]],
  })

  get cityControllers() { return this.cityform.controls }
  get countryControllers() { return this.cityformadd.controls }

  ngOnInit(): void 
  {
  }

  getrefresh()
  {
    if(this.categorylist==true)
    {
       this.citysubmit()
       this.subcategories=false;
       this.subtypes=false
    }
    else if(this.subcategories==true)
    {
      this.getsubcat()
      this.categorylist=false;
      this.subtypes=false
    }
    else if(this.subtypes==true)
    {
      this.getsubcat()
      this.categorylist=false;
      this.subtypes=false;
      this.subcategories=true
    }
  }

  block2()
  {
    this.getcountries=false;
    this.viewcategories=true;
  }

  countrysubmit()
  {
    this.ngxLoader.start();
       
    const keys:any={}


    
    keys['type'] = 'GETCITES';
    keys['countryName'] = this.cityformadd.value.countryName;

    this.login.getcities(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
      if(data['status']=='1069' && data['tokenStatus']=="1008")
      {   
          this.getsearchdetailss=data.cites_list
      
        console.log( this.getsearchdetailss)
        this.block2();
        this.ngxLoader.stop();
      }
      else if(data['status']=='1009' || data['tokenStatus']=='1009'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession()
      }
      else if(data['tokenStatus']=='1187'){
        this.useservice.sendlanguage.subscribe(res=>
          {
            this.logins.data = res
          })
        this.logins.usersession5()
      }
       else if(data['status'])
       {
         this.useservice.getallres = data['status'] ;
         this.better = this.useservice.allrespnse();
         this.betters=true
         setTimeout(() => {
           this.betters = false;
         }, 3000);
         this.ngxLoader.stop();
       }
    }) 
  }

  selectmethod(id)
  {
   this.universalid=id
   console.log(this.universalid)
  }

  gobacking()
  {
    this.getcountries=true;
    this.viewcategories=false;
  }

  citysubmit()
  {
    this.ngxLoader.start();
    if(this.cityformadd.value.countryName==="SaudiArabia"){

    const keys:any={}
    keys['type'] = 'CATEGORIES';
    keys['id'] = this.universalid;
    keys['language'] = this.useservice.chooselanguage;

    this.login.GetCategoriesList(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
      this.getcountries = false;
      this.categorylist = true;
      this.betters=false;
      this.categoryLists= data.list;
      console.log(this.categoryLists)
       this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
    else if (data['status'] == '1070' && data['tokenStatus'] == "1008")
    {
      if (this.useservice.chooselanguage == "en")
      {
        this.nodatas=true
        this.subcategories=false;
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
      else if (this.useservice.chooselanguage == "ar")
      {
        this.nodatas=true
        this.subcategories=false;
        this.betters=true;
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }
    
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
  }
  else
  {
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
  }
  }

  getsubdata(keys:any)
  {
    this.subcat=keys
    console.log(this.subcat)
    this.subcategories=true;
    this.viewcategories=false;
    this.categorylist=false;
    this.getsubcat();
  }

getsubcat()
{
  this.ngxLoader.start();
  const keys:any={}

  keys['type'] = 'SUBCATEGORIES';
  keys['language'] = this.useservice.chooselanguage;
  keys['id'] = this.subcat.categoryId;

  this.login.GetCategoriesList(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
  {
    console.log(data)
   if(data['status']=='1069' && data['tokenStatus']=="1008")
   {
    this.get1=true;
    this.better2=false;
    this.subcategoryLists= data.list
    console.log(this.subcategoryLists)
    this.ngxLoader.stop();
   }
   else if(data['status']=='1009' || data['tokenStatus']=='1009'){
    this.useservice.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession()
  }
  else if(data['tokenStatus']=='1187'){
    this.useservice.sendlanguage.subscribe(res=>
      {
        this.logins.data = res
      })
    this.logins.usersession5()
  }
  else if(data['status']=='1069'){
     this.ngxLoader.stop()
  }
  else if (data['status'] == '1070' && data['tokenStatus'] == "1008")
  {
    this.categorylist=false;
    this.subcategoryLists=[]
    this.subcategories=true;
    this.better2=true;
    this.ngxLoader.stop();
  }
 
    else if(data['status'])
    {
      this.useservice.getallres = data['status'] ;
      this.better = this.useservice.allrespnse();
      this.betters=true
      setTimeout(() => {
        this.betters = false;
      }, 3000);
      this.ngxLoader.stop();
    }
  })
}

  gobacktypplaces()
  {
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=false;
    this.viewsubtypplace=true;
    this.categorylist=false;
    this.viewsubtypattr=false;
    this.get1=true;
    this.get12=false;
    this.get13=true;
    this.get134=false;
    this.get1345=true;
    this.err= false;
  }

  gobacktypattr()
  {
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=false;
    this.viewsubtypplace=false;
    this.categorylist=false;
    this.viewsubtypattr=true;
    this.get1=true;
    this.get12=false;
    this.get13=true;
    this.get134=true;
    this.get1345=false;
    this.err= false;
  }

  gobackattr()
  {
    this.viewsubattr=true;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=false;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.get1=true;
    this.get12=true;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.err= false;
  }

  gobackcat()
  {
    this.viewsubattr=false;
    this.viewcategories=false;
    this.getcountries=true;
    this.subtypes=false;
    this.subcategories=false;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.nodatas=false;
    this.get1=false;
    this.get12=false;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.err= false;
  }

  gobacksubcat()
  {
    this.viewsubattr=true;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=false;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.get1=false;
    this.get12=false;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.err= false;
  }

  getbacktypes()
  {
    this.get1=true;
    this.get12=false;
    this.get13=true;
    this.get134=false;
    this.get1345=false;
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=true;
    this.viewsubtypattr=false;
    this.subcategories=false;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.err= false;
  }

  getbacktypes2()
  {
    this.get1=true;
    this.get12=false;
    this.get13=true;
    this.get134=false;
    this.get1345=false;
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=true;
    this.subcategories=false;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.viewsubtypattr=false;
    this.err= false;
  }

  getbacktypes3()
  {
    this.get1=true;
    this.get12=false;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=true;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.viewsubtypattr=false;
    this.err= false;
    this.better2=false;
  }

  getbacktypes4()
  {
    this.get1=true;
    this.get12=false;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=true;
    this.categorylist=false;
    this.viewsubtypplace=false;
    this.viewsubtypattr=false;
    this.err= false;
  }

  getbacktypes5()
  {
    this.get1=false;
    this.get12=false;
    this.get13=false;
    this.get134=false;
    this.get1345=false;
    this.viewsubattr=false;
    this.viewcategories=false;
    this.subtypes=false;
    this.subcategories=false;
    this.categorylist=true;
    this.viewsubtypplace=false;
    this.viewsubtypattr=false;
    this.err= false;
  }

  alerts()
  {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 4000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    Toast.fire({
      icon: 'warning',
      html: `No Record found`
    })
  }

  getattribute(keys)
  {
    if(keys.subcategoryAttributes===undefined || keys.subcategoryAttributes==="" || keys.subcategoryAttributes===[])
    {
      this.alerts()
      this.viewsubattr=false;
    }
    else
    {
      this.gobackattr();  
      this.subattb = keys.subcategoryAttributes;
      console.log(this.subattb)
    }
  }


  gettypes(item)
  {
      this.subcatypeid=item.subCategoryId
      this.getdatas = item
    
    this.ngxLoader.start();
    const keys:any={}
  
    keys['type'] = 'SUBCATEGORIETYPES';
    keys['language'] = this.useservice.chooselanguage;
    keys['id'] = this.subcatypeid;
  
    this.login.GetCategoriesList(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      console.log(data)
     if(data['status']=='1069' && data['tokenStatus']=="1008")
     {
      this.subtypes=true;
      this.better2=false;
      this.getbacktypes();
      this.typesview= data.list
      console.log(this.typesview)
      this.ngxLoader.stop();
     }
     else if(data['status']=='1009' || data['tokenStatus']=='1009'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession()
    }
    else if(data['tokenStatus']=='1187'){
      this.useservice.sendlanguage.subscribe(res=>
        {
          this.logins.data = res
        })
      this.logins.usersession5()
    }
    else if(data['status']=='1069'){
       this.ngxLoader.stop()
    }
  else if (data['status'] == '1070' && data['tokenStatus'] == "1008")
  {
      this.typesview=[]
      this.subtypes=true;
      this.subcategories=false;
    this.better2=true;
    this.ngxLoader.stop();
  }
   
      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    })
    
  }

  gettypesattr(keys)
  {
    if(keys.subcategoryTypeAttributes===undefined || keys.subcategoryTypeAttributes==="" || keys.subcategoryTypeAttributes===[])
    {
      this.alerts()
      this.viewsubtypattr=false;
    }
    else
    {
      this.gobacktypattr();
      this.typesattr = keys.subcategoryTypeAttributes
     console.log(this.typesattr)
    }
  
  }

  gettypeplaces(item)
  {
    if(item.citiesPrices===undefined || item.citiesPrices==="" || item.citiesPrices===[])
    {
      this.alerts()
      this.viewsubtypplace=false;
    }
    else
    {
      this.gobacktypplaces();
      this.typesplaces = item.citiesPrices
      console.log(this.typesplaces)
    }
  
  }
  

  openCompaniesModal(item:any): void {
    console.log(item)
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {name: item,name1:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal2(item:any): void {
    console.log(item)
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {name: item,name2:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal3(): void {
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {name3:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal4(): void {
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {id:this.subcat,name4:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal5(item): void {
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {dat:item,name5:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal6(item): void {
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {dat:item,name6:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });
    

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal7(item): void {
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {dat1:item,name7:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });
    

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  openCompaniesModal8(): void {
    console.log(this.subcatypeid)
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {dat2:this.getdatas,name8:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });
    
    

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }


  openCompaniesModal10(item:any): void {
    console.log(item)
    var data:boolean=true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: 'auto',
      data: {dat9:item,name9:data}, disableClose: true,
      position: {
        top: '20px'
      }
    });
    
    

    dialogRef.afterClosed().subscribe((result:any) => {
      console.log('The dialog was closed');
    });
  }

  
  deletecategory(bannersobj:any)
  {
    const keys:any={}

    keys['id'] = bannersobj.categoryId;
    keys['type'] = "CATEGORIES";

    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the category?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.cateorysubtydelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
       
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        })
      
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف الفئة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.cateorysubtydelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
            Swal.fire({
              title: 'من فضلك انتظر قبول المشرف المتميز',
              icon: 'warning',
              showConfirmButton: false,
              showCancelButton: false,
              timer: 1500
            })
        })
      
      } 
    })
  }
  }

  deletesubcattyp(bannersobj:any)
  {
    const keys:any={}

    keys['id'] = bannersobj.subCategoryTypeId;
    keys['type'] = "SUBCATEGORIETYPES";

    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the Sub-category Type?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.cateorysubtydelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
       
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        })
      
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف الفئة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.cateorysubtydelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
            Swal.fire({
              title: 'من فضلك انتظر قبول المشرف المتميز',
              icon: 'warning',
              showConfirmButton: false,
              showCancelButton: false,
              timer: 1500
            })
        })
      
      } 
    })
  }
  }

  deletesubcategory(bannersobj:any)
  {
    const keys:any={}

    keys['id'] = bannersobj.subCategoryId;
    keys['type'] = "SUBCATEGORIES";

    if(this.useservice.chooselanguage=="en"){
    console.log(keys)
    Swal.fire({
      title: 'Do you want to delete the subcategory?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.cateorysubtydelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
       
          Swal.fire('Please wait for superadmin acceptance', '', 'warning')
        })
      
      } 
    })
  }
  else if(this.useservice.chooselanguage=="ar")
  {
    console.log(keys)
    Swal.fire({
      title: 'هل تريد حذف الفئة؟',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `نعم`,
      denyButtonText: `لا`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.login.cateorysubtydelete(keys).pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
        {
          console.log(data)
            Swal.fire({
              title: 'من فضلك انتظر قبول المشرف المتميز',
              icon: 'warning',
              showConfirmButton: false,
              showCancelButton: false,
              timer: 1500
            })
        })
      
      } 
    })
  }
  }
}
