import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

export function noWhitespaceValidator(control: FormControl) {
  const isSpace = (control.value || '').match(/\s/g);
  return isSpace ? {'whitespace': true} : null;
}
export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
      control.setValue('');
      console.log(control.value);
      return { required: true }
  }
  else {
      return null;
  }
  }


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy{
  

  fieldTextType: boolean = false;
  ip!: string;
  long!: string;
  latt!: string;
  betters:boolean=false;
  better:boolean=false;
  destroy$: Subject<boolean> = new Subject<boolean>();

  constructor(private formBuilder: FormBuilder, private login:LoginService,private ngxLoader: NgxUiLoaderService, private useservice:AllinoneService, private router:Router,private translateService: TranslateService) 
  {
    this.login.usersession8()
    this.translateService.setDefaultLang('en');
    this.useservice.chooselanguage = 'en';
    this.useservice.changlang('en');
    this.useservice.ipaddress.subscribe(res => {
      this.ip=res
      console.log(this.ip)
    });
    this.useservice.longitude.subscribe(res => {
     this.long=res
    });
    this.useservice.lattitude.subscribe(res => {
      this.latt=res
    });
  }

  ngOnInit(): void {}

 selectmethod(val) 
  {
  this.useservice.chooselanguage=val
  this.translateService.use(val).toPromise();
  this.useservice.changlang(val);
  console.log(this.useservice.chooselanguage)
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  loginform = new FormGroup({
    emailId:new FormControl('',[Validators.pattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"), Validators.required]),
    cred:new FormControl('', [Validators.required, spaceValidator,Validators.minLength(8), Validators.maxLength(16),Validators.pattern(/^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/)])
  })


  get fixit(){
    return this.loginform.controls;
  }

  LoginUser()
  {

    this.ngxLoader.start();
    const keys:any={}

    keys['iPAddress'] = this.ip;
    keys['latitude'] = this.latt;
    keys['longitude'] = this.long;
    keys['language'] = "en"

    this.login.useremaillogin(keys,this.loginform.value.emailId,this.loginform.value.cred)
    .pipe(takeUntil(this.destroy$)).subscribe((data: any)=>
    {
      if(data['status']=='1005' && data['userType']=="Maker")
      {
        this.useservice.nameUser=data.userName;
        this.useservice.type=data.userType;
        this.useservice.changeMessages(data);
        this.useservice.nextMessage(data);
        this.useservice.showmenu = true;
        this.ngxLoader.stop();
        this.router.navigate(['/admin/welcome']);
      }
      if(data['status']=='1005' && data['userType']=="Checker")
      {
        this.useservice.nameUser=data.userName;
        this.useservice.type=data.userType;
        this.useservice.changeMessages(data);
        this.useservice.nextMessage(data);
        this.useservice.showmenu1 = true;
        this.ngxLoader.stop();
        this.router.navigate(['/superadmin/requestlist']);
      }
      if(data['status']=='1005' && data['userType']=="MasterAdmin")
      {
        this.useservice.nameUser=data.userName;
        this.useservice.type=data.userType;
        this.useservice.changeMessages(data);
        this.useservice.nextMessage(data);
        this.useservice.showmenu2 = true;
        this.ngxLoader.stop();
        this.router.navigate(['/masteradmin']);
      }

      else if(data['status'])
      {
        this.useservice.getallres = data['status'] ;
        this.better = this.useservice.allrespnse();
        this.betters=true
        setTimeout(() => {
          this.betters = false;
        }, 3000);
        this.ngxLoader.stop();
      }
    }) 
  }


  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

}
