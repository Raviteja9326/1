import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgotpasswd',
  templateUrl: './forgotpasswd.component.html',
  styleUrls: ['./forgotpasswd.component.scss']
})
export class ForgotpasswdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
