import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './commonshare/dashboard/dashboard.component';
import { LoginComponent } from './secure/login/login.component';
import { RegisterComponent } from './secure/register/register.component';
import { ForgotpasswdComponent } from './secure/forgotpasswd/forgotpasswd.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClient, HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { NgxUiLoaderConfig, NgxUiLoaderModule, SPINNER, POSITION,PB_DIRECTION, NgxUiLoaderRouterModule, NgxUiLoaderService } from 'ngx-ui-loader';
import { ErrorComponent } from './commonshare/error/error.component';
import { SearchComponent } from './commonshare/search/search.component';
import { MaterialModule } from './commonshare/material.module';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Dashboard2Component } from './commonshare/dashboard2/dashboard2.component';
import { Dashboard3Component } from './commonshare/dashboard3/dashboard3.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
}


const ngxUiLoaderConfig: NgxUiLoaderConfig =
{
  "bgsColor": "#d8b253",
  "bgsOpacity": 0.5,
  "bgsPosition": "center-center",
  "bgsSize": 60,
  "bgsType": "ball-scale-multiple",
  "blur": 5,
  "delay": 0,
  "fastFadeOut": true,
  "fgsColor": "#a78a43",
  "fgsPosition": "center-center",
  "fgsSize": 60,
  "fgsType": "ball-scale-multiple",
  "gap": 24,
  "masterLoaderId": "master",
  "overlayBorderRadius": "0",
  "overlayColor": "rgba(167,138,67,0.50)",
  "pbColor": "#d8b253",
  "pbDirection": "ltr",
  "pbThickness": 3,
  "hasProgressBar": true,
  "text": "",
  "textColor": "#FFFFFF",
  "textPosition": "center-center",
  "maxTime": -1,
  "minTime": 300
}

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    Dashboard2Component,
    Dashboard3Component,
    LoginComponent,
    RegisterComponent,
    ForgotpasswdComponent,
    ErrorComponent,
    SearchComponent
  ],
  imports: [
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    BrowserAnimationsModule,
    MaterialModule,
    BrowserModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgxUiLoaderRouterModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
