import {
    Injectable
} from '@angular/core';
import {
    DeviceDetectorService,
    DeviceInfo
} from 'ngx-device-detector';
import {
    BehaviorSubject
} from 'rxjs';
import FingerprintJS from '@fingerprintjs/fingerprintjs'

@Injectable({
    providedIn: 'root'
})

export class AllinoneService {
    public ipaddress = new BehaviorSubject('0');
    public longitude = new BehaviorSubject('0');
    public lattitude = new BehaviorSubject('0');
    public deviceInfo: DeviceInfo | undefined;
    public isMobilevar = false;
    public isTabletvar = false;
    public isDesktopvar = false;
    public showmenu: boolean = false;
    public showmenu1: boolean = false;
    public showmenu2: boolean = false;
    public showaddbann = new BehaviorSubject('false');
    public nameUser!: string;
    public getallres: any;
    public readdy: any;
    public visitorId: any;
    public type: any;
    public chooselanguage: any;
    public titless = new BehaviorSubject('0');
    public accesstoken!: string;
    public messageSource = new BehaviorSubject('default message');
    public currentMessage = this.messageSource.asObservable();
    public sendlanguage = new BehaviorSubject('en');

    constructor(private deviceDetectorService: DeviceDetectorService) {
        this.detectDevice();
        this.isMobile();
        this.isTablet();
        this.isDesktop();
        this.getdeviceid();
    }

    changlang(lang: any) {
        this.sendlanguage.next(lang);
        console.log("ssssssssss", lang)
    }

    setdata(list: any) {
        this.showaddbann.next(list);
    }

    setTitless(ipaddress: any) {
        this.ipaddress.next(ipaddress);
    }

    setTitless2(longitude: any) {
        this.longitude.next(longitude);
    }

    setTitless3(lattitude: any) {
        this.lattitude.next(lattitude);
    }

    public detectDevice() {
        this.deviceInfo = this.deviceDetectorService.getDeviceInfo();
    }

    public isMobile() {
        this.isMobilevar = this.deviceDetectorService.isMobile();
    }

    public isTablet() {
        this.isTabletvar = this.deviceDetectorService.isTablet();
    }

    public isDesktop() {
        this.isDesktopvar = this.deviceDetectorService.isDesktop();
    }

    changeMessages(message: any) {
        this.messageSource.next(message)
        this.accesstoken = message.token;
    }

    nextMessage(message: any) {
        this.messageSource.next(message)
        this.accesstoken = message.token;
    }

    getdeviceid() {
        var length = 32; 
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
            this.visitorId = result
        }
        return  this.visitorId;
    }


    getResponse() {
        const obj: any = {}
        obj["browserType"] = this.deviceInfo?.browser;
        obj["browserVersion"] = this.deviceInfo?.browser_version;
        obj["deviceId"] = this.visitorId;
        obj['deviceType'] = 'Web';
        obj["osType"] = this.deviceInfo?.os;
        obj["osVersion"] = this.deviceInfo?.os_version;
        obj['macAddress'] = "NA";
        return obj;
    }

    allrespnse() {
        if (this.chooselanguage == "en") {

            if (this.getallres == '1001') {
                this.readdy = "Email ID is required"
                return this.readdy

            }
            if (this.getallres == '1002') {
                this.readdy = "EMail is required"
                return this.readdy
            }
            if (this.getallres == '1003') {
                this.readdy = "first name is required"
                return this.readdy
            }
            if (this.getallres == '1004') {
                this.readdy = "last name is required"
                return this.readdy
            }
            if (this.getallres == '1006') {
                this.readdy = "Failure"
                return this.readdy
            }
            if (this.getallres == '1007') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1009') {
                this.readdy = " Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1010') {
                this.readdy = "Please try again after 30 minutes or contact support@mrmusllah.com"
                return this.readdy
            }
            if (this.getallres == '1011') {
                this.readdy = "Invalid Email ID or Password"
                return this.readdy
            }
            if (this.getallres == '1012') {
                this.readdy = "Invalid Email ID or Password"
                return this.readdy
            }
            if (this.getallres == '1013') {
                this.readdy = "OTP sent to registered emailid"
                return this.readdy
            }
            if (this.getallres == '1014') {
                this.readdy = "OTP is not valid"
                return this.readdy
            }
            if (this.getallres == '1015') {
                this.readdy = "OTP is not valid"
                return this.readdy
            }
            if (this.getallres == '1016') {
                this.readdy = "OTP is required"
                return this.readdy
            }
            if (this.getallres == '1017') {
                this.readdy = "OTP is required"
                return this.readdy
            }
            if (this.getallres == '1018') {
                this.readdy = "Please enter valid mobile number"
                return this.readdy
            }
            if (this.getallres == '1019') {
                this.readdy = "Please enter valid Email Address"
                return this.readdy
            }
            if (this.getallres == '1020') {
                this.readdy = "Please enter valid First Name"
                return this.readdy
            }
            if (this.getallres == '1021') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1022') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1023') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1024') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }


            if (this.getallres == '1025') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1026') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1027') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1028') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1029') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1030') {
                this.readdy = "Password is required"
                return this.readdy
            }
            if (this.getallres == '1031') {
                this.readdy = "Password must contain 1 Uppercase Letter and 1 Lowercase Letter and 1 Special Character"
                return this.readdy
            }
            if (this.getallres == '1032') {
                this.readdy = " Password length should be between 8-20"
                return this.readdy
            }
            if (this.getallres == '1034') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1035') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1036') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }

            if (this.getallres == '1037') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1038') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1039') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1040') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1041') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1042') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1043') {
                this.readdy = "Looks Like our Servers are busy! Please try again later!"
                return this.readdy
            }
            if (this.getallres == '1044') {
                this.readdy = "OTP is required"
                return this.readdy
            }
            if (this.getallres == '1045') {
                this.readdy = "OTP length should be 4 digits"
                return this.readdy
            }
            if (this.getallres == '1046') {
                this.readdy = "Email ID already registered"
                return this.readdy
            }
            if (this.getallres == '1047') {
                this.readdy = "EmailId already registered"
                return this.readdy
            }
            if (this.getallres == '1048') {
                this.readdy = "Sucessfully registered, Please for Admin Conformation message"
                return this.readdy
            }
            if (this.getallres == '1049') {
                this.readdy = "Customer type is required"
                return this.readdy
            }
            if (this.getallres == '1050') {
                this.readdy = "Multiple Registrations are not allowed with same device"
                return this.readdy
            }
            if (this.getallres == '1051') {
                this.readdy = "Country code is required"
                return this.readdy
            }
            if (this.getallres == '1052') {
                this.readdy = "Old Password is required"
                return this.readdy
            }
            if (this.getallres == '1053') {
                this.readdy = "New Password is required"
                return this.readdy
            }
            if (this.getallres == '1054') {
                this.readdy = "Conform Password is required"
                return this.readdy
            }
            if (this.getallres == '1055') {
                this.readdy = "Name is required"
                return this.readdy
            }
            if (this.getallres == '1056') {
                this.readdy = "Invalid Old Password"
                return this.readdy
            }
            if (this.getallres == '1057') {
                this.readdy = "Please wait for admin configuration"
                return this.readdy
            }
            if (this.getallres == '1058') {
                this.readdy = "Gender is required"
                return this.readdy
            }
            if (this.getallres == '1060') {
                this.readdy = "New password and Conform password are not equal"
                return this.readdy
            }
            if (this.getallres == '1061') {
                this.readdy = "Id is required"
                return this.readdy
            }
            if (this.getallres == '1062') {
                this.readdy = "Address is required"
                return this.readdy
            }
            if (this.getallres == '1063') {
                this.readdy = "Address is required"
                return this.readdy
            }
            if (this.getallres == '1064') {
                this.readdy = "Address is required"
                return this.readdy
            }
            if (this.getallres == '1065') {
                this.readdy = "City is required"
                return this.readdy
            }

            if (this.getallres == '1066') {
                this.readdy = "State is required"
                return this.readdy
            }
            if (this.getallres == '1067') {
                this.readdy = "Country is required"
                return this.readdy
            }
            if (this.getallres == '1068') {
                this.readdy = "Postalcode is required"
                return this.readdy
            }
            if (this.getallres == '1070') {
                this.readdy = "No data available"
                return this.readdy
            }
            if (this.getallres == '1071') {
                this.readdy = "Please provide valid image format JPG_PNG_PDF_XLX_AND_XLSX"
                return this.readdy
            }
            if (this.getallres == '1072') {
                this.readdy = "Profile image is required"
                return this.readdy
            }
            if (this.getallres == '1073') {
                this.readdy = "Category id is required"
                return this.readdy
            }
            if (this.getallres == '1074') {
                this.readdy = "Subcategory id is required"
                return this.readdy
            }
            if (this.getallres == '1075') {
                this.readdy = "Price is required"
                return this.readdy
            }
            if (this.getallres == '1076') {
                this.readdy = "Quantity is required"
                return this.readdy
            }
            if (this.getallres == '1077') {
                this.readdy = "Invalid address id"
                return this.readdy
            }
            if (this.getallres == '1078') {
                this.readdy = "Invalid city or state"
                return this.readdy
            }
            if (this.getallres == '1079') {
                this.readdy = "Invalid category id"
                return this.readdy
            }

            if (this.getallres == '1080') {
                this.readdy = "Address id is required"
                return this.readdy
            }
            if (this.getallres == '1081') {
                this.readdy = "Service date is required"
                return this.readdy
            }
            if (this.getallres == '1082') {
                this.readdy = "Service time is required"
                return this.readdy
            }
            if (this.getallres == '1083') {
                this.readdy = "Payment is required"
                return this.readdy
            }
            if (this.getallres == '1084') {
                this.readdy = "Search by category is required"
                return this.readdy
            }
            if (this.getallres == '1085') {
                this.readdy = "Category name is required"
                return this.readdy
            }
            if (this.getallres == '1086') {
                this.readdy = "Invalid booking id"
                return this.readdy
            }
            if (this.getallres == '1087') {
                this.readdy = "Booking id is required"
                return this.readdy
            }
            if (this.getallres == '1088') {
                this.readdy = "Professional id is required"
                return this.readdy
            }
            if (this.getallres == '1089') {
                this.readdy = "Rating is required"
                return this.readdy
            }
            if (this.getallres == '1090') {
                this.readdy = "Description is required"
                return this.readdy
            }
            if (this.getallres == '1091') {
                this.readdy = "Postalcode should be in number only"
                return this.readdy
            }
            if (this.getallres == '1092') {
                this.readdy = "Please accept categories and subcategories"
                return this.readdy
            }

            if (this.getallres == '1093') {
                this.readdy = "Expiry date is required"
                return this.readdy
            }
            if (this.getallres == '1094') {
                this.readdy = "Purpose is required"
                return this.readdy
            }
            if (this.getallres == '1095') {
                this.readdy = "Banner image is required"
                return this.readdy
            }
            if (this.getallres == '1096') {
                this.readdy = "Status is required"
                return this.readdy
            }
            if (this.getallres == '1098') {
                this.readdy = "Image path is required"
                return this.readdy
            }
            if (this.getallres == '1099') {
                this.readdy = "Subcategory name is required"
                return this.readdy
            }
            if (this.getallres == '1100') {
                this.readdy = "type is required"
                return this.readdy
            }
            if (this.getallres == '1101') {
                this.readdy = "TicketType is required"
                return this.readdy
            }
            if (this.getallres == '1102') {
                this.readdy = "Issuse description is required"
                return this.readdy
            }
            if (this.getallres == '1103') {
                this.readdy = "Issuse description length should be 255 characters"
                return this.readdy
            }
            if (this.getallres == '1104') {
                this.readdy = "City id is required"
                return this.readdy
            }
            if (this.getallres == '1105') {
                this.readdy = "Invalid city id"
                return this.readdy
            }
            if (this.getallres == '1106') {
                this.readdy = "Category name arabic is required"
                return this.readdy
            }
            if (this.getallres == '1107') {
                this.readdy = "Subcategory name arabic is required"
                return this.readdy
            }
            if (this.getallres == '1108') {
                this.readdy = "Description arabic is required"
                return this.readdy
            }
            if (this.getallres == '1109') {
                this.readdy = "Category image is required"
                return this.readdy
            }
            if (this.getallres == '1110') {
                this.readdy = "Category banner is required"
                return this.readdy
            }
            if (this.getallres == '1111') {
                this.readdy = "Subcategory image is required"
                return this.readdy
            }
            if (this.getallres == '1112') {
                this.readdy = "Status should be accepted or rejected"
                return this.readdy
            }
            if (this.getallres == '1113') {
                this.readdy = "Invalid id"
                return this.readdy
            }
            if (this.getallres == '1114') {
                this.readdy = "Comments is required"
                return this.readdy
            }
            if (this.getallres == '1115') {
                this.readdy = "Comments length should not be more than 250 characters"
                return this.readdy
            }
            if (this.getallres == '1116') {
                this.readdy = "Invalid type"
                return this.readdy
            }
            if (this.getallres == '1117') {
                this.readdy = "Please wait for superadmin conformation"
                return this.readdy
            }
            if (this.getallres == '1118') {
                this.readdy = "Mobile number doesn't exist"
                return this.readdy
            }
            if (this.getallres == '1119') {
                this.readdy = "Account is already blocked"
                return this.readdy
            }
            if (this.getallres == '1120') {
                this.readdy = "Account is already unblock"
                return this.readdy
            }
            if (this.getallres == '1121') {
                this.readdy = "Referral code is required"
                return this.readdy
            }
            if (this.getallres == '1122') {
                this.readdy = "Invalid Referral code"
                return this.readdy
            }
            if (this.getallres == '1123') {
                this.readdy = "Area names is required"
                return this.readdy
            }
            if (this.getallres == '1124') {
                this.readdy = "Offer id is required"
                return this.readdy
            }
            if (this.getallres == '1125') {
                this.readdy = "Offer name is required"
                return this.readdy
            }
            if (this.getallres == '1126') {
                this.readdy = "Offer discount percentage is required"
                return this.readdy
            }
            if (this.getallres == '1127') {
                this.readdy = "Offer description is required"
                return this.readdy
            }
            if (this.getallres == '1128') {
                this.readdy = "Coupon code is required"
                return this.readdy
            }
            if (this.getallres == '1129') {
                this.readdy = "Minimum order value is required"
                return this.readdy
            }
            if (this.getallres == '1130') {
                this.readdy = "Maximum discount value is required"
                return this.readdy
            }
            if (this.getallres == '1131') {
                this.readdy = "Invalid offer id"
                return this.readdy
            }
            if (this.getallres == '1132') {
                this.readdy = "City name is required"
                return this.readdy
            }
            if (this.getallres == '1132') {
                this.readdy = "City name english is required"
                return this.readdy
            }
            if (this.getallres == '1133') {
                this.readdy = "City name arabic is required"
                return this.readdy
            }
            if (this.getallres == '1134') {
                this.readdy = "Country name english is required"
                return this.readdy
            }
            if (this.getallres == '1135') {
                this.readdy = "Country name arabic is required"
                return this.readdy
            }
            if (this.getallres == '1136') {
                this.readdy = "Job status is required"
                return this.readdy
            }
            if (this.getallres == '1137') {
                this.readdy = "Invalid job status"
                return this.readdy
            }
            if (this.getallres == '1138') {
                this.readdy = "Invalid booking status"
                return this.readdy
            }
            if (this.getallres == '1139') {
                this.readdy = "Invalid ticket id"
                return this.readdy
            }
            if (this.getallres == '1140') {
                this.readdy = "Ticket id is required"
                return this.readdy
            }
            if (this.getallres == '1141') {
                this.readdy = "Attachment is required"
                return this.readdy
            }
            if (this.getallres == '1142') {
                this.readdy = "Cart type is required"
                return this.readdy
            }
            if (this.getallres == '1143') {
                this.readdy = "Invalid cart type"
                return this.readdy
            }
            if (this.getallres == '1144') {
                this.readdy = "Sub category type id is required"
                return this.readdy
            }
            if (this.getallres == '1145') {
                this.readdy = "Invalid coupon code"
                return this.readdy
            }
            if (this.getallres == '1146') {
                this.readdy = "Amount is required"
                return this.readdy
            }
            if (this.getallres == '1147') {
                this.readdy = "Minimum amount for offer is required"
                return this.readdy
            }
            if (this.getallres == '1148') {
                this.readdy = "Build id is required"
                return this.readdy
            }
            if (this.getallres == '1149') {
                this.readdy = "Professional not upadated his details"
                return this.readdy
            }
            if (this.getallres == '1150') {
                this.readdy = "No jobs available"
                return this.readdy
            }
            if (this.getallres == '1152') {
                this.readdy = "Invalid build id"
                return this.readdy
            }
            if (this.getallres == '1153') {
                this.readdy = "Invalid payment type"
                return this.readdy
            }
            if (this.getallres == '1154') {
                this.readdy = "Bank account number is required"
                return this.readdy
            }
            if (this.getallres == '1155') {
                this.readdy = "Bank account name is required"
                return this.readdy
            }
            if (this.getallres == '1156') {
                this.readdy = "IBAN number is required"
                return this.readdy
            }
            if (this.getallres == '1157') {
                this.readdy = "Type should be on or off"
                return this.readdy
            }
            if (this.getallres == '1158') {
                this.readdy = "Type should be delete account"
                return this.readdy
            }
            if (this.getallres == '1159') {
                this.readdy = "Sub-category type name english is required"
                return this.readdy
            }
            if (this.getallres == '1160') {
                this.readdy = "Sub-category type name arabic is required"
                return this.readdy
            }
            if (this.getallres == '1161') {
                this.readdy = "Sub-category type description english is required"
                return this.readdy
            }
            if (this.getallres == '1162') {
                this.readdy = "Sub-category type description arabic is required"
                return this.readdy
            }
            if (this.getallres == '1163') {
                this.readdy = "Category type english is required"
                return this.readdy
            }
            if (this.getallres == '1164') {
                this.readdy = "Category type arabic is required"
                return this.readdy
            }
            if (this.getallres == '1165') {
                this.readdy = "Sub-category type image is required"
                return this.readdy
            }
            if (this.getallres == '1166') {
                this.readdy = "Sub-category type id is required"
                return this.readdy
            }
            if (this.getallres == '1167') {
                this.readdy = "Sart date is required"
                return this.readdy
            }
            if (this.getallres == '1168') {
                this.readdy = "Reschedule date is required"
                return this.readdy
            }
            if (this.getallres == '1169') {
                this.readdy = "Reschedule time is required"
                return this.readdy
            }
			if (this.getallres == '1170') {
                this.readdy = "Geolocation time is required"
                return this.readdy
            }
			if (this.getallres == '1178') {
                this.readdy = "Category name (en) is already exist"
                return this.readdy
            }
			if (this.getallres == '1179') {
                this.readdy = "Category name (ar) is already exist"
                return this.readdy
            }
			if (this.getallres == '1180') {
                this.readdy = "Sub-Category name (en) is already exist"
                return this.readdy
            }
			if (this.getallres == '1181') {
                this.readdy = "Sub-Category name (ar) is already exist"
                return this.readdy
            }
			if (this.getallres == '1182') {
                this.readdy = "Sub-Category type name (en) is already exist"
                return this.readdy
            }
			if (this.getallres == '1183') {
                this.readdy = "Sub-Category type name (ar) is already exist"
                return this.readdy
            }
            if (this.getallres == '1231') {
                this.readdy = "Please contact support@mrmusllah.com for more than 100mb size"
                return this.readdy
            }
            if (this.getallres == '1233') {
                this.readdy = "Document name is already exist"
                return this.readdy
            }
        } else if (this.chooselanguage == "ar") {
            if (this.getallres == '1233') {
                this.readdy = "اسم المستند موجود بالفعل"
                return this.readdy
            }
            if (this.getallres == '1231') {
                this.readdy = "يرجى التواصل مع support@mrmusllah.com للحصول على حجم يزيد عن 100 ميغا بايت"
                return this.readdy
            }
            if (this.getallres == '1001') {
                this.readdy = "رقم الهاتف الجوال مطلوب"
                return this.readdy
            }
            if (this.getallres == '1002') {
                this.readdy = "البريد الالكتروني مطلوب"
                return this.readdy
            }
            if (this.getallres == '1003') {
                this.readdy = "الإسم الأول مطلوب"
                return this.readdy
            }
            if (this.getallres == '1004') {
                this.readdy = "إسم الاخير مطلوب"
                return this.readdy
            }
            if (this.getallres == '1006') {
                this.readdy = "فشل"
                return this.readdy
            }
            if (this.getallres == '1007') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1009') {
                this.readdy = " يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1010') {
                this.readdy = "يرجى المحاولة مرة أخرى بعد 30 دقيقة أو ارسال بريد support@mrmusllah.com"
                return this.readdy
            }
            if (this.getallres == '1011') {
                this.readdy = "رقم الهاتف الجوال أو كلمة المرور غير صحيحة"
                return this.readdy
            }
            if (this.getallres == '1012') {
                this.readdy = "رقم الهاتف الجوال أو كلمة المرور غير صحيحة"
                return this.readdy
            }
            if (this.getallres == '1013') {
                this.readdy = "تم إرسال OTP إلى البريد الإلكتروني المسجل"
                return this.readdy
            }
            if (this.getallres == '1014') {
                this.readdy = "OTP غير صالح"
                return this.readdy
            }
            if (this.getallres == '1015') {
                this.readdy = "OTP غير صالح"
                return this.readdy
            }
            if (this.getallres == '1016') {
                this.readdy = "مطلوب OTP"
                return this.readdy
            }
            if (this.getallres == '1017') {
                this.readdy = "مطلوب OTP"
                return this.readdy
            }
            if (this.getallres == '1018') {
                this.readdy = "الرجاء إدخال رقم الهاتف الجوال الصحيح"
                return this.readdy
            }
            if (this.getallres == '1019') {
                this.readdy = "الرجاء إدخال البريد إلكتروني الصحيح"
                return this.readdy
            }
            if (this.getallres == '1020') {
                this.readdy = "الرجاء إدخال الاسم الأول"
                return this.readdy
            }
            if (this.getallres == '1021') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1022') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1023') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1024') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1025') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!!"
                return this.readdy
            }
            if (this.getallres == '1026') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1027') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1028') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1029') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1030') {
                this.readdy = "كلمة السر مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1031') {
                this.readdy = "يجب أن تحتوي كلمة السر على حرف كبير واحد وحرف صغير واحد وحرف خاص واحد"
                return this.readdy
            }
            if (this.getallres == '1032') {
                this.readdy = " يجب أن يكون طول كلمة السر ما بين 8-20"
                return this.readdy
            }
            if (this.getallres == '1034') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1035') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1036') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1037') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1038') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1039') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1040') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1041') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1042') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1043') {
                this.readdy = "يبدو أن خوادمنا مشغولة! الرجاء معاودة المحاولة في وقت لاحق!"
                return this.readdy
            }
            if (this.getallres == '1044') {
                this.readdy = "مطلوب OTP"
                return this.readdy
            }
            if (this.getallres == '1045') {
                this.readdy = "يجب أن يتكون (OTP) من 4 أرقام"
                return this.readdy
            }
            if (this.getallres == '1046') {
                this.readdy = "رقم الهاتف الجوال مسجل مسبقا"
                return this.readdy
            }
            if (this.getallres == '1047') {
                this.readdy = "البريد الإلكتروني مسجل مسبقا"
                return this.readdy
            }
            if (this.getallres == '1048') {
                this.readdy = "تم التسجيل بنجاح ، من فضلك انتطر تأكيد المسؤول"
                return this.readdy
            }
            if (this.getallres == '1049') {
                this.readdy = "نوع العميل مطلوب"
                return this.readdy
            }
            if (this.getallres == '1050') {
                this.readdy = "لا يسمح بالتسجيلات المتعددة من نفس الجوال"
                return this.readdy
            }
            if (this.getallres == '1051') {
                this.readdy = "رمز الدولة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1052') {
                this.readdy = "كلمة السر القديمة مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1053') {
                this.readdy = "كلمة السر الجديدة مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1054') {
                this.readdy = "تأكيد كلمة السر مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1055') {
                this.readdy = "الاسم مطلوب"
                return this.readdy
            }
            if (this.getallres == '1056') {
                this.readdy = "كلمة السر قديمة غير صحيحة"
                return this.readdy
            }
            if (this.getallres == '1057') {
                this.readdy = "يرجى انتظار تاكيد المسؤول"
                return this.readdy
            }
            if (this.getallres == '1058') {
                this.readdy = "النوع مطلوب"
                return this.readdy
            }
            if (this.getallres == '1060') {
                this.readdy = "كلمة السر الجديدة وتأكيد كلمة السر غير مطابقة"
                return this.readdy
            }
            if (this.getallres == '1061') {
                this.readdy = "بطاقة الهوية مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1062') {
                this.readdy = "العنوان مطلوب"
                return this.readdy
            }
            if (this.getallres == '1063') {
                this.readdy = "العنوان مطلوب"
                return this.readdy
            }
            if (this.getallres == '1064') {
                this.readdy = "العنوان مطلوب"
                return this.readdy
            }
            if (this.getallres == '1065') {
                this.readdy = "المدينة مطلوبة"
                return this.readdy
            }

            if (this.getallres == '1066') {
                this.readdy = "المنطقة / الولاية مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1067') {
                this.readdy = "الدولة مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1068') {
                this.readdy = "الرمز البريدي مطلوب"
                return this.readdy
            }
            if (this.getallres == '1070') {
                this.readdy = "لا تتوافر بيانات"
                return this.readdy
            }
            if (this.getallres == '1071') {
                this.readdy = "يرجى تحميل صورة من النوع JPG_PNG_PDF_XLX_AND_XLSX"
                return this.readdy
            }
            if (this.getallres == '1072') {
                this.readdy = "صورة الملف الشخصي مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1073') {
                this.readdy = "نوع الفئة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1074') {
                this.readdy = "نوع الفئة الفرعية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1075') {
                this.readdy = "السعر مطلوب"
                return this.readdy
            }
            if (this.getallres == '1076') {
                this.readdy = "الكمية مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1077') {
                this.readdy = "العنوان غير صالح"
                return this.readdy
            }
            if (this.getallres == '1078') {
                this.readdy = "مدينة أو منطقة / ولاية غير صحيحة"
                return this.readdy
            }
            if (this.getallres == '1079') {
                this.readdy = "نوع الفئة غير صالح"
                return this.readdy
            }

            if (this.getallres == '1080') {
                this.readdy = "العنوان مطلوب"
                return this.readdy
            }
            if (this.getallres == '1081') {
                this.readdy = "تاريخ الخدمة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1082') {
                this.readdy = "وقت الخدمة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1083') {
                this.readdy = "الدفع مطلوب"
                return this.readdy
            }
            if (this.getallres == '1084') {
                this.readdy = "البحث حسب الفئة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1085') {
                this.readdy = "اسم الفئة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1086') {
                this.readdy = "نوع الحجز غير صالح"
                return this.readdy
            }
            if (this.getallres == '1087') {
                this.readdy = "نوع الحجز مطلوب"
                return this.readdy
            }
            if (this.getallres == '1088') {
                this.readdy = "نوع المهنة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1089') {
                this.readdy = "التصنيف مطلوب"
                return this.readdy
            }
            if (this.getallres == '1090') {
                this.readdy = "الوصف مطلوب"
                return this.readdy
            }
            if (this.getallres == '1091') {
                this.readdy = "يجب أن يكون الرمز البريدي من الارقم فقط"
                return this.readdy
            }
            if (this.getallres == '1092') {
                this.readdy = "الرجاء قبول الفئات والفئات الفرعية"
                return this.readdy
            }

            if (this.getallres == '1093') {
                this.readdy = "تاريخ الانتهاء  مطلوب"
                return this.readdy
            }
            if (this.getallres == '1094') {
                this.readdy = "الغرض مطلوب"
                return this.readdy
            }
            if (this.getallres == '1095') {
                this.readdy = "صورة الاعلان مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1096') {
                this.readdy = "الحالة مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1098') {
                this.readdy = "مسار الصورة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1099') {
                this.readdy = "اسم الفئة الفرعية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1100') {
                this.readdy = "النوع مطلوب"
                return this.readdy
            }
            if (this.getallres == '1101') {
                this.readdy = "نوع التذكرة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1102') {
                this.readdy = "وصف المشكلة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1103') {
                this.readdy = "يجب أن يكون طول وصف المشكلة 255 حرفًا"
                return this.readdy
            }
            if (this.getallres == '1104') {
                this.readdy = "المدينة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1105') {
                this.readdy = "المدينة غير صحيحة"
                return this.readdy
            }
            if (this.getallres == '1106') {
                this.readdy = "اسم الفئة العربية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1107') {
                this.readdy = "اسم الفئة الفرعية العربية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1108') {
                this.readdy = "الوصف مطلوب"
                return this.readdy
            }
            if (this.getallres == '1109') {
                this.readdy = "صورة الفئة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1110') {
                this.readdy = "إعلان الفئة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1111') {
                this.readdy = "صورة الفئة الفرعية مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1112') {
                this.readdy = "يجب قبول أو رفض الحالة"
                return this.readdy
            }
            if (this.getallres == '1113') {
                this.readdy = "بطاقة الهوية غير صالحة"
                return this.readdy
            }
            if (this.getallres == '1114') {
                this.readdy = "التعليقات مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1115') {
                this.readdy = "يجب ألا يزيد التعليقات عن 250 حرفًا"
                return this.readdy
            }
            if (this.getallres == '1116') {
                this.readdy = "نوع غير صالح"
                return this.readdy
            }
            if (this.getallres == '1117') {
                this.readdy = "يرجى انتظار تأكيد المشرف المتميز"
                return this.readdy
            }
            if (this.getallres == '1118') {
                this.readdy = "رقم الجوال غير موجود"
                return this.readdy
            }
            if (this.getallres == '1119') {
                this.readdy = "الحساب محظور بالفعل"
                return this.readdy
            }
            if (this.getallres == '1120') {
                this.readdy = "تم إلغاء حظر الحساب"
                return this.readdy
            }
            if (this.getallres == '1121') {
                this.readdy = "كود الإحالة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1122') {
                this.readdy = "رمز الإحالة غير صالح"
                return this.readdy
            }
            if (this.getallres == '1123') {
                this.readdy = "أسماء المناطق مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1124') {
                this.readdy = "نوع العرض مطلوب"
                return this.readdy
            }
            if (this.getallres == '1125') {
                this.readdy = "اسم العرض مطلوب"
                return this.readdy
            }
            if (this.getallres == '1126') {
                this.readdy = "نسبة الخصم على العرض مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1127') {
                this.readdy = "وصف العرض مطلوب"
                return this.readdy
            }
            if (this.getallres == '1128') {
                this.readdy = "رمز الكوبون مطلوب"
                return this.readdy
            }
            if (this.getallres == '1129') {
                this.readdy = "الحد الأدنى لقيمة الطلب مطلوب"
                return this.readdy
            }
            if (this.getallres == '1130') {
                this.readdy = "الحد الأقصى لقيمة الخصم مطلوب"
                return this.readdy
            }
            if (this.getallres == '1131') {
                this.readdy = "العرض غير صالح"
                return this.readdy
            }
            if (this.getallres == '1132') {
                this.readdy = "اسم المدينة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1132') {
                this.readdy = "مطلوب اسم المدينة بالإنجليزية"
                return this.readdy
            }
            if (this.getallres == '1133') {
                this.readdy = "مطلوب اسم المدينة بالعربية"
                return this.readdy
            }
            if (this.getallres == '1134') {
                this.readdy = "مطلوب اسم الدولة بالإنجليزية"
                return this.readdy
            }
            if (this.getallres == '1135') {
                this.readdy = "مطلوب اسم الدولة بالعربية"
                return this.readdy
            }
            if (this.getallres == '1136') {
                this.readdy = "حالة الوظيفة مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1137') {
                this.readdy = "حالة الوظيفة غير صالحة"
                return this.readdy
            }
            if (this.getallres == '1138') {
                this.readdy = "حالة الحجز غير صالحة"
                return this.readdy
            }
            if (this.getallres == '1139') {
                this.readdy = "نوع تذكرة غير صالح"
                return this.readdy
            }
            if (this.getallres == '1140') {
                this.readdy = "نوع التذكرة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1141') {
                this.readdy = "المرفقات مطلوب"
                return this.readdy
            }
            if (this.getallres == '1142') {
                this.readdy = "نوع السيارة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1143') {
                this.readdy = "نوع سلة التسوق غير صالح"
                return this.readdy
            }
            if (this.getallres == '1144') {
                this.readdy = "نوع الفئة الفرعية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1145') {
                this.readdy = "رمز الكوبون غير صالح"
                return this.readdy
            }
            if (this.getallres == '1146') {
                this.readdy = "المبلغ مطلوب"
                return this.readdy
            }
            if (this.getallres == '1147') {
                this.readdy = "المبلغ الأدنى للعرض مطلوب"
                return this.readdy
            }
            if (this.getallres == '1148') {
                this.readdy = "نوع البناء مطلوب"
                return this.readdy
            }
            if (this.getallres == '1149') {
                this.readdy = "لم يقوم المهني بتحديث تفاصيله"
                return this.readdy
            }
            if (this.getallres == '1150') {
                this.readdy = "لا توجد وظائف متاحة"
                return this.readdy
            }
            if (this.getallres == '1152') {
                this.readdy = "نوع بناء غير صالح"
                return this.readdy
            }
            if (this.getallres == '1153') {
                this.readdy = "نوع الدفع غير صالح"
                return this.readdy
            }
            if (this.getallres == '1154') {
                this.readdy = "رقم الحساب المصرفي مطلوب"
                return this.readdy
            }
            if (this.getallres == '1155') {
                this.readdy = "اسم الحساب المصرفي مطلوب"
                return this.readdy
            }
            if (this.getallres == '1156') {
                this.readdy = "رقم الآيبان مطلوب"
                return this.readdy
            }
            if (this.getallres == '1157') {
                this.readdy = "يجب أن يكون النوع في وضع التشغيل أو الإيقاف"
                return this.readdy
            }
            if (this.getallres == '1158') {
                this.readdy = "يجب أن يكون النوع حذف الحساب"
                return this.readdy
            }
            if (this.getallres == '1159') {
                this.readdy = "مطلوب اسم نوع الفئة الفرعية بالإنجليزية"
                return this.readdy
            }
            if (this.getallres == '1160') {
                this.readdy = "اسم نوع الفئة الفرعية بالعربية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1161') {
                this.readdy = "مطلوب وصف نوع الفئة الفرعية باللغة الإنجليزية"
                return this.readdy
            }
            if (this.getallres == '1162') {
                this.readdy = "نوع الفئة الفرعية باللغة العربية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1163') {
                this.readdy = "نوع الفئة بالإنجليزية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1164') {
                this.readdy = "نوع الفئة بالعربية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1165') {
                this.readdy = "صورة نوع الفئة الفرعية مطلوبة"
                return this.readdy
            }
            if (this.getallres == '1166') {
                this.readdy = "نوع الفئة الفرعية مطلوب"
                return this.readdy
            }
            if (this.getallres == '1167') {
                this.readdy = "تاريخ البدء مطلوب"
                return this.readdy
            }
            if (this.getallres == '1168') {
                this.readdy = "تاريخ إعادة الجدولة مطلوب"
                return this.readdy
            }
            if (this.getallres == '1169') {
                this.readdy = "وقت إعادة الجدولة مطلوب"
                return this.readdy
            }
			if (this.getallres == '1170') {
                this.readdy = "وقت تحديد الموقع الجغرافي مطلوب"
                return this.readdy
            }
			if (this.getallres == '1178') {
                this.readdy = "اسم الفئة (en) موجود بالفعل"
                return this.readdy
            }
			if (this.getallres == '1179') {
                this.readdy = "اسم الفئة (ar) موجود بالفعل"
                return this.readdy
            }
			if (this.getallres == '1180') {
                this.readdy = "اسم الفئة الفرعية (en) موجود بالفعل"
                return this.readdy
            }
			if (this.getallres == '1181') {
                this.readdy = "اسم الفئة الفرعية (ar) موجود بالفعل"
                return this.readdy
            }
			if (this.getallres == '1182') {
                this.readdy = "اسم نوع الفئة الفرعية (en) موجود بالفعل"
                return this.readdy
            }
			if (this.getallres == '1183') {
                this.readdy = "اسم نوع الفئة الفرعية (ar) موجود بالفعل"
                return this.readdy
            }
        }
    }

}