import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AllinoneService } from './allinone.service';
const baseUrl = `${environment.baseUrl}/v1`;

@Injectable({
  providedIn: 'root'
})
export class SuperadminService 
{
    data:any;
    constructor(private httpClient: HttpClient, private details:AllinoneService,private router:Router,private ngxLoader: NgxUiLoaderService){}

    GetList():Observable<any> {
        const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + (this.details.accesstoken)
            })
          }
          return this.httpClient.post<any>(baseUrl+'/checker/getPendingList',this.details.getResponse(),httpOptions).pipe(retry(2),catchError((err) => {
            this.ngxLoader.stop();
            this.router.navigate(['/error'])
            console.error(err);
            return throwError(err);
          }));
        }

        updateList(keys):Observable<any> {
          const keys2 = Object.assign({}, keys, this.details.getResponse());
          const httpOptions = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + (this.details.accesstoken)
              })
            }
            return this.httpClient.post<any>(baseUrl+'/checker/acceptOrReject',keys2,httpOptions).pipe(retry(2),catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(['/error'])
              console.error(err);
              return throwError(err);
            }));
          }

      
}