import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable, throwError } from 'rxjs';
import { catchError, retry, timeout } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
import { AllinoneService } from './allinone.service';
const baseUrl = `${environment.baseUrl}/v1`;

@Injectable({
  providedIn: 'root'
})
export class LoginService 
{
  data:any;

    constructor(private httpClient: HttpClient, private details:AllinoneService,private router:Router,private ngxLoader: NgxUiLoaderService){}

      useremaillogin(keys:any, Email:any ,password:any):Observable<any> {
        const keys2 = Object.assign({}, keys, this.details.getResponse());
        let authorizationData = 'Basic ' + btoa(Email + ':' + password);
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': authorizationData
          })
        }
          return this.httpClient.post<any>(baseUrl+'/support/login/cred',keys2,httpOptions).pipe(timeout(6000),
            retry(2),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/error"]);
              console.error(err);
              return throwError(err);
            })
          );
        }


        usersession()
        {
         this.details.nextMessage("default message")
          console.log('1')
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          if(this.data=="en"){
            Toast.fire({
              icon: 'warning',
              html: `<div class="text-center">Your session has expired</div>`
            })
          }
          else if(this.data=="ar"){
            Toast.fire({
              icon: 'warning',
              html: `<div class="text-right" dir="rtl">انتهت صلاحية جلسة العمل الخاصة بك</div>`
            })
          }
            this.ngxLoader.stop();
            this.details.showmenu = false;
            this.details.showmenu1 = false;
            this.details.showmenu2 = false;
            this.router.navigate(['/login'])
        }

        usersession5()
        {
          console.log('9')
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
          
          
          if(this.data=="en"){
            Toast.fire({
              icon: 'warning',
              html: `Someone has login with your credentials`
            })
          }
          else if(this.data=="ar"){
            Toast.fire({
              icon: 'warning',
              html: `<div class="text-right" dir="rtl">شخص ما قام بتسجيل الدخول إلى حسابك</div>`
            })
          }
            this.details.nextMessage("default message")
            this.ngxLoader.stop();
            this.details.showmenu = false;
            this.details.showmenu1 = false;
            this.details.showmenu2 = false;
            this.router.navigate(['/login'])
        }

      usersession2()
        {
          setTimeout(() => {
            this.details.nextMessage("default message")
          },1000)
          console.log('21')
            const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 3000,
              timerProgressBar: true,
              didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
              }
            })
            
              if(this.details.chooselanguage=="en"){
            Toast.fire({
              icon: 'success',
              html: `sucessfully logout`
            })
          }
          else if(this.details.chooselanguage=="ar"){
            Toast.fire({
              icon: 'success',
              html: `<div class="text-right" dir="rtl">تسجيل الخروج بنجاح</div>`
            })
          }
          
          this.ngxLoader.stop();
          this.details.showmenu = false;
          this.details.showmenu1 = false;
          this.details.showmenu2 = false;
          this.router.navigate(['/login'])
          }

          usersession8()
          {
              this.details.nextMessage("default message")
              this.ngxLoader.stop();
              this.details.showmenu = false;
              this.details.showmenu1 = false;
              this.details.showmenu2 = false;
              this.router.navigate(['/login'])
          }

        
}