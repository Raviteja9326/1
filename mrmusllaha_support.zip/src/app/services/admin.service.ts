import {
  HttpClient,
  HttpHeaders,
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { NgxUiLoaderService } from "ngx-ui-loader";
import { Observable, throwError } from "rxjs";
import { catchError, retry, timeout } from "rxjs/operators";
import { environment } from "src/environments/environment";
import { AllinoneService } from "./allinone.service";
const baseUrl = `${environment.baseUrl}/v1`;

@Injectable({
  providedIn: "root",
})
export class AdminService {
  constructor(
    private httpClient: HttpClient,
    private details: AllinoneService,
    private router: Router,
    private ngxLoader: NgxUiLoaderService
  ) {}

  GetBannersList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  Bannersdelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

 documentdelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/deleteProDoc", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  videodelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/deleteVideo", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  cateorysubtydelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/deletecatsubcattype", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  GetCategoriesList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/getcatsubcattypeslist", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  Gettraningvideos(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/getTrainingVideos", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }


  addbanners(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addBanner", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  adddocument(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addProDoc", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  upddocument(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updateProDoc", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addvideo(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addVideo", keys, httpOptions)
     .pipe(timeout(200000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updatebanners(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatebanner", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  block(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  unblock(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  getprofessionals(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  getprofessionalsdocuments(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/getProDocs", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updateprofessionals(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  getoffers(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updateoffers(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updateoffer", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  deleteoffers(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addoffers(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addoffer", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updcat(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updateCategory", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addcattyp(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addSubCategoryType", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addcattyp2(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updateSubCategoryType", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addcat(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addCategory", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addsubcat(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/addSubCategory", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  upsubcat(keys: any): Observable<any> {
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updateSubCategory", keys, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  getcities(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updatecities(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updatepwd(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/updatepassword", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  deletecities(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  addcities(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  professionalpending(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  professionalaccept(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  professionalreject(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  support(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  getbookinguserprofessional(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  getbookingstatus(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updatebookingstatus(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  updatesupportstatus(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/updatedelete", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }

  

  GetallList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    console.log(this.details.accesstoken);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.details.accesstoken,
      }),
    };
    return this.httpClient
      .post<any>(baseUrl + "/maker/get", obj2, httpOptions)
     .pipe(timeout(30000),
            retry(3),
            catchError((err) => {
              this.ngxLoader.stop();
              this.router.navigate(["/errors"]);
              console.error(err);
              return throwError(err);
            })
          );
  }
}
