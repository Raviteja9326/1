import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MasteradminComponent } from './masteradmin.component';
import { MasteradminRoutingModule } from './masteradmin-routing.module';


const components = [MasteradminComponent];


@NgModule({
  declarations: [ ...components],
  imports: [CommonModule,MasteradminRoutingModule]
})
export class MasteradminModule { }
