import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasteradminComponent } from './masteradmin.component';


const masteradminroutes: Routes = [{
    path: '',
    component: MasteradminComponent,
    children: [],
        
},

];

@NgModule({
    imports: [RouterModule.forChild(masteradminroutes)],
    exports: [RouterModule],
})
export class MasteradminRoutingModule { }
