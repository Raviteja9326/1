import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-masteradmin',
  template: `<router-outlet></router-outlet>`
})
export class MasteradminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
