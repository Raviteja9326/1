const express = require('express');
const connection = require('../dao/MySQLConnect');
var { checkMobile, checkEmail, checkUser } = express.Router();


var checkMobile = (req, res, next) => {

    var dataToCheck = [req.body.PhoneNo];
    var sql = "SELECT count(*) totalCount from TblUser WHERE PhoneNo=? AND isDeleted=1"
    connection.query(sql, dataToCheck, function (err, result) {
        if (result[0].totalCount == 0) {
            next();
        }
        else {

            res.json({ 'message': 'MobileNumber Already exists' });
        }
    });

}


var checkEmail = (req, res, next) => {
    var dataToCheck1 = [req.body.Email,];
    var sql1 = "SELECT count(*) totalCount from TblUser WHERE Email=? AND isDeleted=1"
    connection.query(sql1, dataToCheck1, function (err, result) {
        if (result[0].totalCount == 0) {
            next();
        } else {
            res.json({ 'message': 'Email Already exists' });
        }
    });
}


var checkUser = (req, res, next) => {

    var dataToCheck2 = [req.body.UserName,];
    var sql2 = "SELECT count(*) totalCount from TblUser WHERE UserName=? AND isDeleted=1"
    connection.query(sql2, dataToCheck2, function (err, result) {
        if (result[0].totalCount == 0) {
            next();
        } else {
            res.json({ 'message': 'UserName Already exists' });
        }
    });
}



module.exports = { checkMobile, checkEmail, checkUser } 