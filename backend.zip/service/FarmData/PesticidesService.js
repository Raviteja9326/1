var PesticidesDAO = require("../../dao/FarmData/PesticidesDAO")
//for get 
function PesticidesService() {
  this.getAllpesticides = function (req, res) {
    return PesticidesDAO.getAllpesticides(req, res);
  }

  //for get id
  this.getpesticidesId = function (Id, res) {
    // console.log("testing in service", Id);
    return PesticidesDAO.getpesticidesId(Id, res);
  };

  //for post
  this.createpesticides = function (req, res) {
    PesticidesDAO.checkpesticidesExists(req.body.PestName)
      .then(() => {
        return PesticidesDAO.createpesticides(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "PesticideName  already exists with same name!. Plz enter a different PesticideName " });
      });
  };
  //for update

  this.updateById = function (req, pesticidesId, res) {
    // console.log("im from service", pesticidesId);
    PesticidesDAO.checkpesticidesExists(req.body.PestName)
      .then(() => {
        return PesticidesDAO.updateById(req, pesticidesId, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "PestName already exists with same breed!. Plz enter a different PestName " });
      });

  };

  //for delete
  this.deleteById = function (pesticidesId, res) {
    // console.log("im from service", pesticidesId);
    return PesticidesDAO.deleteById(pesticidesId, res);
  };
}

module.exports = new PesticidesService();