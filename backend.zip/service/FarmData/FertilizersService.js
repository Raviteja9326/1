var FertilizerDAO = require("../../dao/FarmData/FertilizerDAO")
//for get 
function FertilizerService() {
  this.getAllfertilizers = function (req, res) {
    return FertilizerDAO.getAllfertilizers(req, res);
  }

  //for get id
  this.getfertilizersId = function (Id, res) {
    // console.log("testing in service", Id);
    return FertilizerDAO.getfertilizersId(Id, res);
  };

  //for post
  this.createfertilizers = function (req, res) {
    FertilizerDAO.checkfertilizerExists(req.body.FertilizerName)
      .then(() => {
        return FertilizerDAO.createfertilizers(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "FertilizerName  already exists with same name!. Plz enter a different FertilizerName " });
      });
  };
  //for update

  this.updateById = function (req, fertilizersId, res) {

    FertilizerDAO.checkfertilizerExists(req.body.FertilizerName)
      .then(() => {
        return FertilizerDAO.updateById(req, fertilizersId, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "FertilizerName already exists with same breed!. Plz enter a different FertilizerName " });
      });

  };

  //for delete
  this.deleteById = function (fertilizersId, res) {
    // console.log("im from service", fertilizersId);
    return FertilizerDAO.deleteById(fertilizersId, res);
  };
}

module.exports = new FertilizerService();