var CompanyMasterDAO = require("../../dao/FarmData/CompanyMasterDAO")
//for get 
function CompanyMasterService() {
  this.getAllcompanymaster = function (req, res) {
    return CompanyMasterDAO.getAllcompanymaster(req, res);
  }

  //for get id
  this.getcompanymasterId = function (Id, res) {
    // console.log("testing in service", Id);
    return CompanyMasterDAO.getcompanymasterId(Id, res);
  };

  this.createcompanymaster = function (req, res) {
    return CompanyMasterDAO.createcompanymaster(req, res);
  };
  this.updateById = function (req, companymasterId, res) {
    return CompanyMasterDAO.updateById(req, companymasterId, res);
  }

  this.deleteById = function (companymasterId, res) {
    return CompanyMasterDAO.deleteById(companymasterId, res);
  }

}

module.exports = new CompanyMasterService();