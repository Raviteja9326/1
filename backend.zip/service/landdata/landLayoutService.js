var landLayoutDAO = require("../../dao/landdata/landLayoutDAO")
//for get 
function landLayoutService() {
    this.getAlllandLayout = function (req, res) {
        return landLayoutDAO.getAlllandLayout(req, res);
    }
    //for get id
    this.getlandLayoutById = function (landlayoutId, res) {
        // console.log("testing in service", landlayoutId);
        return landLayoutDAO.getlandLayoutById(landlayoutId, res);
    };

    this.getlandlayoutByFarmerId = function (FarmerId, res) {
        return landLayoutDAO.getlandlayoutByFarmerId(FarmerId, res);

    }


    //for post
    this.createlandLayout = function (req, res) {
        // console.log("testing body", req);
        return landLayoutDAO.createlandLayout(req, res);
    };

    //for update

    this.updatelandLayoutById = function (req, landlayoutId, res) {
        return landLayoutDAO.updatelandLayoutById(req, landlayoutId, res);
    };

    //for delete
    this.deletelandLayoutById = function (landlayoutId, res) {
        return landLayoutDAO.deletelandLayoutById(landlayoutId, res);
    };


}

module.exports = new landLayoutService();