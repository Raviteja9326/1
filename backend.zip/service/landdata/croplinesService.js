var croplinesDAO = require("../../dao/landdata/croplinesDAO")
//for get 
function croplinesService() {
    this.getAllcroplines = function (req, res) {
        return croplinesDAO.getAllcroplines(req, res);
    }
    //for get id
    this.getcroplinesById = function (croplinesId, res) {
        // console.log("testing in service", croplinesId);
        return croplinesDAO.getcroplinesById(croplinesId, res);
    };

    this.getcroplinesByLandId = function (landId, res) {
        return croplinesDAO.getcroplinesByLandId(landId, res);
    }

    this.getcroplinesByPlottingId = function (plottingID, res) {
        return croplinesDAO.getcroplinesByPlottingId(plottingID, res);
    }


    //for post
    this.createcroplines = function (req, res) {
        // console.log("testing body", req);
        return croplinesDAO.createcroplines(req, res);
    };

    //for update

    this.updatecroplinesById = function (req, croplinesId, res) {
        return croplinesDAO.updatecroplinesById(req, croplinesId, res);
    };

    //for delete
    this.deletecroplinesById = function (croplinesId, res) {
        return croplinesDAO.deletecroplinesById(croplinesId, res);
    };


}

module.exports = new croplinesService();