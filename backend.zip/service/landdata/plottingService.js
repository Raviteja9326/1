var plottingDAO = require("../../dao/landdata/PlotingDAO")
//for get 
function plottingService() {
    this.getAllplotting = function (req, res) {
        return plottingDAO.getAllplotting(req, res);
    }
    //for get id
    this.getplottingById = function (plottingId, res) {
        // console.log("testing in service", plottingId);
        return plottingDAO.getplottingById(plottingId, res);
    };

    this.getplottingByLandId = function (LandId, res) {
        return plottingDAO.getplottingByLandId(LandId, res);

    }


    //for post
    this.createplotting = function (req, res) {
        // console.log("testing body", req);
        return plottingDAO.createplotting(req, res);
    };

    //for update

    this.updateplottingById = function (req, plottingId, res) {
        return plottingDAO.updateplottingById(req, plottingId, res);
    };

    //for delete
    this.deleteplottingById = function (plottingId, res) {
        return plottingDAO.deleteplottingById(plottingId, res);
    };


}

module.exports = new plottingService();