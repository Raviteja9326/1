var ConsultExpertDAO = require("../../dao/consultexpert/ConsultExpertDAO")
//for get 
function ConsultExpertService() {
  this.getAllconsultExpert = function (req, res) {
    return ConsultExpertDAO.getAllconsultExpert(req, res);
  }

  //for get id
  this.getConsultExpertId = function (Id, res) {

    return ConsultExpertDAO.getConsultExpertId(Id, res);
  };

  //for post
  this.createconsultExpert = function (req, res) {
    return ConsultExpertDAO.createconsultExpert(req, res);
  };
  //for update

  this.updateById = function (consultexpertId, res) {
    return ConsultExpertDAO.updateById(consultexpertId, res);
  };

  //for delete
  this.deleteById = function (consultexpertId, res) {

    return ConsultExpertDAO.deleteById(consultexpertId, res);
  };
}

module.exports = new ConsultExpertService();