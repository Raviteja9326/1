var correctionFollowUpServiceDAO = require("../../dao/consultexpert/CorrectionfollowupDAO");


function correctionfollowupService() {
    //for get
    this.getAllCorrectionFollowUp = function (req, res) {
        return correctionFollowUpServiceDAO.getAllCorrectionFollowUp(req, res);

    }
    //for get id
    this.getAllCorrectionFollowUpById = function (correctionfollowupID, res) {
        console.log("testing in service", correctionfollowupId);
        return correctionfollowupDAO.getAllCorrectionFollowUpById(correctionfollowupId, res);

    };

    //for post
    this.createcorrectionFollowUp = function (req, res) {
        console.log("testing body", req.body.Name);
        CorrectionFollowUpDAO.checkCorrectionFollowUpExists(req.body.Name)
            .then(() => {
                return CorrectionFollowUpDAO.createCorrectionFollowUp(req, res)
            })

    }
















}







module.exports = new correctionfollowupService();