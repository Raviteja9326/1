var CropCopRawmaterialDAO = require("../../dao/Cropdata/CropCopRawmaterialDAO")
//for get 
function CropCopRawmaterialService() {
  this.getAllCropCOPRawmaterial = function (req, res) {
    console.log("in  route, Id ", req.params.cropcoprawmaterlId);
    return CropCopRawmaterialDAO.getAllCropCOPRawmaterial(req, res);
  }

  //for get id
  this.getCropCOPRawmaterialById = function (TblCropCOP_ID, res) {
    console.log("testing in service", TblCropCOP_ID);
    return CropCopRawmaterialDAO.getCropCOPRawmaterialById(TblCropCOP_ID, res);
  };

  //for post
  this.createCropCOPRawmaterial = function (req, res) {
    return CropCopRawmaterialDAO.createCropCOPRawmaterial(req, res);
  };


  //for update

  this.updateCropCOPRawmaterial = function (req, cropcoprawmaterlId, res) {
    console.log("im from service", cropcoprawmaterlId);
    return CropCopRawmaterialDAO.updateCropCOPRawmaterial(req, cropcoprawmaterlId, res);
  };

  //for delete
  this.removeCropCOPRawmaterial = function (cropcoprawmaterlId, res) {
    return CropCopRawmaterialDAO.removeCropCOPRawmaterial(cropcoprawmaterlId, res);
  };

}



module.exports = new CropCopRawmaterialService();