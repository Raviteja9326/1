var cropCategoryDAO = require('../../dao/Cropdata/CropCategoryDAO');

function CropCategoryService() {
    this.getAllCropCategories = function (req, res) {
        return cropCategoryDAO.getAllCropCategories(req, res);
    }
    this.getCropCategoryById = function (cropcatId, res) {
        return cropCategoryDAO.getCropCategoryById(cropcatId, res);
    }
    this.createCropCategory = function (req, res) {
        cropCategoryDAO.checkCropCategoryExists(req.body.CropCatName)
            .then(() => {
                return cropCategoryDAO.createCropCategory(req, res);
            })
            .catch(() => {
                res.json({ serverErrorCropCategoryExistence: "Category already exists with same name!. Plz enter a different name" });
            });
    }
    this.updateCropCategory = function (cropcatId, req, res) {
        return cropCategoryDAO.updateCropCategory(cropcatId, req, res);
    }
    this.removeCropCategory = function (cropcatId, res) {
        return cropCategoryDAO.removeCropCategory(cropcatId, res);
    }
}
module.exports = new CropCategoryService();