var cropCOPDAO = require('../../dao/Cropdata/CropCOPDAO');

function CropCOPService() {
    this.getAllCropCOP = function (req, res) {
        return cropCOPDAO.getAllCropCOP(req, res);
    }
    this.getCropCOPById = function (cropcopId, res) {
        return cropCOPDAO.getCropCOPById(cropcopId, res);
    }
    this.createCropCOP = function (req, res) {
        return cropCOPDAO.createCropCOP(req, res);
    }
    this.updateCropCOP = function (req, cropcopId, res) {
        return cropCOPDAO.updateCropCOP(req, cropcopId, res);
    }
    this.removeCropCOP = function (cropcopId, res) {
        return cropCOPDAO.removeCropCOP(cropcopId, res);
    }
}

module.exports = new CropCOPService();