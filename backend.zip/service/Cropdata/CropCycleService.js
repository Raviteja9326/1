var cropCycleDAO = require('../../dao/Cropdata/CropCycleDAO');

function CropcCycleService() {
    this.getAllCropCycles = function (req, res) {
        return cropCycleDAO.getAllCropCycles(req, res);
    }
    this.getCropCycleById = function (cropcycleId, res) {
        return cropCycleDAO.getCropCycleById(cropcycleId, res);
    }
    this.createCropCycle = function (req, res) {
        return cropCycleDAO.createCropCycle(req, res);
    }
    this.updateCropCycle = function (cropcycleId, req, res) {
        // console.log("from service",req.body);
        return cropCycleDAO.updateCropCycle(cropcycleId, req, res);
    }
    this.removeCropCycle = function (cropcycleId, res) {
        return cropCycleDAO.removeCropCycle(cropcycleId, res);
    }
}



module.exports = new CropcCycleService();