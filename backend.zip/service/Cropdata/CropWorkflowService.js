var cropWorkflowDAO = require('../../dao/Cropdata/CropWorkflowDAO');

function CropWorkflowService() {
    this.getAllCropWorkflow = function (req, res) {
        console.log(res)
        return cropWorkflowDAO.getAllCropWorkflow(req, res);
    }
    this.getCropWorkflowById = function (cropcatId, res) {
        return cropWorkflowDAO.getCropWorkflowById(cropcatId, res);
    }
    this.createCropWorkflow = function (req, res) {
        return cropWorkflowDAO.createCropWorkflow(req, res)
    }
    this.updateCropflow = function (cropcatId, req, res) {
        return cropWorkflowDAO.updateCropflow(cropcatId, req, res);
    }
    this.removeCropflow = function (cropcatId, res) {
        return cropWorkflowDAO.removeCropflow(cropcatId, res);
    }
}
module.exports = new CropWorkflowService();