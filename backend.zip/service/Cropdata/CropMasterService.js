var cropMasterDAO = require('../../dao/Cropdata/CropMasterDAO');

function CropMasterService() {
    this.getAllCropMasters = function (req, res) {
        return cropMasterDAO.getAllCropMasters(req, res);
    }
    this.getCropMasterById = function (cropmasterId, res) {
        return cropMasterDAO.getCropMasterById(cropmasterId, res);
    }
    this.createCropMaster = function (req, res) {
        cropMasterDAO.checkCropMasterExists(req.body.CropVarietyName)
            .then(() => {
                return cropMasterDAO.createCropMaster(req, res);
            })
            .catch(() => {
                res.json({ serverErrorCropMasterExistence: "Crop Master already exists with same name!. Plz enter a different name" });
            });
    }
    this.updateCropMaster = function (cropmasterId, req, res) {
        return cropMasterDAO.updateCropMaster(cropmasterId, req, res);
    }
    this.removeCropMaster = function (cropmasterId, res) {
        return cropMasterDAO.removeCropMaster(cropmasterId, res);
    }
}

module.exports = new CropMasterService();