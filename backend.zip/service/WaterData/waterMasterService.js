var WaterMasterDAO = require("../../dao/WaterData/WatermasterDAO")
//for get 
function waterMasterService() {
  this.getAllWaterMaster = function (req, res) {
    return WaterMasterDAO.getAllWaterMaster(req, res);
  }
  //for get id
  this.getWaterMasterById = function (watermasterId, res) {
    // console.log("testing in service", watermasterId);
    return WaterMasterDAO.getWaterMasterById(watermasterId, res);
  };

  //for post
  this.createWaterMaster = function (req, res) {
    // console.log("testing body", req.body.Name);
    WaterMasterDAO.checkWaterMasterExists(req.body.Name)
      .then(() => {
        return WaterMasterDAO.createWaterMaster(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "watermaster already exists with same type!. Plz enter a different watermaster " });
      });
  };

  //for update

  this.updateById = function (req, watermasterId, res) {
    return WaterMasterDAO.updateById(req, watermasterId, res);


  };

  //for delete
  this.deleteById = function (watermasterId, res) {
    return WaterMasterDAO.deleteById(watermasterId, res);
  };


}

module.exports = new waterMasterService();