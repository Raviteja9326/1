var WaterCategoryDAO = require("../../dao/WaterData/WaterCategoryDAO")
//for get 
function waterCategoryService() {
  this.getAllWaterCategory = function (req, res) {
    return WaterCategoryDAO.getAllWaterCategory(req, res);
  }
  //for get id
  this.getWaterCategoryById = function (watercategoryId, res) {
    // console.log("testing in service", watercategoryId);
    return WaterCategoryDAO.getWaterCategoryById(watercategoryId, res);
  };

  //for post
  this.createWaterCategory = function (req, res) {
    // console.log("testing body", req.body.WaterCategory);
    WaterCategoryDAO.checkWaterCategoryExists(req.body.WaterCategory)
      .then(() => {
        return WaterCategoryDAO.createWaterCategory(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "watercategory already exists with same category!. Plz enter a different watercategory " });
      });
  };

  //for update

  this.updateById = function (req, watercategoryId, res) {
    return WaterCategoryDAO.updateById(req, watercategoryId, res);
  };

  //for delete
  this.deleteById = function (watercategoryId, res) {
    return WaterCategoryDAO.deleteById(watercategoryId, res);
  };


}

module.exports = new waterCategoryService();