var WaterTestDataDAO = require('../../dao/WaterData/WaterTestDataDAO');
//for get
function waterTestDataService() {
	this.getAllWaterTestData = function (req, res) {
		return WaterTestDataDAO.getAllWaterTestData(req, res);
	};
	//for get id
	this.getWaterTestDataById = function (watertestdataId, res) {
		console.log('testing in service', watertestdataId);
		return WaterTestDataDAO.getWaterTestDataById(watertestdataId, res);
	};

	//for post
	this.createWaterTestData = function (req, res) {
		//console.log('res from roting', req);
		return WaterTestDataDAO.createWaterTestData(req, res);
		// console.log("testing body", req.body.WaterTestData);
		// WaterTestDataDAO.checkWaterTestDataExists(req.body.WaterTestData)
		//   .then(() => {
		//     return WaterTestDataDAO.createWaterTestData(req, res);
		//   })
		//   .catch(() => {
		//     res.json({ serverErrorStateExistence: "watertestdata already exists with same testdata!. Plz enter a different watertestdata " });
		//   });
	};

	//for update

	this.updateById = function (req, watertestdataId, res) {
		return WaterTestDataDAO.updateById(req, watertestdataId, res);
	};

	//for delete
	this.deleteById = function (watertestdataId, res) {
		console.log('id from service', watertestdataId);
		return WaterTestDataDAO.deleteById(watertestdataId, res);
	};
}

module.exports = new waterTestDataService();
