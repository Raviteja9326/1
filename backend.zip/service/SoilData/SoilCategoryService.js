var SoilCategoryDAO = require("../../dao/SoilData/SoilCategoryDAO")
//for get 
function SoilCategoryService() {
  this.getAllSoilCategory = function (req, res) {
    return SoilCategoryDAO.getAllSoilCategory(req, res);
  }
  //for get id
  this.getSoilCategoryById = function (soilcategoryId, res) {
    // console.log("testing in service", soilcategoryId);
    return SoilCategoryDAO.getSoilCategoryById(soilcategoryId, res);
  };

  //for post
  this.createSoilCategory = function (req, res) {
    // console.log("testing body", req.body.SoilCatType);
    SoilCategoryDAO.checkSoilCategoryExists(req.body.SoilCatType)
      .then(() => {
        return SoilCategoryDAO.createSoilCategory(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Soilcategory already exists with same type!. Plz enter a different soiltype " });
      });
  };

  //for update

  this.updateById = function (req, soilcategoryId, res) {
    return SoilCategoryDAO.updateById(req, soilcategoryId, res);
  };

  //for delete
  this.deleteById = function (soilcategoryId, res) {
    return SoilCategoryDAO.deleteById(soilcategoryId, res);
  };


}

module.exports = new SoilCategoryService();