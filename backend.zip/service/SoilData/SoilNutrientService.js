var SoilNutrientDAO = require("../../dao/SoilData/SoilNutrientDAO")
//for get 
function SoilNutrientService() {
  this.getAllSoilNutrient = function (req, res) {
    return SoilNutrientDAO.getAllSoilNutrient(req, res);
  }

  //for get id
  this.getSoilNutrientById = function (soilnutrientId, res) {
    // console.log("testing in service", soilnutrientId);
    return SoilNutrientDAO.getSoilNutrientById(soilnutrientId, res);
  };


  //for post
  this.createSoilNutrient = function (req, res) {
    SoilNutrientDAO.checkSoilNutrientExists(req.body.SoilNutrientName)
      .then(() => {
        return SoilNutrientDAO.createSoilNutrient(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Soilnutrient already exists with same type!. Plz enter a different soilnutrient " });
      });
  }
  //for update

  this.updateById = function (req, soilnutrientId, res) {
    return SoilNutrientDAO.updateById(req, soilnutrientId, res);
  };

  //for delete
  this.deleteById = function (soilnutrientId, res) {
    return SoilNutrientDAO.deleteById(soilnutrientId, res);
  };

};

module.exports = new SoilNutrientService();