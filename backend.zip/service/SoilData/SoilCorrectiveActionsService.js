var SoilCorrectiveActionsDAO = require('../../dao/SoilData/SoilCorrectiveActionsDAO');

function SoilCorrectiveActionsService() {
	//for get all
	this.getAllSoilCorrectiveAction = function (req, res) {
		return SoilCorrectiveActionsDAO.getAllSoilCorrectiveAction(req, res);
	};

	//get by id
	this.getSoilCorrectiveActionByID = function (SoilCorrectiveId, res) {
		console.log(SoilCorrectiveId, 'id from service');
		return SoilCorrectiveActionsDAO.getSoilCorrectiveActionByID(SoilCorrectiveId, res);
	};

	//get solitestdata by id
	this.getSoilTestDataByID = function (TblSoilTestData_ID, res) {
		console.log('soiltestdata id =', TblSoilTestData_ID);
		return SoilCorrectiveActionsDAO.getSoilTestDataByID(TblSoilTestData_ID, res);
	};

	//for post data
	this.createSoilCorrectiveAction = function (req, res) {
		return SoilCorrectiveActionsDAO.createSoilCorrectiveAction(req, res);
	};

	//for update data
	this.updateSoilCorrectiveActionByID = function (req, SoilCorrectiveId, res) {
		console.log('this id from service', SoilCorrectiveId);
		return SoilCorrectiveActionsDAO.updateSoilCorrectiveActionByID(req, SoilCorrectiveId, res);
	};

	//for delete data
	this.deleteSoilCorrectiveActionByID = function (SoilCorrectiveId, res) {
		console.log('id to delete from Serice = ', SoilCorrectiveId);
		return SoilCorrectiveActionsDAO.deleteSoilCorrectiveActionByID(SoilCorrectiveId, res);
	};
}

module.exports = new SoilCorrectiveActionsService();
