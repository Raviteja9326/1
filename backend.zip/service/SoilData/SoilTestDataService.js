var soilTestDataDAO = require('../../dao/SoilData/SoilTestDataDAO');

function SoilTestDataService() {
	this.getAllSoilTestData = function (req, res) {
		return soilTestDataDAO.getAllSoilTestDataFromDAO(req, res);
	};

	this.getSoilTestDataByID = function (soilDataID, res) {
		return soilTestDataDAO.getSoilTestDataByID(soilDataID, res);
	};

	this.deleteSoilTestDataById = function (soiltestdataId, res) {
		return soilTestDataDAO.deleteSoilTestDataById(soiltestdataId, res);
	};

	this.updateSoilTestDataByID = function (req, soiltestdataId, res) {
		return soilTestDataDAO.updateSoilTestDataByID(req, soiltestdataId, res);
	};
}

module.exports = new SoilTestDataService();
