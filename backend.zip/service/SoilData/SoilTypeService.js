var soiltypeDAO = require("../../dao/SoilData/SoilTypeDAO")
//for get 
function SoilTypeService() {
  this.getAllSoilType = function (req, res) {
    return soiltypeDAO.getAllSoilType(req, res);
  }

  //for get id
  this.getSoilTypeById = function (Id, res) {
    // console.log("testing in service", Id);
    return soiltypeDAO.getSoilTypeById(Id, res);
  };

  //for post
  this.createSoilType = function (req, res) {
    soiltypeDAO.checkSoilTypeExists(req.body.SoilType)
      .then(() => {
        return soiltypeDAO.createSoilType(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Soiltype already exists with same type!. Plz enter a different soiltype " });
      });
  };


  //for update

  this.updateById = function (req, soiltypeId, res) {
    return soiltypeDAO.updateById(req, soiltypeId, res);
  };

  //for delete
  this.deleteById = function (soiltypeId, res) {
    return soiltypeDAO.deleteById(soiltypeId, res);
  };

}



module.exports = new SoilTypeService();