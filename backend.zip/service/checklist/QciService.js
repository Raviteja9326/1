var QCIDAO = require("../../dao/cheecklist/QciModuleDAO")
//for get 
function QciService() {
  //for get qci farmer
  this.getAllqcifarmer = function (req, res) {
    return QCIDAO.getAllqcifarmer(req, res);
  }
  //for get qci module
  this.getAllqcimodule = function (req, res) {
    return QCIDAO.getAllqcimodule(req, res);
  }

  this.getAllchecklist = function (req, res) {
    return QCIDAO.getAllchecklist(req, res);
  }

  //for getfarmer id
  this.getqcifarmerId = function (TblQCIModule_ID, res) {

    return QCIDAO.getqcifarmerId(TblQCIModule_ID, res);
  };


  //for getmodule id
  this.getqcimoduleId = function (req, FarmerID, res) {

    return QCIDAO.getqcimoduleId(req, FarmerID, res);
  };

  this.getfarmerId = function (req, farmerId, res) {

    return QCIDAO.getfarmerId(req, farmerId, res);
  };
  //for post
  this.createqcifarmer = function (req, res) {
    return QCIDAO.createqcifarmer(req, res);
  };

  this.getChecklistByfarmerid = function (req, farmerID, res) {
    return QCIDAO.getChecklistByfarmerid(req, farmerID, res);
  };

  this.getfarmerid = function (req, farmerID, res) {
    return QCIDAO.getfarmerid(req, farmerID, res);
  };
}


module.exports = new QciService();