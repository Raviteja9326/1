var LoanDAO = require('../../dao/LoanData/LoanDAO');
function LoanService() {
    this.getAllLoans = function (req, res) {
        return LoanDAO.getAllLoans(req, res);
    }
    this.getAllPaymentFrequency = function (req, res) {
        return LoanDAO.getAllPaymentFrequency(req, res);
    }

    this.getLoanById = function (loanId, res) {
        return LoanDAO.getLoanById(loanId, res);
    }
    this.createLoan = function (req, res) {
        return LoanDAO.createLoan(req, res);
    }

    this.createLoan = function (req, res) {
        LoanDAO.checkLoanExists(req.body.LoanNumber)
            .then(() => {
                return LoanDAO.createLoan(req, res);
            })
            .catch(() => {
                res.json({ serverErrorloanExistence: "Loan Number already exists with same Number!. Plz enter a different Number" });
            });
    }

    this.updateLoan = function (loanId, req, res) {
        return LoanDAO.updateLoan(loanId, req, res);
    }
    this.removeLoan = function (loanId, res) {
        return LoanDAO.removeLoan(loanId, res);
    }
}
module.exports = new LoanService();