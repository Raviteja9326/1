var loanEMIDAO = require('../../dao/LoanData/LoanEMIDAO');

function LoanEMIService() {
    this.getAllLoanEMI = function (req, res) {
        return loanEMIDAO.getAllLoanEMI(req, res);
    }
    this.getLoanEMIById = function (loanEMIId, res) {
        return loanEMIDAO.getLoanEMIById(loanEMIId, res);
    }
    this.createLoanEMI = function (req, res) {
        return loanEMIDAO.createLoanEMI(req, res);
    }
    this.updateLoanEMI = function (loanEMIId, req, res) {
        return loanEMIDAO.updateLoanEMI(loanEMIId, req, res);
    }
    this.removeLoanEMI = function (loanEMIId, res) {
        return loanEMIDAO.removeLoanEMI(loanEMIId, res);
    }
}

module.exports = new LoanEMIService();