var DealerDAO = require("../../dao/Raw Material/DealerDAO")
//for get 
function DealerService() {
  this.getAlldealer = function (req, res) {
    return DealerDAO.getAlldealer(req, res);
  }

  //for get id
  this.getdealerId = function (Id, res) {
    // console.log("testing in service", Id);
    return DealerDAO.getdealerId(Id, res);
  };

  //for post
  this.createdealer = function (req, res) {
    DealerDAO.checkdealerExists(req.body.DealerName)
      .then(() => {
        return DealerDAO.createdealer(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "dealer  already exists with same name!. Plz enter a different dealer name " });
      });
  };
  //for update

  this.updateById = function (req, dealerId, res) {
    DealerDAO.checkdealerExists(req.body.DealerName)
      .then(() => {
        return DealerDAO.updateById(req, dealerId, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "dealer already exists with same breed!. Plz enter a different dealer " });
      });


  };

  //for delete
  this.deleteById = function (dealerId, res) {
    // console.log("im from service", dealerId);
    return DealerDAO.deleteById(dealerId, res);
  };
}

module.exports = new DealerService();