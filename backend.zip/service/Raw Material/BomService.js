var BOMDAO = require("../../dao/Raw Material/BomDAO")
//for get 
function BomService() {
  this.getAllbom = function (req, res) {
    return BOMDAO.getAllbom(req, res);
  }

  //for get id
  this.getbomId = function (Id, res) {
    // console.log("testing in service", Id);
    return BOMDAO.getbomId(Id, res);
  };

  //for post
  this.createbom = function (req, res) {

    return BOMDAO.createbom(req, res);
  };


  //for update

  this.updateById = function (req, bomId, res) {
    // console.log("im from service", bomId);
    return BOMDAO.updateById(req, bomId, res);
  };

  //for delete
  this.deleteById = function (bomId, res) {
    // console.log("im from service", bomId);
    return BOMDAO.deleteById(bomId, res);
  };
}

module.exports = new BomService();