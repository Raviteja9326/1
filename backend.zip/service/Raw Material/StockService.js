var stockDAO = require('../../dao/Raw Material/StockDAO');
function StockService() {
    this.getAllStock = function (req, res) {
        return stockDAO.getAllStock(req, res);
    }
    this.getStockMaterials = function (req, res) {
        return stockDAO.getStockMaterials(req, res);
    }

    this.getUnits = function (req, res) {
        return stockDAO.getUnits(req, res);
    }
    this.getLoaction = function (req, res) {
        return stockDAO.getLoaction(req, res);
    }
    this.getMaterialCatByMatID = function (req, matID, res) {
        return stockDAO.getMaterialCatByMatID(req, matID, res);

    }
    this.createStock = function (req, res) {
        return stockDAO.createStock(req, res);
    }
    this.updateStockByID = function (req, stockID, res) {
        // console.log("stock id is  ",stockID);
        return stockDAO.updateStockByID(req, stockID, res);

    }
    this.deleteStockByID = function (req, stockID, res) {
        return stockDAO.deleteStockByID(req, stockID, res);
    }
    this.getStockByFarmerID = function (req, farmerID, res) {
        return stockDAO.getStockByFarmerID(req, farmerID, res);

    }
}

module.exports = new StockService();