var inventoryDAO = require('../../dao/Raw Material/InventoryDAO');
function InventoryService() {
    this.getAllInventories = function (req, res) {
        return inventoryDAO.getAllInventories(req, res);
    }
    this.getInventoryByFarmerID = function (req, farmerID, res) {
        return inventoryDAO.getInventoryByFarmerID(req, farmerID, res);
    }
    this.createInventory = function (req, res) {
        return inventoryDAO.createInventory(req, res);
    }
    this.updateInventoryByID = function (req, inventoryID, res) {
        return inventoryDAO.updateInventoryByID(req, inventoryID, res);
    }
    this.deleteInventory = function (req, inventoryID, res) {
        return inventoryDAO.deleteInventory(req, inventoryID, res);
    }
}

module.exports = new InventoryService();