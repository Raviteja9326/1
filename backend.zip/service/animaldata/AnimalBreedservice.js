var AnimalBreedDAO = require("../../dao/animaldata/AnimalBreedDAO")
//for get 
function AnimalbreedService() {
  this.getAllanimalbreed = function (req, res) {
    return AnimalBreedDAO.getAllanimalbreed(req, res);
  }
  //for get id
  this.getanimalbreedId = function (animalbreedId, res) {
    // console.log("testing in service", animalbreedId);
    return AnimalBreedDAO.getanimalbreedId(animalbreedId, res);
  };

  this.getBreedByCatName = function (catName, res) {
    return AnimalBreedDAO.getBreedByCatName(catName, res);
  }

  //for post
  this.createAnimalBreed = function (req, res) {
    // console.log("testing body", req.body.BreedName);
    AnimalBreedDAO.checkAnimalBreedExists(req.body.BreedName)
      .then(() => {
        return AnimalBreedDAO.createAnimalBreed(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "animal breed already exists with same breed!. Plz enter a different breed " });
      });
  };

  //for update

  this.updateById = function (req, animalbreedId, res) {
   return AnimalBreedDAO.updateById(req,animalbreedId,res)
  };

  //for delete
  this.deleteById = function (animalbreedId, res) {
    return AnimalBreedDAO.deleteById(animalbreedId, res);
  };


}

module.exports = new AnimalbreedService();