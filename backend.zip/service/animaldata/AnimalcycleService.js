var animalcycleDAO = require('../../dao/animaldata/AnimalCycleDAO');
//for get
function AnimalCycleService() {
	this.getAllAnimalCycle = function (req, res) {
		return animalcycleDAO.getAllAnimalCycle(req, res);
	};

	//for get id
	this.getAnimalCycleById = function (Id, res) {
		console.log('testing in service', Id);
		return animalcycleDAO.getAnimalCycleById(Id, res);
	};

	//for post
	this.createAnimalcycle = function (req, res) {
		return animalcycleDAO.createAnimalcycle(req, res);
	};

	//for update

	this.updateById = function (req, animalcycleId, res) {
		console.log('im from service', animalcycleId);
		return animalcycleDAO.updateById(req, animalcycleId, res);
	};

	//for delete
	this.deleteById = function (animalcycleId, res) {
		return animalcycleDAO.deleteById(animalcycleId, res);
	};
}

module.exports = new AnimalCycleService();
