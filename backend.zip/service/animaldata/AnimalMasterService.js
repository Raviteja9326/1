var AnimalMasterDAO = require("../../dao/animaldata/AnimalMasterDAO")
//for get 
function AnimalMasterService() {
  this.getAllanimalmaster = function (req, res) {
    return AnimalMasterDAO.getAllanimalmaster(req, res);
  }

  //for get id
  this.getanimalmasterId = function (Id, res) {
    // console.log("testing in service", Id);
    return AnimalMasterDAO.getanimalmasterId(Id, res);
  };

  //for post
  this.createAnimalMaster = function (req, res) {
    AnimalMasterDAO.checkAnimalMasterExists(req.body.AnimalName)
      .then(() => {
        return AnimalMasterDAO.createAnimalMaster(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "animalname already exists with same name!. Plz enter a different animalname " });
      });
  };
  //for update

  this.updateById = function (req, animalmasterId, res) {

  return AnimalMasterDAO.updateById(req,animalmasterId,res)

  };

  //for delete
  this.deleteById = function (animalmasterId, res) {
    // console.log("im from service", animalmasterId);
    return AnimalMasterDAO.deleteById(animalmasterId, res);
  };
}

module.exports = new AnimalMasterService();