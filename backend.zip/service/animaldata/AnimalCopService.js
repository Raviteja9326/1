var animalCOPDAO = require('../../dao/animaldata/AnimalCopDAO');

function AnimalCOPService() {
    this.getAllAnimalCOP = function (req, res) {
        return animalCOPDAO.getAllAnimalCOP(req, res);
    }
    this.getAnimalCOPById = function (animalcopId, res) {
        return animalCOPDAO.getAnimalCOPById(animalcopId, res);
    }

    this.updateAnimalCOP = function (animalcopId, req, res) {
        return animalCOPDAO.updateAnimalCOP(animalcopId, req, res);
    }
    this.removeAnimalCOP = function (animalcopId, res) {
        return animalCOPDAO.removeAnimalCOP(animalcopId, res);
    }
}

module.exports = new AnimalCOPService();