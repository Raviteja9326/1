var vaccinationDAO = require('../../dao/animaldata/VaccinationDAO');
function VaccinationService() {
  this.getAllVaccines = function (req, res) {
    return vaccinationDAO.getAllVaccines(req, res);
  }
  this.getVaccineByID = function (vaccineID, res) {
    return vaccinationDAO.getVaccineByID(vaccineID, res);
  }

  this.createVaccines = function (req, res) {
    vaccinationDAO.checkVaccineExists(req.body.Name)
      .then(() => {
        return vaccinationDAO.createVaccines(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Vaccine Name  already exists with same name!. Plz enter a different Name " });
      });
  }

  this.updateVaccineById = function (req, vaccineID, res) {
    vaccinationDAO.checkVaccineExists(req.body.Name)
      .then(() => {
        return vaccinationDAO.updateVaccineById(req, vaccineID, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Vaccine Name already exists with same breed!. Plz enter a different Vaccine Name " });
      });

  }

  this.deleteVaccineById = function (vaccineID, res) {
    return vaccinationDAO.deleteVaccineById(vaccineID, res);
  }
}

module.exports = new VaccinationService();
