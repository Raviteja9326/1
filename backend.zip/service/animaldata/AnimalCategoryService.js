var AnimalCategoryDAO = require("../../dao/animaldata/AnimalCategoryDAO")
//for get 
function AnimalCategoryService() {
  this.getAllanimalCategory = function (req, res) {
    return AnimalCategoryDAO.getAllanimalCategory(req, res);
  }
  //for get id
  this.getAnimalCategoryById = function (animalcategoryId, res) {
    // console.log("testing in service", animalcategoryId);
    return AnimalCategoryDAO.getAnimalCategoryById(animalcategoryId, res);
  };

  //for post
  this.createAnimalCategory = function (req, res) {
     console.log("testing body", req.body.AnimalCatName);
    AnimalCategoryDAO.checkAnimalCategoryExists(req.body.AnimalCatName)
      .then(() => {
        return AnimalCategoryDAO.createAnimalCategory(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Animalcategory already exists with same type!. Plz enter a different animalcategory " });
      });
  };

  //for update

  this.updateById = function (req, animalcategoryId, res) {
   return AnimalCategoryDAO.updateById(req,animalcategoryId,res)
  };

  //for delete
  this.deleteById = function (animalcategoryId, res) {
    return AnimalCategoryDAO.deleteById(animalcategoryId, res);
  };


}

module.exports = new AnimalCategoryService();
