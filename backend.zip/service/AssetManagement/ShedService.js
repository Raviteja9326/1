var ShedDAO = require("../../dao/AssetManagement/ShedDAO");

function ShedService() {
  this.getAllshedData = function (req, res) {
    return ShedDAO.getAllshedData(req, res);
  };
  this.getshedDataByID = function (shedId, res) {
    return ShedDAO.getshedDataByID(shedId, res);
  };

  this.createshed = function (req, res) {
    // console.log("from service", req.body.Name);
    ShedDAO.checkShedExists(req.body.Name)
      .then(() => {
        return ShedDAO.createshed(req, res);
      })
      .catch(() => {
        res.json({
          serverErrorshedExistence:
            "Shed already exists with same name!. Plz enter a different  name"
        });
      });
  };

  this.updatshed = function (req, shedId, res) {
    ShedDAO.checkShedExists(req.body.Name)
      .then(() => {
        return ShedDAO.updatshed(req, shedId, res);
        s;
      })
      .catch(() => {
        res.json({
          serverErrorshedExistence:
            "Shed already exists with same name!. Plz enter a different  name"
        });
      });
  };

  this.removeshed = function (shedId, res) {
    return ShedDAO.removeshed(shedId, res);
  };
}
module.exports = new ShedService();
