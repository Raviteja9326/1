var machineryDAO = require('../../dao/AssetManagement/MachineryDAO');

function MachineryService() {
    this.getAllMachinery = function (req, res) {
        return machineryDAO.getAllMachinery(req, res);

    }
    this.getMachineryById = function (machineryId, res) {
        return machineryDAO.getMachineryById(machineryId, res);

    }
    this.createmachinery = function (req, res) {
        machineryDAO.checkmachineryExists(req.body.Name)
            .then(() => {
                return machineryDAO.createmachinery(req, res);
            })
            .catch(() => {
                res.json({
                    serverErrorMachineryExistence: "Machinery already exists with same name!. Plz enter a different  name"
                });
            });
    };

    this.updatmachinery = function (req, machineryId, res) {
        return machineryDAO.updatmachinery(req, machineryId, res);

    }

    this.removemachinery = function (machineryId, res) {
        return machineryDAO.removemachinery(machineryId, res);
    }
}


module.exports = new MachineryService();