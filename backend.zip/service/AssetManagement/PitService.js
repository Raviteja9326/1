var pitDAO = require('../../dao/AssetManagement/PitDAO');

function PitService() {
    this.getAllPitData = function (req, res) {
        return pitDAO.getAllPitData(req, res);
    }
    this.getPitDataByID = function (pitId, res) {
        return pitDAO.getPitDataByID(pitId, res);
    }

    this.getPitTypes = function (req, res) {
        return pitDAO.getPitTypes(req, res);
    }

    this.getPitConstructionTypes = function (req, res) {
        return pitDAO.getPitConstructionTypes(req, res);
    }

    this.createPit = function (req, res) {
        return pitDAO.createPit(req, res);

    };

    this.updatePit = function (req, pitId, res) {
        return pitDAO.updatePit(req, pitId, res);
    }

    this.removePit = function (pitId, res) {
        return pitDAO.removePit(pitId, res);
    }
}
module.exports = new PitService();