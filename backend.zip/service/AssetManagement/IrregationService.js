var IrregationDAO = require("../../dao/AssetManagement/IrregationDAO")
//for get 
function IrregationService() {
  this.getAllirregation = function (req, res) {
    return IrregationDAO.getAllirregation(req, res);
  }

  //for get id
  this.getirregationId = function (Id, res) {
    // console.log("testing in service", Id);
    return IrregationDAO.getirregationId(Id, res);
  };

  //for post
  this.createirregation = function (req, res) {
    IrregationDAO.checkirregationExists(req.body.IrrigationName)
      .then(() => {
        return IrregationDAO.createirregation(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "irregation Name already exists with same name!. Plz enter a different irregation Name " });
      });
  };
  //for update

  this.updateById = function (req, irregationId, res) {
    return IrregationDAO.updateById(req, irregationId, res);
  };

  //for delete
  this.deleteById = function (irregationId, res) {
    // console.log("im from service", irregationId);
    return IrregationDAO.deleteById(irregationId, res);
  };
}

module.exports = new IrregationService();