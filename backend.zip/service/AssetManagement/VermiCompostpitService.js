var VermicompostpitDAO = require('../../dao/AssetManagement/VermiCompostPitDAO');

function vermicompostPitService() {
    this.getAllVermicompostPitData = function (req, res) {
        return VermicompostpitDAO.getAllVermicompostPitData(req, res);
    }
    this.getvermicompostPitDataByID = function (vermicompostpitId, res) {
        // console.log("gfgdxgxdg",vermicompostpitId);
        return VermicompostpitDAO.getvermicompostPitDataByID(vermicompostpitId, res);
    }

    this.createvermicompostPit = function (req, res) {
        VermicompostpitDAO.checkvermicompostPitExists(req.body.ConstructionType)
            .then(() => {
                return VermicompostpitDAO.createvermicompostPit(req, res);
            })
            .catch(() => {
                res.json({
                    serverErrorCurrencyExistence: "construction type already exists with same name!. Plz enter a different  name"
                });
            });
    };

    this.updatevermicompostPit = function (req, vermicompostpitId, res) {
        return VermicompostpitDAO.updatevermicompostPit(req, vermicompostpitId, res);
    }

    this.removevermicompostPit = function (vermicompostpitId, res) {
        return VermicompostpitDAO.removevermicompostPit(vermicompostpitId, res);
    }

}
module.exports = new vermicompostPitService();