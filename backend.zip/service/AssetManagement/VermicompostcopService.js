var VermicompostcopDAO = require('../../dao/AssetManagement/VermicompostcopDAO');

function vermicompostcopService() {
    this.getAllVermicompostcopData = function (req, res) {
        return VermicompostcopDAO.getAllVermicompostcopData(req, res);
    }
    this.getvermicompostcopDataByID = function (vermicompostcopId, res) {
        return VermicompostcopDAO.getvermicompostcopDataByID(vermicompostcopId, res);
    }

    this.createvermicompostcop = function (req, res) {
        VermicompostcopDAO.checkvermicompostcopExists(req.body.Process)
            .then(() => {
                return VermicompostcopDAO.createvermicompostcop(req, res);
            })
            .catch(() => {
                res.json({
                    serverErrorCurrencyExistence: "process type already exists with same name!. Plz enter a different  name"
                });
            });
    };

    this.updatevermicompostcop = function (req, vermicompostcopId, res) {
        return VermicompostcopDAO.updatevermicompostcop(req, vermicompostcopId, res);
    }

    this.removevermicompostcop = function (vermicompostcopId, res) {
        return VermicompostcopDAO.removevermicompostcop(vermicompostcopId, res);
    }

}
module.exports = new vermicompostcopService();