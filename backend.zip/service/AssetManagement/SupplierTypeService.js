var SuppliertypeDAO = require("../../dao/AssetManagement/SupplierTypeDAO");
//for get
function SuppliertypeService() {
  this.getAllsuppliertype = function (req, res) {
    return SuppliertypeDAO.getAllsuppliertype(req, res);
  };

  //for get id
  this.getsuppliertypeId = function (Id, res) {
    // console.log("testing in service", Id);
    return SuppliertypeDAO.getsuppliertypeId(Id, res);
  };

  //for post
  this.createsuppliertype = function (req, res) {
    SuppliertypeDAO.checksuppliertypeExists(req.body.SupplierType)
      .then(() => {
        return SuppliertypeDAO.createsuppliertype(req, res);
      })
      .catch(() => {
        res.json({
          serverErrorStateExistence:
            "suppliertype  already exists with same name!. Plz enter a different suppliertype "
        });
      });
  };
  //for update

  this.updateById = function (req, suppliertypeId, res) {
    // console.log("im from service", suppliertypeId);
    return SuppliertypeDAO.updateById(req, suppliertypeId, res);
  };

  //for delete
  this.deleteById = function (suppliertypeId, res) {
    // console.log("im from service", suppliertypeId);
    return SuppliertypeDAO.deleteById(suppliertypeId, res);
  };
}

module.exports = new SuppliertypeService();
