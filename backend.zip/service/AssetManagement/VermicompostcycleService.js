var VermicompostcycleDAO = require('../../dao/AssetManagement/VermicompostcycleDAO');

function vermicompostcycleService() {
    this.getAllVermicompostcycleData = function (req, res) {
        return VermicompostcycleDAO.getAllVermicompostcycleData(req, res);
    }
    this.getvermicompostcycleDataByID = function (vermicompostcycleId, res) {
        return VermicompostcycleDAO.getvermicompostcycleDataByID(vermicompostcycleId, res);
    }

    this.createvermicompostcycle = function (req, res) {
        return VermicompostcycleDAO.createvermicompostcycle(req, res);
    };
    this.updatevermicompostcycle = function (req, vermicompostcycleId, res) {
        return VermicompostcycleDAO.updatevermicompostcycle(req, vermicompostcycleId, res);
    }

    this.removevermicompostcycle = function (vermicompostcycleId, res) {
        return VermicompostcycleDAO.removevermicompostcycle(vermicompostcycleId, res);
    }

}
module.exports = new vermicompostcycleService();