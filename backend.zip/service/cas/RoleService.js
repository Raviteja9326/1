const roleDAO = require('../../dao/cas/RolesDAO');

function RoleService() {
	this.getAllRoles = function() {
		return roleDAO.getAllRoles();
	};
}

module.exports = new RoleService();
