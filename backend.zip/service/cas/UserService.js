const userDAO = require('../../dao/cas/UsersDAO');
function UserService() {
	this.userLogin = function(req, res) {
		return userDAO.loginUser(req, res);
	};

	this.getAllUsers = function(req, res) {
		return userDAO.getAllUsers(req, res);
	};
	this.getUserByID = function(userID, res) {
		return userDAO.getUserByID(userID, res);
	};
	this.updateUser = function(req, userID, res) {
		return userDAO.updateUser(req, userID, res);
	};

	this.delloite = function(userID, res) {
		return userDAO.delloite(userID, res);
	};

	this.chartData = (data) => {
		const graphdata = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ];
		for (let index = 0; index < data.length; index++) {
			graphdata[data[index].month] = data[index].totalcount;
		}
		graphdata.shift();
		graphdata.length === 11 ? graphdata.push(0) : graphdata;
		console.log(graphdata);
		return graphdata;
	};
}

module.exports = new UserService();
