var animalDiseaseDAO = require("../../dao/DiseasData/AnimalDiseaseDAO");

function AnimalDiseaseService() {
    this.getAllAnimalDisease = function (req, res) {
        return animalDiseaseDAO.getAllAnimalDisease(req, res);
    }
    this.getAnimalDiseaseById = function (animaldiseaseId, res) {
        return animalDiseaseDAO.getAnimalDiseaseById(animaldiseaseId, res);
    }
    this.createAnimalDisease = function (req, res) {
        return animalDiseaseDAO.createAnimalDisease(req, res)
    }
    this.updateAnimalDisease = function (animaldiseaseId, req, res) {
        console.log(animaldiseaseId, "uioi")
        return animalDiseaseDAO.updateAnimalDisease(animaldiseaseId, req, res);
    }
    this.removeAnimalDisease = function (animaldiseaseId, res) {
        return animalDiseaseDAO.removeAnimalDisease(animaldiseaseId, res);
    }
}
module.exports = new AnimalDiseaseService();