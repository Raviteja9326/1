var cropReportDiseaseDAO = require("../../dao/DiseasData/CropReportDiseaseDAO");

function CropReportDiseaseService() {
    this.getAllCropReportDisease = function (req, res) {
        return cropReportDiseaseDAO.getAllCropReportDisease(req, res);
    }
    this.getCropReportDiseaseById = function (cropreportdiseaseId, res) {
        return cropReportDiseaseDAO.getCropReportDiseaseById(cropreportdiseaseId, res);
    }
    this.createCropReportDisease = function (req, res) {
        return cropReportDiseaseDAO.createCropReportDisease(req, res)
    }
    this.updateCropReportDisease = function (cropreportdiseaseId, req, res) {
        return cropReportDiseaseDAO.updateCropReportDisease(cropreportdiseaseId, req, res);
    }
    this.removeCropReportDisease = function (cropreportdiseaseId, res) {
        return cropReportDiseaseDAO.removeCropReportDisease(cropreportdiseaseId, res);
    }
}
module.exports = new CropReportDiseaseService();