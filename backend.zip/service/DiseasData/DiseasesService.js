var DiseaseDAO = require('../../dao/DiseasData/DiseasesDAO');

function DiseaseService() {
    this.getAllDiseases = function (req, res) {
        return DiseaseDAO.getAllDiseases(req, res);
    }
    this.getallDiseaseTypes = function (req, res) {
        return DiseaseDAO.getallDiseaseTypes(req, res);
    }
    this.getallCropDiseaseTypes = function (req, res) {
        return DiseaseDAO.getallCropDiseaseTypes(req, res);
    }
    this.getallAnimalDiseaseTypes = function (req, res) {
        return DiseaseDAO.getallAnimalDiseaseTypes(req, res);
    }
    this.getDiseaseById = function (diseaseId, res) {
        return DiseaseDAO.getDiseaseById(diseaseId, res);
    }
    this.createDisease = function (req, res) {
        DiseaseDAO.checkDiseaseExists(req.body.DiseaseType)
            .then(() => {
                return DiseaseDAO.createDisease(req, res);
            })
            .catch(() => {
                res.json({ serverErrorDiseaseExistence: "Disease already exists with same Disease!. Plz enter a different Disease" });
            });
    }
    this.updateDisease = function (diseaseId, req, res) {
        return DiseaseDAO.updateDisease(diseaseId, req, res);
    }
    this.removeDisease = function (diseaseId, res) {
        return DiseaseDAO.removeDisease(diseaseId, res);
    }
}

module.exports = new DiseaseService();