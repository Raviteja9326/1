var cropDiseaseDAO = require("../../dao/DiseasData/CropDiseaseDAO");

function CropDiseaseService() {
    this.getAllCropDisease = function (req, res) {
        return cropDiseaseDAO.getAllCropDisease(req, res);
    }
    this.getCropDiseaseById = function (cropdiseaseId, res) {
        return cropDiseaseDAO.getCropDiseaseById(cropdiseaseId, res);
    }
    this.createCropDisease = function (req, res) {
        return cropDiseaseDAO.createCropDisease(req, res)
    }
    this.updateCropDisease = function (cropdiseaseId, req, res) {
        return cropDiseaseDAO.updateCropDisease(cropdiseaseId, req, res);
    }
    this.removeCropDisease = function (cropdiseaseId, res) {
        return cropDiseaseDAO.removeCropDisease(cropdiseaseId, res);
    }
}
module.exports = new CropDiseaseService();