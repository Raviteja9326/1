var animalReportDiseaseDAO = require("../../dao/DiseasData/AnimalReportDiseaseDAO");

function AnimalReportDiseaseService() {
    this.getAllAnimalReportDisease = function (req, res) {
        return animalReportDiseaseDAO.getAllAnimalReportDisease(req, res);
    }
    this.getAnimalReportDiseaseById = function (animalreportdiseaseId, res) {
        return animalReportDiseaseDAO.getAnimalReportDiseaseById(animalreportdiseaseId, res);
    }
    this.createAnimalReportDisease = function (req, res) {
        return animalReportDiseaseDAO.createAnimalReportDisease(req, res)
    }
    this.updateAnimalReportDisease = function (animalreportdiseaseId, req, res) {
        return animalReportDiseaseDAO.updateAnimalReportDisease(animalreportdiseaseId, req, res);
    }
    this.removeAnimalReportDisease = function (animalreportdiseaseId, res) {
        return animalReportDiseaseDAO.removeAnimalReportDisease(animalreportdiseaseId, res);
    }
}
module.exports = new AnimalReportDiseaseService();