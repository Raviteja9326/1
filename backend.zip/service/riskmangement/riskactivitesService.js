var riskActivitiesDAO = require("../../dao/riskmangement/riskactivitesDAO");
//for get
function RiskActivitiesService() {
  this.getAllRiskActivities = function(req, res) {
    return riskActivitiesDAO.getAllRiskActivities(req, res);
  };
  //for get id
  this.getRiskActivitiesId = function(riskactivitiesId, res) {
    return riskActivitiesDAO.getRiskActivitiesId(riskactivitiesId, res);
  };
   //for post
   this.createRiskActivitiesId = function (req, res) {
    return riskActivitiesDAO.createRiskActivitiesId(req, res);
  }; 
 
  //for update
  this.updateRiskActivitiesById = function(req, riskactivitiesId, res) {
    return riskActivitiesDAO.updateRiskActivitiesById(req, riskactivitiesId, res);
  };
  //for delete
  this.deleteRiskActivitiesById = function(riskactivitiesId, res) {  
    return deleteRiskActivitiesById.deleteById(riskactivitiesId, res);
  };
}

module.exports = new RiskActivitiesService();
