var riskManagementDAO = require("../../dao/riskmangement/riskmanagementDAO");
//for get
function RiskManagementService() {
  this.getAllRiskManagement = function(req, res) {
    return riskManagementDAO.getAllRiskManagement(req, res);
  };

  //for get id
  this.getRiskManagementId = function(riskmanagementID, res) {
    
    return riskManagementDAO.getRiskManagementId(riskmanagementID, res);
  };
   //for post
   this.createRiskManagement = function (req, res) {
    return riskManagementDAO.createRiskManagement(req, res);
  }; 
 
  //for update

  this.updateRiskManagementById = function(req, riskmanagementID, res) {
    
    return riskManagementDAO.updateRiskManagementById(req, riskmanagementID, res);
  };

  //for delete
  this.deleteRiskManagementById = function(riskmanagementID, res) {
    
    return riskManagementDAO.deleteRiskManagementById(riskmanagementID, res);
  };
}

module.exports = new RiskManagementService();
