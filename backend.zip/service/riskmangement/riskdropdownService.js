var RiskdropdownDAO = require("../../dao/riskmangement/riskdropdownDAO");
//for get

function riskdropdownService() {
  this.getAllriskdropdown = function(req, res) {
    return RiskdropdownDAO.getAllriskdropdown(req, res);
  };


  
    this.getAllriskstatus = function(req, res) {
      return RiskdropdownDAO.getAllriskstatus(req, res);
    };

    this.getAllImpact=function(req,res){
        return RiskdropdownDAO.getAllImpact(req,res)
    }

  //for get id
  this.getriskdropdownId = function(Id, res) {
    // console.log("testing in service", Id);
    return RiskdropdownDAO.getriskdropdownId(Id, res);
  };

  //for post
  this.createriskdropdown = function(req, res) {
      // console.log('fix', req.body.RiskArea)
    RiskdropdownDAO.checkriskdropdownExists(req.body.RiskArea)
      .then(() => {
        return RiskdropdownDAO.createriskdropdown(req, res);
      })
      .catch(() => {
        res.json({
          serverErrorRiskdropdownExistence:
            "RiskArea already exists with same name!. Plz enter a different RiskArea "
        });
      });
  };
}

module.exports = new riskdropdownService();
