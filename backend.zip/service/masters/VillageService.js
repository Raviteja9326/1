var villageDAO = require("../../dao/masters/VillagesDAO");

function VillageService() {
  this.getAllVillages = function (res) {
    return villageDAO.getAllVillages(res);
  };

  this.getVillageById = function (villageId, res) {
    return villageDAO.getVillageById(villageId, res);
  };

  this.getVillagesByMandalId = function (mandalId, res) {
    return villageDAO.getVillagesByMandalId(mandalId, res);
  }
  this.createVillage = function (req, res) {
    villageDAO.checkVillageExists(req, res)
      .then(() => {
        return villageDAO.createVillage(req, res);
      })
      .catch(() => {
        res.json({ serverErrorVillageExistence: "Village already exists with same name!. Plz enter a different village name" });
      });
  };


  this.updateVillageById = function (req, villageId, res) {
    return villageDAO.updateVillageById(req, villageId, res);

  };

  this.deleteVillageById = function (villageId, res) {
    return villageDAO.deleteVillageById(villageId, res);
  };
}

module.exports = new VillageService();
