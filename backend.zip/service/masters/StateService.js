var statesDAO = require("../../dao/masters/StatesDAO");

function StateService() {
  this.getAllStates = function (res) {
    // console.log("in StatesService.getAllStates");
    return statesDAO.getAllStates(res);
  };

  this.getStateById = function (stateId, res) {
    return statesDAO.getStateById(stateId, res);
  };

  this.getStatesByCountryId = function (countryId, res) {
    return statesDAO.getStatesByCountryId(countryId, res);

  }
  this.createState = function (req, res) {
    statesDAO.checkStateExists(req.body.TblCountry_CountryID, req.body.StateName, res)
      .then(() => {
        return statesDAO.createState(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "State already exists with same name!. Plz enter a different state name" });
      });
  };

  this.updateStateById = function (stateId, req, res) {
    return statesDAO.updateStateById(stateId, req, res);
  };
  this.deleteStateById = function (stateId, res) {
    return statesDAO.deleteStateById(stateId, res);
  };

}

module.exports = new StateService();
