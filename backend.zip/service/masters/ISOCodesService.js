var isocodesDAO = require("../../dao/masters/ISOCodesDAO");

function IsocodeService() {
  
  this.getISOcodes = function (req, res) {
    return isocodesDAO.getISOcodes(req, res);

  }
 

}

module.exports = new IsocodeService();