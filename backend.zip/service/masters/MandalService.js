var mandalsDAO = require('../../dao/masters/MandalsDAO');

function mandalService() {
	this.getAllMandals = function (res) {
		return mandalsDAO.getAllMandals(res);
	};
	this.getMandalById = function (mandalId, res) {
		return mandalsDAO.getMandalById(mandalId, res);
	};
	this.getMandalsByDistrictId = function (districtId, res) {
		return mandalsDAO.getMandalsByDistrictId(districtId, res);
	};
	this.getMandalsByC3OfficeId = function (c3officeId, res) {
		return mandalsDAO.getMandalsByC3OfficeId(c3officeId, res);
	};
	this.deleteMandalById = function (mandalId, res) {
		return mandalsDAO.deleteMandalById(mandalId, res);
	};
	this.createMandal = function (req, res) {
		mandalsDAO
			.checkMandalExists(req, res)
			.then(() => {
				return mandalsDAO.createMandal(req, res);
			})
			.catch(() => {
				res.json({
					serverErrorMandalExistence:
						'Mandal already exists with same name!. Plz enter a different mandal name'
				});
			});
	};

	this.updateMandalById = function (req, mandalId, res) {
		return mandalsDAO.updateMandalById(req, mandalId, res);
	};
}

module.exports = new mandalService();
