var countriesDAO = require("../../dao/masters/CountryDAO");

function CountryService() {
  this.getAllCountries = function (res) {
    // console.log("in CountryService.getAllCountries");
    return countriesDAO.getAllCountries(res);
  };

  this.getCountryById = function (countryId, res) {
    return countriesDAO.getCountryById(countryId, res);
  };

  this.createCountry = function (req, res) {
    countriesDAO.checkCountryExists(req.body.CountryName, res)
      .then(() => {
        return countriesDAO.createCountry(req, res);
      })
      .catch(() => {
        res.json({ serverErrorCountryExistence: "Country already exists with same name!. Plz enter a different country name" });
      });
  };

  this.updateCountryById = function (req, countryId, res) {
    return countriesDAO.updateCountryById(req, countryId, res);
  };
  this.deleteCountryById = function (countryId, res) {
    // console.log("this is country ID from service", countryId)
    return countriesDAO.deleteCountryById(countryId, res);
  };

}

module.exports = new CountryService();
