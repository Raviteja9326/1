var c3OfficeDAO = require("../../dao/masters/C3OfficeDAO");

function C3OfficeService() {
    this.getAllC3Offices = function (res) {
        // console.log("in C3OfficeService.getAllC3Offices");
        return c3OfficeDAO.getAllC3Offices(res);
    };

    this.getC3OfficeById = function (c3OfficeId, res) {
        return c3OfficeDAO.getC3OfficeById(c3OfficeId, res);
    };
    this.getC3OfficeByDistrictId = function (districtId, res) {
        return c3OfficeDAO.getC3OfficeByDistrictId(districtId, res);
    }
    this.createC3Office = function (req, res) {
        c3OfficeDAO.checkC3OfficeExists(req, res)
            .then(() => {
                return c3OfficeDAO.createC3Office(req, res);
            })
            .catch(() => {
                res.json({ serverErrorC3OfficeExistence: "Office already exists with same name!. Plz enter a different  name" });
            });
    };

    this.updateC3OfficeById = function (req, c3OfficeId, res) {
        return c3OfficeDAO.updateC3OfficeById(req, c3OfficeId, res);
    };
    this.deleteC3OfficeById = function (c3OfficeId, res) {
        return c3OfficeDAO.deleteC3OfficeById(c3OfficeId, res);
    };

}

module.exports = new C3OfficeService();