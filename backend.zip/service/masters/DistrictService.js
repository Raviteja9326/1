var districtsDAO = require('../../dao/masters/DistrictDAO');

function DistrictService() {
	this.getAllDistricts = function (res) {
		// console.log('in StatesService.getAllStates');
		return districtsDAO.getAllDistricts(res);
	};

	this.getDistrictById = function (districtId, res) {
		return districtsDAO.getDistrictById(districtId, res);
	};

	this.getDistrictsByStateId = function (stateId, res) {
		return districtsDAO.getDistrictsByStateId(stateId, res);
	};
	this.createDistrict = function (req, res) {
		districtsDAO
			.checkDistrictExists(
				req.body.DistrictName,
				req.body.TblState_StateID,
				req.body.TblState_TblCountry_CountryID, res
			)
			.then(() => {
				return districtsDAO.createDistrict(req, res);
			})
			.catch(() => {
				res.json({
					serverErrorDistrictExistence:
						'District already exists with same name!. Plz enter a different district name'
				});
			});
	};
	this.updateDistrictById = function (req, districtId, res) {
		return districtsDAO.updateDistrictById(req, districtId, res);
	};
	this.deleteDistrictById = function (districtId, res) {
		return districtsDAO.deleteDistrictById(districtId, res);
	};
}

module.exports = new DistrictService();
