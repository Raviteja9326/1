var RevenueDivisionDAO = require("../../dao/masters/RevenueDivisionDAO");

function RevenueDivisionService() {
    this.getAllRevenueDivisions = function (res) {
        // console.log("in RevenueDivisionService.getAllStates");
        return RevenueDivisionDAO.getAllRevenueDivisions(res);
    };

    this.getRevenueDivisionById = function (revenuedivisionId, res) {
        return RevenueDivisionDAO.getRevenueDivisionById(revenuedivisionId, res);
    };

    this.createRevenueDivision = function (req, res) {
        RevenueDivisionDAO.checkRevenueDivisionExists(req, res)
            .then(() => {
                return RevenueDivisionDAO.createRevenueDivision(req, res);
            })
            .catch(() => {
                res.json({ serverErrorRDExistence: "RD already exists with same name!. Plz enter a different  name" });
            });
    };

    this.updateRevenueDivisionById = function (req, revenuedivisionId, res) {
        return RevenueDivisionDAO.updateRevenueDivisionById(req, revenuedivisionId, res);

    };

    this.deleteRevenueDivisionById = function (revenuedivisionId, res) {
        return RevenueDivisionDAO.deleteRevenueDivisionById(revenuedivisionId, res);
    };

}

module.exports = new RevenueDivisionService();


