var villageSarpanchDAO = require("../../dao/masters/VillageSarpanchDAO");

function VillageSarpanchService() {
    this.getAllVillageSarpanches = function (res) {
        // console.log("in VillageSarpanchService.getAllVillageSarpanches");
        return villageSarpanchDAO.getAllVillageSarpanches(res);
    };

    this.getVillageSarpanchById = function (villageSarpanchId, res) {
        return villageSarpanchDAO.getVillageSarpanchById(villageSarpanchId, res);
    };

    this.createVillageSarpanch = function (req, res) {
        villageSarpanchDAO.checkVillageSarpanchExists(req, res)
            .then(() => {
                return villageSarpanchDAO.createVillageSarpanch(req, res);
            })
            .catch(() => {
                res.json({ serverErrorVillageSarpanchExistence: "Sarpanch already exists with same name!. Plz enter a different  name" });
            });
    };

    this.updateVillageSarpanchById = function (req, villageSarpanchId, res) {
        return villageSarpanchDAO.updateVillageSarpanchById(req, villageSarpanchId, res);

    };
    this.deleteVillageSarpanchById = function (villageSarpanchId, res) {
        return villageSarpanchDAO.deleteVillageSarpanchById(villageSarpanchId, res);
    };

}

module.exports = new VillageSarpanchService();