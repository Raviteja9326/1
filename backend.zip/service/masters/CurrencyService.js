var currencyDAO = require('../../dao/masters/CurrencyDAO');

function CurrencyService() {
	this.getAllCurrency = function (res) {
		// console.log('in CurrencyService.getAllCurrency');
		return currencyDAO.getAllCurrency(res);
	};

	this.getCurrencyById = function (currencyId, res) {
		return currencyDAO.getCurrencyById(currencyId, res);
	};

	this.createCurrency = function (req, res) {
		currencyDAO
			.checkCurrencyExists(req.body.TblCountry_CountryID, res)
			.then(() => {
				return currencyDAO.createCurrency(req, res);
			})
			.catch(() => {
				res.json({
					serverErrorCurrencyExistence:
						'Currency already exists with same name!. Plz enter a different currency name'
				});
			});
	};

	this.updateCurrencyById = function (req, currencyId, res) {
		return currencyDAO.updateCurrencyById(req, currencyId, res);

	};
	this.deleteCurrencyById = function (currencyId, res) {
		return currencyDAO.deleteCurrencyById(currencyId, res);
	};
}

module.exports = new CurrencyService();
