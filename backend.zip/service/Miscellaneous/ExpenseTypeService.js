var ExpensetypeDAO = require("../../dao/Miscellaneous/ExpenseTypeDAO")
//for get 
function ExpensetypeService() {
  this.getAllexpensetype = function (req, res) {
    return ExpensetypeDAO.getAllexpensetype(req, res);
  }

  //for get id
  this.getexpensetypeId = function (Id, res) {
    // console.log("testing in service", Id);
    return ExpensetypeDAO.getexpensetypeId(Id, res);
  };

  //for post
  this.createexpensetype = function (req, res) {
    ExpensetypeDAO.checkexpensetypeExists(req.body.ExpenseTypes)
      .then(() => {
        return ExpensetypeDAO.createexpensetype(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "ExpenseTypes  already exists with same name!. Plz enter a different ExpenseTypes " });
      });
  };
  //for update

  this.updateById = function (req, expensetypeId, res) {
    return ExpensetypeDAO.updateById(req, expensetypeId, res);
  };

  //for delete
  this.deleteById = function (expensetypeId, res) {
    // console.log("im from service", expensetypeId);
    return ExpensetypeDAO.deleteById(expensetypeId, res);
  };
}

module.exports = new ExpensetypeService();