var labourHoursDAO = require('../../dao/Miscellaneous/LabourHoursDAO');
function LabourHoursService() {
	this.createLabourHours = function (req, res) {
		labourHoursDAO
			.checkLabourHours(req.body.Date)
			.then(() => {
				return labourHoursDAO.createLabourHours(req, res);
			})
			.catch(() => {
				res.json({ serverErrorStateExistence: 'LabourHours  with given date Already Exists' });
			});
	};
	this.getLabourHours = function (req, res) {
		return labourHoursDAO.getLabourHours(req, res);
	};
	this.getAllAlbourActys = function (req, res) {
		return labourHoursDAO.getAllAlbourActys(req, res);
	};
	this.getlabourhoursByDate = function (req, res) {
		return labourHoursDAO.getlabourhoursByDate(req, res);
	};
	this.getLabourHoursByID = function (labourID, res) {
		return labourHoursDAO.getLabourHoursByID(labourID, res);
	};
}

module.exports = new LabourHoursService();
