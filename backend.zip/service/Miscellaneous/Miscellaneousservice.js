var miscellaneousDAO = require("../../dao/Miscellaneous/MiscellaneousDAO");
//for get
function miscellaneousService() {
  this.getAllmiscellaneous = function (req, res) {
    return miscellaneousDAO.getAllmiscellaneous(req, res);
  };

  //for get id
  this.getmiscellaneousId = function (Id, res) {
    // console.log("testing in service", Id);
    return miscellaneousDAO.getmiscellaneousId(Id, res);
  };
  //for post
  this.createmiscellaneous = function (req, res) {
    return miscellaneousDAO.createmiscellaneous(req, res);
  };

  //for update

  this.updateById = function (req, miscellaneousId, res) {
    // console.log("im from service", miscellaneousId);
    return miscellaneousDAO.updateById(req, miscellaneousId, res);
  };

  //for delete
  this.deleteById = function (miscellaneousId, res) {
    // console.log("im from service", miscellaneousId);
    return miscellaneousDAO.deleteById(miscellaneousId, res);
  };
}

module.exports = new miscellaneousService();
