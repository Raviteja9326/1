var farmerDataDAO = require("../../dao/farmerinformation/FarmerDataDAO");

function FarmerDataService() {

  this.getAllfarmerQrData = function (res) {
    return farmerDataDAO.getAllfarmerQrData(res);
  };

  this.getFarmerDataByUser = (userID, res) => {
    return farmerDataDAO.getFarmerDataByUser(userID, res)
  }

  this.getAllfarmerData = function (res) {
    return farmerDataDAO.getAllfarmerData(res);
  };

  this.getFarmerDataById = function (farmerId, res) {
    return farmerDataDAO.getFarmerDataById(farmerId, res);
  };

  this.createfarmer = function (req, res) {
    return farmerDataDAO.createfarmer(req, res);
  };

  this.updateFarmerData = function (req, farmerId, res) {
    return farmerDataDAO.updateFarmerData(req, farmerId, res);
  };
  this.removeFarmer = function (farmerId, res) {
    return farmerDataDAO.removeFarmer(farmerId, res);
  };

  this.getDataForQR = function (farmername, res) {
    return farmerDataDAO.getDataForQR(farmername, res);
  };
}

module.exports = new FarmerDataService();
