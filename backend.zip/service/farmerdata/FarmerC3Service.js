var farmerc3DAO = require('../../dao/farmerinformation/FarmerC3DAO');
function FarmerC3Service() {
    this.getAllFarmerC3 = function (req, res) {
        return farmerc3DAO.getAllFarmerC3(req, res);
    }
    this.createFramerC3 = function (req, res) {
        return farmerc3DAO.createFramerC3(req, res);
    }
    this.removefarmerc3 - function (farmerc3Id, res) {
        return farmerc3DAO.removefarmerc3(farmerc3Id, res);
    }
}
module.exports = new FarmerC3Service();