var LabourDAO = require("../../dao/farmerinformation/LabourDAO")
//for get 
function LabourService() {
  this.getAlllabour = function (req, res) {
    return LabourDAO.getAlllabour(req, res);
  }

  //for get id
  this.getlabourById = function (Id, res) {
    // console.log("testing in service",Id);
    return LabourDAO.getlabourById(Id, res);
  };

  //for post
  this.createLabour = function (req, res) {
    LabourDAO.checkLabourExists(req.body.FullName)
      .then(() => {
        return LabourDAO.createLabour(req, res);
      })
      .catch(() => {
        res.json({ serverErrorStateExistence: "Labour already exists with same name!. Plz enter a different labour " });
      });
  };
  //for update

  this.updateById = function (req, labourId, res) {
    // console.log("im from service",labourId);
    return LabourDAO.updateById(req, labourId, res);
  };

  //for delete
  this.deleteById = function (labourId, res) {
    return LabourDAO.deleteById(labourId, res);
  };
}

module.exports = new LabourService();