const req = require('request-promise');

var sendTextLocalSMS = function() {
	this.mobileMessage = async function(mobileNumber, MSG_TEMPLATE) {
		let options = {
			apikey: process.env.TEXT_LOCAL_API_KEY,

			sender: process.env.TEXT_LOCAL_SENDER,
			message: MSG_TEMPLATE,
			numbers: mobileNumber
		};

		return new Promise((resolve, reject) => {
			req.post({ url: process.env.TEXT_LOCAL_HOST, form: options }, (error, response, body) => {
				if (error) {
					 reject(error);
				}
				resolve( body );
			});
		});
	};
};

module.exports = new sendTextLocalSMS();
