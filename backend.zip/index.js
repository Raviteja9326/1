var morgan = require('morgan');
var express = require("express");
var app = express();
var cors = require("cors");
var bodyParser = require('body-parser');

const path = require('path');
const { handleError } = require('./error');

app.use(morgan('dev'));

app.use((err, req, res, next) => {
	handleError(err, res);
});

app.use("/public", express.static(path.join(__dirname, "public")));

app.use(cors({ origin: "*" }));

app.use(express.json());

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: false }));

app.use((req, res, next) => {
	res.set({ 'content-type': 'application/json; charset=utf-8' });
	res.header("Content-Type", "application/json; charset=utf-8");
	res.header("Access-Control-Allow-Origin", "*");
	res.charset = 'utf-8';
	next();
});

var statesroutes = require('./routes/masters/states');
var villageroutes = require('./routes/masters/villages');
var mandalroutes = require('./routes/masters/mandals');
var districtroutes = require('./routes/masters/districts');
var countryroutes = require('./routes/masters/countries');
var currencyroutes = require('./routes/masters/currency');
var villagesarpanchroutes = require('./routes/masters/villagesarpanch');
var c3officeroutes = require('./routes/masters/c3office');
var revenuedivisionroutes = require('./routes/masters/revenuedivision');
var isocodesroutes = require('./routes/masters/isocodes');
var pitroutes = require('./routes/AssetManagement/pit');
var vermicompostpitroutes = require('./routes/AssetManagement/vermiCompostpit');
var vermicompostcoproutes = require('./routes/AssetManagement/Vermicompostcop');
var vermicompostcycleroutes = require('./routes/AssetManagement/Vermicompostcycle');
var machineryroutes = require('./routes/AssetManagement/machinery');
var Shedroutes = require('./routes/AssetManagement/Shed');
var irregationroutes = require('./routes/AssetManagement/irregation');
var cropcategoryroutes = require('./routes/Cropdata/cropCategory');
var cropmasterroutes = require('./routes/Cropdata/cropMaster');
var cropcoproutes = require('./routes/Cropdata/cropCOP');
var cropcycleroutes = require('./routes/Cropdata/cropCycle');
var animalbreedroutes = require('./routes/animaldata/animalbreed');
var animalcategoryroutes = require('./routes/animaldata/animalCategory');
var animalmasterroutes = require('./routes/animaldata/animalMaster');
var animalcycleroutes = require('./routes/animaldata/animalcycle');
var vaccinationroutes = require('./routes/animaldata/vaccination');
var companymasterroutes = require('./routes/FarmData/companymaster');
var fertilizersroutes = require('./routes/FarmData/fertilizers');
var pesticidesroutes = require('./routes/FarmData/pesticides');
var dealerroutes = require('./routes/Raw Material/dealer');
var stockroutes = require('./routes/Raw Material/stock');
var inventoryroutes = require('./routes/Raw Material/inventory');
var bomroutes = require('./routes/Raw Material/bom');
var farmerdataroutes = require('./routes/farmerinformation/farmerData');
var landLayoutroutes = require('./routes/landdata/landLayout');
var plottingroutes = require('./routes/landdata/plotting');
var croplinesroutes = require('./routes/landdata/croplines');
var farmerc3routes = require('./routes/farmerinformation/farmerC3');
var loanroutes = require('./routes/LoanData/loan');
var loanemiroutes = require('./routes/LoanData/loanEMI');
var labourroutes = require('./routes/farmerinformation/labour');
var labourhoursroutes = require('./routes/Miscellaneous/labourhours');
var animalcycleroutes = require('./routes/animaldata/animalcycle');
var expensetyperoutes = require('./routes/Miscellaneous/ExpenseType');
var supplierroutes = require('./routes/AssetManagement/SupplierType');
var miscellaneous = require('./routes/Miscellaneous/Miscellaneous');
var riskdropdownroutes = require('./routes/riskmangement/riskdropdown');
var riskmanagementroutes = require('./routes/riskmangement/riskmanagement');
var riskactivitesroutes = require('./routes/riskmangement/riskactivites');
var soiltyperoutes = require('./routes/SoilData/soiltype');
var soilcategoryroutes = require('./routes/SoilData/soilCategory');
var soilnutrientroutes = require('./routes/SoilData/soilnutrient');
var watercategoryroutes = require('./routes/WaterData//waterCategory');
var watermasterroutes = require('./routes/WaterData/waterMaster');
var watertestdataroutes = require('./routes/WaterData/watertestdata');
var userroutes = require('./routes/cas/users');
var soilTestDataRoutes = require('./routes/SoilData/soilTestData');
var soilCorrectiveActions = require('./routes/SoilData/SoilCorrectiveActions');
var roleRoutes = require('./routes/cas/roles');
var followuproutes = require('./routes/consultexpert/correctionfollowup');
var anmialcycleroutes = require('./routes/animaldata/animalcycle');
var animalcoproutes = require('./routes/animaldata/animalCop');
var CropDisease = require('./routes/DiseasData/cropDisease');
var Disease = require('./routes/DiseasData/Disease');
var CropReportDisease = require('./routes/DiseasData/cropReportDisease');
var ConsultExpert = require('./routes/consultexpert/ConsultExpert');
var AnimalDisease = require('./routes/DiseasData/animalDisease');
var AnimalReportDisease = require('./routes/DiseasData/animalReportDisease');
var checklist = require('./routes/checklist/qcimodule');


app.use(
	'/',
	checklist,
	CropDisease,
	Disease,
	CropReportDisease,
	ConsultExpert,
	AnimalDisease,
	AnimalReportDisease,
	userroutes,
	soilTestDataRoutes,
	soilCorrectiveActions,
	roleRoutes,
	followuproutes,
	anmialcycleroutes,
	animalcoproutes,
	watertestdataroutes,
	statesroutes,
	villageroutes,
	mandalroutes,
	districtroutes,
	isocodesroutes,
	countryroutes,
	currencyroutes,
	villagesarpanchroutes,
	c3officeroutes,
	revenuedivisionroutes,
	pitroutes,
	vermicompostpitroutes,
	vermicompostcoproutes,
	vermicompostcycleroutes,
	machineryroutes,
	Shedroutes,
	irregationroutes,
	cropcategoryroutes,
	animalbreedroutes,
	animalcategoryroutes,
	animalmasterroutes,
	cropmasterroutes,
	animalcycleroutes,
	cropcoproutes,
	cropcycleroutes,
	companymasterroutes,
	fertilizersroutes,
	pesticidesroutes,
	dealerroutes,
	vaccinationroutes,
	farmerdataroutes,
	landLayoutroutes,
	plottingroutes,
	croplinesroutes,
	farmerc3routes,
	loanroutes,
	loanemiroutes,
	labourroutes,
	animalcycleroutes,
	labourhoursroutes,
	dealerroutes,
	stockroutes,
	inventoryroutes,
	expensetyperoutes,
	supplierroutes,
	miscellaneous,
	riskdropdownroutes,
	riskmanagementroutes,
	riskactivitesroutes,
	soiltyperoutes,
	soilcategoryroutes,
	soilnutrientroutes,
	watercategoryroutes,
	watermasterroutes,
	bomroutes
);

app.listen(3200, '139.59.67.91');
console.log('Server running at http://139.59.67.91:3200/');

module.exports = app;
