var express = require('express');
var labourhourroutes = require('express').Router();
var labourHoursService = require('../../service/Miscellaneous/LabourHoursService');
var bodyparser = require('body-parser');

labourhourroutes.use(bodyparser.json());

labourhourroutes.post('/labourhours/create', function (req, res) {
	labourHoursService.createLabourHours(req, res);
});

labourhourroutes.post('/labourhours/getlabourhoursbydate', function (req, res) {
	labourHoursService.getlabourhoursByDate(req, res);
});

labourhourroutes.get('/labourhours/:labourID', function (req, res) {
	if (req.params.labourID >= 0) labourHoursService.getLabourHoursByID(req.params.labourID, res);
	else if (req.params.labourID == 'all') labourHoursService.getLabourHours(req, res);
	else {
		res.json('Entered Path is Incorrect');
	}
});
labourhourroutes.get('/labouractivities/all', function (req, res) {
	labourHoursService.getAllAlbourActys(req, res);
});
module.exports = labourhourroutes;
