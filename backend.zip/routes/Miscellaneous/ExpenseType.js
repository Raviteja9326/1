var express = require("express")
var expensetypesroutes = require('express').Router();
var bodyparser = require("body-parser");
var ExpensetypesService = require('../../service/Miscellaneous/ExpenseTypeService');



//for get
expensetypesroutes.use(bodyparser.json());
expensetypesroutes.get("/expensetype/:expensetypeId", function (req, res) {
  // console.log("in /expensetype route, Id ", req.params.expensetypeId);
  if (req.params.expensetypeId >= 1)
    ExpensetypesService.getexpensetypeId(req.params.expensetypeId, res);
  else if (req.params.expensetypeId == "all") ExpensetypesService.getAllexpensetype(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
expensetypesroutes.post("/expensetype/create", function (req, res) {
  // console.log("create body=", req.body);
  ExpensetypesService.createexpensetype(req, res);
});

//for update
expensetypesroutes.put("/expensetype/update/:expensetypeId", function (req, res) {
  // console.log(req.params.expensetypeId);
  ExpensetypesService.updateById(req, req.params.expensetypeId, res);
});

//for delete
expensetypesroutes.delete("/expensetype/delete/:expensetypeId", function (req, res) {
  ExpensetypesService.deleteById(req.params.expensetypeId, res);
});

module.exports = expensetypesroutes;