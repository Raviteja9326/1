var express = require("express");
var miscellaneousroutes = require("express").Router();
var bodyparser = require("body-parser");
var miscellaneousService = require("../../service/Miscellaneous/Miscellaneousservice");

//for get
miscellaneousroutes.use(bodyparser.json());
miscellaneousroutes.get("/miscellaneous/:miscellaneousId", function (req, res) {
  // console.log("in /miscellaneous route, Id ", req.params.miscellaneousId);
  if (req.params.miscellaneousId >= 1)
    miscellaneousService.getmiscellaneousId(req.params.miscellaneousId, res);
  else if (req.params.miscellaneousId == "all")
    miscellaneousService.getAllmiscellaneous(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
miscellaneousroutes.post("/miscellaneous/create", function (req, res) {
  // console.log("create body=", req.body);
  miscellaneousService.createmiscellaneous(req, res);
});

//for update
miscellaneousroutes.put("/miscellaneous/update/:miscellaneousId", function (req, res) {
  // console.log(req.params.miscellaneousId);
  miscellaneousService.updateById(req, req.params.miscellaneousId, res);
});

//for delete
miscellaneousroutes.delete("/miscellaneous/delete/:miscellaneousId", function (req, res) {
  miscellaneousService.deleteById(req.params.miscellaneousId, res);
});

module.exports = miscellaneousroutes;
