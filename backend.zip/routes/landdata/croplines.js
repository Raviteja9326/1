var express = require("express");
var croplinesroutes = require('express').Router();
var bodyparser = require("body-parser");
var croplinesService = require("../../service/landdata/croplinesService");

croplinesroutes.use(bodyparser.json());

croplinesroutes.get('/croplines/:croplinesId', function (req, res) {
    if (req.params.croplinesId >= 1) croplinesService.getcroplinesById(req.params.croplinesId, res);
    else if (req.params.croplinesId == "all") croplinesService.getAllcroplines(res);
    else res.json("Entered Path Is Incorrect");

});

croplinesroutes.get("/croplines/getcroplinesByLandId/:landId", function (req, res) {
    croplinesService.getcroplinesByLandId(req.params.landId, res);

});

croplinesroutes.get("/croplines/getcroplinesByPlottingId/:plottingID", function (req, res) {
    croplinesService.getcroplinesByPlottingId(req.params.plottingID, res);

});


croplinesroutes.post('/croplines/create', function (req, res) {
    croplinesService.createcroplines(req, res);
})

croplinesroutes.put('/croplines/update/:croplinesId', function (req, res) {
    croplinesService.updatecroplinesById(req, req.params.croplinesId, res);
})

croplinesroutes.delete('/croplines/delete/:croplinesId', function (req, res) {
    croplinesService.deletecroplinesById(req.params.croplinesId, res);
})






module.exports = croplinesroutes;