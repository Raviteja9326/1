var express = require("express");
var plottingroutes = require('express').Router();
var bodyparser = require("body-parser");
var plottingService = require("../../service/landdata/plottingService");

plottingroutes.use(bodyparser.json());

plottingroutes.get('/plotting/:plottingId', function (req, res) {
    if (req.params.plottingId >= 1) plottingService.getplottingById(req.params.plottingId, res);
    else if (req.params.plottingId == "all") plottingService.getAllplotting(res);
    else res.json("Entered Path Is Incorrect");

});

plottingroutes.get("/plotting/getplottingByLandId/:LandId", function (req, res) {
    // console.log("create body=", req.body);
    plottingService.getplottingByLandId(req.params.LandId, res);
});

plottingroutes.post('/plotting/create', function (req, res) {
    plottingService.createplotting(req, res);
})

plottingroutes.put('/plotting/update/:plottingId', function (req, res) {
    plottingService.updateplottingById(req, req.params.plottingId, res);
})

plottingroutes.delete('/plotting/delete/:plottingId', function (req, res) {
    plottingService.deleteplottingById(req.params.plottingId, res);
})






module.exports = plottingroutes;