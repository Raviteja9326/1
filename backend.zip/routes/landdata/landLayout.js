var express = require("express");
var landLayoutroutes = require('express').Router();
var bodyparser = require("body-parser");
var landLayoutService = require("../../service/landdata/landLayoutService");

landLayoutroutes.use(bodyparser.json());

landLayoutroutes.get('/landlayout/:landlayoutId', function (req, res) {
    if (req.params.landlayoutId >= 1) landLayoutService.getlandLayoutById(req.params.landlayoutId, res);
    else if (req.params.landlayoutId == "all") landLayoutService.getAlllandLayout(res);
    else res.json("Entered Path Is Incorrect");

});

landLayoutroutes.get("/landlayout/getlandlayoutByFarmerId/:FarmerId", function (req, res) {
    // console.log("create body=", req.body);
    landLayoutService.getlandlayoutByFarmerId(req.params.FarmerId, res);
});

landLayoutroutes.post('/landlayout/create', function (req, res) {
    landLayoutService.createlandLayout(req, res);
})

landLayoutroutes.put('/landlayout/update/:landlayoutId', function (req, res) {
    landLayoutService.updatelandLayoutById(req, req.params.landlayoutId, res);
})

landLayoutroutes.delete('/landlayout/delete/:landlayoutId', function (req, res) {
    landLayoutService.deletelandLayoutById(req.params.landlayoutId, res);
})






module.exports = landLayoutroutes;