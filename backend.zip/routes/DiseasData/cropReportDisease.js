var express = require('express');
var cropreportdiseaseroutes = require('express').Router();
var cropReportDiseaseService = require('../../service/DiseasData/CropReportDiseaseService');
var bodyparser = require('body-parser');

cropreportdiseaseroutes.use(bodyparser.json());
cropreportdiseaseroutes.get('/cropreportdisease/:cropreportdiseaseId', function (req, res) {
    if (req.params.cropreportdiseaseId >= 1) cropReportDiseaseService.getCropReportDiseaseById(req.params.cropreportdiseaseId, res)
    else if (req.params.cropreportdiseaseId == "all") cropReportDiseaseService.getAllCropReportDisease(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

cropreportdiseaseroutes.post("/cropreportdisease/create", function (req, res) {
    cropReportDiseaseService.createCropReportDisease(req, res);
});

cropreportdiseaseroutes.put("/cropreportdisease/update/:cropreportdiseaseId", function (req, res) {
    cropReportDiseaseService.updateCropReportDisease(req.params.cropreportdiseaseId, req, res);
});

cropreportdiseaseroutes.delete("/cropreportdisease/delete/:cropreportdiseaseId", function (req, res) {
    cropReportDiseaseService.removeCropReportDisease(req.params.cropreportdiseaseId, res);
})



module.exports = cropreportdiseaseroutes;