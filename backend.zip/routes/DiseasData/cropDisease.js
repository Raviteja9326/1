var express = require('express');
var cropdiseaseroutes = require('express').Router();
var cropDiseaseService = require('../../service/DiseasData/CropDiseaseService');
var bodyparser = require('body-parser');

cropdiseaseroutes.use(bodyparser.json());
cropdiseaseroutes.get('/cropdisease/:cropdiseaseId', function (req, res) {
    if (req.params.cropdiseaseId >= 1) cropDiseaseService.getCropDiseaseById(req.params.cropdiseaseId, res)
    else if (req.params.cropdiseaseId == "all") cropDiseaseService.getAllCropDisease(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

cropdiseaseroutes.post("/cropdisease/create", function (req, res) {
    cropDiseaseService.createCropDisease(req, res);
});

cropdiseaseroutes.put("/cropdisease/update/:cropdiseaseId", function (req, res) {
    cropDiseaseService.updateCropDisease(req.params.cropdiseaseId, req, res);
});

cropdiseaseroutes.delete("/cropdisease/delete/:cropdiseaseId", function (req, res) {
    cropDiseaseService.removeCropDisease(req.params.cropdiseaseId, res);
})



module.exports = cropdiseaseroutes;