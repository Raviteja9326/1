var express = require('express');
var animaldiseaseroutes = require('express').Router();
var animalDiseaseService = require('../../service/DiseasData/AnimalDiseaseService');
var bodyparser = require('body-parser');

animaldiseaseroutes.use(bodyparser.json());
animaldiseaseroutes.get('/animaldisease/:animaldiseaseId', function (req, res) {
    if (req.params.animaldiseaseId >= 1) animalDiseaseService.getAnimalDiseaseById(req.params.animaldiseaseId, res)
    else if (req.params.animaldiseaseId == "all") animalDiseaseService.getAllAnimalDisease(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

animaldiseaseroutes.post("/animaldisease/create", function (req, res) {
    animalDiseaseService.createAnimalDisease(req, res);
});

animaldiseaseroutes.put("/animaldisease/update/:animaldiseaseId", function (req, res) {
    animalDiseaseService.updateAnimalDisease(req.params.animaldiseaseId, req, res);
});

animaldiseaseroutes.delete("/animaldisease/delete/:animaldiseaseId", function (req, res) {
    animalDiseaseService.removeAnimalDisease(req.params.animaldiseaseId, res);
})



module.exports = animaldiseaseroutes;