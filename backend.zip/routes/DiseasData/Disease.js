var express = require('express');
var diseaseroutes = require('express').Router();
var diseaseService = require('../../service/DiseasData/DiseasesService');
var bodyparser = require('body-parser');

diseaseroutes.use(bodyparser.json());
diseaseroutes.get('/disease/:diseaseId', function (req, res) {
    if (req.params.diseaseId >= 1) diseaseService.getDiseaseById(req.params.diseaseId, res);
    else if (req.params.diseaseId == "all") diseaseService.getAllDiseases(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

diseaseroutes.post("/disease/create", function (req, res) {
    diseaseService.createDisease(req, res);
});

diseaseroutes.put("/disease/update/:diseaseId", function (req, res) {
    diseaseService.updateDisease(req.params.diseaseId, req, res);
});

diseaseroutes.delete("/disease/delete/:diseaseId", function (req, res) {
    diseaseService.removeDisease(req.params.diseaseId, res);
})
diseaseroutes.get("/type/all", function (req, res) {
    diseaseService.getallDiseaseTypes(req, res);
})
diseaseroutes.get("/croptypedisease/all", function (req, res) {
    diseaseService.getallCropDiseaseTypes(req, res);
})
diseaseroutes.get("/animaltypedisease/all", function (req, res) {
    diseaseService.getallAnimalDiseaseTypes(req, res);
})


module.exports = diseaseroutes; 