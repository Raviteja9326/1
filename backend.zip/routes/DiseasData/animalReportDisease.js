var express = require('express');
var animalreportdiseaseroutes = require('express').Router();
var animalReportDiseaseService = require('../../service/DiseasData/AnimalReportDiseaseService');
var bodyparser = require('body-parser');

animalreportdiseaseroutes.use(bodyparser.json());
animalreportdiseaseroutes.get('/animalreportdisease/:animalreportdiseaseId', function (req, res) {
    if (req.params.animalreportdiseaseId >= 1) animalReportDiseaseService.getAnimalReportDiseaseById(req.params.animalreportdiseaseId, res)
    else if (req.params.animalreportdiseaseId == "all") animalReportDiseaseService.getAllAnimalReportDisease(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

animalreportdiseaseroutes.post("/animalreportdisease/create", function (req, res) {
    animalReportDiseaseService.createAnimalReportDisease(req, res);
});

animalreportdiseaseroutes.put("/animalreportdisease/update/:animalreportdiseaseId", function (req, res) {
    animalReportDiseaseService.updateAnimalReportDisease(req.params.animalreportdiseaseId, req, res);
});

animalreportdiseaseroutes.delete("/animalreportdisease/delete/:animalreportdiseaseId", function (req, res) {
    animalReportDiseaseService.removeAnimalReportDisease(req.params.animalreportdiseaseId, res);
})



module.exports = animalreportdiseaseroutes;