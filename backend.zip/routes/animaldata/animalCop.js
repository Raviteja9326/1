var express = require('express');
var animalcoproutes = require('express').Router();
var animalCOPService = require('../../service/animaldata/AnimalCopService');
var bodyparser = require('body-parser');
var connection = require('../../dao/MySQLConnect');
animalcoproutes.use(bodyparser.json());
animalcoproutes.get('/animalcop/:animalcopId', function (req, res) {
    if (req.params.animalcopId >= 1) animalCOPService.getAnimalCOPById(req.params.animalcopId, res);
    else if (req.params.animalcopId == "all") animalCOPService.getAllAnimalCOP(req, res);
    else res.json("Entered path is Incorrect :-( ");
});


animalcoproutes.post("/animalcop/create", function (req, res) {
    connection.init();
    connection.acquire(function (err, acquiredConnection) {
        if (err) console.log(err);
        var dataToPostAnimalCoptable = {
            COPNO: req.body.COPNO,
            Activity: req.body.Activity,
            AnimalMilestoneID: req.body.AnimalMilestoneID,
            CriticalActivity: req.body.CriticalActivity,
            Dependency: req.body.Dependency,
            Dose: req.body.Dose,
            AgeofDose: req.body.AgeofDose,
            TblAnimalMaster_ID: req.body.TblAnimalMaster_ID,
            created_by: req.body.created_by
        };
        var sql = 'INSERT INTO TBLAnimalCOP SET ?';
        acquiredConnection.query(sql, dataToPostAnimalCoptable, function (err, data) {
            if (err) console.log(err);
            console.log(data, "hfdfff")
            var AnimalCopID = data.insertId;

            for (let index = 0; index <
                req.body.Rawmaterialdata.length; index++) {
                var dataToPostAnimalCopRawmaterialtable = {
                    TblMaterials_ID: req.body.Rawmaterialdata[index].MatName,
                    Quantity: req.body.Rawmaterialdata[index].Quantity,
                    UnitID: req.body.Rawmaterialdata[index].Units,
                    TblAnimalCOP_ID: AnimalCopID
                };
                console.log(dataToPostAnimalCopRawmaterialtable, "helellelele")
                var sql1 = 'INSERT INTO TblAnimalRawMaterial SET ?'
                acquiredConnection.query(sql1, dataToPostAnimalCopRawmaterialtable, function (err, result) {
                    if (err) console.log('error from ', err);
                });
            }
            acquiredConnection.release();
            res.json({ data: 'Success' });
        });

    })
})


animalcoproutes.put("/animalcop/update/:animalcopId", function (req, res) {

    animalCOPService.updateAnimalCOP(req.params.animalcopId, req, res);

});

animalcoproutes.delete("/animalcop/delete/:animalcopId", function (req, res) {
    animalCOPService.removeAnimalCOP(req.params.animalcopId, res);
})

// cropcoproutes.use((err,res,req,next)=>{
//     res.json("some error occured");
// })
module.exports = animalcoproutes;