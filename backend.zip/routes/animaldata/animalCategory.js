var express = require("express")
var animalCategoryroutes = require('express').Router();
var bodyparser = require("body-parser");
var animalCategoryService = require('../../service/animaldata/AnimalCategoryService');


//for get
animalCategoryroutes.use(bodyparser.json());
animalCategoryroutes.get("/animalcategory/:animalcategoryId", function (req, res) {
  // console.log("in /animalCategory route, Id ", req.params.animalcategoryId);
  if (req.params.animalcategoryId >= 1)
    animalCategoryService.getAnimalCategoryById(req.params.animalcategoryId, res);
  else if (req.params.animalcategoryId == "all") animalCategoryService.getAllanimalCategory(req, res);
  else res.json("Entered path is Incorrect ");
});


//for post
animalCategoryroutes.post("/animalcategory/create", function (req, res) {
  // console.log("create body=", req.body);
  animalCategoryService.createAnimalCategory(req, res);
});
//for update
animalCategoryroutes.put("/animalcategory/update/:animalcategoryId", function (req, res) {
  animalCategoryService.updateById(req, req.params.animalcategoryId, res);
});

//for delete
animalCategoryroutes.delete("/animalcategory/delete/:animalcategoryId", function (req, res) {
  animalCategoryService.deleteById(req.params.animalcategoryId, res);
});

module.exports = animalCategoryroutes;
