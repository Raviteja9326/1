const animalmasterroutes = require('express').Router();
const bodyparser = require("body-parser");
const AnimalMasterService = require('../../service/animaldata/AnimalMasterService');
const connection = require('../../dao/MySQLConnect');
const multer = require('multer');
const fs = require('fs');
const path = require('path')


// const storage = multer.diskStorage({
//   destination: function (req, file, callback) {
//     const FarmerID = req.params.FarmerID
//     let dir = `public/images/farmer/${FarmerID}/Animalmaster`;
//     if (!fs.existsSync(dir)) {
//       fs.mkdirSync(dir, { recursive: true });
//     }
//     callback(null, dir)
//   },
//   filename: function (req, file, cb) {
//     cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
//   }

// });
// var upload = multer({ storage: storage }).array('sampleImage', 10);

animalmasterroutes.get("/animalmaster/:animalmasterId", function (req, res) {
  if (req.params.animalmasterId >= 1)
    AnimalMasterService.getanimalmasterId(req.params.animalmasterId, res);
  else if (req.params.animalmasterId == "all") AnimalMasterService.getAllanimalmaster(req, res);
  else res.json("Entered path is Incorrect ");
});

animalmasterroutes.post("/animalmaster/create", function (req, res) {
  AnimalMasterService.createAnimalMaster(req, res);
});


// animalmasterroutes.post('/animalmaster/upload/image/:FarmerID', (req, res) => {
//   upload(req, res, function (err) {
//     if (err) {
//       return res.json({ "data": "something gone wrong" })
//     }
//     else {
//       const multiple = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
//       try {
//         connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multiple]).then((data) => {
//           if (data.insertId > 0) {
//             res.json('Successfully uploaded images');
//           }
//         });
//       } catch (error) {
//         res.json('something went wrong');
//       }
//     }
//   })

// });

//for update
animalmasterroutes.put("/animalmaster/update/:animalmasterId", function (req, res) {
  // console.log(req.params.animalmasterId);
  AnimalMasterService.updateById(req, req.params.animalmasterId, res);
});

//for delete
animalmasterroutes.delete("/animalmaster/delete/:animalmasterId", function (req, res) {
  AnimalMasterService.deleteById(req.params.animalmasterId, res);
});

module.exports = animalmasterroutes;