var express = require("express")
var animalbreedroutes = require('express').Router();
var bodyparser = require("body-parser");
var animalBreedService = require('../../service/animaldata/AnimalBreedservice');


//for get
animalbreedroutes.use(bodyparser.json());
animalbreedroutes.get("/animalbreed/:animalbreedId", function (req, res) {
  // console.log("in /animalbreed route, Id ", req.params.animalbreedId);
  if (req.params.animalbreedId >= 1)
    animalBreedService.getanimalbreedId(req.params.animalbreedId, res);
  else if (req.params.animalbreedId == "all") animalBreedService.getAllanimalbreed(req, res);
  else res.json("Entered path is Incorrect ");
});

animalbreedroutes.get('/animalbreed/getBreedByCatName/:catName', function (req, res) {
  animalBreedService.getBreedByCatName(req.params.catName, res);
});
//for post
animalbreedroutes.post("/animalbreed/create", function (req, res) {
  // console.log("create body=", req.body);
  animalBreedService.createAnimalBreed(req, res);
});

//for update
animalbreedroutes.put("/animalbreed/update/:animalbreedId", function (req, res) {
  animalBreedService.updateById(req, req.params.animalbreedId, res);
});

//for delete
animalbreedroutes.delete("/animalbreed/delete/:animalbreedId", function (req, res) {
  animalBreedService.deleteById(req.params.animalbreedId, res);
});



module.exports = animalbreedroutes;
