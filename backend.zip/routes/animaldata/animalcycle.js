var express = require('express');
var anmialcycleroutes = require('express').Router();
var bodyparser = require('body-parser');
var animalcycleService = require('../../service/animaldata/AnimalcycleService');

//for get
anmialcycleroutes.use(bodyparser.json());
anmialcycleroutes.get('/animalcycle/:animalcycleId', function (req, res) {
	console.log('in /animalcycle route, Id ', req.params.animalcycleId);
	if (req.params.animalcycleId >= 1) animalcycleService.getAnimalCycleById(req.params.animalcycleId, res);
	else if (req.params.animalcycleId == 'all') animalcycleService.getAllAnimalCycle(req, res);
	else res.json('Entered path is Incorrect :-( ');
});

//for post
anmialcycleroutes.post('/animalcycle/create', function (req, res) {
	console.log('create body=', req.body);
	animalcycleService.createAnimalcycle(req, res);
});

//for update
anmialcycleroutes.put('/animalcycle/update/:animalcycleId', function (req, res) {
	animalcycleService.updateById(req, req.params.animalcycleId, res);
});

//for delete
anmialcycleroutes.delete('/animalcycle/delete/:animalcycleId', function (req, res) {
	animalcycleService.deleteById(req.params.animalcycleId, res);
});
module.exports = anmialcycleroutes;
