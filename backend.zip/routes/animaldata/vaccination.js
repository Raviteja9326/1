var express = require('express')
var vaccinationroutes = express.Router();
var bodyparser = require('body-parser');
var vaccinationService = require('../../service/animaldata/VaccinationService');

vaccinationroutes.use(bodyparser.json());
vaccinationroutes.get('/vaccines/:vaccineID', function (req, res) {
    if (req.params.vaccineID >= 1) vaccinationService.getVaccineByID(req.params.vaccineID, res);
    else if (req.params.vaccineID == "all") vaccinationService.getAllVaccines(req, res);
    else {
        res.json('Entered Path is incorrect');
    }
})
vaccinationroutes.post("/vaccines/create", function (req, res) {
    vaccinationService.createVaccines(req, res);
});

vaccinationroutes.put("/vaccines/update/:vaccineID", function (req, res) {
    vaccinationService.updateVaccineById(req, req.params.vaccineID, res);
});

vaccinationroutes.delete("/vaccines/delete/:vaccineID", function (req, res) {
    vaccinationService.deleteVaccineById(req.params.vaccineID, res);
});

module.exports = vaccinationroutes;
