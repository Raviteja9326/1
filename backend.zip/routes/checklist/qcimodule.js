var express = require("express")
var qciroutes = require('express').Router();
var bodyparser = require("body-parser");
var QciService = require('../../service/checklist/QciService');



//for get
qciroutes.use(bodyparser.json());
qciroutes.get("/qcifarmer/:TblQCIModule_ID", function (req, res) {

  if (req.params.TblQCIModule_ID >= 1)
    QciService.getqcifarmerId(req.params.TblQCIModule_ID, res);
  else if (req.params.TblQCIModule_ID == "all") QciService.getAllqcifarmer(req, res);
  else res.json("Entered path is Incorrect ");
});


//for get qcimodules
qciroutes.get("/qcimodule/:qcimoduleID", function (req, res) {

  if (req.params.qcimoduleID >= 1)
    QciService.getqcimoduleId(req.params.qcimoduleID, res);
  else if (req.params.qcimoduleID == "all") QciService.getAllqcimodule(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
qciroutes.post("/qcifarmer/create", function (req, res) {
  QciService.createqcifarmer(req, res);
});

qciroutes.get('/checklist/:farmerId', function (req, res) {
  if (req.params.farmerId >= 1)
    QciService.getfarmerId(req, req.params.farmerId, res);
  else if (req.params.farmerId == "all") QciService.getAllchecklist(req, res);
});

qciroutes.get('/farmerdata/checklist/:farmerID', (req, res) => {
  QciService.getChecklistByfarmerid(req, req.params.farmerID, res);
});

qciroutes.get('/farmerdata/single/:farmerID', (req, res) => {
  QciService.getfarmerid(req, req.params.farmerID, res);
});



module.exports = qciroutes;