var express = require('express');
var followuproutes = express.Router();
var connection = require('../../dao/MySQLConnect');
var correctionfollowupservice = require('../../service/consultexpert/correctionsfollowupservice');

//for get data
followuproutes.get('/CorrectionFollowUpData/all', function (req, res, next) {
	try {
		var sql = 'SELECT * FROM TblCorrectionsFollowUp WHERE isDeleted=1';
		connection.query(sql, function (err, result) {
			if (err) {
				console.log('error', err);
				return next(err);
			}
			res.json(result);
		});
	} catch (error) {
		res.json('error in connecting data base');
	}
});
followuproutes.use((err, req, res, next) => {
	res.json('Some Error Occured');
});

//for post data
followuproutes.post('/CorrectionFollowUpData/create', function (req, res) {
	console.log('this is routing file body', req.body);
	correctionfollowupservice.createCorrectionFollowUp(req, res);
});

//for delete data
followuproutes.delete('/CorrectionFollowUpData/delete/:FollowupID', function (req, res) {
	console.log('ID from routing', req);
	correctionfollowupservice.deleteCorrectionFollowUp(req.params.FollowupID, res);
});

//for update data
followuproutes.put('/CorrectionFollowUpData/update/:FollowupID', function (req, res) {
	console.log('from routing = ', req.body);
	correctionfollowupservice.updateCorrectionFollowUp(req, req.params.FollowupID, res);
});

module.exports = followuproutes;
