var express = require("express")
var consultexportroutes = require('express').Router();
var bodyparser = require("body-parser");
var ConsultExpertService = require('../../service/consultexpert/ConseltExpertService');



//for get
consultexportroutes.use(bodyparser.json());
consultexportroutes.get("/consultexpert/:consultexpertId", function (req, res) {
  console.log("in /animalmaster route, Id ", req.params.consultexpertId);
  if (req.params.consultexpertId >= 1)
    ConsultExpertService.getConsultExpertId(req.params.consultexpertId, res);
  else if (req.params.consultexpertId == "all") ConsultExpertService.getAllconsultExpert(req, res);
  else res.json("Entered path is Incorrect :-( ");
});

//for post
consultexportroutes.post("/consultexpert/create", function (req, res) {
  console.log("create body=", req.body);
  ConsultExpertService.createconsultExpert(req, res);
});

//for update
consultexportroutes.put("/consultexpert/update/:consultexpertId", function (req, res) {
  console.log(req.params.consultexpertId);
  ConsultExpertService.updateById(req, req.params.consultexpertId, res);
});

//for delete
consultexportroutes.delete("/consultexpert/delete/:consultexpertId", function (req, res) {
  ConsultExpertService.deleteById(req.params.consultexpertId, res);
});

module.exports = consultexportroutes;