var express = require('express');
var cropcoproutes = require('express').Router();
var cropCOPService = require('../../service/Cropdata/CropCOPService');
var bodyparser = require('body-parser');
var connection = require('../../dao/MySQLConnect');
cropcoproutes.use(bodyparser.json());
cropcoproutes.get('/cropcop/:cropcopId', function (req, res) {
    if (req.params.cropcopId >= 1) cropCOPService.getCropCOPById(req.params.cropcopId, res);
    else if (req.params.cropcopId == "all") cropCOPService.getAllCropCOP(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

// cropcoproutes.post("/cropcop/create", function (req, res) {
//     cropCOPService.createCropCOP(req, res);
// });
cropcoproutes.post("/cropcop/create", function (req, res) {
    connection.init();
    connection.acquire(function (err, acquiredConnection) {
        if (err) console.log(err);
        var dataToPostCropCoptable = {
            COPNO: req.body.COPNO,
            Activity: req.body.Activity,
            CropMilestoneID: req.body.CropMilestoneID,
            CriticalActivity: req.body.CriticalActivity,
            Dependency: req.body.Dependency,
            Duration: req.body.Duration,
            Season: req.body.Season,
            TblCropMaster_ID: req.body.TblCropMaster_ID,
            created_by: req.body.created_by
        };
        var sql = 'INSERT INTO TblCropCOP SET ?';
        acquiredConnection.query(sql, dataToPostCropCoptable, function (err, data) {
            if (err) console.log(err);
            console.log(data, "hfdfff")
            var CropCopID = data.insertId;

            for (let index = 0; index <
                req.body.Rawmaterialdata.length; index++) {
                var dataToPostCropCopRawmaterialtable = {
                    TblMaterials_ID: req.body.Rawmaterialdata[index].MatName,
                    Quantity: req.body.Rawmaterialdata[index].Quantity,
                    UnitID: req.body.Rawmaterialdata[index].Units,
                    TblCropCop_ID: CropCopID
                };
                console.log(dataToPostCropCopRawmaterialtable, "helellelele")
                var sql1 = 'INSERT INTO TblCOPRawMaterial SET ?'
                acquiredConnection.query(sql1, dataToPostCropCopRawmaterialtable, function (err, result) {
                    if (err) console.log('error from ', err);
                });
            }
            acquiredConnection.release();
            res.json({ data: 'Success' });
        });

    })
})


cropcoproutes.put("/cropcop/update/:cropcopId", function (req, res) {

    cropCOPService.updateCropCOP(req.params.cropcopId, req, res);

});

cropcoproutes.delete("/cropcop/delete/:cropcopId", function (req, res) {
    cropCOPService.removeCropCOP(req.params.cropcopId, res);
})

// cropcoproutes.use((err,res,req,next)=>{
//     res.json("some error occured");
// })
module.exports = cropcoproutes;