var express = require('express');
var cropcycleroutes = require('express').Router();
var cropCycleService = require('../../service/Cropdata/CropCycleService');
var bodyparser = require('body-parser');

cropcycleroutes.use(bodyparser.json());
cropcycleroutes.get('/cropcycle/:cropcycleId', function (req, res) {
    if (req.params.cropcycleId >= 1) cropCycleService.getCropCycleById(req.params.cropcycleId, res);
    else if (req.params.cropcycleId == "all") cropCycleService.getAllCropCycles(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

cropcycleroutes.post("/cropcycle/create", function (req, res) {
    cropCycleService.createCropCycle(req, res);
});

cropcycleroutes.put("/cropcycle/update/:cropcycleId", function (req, res) {
    cropCycleService.updateCropCycle(req.params.cropcycleId, req, res);
});

cropcycleroutes.delete("/cropcycle/delete/:cropcycleId", function (req, res) {
    cropCycleService.removeCropCycle(req.params.cropcycleId, res);
})



module.exports = cropcycleroutes; 