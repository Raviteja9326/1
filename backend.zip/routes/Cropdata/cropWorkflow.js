var express = require('express');
var cropworkflowroutes = require('express').Router();
var cropWorkflowService = require('../../service/Cropdata/CropWorkflowService');
var bodyparser = require('body-parser');

cropworkflowroutes.use(bodyparser.json());
cropworkflowroutes.get('/cropworkflow/:cropworkflowId', function (req, res) {
    if (req.params.cropworkflowId >= 1) cropWorkflowService.getCropWorkflowById(req.params.cropworkflowId, res)
    else if (req.params.cropworkflowId == "all") cropWorkflowService.getAllCropWorkflow(req, res);
    else res.json("Entered path is Incorrect :-( ");
});

cropworkflowroutes.post("/cropworkflow/create", function (req, res) {
    cropWorkflowService.createCropWorkflow(req, res);
});

cropworkflowroutes.put("/cropworkflow/update/:cropworkflowId", function (req, res) {
    cropWorkflowService.updateCropflow(req.params.cropworkflowId, req, res);
});

cropworkflowroutes.delete("/cropworkflow/delete/:cropworkflowId", function (req, res) {
    cropWorkflowService.removeCropflow(req.params.cropworkflowId, res);
})



module.exports = cropworkflowroutes;