var express = require('express');
var cropmasterroutes = require('express').Router();
var bodyparser = require('body-parser');
var cropMasterService = require('../../service/Cropdata/CropMasterService');

cropmasterroutes.use(bodyparser.json());
cropmasterroutes.get('/cropmaster/:cropmasterId', function (req, res) {
    if (req.params.cropmasterId >= 1) cropMasterService.getCropMasterById(req.params.cropmasterId, res)
    else if (req.params.cropmasterId == "all") cropMasterService.getAllCropMasters(req, res);
    else res.json("Entered path is Incorrect ");
});

cropmasterroutes.post("/cropmaster/create", function (req, res) {
    cropMasterService.createCropMaster(req, res);
});

cropmasterroutes.put("/cropmaster/update/:cropmasterId", function (req, res) {
    cropMasterService.updateCropMaster(req.params.cropmasterId, req, res);
});

cropmasterroutes.delete("/cropmaster/delete/:cropmasterId", function (req, res) {
    cropMasterService.removeCropMaster(req.params.cropmasterId, res);
})


module.exports = cropmasterroutes;