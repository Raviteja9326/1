var express = require('express');
var cropcoprawmaterialroutes = require('express').Router();
var cropCOPRawmaterialService = require('../../service/Cropdata/CropCopRawmaterialService');
var bodyparser = require('body-parser');

cropcoprawmaterialroutes.use(bodyparser.json());
cropcoprawmaterialroutes.get('/cropcoprawmaterial/:TblCropCOP_ID', function (req, res) {
    if (req.params.TblCropCOP_ID >= 1) cropCOPRawmaterialService.getCropCOPRawmaterialById(req.params.TblCropCOP_ID, res);
    else if (req.params.TblCropCOP_ID == "all") cropCOPRawmaterialService.getAllCropCOPRawmaterial(req, res);
    else res.json("Entered path is Incorrect :-( ");

});

cropcoprawmaterialroutes.post("/cropcoprawmaterial/create", function (req, res) {
    cropCOPRawmaterialService.createCropCOPRawmaterial(req, res);
});

cropcoprawmaterialroutes.put("/cropcoprawmaterial/update/:cropcoprawmaterlId", function (req, res) {
    cropCOPRawmaterialService.updateCropCOPRawmaterial(req.params.cropcoprawmaterlId, req, res);
});

cropcoprawmaterialroutes.delete("/cropcoprawmaterial/delete/:cropcoprawmaterlId", function (req, res) {
    cropCOPRawmaterialService.removeCropCOPRawmaterial(req.params.cropcoprawmaterlId, res);
})


module.exports = cropcoprawmaterialroutes;