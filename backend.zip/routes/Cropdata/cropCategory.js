var express = require('express');
var cropcategoryroutes = require('express').Router();
var cropCategoryService = require('../../service/Cropdata/CropCategoryService');
var bodyparser = require('body-parser');

cropcategoryroutes.use(bodyparser.json());
cropcategoryroutes.get('/cropcategory/:cropcatId', function (req, res) {
    if (req.params.cropcatId >= 1) cropCategoryService.getCropCategoryById(req.params.cropcatId, res)
    else if (req.params.cropcatId == "all") cropCategoryService.getAllCropCategories(req, res);
    else res.json("Entered path is Incorrect ");
});

cropcategoryroutes.post("/cropcategory/create", function (req, res) {
    cropCategoryService.createCropCategory(req, res);
});

cropcategoryroutes.put("/cropcategory/update/:cropcatId", function (req, res) {
    cropCategoryService.updateCropCategory(req.params.cropcatId, req, res);
});

cropcategoryroutes.delete("/cropcategory/delete/:cropcatId", function (req, res) {
    cropCategoryService.removeCropCategory(req.params.cropcatId, res);
})



module.exports = cropcategoryroutes;