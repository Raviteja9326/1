var express = require("express")
var companymasterroutes = require('express').Router();
var bodyparser = require("body-parser");
var CompanyMasterService = require('../../service/FarmData/CompanyMasterService');



//for get
companymasterroutes.use(bodyparser.json());
companymasterroutes.get("/companymaster/:companymasterId", function (req, res) {
  // console.log("in /companymaster route, Id ", req.params.companymasterId);
  if (req.params.companymasterId >= 1)
    CompanyMasterService.getcompanymasterId(req.params.companymasterId, res);
  else if (req.params.companymasterId == "all") CompanyMasterService.getAllcompanymaster(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
companymasterroutes.post("/companymaster/create", function (req, res) {
  // console.log("create body=", req.body);
  CompanyMasterService.createcompanymaster(req, res);
});

//for update
companymasterroutes.put("/companymaster/update/:companymasterId", function (req, res) {
  // console.log(req.params.companymasterId);
  CompanyMasterService.updateById(req, req.params.companymasterId, res);
});

//for delete
companymasterroutes.delete("/companymaster/delete/:companymasterId", function (req, res) {
  CompanyMasterService.deleteById(req.params.companymasterId, res);
});

module.exports = companymasterroutes;