var express = require("express")
var pesticidesroutes = require('express').Router();
var bodyparser = require("body-parser");
var PesticidesService = require('../../service/FarmData/PesticidesService');



//for get
pesticidesroutes.use(bodyparser.json());
pesticidesroutes.get("/pesticides/:pesticidesId", function (req, res) {
  // console.log("in /pesticides route, Id ", req.params.pesticidesId);
  if (req.params.pesticidesId >= 1)
    PesticidesService.getpesticidesId(req.params.pesticidesId, res);
  else if (req.params.pesticidesId == "all") PesticidesService.getAllpesticides(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
pesticidesroutes.post("/pesticides/create", function (req, res) {
  // console.log("create body=", req.body);
  PesticidesService.createpesticides(req, res); ``
});

//for update
pesticidesroutes.put("/pesticides/update/:pesticidesId", function (req, res) {
  // console.log(req.params.pesticidesId);
  PesticidesService.updateById(req, req.params.pesticidesId, res);
});

//for delete
pesticidesroutes.delete("/pesticides/delete/:pesticidesId", function (req, res) {
  PesticidesService.deleteById(req.params.pesticidesId, res);
});

module.exports = pesticidesroutes;