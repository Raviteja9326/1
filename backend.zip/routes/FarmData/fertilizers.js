var express = require("express")
var fertilizersroutes = require('express').Router();
var bodyparser = require("body-parser");
var FertilizersService = require('../../service/FarmData/FertilizersService');



//for get
fertilizersroutes.use(bodyparser.json());
fertilizersroutes.get("/fertilizers/:fertilizersId", function (req, res) {
  // console.log("in /fertilizers route, Id ", req.params.fertilizersId);
  if (req.params.fertilizersId >= 1)
    FertilizersService.getfertilizersId(req.params.fertilizersId, res);
  else if (req.params.fertilizersId == "all") FertilizersService.getAllfertilizers(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
fertilizersroutes.post("/fertilizers/create", function (req, res) {
  // console.log("create body=", req.body);
  FertilizersService.createfertilizers(req, res);
});

//for update
fertilizersroutes.put("/fertilizers/update/:fertilizersId", function (req, res) {
  // console.log(req.params.fertilizersId);
  FertilizersService.updateById(req, req.params.fertilizersId, res);
});

//for delete
fertilizersroutes.delete("/fertilizers/delete/:fertilizersId", function (req, res) {
  FertilizersService.deleteById(req.params.fertilizersId, res);
});

module.exports = fertilizersroutes;