var express = require('express');
var loanroutes = require('express').Router();
var bodyparser = require('body-parser');
const path = require('path');
var loanService = require('../../service/LoanData/LoanService');
const loanDAO = require('../../dao/LoanData/LoanDAO');
const connection = require('../../dao/MySQLConnect');
// const multer = require('multer');

// const storage = multer.diskStorage({
// 	destination: 'public/images/farmer/loan',
// 	filename: function (req, file, cb) {
// 		cb(null, Date.now() + file.originalname);
// 	}
// });
// const upload = multer({ storage: storage });

loanroutes.use(bodyparser.json());
loanroutes.get('/loan/:loanId', function (req, res) {
	if (req.params.loanId >= 1) loanService.getLoanById(req.params.loanId, res);
	else if (req.params.loanId == 'all') loanService.getAllLoans(req, res);
	else res.json('Entered path is Incorrect ');
});

loanroutes.post('/loan/create', function (req, res) {
	loanService.createLoan(req, res);
});

loanroutes.put('/loan/update/:loanId', function (req, res) {
	loanService.updateLoan(req.params.loanId, req, res);
});

loanroutes.delete('/loan/delete/:loanId', function (req, res) {
	loanService.removeLoan(req.params.loanId, res);
});

loanroutes.get('/paymentfrequency/all', function (req, res) {
	loanService.getAllPaymentFrequency(req, res);
});

loanroutes.get('/loan/user/:userID', (req, res) => {
	loanDAO.getLoanDataByUser(req.params.userID, res);
});

// loanroutes.post('/Loan/upload/image', upload.array('Location', 10), function (req, res) {
// 	var dataToPost = {
// 		Activity: req.body.Activity,
// 		FarmerID: req.body.FarmerID,
// 	};
// 	try {
// 		connection.query('INSERT INTO TblImage SET ?', dataToPost).then((data) => {
// 			if (data.insertId > 0) {
// 				res.json('Successfully uploaded images');
// 			}
// 		});
// 	} catch (error) {
// 		res.json('something went wrong');
// 	}
// });

// loanroutes.get('/loan/uploaded/image/:id', (req, res) => {
// 	try {
// 		connection
// 			.query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='Loan' AND FarmerID=${req.params.id}`)
// 			.then((data) => {
// 				console.log(data);
// 				var dataToSubmit = data.map((da) => {
// 					return {
// 						Actiity: da.Actiity,
// 						Image: da.Location,
// 						FarmerID: da.FarmerID
// 					};
// 				});
// 				// var dataToSubmit = {
// 				// 	Actiity: data[0].Actiity,sri
// 				// 	Image: data[0].Location,
// 				// 	FarmerID: data[0].FarmerID
// 				// };
// 				res.json({ status: true, data: dataToSubmit, message: '' });
// 			})
// 			.catch((err) => {
// 				res.json('Internal server error');
// 			});
// 	} catch (error) {
// 		res.json('Something went wrong');
// 	}
// });
module.exports = loanroutes;
