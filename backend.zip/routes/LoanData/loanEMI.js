var express = require('express');
var loanemiroutes = require('express').Router();
var bodyparser = require('body-parser');
var loanEMIService = require('../../service/LoanData/LoanEMIService');
const loanEMIDAO = require('../../dao/LoanData/LoanEMIDAO');

loanemiroutes.use(bodyparser.json());

loanemiroutes.get('/loanEMI/:loanEMIId', function(req, res) {
	if (req.params.loanEMIId >= 1) loanEMIService.getLoanEMIById(req.params.loanEMIId, res);
	else if (req.params.loanEMIId == 'all') loanEMIService.getAllLoanEMI(res);
	else res.json('Entered Path Is Incorrect');
});

loanemiroutes.post('/loanEMI/create', function(req, res) {
	loanEMIService.createLoanEMI(req, res);
});

loanemiroutes.put('/loanEMI/update/:loanEMIId', function(req, res) {
	loanEMIService.updateLoanEMI(req.params.loanEMIId, req, res);
});

loanemiroutes.delete('/loanEMI/delete/:loanEMIId', function(req, res) {
	loanEMIService.removeLoanEMI(req.params.loanEMIId, res);
});

loanemiroutes.get('/loanEMI/user/:userID', (req, res) => {
	loanEMIDAO.getLoanEMIDataByUser(req.params.userID, res);
});

module.exports = loanemiroutes;
