var express = require("express")
var soilnutrientroutes = require('express').Router();
var bodyparser = require("body-parser");
var soilNutrientService = require('../../service/SoilData/SoilNutrientService');


//for get
soilnutrientroutes.use(bodyparser.json());
soilnutrientroutes.get("/soilnutrient/:soilnutrientId", function (req, res) {
  // console.log("in /soilnutrient route, Id ", req.params.soilnutrientId);
  if (req.params.soilnutrientId >= 1) soilNutrientService.getSoilNutrientById(req.params.soilnutrientId, res);
  else if (req.params.soilnutrientId == "all") soilNutrientService.getAllSoilNutrient(req, res);
  else res.json("Entered path is Incorrect ");
});


//for post
soilnutrientroutes.post("/soilnutrient/create", function (req, res) {
  // console.log("create body=", req.body);
  soilNutrientService.createSoilNutrient(req, res);
});
//for update
soilnutrientroutes.put("/soilnutrient/update/:soilnutrientId", function (req, res) {
  soilNutrientService.updateById(req, req.params.soilnutrientId, res);
});

//for delete
soilnutrientroutes.delete("/soilnutrient/delete/:soilnutrientId", function (req, res) {
  soilNutrientService.deleteById(req.params.soilnutrientId, res);
});

module.exports = soilnutrientroutes;