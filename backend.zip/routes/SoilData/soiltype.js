var express = require("express")
var soiltyperoutes = require('express').Router();
var bodyparser = require("body-parser");
var soilTypeService = require('../../service/SoilData/SoilTypeService');



//for get
soiltyperoutes.use(bodyparser.json());
soiltyperoutes.get("/soiltype/:soiltypeId", function (req, res) {
  // console.log("in /soiltype route, Id ", req.params.soiltypeId);
  if (req.params.soiltypeId >= 1)
    soilTypeService.getSoilTypeById(req.params.soiltypeId, res);
  else if (req.params.soiltypeId == "all") soilTypeService.getAllSoilType(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
soiltyperoutes.post("/soiltype/create", function (req, res) {
  // console.log("create body=", req.body);
  soilTypeService.createSoilType(req, res);
});

//for update
soiltyperoutes.put("/soiltype/update/:soiltypeId", function (req, res) {
  soilTypeService.updateById(req, req.params.soiltypeId, res);
});

//for delete
soiltyperoutes.delete("/soiltype/delete/:soiltypeId", function (req, res) {
  soilTypeService.deleteById(req.params.soiltypeId, res);
});
module.exports = soiltyperoutes;
