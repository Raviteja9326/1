var express = require('express');
var bodyparser = require('body-parser');
var SoilCorrectiveActionsRoutes = require('express').Router();
var SoilCorrectiveActionsService = require('../../service/SoilData/SoilCorrectiveActionsService');

SoilCorrectiveActionsRoutes.use(bodyparser.json());
//for get
SoilCorrectiveActionsRoutes.get('/SoilCorrectiveActions/:SoilCorrectiveId', function (req, res) {
	console.log('gellojkgsadjfgagf', req.body.TblSoilTestData_ID);
	if (req.params.SoilCorrectiveId >= 1)
		SoilCorrectiveActionsService.getSoilCorrectiveActionByID(req.params.SoilCorrectiveId, res);
	else if (req.params.SoilCorrectiveId == 'all') SoilCorrectiveActionsService.getAllSoilCorrectiveAction(req, res);
	else res.json('Entered path is Incorrect :-(');
});

//for get by soiltestdata id
SoilCorrectiveActionsRoutes.get('/SoilCorrectiveActions/SoiltestdataByID/:TblSoilTestData_ID', function (req, res) {
	console.log('gellojkgsadjfgagf', req.body.TblSoilTestData_ID);
	SoilCorrectiveActionsService.getSoilTestDataByID(req.params.TblSoilTestData_ID, res);
});

// for post
SoilCorrectiveActionsRoutes.post('/SoilCorrectiveActions/create', function (req, res) {
	// console.log('create data', req);
	SoilCorrectiveActionsService.createSoilCorrectiveAction(req, res);
});

//for update
SoilCorrectiveActionsRoutes.put('/SoilCorrectiveActions/update/:SoilCorrectiveId', function (req, res) {
	SoilCorrectiveActionsService.updateSoilCorrectiveActionByID(req, req.params.SoilCorrectiveId, res);
});

//for delete
SoilCorrectiveActionsRoutes.delete('/SoilCorrectiveActions/delete/:SoilCorrectiveId', function (req, res) {
	SoilCorrectiveActionsService.deleteSoilCorrectiveActionByID(req.params.SoilCorrectiveId, res);
});

module.exports = SoilCorrectiveActionsRoutes;
