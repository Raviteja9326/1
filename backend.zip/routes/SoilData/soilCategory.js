var express = require("express")
var soilcategoryroutes = require('express').Router();
var bodyparser = require("body-parser");
var soilCategoryService = require('../../service/SoilData/SoilCategoryService');


//for get
soilcategoryroutes.use(bodyparser.json());
soilcategoryroutes.get("/soilcategory/:soilcategoryId", function (req, res) {
  // console.log("in /soilCategory route, Id ", req.params.soilcategoryId);
  if (req.params.soilcategoryId >= 1)
    soilCategoryService.getSoilCategoryById(req.params.soilcategoryId, res);
  else if (req.params.soilcategoryId == "all") soilCategoryService.getAllSoilCategory(req, res);
  else res.json("Entered path is Incorrect ");
});


//for post
soilcategoryroutes.post("/soilcategory/create", function (req, res) {
  // console.log("create body=", req.body);
  soilCategoryService.createSoilCategory(req, res);
});

//for update
soilcategoryroutes.put("/soilcategory/update/:soilcategoryId", function (req, res) {
  soilCategoryService.updateById(req, req.params.soilcategoryId, res);
});

//for delete
soilcategoryroutes.delete("/soilcategory/delete/:soilcategoryId", function (req, res) {
  soilCategoryService.deleteById(req.params.soilcategoryId, res);
});



module.exports = soilcategoryroutes;
