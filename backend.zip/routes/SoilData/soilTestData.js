var express = require('express');
var soilTestDataRoutes = require('express').Router();
var soilTestDataService = require('../../service/SoilData/SoilTestDataService');
var bodyparser = require('body-parser');

var connection = require('../../dao/MySQLConnect');
soilTestDataRoutes.use(bodyparser.json());

//for get soiltestdata
soilTestDataRoutes.get('/soiltestdata/:soildataid', function (req, res) {
	if (req.params.soildataid >= 1) {
		soilTestDataService.getSoilTestDataByID(req.params.soildataid, res);
	} else if (req.params.soildataid === 'all') {
		soilTestDataService.getAllSoilTestData(req, res);
	} else {
		res.json({ status: false, message: 'Cant Found Any Route' });
	}
});

//for post soiltestdata
soilTestDataRoutes.post('/soiltestdata/create', function (req, res, next) {
	console.log('postdata', req.body);
	var dataToPostinsoildatatable = {
		TestAgentID: req.body.TestAgentID,
		SampleNumber: req.body.SampleNumber,
		SampleReceivedDate: req.body.SampleReceivedDate,
		TestCompletedDate: req.body.TestCompletedDate,
		SampleQuantity: req.body.SampleQuantity,
		SamplePackaging: req.body.SamplePackaging,
		VerifiedBy: req.body.VerifiedBy,
		Remarks: req.body.Remarks,
		TblFarmer_ID: req.body.TblFarmer_ID,
		TblPloting_TblLand_ID: req.body.TblPloting_TblLand_ID,
		created_by: req.body.created_by
	};
	console.log('posting', dataToPostinsoildatatable);
	var sql = 'INSERT INTO TblSoilTestData SET ?';
	connection.query(sql, dataToPostinsoildatatable, function (err, data) {
		console.log('data', data);
		console.log('eroor', err);
		if (err) return next(err);
		var soilTestID = data.insertId;

		for (let index = 0; index < req.body.Nutrientlists.length; index++) {
			var dataToPostInSoilTestDetails = {
				count: req.body.Nutrientlists[index].count,
				TblSoilNutrient_ID: req.body.Nutrientlists[index].TblSoilNutrient_ID,
				TblSoilTestData_ID: soilTestID
			};

			var sql1 = 'INSERT INTO TblSoilTestDetails SET ?';
			connection.query(sql1, dataToPostInSoilTestDetails, function (err, result) {
				if (err) console.log('error from ', err);
			});
		}
		res.json({ data: 'Success' });
	});
});

//for update soiltestdata
soilTestDataRoutes.put('/soiltestdata/update/:soiltestdataId', function (req, res) {
	soilTestDataService.updateSoilTestDataByID(req, req.params.soiltestdataId, res);
});

//for delete soiltestdata
soilTestDataRoutes.delete('/soiltestdata/delete/:soiltestdataId', function (req, res) {
	soilTestDataService.deleteSoilTestDataById(req.params.soiltestdataId, res);
});

soilTestDataRoutes.use((err, req, res, next) => {
	res.json('Some error Occured');
});
module.exports = soilTestDataRoutes;
