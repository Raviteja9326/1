var express = require("express");
var riskmanagementsroutes = require("express").Router();
var bodyparser = require("body-parser");
var riskmanagementService = require("../../service/riskmangement/riskmanagementService");

//for get
riskmanagementsroutes.use(bodyparser.json());
riskmanagementsroutes.get("/riskmanagement/:riskmanagementID", function (req, res) {

  if (req.params.riskmanagementID >= 1)
    riskmanagementService.getRiskManagementId(req.params.riskmanagementID, res);
  else if (req.params.riskmanagementID == "all")
    riskmanagementService.getAllRiskManagement(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
riskmanagementsroutes.post("/riskmanagement/create", function (req, res) {
  // console.log("create body=", req.body);
  riskmanagementService.createRiskManagement(req, res);
});

//for update
riskmanagementsroutes.put("/riskmanagement/update/:riskmanagementID", function (req, res) {
  // console.log(req.params.riskmanagementID);
  riskmanagementService.updateRiskManagementById(req, req.params.riskmanagementID, res);
});

//for delete
riskmanagementsroutes.delete("/riskmanagement/delete/:riskmanagementID", function (req, res) {
  riskmanagementService.deleteRiskManagementById(req.params.riskmanagementID, res);
});

module.exports = riskmanagementsroutes;
