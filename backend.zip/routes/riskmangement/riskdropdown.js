var express = require("express");
var riskdropdownroutes = require("express").Router();
var bodyparser = require("body-parser");
var riskdropdownService = require("../../service/riskmangement/riskdropdownService");

//for get
riskdropdownroutes.use(bodyparser.json());
riskdropdownroutes.get("/riskdropdown/:riskdropdownId", function (req, res) {
  // console.log("in /riskdropdown route, Id ", req.params.riskdropdownId);
  if (req.params.riskdropdownId >= 1)
    riskdropdownService.getriskdropdownId(req.params.riskdropdownId, res);
  else if (req.params.riskdropdownId == "all")
    riskdropdownService.getAllriskdropdown(req, res);
  else res.json("Entered path is Incorrect ");
});


//for get

riskdropdownroutes.get("/riskstatus/all", function (req, res) {
  riskdropdownService.getAllriskstatus(req, res);

});

riskdropdownroutes.get("/riskimpact/all", function (req, res) {
  riskdropdownService.getAllImpact(req, res);

});

//for post
riskdropdownroutes.post("/riskdropdown/create", function (req, res) {
  // console.log("create body=", req.body.RiskArea);
  riskdropdownService.createriskdropdown(req, res);
});

//for post
riskdropdownroutes.post("/riskstatus/create", function (req, res) {
  // console.log("create body=", req.body.Status);
  riskdropdownService.createriskdropdown(req, res);
});


module.exports = riskdropdownroutes;
