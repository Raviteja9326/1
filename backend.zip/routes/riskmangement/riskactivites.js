var express = require("express");
var riskactivitiesroutes = require("express").Router();
var bodyparser = require("body-parser");
var riskActivitiesService = require("../../service/riskmangement/riskactivitesService");

//for get
riskactivitiesroutes.use(bodyparser.json());
riskactivitiesroutes.get("/riskactivities/:riskactivitiesId", function (req, res) {

  if (req.params.riskactivitiesId >= 1)
    riskActivitiesService.getRiskActivitiesId(req.params.riskactivitiesId, res);
  else if (req.params.riskactivitiesId == "all")
    riskActivitiesService.getAllRiskActivities(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
riskactivitiesroutes.post("/riskactivities/create", function (req, res) {

  riskActivitiesService.createRiskActivitiesId(req, res);
});

//for update
riskactivitiesroutes.put("/riskactivities/update/:riskactivitiesId", function (req, res) {

  riskActivitiesService.updateRiskActivitiesById(req, req.params.riskactivitiesId, res);
});

//for delete
riskactivitiesroutes.delete("/riskactivities/delete/:riskactivitiesId", function (req, res) {
  riskActivitiesService.deleteRiskActivitiesById(req.params.riskactivitiesId, res);
});

module.exports = riskactivitiesroutes;
