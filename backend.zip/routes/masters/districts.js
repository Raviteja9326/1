var express = require("express");
const bodyparser = require("body-parser");
const districtroutes = require("express").Router();

const districtService = require("../../service/masters/DistrictService");

districtroutes.use(bodyparser.json());
districtroutes.get("/districts/:districtId", function (req, res) {
  // console.log("in /districts route, districtId ", req.params.districtId);
  if (req.params.districtId >= 1)
    districtService.getDistrictById(req.params.districtId, res);
  else if (req.params.districtId == "all") districtService.getAllDistricts(res);
  else res.send("Entered path is Incorrect ");
});

districtroutes.get("/districts/getDistrictsByStateID/:stateId", function (req, res) {
  // console.log(req.body);
  districtService.getDistrictsByStateId(req.params.stateId, res);
});

districtroutes.post("/districts/create", function (req, res) {
  // console.log(req.body);
  districtService.createDistrict(req, res);
});

districtroutes.put("/districts/update/:districtId", function (req, res) {
  districtService.updateDistrictById(req, req.params.districtId, res);
});

districtroutes.delete("/districts/delete/:districtId", function (req, res) {
  districtService.deleteDistrictById(req.params.districtId, res);
});
module.exports = districtroutes;
