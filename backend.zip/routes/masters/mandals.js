const express = require("express");

const bodyparser = require("body-parser");

const mandalroutes = require("express").Router();

const mandalService = require("../../service/masters/MandalService");

mandalroutes.use(bodyparser.json());

mandalroutes.get("/mandals/:mandalId", function (req, res) {
  // console.log("in /mandals route, mandalId ", req.params.mandalId);
  if (req.params.mandalId >= 1)
    mandalService.getMandalById(req.params.mandalId, res);
  else if (req.params.mandalId == "all") mandalService.getAllMandals(res);
  else res.send("Entered path is Incorrect ");
});

mandalroutes.delete("/mandals/delete/:mandalId", function (req, res) {
  mandalService.deleteMandalById(req.params.mandalId, res);
});

mandalroutes.get('/mandals/getMandalsByC3OfficeID/:c3officeId', function (req, res) {
  mandalService.getMandalsByC3OfficeId(req.params.c3officeId, res);
});

mandalroutes.get("/mandals/getMandalsByDistrictID/:districtId", function (req, res) {
  // console.log(req.params.districtId);
  mandalService.getMandalsByDistrictId(req.params.districtId, res);
});

mandalroutes.post("/mandals/create", function (req, res) {
  mandalService.createMandal(req, res);
});

mandalroutes.put("/mandals/update/:mandalId", function (req, res) {
  mandalService.updateMandalById(req, req.params.mandalId, res);
});

module.exports = mandalroutes;
