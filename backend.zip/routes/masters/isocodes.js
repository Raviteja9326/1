var express = require("express");
const bodyparser = require("body-parser");
const isocoderoutes = require("express").Router();

const isocodeService = require("../../service/masters/ISOCodesService");

isocoderoutes.use(bodyparser.json());


isocoderoutes.get("/isocodes/all", function (req, res) {
 
  isocodeService.getISOcodes(req, res);
});

module.exports = isocoderoutes;
