var express = require("express");
const bodyparser = require("body-parser");
const stateroutes = require("express").Router();

const stateService = require("../../service/masters/StateService");

stateroutes.use(bodyparser.json());
stateroutes.get("/states/:stateId", function (req, res) {
  // console.log("in /states route, stateId ", req.params.stateId);
  if (req.params.stateId >= 1)
    stateService.getStateById(req.params.stateId, res);
  else if (req.params.stateId == "all") stateService.getAllStates(res);
  else res.send("Entered path is Incorrect ");
});

stateroutes.get("/states/getStatesByCountryID/:countryId", function (req, res) {
  // console.log("create body=", req.body);
  stateService.getStatesByCountryId(req.params.countryId, res);
});

stateroutes.post("/states/create", function (req, res) {
  // console.log("create body=", req.body);
  stateService.createState(req, res);
});

stateroutes.put("/states/update/:stateId", function (req, res) {
  stateService.updateStateById(req.params.stateId, req, res);
});

stateroutes.delete("/states/delete/:stateId", function (req, res) {
  stateService.deleteStateById(req.params.stateId, res);
});
module.exports = stateroutes;
