var express = require("express");
const bodyparser = require("body-parser");

const villagesarpanchroutes = require("express").Router();

const villageSarpanchService = require("../../service/masters/VillageSarpanchService");

villagesarpanchroutes.get("/villagesarpanch/:villagesarpanchId", function (req, res) {
    // console.log("in /villagesarpanch route, villagesarpanchId ", req.params.villagesarpanchId);
    if (req.params.villagesarpanchId >= 1)
        villageSarpanchService.getVillageSarpanchById(req.params.villagesarpanchId, res);
    else if (req.params.villagesarpanchId == "all") villageSarpanchService.getAllVillageSarpanches(res);
    else res.send("Entered path is Incorrect ");
});

villagesarpanchroutes.post("/villagesarpanch/create", function (req, res) {
    villageSarpanchService.createVillageSarpanch(req, res);
});

villagesarpanchroutes.put("/villagesarpanch/update/:villagesarpanchId", function (req, res) {
    villageSarpanchService.updateVillageSarpanchById(req, req.params.villagesarpanchId, res);
});

villagesarpanchroutes.delete("/villagesarpanch/delete/:villagesarpanchId", function (req, res) {
    villageSarpanchService.deleteVillageSarpanchById(req.params.villagesarpanchId, res);
});


module.exports = villagesarpanchroutes;