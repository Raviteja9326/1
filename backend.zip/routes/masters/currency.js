var express = require("express");
const bodyparser = require("body-parser");
const currencyroutes = require("express").Router();

const currencyService = require("../../service/masters/CurrencyService");

currencyroutes.use(bodyparser.json());
currencyroutes.get("/currency/:currencyId", function (req, res) {
  // console.log("in /currency route, currencyId ", req.params.currencyId);
  if (req.params.currencyId >= 1)
    currencyService.getCurrencyById(req.params.currencyId, res);
  else if (req.params.currencyId == "all") currencyService.getAllCurrency(res);
  else res.send("Entered path is Incorrect ");
});

currencyroutes.post("/currency/create", function (req, res) {
  currencyService.createCurrency(req, res);
});

currencyroutes.put("/currency/update/:currencyId", function (req, res) {
  currencyService.updateCurrencyById(req, req.params.currencyId, res);
});

currencyroutes.delete("/currency/delete/:currencyId", function (req, res) {
  currencyService.deleteCurrencyById(req.params.currencyId, res);
});
module.exports = currencyroutes;
