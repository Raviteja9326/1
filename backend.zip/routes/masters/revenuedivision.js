var express = require("express");
const bodyparser = require("body-parser");
const revenuedivisionroutes = require("express").Router();

const revenueDivisionService = require("../../service/masters/RevenueDivisionService");

revenuedivisionroutes.use(bodyparser.json());
revenuedivisionroutes.get("/revenuedivision/:revenuedivisionId", function (req, res) {
    // console.log("in /revenuedivision route, revenuedivisionId ", req.params.revenuedivisionId);
    if (req.params.revenuedivisionId >= 1)
        revenueDivisionService.getRevenueDivisionById(req.params.revenuedivisionId, res);
    else if (req.params.revenuedivisionId == "all") revenueDivisionService.getAllRevenueDivisions(res);
    else res.send("Entered path is Incorrect ");
});

revenuedivisionroutes.post("/revenuedivision/create", function (req, res) {
    // console.log("create body=", req.body);
    revenueDivisionService.createRevenueDivision(req, res);
});

revenuedivisionroutes.put("/revenuedivision/update/:revenuedivisionId", function (req, res) {
    revenueDivisionService.updateRevenueDivisionById(req, req.params.revenuedivisionId, res);
});

revenuedivisionroutes.delete("/revenuedivision/delete/:revenuedivisionId", function (req, res) {
    revenueDivisionService.deleteRevenueDivisionById(req.params.revenuedivisionId, res);
});


module.exports = revenuedivisionroutes;