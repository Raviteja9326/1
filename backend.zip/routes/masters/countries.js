const bodyparser = require("body-parser");
const countryroutes = require("express").Router();
var HttpStatus = require('http-status-codes');

const countryService = require("../../service/masters/CountryService");

countryroutes.use(bodyparser.json());
countryroutes.get("/countries/:countryId", function (req, res) {
  // console.log("in /countries route, countryId ", req.params.countryId);
  if (req.params.countryId >= 1)
    countryService.getCountryById(req.params.countryId, res);
  else if (req.params.countryId == "all") countryService.getAllCountries(res);
  else res.status(HttpStatus.getStatusCode('Bad Gateway')).json({
    status: HttpStatus.getStatusCode('Bad Request'),
    error: "path is incorrect"
  })

});

countryroutes.post("/countries/create", function (req, res) {
  countryService.createCountry(req, res);
});

countryroutes.put("/countries/update/:countryId", function (req, res) {
  countryService.updateCountryById(req, req.params.countryId, res);
});

countryroutes.delete("/countries/delete/:countryId", function (req, res) {
  countryService.deleteCountryById(req.params.countryId, res);
});

module.exports = countryroutes;
