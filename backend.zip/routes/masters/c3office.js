var express = require('express');
const bodyparser = require('body-parser');
const c3officeroutes = require('express').Router();

const c3OfficeService = require('../../service/masters/C3OfficeService');

const c3DAO = require('../../dao/masters/C3OfficeDAO');

c3officeroutes.use(bodyparser.json());
c3officeroutes.get('/c3office/:c3OfficeId', function (req, res) {
	// console.log("in /states route, c3OfficeId ", req.params.c3OfficeId);
	if (req.params.c3OfficeId >= 1) c3OfficeService.getC3OfficeById(req.params.c3OfficeId, res);
	else if (req.params.c3OfficeId == 'all') c3OfficeService.getAllC3Offices(res);
	else res.json('Entered path is Incorrect ');
});
c3officeroutes.get('/c3office/getC3OfficeByDistrictId/:districtId', function (req, res) {
	c3OfficeService.getC3OfficeByDistrictId(req.params.districtId, res);
});
c3officeroutes.post('/c3office/create', function (req, res) {
	// console.log("create body=", req.body);
	c3OfficeService.createC3Office(req, res);
});

c3officeroutes.put('/c3office/update/:c3OfficeId', function (req, res) {
	c3OfficeService.updateC3OfficeById(req, req.params.c3OfficeId, res);
});

c3officeroutes.delete('/c3office/delete/:c3OfficeId', function (req, res) {
	c3OfficeService.deleteC3OfficeById(req.params.c3OfficeId, res);
});

c3officeroutes.get('/c3office/getC3OfficeByCountryId/:countryId', (req, res) => {
	c3DAO.getC3OfficeByCountryId(req.params.countryId, res);
});
c3officeroutes.get('/c3office/getC3OfficeByStateID/:stateId', (req, res) => {
	c3DAO.getC3OfficeByStateID(req.params.stateId, res);
});

module.exports = c3officeroutes;
