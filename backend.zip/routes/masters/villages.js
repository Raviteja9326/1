var express = require("express");
const bodyparser = require("body-parser");

const villageroutes = require("express").Router();

const villageService = require("../../service/masters/VillageService");

villageroutes.get("/villages/:villageId", function (req, res) {
  // console.log("in /villages route, villageId ", req.params.villageId);
  if (req.params.villageId >= 1)
    villageService.getVillageById(req.params.villageId, res);
  else if (req.params.villageId == "all") villageService.getAllVillages(res);
  else res.send("Entered path is Incorrect ");
});

villageroutes.get("/villages/getVillagesByMandalID/:mandalId", function (req, res) {
  villageService.getVillagesByMandalId(req.params.mandalId, res);
});

villageroutes.post("/villages/create", function (req, res) {
  villageService.createVillage(req, res);
});

villageroutes.put("/villages/update/:villageId", function (req, res) {
  villageService.updateVillageById(req, req.params.villageId, res);
});

villageroutes.delete("/villages/delete/:villageId", function (req, res) {
  villageService.deleteVillageById(req.params.villageId, res);
});
module.exports = villageroutes;
