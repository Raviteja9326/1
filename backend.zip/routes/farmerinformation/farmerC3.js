var express = require('express');
var bodyparser = require('body-parser');
var farmerc3routes = require("express").Router();
var farmerc3Service = require('../../service/farmerdata/FarmerC3Service');
farmerc3routes.use(bodyparser.json());

farmerc3routes.get('/farmerc3/all', function (req, res) {
    farmerc3Service.getAllFarmerC3(req, res);
});
farmerc3routes.post('/farmerc3/create', function (req, res) {
    farmerc3Service.createFramerC3(req, res);
});
farmerc3routes.delete('/farmerc3/delete/:farmerc3Id', function (req, res) {
    farmerc3Service.removefarmerc3(req.params.farmerc3Id, res)
});
module.exports = farmerc3routes;