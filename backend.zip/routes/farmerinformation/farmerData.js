var farmerDataroutes = require('express').Router();
var bodyparser = require("body-parser");
var farmerDataService = require("../../service/farmerdata/FarmerDataService");
const connection = require('../../dao/MySQLConnect');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const helper = require('./helper');

farmerDataroutes.use(bodyparser.json());

farmerDataroutes.get('/farmerdata/:farmerId', function (req, res) {
    if (req.params.farmerId >= 1) farmerDataService.getFarmerDataById(req.params.farmerId, res);
    else if (req.params.farmerId == "all") farmerDataService.getAllfarmerData(res);
    else res.json("Entered Path Is Incorrect");

});


farmerDataroutes.get('/farmerdata/user/:userID', (req, res) => {
    farmerDataService.getFarmerDataByUser(req.params.userID, res);
})

farmerDataroutes.get('/farmerqrdata/all', function (req, res) {
    farmerDataService.getAllfarmerQrData(res);
});


farmerDataroutes.post('/farmerdata/create', function (req, res) {
    farmerDataService.createfarmer(req, res);
})

farmerDataroutes.put('/farmerdata/update/:farmerId', function (req, res) {
    farmerDataService.updateFarmerData(req, req.params.farmerId, res);
})

farmerDataroutes.delete('/farmerdata/delete/:farmerId', function (req, res) {
    farmerDataService.removeFarmer(req.params.farmerId, res);
})

farmerDataroutes.get('/farmerqrdata/:farmername', function (req, res) {

    farmerDataService.getDataForQR(req.params.farmername, res);
});

farmerDataroutes.post('/farmer/upload/image/:FarmerID', (req, res) => {
    const storage = multer.diskStorage({
        destination: function (req, file, callback) {
            const FarmerID = req.params.FarmerID;
            const path = `./public/images/farmer/${FarmerID}/ardhar`;
            try {
                if (!fs.existsSync(path)) {
                    fs.mkdirSync(path, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return callback(null, path, true)
        },
        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }
    });
    var upload = multer({ storage: storage, fileFilter: helper.imageFilter }).array('sampleImage', 2);

    upload(req, res, function (err) {
        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multiple = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multiple]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});

farmerDataroutes.post('/farmer/upload/farmerimage/:farmid', (req, res) => {
    const storages = multer.diskStorage({
        destination: function (req, file, callback) {
            const farmid = req.params.farmid;
            const dir = `./public/images/farmer/${farmid}/Profile`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return callback(null, dir, true)
        },
        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }

    });
    var uploads = multer({ storage: storages, fileFilter: helper.imageFilter }).array('sampleImages', 1);

    uploads(req, res, function (err) {
        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multiples = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multiples]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});

farmerDataroutes.post('/farmer/upload/farmersoil/:soilid', (req, res) => {
    const storagesoil = multer.diskStorage({
        destination: function (req, file, cb) {
            var soilid = req.params.soilid;
            var dir = `./public/images/farmer/${soilid}/soil`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }

    });
    let uploadsoil = multer({ storage: storagesoil, fileFilter: helper.imageFilter }).array('samplesoil', 10);

    uploadsoil(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }

        else {
            const multip = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multip]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});

farmerDataroutes.post('/farmer/upload/farmerland/:landid', (req, res) => {

    const storageland = multer.diskStorage({
        destination: function (req, file, cb) {
            const landid = req.params.landid;
            const dir = `./public/images/farmer/${landid}/land`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }
    });

    var uploadland = multer({ storage: storageland, fileFilter: helper.imageFilter }).array('sampleland', 10);
    uploadland(req, res, function (err) {
        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multi = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multi]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});


farmerDataroutes.post('/farmer/upload/farmerwater/:waterid', (req, res) => {

    const storagewater = multer.diskStorage({
        destination: function (req, file, cb) {
            const waterid = req.params.waterid;
            const dir = `./public/images/farmer/${waterid}/water`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }

    });

    var uploadwater = multer({ storage: storagewater, fileFilter: helper.imageFilter }).array('samplewater', 10);


    uploadwater(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const mult = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [mult]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});


farmerDataroutes.post('/farmer/upload/farmerseed/:seedid', (req, res) => {

    const storageseed = multer.diskStorage({
        destination: function (req, file, cb) {
            const seedid = req.params.seedid;
            const dir = `./public/images/farmer/${seedid}/seed&planting`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }


    });

    var uploadseed = multer({ storage: storageseed, fileFilter: helper.imageFilter }).array('sampleseed', 10);
    uploadseed(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const mul = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [mul]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});

farmerDataroutes.post('/farmer/upload/farmercompost/:compostid', (req, res) => {
    const storagecompost = multer.diskStorage({
        destination: function (req, file, cb) {
            const compostid = req.params.compostid;
            const dir = `./public/images/farmer/${compostid}/FYM&compost`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }
    });

    var uploadcompost = multer({ storage: storagecompost, fileFilter: helper.imageFilter }).array('samplecompost', 10);

    uploadcompost(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const mults = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [mults]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});


farmerDataroutes.post('/farmer/upload/farmerinorganic/:inorganicid', (req, res) => {

    const storageinorganic = multer.diskStorage({
        destination: function (req, file, cb) {
            const inorganicid = req.params.inorganicid;
            const dir = `./public/images/farmer/${inorganicid}/inorganic`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }

    });

    var uploadinorganic = multer({ storage: storageinorganic, fileFilter: helper.imageFilter }).array('sampleinorganic', 10);

    uploadinorganic(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multsinorganic = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multsinorganic]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});

farmerDataroutes.post('/farmer/upload/farmerorganic/:organicid', (req, res) => {
    const storageorganic = multer.diskStorage({
        destination: function (req, file, cb) {
            const organicid = req.params.organicid;
            let dir = `./public/images/farmer/${organicid}/organic`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }

    });

    var uploadorganic = multer({ storage: storageorganic, fileFilter: helper.imageFilter }).array('sampleorganic', 10);
    uploadorganic(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multsorganic = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multsorganic]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});


farmerDataroutes.post('/farmer/upload/farmerMachinery/:Machineryid', (req, res) => {

    const storageMachinery = multer.diskStorage({
        destination: function (req, file, cb) {
            const Machineryid = req.params.Machineryid;
            let dir = `./public/images/farmer/${Machineryid}/Machinery`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }


    });

    var uploadMachinery = multer({ storage: storageMachinery, fileFilter: helper.imageFilter }).array('sampleMachinery', 10);


    uploadMachinery(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multsMachinery = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multsMachinery]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});


farmerDataroutes.post('/farmer/upload/farmertraining/:trainingid', (req, res) => {
    const storagetraining = multer.diskStorage({
        destination: function (req, file, cb) {
            const trainingid = req.params.trainingid;
            let dir = `./public/images/farmer/${trainingid}/training`;
            try {
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
            } catch (err) {
                console.error(err)
            }
            return cb(null, dir, true)

        },

        filename: function (req, file, cb) {
            cb(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + path.extname(file.originalname));
        }


    });

    var uploadtraining = multer({ storage: storagetraining, fileFilter: helper.imageFilter }).array('sampletraining', 10);
    uploadtraining(req, res, function (err) {

        if (req.fileValidationError) {
            return res.json({ "data": req.fileValidationError });
        }
        else if (!req.files) {
            return res.json('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.json({ "datas": err });
        }
        else if (err) {
            return res.json({ "data": "something gone wrong" })
        }
        else {
            const multstraining = req.files.map(item => [req.body.Activity, req.body.FarmerID, item.path])
            try {
                connection.query('INSERT INTO TblImage (Activity,FarmerID,Location) values ?', [multstraining]).then((data) => {
                    if (data.insertId > 0) {
                        res.json({ "data": 'Successfully uploaded images' });
                    }
                });
            } catch (error) {
                res.json({ "data": 'something went wrong' });
            }
        }
    })

});


farmerDataroutes.get('/qachecklist/image/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciProfile' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/ardhar/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciAdhar' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/land/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciLand' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/Compost/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciCompost' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/Machinery/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciMachinery' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/Organic/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciOrganic' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/soil/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciSoil' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/Traning/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciTraning' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/Inorganic/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciInorganic' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});

farmerDataroutes.get('/qachecklist/Water/:id', (req, res) => {
    try {
        connection
            .query(`SELECT * FROM TblImage where isDeleted=1 AND Activity='QciWater' AND FarmerID=${req.params.id}`)
            .then((data) => {
                var dataToSubmit = data.map((da) => {
                    return {
                        Image: da.Location
                    };
                });
                if (data.length == 0) {
                    res.json({ data: "No Image Found" })
                }
                else {
                    res.json(dataToSubmit);
                }
            })
            .catch((err) => {
                res.json('Internal server error');
            });
    } catch (error) {
        res.json('Something went wrong');
    }
});
module.exports = farmerDataroutes;