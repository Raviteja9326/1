var express = require("express")
var labourroutes = require('express').Router();
var bodyparser = require("body-parser");
var LabourService = require('../../service/farmerdata/LabourService');



//for get
labourroutes.use(bodyparser.json());
labourroutes.get("/labour/:labourId", function (req, res) {
  // console.log("in /labour route, Id ", req.params.labourId);
  if (req.params.labourId >= 1)
    LabourService.getlabourById(req.params.labourId, res);
  else if (req.params.labourId == "all") LabourService.getAlllabour(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
labourroutes.post("/labour/create", function (req, res) {

  LabourService.createLabour(req, res);
});

//for update
labourroutes.put("/labour/update/:labourId", function (req, res) {

  LabourService.updateById(req, req.params.labourId, res);
});

//for delete
labourroutes.delete("/labour/delete/:labourId", function (req, res) {
  LabourService.deleteById(req.params.labourId, res);
});

module.exports = labourroutes;