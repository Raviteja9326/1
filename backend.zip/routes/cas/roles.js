const express = require('express');
const roleRoutes = express.Router();
const bodyparser = require('body-parser');
const rolesDAO = require('../../dao/cas/RolesDAO');
//const roleService = require('../../service/cas/RoleService');

//const checkToken = require('../../middlewares/checkToken');

roleRoutes.get('/roles/all', function (req, res) {
	rolesDAO.getAllRoles(req, res);
});

roleRoutes.post('/roles/create', function (req, res) {
	rolesDAO.createRole(req, res);
});


roleRoutes.get('/masteractivities/all', function (req, res) {
	rolesDAO.getAllActivities(req, res);
});

roleRoutes.post('/activitiesbyMasterIDs', function (req, res) {
	rolesDAO.getAllActivitiesByMasterID(req, res);
});

roleRoutes.post('/roleactivities/create', function (req, res) {
	rolesDAO.createRoleActivites(req, res);
});
roleRoutes.use((err, req, res, next) => {
	res.json('Some error Occured');
});

roleRoutes.put('/roles/update/:roleID', function (req, res) {
	rolesDAO.updateRole(req, req.params.roleID, res);
});

roleRoutes.put('/roleactivities/update/:roleID', function (req, res) {
	rolesDAO.updateRoleActivites(req, req.params.roleID, res);
});

roleRoutes.get('/roles/:roleID', function (req, res) {
	rolesDAO.getAllActivitiesByRoleID(req.params.roleID, res);
});

roleRoutes.delete('/roles/delete/:roleID', function (req, res) {
	rolesDAO.deleteRole(req.params.roleID, res);
});

roleRoutes.get('/CRUDoperations/all', function (req, res) {
	rolesDAO.getOpeations(req, res);
});

module.exports = roleRoutes;
