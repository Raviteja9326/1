const express = require('express');
const bodyparser = require('body-parser');
const userroutes = express.Router();
const connection = require('../../dao/MySQLConnect');
const userService = require('../../service/cas/UserService');
const userDAO = require('../../dao/cas/UsersDAO');
const { checkMobile, checkEmail, checkUser } = require('../../middlewares/user');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const storage = multer.diskStorage({
	destinations: function(req, file, callback) {
		let dir = 'public/images/Users';
		if (!fs.existsSync(dir)) {
			fs.mkdirSync(dir, { recursive: true });
		}
		callback(null, dir);
	},
	filename: function(req, file, cb) {
		cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
	}
});

const upload = multer({ storage: storage }).single('user');
userroutes.use(bodyparser.json());

userroutes.post('/user/create', checkUser, checkEmail, checkMobile, (req, res) => {
	return userDAO.createUser(req, res);
});

userroutes.post('/user/checkmail', function(req, res) {
	var dataToCheck1 = req.body.Email;
	var sql1 = 'SELECT count(*) totalCount from TblUser WHERE Email=? AND isDeleted=1';
	connection.query(sql1, dataToCheck1, function(err, result) {
		if (result[0].totalCount === 0) {
			res.json({ message: 'Email is ok' });
		} else {
			res.json({ message: 'Email Already exists' });
		}
	});
});

userroutes.post('/user/checkphone', function(req, res) {
	var dataToCheck1 = req.body.PhoneNo;
	var sql1 = 'SELECT count(*) totalCount from TblUser WHERE PhoneNo=? AND isDeleted=1';
	connection.query(sql1, dataToCheck1, function(err, result) {
		if (result[0].totalCount === 0) {
			res.json({ message: 'PhoneNumber is ok' });
		} else {
			res.json({ message: 'PhoneNumber Already exists' });
		}
	});
});

userroutes.post('/user/checkusername', function(req, res) {
	var dataToCheck2 = req.body.UserName;
	var sql2 = 'SELECT count(*) totalCount from TblUser WHERE UserName=? AND isDeleted=1';
	connection.query(sql2, dataToCheck2, function(err, result) {
		if (result[0].totalCount === 0) {
			res.json({ message: 'UserName is ok' });
		} else {
			res.json({ message: 'UserName Already exists' });
		}
	});
});

userroutes.post('/user/login', function(req, res) {
	userService.userLogin(req, res);
});

userroutes.get('/user/all', function(req, res) {
	userService.getAllUsers(req, res);
});

userroutes.get('/user/:userID', function(req, res) {
	userService.getUserByID(req.params.userID, res);
});

userroutes.put('/user/update/:userID', function(req, res) {
	userService.updateUser(req, req.params.userID, res);
});

userroutes.delete('/user/delete/:userID', function(req, res) {
	userService.delloite(req.params.userID, res);
});

userroutes.post('/user/forgotPassword', (req, res) => {
	userDAO.forgotPassword(req.body.PhoneNo, res);
});

userroutes.put('/user/updatePasword/:userID', (req, res) => {
	userDAO.updatePassword(req.params.userID, req, res);
});

userroutes.put('/user/upload/image/:id', (req, res) => {
	upload(req, res, function(err) {
		if (err) {
			return res.json({ data: 'something gone wrong' });
		} else {
			let sql = `UPDATE TblUser  SET Location = '${req.file.destination}/${req.file.filename}' WHERE ID= ${req
				.params.id}`;
			connection.query(sql, function(err, result) {
				res.json({ data: 'Successfully Uploaded Images' });
			});
		}
	});
});

userroutes.get('/user/chart/country/:countryID', (req, res) => {
	let sql = `SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE   fr.TblCountry=${req
		.params
		.countryID} AND YEAR(fr.created_at)=YEAR(CURDATE())  AND fr.ID IN(SELECT DISTINCT frc.FarmerID FROM TblCivilforceCheckList_Farmer frc ) GROUP BY MONTH(fr.created_at)`;
	// 'SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE YEAR(fr.created_at)=2019  GROUP BY MONTH(fr.created_at)';
	connection
		.query(sql)
		.then((result) => {
			res.json(userService.chartData(result));
		})
		.catch((error) => {
			res.json({ message: error.message });
		});
});
userroutes.get('/user/chart/state/:stateID', (req, res) => {
	let sql = `SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE   fr.TblState=${req
		.params
		.stateID}  AND YEAR(fr.created_at)=YEAR(CURDATE()) AND fr.ID IN(SELECT DISTINCT frc.FarmerID FROM TblCivilforceCheckList_Farmer frc ) GROUP BY MONTH(fr.created_at)`;
	connection
		.query(sql)
		.then((result) => {
			res.json(userService.chartData(result));
		})
		.catch((error) => {
			res.json({ message: error.message });
		});
});
userroutes.get('/user/chart/district/:districtID', (req, res) => {
	let sql = `SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE  fr.Tbldistrict=${req
		.params
		.districtID} AND YEAR(fr.created_at)=YEAR(CURDATE()) AND fr.ID IN(SELECT DISTINCT frc.FarmerID FROM TblCivilforceCheckList_Farmer frc ) GROUP BY MONTH(fr.created_at)`;
	connection
		.query(sql)
		.then((result) => {
			res.json(userService.chartData(result));
		})
		.catch((error) => {
			res.json({ message: error.message });
		});
});

userroutes.get('/user/noncertified/country/:countryID', (req, res) => {
	let sql = `SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE  fr.TblCountry=${req
		.params.countryID}  AND YEAR(fr.created_at)=YEAR(CURDATE()) GROUP BY MONTH(fr.created_at)`;
	connection
		.query(sql)
		.then((result) => {
			res.json(userService.chartData(result));
		})
		.catch((error) => {
			res.json({ message: error.message });
		});
});
userroutes.get('/user/noncertified/state/:stateID', (req, res) => {
	let sql = `SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE  fr.TblState=${req
		.params.stateID}  AND YEAR(fr.created_at)=YEAR(CURDATE()) GROUP BY MONTH(fr.created_at)`;
	connection
		.query(sql)
		.then((result) => {
			res.json(userService.chartData(result));
		})
		.catch((error) => {
			res.json({ message: error.message });
		});
});
userroutes.get('/user/noncertified/district/:districtID', (req, res) => {
	let sql = `SELECT  MONTH(fr.created_at)as month  ,COUNT(*) as totalcount  from TblFarmer fr  WHERE  fr.Tbldistrict=${req
		.params.districtID}  AND YEAR(fr.created_at)=YEAR(CURDATE()) GROUP BY MONTH(fr.created_at)`;
	connection
		.query(sql)
		.then((result) => {
			res.json(userService.chartData(result));
		})
		.catch((error) => {
			res.json({ message: error.message });
		});
});

userroutes.get('/user/checklist/get/:farmerID', (req, res) => {
	let sql = `SELECT a.ID,a.Module_Name,(SELECT  JSON_ARRAYAGG(JSON_OBJECT("ID",b.ID,"QCIModuleID",b.QCIModuleID,"CheckListID",b.CheckListID,"Action",b.Action,"extraAction",b.extraAction,"desc",c.Desc)))as checkList FROM TblQCIModule a LEFT JOIN TblCivilforceCheckList_Farmer b ON b.QCIModuleID=a.ID 	LEFT JOIN TblCivilforceCheckList c ON a.ID=c.TblQCIModule_ID WHERE b.FarmerID=${req
		.params.farmerID} AND a.ID=c.TblQCIModule_ID AND b.CheckListID=c.CheckListID  GROUP BY a.ID`;
	connection
		.query(sql)
		.then((data) => {
			//res.json(data);
			const da = data.map((ele) => {
				return {
					ID: ele.ID,
					Module_Name: ele.Module_Name,
					checklist: JSON.parse(ele.checkList)
				};
			});
			res.json(da);
		})
		.catch((error) => {
			console.log(error);
			res.json(error.message);
		});
});

module.exports = userroutes;
