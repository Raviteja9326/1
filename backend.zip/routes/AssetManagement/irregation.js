var express = require("express")
var irregationroutes = require('express').Router();
var bodyparser = require("body-parser");
var IrregationService = require('../../service/AssetManagement/IrregationService');



//for get
irregationroutes.use(bodyparser.json());
irregationroutes.get("/irregation/:irregationId", function (req, res) {
  // console.log("in /irregation route, Id ", req.params.irregationId);
  if (req.params.irregationId >= 1)
    IrregationService.getirregationId(req.params.irregationId, res);
  else if (req.params.irregationId == "all") IrregationService.getAllirregation(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
irregationroutes.post("/irregation/create", function (req, res) {
  // console.log("create body=", req.body);
  IrregationService.createirregation(req, res);
});

//for update
irregationroutes.put("/irregation/update/:irregationId", function (req, res) {
  // console.log(req.params.irregationId);
  IrregationService.updateById(req, req.params.irregationId, res);
});

//for delete
irregationroutes.delete("/irregation/delete/:irregationId", function (req, res) {
  IrregationService.deleteById(req.params.irregationId, res);
});

module.exports = irregationroutes;