const express = require('express');
const machineryroutes = require('express').Router();
var machineryService = require('../../service/AssetManagement/MachineryService');

const bodyparser = require('body-parser');

machineryroutes.get('/machinery/:machineryId', function (req, res) {
    if (req.params.machineryId >= 1) { machineryService.getMachineryById(req.params.machineryId, res) }
    else if (req.params.machineryId == 'all') { machineryService.getAllMachinery(req, res) }
    else { res.json({ data: "Entered Path Is Incorrect" }) }
})

machineryroutes.post('/machinery/create', function (req, res) {
    machineryService.createmachinery(req, res);
})

machineryroutes.put('/machinery/update/:machineryId', function (req, res) {
    machineryService.updatmachinery(req, req.params.machineryId, res);
})
machineryroutes.delete('/machinery/delete/:machineryId', function (req, res) {
    machineryService.removemachinery(req.params.machineryId, res);
})


module.exports = machineryroutes;