const express = require('express');
const pitroutes = require('express').Router();
const bodyparser = require('body-parser');
var pitService = require('../../service/AssetManagement/PitService');

pitroutes.use(bodyparser.json());
pitroutes.get('/pit/:pitId', function (req, res) {
    if (req.params.pitId >= 1) pitService.getPitDataByID(req.params.pitId, res);
    else if (req.params.pitId == "all") pitService.getAllPitData(req, res);
    else res.json("Entered path is Incorrect ");
});


pitroutes.get('/pittypes/all', function (req, res) {
    pitService.getPitTypes(req, res);
})

pitroutes.get('/pitconstructiontypes/all', function (req, res) {
    pitService.getPitConstructionTypes(req, res);
})


pitroutes.post('/pit/create', function (req, res) {
    pitService.createPit(req, res);
})

pitroutes.put('/pit/update/:pitId', function (req, res) {
    pitService.updatePit(req, req.params.pitId, res);
})
pitroutes.delete('/pit/delete/:pitId', function (req, res) {
    pitService.removePit(req.params.pitId, res);
})


module.exports = pitroutes;