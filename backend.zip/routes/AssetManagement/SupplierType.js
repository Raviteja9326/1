var express = require("express");
var supplierroutes = require("express").Router();
var bodyparser = require("body-parser");
var suppliertypeService = require("../../service/AssetManagement/SupplierTypeService");

//for get
supplierroutes.use(bodyparser.json());
supplierroutes.get("/suppliertype/:suppliertypeId", function (req, res) {
  // console.log("in /suppliertype route, Id ", req.params.suppliertypeId);
  if (req.params.suppliertypeId >= 1)
    suppliertypeService.getsuppliertypeId(req.params.suppliertypeId, res);
  else if (req.params.suppliertypeId == "all")
    suppliertypeService.getAllsuppliertype(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
supplierroutes.post("/suppliertype/create", function (req, res) {
  // console.log("create body=", req.body);
  suppliertypeService.createsuppliertype(req, res);
});

//for update
supplierroutes.put("/suppliertype/update/:suppliertypeId", function (req, res) {
  // console.log(req.params.suppliertypeId);
  suppliertypeService.updateById(req, req.params.suppliertypeId, res);
});

//for delete
supplierroutes.delete("/suppliertype/delete/:suppliertypeId", function (req, res) {
  suppliertypeService.deleteById(req.params.suppliertypeId, res);
});

module.exports = supplierroutes;
