const express = require('express');
const Vermicompostcoproutes = require('express').Router();
const bodyparser = require('body-parser');
var VermiCompostcopService = require('../../service/AssetManagement/VermicompostcopService');

Vermicompostcoproutes.use(bodyparser.json());
Vermicompostcoproutes.get('/vermicompostcop/:vermicompostcopId', function (req, res) {
    if (req.params.vermicompostcopId >= 1) VermiCompostcopService.getvermicompostcopDataByID(req.params.vermicompostcopId, res);
    else if (req.params.vermicompostcopId == "all") VermiCompostcopService.getAllVermicompostcopData(req, res);
    else res.json("Entered path is Incorrect ");
});
Vermicompostcoproutes.post('/vermicompostcop/create', function (req, res) {
    VermiCompostcopService.createvermicompostcop(req, res);
})

Vermicompostcoproutes.put('/vermicompostcop/update/:vermicompostcopId', function (req, res) {
    VermiCompostcopService.updatevermicompostcop(req, req.params.vermicompostcopId, res);
})
Vermicompostcoproutes.delete('/vermicompostcop/delete/:vermicompostcopId', function (req, res) {
    VermiCompostcopService.removevermicompostcop(req.params.vermicompostcopId, res);
})

module.exports = Vermicompostcoproutes;