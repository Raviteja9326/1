const express = require("express");
const Shedroutes = require("express").Router();
const bodyparser = require("body-parser");
var ShedService = require("../../service/AssetManagement/ShedService");

Shedroutes.use(bodyparser.json());

Shedroutes.get("/shed/:shedId", function (req, res) {
  if (req.params.shedId >= 1)
    ShedService.getshedDataByID(req.params.shedId, res);
  else if (req.params.shedId == "all") ShedService.getAllshedData(req, res);
  else res.json("Entered path is Incorrect ");
});
Shedroutes.post("/shed/create", function (req, res) {
  // console.log("from js", req.body);
  ShedService.createshed(req, res);
});

Shedroutes.put("/shed/update/:shedId", function (req, res) {
  ShedService.updatshed(req, req.params.shedId, res);
});
Shedroutes.delete("/shed/delete/:shedId", function (req, res) {
  ShedService.removeshed(req.params.shedId, res);
});

module.exports = Shedroutes;
