const express = require('express');
const Vermicompostcycleroutes = require('express').Router();
const bodyparser = require('body-parser');
var VermiCompostcycleService = require('../../service/AssetManagement/VermicompostcycleService');

Vermicompostcycleroutes.use(bodyparser.json());
Vermicompostcycleroutes.get('/vermicompostcycle/:vermicompostcycleId', function (req, res) {
    if (req.params.vermicompostcycleId >= 1) VermiCompostcycleService.getvermicompostcycleDataByID(req.params.vermicompostcycleId, res);
    else if (req.params.vermicompostcycleId == "all") VermiCompostcycleService.getAllVermicompostcycleData(req, res);
    else res.json("Entered path is Incorrect ");
});
Vermicompostcycleroutes.post('/vermicompostcycle/create', function (req, res) {
    VermiCompostcycleService.createvermicompostcycle(req, res);
})

Vermicompostcycleroutes.put('/vermicompostcycle/update/:vermicompostcycleId', function (req, res) {
    VermiCompostcycleService.updatevermicompostcycle(req, req.params.vermicompostcycleId, res);
})
Vermicompostcycleroutes.delete('/vermicompostcycle/delete/:vermicompostcycleId', function (req, res) {
    VermiCompostcycleService.removevermicompostcycle(req.params.vermicompostcycleId, res);
})

module.exports = Vermicompostcycleroutes;