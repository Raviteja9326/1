const express = require('express');
const Vermicompostpitroutes = require('express').Router();
const bodyparser = require('body-parser');
var VermiCompostPitService = require('../../service/AssetManagement/VermiCompostpitService');

Vermicompostpitroutes.use(bodyparser.json());
Vermicompostpitroutes.get('/vermicompostpit/:vermicompostpitId', function (req, res) {
    if (req.params.vermicompostpitId >= 1) VermiCompostPitService.getvermicompostPitDataByID(req.params.vermicompostpitId, res);
    else if (req.params.vermicompostpitId == "all") VermiCompostPitService.getAllVermicompostPitData(req, res);
    else res.json("Entered path is Incorrect ");
});
Vermicompostpitroutes.post('/vermicompostpit/create', function (req, res) {
    VermiCompostPitService.createvermicompostPit(req, res);
})

Vermicompostpitroutes.put('/vermicompostpit/update/:vermicompostpitId', function (req, res) {
    VermiCompostPitService.updatevermicompostPit(req, req.params.vermicompostpitId, res);
})
Vermicompostpitroutes.delete('/vermicompostpit/delete/:vermicompostpitId', function (req, res) {
    VermiCompostPitService.removevermicompostPit(req.params.vermicompostpitId, res);
})

module.exports = Vermicompostpitroutes;