var express = require('express');
var inventoryroutes = require('express').Router();
var bodyparser = require('body-parser');
var inventoryService = require('../../service/Raw Material/InventoryService');

inventoryroutes.use(bodyparser.json());

inventoryroutes.get('/inventory/all', function (req, res) {
    inventoryService.getAllInventories(req, res);
})

inventoryroutes.get('/inventory/getInventoryByFarmerID/:getInventoryByFarmerID', function (req, res) {
    inventoryService.getInventoryByFarmerID(req, req.params.getInventoryByFarmerID, res);
})

inventoryroutes.post('/inventory/create', function (req, res) {
    inventoryService.createInventory(req, res);
})

inventoryroutes.put('/inventory/update/:inventoryID', function (req, res) {
    inventoryService.updateInventoryByID(req, req.params.inventoryID, res)
})

inventoryroutes.delete('/inventory/delete/:inventoryID', function (req, res) {
    inventoryService.deleteInventory(req, req.params.inventoryID, res);
})
module.exports = inventoryroutes;