var express = require("express")
var bomroutes = require('express').Router();
var bodyparser = require("body-parser");
var BomService = require('../../service/Raw Material/BomService');



//for get
bomroutes.use(bodyparser.json());
bomroutes.get("/bom/:bomId", function (req, res) {
  // console.log("in /bom route, Id ", req.params.bomId);
  if (req.params.bomId >= 1)
    BomService.getbomId(req.params.bomId, res);
  else if (req.params.bomId == "all") BomService.getAllbom(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
bomroutes.post("/bom/create", function (req, res) {
  // console.log("create body=", req.body);
  BomService.createbom(req, res);
});

//for update
bomroutes.put("/bom/update/:bomId", function (req, res) {
  // console.log(req.params.bomId);
  BomService.updateById(req, req.params.bomId, res);
});

//for delete
bomroutes.delete("/bom/delete/:bomId", function (req, res) {
  BomService.deleteById(req.params.bomId, res);
});

module.exports = bomroutes;