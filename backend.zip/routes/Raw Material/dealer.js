var express = require("express")
var dealerroutes = require('express').Router();
var bodyparser = require("body-parser");
var DealerService = require('../../service/Raw Material/DealerService');



//for get
dealerroutes.use(bodyparser.json());
dealerroutes.get("/dealer/:dealerId", function (req, res) {
  // console.log("in /dealer route, Id ", req.params.dealerId);
  if (req.params.dealerId >= 1)
    DealerService.getdealerId(req.params.dealerId, res);
  else if (req.params.dealerId == "all") DealerService.getAlldealer(req, res);
  else res.json("Entered path is Incorrect ");
});

//for post
dealerroutes.post("/dealer/create", function (req, res) {
  // console.log("create body=", req.body);
  DealerService.createdealer(req, res);
});

//for update
dealerroutes.put("/dealer/update/:dealerId", function (req, res) {
  // console.log(req.params.dealerId);
  DealerService.updateById(req, req.params.dealerId, res);
});

//for delete
dealerroutes.delete("/dealer/delete/:dealerId", function (req, res) {
  DealerService.deleteById(req.params.dealerId, res);
});

module.exports = dealerroutes;