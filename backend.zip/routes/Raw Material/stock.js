const express = require('express');
const stockroutes = require('express').Router();
const stockService = require('../../service/Raw Material/StockService');
const bodyparser = require('body-parser');
stockroutes.use(bodyparser.json());
stockroutes.get('/stock/all', function (req, res) {
    stockService.getAllStock(req, res);
})
stockroutes.get('/stock/getStockByFarmerID/:getStockByFarmerID', function (req, res) {
    stockService.getStockByFarmerID(req, req.params.getStockByFarmerID, res);
})
stockroutes.get('/materials/all', function (req, res) {
    stockService.getStockMaterials(req, res);
})
stockroutes.get('/getMaterialCatByMatID/:getMaterialCatByMatID', function (req, res) {
    stockService.getMaterialCatByMatID(req, req.params.getMaterialCatByMatID, res);
})
stockroutes.get('/units/all', function (req, res) {
    stockService.getUnits(req, res);
})
stockroutes.get('/location/all', function (req, res) {
    stockService.getLoaction(req, res);
})
stockroutes.post('/stock/create', function (req, res) {
    stockService.createStock(req, res);
})
stockroutes.put('/stock/update/:stockId', function (req, res) {
    // console.log("stock id is  ",req.params.stockId);
    stockService.updateStockByID(req, req.params.stockId, res);
})
stockroutes.delete('/stock/delete/:stockId', function (req, res) {
    stockService.deleteStockByID(req, req.params.stockId, res)
})

module.exports = stockroutes;