var express = require('express');
var watertestdataroutes = express.Router();
var bodyparser = require('body-parser');
var bodyparser = require('body-parser');
var WaterTestdataService = require('../../service/WaterData/WaterTestDataService');
watertestdataroutes.use(bodyparser.json());

//for get
watertestdataroutes.get('/watertestdata/:watertestdataId', function (req, res) {
	console.log('in /watertestdata route, Id', req.params.watertestdataId, res);
	if (req.params.watertestdataId >= 1) WaterTestdataService.getWaterTestDataById(req.params.watertestdataId, res);
	else if (req.params.watertestdataId == 'all') WaterTestdataService.getAllWaterTestData(req, res);
	else res.json('Entered path is Incorrect :-( ');
});

// for post
watertestdataroutes.post('/watertestdata/create', function (req, res) {
	console.log('create body=', req.body);
	WaterTestdataService.createWaterTestData(req, res);
});

//for update
watertestdataroutes.put('/watertestdata/update/:watertestdataId', function (req, res) {
	console.log(req.body);
	WaterTestdataService.updateById(req, req.params.watertestdataId, res);
});

//for delete
watertestdataroutes.delete('/watertestdata/delete/:watertestdataId', function (req, res) {
	WaterTestdataService.deleteById(req.params.watertestdataId, res);
});

module.exports = watertestdataroutes;
