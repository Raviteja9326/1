var express = require("express")
var watercategoryroutes = require('express').Router();
var bodyparser = require("body-parser");
var waterCategoryService = require('../../service/WaterData/WaterCategoryService');


//for get
watercategoryroutes.use(bodyparser.json());
watercategoryroutes.get("/watercategory/:watercategoryId", function (req, res) {
  // console.log("in /waterCategory route, Id ", req.params.watercategoryId);
  if (req.params.watercategoryId >= 1)
    waterCategoryService.getWaterCategoryById(req.params.watercategoryId, res);
  else if (req.params.watercategoryId == "all") waterCategoryService.getAllWaterCategory(req, res);
  else res.json("Entered path is Incorrect ");
});


//for post
watercategoryroutes.post("/watercategory/create", function (req, res) {
  // console.log("create body=", req.body);
  waterCategoryService.createWaterCategory(req, res);
});

//for update
watercategoryroutes.put("/watercategory/update/:watercategoryId", function (req, res) {
  waterCategoryService.updateById(req, req.params.watercategoryId, res);
});

//for delete
watercategoryroutes.delete("/watercategory/delete/:watercategoryId", function (req, res) {
  waterCategoryService.deleteById(req.params.watercategoryId, res);
});



module.exports = watercategoryroutes;
