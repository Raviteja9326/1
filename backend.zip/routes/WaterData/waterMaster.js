var express = require("express")
var watermasterroutes = require('express').Router();
var bodyparser = require("body-parser");
var waterMasterService = require('../../service/WaterData/waterMasterService');


//for get
watermasterroutes.use(bodyparser.json());
watermasterroutes.get("/watermaster/:watermasterId", function (req, res) {
  // console.log("in /waterCategory route, Id ", req.params.watermasterId);
  if (req.params.watermasterId >= 1)
    waterMasterService.getWaterMasterById(req.params.watermasterId, res);
  else if (req.params.watermasterId == "all") waterMasterService.getAllWaterMaster(req, res);
  else res.json("Entered path is Incorrect ");
});


//for post
watermasterroutes.post("/watermaster/create", function (req, res) {
  // console.log("create body=", req.body);
  waterMasterService.createWaterMaster(req, res);
});

//for update
watermasterroutes.put("/watermaster/update/:watermasterId", function (req, res) {
  waterMasterService.updateById(req, req.params.watermasterId, res);
});

//for delete
watermasterroutes.delete("/watermaster/delete/:watermasterId", function (req, res) {
  waterMasterService.deleteById(req.params.watermasterId, res);
});



module.exports = watermasterroutes;
