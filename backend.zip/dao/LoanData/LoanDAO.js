var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function LoanDAO() {
    this.getAllLoans = async function (req, res) {


        // console.log("error", err);
        var sql = "SELECT lt.*, fr.FarmerName,fr.SurName,sr.PaymentFrequency FROM TblLoan lt LEFT JOIN TblFarmer fr ON lt.TblFarmer_ID=fr.ID LEFT JOIN TblPaymentFrequency sr ON lt.PaymentFrequency_ID=sr.ID  WHERE lt.isDeleted=1 AND fr.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.getLoanDataByUser = (userID, res) => {
        try {
            var sql = `SELECT lt.*, fr.FarmerName,fr.SurName,sr.PaymentFrequency FROM TblLoan lt LEFT JOIN TblFarmer fr ON lt.TblFarmer_ID=fr.ID LEFT JOIN TblPaymentFrequency sr ON lt.PaymentFrequency_ID=sr.ID  WHERE lt.isDeleted=1 AND fr.isDeleted=1 AND fr.TblMandal IN(SELECT man.ID FROM TblMandal man  WHERE man.TblC3Office_C3OfficeID IN (SELECT userc3.TblC3Office_ID FROM TblUserC3 userc3 WHERE userc3.TblUser_ID=${userID}))`;
            connection.query(sql).then((data) => {
                res.json(data);
            });
        } catch (error) {
            res.json('Internal Server Error');
        }
    };


    this.getAllPaymentFrequency = async function (req, res) {


        // console.log("error", err);
        var sql = "SELECT *  FROM TblPaymentFrequency";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    }
    this.getLoanById = function (loanId, res) {


        // console.log("error", err);
        var sql = "SELECT lt.*,fr.FarmerName,fr.SurName FROM TblLoan lt LEFT JOIN TblFarmer fr ON lt.TblFarmer_ID=fr.ID  WHERE lt.isDeleted=1 AND fr.isDeleted=1 AND lt.ID=?";
        try {
            connection.query(sql, loanId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };

    this.checkLoanExists = function (LoanNumber) {

        // console.log("getting checkLoanExists ", LoanNumber);
        return new Promise(function (resolve, reject) {

            // console.log("error", err);
            var sql =
                "SELECT count(*) totalCount FROM TblLoan where isDeleted=1 AND LoanNumber like ?";
            try {
                connection.query(sql, LoanNumber.toUpperCase().trim()).then(data => {
                    if (data[0].totalCount == 0) {
                        return resolve()
                    }
                    else {
                        reject()
                    };
                })
            }
            catch (error) {
                res.status(HttpStatus.getStatusCode('Server Error')).json({
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                })
            }
        })
    };


    this.createLoan = function (req, res) {


        // console.log("error", err);
        var post = {
            LoanAmount: req.body.LoanAmount,
            LoanNumber: req.body.LoanNumber,
            LoanPurpose: req.body.LoanPurpose,
            LoanDate: req.body.LoanDate,
            LoanOfficer: req.body.LoanOfficer,
            LoanBank: req.body.LoanBank,
            LoanBankBranch: req.body.LoanBankBranch,
            LoanIntrest: req.body.LoanIntrest,
            Status: req.body.Status,
            Tenure: req.body.Tenure,
            PaymentFrequency_ID: req.body.PaymentFrequency_ID,
            OutstandingAmount: req.body.OutstandingAmount,
            TblFarmer_ID: req.body.TblFarmer_ID,
            created_by: req.body.created_by

        };
        var sql = "INSERT INTO TblLoan SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };

    this.updateLoan = function (loanId, req, res) {
        // console.log(req.body)

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.LoanAmount,
            req.body.LoanNumber,
            req.body.LoanPurpose,
            req.body.LoanDate,
            req.body.LoanOfficer,
            req.body.LoanBank,
            req.body.LoanBankBranch,
            req.body.LoanIntrest,
            req.body.Status,
            req.body.Tenure,
            req.body.PaymentFrequency_ID,
            req.body.OutstandingAmount,
            req.body.TblFarmer_ID,

            req.body.modified_by,
            loanId
        ]
        var sql = `UPDATE TblLoan SET LoanAmount=?,LoanNumber=?,LoanPurpose=?,LoanDate=?,LoanOfficer=?,LoanBank=?,LoanBankBranch=?,LoanIntrest=?,Status=?,Tenure=?,PaymentFrequency_ID=?,OutstandingAmount=?,TblFarmer_ID=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

        try {
            connection.query(sql, loanId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };

    this.removeLoan = function (loanId, res) {


        // console.log("error", err);
        var sql = `UPDATE TblLoan m
            LEFT JOIN TblLoanEMI c ON c.TblLoan_ID=m.ID
             SET  m.isDeleted=0,
             c.isDeleted=0
             WHERE m.ID='${loanId}'`;
        try {
            connection.query(sql, loanId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}
module.exports = new LoanDAO();