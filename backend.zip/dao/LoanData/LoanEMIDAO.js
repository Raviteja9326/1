var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function LoanEMIDAO() {
	this.getAllLoanEMI = async function (res) {
		// console.log("error", err);
		var sql =
			'SELECT a.*,b.FarmerName,b.SurName,c.LoanNumber FROM TblLoanEMI a LEFT JOIN TblLoan c ON c.ID=a.TblLoan_ID LEFT JOIN TblFarmer b ON c.TblFarmer_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getLoanEMIDataByUser = (userID, res) => {
		try {
			var sql = `SELECT a.*,b.FarmerName,b.SurName,c.LoanNumber FROM TblLoanEMI a LEFT JOIN TblLoan c ON c.ID=a.TblLoan_ID LEFT JOIN TblFarmer b ON c.TblFarmer_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND b.TblMandal IN(SELECT man.ID FROM TblMandal man  WHERE man.TblC3Office_C3OfficeID IN (SELECT userc3.TblC3Office_ID FROM TblUserC3 userc3 WHERE userc3.TblUser_ID=${userID}))`;
			connection.query(sql).then((data) => {
				res.json(data);
			});
		} catch (error) {
			res.json('Internal Server Error');
		}
	};

	this.getLoanEMIById = function (loanEMIId, res) {
		// console.log("error", err);
		var sql =
			'SELECT a.*,b.FarmerName,b.SurName FROM TblLoanEMI a LEFT JOIN TblLoan c ON c.ID=a.TblLoan_ID LEFT JOIN TblFarmer b ON c.TblFarmer_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND a.ID=?';
		try {
			connection.query(sql, loanEMIId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	this.createLoanEMI = function (req, res) {
		// console.log("error", err);
		var post = {
			ReceiptNo: req.body.ReceiptNo,
			Amount: req.body.Amount,
			EMIDate: req.body.EMIDate,
			ReceivedBy: req.body.ReceivedBy,
			EMINo: req.body.EMINo,
			PaymentType: req.body.PaymentType,
			CheckNo: req.body.CheckNo,
			Signedby: req.body.Signedby,
			Witness: req.body.Witness,
			GeneralLedgeID: req.body.GeneralLedgeID,
			TblLoan_ID: req.body.TblLoan_ID,
			created_by: req.body.created_by
		};
		var sql = 'INSERT INTO TblLoanEMI SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	this.updateLoanEMI = function (loanEMIId, req, res) {
		// console.log(req.body.ReceiptNo, loanEMIId)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var dataToBeUpdated = [
			req.body.ReceiptNo,
			req.body.Amount,
			req.body.EMIDate,
			req.body.ReceivedBy,
			req.body.EMINo,
			req.body.PaymentType,
			req.body.CheckNo,
			req.body.Signedby,
			req.body.Witness,
			req.body.GeneralLedgeID,
			req.body.TblLoan_ID,
			req.body.modified_by,
			loanEMIId
		];
		var sql = `UPDATE TblLoanEMI SET ReceiptNo=?,Amount=?,EMIDate=?,ReceivedBy=?,EMINo=?,PaymentType=?,CheckNo=?,Signedby=?,Witness=?,GeneralLedgeID=?,TblLoan_ID=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

		try {
			connection.query(sql, loanEMIId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	this.removeLoanEMI = function (loanEMIId, res) {
		// console.log("error", err);
		var sql = `UPDATE TblLoanEMI SET  isDeleted=0 WHERE ID='${loanEMIId}'`;
		try {
			connection.query(sql, loanEMIId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new LoanEMIDAO();
