var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
// for get
function correctionfollowupDAO() {
	this.getAllCorrectionFollowUp = async function (req, res) {


		var sql = "SELECT f .*, a.CorrectionFollowUp From TblCorrectionFollowUp f LEFT JOIN TblCorrectionFollowUp_ID=a.ID WHERE f.is Deleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get by id
	// this.getCorrectionFollowUpById = function (correctionfollowupId, res) {
	//     console.log("testing in dao", correctionfollowupId)
	//     Connection.init();
	//     // get id as parameter to passing into query and return filters data
	//     Connection.acquire(function(err, con))
	//     }








}






module.exports = new correctionfollowupDAO();
