var connection = require('../../dao/MySQLConnect');

function ConsultExpertDAO() {
    this.getAllconsultExpert = async function (req, res) {

        var sql = "SELECT a.*,b.FarmerName,c.RoleName  FROM TblConsultexpert a LEFT JOIN TblFarmer b ON a.FarmerID=b.ID  LEFT JOIN TblRole c ON a.ExpertID=c.ID   WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1";
        try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};


    this.getConsultExpertId = async function (consultexpertId, res) {

        var sql = "SELECT a.*,b.FarmerName,c.RoleName  FROM TblConsultexpert a LEFT JOIN TblFarmer b ON a.FarmerID=b.ID  LEFT JOIN TblRole c ON a.ExpertID=c.ID   WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND ID=?";
        try {
			await connection.query(sql, consultexpertId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};


    this.createconsultExpert = function (req, res) {

        var post = {
            QuerySubject: req.body.QuerySubject,
            QueryDesc: req.body.QueryDesc,
            FarmerID: req.body.FarmerID,
            QueryType: req.body.QueryType,
            ExpertID: req.body.ExpertID,
            ExpertName: req.body.ExpertName,
            created_by: req.body.created_by
        };
        var sql = "INSERT INTO TblConsultexpert SET ?";
        try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};



    this.updateById = function (req, consultexpertId, res) {

        var dataToBeUpdated = [
            req.body.QuerySubject,
            req.body.QueryDesc,
            req.body.FarmerID,
            req.body.QueryType,
            req.body.ExpertID,
            req.body.ExpertName,
            req.body.modified_by,
            consultexpertId
        ]
        try {
			connection.query(sql, consultexpertId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

    this.deleteById = function (consultexpertId, res) {

        var sql = "UPDATE TblConsultexpert SET  isDeleted=0 WHERE ID=?";
        try {
            connection.query(sql, consultexpertId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
    }

module.exports = new ConsultExpertDAO();