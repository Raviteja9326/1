var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function WaterCategoryDAO() {
	this.getAllWaterCategory = async function (req, res) {


		// console.log('error', err);
		var sql = 'SELECT * FROM TblWaterCategory WHERE isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	//get gy id
	this.getWaterCategoryById = async function (watercategoryId, res) {
		// console.log('testing in dao', watercategoryId);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
		var sql = 'SELECT * FROM TblWaterCategory WHERE isDeleted=1 AND ID=?';
		try {
			await connection.query(sql, watercategoryId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//for post

	this.createWaterCategory = function (req, res) {


		// console.log('error', err);

		var post = {
			WaterCategory: req.body.WaterCategory,
			WaterCategorySource: req.body.WaterCategorySource,

			created_by: req.body.created_by,
			modified_by: req.body.modified_by
		};
		var sql = 'INSERT INTO TblWaterCategory SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for checking samesoiltype
	this.checkWaterCategoryExists = function (WaterCategory) {
		// console.log('testing  ', WaterCategory);

		// console.log('getting checkWaterCategoryExists ', WaterCategory.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(function (resolve, reject) {

			// console.log('error', err);
			var sql =
				'SELECT count(*) totalCount FROM TblWaterCategory  where isDeleted=1 AND upper(WaterCategory) like ?';
			try {
				connection.query(sql, WaterCategory.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};


	//for update
	this.updateById = function (req, watercategoryId, res) {
		console.log(watercategoryId);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);

		var sql = `UPDATE TblWaterCategory SET WaterCategory='${req.body.WaterCategory}',WaterCategorySource='${req.body.WaterCategorySource}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${watercategoryId} `;

		try {
			connection.query(sql, watercategoryId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	//for delete
	this.deleteById = function (watercategoryId, res) {



		// console.log('error', err);
		let sql = `UPDATE  TblWaterCategory a 
      LEFT JOIN TblWaterMaster b ON a.ID=b.TblWaterCategory_ID
      SET a.isDeleted=0,b.isDeleted=0 WHERE a.ID = ${watercategoryId}`;
		try {
			connection.query(sql, watercategoryId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new WaterCategoryDAO();
