var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function WaterMasterDAO() {
	this.getAllWaterMaster = async function (req, res) {


		// console.log("error", err);

		var sql = "SELECT  f.*, a.WaterCategory FROM TblWaterMaster f  LEFT JOIN TblWaterCategory a ON  f.TblWaterCategory_ID=a.ID   WHERE f.isDeleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get by id
	this.getWaterMasterById = async function (watermasterId, res) {
		// console.log("testing in dao", watermasterId)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);

		var sql = "SELECT  f.*, a.WaterCategory FROM TblWaterMaster f  LEFT JOIN TblWaterCategory a ON  f.TblWaterCategory_ID=a.ID   WHERE f.isDeleted=1 AND f.ID=?";

		try {
			await connection.query(sql, watermasterId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//for post

	this.createWaterMaster = function (req, res) {


		// console.log("error", err);

		var post = {
			Name: req.body.Name,
			Symbol: req.body.Symbol,
			UnitType: req.body.UnitType,
			VeryLow: req.body.VeryLow,
			Low: req.body.Low,
			Medium: req.body.Medium,
			High: req.body.High,
			VeryHigh: req.body.VeryHigh,
			TblWaterCategory_ID: req.body.TblWaterCategory_ID,
			created_by: req.body.created_by,
			modified_by: req.body.modified_by


		};
		var sql = "INSERT INTO TblWaterMaster SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for checking samesoiltype
	this.checkWaterMasterExists = function (Name) {
		// console.log("testing  ", Name);

		// console.log("getting checkWaterMasterExists ", Name.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(function (resolve, reject) {

			// console.log("error", err);
			var sql =
				"SELECT count(*) totalCount FROM TblWaterMaster where  isDeleted=1 AND upper(Name) like ?";

			try {
				connection.query(sql, Name.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};

	//for update

	this.updateById = function (req, watermasterId, res) {
		// console.log(req.body)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		
		var sql = `UPDATE TblWaterMaster SET Name='${req.body.Name}',Symbol='${req.body.Symbol}',UnitType='${req.body.UnitType}',VeryLow='${req.body.VeryLow}',Low='${req.body.Low}',Medium='${req.body.Medium}',High='${req.body.High}',VeryHigh='${req.body.VeryHigh}',TblWaterCategory_ID='${req.body.TblWaterCategory_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${watermasterId} `;

		try {
			connection.query(sql, watermasterId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};


	//for delete
	this.deleteById = function (watermasterId, res) {



		// console.log("error", err);
		let sql = `UPDATE TblWaterMaster SET isDeleted=0 WHERE ID=${watermasterId}`;
		try {
			connection.query(sql, watermasterId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}
module.exports = new WaterMasterDAO();