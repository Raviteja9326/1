var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function WaterTestDataDAO() {
	this.getAllWaterTestData = async function (req, res) {
		var sql =
			"SELECT a.*,b.FarmerName,b.SurName,JSON_ARRAYAGG(JSON_OBJECT('count',c.count,'Tbl_WaterMaster_ID',c.Tbl_WaterMaster_ID)) as watermasterlist FROM TblWaterTestData a LEFT JOIN TblFarmer b ON a.TblFarmer_ID=b.ID LEFT JOIN TblWaterTestDetails c ON c.Tbl_WaterTestData_ID = a.ID  WHERE a.isDeleted=1 GROUP BY a.ID";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get gy id
	this.getWaterTestDataById = function (watertestdataId, res) {
		console.log('testing in dao', watertestdataId);
		var sql =
			'SELECT a.*,d.FarmerName,d.SurName FROM TblWaterTestData a LEFT JOIN TblFarmer d ON a.TblFarmer_ID=d.ID WHERE a.ID=? ';
		connection.query(sql, watertestdataId, function (err, data) {
			console.log('data of first form', data);
			if (err) console.log('error in query', err);
			else {
				var sql1 =
					'SELECT count,Tbl_WaterMaster_ID,a.Name,a.Symbol FROM TblWaterTestDetails LEFT JOIN TblWaterMaster a ON Tbl_WaterMaster_ID=a.ID WHERE Tbl_WaterTestData_ID=?';
				connection.query(sql1, watertestdataId, function (err, data1) {
					console.log('2nd form data', data1);
					if (err) console.log('error in 2nd query', err);
					else {
						let waterlist = data1;
						var waterresult = {
							ID: data[0].ID,
							TestAgentID: data[0].TestAgentID,
							SampleNumber: data[0].SampleNumber,
							SampleRecivedDate: data[0].SampleRecivedDate,
							TestCompletedDate: data[0].TestCompletedDate,
							SampleQyantity: data[0].SampleQyantity,
							SamplePackaging: data[0].SamplePackaging,
							VerifiedBy: data[0].VerifiedBy,
							Remarks: data[0].Remarks,
							FarmerName: data[0].FarmerName,
							SurName: data[0].SurName,
							LandName: data[0].LandName,
							created_by: data[0].created_by,
							TblFarmer_ID: data[0].TblFarmer_ID,
							result: waterlist
						};
					}
					res.json(waterresult);
				});
			}
		});
	};

	//for posting data
	this.createWaterTestData = function (req, res) {
		var dataToBePosted = {
			TestAgentID: req.body.TestAgentID,
			SampleNumber: req.body.SampleNumber,
			SampleRecivedDate: req.body.SampleRecivedDate,
			TestCompletedDate: req.body.TestCompletedDate,
			SampleQyantity: req.body.SampleQyantity,
			SamplePackaging: req.body.SamplePackaging,
			VerifiedBy: req.body.VerifiedBy,
			Remarks: req.body.Remarks,
			TblFarmer_ID: req.body.TblFarmer_ID,
			created_by: req.body.created_by
		};
		var sql = 'INSERT INTO TblWaterTestData SET ?';
		connection.query(sql, dataToBePosted, function (err, data) {
			if (err) console.log('error inn first query', err);
			var waterTestID = data.insertId;

			for (let index = 0; index < req.body.watermasterlist.length; index++) {
				var datapostinwatertestdetails = {
					count: req.body.watermasterlist[index].count,
					Tbl_WaterMaster_ID: req.body.watermasterlist[index].Tbl_WaterMaster_ID,
					Tbl_WaterTestData_ID: waterTestID
				};
				var sql1 = 'INSERT INTO TblWaterTestDetails SET ?';
				connection.query(sql1, datapostinwatertestdetails, function (err, result) {
					if (err) console.log('error in second query', err);
				});
			}
			res.json({ data: 'Success' });
		});
	};

	//for delete
	this.deleteById = function (watertestdataId, res) {
		console.log('id from DAO', watertestdataId);
		var sql =
			'UPDATE TblWaterTestData a LEFT JOIN TblWaterTestDetails b ON b.Tbl_WaterTestData_ID =a.ID SET a.isDeleted=0,b.isDeleted=0 WHERE a.ID=?';
		connection.query(sql, watertestdataId, function (err, result) {
			if (err) console.log('error in query', err);
			console.log('this is result ', result);
			res.json({ data: 'Success' });
		});
	};

	//for update
	this.updateById = function (req, watertestdataId, res) {
		console.log('before update', req.body);
		var datatobeupdate = [
			req.body.TestAgentID,
			req.body.SampleNumber,
			req.body.SampleRecivedDate,
			req.body.TestCompletedDate,
			req.body.SampleQyantity,
			req.body.SamplePackaging,
			req.body.VerifiedBy,
			req.body.Remarks,
			req.body.TblFarmer_ID,
			req.body.modified_by,
			watertestdataId
		];
		console.log('rtghhg', datatobeupdate);
		var sql = `UPDATE TblWaterTestData SET TestAgentID=?,SampleNumber=?,SampleRecivedDate=?,TestCompletedDate=?,
			SampleQyantity=?,SamplePackaging=?,VerifiedBy=?,Remarks=?,TblFarmer_ID=?,modified_by=? WHERE isDeleted=1 AND ID=?`;
		connection.query(sql, datatobeupdate, function (err, result) {
			console.log('liattttttt', req.body.watermasterlist.length);
			for (let index = 0; index < req.body.watermasterlist.length; index++) {
				var dataToUpdateInSoilTestDetails = {
					count: req.body.watermasterlist[index].count,
					Tbl_WaterMaster_ID: req.body.watermasterlist[index].Tbl_WaterMaster_ID,
					Tbl_WaterTestData_ID: watertestdataId
				};
				var dCompar = [
					{ count: req.body.watermasterlist[index].count },
					{ Tbl_WaterMaster_ID: req.body.watermasterlist[index].Tbl_WaterMaster_ID },
					{ Tbl_WaterTestData_ID: watertestdataId }
				];
				var dCompar1 = [
					{ Tbl_WaterMaster_ID: req.body.watermasterlist[index].Tbl_WaterMaster_ID },
					{ Tbl_WaterTestData_ID: watertestdataId }
				];
				//console.log('dcom', dCompar);
				//console.log('dcom1', dCompar1);
				//var sql2 = 'SELECT ID FROM TblSoilTestDetails WHERE ? AND ? ';
				//acquiredDBConnection.query(sql2, dCompar1, function(err, result) {
				//	console.log('res ', result);
				//	if (err) console.log('error from details', err);
				//	if (result.length > 0) {
				//		console.log('action update');
				var sql1 = 'UPDATE TblWaterTestDetails SET ? WHERE ? AND ?';
				connection.query(sql1, dCompar, function (err, result) {
					if (err) console.log('error from details', err);
					console.log('result after update', result);
				});
				// } else {
				// 	console.log('action insert');
				// 	var sql1 = 'INSERT INTO TblSoilTestDetails SET ?';
				// 	acquiredDBConnection.query(sql1, dataToUpdateInSoilTestDetails, function(err, result) {
				// 		if (err) console.log('error from details', err);
				// 		console.log('jamk', dataToUpdateInSoilTestDetails);
				// 	});
				// }
				//});
			}
			res.status(200).json({ data: 'Success' });
		});
	};
}
module.exports = new WaterTestDataDAO();
