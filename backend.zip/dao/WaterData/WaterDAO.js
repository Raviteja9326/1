var connection = require('./MySQLConnect');

function WaterDAO() {

    this.getWaterDetailsByFarmerId = function (farmerId, res) {

        // get id as parameter to passing into query and return filter data  

        var sql = "select wm.water_test_type_name , wtd.water_test_result, DATE_FORMAT(date(wt.water_test_date), '%d-%m-%Y') 'water_test_date' from AgriXrp_Dev.water_master wm, AgriXrp_Dev.water_test wt, AgriXrp_Dev.water_test_details wtd where wm.water_test_type_id = wt.water_test_id and wt.water_test_id = wtd.water_test_id and wt.farmer_id=?;";
        try {
            connection.query(sql, farmerId).then(data => {
               if (data.length == 0) {
                   res.json({
                       data: "No Data Available with this ID"
                   })
               }
               else {
                   res.status(HttpStatus.OK).json(data)
               }
           })
       }
       catch (error) {
           res.status(HttpStatus.getStatusCode('Server Error')).json({
               message: error.message,
               status: HttpStatus.getStatusCode('Server Error')

           })
       }
   };
}
module.exports = new WaterDAO();  
