const connection = require('../MySQLConnect');
var HttpStatus = require('http-status-codes');
function StockDAO() {
	this.getAllStock = async function (req, res) {
		try {
			var sql =
				'SELECT a.*,b.FarmerName,b.SurName,c.MatName,d.MatCatName,e.Name,f.Units FROM TblStock a LEFT JOIN TblFarmer b ON a.TblFarmer_ID=b.ID  LEFT JOIN TblMaterials c ON a.TblMaterials_ID=c.ID  LEFT JOIN TblMatCategory d ON a.TblMatCategory_ID=d.ID  LEFT JOIN TblLocation e ON a.TblLocation_ID=e.ID  LEFT JOIN TblUnits f ON a.TblUnits_ID=f.ID WHERE a.isDeleted=1 AND b.isDeleted=1  ';
			try {
				connection.query(sql, function (err, result) {
					res.json(result);
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.getStockMaterials = function (req, res) {
		// console.log('error', err);
		var sql = 'SELECT * FROM TblMaterials ';
		connection.query(sql, function (err, result) {
			// console.log('error', err);
			res.json(result);
		});
	};

	this.getLoaction = function (req, res) {
		// console.log('error', err);
		var sql = 'SELECT * FROM TblLocation ';
		connection.query(sql, function (err, result) {
			// console.log('error', err);
			res.json(result);
		});
	};

	this.getUnits = function (req, res) {
		var sql = 'SELECT * FROM TblUnits ';
		connection.query(sql, function (err, result) {
			// console.log('error', err);
			res.json(result);
		});
	};

	this.getMaterialCatByMatID = function (req, matID, res) {
		try {
			var sql = 'SELECT * FROM TblMatCategory WHERE TblMaterials_ID=?';
			try {
				connection.query(sql, matID, function (err, result) {
					res.json(result);
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.getStockByFarmerID = function (req, farmerID, res) {
		try {

			var sql =
				'SELECT a.*,b.FarmerName,b.SurName,c.MatName,d.MatCatName,e.Name,f.Units FROM TblStock a LEFT JOIN TblFarmer b ON a.TblFarmer_ID=b.ID  LEFT JOIN TblMaterials c ON a.TblMaterials_ID=c.ID  LEFT JOIN TblMatCategory d ON a.TblMatCategory_ID=d.ID  LEFT JOIN TblLocation e ON a.TblLocation_ID=e.ID  LEFT JOIN TblUnits f ON a.TblUnits_ID=f.ID WHERE a.isDeleted=1 AND b.isDeleted=1  AND a.TblFarmer_ID= ? ';
			try {
				connection.query(sql, farmerID, function (err, result) {
					res.json(result);
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.createStock = function (req, res) {
		try {
			var sql = `SELECT * FROM TblStock WHERE ByProduct='${req.body.ByProduct}' AND ByProductID='${req.body
				.ByProductID}' AND TblFarmer_ID='${req.body.TblFarmer_ID}' AND TblUnits_ID='${req.body
					.TblUnits_ID}' AND TblLocation_ID='${req.body.TblLocation_ID}' AND TblMaterials_ID='${req.body
						.TblMaterials_ID}' AND TblMatCategory_ID='${req.body.TblMatCategory_ID}' AND isDeleted=1`;
			connection.query(sql, function (err, result) {
				// console.log('error from total', err);
				if (result.length > 0) {
					var newQuantity = result[0].Quantity;
					newQuantity += req.body.Quantity;
					var sql1 = `UPDATE TblStock SET Quantity='${newQuantity}' WHERE ID ='${result[0].ID} '`;
					connection.query(sql1, function (err, result) {
						// console.log('error', err);
						res.json({ data: 'Success' });
					});
				} else {
					var sql2 = 'INSERT INTO TblStock SET ?';
					var post = {
						Quantity: req.body.Quantity,
						ByProductID: req.body.ByProductID,
						TblFarmer_ID: req.body.TblFarmer_ID,
						ByProduct: req.body.ByProduct,
						TblUnits_ID: req.body.TblUnits_ID,
						TblLocation_ID: req.body.TblLocation_ID,
						TblMaterials_ID: req.body.TblMaterials_ID,
						TblMatCategory_ID: req.body.TblMatCategory_ID,
						created_by: req.body.created_by
					};
					connection.query(sql2, post, function (err, result) {
						// console.log('error', err);

						res.json({ data: 'Success' });
					});
				}
			});
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.updateStockByID = function (req, stockID, res) {
		// console.log('stock id is  ', stockID);
		try {

			var dataToUpdate = [
				req.body.Quantity,
				req.body.ByProduct,
				req.body.ByProductID,
				req.body.TblFarmer_ID,
				req.body.TblUnits_ID,
				req.body.TblLocation_ID,
				req.body.TblMaterials_ID,
				req.body.TblMatCategory_ID,
				req.body.modified_by,
				stockID
			];
			var sql = `UPDATE TblStock SET Quantity=?, ByProduct=? , ByProductID=? , TblFarmer_ID=? , TblUnits_ID=? , TblLocation_ID=?, TblMaterials_ID=? , TblMatCategory_ID=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;
			try {
				connection.query(sql, dataToUpdate, function (err, result) {
					res.status(200).json({ data: 'Success' });
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.deleteStockByID = function (req, stockID, res) {
		try {

			var sql = `UPDATE TblStock SET isDeleted=0 where ID='${stockID}'`;
			try {
				connection.query(sql, stockID, function (err, result) {
					res.json({ data: 'Success' });
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};
}

module.exports = new StockDAO();
