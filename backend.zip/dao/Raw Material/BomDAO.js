var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function BomDAO() {
  this.getAllbom = async function (req, res) {


    // console.log("error", err);

    var sql =
      "SELECT a.*,q.Quantity,b.FarmerName,b.SurName,c.MatName,d.MatCatName,e.Name,f.Units FROM TblBOM a   LEFT JOIN TblStock q ON a.TblStock_ID=q.ID LEFT JOIN TblFarmer b ON q.TblFarmer_ID=b.ID  LEFT JOIN TblMaterials c ON q.TblMaterials_ID=c.ID  LEFT JOIN TblMatCategory d ON q.TblMatCategory_ID=d.ID  LEFT JOIN TblLocation e ON q.TblLocation_ID=e.ID  LEFT JOIN TblUnits f ON q.TblUnits_ID=f.ID WHERE a.isDeleted=1 AND q.isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getbomId = async function (bomId, res) {
    // console.log("testing in dao", bomId);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql =
      "SELECT a.*,q.Quantity,b.FarmerName,b.SurName,c.MatName,d.MatCatName,e.Name,f.Units FROM TblBOM a   LEFT JOIN TblStock q ON a.TblStock_ID=q.ID LEFT JOIN TblFarmer b ON q.TblFarmer_ID=b.ID  LEFT JOIN TblMaterials c ON q.TblMaterials_ID=c.ID  LEFT JOIN TblMatCategory d ON q.TblMatCategory_ID=d.ID  LEFT JOIN TblLocation e ON q.TblLocation_ID=e.ID  LEFT JOIN TblUnits f ON q.TblUnits_ID=f.ID WHERE a.isDeleted=1 AND q.isDeleted=1 AND q.TblFarmer_ID=?";
    try {
      await connection.query(sql, bomId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };


  //for post

  this.createbom = function (req, res) {


    // console.log("error", err);
    var post = {
      Qty: req.body.Qty,

      TblUnits_ID: req.body.TblUnits_ID,
      UnitCost: req.body.UnitCost,
      Cost: req.body.Cost,
      Tbl_StockParentID: req.body.Tbl_StockParentID,
      Level: req.body.Level,
      TblStock_ID: req.body.TblStock_ID,
      created_by: req.body.created_by,
      modified_by: req.body.modified_by
    };
    var sql = "INSERT INTO TblBOM SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  // //for checking samedealer
  // this.checkbomExists = function(MatCatName) {
  //   // console.log("testing type", MatCatName);
  //   
  //   // console.log("getting checkbomExists ", MatCatName.toUpperCase());
  //   // get id as parameter to passing into query and return filter data
  //   return new Promise(function(resolve, reject) {
  //     connection.acquire(function(err, con) {
  //       // console.log("error", err);
  //       var sql =
  //         "SELECT count(bom.ID) totalCount, upper(mc.MatCatName) FROM TblBOM bom left join TblStock ts on bom.TblStock_ID = ts.ID left join TblMatCategory mc on ts.TblMatCategory_ID = mc.ID  where bom.isDeleted=1 AND upper(mc.MatCatName) like ? group by mc.ID";
  //       connection.query(sql, MatCatName.toUpperCase(), function(err, result) {
  //         // console.log("result", result);
  //         
  //         if (result.length != 0 && result[0].totalCount == 0)
  //           return resolve(true);
  //         else reject(new Error("name already exists!"));
  //       });
  //     });
  //   });
  // };

  //for update
  this.updateById = function (req, bomId, res) {
    // console.log(req.body);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var dataToBeUpdated = [
      req.body.Qty,
      req.body.TblUnits_ID,
      req.body.UnitCost,
      req.body.Cost,
      req.body.Tbl_StockParentID,
      req.body.Level,
      req.body.TblStock_ID,
      req.body.modified_by,
      bomId
    ];
    var sql = `UPDATE TblBOM SET Qty=?,TblUnits_ID=?,UnitCost=?,Cost=?,Tbl_StockParentID=?,Level=?,TblStock_ID=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

    try {
      connection.query(sql, bomId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };
  //for delete
  this.deleteById = function (Id, res) {



    // console.log("error", err);
    let sql = `UPDATE TblBOM SET isDeleted=0 WHERE ID =${Id}`;
    try {
      connection.query(sql, Id).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new BomDAO();
