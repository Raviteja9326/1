var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function DealerDAO() {
  this.getAlldealer = async function (req, res) {


    // console.log("error", err);
    var sql =
      "SELECT  f.*, a.StateName,b.DistrictName,c.MandalName,d.VillageName,e.CompanyName,g.CountryName FROM TblDealer f  LEFT JOIN TblState a ON  f.TblState_ID=a.ID LEFT JOIN TblDistrict b ON f.TblDistrict_ID=b.ID  LEFT JOIN TblMandal c ON f.TblMandal_ID=c.ID LEFT JOIN TblVillage d ON f.TblVillage_ID=d.ID LEFT JOIN TblCompanyMaster e ON f.TblFertilizerCompanyMaster_ID=e.ID LEFT JOIN TblCountry g ON f.TblCountry_ID=g.ID WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND d.isDeleted=1 AND e.isDeleted=1 AND g.isDeleted=1 ";

    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getdealerId = async function (dealerId, res) {
    // console.log("testing in dao", dealerId);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql =
      "SELECT  f.*, a.StateName,b.DistrictName,c.MandalName,d.VillageName,e.CompanyName,g.CountryName FROM TblDealer f  LEFT JOIN TblState a ON  f.TblState_ID=a.ID LEFT JOIN TblDistrict b ON f.TblDistrict_ID=b.ID  LEFT JOIN TblMandal c ON f.TblMandal_ID=c.ID LEFT JOIN TblVillage d ON f.TblVillage_ID=d.ID LEFT JOIN TblCompanyMaster e ON f.TblFertilizerCompanyMaster_ID=e.ID LEFT JOIN TblCountry g ON f.TblCountry_ID=g.ID WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND d.isDeleted=1 AND e.isDeleted=1 AND g.isDeleted=1  AND f.ID=?";
    try {
      await connection.query(sql, dealerId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };


  //for post

  this.createdealer = function (req, res) {


    // console.log("error", err);
    var post = {
      DealerName: req.body.DealerName,
      DealerType: req.body.DealerType,
      SellsFertilizerType: req.body.SellsFertilizerType,
      Dealeraddress: req.body.Dealeraddress,
      LicenseStartDate: req.body.LicenseStartDate,
      LicenseEndDate: req.body.LicenseEndDate,
      TblCountry_ID: req.body.TblCountry_ID,
      TblState_ID: req.body.TblState_ID,
      TblDistrict_ID: req.body.TblDistrict_ID,
      TblMandal_ID: req.body.TblMandal_ID,
      TblVillage_ID: req.body.TblVillage_ID,
      ContactNos: req.body.ContactNos,
      ContactPersonName: req.body.ContactPersonName,
      Website: req.body.Website,
      Email: req.body.Email,
      TblFertilizerCompanyMaster_ID: req.body.TblFertilizerCompanyMaster_ID,
      created_by: req.body.created_by
    };
    var sql = "INSERT INTO TblDealer SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  //for checking samedealer
  this.checkdealerExists = function (DealerName) {
    // console.log("testing type", labour);

    // console.log("getting checkdealerExists ", labour.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblDealer where isDeleted=1 AND upper(DealerName) like ?";
      try {
        connection.query(sql, DealerName.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };
  //for update
  this.updateById = function (req, dealerId, res) {
    // console.log(req.body);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var dataToBeUpdated = [
      req.body.DealerName,
      req.body.DealerType,
      req.body.SellsFertilizerType,
      req.body.Dealeraddress,
      req.body.LicenseStartDate,
      req.body.LicenseEndDate,
      req.body.TblCountry_ID,
      req.body.TblState_ID,
      req.body.TblDistrict_ID,
      req.body.TblMandal_ID,
      req.body.TblVillage_ID,
      req.body.ContactNos,
      req.body.ContactPersonName,
      req.body.Website,
      req.body.Email,
      req.body.TblFertilizerCompanyMaster_ID,

      req.body.modified_by,
      dealerId
    ];
    var sql = `UPDATE TblDealer SET DealerName='${req.body.DealerName}',DealerType='${req.body.DealerType}',SellsFertilizerType='${req.body.SellsFertilizerType}',Dealeraddress='${req.body.Dealeraddress}',LicenseStartDate='${req.body.LicenseStartDate}',LicenseEndDate='${req.body.LicenseEndDate}',TblCountry_ID='${req.body.TblCountry_ID}',TblState_ID='${req.body.TblState_ID}',TblDistrict_ID='${req.body.TblDistrict_ID}',TblMandal_ID='${req.body.TblMandal_ID}',TblVillage_ID='${req.body.TblVillage_ID}',ContactNos='${req.body.ContactNos}',ContactPersonName='${req.body.ContactPersonName}',Website='${req.body.Website}',Email='${req.body.Email}',TblFertilizerCompanyMaster_ID='${req.body.TblFertilizerCompanyMaster_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${dealerId} `;

    try {
      connection.query(sql, dealerId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };
  //for delete
  this.deleteById = function (Id, res) {



    // console.log("error", err);
    let sql = `UPDATE TblDealer SET isDeleted=0 WHERE ID =${Id}`;
    try {
      connection.query(sql, Id).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new DealerDAO();
