var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function InventoryDAO() {
	this.getAllInventories = async function (req, res) {
		try {
			var sql =
				'SELECT a.*,q.Quantity,b.FarmerName,b.SurName,c.MatName,d.MatCatName,e.Name,f.Units FROM TblInventory a   LEFT JOIN TblStock q ON a.TblStock_ID=q.ID LEFT JOIN TblFarmer b ON q.TblFarmer_ID=b.ID  LEFT JOIN TblMaterials c ON q.TblMaterials_ID=c.ID  LEFT JOIN TblMatCategory d ON q.TblMatCategory_ID=d.ID  LEFT JOIN TblLocation e ON q.TblLocation_ID=e.ID  LEFT JOIN TblUnits f ON q.TblUnits_ID=f.ID WHERE a.isDeleted=1 AND q.isDeleted=1 ';
			try {
				connection.query(sql, function (err, result) {
					res.json(result);
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.getInventoryByFarmerID = function (req, farmerID, res) {
		try {
			var sql =
				'SELECT a.*,q.Quantity,b.FarmerName,b.SurName,c.MatName,d.MatCatName,e.Name,f.Units FROM TblInventory a   LEFT JOIN TblStock q ON a.TblStock_ID=q.ID LEFT JOIN TblFarmer b ON q.TblFarmer_ID=b.ID  LEFT JOIN TblMaterials c ON q.TblMaterials_ID=c.ID  LEFT JOIN TblMatCategory d ON q.TblMatCategory_ID=d.ID  LEFT JOIN TblLocation e ON q.TblLocation_ID=e.ID  LEFT JOIN TblUnits f ON q.TblUnits_ID=f.ID WHERE a.isDeleted=1 AND q.isDeleted=1 AND q.TblFarmer_ID=?';
			try {
				connection.query(sql, farmerID, function (err, result) {
					res.status(200).json(result);
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.createInventory = function (req, res) {
		try {
			var post = {
				InventoryDate: req.body.InventoryDate,
				SalesOrderID: req.body.SalesOrderID,
				ReceivedBy: req.body.ReceivedBy,
				ReceivedDate: req.body.ReceivedDate,
				TblStock_ID: req.body.TblStock_ID,
				created_by: req.body.created_by
			};
			var sql = 'INSERT INTO TblInventory SET ?';
			try {
				connection.query(sql, post, function (err, result) {
					res.status(200).json({ data: 'Success' });
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.updateInventoryByID = function (req, inventoryID, res) {
		try {
			var dataToUpdate = [
				req.body.InventoryDate,
				req.body.SalesOrderID,
				req.body.ReceivedBy,
				req.body.ReceivedDate,
				req.body.TblStock_ID,
				req.body.modified_by,
				inventoryID
			];
			var sql = `UPDATE TblInventory SET InventoryDate=?,SalesOrderID=?,ReceivedBy=?,ReceivedDate=?,TblStock_ID=?,modified_by=? WHERE isDeleted=1 AND ID=?`;
			try {
				connection.query(sql, dataToUpdate, function (err, result) {

					res.status(200).json({ data: 'Success' });
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};

	this.deleteInventory = function (req, inventoryID, res) {
		try {
			var sql = `UPDATE TblInventory SET isDeleted=0 WHERE ID='${inventoryID}'`;
			try {
				connection.query(sql, inventoryID, function (err, result) {
					res.status(200).json({ data: 'Success' });
				});
			} catch (err) {
				res.json('Some Error Occured');
			}
		} catch (err) {
			res.json('Some Error Occured in connecting Data Base');
		}
	};
}
module.exports = new InventoryDAO();
