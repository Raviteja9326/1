var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function suppliertypeDAO() {
	this.getAllsuppliertype = async function (req, res) {


		// console.log("error", err);
		var sql = "SELECT * FROM TblSupplier WHERE isDeleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get gy id
	this.getsuppliertypeId = async function (suppliertypeId, res) {
		// console.log("testing in dao", suppliertypeId)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var sql = "SELECT * FROM TblSupplier WHERE isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, suppliertypeId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//for post

	this.createsuppliertype = function (req, res) {


		// console.log("error", err);
		var post = {
			SupplierType: req.body.SupplierType,
			created_by: req.body.created_by

		};
		var sql = "INSERT INTO TblSupplier SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for checking samesoiltype
	this.checksuppliertypeExists = function (SupplierType) {
		// console.log("testing  ", SupplierType);

		// console.log("getting checksuppliertypeExists ", SupplierType.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(function (resolve, reject) {

			// console.log("error", err);
			var sql =
				"SELECT count(*) totalCount FROM TblSupplier where isDeleted=1 AND upper(SupplierType) like ?";
			try {
				connection.query(sql, SupplierType.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};
	//for update

	this.updateById = function (req, suppliertypeId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var dataToBeUpdated = [
			req.body.SupplierType,



			req.body.modified_by,
			suppliertypeId
		];
		var sql = `UPDATE TblSupplier SET SupplierType=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;
		try {
			connection.query(sql, animalcategoryId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	//for delete
	this.deleteById = function (suppliertypeId, res) {



		// console.log("error", err);
		let sql = `UPDATE TblSupplier SET isDeleted=0 WHERE ID =${suppliertypeId}`;
		try {
			connection.query(sql, animalcategoryId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}

}
module.exports = new suppliertypeDAO();
