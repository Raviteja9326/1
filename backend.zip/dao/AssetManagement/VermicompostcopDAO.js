var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function vermicompostcopDAO() {
    this.getAllVermicompostcopData = async function (req, res) {
        var sql = "SELECT * FROM TblVermicompostCOP WHERE isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.getvermicompostcopDataByID = function (vermicompostcopId, res) {
        var sql = "SELECT * FROM TblVermicompostCOP WHERE isDeleted=1 AND ID=?";
        try {
            connection.query(sql, vermicompostcopId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };

    this.checkvermicompostcopExists = function (Process) {
        return new Promise(function (resolve, reject) {
            var sql =
                "SELECT count(*) totalCount FROM TblVermicompostCOP where  isDeleted=1 AND upper(Process) like ?";
            try {
                connection.query(sql, Process.toUpperCase().trim()).then(data => {
                    if (data[0].totalCount == 0) {
                        return resolve()
                    }
                    else {
                        reject()
                    };
                })
            }
            catch (error) {
                res.status(HttpStatus.getStatusCode('Server Error')).json({
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                })
            }
        })
    };

    this.createvermicompostcop = function (req, res) {


        // console.log("error", err);
        var post = {
            Process: req.body.Process,
            Period: req.body.Period,
            TankNo: req.body.TankNo,
            created_by: req.body.created_by,
            modified_by: req.body.modified_by

        }
        var sql = "INSERT INTO TblVermicompostCOP   SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };


    this.updatevermicompostcop = function (req, vermicompostcopId, res) {

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.Process,
            req.body.Period,
            req.body.TankNo,
            req.body.modified_by,
            vermicompostcopId
        ];

        var sql = `UPDATE TblVermicompostCOP  SET Process=?,Period=?,TankNo=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;

        try {
            connection.query(sql, vermicompostcopId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };
    this.removevermicompostcop = function (vermicompostcopId, res) {


        // console.log("error", err);
        var sql = `UPDATE TblVermicompostCOP SET isDeleted=0 WHERE ID=${vermicompostcopId}`;
        try {
            connection.query(sql, vermicompostcopId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}

module.exports = new vermicompostcopDAO();