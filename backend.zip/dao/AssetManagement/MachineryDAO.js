var connection = require("../MySQLConnect");
function MachineryDAO() {
  this.getAllMachinery = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblMachinery WHERE isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };
  this.getMachineryById = function (machineryId, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblMachinery WHERE isDeleted=1 AND ID=?";
    try {
      connection.query(sql, machineryId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };
  this.checkmachineryExists = function (machinerytype) {

    // console.log("getting checkmachineryExists ", machinerytype.toUpperCase());
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblMachinery where  isDeleted=1 AND upper(Name) like ?";
      try {
        connection.query(sql, machinerytype.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  this.createmachinery = function (req, res) {


    // console.log("error", err);
    var post = {
      Name: req.body.Name,
      NoOfItems: req.body.NoOfItems,
      MachineryType: req.body.MachineryType,
      CapacityHP: req.body.CapacityHP,
      CostPurchase: req.body.CostPurchase,
      RemainingLife: req.body.RemainingLife,
      AgeInYears: req.body.AgeInYears,
      PresentValue: req.body.PresentValue,
      TblFarmer_ID: req.body.TblFarmer_ID,
      created_by: req.body.created_by
    };
    var sql = "INSERT INTO TblMachinery   SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  this.updatmachinery = function (req, machineryId, res) {

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var dataToBeUpdated = [
      req.body.Name,
      req.body.NoOfItems,
      req.body.MachineryType,
      req.body.CapacityHP,
      req.body.CostPurchase,
      req.body.RemainingLife,
      req.body.AgeInYears,

      req.body.PresentValue,
      req.body.TblFarmer_ID,

      req.body.modified_by,
      machineryId
    ];

    var sql = `UPDATE TblMachinery  SET Name=?,NoOfItems=?,MachineryType=?,CapacityHP=?,CostPurchase=?,RemainingLife=?,AgeInYears=?,PresentValue=?,TblFarmer_ID=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;

    try {
      connection.query(sql, machineryId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };


  this.removemachinery = function (machineryId, res) {


    // console.log("error", err);
    var sql = `UPDATE TblMachinery SET isDeleted=0 WHERE ID=${machineryId}`;
    try {
      connection.query(sql, machineryId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}
module.exports = new MachineryDAO();
