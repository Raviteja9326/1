var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function PitDAO() {
    this.getAllPitData = async function (req, res) {
        var sql = "SELECT * FROM TblPit WHERE isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.getPitDataByID = function (pitId, res) {
        var sql = "SELECT * FROM TblPit WHERE isDeleted=1 AND ID=?";
        try {
            connection.query(sql, pitId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };


    this.getPitTypes = async function (req, res) {
        var sql = "SELECT * FROM TblPitTypes";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.getPitConstructionTypes = async function (req, res) {
        var sql = "SELECT * FROM TblPitConstructionTypes";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };


    this.createPit = function (req, res) {
        var post = {
            TotalArea: req.body.TotalArea,
            PitType: req.body.PitType,
            ConstructionType: req.body.ConstructionType,
            CostPurchaseYear: req.body.CostPurchaseYear,
            AgingYears: req.body.AgingYears,
            RemainingLife: req.body.RemainingLife,
            Cost: req.body.Cost,
            PresentValue: req.body.PresentValue,
            Width: req.body.Width,
            Height: req.body.Height,
            StartDate: req.body.StartDate,
            EndDate: req.body.EndDate,
            TblPloting_ID: req.body.TblPloting_ID,
            created_by: req.body.created_by
        }
        var sql = "INSERT INTO TblPit SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };

    this.updatePit = function (req, pitId, res) {
        var dataToBeUpdated = [
            req.body.TotalArea,
            req.body.PitType,
            req.body.ConstructionType,
            req.body.CostPurchaseYear,
            req.body.AgingYears,
            req.body.RemainingLife,
            req.body.Cost,
            req.body.PresentValue,
            req.body.Width,
            req.body.Height,
            req.body.StartDate,
            req.body.EndDate,
            req.body.TblPloting_ID,
            req.body.modified_by,
            pitId

        ];

        var sql = `UPDATE TblPit  SET TotalArea=?,PitType=?,
          ConstructionType=?,CostPurchaseYear=?,AgingYears=?,RemainingLife=?,Cost=?,PresentValue=?, Width=?,Height=?,StartDate=?,EndDate=?,TblPloting_ID=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;

        try {
            connection.query(sql, pitId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };



    this.removePit = function (pitId, res) {
        var sql = `UPDATE TblPit SET isDeleted=0 WHERE ID=${pitId}`;
        try {
            connection.query(sql, pitId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}

module.exports = new PitDAO();