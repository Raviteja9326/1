var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function vermicompostPitDAO() {
    this.getAllVermicompostPitData = async function (req, res) {


        var sql = "SELECT  f.*, a.PlotingName FROM TblVERMICOMPOSTPIT f    LEFT JOIN TblPloting a ON  f.TblPloting_ID=a.ID  WHERE f.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };
    this.getvermicompostPitDataByID = function (vermicompostpitId, res) {

        var sql = "SELECT  f.*, a.PlotingName FROM TblVERMICOMPOSTPIT f    LEFT JOIN TblPloting a ON  f.TblPloting_ID=a.ID  WHERE f.isDeleted=1 AND f.ID=?";
        try {
            connection.query(sql, vermicompostpitId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };
    this.checkvermicompostPitExists = function (ConstructionType) {

        return new Promise(function (resolve, reject) {

            var sql =
                "SELECT count(*) totalCount FROM TblVERMICOMPOSTPIT where  isDeleted=1 AND upper(ConstructionType) like ?";
            try {
                connection.query(sql, ConstructionType.toUpperCase().trim()).then(data => {
                    if (data[0].totalCount == 0) {
                        return resolve()
                    }
                    else {
                        reject()
                    };
                })
            }
            catch (error) {
                res.status(HttpStatus.getStatusCode('Server Error')).json({
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                })
            }
        })
    };


    this.createvermicompostPit = function (req, res) {

        var post = {
            TotalArea: req.body.TotalArea,
            ConstructionType: req.body.ConstructionType,
            CostPurchaseYear: req.body.CostPurchaseYear,
            AgeinYears: req.body.AgeinYears,
            RemainingLife: req.body.RemainingLife,
            Cost: req.body.Cost,
            PresentValue: req.body.PresentValue,
            Width: req.body.Width,
            Height: req.body.Height,
            NoOfTanks: req.body.NoOfTanks,
            TblPloting_ID: req.body.TblPloting_ID,
            created_by: req.body.created_by,
            modified_by: req.body.modified_by

        }
        var sql = "INSERT INTO TblVERMICOMPOSTPIT   SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };

    this.updatevermicompostPit = function (req, vermicompostpitId, res) {
        var dataToBeUpdated = [
            req.body.TotalArea,
            req.body.ConstructionType,
            req.body.CostPurchaseYear,
            req.body.AgeinYears,
            req.body.RemainingLife,
            req.body.Cost,
            req.body.PresentValue,

            req.body.Width,
            req.body.Height,
            req.body.NoOfTanks,
            req.body.TblPloting_ID,

            req.body.modified_by,
            vermicompostpitId
        ];

        var sql = `UPDATE TblVERMICOMPOSTPIT  SET TotalArea=?,ConstructionType=?,CostPurchaseYear=?,AgeinYears=?,RemainingLife=?,Cost=?,PresentValue=?,Width=?,Height=?,NoOfTanks=?,TblPloting_ID=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;

        try {
            connection.query(sql, vermicompostpitId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };
    this.removevermicompostPit = function (vermicompostpitId, res) {
        var sql = `UPDATE TblVERMICOMPOSTPIT SET isDeleted=0 WHERE ID=${vermicompostpitId}`;
        try {
            connection.query(sql, vermicompostpitId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}

module.exports = new vermicompostPitDAO();