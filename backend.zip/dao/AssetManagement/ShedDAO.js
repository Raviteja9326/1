var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function ShedDAO() {
  this.getAllshedData = async function (req, res) {
    var sql =
      "SELECT s.*,a.PlotingName,b.LandName FROM TblShed s LEFT JOIN TblPloting a ON s.TblPloting_TblplotID=a.ID LEFT JOIN TblLand b ON s.TblPloting_TblLand_ID=b.ID WHERE s.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };
  this.getshedDataByID = function (shedId, res) {
    var sql = "SELECT * FROM TblShed WHERE isDeleted=1 AND ID=?";
    try {
      connection.query(sql, shedId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  this.checkShedExists = function (name) {
    return new Promise(function (resolve, reject) {
      var sql =
        "SELECT count(*) totalCount FROM TblShed where  isDeleted=1 AND upper(Name) like ?";
      try {
        connection.query(sql, name.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  this.createshed = function (req, res) {
    var post = {
      Name: req.body.Name,
      BuiltType: req.body.BuiltType,
      Material: req.body.Material,
      UsePurpose: req.body.UsePurpose,
      Flooring: req.body.Flooring,
      Capacity: req.body.Capacity,
      SunLight: req.body.SunLight,
      ProtectionfromWind: req.body.ProtectionfromWind,
      Drinage: req.body.Drinage,
      Electricity: req.body.Electricity,
      Cost: req.body.Cost,
      Width: req.body.Width,
      Lenght: req.body.Lenght,
      WallTye: req.body.WallTye,
      TblPloting_TblplotID: req.body.TblPloting_TblplotID,
      TblPloting_TblLand_ID: req.body.TblPloting_TblLand_ID
    };
    var sql = "INSERT INTO TblShed   SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  this.updatshed = function (req, shedId, res) {
    var dataToBeUpdated = [
      req.body.Name,
      req.body.BuiltType,
      req.body.Material,
      req.body.UsePurpose,
      req.body.Flooring,
      req.body.Capacity,
      req.body.SunLight,
      req.body.ProtectionfromWind,
      req.body.Drinage,
      req.body.Electricity,
      req.body.Cost,
      req.body.Width,
      req.body.Lenght,
      req.body.WallTye,
      req.body.TblPloting_TblplotID,
      req.body.TblPloting_TblLand_ID,
      shedId
    ];

    var sql = `UPDATE TblShed  SET Name=?,BuiltType=?,
          Material=?,UsePurpose=?,Flooring=?,Capacity=?,SunLight=?,ProtectionfromWind=?, Drinage=?,Electricity=?,Cost=?,Width=?,Lenght=?,WallTye=?,TblPloting_TblplotID=?,TblPloting_TblLand_ID=?  WHERE isDeleted=1 AND ID=?`;

    try {
      connection.query(sql, shedId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };

  this.removeshed = function (shedId, res) {

    var sql = `UPDATE TblShed SET isDeleted=0 WHERE ID=${shedId}`;
    try {
      connection.query(sql, shedId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new ShedDAO();
