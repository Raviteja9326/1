var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function IrregationDAO() {
  this.getAllirregation = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT  f.*, a.LandName FROM TblIrrigation f  LEFT JOIN TblLand a ON  f.TblLand_ID=a.ID  WHERE f.isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getirregationId = function (irregationId, res) {
    // console.log("testing in dao", irregationId)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql = "SELECT  f.*, a.LandName FROM TblIrrigation f  LEFT JOIN TblLand a ON  f.TblLand_ID=a.ID  WHERE f.isDeleted=1 AND f.ID=?";
    try {
      connection.query(sql, irregationId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for post

  this.createirregation = function (req, res) {


    // console.log("error", err);
    var post = {
      IrrigationName: req.body.IrrigationName,
      Source_Type: req.body.Source_Type,
      Net_Area_Irrigated: req.body.Net_Area_Irrigated,
      Area_Irrigated_More_Than_Once: req.body.Area_Irrigated_More_Than_Once,
      Gross_Area_Irrigated: req.body.Gross_Area_Irrigated,
      Number_Of_Irrigation: req.body.Number_Of_Irrigation,
      Method_Of_Irrigation: req.body.Method_Of_Irrigation,
      No_of_Tube_Borewell: req.body.No_of_Tube_Borewell,
      Tube_Borewell_Area: req.body.Tube_Borewell_Area,
      No_Of_Lift: req.body.No_Of_Lift,
      Lift_Area: req.body.Lift_Area,
      No_of_Tanks: req.body.No_of_Tanks,
      Tank_Area: req.body.Tank_Area,
      No_Of_Openwells: req.body.No_Of_Openwells,
      No_Of_Ponds: req.body.No_Of_Ponds,
      Irrigated_Area: req.body.Irrigated_Area,
      Irrigation_Method: req.body.Irrigation_Method,
      Irrigation_System: req.body.Irrigation_System,
      Area_Coverage_In_A_Year: req.body.Area_Coverage_In_A_Year,
      TblLand_ID: req.body.TblLand_ID,
      created_by: req.body.created_by

    };
    var sql = "INSERT INTO TblIrrigation SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };
  //for checking sameIrrigationName
  this.checkirregationExists = function (IrrigationName) {
    // console.log("testing type", IrrigationName);

    // console.log("getting checkirregationExists ", IrrigationName.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql = "SELECT count(*) totalCount FROM TblIrrigation where isDeleted=1 AND upper(IrrigationName) like ?";
      try {
        connection.query(sql, IrrigationName.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  //for update
  this.updateById = function (req, irregationId, res) {

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var dataToBeUpdated = [
      req.body.IrrigationName,
      req.body.Source_Type,
      req.body.Net_Area_Irrigated,
      req.body.Area_Irrigated_More_Than_Once,
      req.body.Gross_Area_Irrigated,
      req.body.Number_Of_Irrigation,
      req.body.Method_Of_Irrigation,
      req.body.No_of_Tube_Borewell,
      req.body.Tube_Borewell_Area,
      req.body.No_Of_Lift,
      req.body.Lift_Area,
      req.body.No_of_Tanks,
      req.body.Tank_Area,
      req.body.No_Of_Openwells,
      req.body.No_Of_Ponds,
      req.body.Irrigated_Area,
      req.body.Irrigation_Method,
      req.body.Irrigation_System,
      req.body.Area_Coverage_In_A_Year,
      req.body.TblLand_ID,
      req.body.modified_by,
      irregationId

    ];

    var sql = `UPDATE TblIrrigation  SET IrrigationName=?,Source_Type=?,
      Net_Area_Irrigated=?,Area_Irrigated_More_Than_Once=?,Gross_Area_Irrigated=?,Number_Of_Irrigation=?,Method_Of_Irrigation=?,No_of_Tube_Borewell=?, Tube_Borewell_Area=?,No_Of_Lift=?,Lift_Area=?,No_of_Tanks=?,Tank_Area=?,No_Of_Openwells=?,No_Of_Ponds=?,Irrigated_Area=?,Irrigation_Method=?,Irrigation_System=?,Area_Coverage_In_A_Year=?,TblLand_ID=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;

    try {
      connection.query(sql, irregationId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };


  //for delete
  this.deleteById = function (Id, res) {



    // console.log("error", err);
    let sql = `UPDATE TblIrrigation SET isDeleted=0 WHERE ID =${Id}`;
    try {
      connection.query(sql, Id).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new IrregationDAO;