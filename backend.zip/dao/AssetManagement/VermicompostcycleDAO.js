var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function vermicompostcycleDAO() {
	this.getAllVermicompostcycleData = async function (req, res) {
		var sql =
			'SELECT  f.*, a.Process,b.ConstructionType FROM TblVermicompostCycle f    LEFT JOIN TblVermicompostCOP a ON  f.TblVermicompostCOP_ID=a.ID   LEFT JOIN TblVERMICOMPOSTPIT b ON  f.TblVERMICOMPOSTPIT_ID=b.ID WHERE f.isDeleted=1 AND a.isDeleted=1  AND b.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getvermicompostcycleDataByID = function (vermicompostcycleId, res) {
		var sql =
			'SELECT  f.*, a.Process,b.ConstructionType FROM TblVermicompostCycle f    LEFT JOIN TblVermicompostCOP a ON  f.TblVermicompostCOP_ID=a.ID   LEFT JOIN TblVERMICOMPOSTPIT b ON  f.TblVERMICOMPOSTPIT_ID=b.ID WHERE f.isDeleted=1 AND a.isDeleted=1  AND b.isDeleted=1 AND f.ID=?';
		try {
			connection.query(sql, vermicompostcycleId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.createvermicompostcycle = function (req, res) {
		var post = {
			StartDate: req.body.StartDate,
			EndTime: req.body.EndTime,
			TankNo: req.body.TankNo,
			TblVermicompostCOP_ID: req.body.TblVermicompostCOP_ID,
			TblVERMICOMPOSTPIT_ID: req.body.TblVERMICOMPOSTPIT_ID,
			created_by: req.body.created_by
		};

		var sql = 'INSERT INTO TblVermicompostCycle   SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	this.updatevermicompostcycle = function (req, vermicompostcycleId, res) {
		var dataToBeUpdated = [
			req.body.StartDate,
			req.body.EndTime,
			req.body.TankNo,
			req.body.TblVermicompostCOP_ID,
			req.body.TblVERMICOMPOSTPIT_ID,
			req.body.modified_by,
			vermicompostcycleId
		];

		var sql = `UPDATE TblVermicompostCycle  SET StartDate=?,EndTime=?,TankNo=?,TblVermicompostCOP_ID=?,TblVERMICOMPOSTPIT_ID=?, modified_by=?  WHERE isDeleted=1 AND ID=?`;

		try {
			connection.query(sql, vermicompostcycleId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.removevermicompostcycle = function (vermicompostcycleId, res) {
		var sql = `UPDATE TblVermicompostCycle SET isDeleted=0 WHERE ID=${vermicompostcycleId}`;
		try {
			connection.query(sql, vermicompostcycleId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new vermicompostcycleDAO();
