var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function SoilCorrectiveActionsDAO() {
	this.getAllSoilCorrectiveAction = async function (req, res) {
		var sql = 'SELECT * FROM TblSoilCorrective WHERE isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get by Id
	this.getSoilCorrectiveActionByID = function (SoilCorrectiveId, res) {
		var sql = 'SELECT * FROM TblSoilCorrective WHERE ID=? AND isDeleted = 1';
		try {
			connection.query(sql, SoilCorrectiveId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//get soiltestdata by id
	this.getSoilTestDataByID = function (TblSoilTestData_ID, res) {
		var sql = 'SELECT * FROM TblSoilCorrective WHERE TblSoilTestData_ID=? AND isDeleted=1';
		try {
			connection.query(sql, TblSoilTestData_ID).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//for post data
	this.createSoilCorrectiveAction = function (req, res) {
		var datatopost = {
			SoilConsultentName: req.body.SoilConsultentName,
			ActionItems: req.body.ActionItems,
			TblSoilTestData_ID: req.body.TblSoilTestData_ID,
			created_by: req.body.created_by
		};
		var sql = 'INSERT INTO TblSoilCorrective SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for update data
	this.updateSoilCorrectiveActionByID = function (req, SoilCorrectiveId, res) {
		var datatobeupdate = [
			req.body.SoilConsultentName,
			req.body.ActionItems,
			req.body.TblSoilTestData_ID,
			req.body.modified_by,
			SoilCorrectiveId
		];
		var sql =
			'UPDATE TblSoilCorrective SET SoilConsultentName=?,ActionItems=?,TblSoilTestData_ID=?,modified_by=? WHERE isDeleted=1 AND ID=?';
		try {
			connection.query(sql, SoilCorrectiveId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	//to delete data
	this.deleteSoilCorrectiveActionByID = function (SoilCorrectiveId, res) {
		var sql = 'UPDATE TblSoilCorrective SET isDeleted=0 WHERE ID=?';
		try {
			connection.query(sql, SoilCorrectiveId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new SoilCorrectiveActionsDAO();
