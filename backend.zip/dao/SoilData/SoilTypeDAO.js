var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function SoilTypeDAO() {



  this.getAllSoilType = async function (req, res) {



    // console.log("error", err);
    var sql = "SELECT * FROM TblSoilType WHERE isDeleted=1";
    connection.query(sql, function (err, result) {
      // console.log("error", err);

      res.json(result);
    })
  }

  //get gy id
  this.getSoilTypeById = async function (soiltypeId, res) {
    []
    // console.log("testing in dao", soiltypeId)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql = "SELECT * FROM TblSoilType WHERE isDeleted=1 AND ID=?";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //for post

  this.createSoilType = function (req, res) {



    // console.log("error", err);

    var post = {
      SoilType: req.body.SoilType,
      SoilTypeNotes: req.body.SoilTypeNotes,
      created_by: req.body.created_by,
      modified_by: req.body.modified_by

    };
    var sql = "INSERT INTO TblSoilType SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  //for checking samesoiltype
  this.checkSoilTypeExists = function (SoilType) {

    // console.log("getting checkSoilTypeExists ", soilType.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblSoilType where isDeleted=1 AND upper(SoilType) like ?";
      try {
        connection.query(sql, SoilType.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };
  //for update

  this.updateById = function (req, soiltypeId, res) {
    // console.log(req.body)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
   
    var sql = `UPDATE TblSoilType SET SoilType='${req.body.SoilType}',SoilTypeNotes='${req.body.SoilTypeNotes}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID='${soiltypeId}' `;

    try {
      connection.query(sql, soiltypeId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };



  //for delete
  this.deleteById = function (soiltypeId, res) {



    // console.log("error", err);
    let sql = `UPDATE TblSoilType SET isDeleted=0 WHERE ID=${soiltypeId}`;
    try {
      connection.query(sql, soiltypeId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}



module.exports = new SoilTypeDAO();