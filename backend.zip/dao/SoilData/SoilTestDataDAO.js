var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function SoilTestDataDAO() {
	this.getAllSoilTestDataFromDAO = function (req, res) {

		try {

			var sql =
				"SELECT a.*,d.FarmerName,d.SurName,e.LandName,JSON_ARRAYAGG(JSON_OBJECT('count',b.count,'TblSoilNutrient_ID',b.TblSoilNutrient_ID, 'SoilNutrientName',c.SoilNutrientName, 'SoilNutrientChemicalsymbol',c.SoilNutrientChemicalsymbol)) as nutreintlist FROM TblSoilTestData a LEFT JOIN TblSoilTestDetails b ON b.TblSoilTestData_ID =a.ID LEFT JOIN TblSoilNutrient c ON b.TblSoilNutrient_ID= c.ID LEFT JOIN TblFarmer d ON a.TblFarmer_ID=d.ID LEFT JOIN  TblLand e ON a.TblPloting_TblLand_ID=e.ID WHERE a.isDeleted=1 GROUP BY a.ID";
			try {
				connection.query(sql, (err, data) => {
					if (err) {
						console.log('error  is ', err);
					} else {
						res.status(200).json(data);
					}
				});
			} catch (error) {
				res.json({ status: false, message: 'error in executing query' });
			}
		} catch (error) {
			res.json({ status: false, message: 'error in coonecting DataBase in acquire' });
		}
	};

	this.getSoilTestDataByID = function (soilTestDataID, res) {

		try {

			var sql =
				// "SELECT a.*,d.FarmerName,d.SurName,e.LandName,(JSON_ARRAYAGG(JSON_OBJECT('count',b.count,'TblSoilNutrient_ID',b.TblSoilNutrient_ID, 'SoilNutrientName',c.SoilNutrientName, 'SoilNutrientChemicalsymbol',c.SoilNutrientChemicalsymbol))) as nutreintlist FROM TblSoilTestData a LEFT JOIN TblSoilTestDetails b ON b.TblSoilTestData_ID =a.ID LEFT JOIN TblSoilNutrient c ON b.TblSoilNutrient_ID= c.ID LEFT JOIN TblFarmer d ON a.TblFarmer_ID=d.ID LEFT JOIN  TblLand e ON a.TblPloting_TblLand_ID=e.ID WHERE a.ID=? GROUP BY a.ID";
				'SELECT a.*,d.FarmerName,d.SurName,e.LandName FROM TblSoilTestData a LEFT JOIN TblFarmer d ON a.TblFarmer_ID=d.ID LEFT JOIN  TblLand e ON a.TblPloting_TblLand_ID=e.ID  WHERE a.ID=? ';
			// "SELECT a.*, CONCAT('[',COALESCE(GROUP_CONCAT(CONCAT('{','\"count\": \"', HEX(t.count), '\", ','\"TblSoilNutrient_ID\": \"', HEX(t.TblSoilNutrient_ID), '\"','}') ORDER BY t.ID ASC SEPARATOR ','),''),']') AS list FROM TblSoilTestData as a left join TblSoilTestDetails as t on a.ID = t.TblSoilTestData_ID where a.ID = ? GROUP BY a.ID";
			connection.query(sql, soilTestDataID, function (err, data) {
				console.log('createdby', data);
				if (err) console.log(err, ' this is error from first');
				else {
					var sql1 =
						'SELECT count,TblSoilNutrient_ID,c.SoilNutrientName,c.SoilNutrientChemicalsymbol FROM TblSoilTestDetails LEFT JOIN TblSoilNutrient c ON TblSoilNutrient_ID= c.ID WHERE  TblSoilTestData_ID=? ';
					connection.query(sql1, soilTestDataID, function (err, data1) {
						if (err) {
							console.log(err, ' this is error from first');
						} else {
							let result1 = data1;
							var object = {
								ID: data[0].ID,
								TestAgentID: data[0].TestAgentID,
								SampleNumber: data[0].SampleNumber,
								SampleReceivedDate: data[0].SampleReceivedDate,
								TestCompletedDate: data[0].TestCompletedDate,
								SampleQuantity: data[0].SampleQuantity,
								SamplePackaging: data[0].SamplePackaging,
								VerifiedBy: data[0].VerifiedBy,
								Remarks: data[0].Remarks,
								FarmerName: data[0].FarmerName,
								SurName: data[0].SurName,
								LandName: data[0].LandName,
								created_by: data[0].created_by,
								TblFarmer_ID: data[0].TblFarmer_ID,
								TblPloting_TblLand_ID: data[0].TblPloting_TblLand_ID,
								result: result1
							};
							//console.log('thiss =is relut ', object);
							res.json({ status: true, object });
						}
					});
				}

				console.log(data);
				// res.contentType('application/json');
				// res.json({ status: true, object: data, lis: JSON.parse(data[0].abhi) });
				return res.data;
			});
		} catch (error) {
			res.json({ status: false, message: 'error in coonecting DataBase in acquire' });
		}

	};

	this.deleteSoilTestDataById = function (soiltestdataId, res) {

		let sql =
			'UPDATE TblSoilTestData a LEFT JOIN TblSoilTestDetails b ON b.TblSoilTestData_ID =a.ID SET a.isDeleted=0,b.isDeleted=0 WHERE a.ID=?';
		try {
			connection.query(sql, soiltestdataId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}



	this.updateSoilTestDataByID = function (req, soiltestdataId, res) {

		if (err) console.log('error in first step', err);
		var updatedingdata = [
			req.body.TestAgentID,
			req.body.SampleNumber,
			req.body.SampleReceivedDate,
			req.body.TestCompletedDate,
			req.body.SampleQuantity,
			req.body.SamplePackaging,
			req.body.VerifiedBy,
			req.body.Remarks,
			req.body.TblFarmer_ID,
			req.body.TblPloting_TblLand_ID,
			req.body.modified_by,
			soiltestdataId
		];
		console.log('rtghhg', updatedingdata);
		var sql = `UPDATE TblSoilTestData SET TestAgentID=?,SampleNumber=?,SampleReceivedDate=?,TestCompletedDate=?,
			SampleQuantity=?,SamplePackaging=?,VerifiedBy=?,Remarks=?,TblFarmer_ID=?,TblPloting_TblLand_ID=?,modified_by=? WHERE isDeleted=1 AND ID=?`;
		connection.query(sql, updatedingdata, function (err, result) {
			console.log('liattttttt', req.body.Nutrientlists.length);
			for (let index = 0; index < req.body.Nutrientlists.length; index++) {
				var dataToUpdateInSoilTestDetails = {
					count: req.body.Nutrientlists[index].count,
					TblSoilNutrient_ID: req.body.Nutrientlists[index].TblSoilNutrient_ID,
					TblSoilTestData_ID: soiltestdataId
				};
				var dCompar = [
					{ count: req.body.Nutrientlists[index].count },
					{ TblSoilNutrient_ID: req.body.Nutrientlists[index].TblSoilNutrient_ID },
					{ TblSoilTestData_ID: soiltestdataId }
				];
				var dCompar1 = [
					{ TblSoilNutrient_ID: req.body.Nutrientlists[index].TblSoilNutrient_ID },
					{ TblSoilTestData_ID: soiltestdataId }
				];
				//console.log('dcom', dCompar);
				//console.log('dcom1', dCompar1);
				//var sql2 = 'SELECT ID FROM TblSoilTestDetails WHERE ? AND ? ';

				//acquiredDBConnection.query(sql2, dCompar1, function(err, result) {
				//	console.log('res ', result);
				//	if (err) console.log('error from details', err);
				//	if (sql2 > 0) {
				//		console.log('action update');

				// this is original code
				var sql1 = 'UPDATE TblSoilTestDetails SET ? WHERE ? AND ?';
				connection.query(sql1, dCompar, function (err, result) {
					if (err) console.log('error from details', err);
					console.log('result after update', result);
				});
				// original code till here

				// } else {
				// 	console.log('action insert');
				// 	var sql1 = 'INSERT INTO TblSoilTestDetails SET ?';
				// 	acquiredDBConnection.query(sql1, dataToUpdateInSoilTestDetails, function(err, result) {
				// 		if (err) console.log('error from details', err);
				// 		console.log('jamk', dataToUpdateInSoilTestDetails);
				// 	});
				// }
				//});
			}
			res.status(200).json({ data: 'Success' });
		});
	};
}

module.exports = new SoilTestDataDAO();
