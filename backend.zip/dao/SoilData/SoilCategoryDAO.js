var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function SoilCategoryDAO() {
	this.getAllSoilCategory = async function (req, res) {


		// console.log('error', err);

		var sql = 'SELECT * FROM TblSoilCategory WHERE isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	//get gy id
	this.getSoilCategoryById = function (soilcategoryId, res) {
		// console.log('testing in dao', soilcategoryId);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);

		var sql = 'SELECT * FROM TblSoilCategory WHERE isDeleted=1 AND ID=?';
		try {
			connection.query(sql, soilcategoryId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//post

	this.createSoilCategory = function (req, res) {


		// console.log('error', err);

		var post = {
			SoilCatType: req.body.SoilCatType,
			SoilCatSource: req.body.SoilCatSource,

			created_by: req.body.created_by,
			modified_by: req.body.modified_by
		};
		var sql = 'INSERT INTO TblSoilCategory SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};

	//for checking samesoiltype
	this.checkSoilCategoryExists = function (SoilCatType) {
		// console.log('testing  ', SoilCategory);

		// console.log('getting checkSoilCategoryExists ', SoilCategory.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(function (resolve, reject) {

			// console.log('error', err);
			var sql =
				'SELECT count(*) totalCount FROM TblSoilCategory where  isDeleted=1 AND upper(SoilCatType) like ?';
			try {
				connection.query(sql, SoilCatType.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};

	//for update

	this.updateById = function (req, soilcategoryId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
		
		var sql = `UPDATE TblSoilCategory SET SoilCatType='${req.body.SoilCatType}',SoilCatSource='${req.body.SoilCatSource}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID='${soilcategoryId}' `;

		try {
			connection.query(sql, soilcategoryId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	//for delete
	this.deleteById = function (soilcategoryId, res) {



		// console.log('error', err);
		let sql = `UPDATE TblSoilCategory s 
        LEFT JOIN TblSoilNutrient b ON s.ID=b.TblSoilCategory_ID
      SET s.isDeleted=0,b.isDeleted=0 WHERE s.ID=${soilcategoryId}`;
		try {
			connection.query(sql, soilcategoryId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}
module.exports = new SoilCategoryDAO();
