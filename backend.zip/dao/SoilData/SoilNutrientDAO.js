var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function SoilNutrientDAO() {
  this.getAllSoilNutrient = async function (req, res) {


    // console.log("error", err);

    var sql = "SELECT  f.*, a.SoilCatType FROM TblSoilNutrient f  LEFT JOIN TblSoilCategory a ON  f.TblSoilCategory_ID=a.ID    WHERE f.isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get by id
  this.getSoilNutrientById = function (soilnutrientId, res) {
    // console.log("testing in dao", soilnutrientId)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);

    var sql = "SELECT  f.*, a.SoilCatType FROM TblSoilNutrient f  LEFT JOIN TblSoilCategory a ON  f.TblSoilCategory_ID=a.ID    WHERE f.isDeleted=1 AND f.ID=?";

    try {
      connection.query(sql, soilnutrientId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for post

  this.createSoilNutrient = function (req, res) {


    // console.log("error", err);

    var post = {
      SoilNutrientName: req.body.SoilNutrientName,
      SoilNutrientChemicalsymbol: req.body.SoilNutrientChemicalsymbol,
      SoilNutrientVerylow: req.body.SoilNutrientVerylow,
      SoilNutrientLow: req.body.SoilNutrientLow,
      SoilNutrientMedium: req.body.SoilNutrientMedium,
      SoilNutrientHigh: req.body.SoilNutrientHigh,
      SoilNutrientVeryHigh: req.body.SoilNutrientVeryHigh,
      TblSoilCategory_ID: req.body.TblSoilCategory_ID,
      created_by: req.body.created_by,
      modified_by: req.body.modified_by


    };
    var sql = "INSERT INTO TblSoilNutrient SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  //for checking samesoiltype
  this.checkSoilNutrientExists = function (SoilNutrientName) {
    // console.log("testing type", soilNutrient);

    // console.log("getting checkSoilNutrientExists ", soilNutrient.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblSoilNutrient where  isDeleted=1 AND upper(SoilNutrientName) like ?";
      try {
        connection.query(sql, SoilNutrientName.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  //for update

  this.updateById = function (req, soilnutrientId, res) {
    // console.log(req.body)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
   
    var sql = `UPDATE TblSoilNutrient SET SoilNutrientName='${req.body.SoilNutrientName}',SoilNutrientChemicalsymbol='${req.body.SoilNutrientChemicalsymbol}',SoilNutrientVerylow='${req.body.SoilNutrientVerylow}',SoilNutrientLow='${req.body.SoilNutrientLow}',SoilNutrientMedium='${req.body.SoilNutrientMedium}',SoilNutrientHigh='${req.body.SoilNutrientHigh}',SoilNutrientVeryHigh='${req.body.SoilNutrientVeryHigh}',TblSoilCategory_ID='${req.body.TblSoilCategory_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${soilnutrientId} `;

    try {
      connection.query(sql, soilnutrientId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };
  // delete
  this.deleteById = function (soilnutrientId, res) {
    // console.log(soilnutrientId, "ima soilnutrientId")


    // console.log("error", err);
    var sql = `UPDATE  TblSoilNutrient  SET isDeleted=0 WHERE ID=${soilnutrientId}`;
    try {
      connection.query(sql, soilnutrientId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new SoilNutrientDAO();