var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function RiskManagementDAO() {
  this.getAllRiskManagement = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblRiskManagement WHERE isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getRiskManagementId = function (riskmanagementID, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblRiskManagement WHERE isDeleted=1 AND ID=?";
    try {
      connection.query(sql, riskmanagementID).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for post

  this.createRiskManagement = function (req, res) {


    // console.log("error", err);
    var post = {
      RiskArea: req.body.RiskArea,
      Status: req.body.Status,
      Impact: req.body.Impact,
      ProbabilityofOccurrence: req.body.ProbabilityofOccurrence,
      Description: req.body.Description,
      Symptoms: req.body.Symptoms,
      Triggers: req.body.Triggers,
      ContingencyPlan: req.body.ContingencyPlan
    };
    var sql = "INSERT INTO TblRiskManagement SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };


  //for update

  this.updateRiskManagementById = function (req, riskmanagementID, res) {




    // console.log("error", err);
    let sql = `UPDATE TblRiskManagement  SET RiskArea='${req.body.RiskArea}',Status='${req.body.Status}',Impact='${req.body.Impact}',ProbabilityofOccurrence='${req.body.ProbabilityofOccurrence}',Description='${req.body.Description}',Symptoms='${req.body.Symptoms}',Triggers='${req.body.Triggers}',ContingencyPlan='${req.body.ContingencyPlan}'  WHERE isDeleted=1 AND ID= '${riskmanagementID}'`;
    try {
      connection.query(sql, riskmanagementID).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };

  //for delete
  this.deleteRiskManagementById = function (riskmanagementID, res) {



    // console.log("error", err);
    let sql = `UPDATE TblRiskManagement m
      INNER JOIN TblRiskActivities c ON c.TblRiskManagement_ID = m.ID
      SET m.isDeleted=0,
      c.isDeleted=0
      WHERE m.ID = '${riskmanagementID}'`;
    try {
      connection.query(sql, riskmanagementID).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new RiskManagementDAO();