var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function RiskActivitiesDAO() {
  this.getAllRiskActivities = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblRiskActivities WHERE isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };
  //get gy id
  this.getRiskActivitiesId = function (riskactivitiesId, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblRiskActivities WHERE isDeleted=1 AND ID=?";
    try {
      connection.query(sql, riskactivitiesId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for post

  this.createRiskActivitiesId = function (req, res) {


    // console.log("error", err);
    var post = {
      ActionSummary: req.body.ActionSummary,
      ActionPerformedBy: req.body.ActionPerformedBy,
      Date: req.body.Date,
      Description: req.body.Description,
      Actionitems: req.body.Actionitems,
      Followby: req.body.Followby,
      TblRiskManagement_ID: req.body.TblRiskManagement_ID



    };
    var sql = "INSERT INTO TblRiskActivities SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };


  //for update

  this.updateRiskActivitiesById = function (req, riskactivitiesId, res) {


    // console.log("error", err);
    let sql = `UPDATE TblRiskActivities  SET ActionSummary='${req.body.ActionSummary}',Date='${req.body.Date}',ActionPerformedBy='${req.body.ActionPerformedBy}',Description='${req.body.Description}',Actionitems='${req.body.Actionitems}',Followby='${req.body.Followby}',TblRiskManagement_ID='${req.body.TblRiskManagement_ID}'   WHERE isDeleted=1 AND ID= '${riskactivitiesId}'`;
    try {
      connection.query(sql, riskactivitiesId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };

  //for delete
  this.deleteRiskActivitiesById = function (riskactivitiesId, res) {



    // console.log("error", err);
    let sql = `UPDATE TblRiskActivities SET isDeleted=0 WHERE ID =${riskactivitiesId}`;
    try {
      connection.query(sql, riskactivitiesId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new RiskActivitiesDAO();