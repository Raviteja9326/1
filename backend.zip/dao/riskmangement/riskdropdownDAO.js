var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function RiskdropdownDAO() {
  this.getAllriskdropdown = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblRiskDropDown";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getriskdropdownId = function (riskdropdownId, res) {
    // console.log("testing in dao", riskdropdownId)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql = "SELECT * FROM TblRiskDropDown WHERE ID=?";
    try {
      connection.query(sql, riskdropdownId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };
  //for get

  this.getAllriskstatus = async function (req, res) {


    // console.log("error",err);
    var sql = "SELECT * FROM TblStatus ";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };


  this.getAllImpact = async function (req, res) {


    // console.log("error",err);
    var sql = "SELECT * FROM TblImpact ";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  this.createriskdropdown = function (req, res) {


    // console.log("error", err);
    var post = {
      RiskArea: req.body.RiskArea
    };
    var sql = "INSERT INTO TblRiskDropDown SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };
  //for checking samesoiltype
  this.checkriskdropdownExists = function (riskdropdown) {
    // console.log("testing  ", riskdropdown);

    // console.log("getting checkriskdropdownExists ", riskdropdown.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblRiskDropDown where  upper(RiskArea) like ?";
      try {
        connection.query(sql, riskdropdown.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };


}
module.exports = new RiskdropdownDAO();
