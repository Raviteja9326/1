var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function FarmerC3DAO() {
    this.getAllFarmerC3 = async function (req, res) {


        // console.log("error", err);
        var sql = " SELECT * FROM TblFarmerC3 ";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.createFramerC3 = function (req, res) {


        // console.log('error', err);
        var id = req.body.ID;

        var post = {

            TblFarmer_ID: req.body.TblFarmer_ID,
            TblC3Office_ID: req.body.TblC3Office_ID,
            TblMandal_ID: req.body.TblMandal_ID,
            TblVillage_ID: req.body.TblVillage_ID,
            created_by: req.body.created_by

        };
        var update = {

            TblFarmer_ID: req.body.TblFarmer_ID,
            TblC3Office_ID: req.body.TblC3Office_ID,
            TblMandal_ID: req.body.TblMandal_ID,
            TblVillage_ID: req.body.TblVillage_ID,
            modified_by: req.body.modified_by

        };
        if (id > 0) {
            var sql1 = `SELECT COUNT(ID) as rowCount FROM TblFarmerC3 WHERE TblFarmer_ID='${req.body.TblFarmer_ID}' AND TblC3Office_ID='${req.body.TblC3Office_ID}' AND TblMandal_ID='${req.body.TblMandal_ID}'  AND TblVillage_ID='${req.body.TblVillage_ID}' AND ID!='${req.body.ID}' GROUP BY TblFarmer_ID`;
            connection.query(sql1, function (err, result) {
                // console.log("eror in testing", err);
                if (result.length === 0) {
                    var rowCount = 0;
                } else {
                    var rowCount = result[0].rowCount;
                }
                if (rowCount > 0) {
                    res.json("duplicate entry");
                } else {
                    var update1 = `UPDATE TblFarmerC3 SET ? WHERE ID='${req.body.ID}'`;
                    connection.query(update1, update, function (err, result) {
                        // console.log("error", err);
                        res.json({ data: "Success" });
                    })
                }
            })

        } else {
            var sql1 = `SELECT COUNT(ID) as rowCount FROM TblFarmerC3 WHERE TblFarmer_ID='${req.body.TblFarmer_ID}' AND TblC3Office_ID='${req.body.TblC3Office_ID}' AND TblMandal_ID='${req.body.TblMandal_ID}'  AND TblVillage_ID='${req.body.TblVillage_ID}' GROUP BY TblFarmer_ID`;
            connection.query(sql1, function (err, result) {
                // console.log("eror in testing", err);
                if (result.length === 0) {
                    var sql = "INSERT INTO TblFarmerC3 SET ?";
                    connection.query(sql, post, function (err, result) {
                        // console.log("error", err);
                        // console.log('inserted');

                        res.json({ data: "Success" });

                    });
                } else {
                    // console.log('duplicate entry');
                    res.json({ data: "duplicate entry" });
                }
            })

        }

    }

    this.removefarmerc3 = function (farmerc3Id, res) {


        // console.log("error", err);
        var sqsl = "DELETE FROM TblFarmerC3 WHERE ID=?";
        try {
            connection.query(sql, farmerc3Id).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}
module.exports = new FarmerC3DAO();