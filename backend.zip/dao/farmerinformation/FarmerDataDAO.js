var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function FarmerDataDAO() {
	this.getAllfarmerQrData = async function (res) {
		// console.log("error", err);
		var sql =
			'SELECT ID,FarmerName,SurName,CultivateCrop,FarmerImage,TblVillage_ID FROM TblFarmer WHERE isDeleted=1';

		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getAllfarmerData = async function (res) {
		// console.log("error", err);
		var sql = `SELECT a.*,b.Countryname,c.StateName,d.DistrictName,e.MandalName,f.VillageName fROM TblFarmer a LEFT JOIN TblCountry b ON a.TblCountry=b.ID  LEFT JOIN TblState c ON a.TblState=c.ID LEFT JOIN TblDistrict d ON a.Tbldistrict=d.ID LEFT JOIN TblMandal e ON a.TblMandal=e.ID LEFT JOIN TblVillage f ON a.TblVillage_ID=f.ID WHERE a.isDeleted=1 `;
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getFarmerDataByUser = (userID, res) => {
		try {
			var sql = `SELECT a.*,b.Countryname,c.StateName,d.DistrictName,e.MandalName,f.VillageName fROM TblFarmer a LEFT JOIN TblCountry b ON a.TblCountry=b.ID  LEFT JOIN TblState c ON a.TblState=c.ID LEFT JOIN TblDistrict d ON a.Tbldistrict=d.ID LEFT JOIN TblMandal e ON a.TblMandal=e.ID LEFT JOIN TblVillage f ON a.TblVillage_ID=f.ID WHERE a.isDeleted=1 AND a.TblMandal IN(SELECT man.ID FROM TblMandal man  WHERE man.TblC3Office_C3OfficeID IN (SELECT userc3.TblC3Office_ID FROM TblUserC3 userc3 WHERE userc3.TblUser_ID=${userID}) )`;
			connection.query(sql).then((data) => {
				res.status(HttpStatus.OK).json(data);
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			});
		}
	};

	this.getFarmerDataById = function (farmerId, res) {
		// console.log("error", err);
		var sql =
			'SELECT a.*,b.Countryname,c.StateName,d.DistrictName,e.MandalName,f.VillageName fROM TblFarmer a LEFT JOIN TblCountry b ON a.TblCountry=b.ID  LEFT JOIN TblState c ON a.TblState=c.ID LEFT JOIN TblDistrict d ON a.Tbldistrict=d.ID LEFT JOIN TblMandal e ON a.TblMandal=e.ID LEFT JOIN TblVillage f ON a.TblVillage_ID=f.ID WHERE a.isDeleted=1 AND a.ID=?';
		try {
			connection.query(sql, farmerId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.createfarmer = function (req, res) {
		// console.log("error", err);

		var post = {
			FarmerName: req.body.FarmerName,
			SurName: req.body.SurName,
			FatherName: req.body.FatherName,
			Gender: req.body.Gender,
			Address: req.body.Address,
			BankName: req.body.BankName,
			IFSCCode: req.body.IFSCCode,
			MobileNumber: req.body.MobileNumber,
			BankAccountNo: req.body.BankAccountNo,
			AadhaarNo: req.body.AadhaarNo,
			BankBranch: req.body.BankBranch,
			TblVillage_ID: req.body.TblVillage_ID,
			FarmerImage: req.body.FarmerImage,
			CultivateCrop: req.body.CultivateCrop,
			created_by: req.body.created_by,
			TblCountry: req.body.TblCountry,
			TblState: req.body.TblState,
			Tbldistrict: req.body.Tbldistrict,
			TblMandal: req.body.TblMandal
		};
		var sql = 'INSERT INTO TblFarmer SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};


	this.updateFarmerData = function (req, farmerId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var dataToBeUpdated = [
			req.body.FarmerName,
			req.body.SurName,
			req.body.FatherName,
			req.body.Gender,
			req.body.Address,
			req.body.BankName,
			req.body.IFSCCode,
			req.body.MobileNumber,
			req.body.BankAccountNo,
			req.body.AadhaarNo,
			req.body.TblVillage_ID,
			req.body.FarmerImage,
			req.body.CultivateCrop,
			req.body.BankBranch,
			req.body.modified_by,
			req.body.TblCountry,
			req.body.TblState,
			req.body.Tbldistrict,
			req.body.TblMandal,
			farmerId
		];
		var sql = `UPDATE TblFarmer SET FarmerName=?,SurName=?,FatherName=?,Gender=?,Address=?,BankName=?,IFSCCode=?,MobileNumber=?,BankAccountNo=?,AadhaarNo=?,TblVillage_ID=?,FarmerImage=?,CultivateCrop=?,BankBranch=?,modified_by=?,TblCountry=?,TblState=?,
    Tbldistrict=?,TblMandal=? WHERE isDeleted=1 AND ID=?`;

		try {
			connection.query(sql, farmerId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};


	this.removeFarmer = function (farmerId, res) {
		// console.log(farmerId, "ima farmer");

		// console.log("error", err);
		var sql = `UPDATE TblFarmer m 
            LEFT JOIN TblLoan c ON c.TblFarmer_ID=m.ID
            LEFT JOIN TblLand b ON b.TblFarmer_ID=m.ID
            LEFT JOIN TblAnimalMaster e ON e.TblFarmer_ID=m.ID
            LEFT JOIN TblMachinery h ON h.TblFarmer_ID=m.ID
            LEFT JOIN TblStock s ON s.TblFarmer_ID=m.ID
            SET m.isDeleted=0,
            c.isDeleted=0,
            b.isDeleted=0,
            e.isDeleted=0,
            h.isDeleted=0,
            s.isDeleted=0 WHERE m.ID='${farmerId}'`;
		try {
			connection.query(sql, farmerId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}


	this.getDataForQR = async function (farmername, res) {
		var sql = 'SELECT ID,FarmerName,SurName FROM TblFarmer';
		try {
			await connection.query(sql).then((result) => {
				for (let index = 0; index < result.length; index++) {
					if ((result[index].FarmerName + result[index].SurName).toUpperCase() === farmername.toUpperCase()) {
						var farmerId = result[index].ID;
					}
				}
				if (!farmerId) {
					res.status(HttpStatus.getStatusCode('Not Found')).json({
						message: 'no data found',
						status: HttpStatus.getStatusCode('Not Found')
					});
				} else {
					var sql12 = `SELECT ID,FarmerName,CultivateCrop,SurName,FarmerImage,TblVillage_ID FROM TblFarmer  WHERE ID=${farmerId} AND isDeleted=1`;

					connection.query(sql12, function (err, data) {
						if (!data) {
							res.status(HttpStatus.getStatusCode('Not Found')).json({
								message: 'no data found',
								status: HttpStatus.getStatusCode('Not Found')
							});
						} else {
							res.status(HttpStatus.OK).send(data);
						}
					});
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			});
		}
	};
}

module.exports = new FarmerDataDAO();
