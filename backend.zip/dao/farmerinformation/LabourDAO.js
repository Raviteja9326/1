var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function LabourDAO() {
  this.getAlllabour = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblLabour WHERE isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getlabourById = function (Id, res) {
    // console.log("testing in dao", Id)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql = "SELECT * FROM TblLabour WHERE isDeleted=1 AND ID=?";
    try {
      connection.query(sql, Id).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for post

  this.createLabour = function (req, res) {


    // console.log("error", err);
    var post = {
      FullName: req.body.FullName,
      ResidingatFarm: req.body.ResidingatFarm,
      Relationship: req.body.Relationship,
      MaritalStatus: req.body.MaritalStatus,
      Age: req.body.Age,
      Sex: req.body.Sex,
      TypeofWork: req.body.TypeofWork,
      PaymentType: req.body.PaymentType,
      PaymentFrequency: req.body.PaymentFrequency,
      Holidays: req.body.Holidays,
      Education: req.body.Education,
      DependentStatus: req.body.DependentStatus,
      PercentageTimeonFarm: req.body.PercentageTimeonFarm,
      MajorWork: req.body.MajorWork,
      MinorWork: req.body.MinorWork,
      created_by: req.body.created_by

    };
    var sql = "INSERT INTO TblLabour SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for checking samelabour
  this.checkLabourExists = function (labour) {
    // console.log("testing type", labour);

    // console.log("getting checkLabourExists ", labour.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblLabour where isDeleted=1 AND upper(FullName) like ?";
      try {
        connection.query(sql, labour.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  //for update


  //for update
  this.updateById = function (req, labourId, res) {
    // console.log(req.body)

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var dataToBeUpdated = [
      req.body.FullName,
      req.body.ResidingatFarm,
      req.body.Relationship,
      req.body.MaritalStatus,
      req.body.Age,
      req.body.Sex,
      req.body.TypeofWork,
      req.body.PaymentType,
      req.body.PaymentFrequency,
      req.body.Holidays,
      req.body.Education,
      req.body.DependentStatus,
      req.body.PercentageTimeonFarm,
      req.body.MajorWork,
      req.body.MinorWork,
      req.body.modified_by,
      labourId
    ]
    var sql = `UPDATE TblLabour SET FullName=?,ResidingatFarm=?,Relationship=?,MaritalStatus=?,Age=?,Sex=?,TypeofWork=?,PaymentType=?,PaymentFrequency=?,Holidays=?,Education=?,DependentStatus=?,PercentageTimeonFarm=?,MajorWork=?,MinorWork=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

    try {
      connection.query(sql, labourId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };



  //for delete
  this.deleteById = function (Id, res) {



    // console.log("error", err);
    let sql = `UPDATE  TblLabour SET isDeleted=0 WHERE ID =${Id}`;
    try {
      connection.query(sql, Id).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}
module.exports = new LabourDAO;