var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function MiscellanousDAO() {
	this.getAllmiscellaneous = async function (req, res) {


		// console.log("error", err);
		var sql = "SELECT  f.*, a.SupplierType,b.ExpenseTypes FROM TblMiscellaneous f  LEFT JOIN TblSupplier a ON  f.TblSupplier_ID=a.ID   LEFT JOIN TblExpensesTypes b ON f.TblExpensesTypes_ID=b.ID  WHERE f.isDeleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get gy id
	this.getmiscellaneousId = async function (miscellaneousId, res) {
		// console.log("testing in dao", miscellaneousId)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var sql = "SELECT  f.*, a.SupplierType,b.ExpenseTypes FROM TblMiscellaneous f  LEFT JOIN TblSupplier a ON  f.TblSupplier_ID=a.ID   LEFT JOIN TblExpensesTypes b ON f.TblExpensesTypes_ID=b.ID  WHERE f.isDeleted=1 AND f.ID=?";
		try {
			await connection.query(sql, miscellaneousId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	//for post

	this.createmiscellaneous = function (req, res) {


		// console.log("error", err);
		var post = {
			Amount: req.body.Amount,
			Date: req.body.Date,
			PaidTo: req.body.PaidTo,
			InvoiceNo: req.body.InvoiceNo,
			AccountCode: req.body.AccountCode,
			TblSupplier_ID: req.body.TblSupplier_ID,
			TblExpensesTypes_ID: req.body.TblExpensesTypes_ID,

			created_by: req.body.created_by

		};
		var sql = "INSERT INTO TblMiscellaneous SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};

	//for update

	this.updateById = function (req, miscellaneousId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
	
		var sql = `UPDATE TblMiscellaneous SET Amount='${req.body.Amount}',Date='${req.body.Date}',PaidTo='${req.body.PaidTo}',InvoiceNo='${req.body.InvoiceNo}',AccountCode='${req.body.AccountCode}',TblSupplier_ID='${req.body.TblSupplier_ID}',TblExpensesTypes_ID='${req.body.TblExpensesTypes_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${miscellaneousId} `;
		try {
			connection.query(sql, miscellaneousId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	//for delete
	this.deleteById = function (miscellaneousId, res) {



		// console.log("error", err);
		let sql = `UPDATE TblMiscellaneous SET isDeleted=0 WHERE ID =${miscellaneousId}`;
		try {
			connection.query(sql, miscellaneousId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}
module.exports = new MiscellanousDAO();