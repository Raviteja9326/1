var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function expnsetypeDAO() {
	this.getAllexpensetype = async function (req, res) {


		// console.log("error", err);
		var sql = "SELECT * FROM TblExpensesTypes WHERE isDeleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};


	//get gy id
	this.getexpensetypeId = async function (expensetypeId, res) {
		// console.log("testing in dao", expensetypeId)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var sql = "SELECT * FROM TblExpensesTypes WHERE isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, expensetypeId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//for post

	this.createexpensetype = function (req, res) {


		// console.log("error", err);
		var post = {
			ExpenseTypes: req.body.ExpenseTypes,
			created_by: req.body.created_by

		};
		var sql = "INSERT INTO TblExpensesTypes SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	//for checking samesoiltype
	this.checkexpensetypeExists = function (ExpenseTypes) {
		// console.log("testing  ", ExpenseTypes);

		// console.log("getting checkexpensetypeExists ", ExpenseTypes.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(function (resolve, reject) {

			// console.log("error", err);
			var sql =
				"SELECT count(*) totalCount FROM TblExpensesTypes where isDeleted=1 AND upper(ExpenseTypes) like ?";
			try {
				connection.query(sql, ExpenseTypes.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};
	//for update

	this.updateById = function (req, expensetypeId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		
		var sql = `UPDATE TblExpensesTypes SET ExpenseTypes='${req.body.ExpenseTypes}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${expensetypeId} `;

		try {
			connection.query(sql, expensetypeId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};


	//for delete
	this.deleteById = function (expensetypeId, res) {



		// console.log("error", err);
		let sql = `UPDATE TblExpensesTypes SET isDeleted=0 WHERE ID =${expensetypeId}`;
		try {
			connection.query(sql, expensetypeId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}

}
module.exports = new expnsetypeDAO();
