var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function LabourHoursDAO() {
  this.createLabourHours = function (req, res) {


    // console.log("error", err);
    var post = {
      Date: req.body.Date,
      Hours: req.body.Hours,
      PercentageOfWork: req.body.PercentageOfWork,
      StartTime: req.body.StartTime,
      EndTIme: req.body.EndTIme,
      OverTime: req.body.OverTime,
      PayID: req.body.PayID,
      TblLabour_ID: req.body.TblLabour_ID,
      TblLocation_ID: req.body.TblLocation_ID,
      TblLabourActy_ID: req.body.TblLabourActy_ID,
      created_by: req.body.created_by
    };

    var sql = "INSERT INTO TbllabourHours SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };


  this.checkLabourHours = function (date) {
    // console.log("req.body date is", date);
    var reqDate = date;

    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql = `SELECT Date FROM TbllabourHours WHERE DATE(Date)= DATE('${reqDate}')AND isDeleted=1`;
      try {
        connection.query(sql, reqDate.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  this.getLabourHours = function (req, res) {

    try {

      throw err;
      var sql =
        // "SELECT Day(Date) as 'day',MONTH(Date) as 'month',StartTime,EndTIme FROM TbllabourHours  WHERE YEAR(Date) LIKE '2018' ";

        "SELECT a.*,b.FullName,c.Name,d.ActyName FROM TbllabourHours a LEFT JOIN TblLabourActy d ON a.TblLabourActy_ID=d.ID LEFT JOIN TblLocation c ON a.TblLocation_ID=c.ID LEFT JOIN TblLabour b ON a.TblLabour_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1   ";

      // var sql = "SELECT GROUP_CONCAT(DAY(t.Date) ) as WorkingDays FROM TbllabourHours t WHERE MONTH(t.Date) = MONTH('2019-11-05') AND YEAR(t.Date) = YEAR('2019-11-05') group by t.TblLabour_ID AND t.isDeleted=1";
      try {
        connection.query(sql, function (err, result) {
          throw err;

          // result == '' ? res.status(404).json('No Data Available') : res.status(200).json(result);
          res.json(result);
        });
      } catch (error) {
        res.json("Some Error Occured");
      }
    } catch (error) {
      res.json("Some Error Occured");
    }
  };

  this.getlabourhoursByDate = async function (req, res) {


    // console.log("error", err);
    var date = [req.body.month, req.body.year, req.body.TblLabour_ID];
    var sql =
      "SELECT a.StartTime,a.EndTIme,a.OverTime,b.FullName,c.Name,d.ActyName FROM TbllabourHours a LEFT JOIN TblLabourActy d ON a.TblLabourActy_ID=d.ID LEFT JOIN TblLocation c ON a.TblLocation_ID=c.ID LEFT JOIN TblLabour b ON a.TblLabour_ID=b.ID WHERE MONTH(Date)=? AND YEAR(Date)=? AND TblLabour_ID=?";

    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  this.getAllAlbourActys = async function (req, res) {


    // console.log("error", err);
    var sql = "SELECT * FROM TblLabourActy";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  this.getLabourHoursByID = function (labourID, res) {


    // console.log("error", err);
    var sql =
      "SELECT a.*,b.FullName,c.Name,d.ActyName FROM TbllabourHours a LEFT JOIN TblLabourActy d ON a.TblLabourActy_ID=d.ID LEFT JOIN TblLocation c ON a.TblLocation_ID=c.ID LEFT JOIN TblLabour b ON a.TblLabour_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND TblLabour_ID=?  ";
    try {
      connection.query(sql, labourID).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  }
}
module.exports = new LabourHoursDAO();
