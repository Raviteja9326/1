
var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropMasterDAO() {
    this.getAllCropMasters = async function (req, res) {


        // console.log('error', err);
        var sql = "SELECT a.*,b.CropCatName  FROM TblCropMaster a LEFT JOIN TblCropCategory b ON a.TblCropCategory_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.getCropMasterById = function (cropmasterId, res) {


        // console.log("error", err);
        var sql = "SELECT a.*,b.CropCatName  FROM TblCropMaster a LEFT JOIN TblCropCategory b ON a.TblCropCategory_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND  a.ID=?";
        try {
            connection.query(sql, cropmasterId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };

    this.checkCropMasterExists = function (cropVarietyName) {

        // console.log("getting checkCropMasterExists ", cropVarietyName.toUpperCase());
        return new Promise(function (resolve, reject) {

            // console.log("error", err);
            var sql =
                "SELECT count(*) totalCount FROM TblCropMaster WHERE isDeleted=1 AND upper(CropVarietyName) like ?";
            try {
                connection.query(sql, cropVarietyName.toUpperCase().trim()).then(data => {
                    if (data[0].totalCount == 0) {
                        return resolve()
                    }
                    else {
                        reject()
                    };
                })
            }
            catch (error) {
                res.status(HttpStatus.getStatusCode('Server Error')).json({
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                })
            }
        })
    };


    this.createCropMaster = function (req, res) {


        // console.log("error", err);
        var post = {
            CropVarietyName: req.body.CropVarietyName,
            Maturitydays: req.body.Maturitydays,
            AgronomicFeatures: req.body.AgronomicFeatures,
            BiologicalName: req.body.BiologicalName,
            VarietyDescription: req.body.VarietyDescription,
            ParentDescription: req.body.ParentDescription,
            AverageYield: req.body.AverageYield,
            TblCropCategory_ID: req.body.TblCropCategory_ID,
            created_by: req.body.created_by

        };
        var sql = "INSERT INTO TblCropMaster SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };
    this.updateCropMaster = function (req, cropmasterId, res) {
        // console.log(req.body)

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.CropVarietyName,
            req.body.Maturitydays,
            req.body.AgronomicFeatures,
            req.body.BiologicalName,
            req.body.VarietyDescription,
            req.body.ParentDescription,
            req.body.AverageYield,
            req.body.TblCropCategory_ID,

            req.body.modified_by,
            cropmasterId
        ]
        var sql = `UPDATE TblCropMaster SET CropVarietyName=?,Maturitydays=?,AgronomicFeatures=?,BiologicalName=?,VarietyDescription=?,ParentDescription=?,AverageYield=?,TblCropCategory_ID=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

        try {
            connection.query(sql, cropmasterId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };
    this.removeCropMaster = function (cropmasterId, res) {


        // console.log("error", err);
        var sql = "UPDATE TblCropMaster SET isDeleted=0 WHERE ID=?";
        try {
            connection.query(sql, cropmasterId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}


module.exports = new CropMasterDAO();