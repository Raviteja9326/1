var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropCOPDAO() {
	this.getAllCropCOP = function (req, res) {

		var sql = "SELECT a.*,d.CropVarietyName,JSON_ARRAYAGG(JSON_OBJECT('TblMaterials_ID',b.TblMaterials_ID,'Quantity',b.Quantity, 'UnitID',b.UnitID)) as Rawmaterialdata FROM TblCropCOP a LEFT JOIN TblCOPRawMaterial b ON b.TblCropCOP_ID=a.ID  LEFT JOIN TblCropMaster d ON a.TblCropMaster_ID=d.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1  GROUP BY a.ID"
		try {
			connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};


	this.getCropCOPById = function (cropcopId, res) {

		var sql = "SELECT a.*,b.CropVarietyName,c.CropCatName   FROM TblCropCOP a LEFT JOIN TblCropMaster b ON a.TblCropMaster_ID=b.ID  LEFT JOIN TblCropCategory c ON b.TblCropCategory_ID=c.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND a.ID=?";
		try {
			connection.query(sql, cropcopId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	this.updateCropCOP = function (cropcopId, req, res) {
		// console.log(req.body)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		var dataToBeUpdated = [
			req.body.COPNO,
			req.body.Activity,
			req.body.CropMilestoneID,
			req.body.CriticalActivity,
			req.body.Dependency,
			req.body.Duration,
			req.body.Season,
			req.body.TblCropMaster_ID,
			req.body.modified_by,
			cropcopId
		]
		var sql = `UPDATE TblCropCOP SET COPNO=?,Activity=?,CropMilestoneID=?,CriticalActivity=?,Dependency=?,Duration=?,Season=?,TblCropMaster_ID=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

		try {
			connection.query(sql, cropcopId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};






	this.removeCropCOP = function (cropcopId, res) {

		var sql = "UPDATE  TblCropCOP SET isDeleted=0 WHERE ID=?";
		try {
			connection.query(sql, cropcopId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}
module.exports = new CropCOPDAO();