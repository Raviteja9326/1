var connection = require('./MySQLConnect');

function FarmerDAO() {

    this.getFarmerById = function (farmerId, res) {

        // get id as parameter to passing into query and return filter data  

        var sql = 'select id,farmer_name,gender,farmer_spouse_name,farmer_code_ref,farmer_code,farmer_address,farmer_aadhar_no,farmer_bank_name,bank_branch,bank_ifsc_code,farmer_bank_account_no,farmer_mobile_number,farmer_country_id,user_id,created_at,updated_at from farmer_master where id=?;';
        try {
            connection.query(sql, farmerId).then(data => {
               if (data.length == 0) {
                   res.json({
                       data: "No Data Available with this ID"
                   })
               }
               else {
                   res.status(HttpStatus.OK).json(data)
               }
           })
       }
       catch (error) {
           res.status(HttpStatus.getStatusCode('Server Error')).json({
               message: error.message,
               status: HttpStatus.getStatusCode('Server Error')

           })
       }
   };
}
module.exports = new FarmerDAO();  
