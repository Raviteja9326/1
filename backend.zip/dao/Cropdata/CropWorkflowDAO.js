var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropWorkflowDAO() {
    this.getAllCropWorkflow = function (req, res) {

        var sql = "SELECT  f.*, a.Activity,b.CropVarietyName  FROM TblCOPworkflow f  LEFT JOIN TblCropCOP a ON  f.TblCropCOP_ID=a.ID  LEFT JOIN TblCropMaster b ON  f.TblCropMaster_ID=b.ID  WHERE f.isDeleted=1  AND a.isDeleted=1  AND b.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };


    this.getCropWorkflowById = function (cropworkflowId, res) {

        var sql = "SELECT ID,CropCatName,created_by,modified_by FROM TblCropCategory WHERE isDeleted=1 AND ID=?";
        try {
            connection.query(sql, cropworkflowId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };


    this.createCropWorkflow = function (req, res) {

        var post = {
            CropCatName: req.body.CropCatName.toUpperCase(),
            created_by: req.body.created_by

        };
        var sql = "INSERT INTO TblCropCategory SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };



    this.updateCropflow = function (req, cropworkflowId, res) {

        var dataToBeUpdated = [
            req.body.CropCatName,

            req.body.modified_by,
            cropworkflowId
        ]
        var sql = `UPDATE TblCropCategory SET CropCatName=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

        try {
            connection.query(sql, cropworkflowId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };

    this.removeCropflow = function (cropworkflowId, res) {

        var sql = "UPDATE TblCropCategory SET  isDeleted=0 WHERE ID=?";
        try {
            connection.query(sql, cropworkflowId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}

module.exports = new CropWorkflowDAO();