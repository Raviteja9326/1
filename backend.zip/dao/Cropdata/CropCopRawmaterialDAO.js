var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropCopRawmaterialDAO() {
	this.getAllCropCOPRawmaterial = async function (req, res) {

		var sql = 'SELECT f.*,b.*,c.COPNO FROM TblCOPRawMaterial f LEFT JOIN  TblMaterials b ON f.TblMaterials_ID=b.ID  LEFT JOIN TblCropCOP c ON f.TblCropCOP_ID=c.ID WHERE  f.isDeleted=1  AND  b.isDeleted=1  AND  c.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};


	//get gy id
	this.getCropCOPRawmaterialById = async function (TblCropCOP_ID, res) {

		var sql = "SELECT f.*,b.*,c.COPNO FROM TblCOPRawMaterial f LEFT JOIN  TblMaterials b ON f.TblMaterials_ID=b.ID  LEFT JOIN TblCropCOP c ON f.TblCropCOP_ID=c.ID WHERE  f.isDeleted=1  AND  b.isDeleted=1  AND  c.isDeleted=1 AND f.TblCropCOP_ID=?";
		try {
			await connection.query(sql, TblCropCOP_ID).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};
	//for post

	this.createCropCOPRawmaterial = function (req, res) {

		var post = {
			TblMaterials_ID: req.body.TblMaterials_ID,
			Quantity: req.body.Quantity,
			UnitID: req.body.UnitID,
			TblCropCOP_ID: req.body.TblCropCOP_ID,
			created_by: req.body.created_by

		};
		var sql = "INSERT INTO TblCOPRawMaterial SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for update
	this.updateCropCOPRawmaterial = function (req, cropcoprawmaterlId, res) {

		var dataToBeUpdated = [
			req.body.Tbl_RawMaterialID,
			req.body.Quantity,
			req.body.UnitID,
			req.body.TblCropCOP_ID,
			req.body.modified_by,
			cropcoprawmaterlId
		]
		var sql = `UPDATE TblCOPRawMaterial SET Tbl_RawMaterialID=?,Quantity=?,UnitID=?,TblCropCOP_ID=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;
		try {
			connection.query(sql, cropcoprawmaterlId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};



	//for delete
	this.removeCropCOPRawmaterial = function (cropcoprawmaterlId, res) {

		let sql = `UPDATE TblCOPRawMaterial SET isDeleted=0 WHERE ID =${cropcoprawmaterlId}`;
		try {
			connection.query(sql, cropcoprawmaterlId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new CropCopRawmaterialDAO();