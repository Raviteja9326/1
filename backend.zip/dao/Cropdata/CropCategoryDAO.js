var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropCategoryDAO() {
    this.getAllCropCategories = async function (req, res) {
        var sql = "SELECT *  FROM TblCropCategory WHERE isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };
    this.getCropCategoryById = function (cropcatId, res) {

        var sql = "SELECT ID,CropCatName,created_by,modified_by FROM TblCropCategory WHERE isDeleted=1 AND ID=?";
        try {
            connection.query(sql, cropcatId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };

    this.checkCropCategoryExists = function (cropCatName) {
        // get id as parameter to passing into query and return filter data
        return new Promise(function (resolve, reject) {

            // console.log("error", err);
            var sql =
                "SELECT count(*) totalCount FROM TblCropCategory WHERE isDeleted=1 AND upper(CropCatName) like ?";
            try {
                connection.query(sql, cropCatName.toUpperCase().trim()).then(data => {
                    if (data[0].totalCount == 0) {
                        return resolve()
                    }
                    else {
                        reject()
                    };
                })
            }
            catch (error) {
                res.status(HttpStatus.getStatusCode('Server Error')).json({
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                })
            }
        })
    };


    this.createCropCategory = function (req, res) {


        // console.log("error", err);
        var post = {
            CropCatName: req.body.CropCatName.toUpperCase(),
            created_by: req.body.created_by

        };
        var sql = "INSERT INTO TblCropCategory SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };



    this.updateCropCategory = function (cropcatId, req, res) {
        // console.log(req.body)

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.CropCatName,

            req.body.modified_by,
            cropcatId
        ]
        var sql = `UPDATE TblCropCategory SET CropCatName=?,modified_by=?  WHERE isDeleted=1 AND ID=? `;

        try {
            connection.query(sql, cropcatId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };

    this.removeCropCategory = function (cropcatId, res) {


        // console.log("error", err);
        var sql = "UPDATE TblCropCategory SET  isDeleted=0 WHERE ID=?";
        try {
            connection.query(sql, cropcatId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}

module.exports = new CropCategoryDAO();