var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropcCycleDAO() {
    this.getAllCropCycles =async function (req, res) {

        var sql = "SELECT a.*,b.CropVarietyName,b.Maturitydays,c.LandName,d.PlotingName,e.Name,f.FarmerName,JSON_ARRAYAGG(JSON_OBJECT('activity', g.Activity,'duration',g.Duration)) as mainactivities FROM TblCropCycle a LEFT JOIN TblCropMaster b ON a.TblCropMaster_ID=b.ID LEFT JOIN TblLand c ON a.TblLand_ID=c.ID  LEFT JOIN TblPloting d ON a.TblPloting_ID=d.ID  LEFT JOIN TblCropLane e ON a.TblCropLane_ID=e.ID  LEFT JOIN TblFarmer f ON a.Tbl_FarrmerID=f.ID  LEFT JOIN TblCropCOP g ON a.TblCropMaster_ID=g.TblCropMaster_ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1 AND e.isDeleted=1 AND c.isDeleted=1 AND g.isDeleted=1  AND f.isDeleted=1 group by g.TblCropMaster_ID, a.ID";
        try {
            await connection.query(sql).then(data => {
              res.status(HttpStatus.OK).json(data);
            })
          } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
              err: {
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
              }
            })
          }
        };


    this.getCropCycleById = function (Id, res) {

        var sql = "SELECT a.*,b.CropVarietyName,c.LandName,d.PlotingName,e.Name,f.FarmerName FROM TblCropCycle a LEFT JOIN TblCropMaster b ON a.TblCropMaster_ID=b.ID LEFT JOIN TblLand c ON a.TblLand_ID=c.ID  LEFT JOIN TblPloting d ON a.TblPloting_ID=d.ID  LEFT JOIN TblCropLane e ON a.TblCropLane_ID=e.ID  LEFT JOIN TblFarmer f ON a.Tbl_FarrmerID=f.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1 AND e.isDeleted=1 AND c.isDeleted=1 AND f.isDeleted=1 AND  a.ID=?";

        connection.query(sql, Id, function (err, data) {
            if (err) console.log('err in first quert', err);
            else {
                var sql1 = "SELECT g.Activity,g.Duration FROM TblCropCOP g LEFT JOIN TblCropCycle h ON g.TblCropMaster_ID=h.TblCropMaster_ID WHERE h.ID=?"
                connection.query(sql1, Id, function (err, data1) {
                    if (err) {
                        console.log(err, ' this is error from first');
                    } else {
                        let result1 = data1;
                        var object = {
                            ID: data[0].ID,
                            LandInAcres: data[0].LandInAcres,
                            CropMaturityDays: data[0].CropMaturityDays,
                            CropStartDate: data[0].CropStartDate,
                            CropOutputQuantity: data[0].CropOutputQuantity,
                            TblLand_ID: data[0].TblLand_ID,
                            TblCropCOP_ID: data[0].TblCropCOP_ID,
                            TblCropMaster_ID: data[0].TblCropMaster_ID,
                            TblPloting_ID: data[0].TblPloting_ID,
                            TblCropLane_ID: data[0].TblCropLane_ID,
                            FarmerName: data[0].FarmerName,
                            Name: data[0].Name,
                            PlotingName: data[0].PlotingName,
                            LandName: data[0].LandName,
                            CropVarietyName: data[0].CropVarietyName,
                            result: result1
                        };
                        //console.log('thiss =is relut ', object);
                        res.json({ status: true, object });
                    }
                })
                return res.data;
            }


            res.json(result);
        })
    }


    this.createCropCycle = function (req, res) {

        var post = {
            LandInAcres: req.body.LandInAcres,
            CropMaturityDays: req.body.CropMaturityDays,
            CropStartDate: req.body.CropStartDate,
            CropEndDate: req.body.CropEndDate,
            CropOutputQuantity: req.body.CropOutputQuantity,
            TblLand_ID: req.body.TblLand_ID,
            Tbl_FarrmerID: req.body.Tbl_FarrmerID,
            TblCropMaster_ID: req.body.TblCropMaster_ID,
            TblPloting_ID: req.body.TblPloting_ID,
            TblCropLane_ID: req.body.TblCropLane_ID,
            created_by: req.body.created_by

        };
        var sql = "INSERT INTO TblCropCycle SET ?";
        try {
            connection.query(sql, post).then(result => {
              if (result) {
                res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
              }
              else {
                res.status(HttpStatus.getStatusCode('Bad Request')).json({
                  status: HttpStatus.getStatusCode('Bad Request'),
                })
              }
            })
          }
          catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
              message: error.message,
              status: HttpStatus.getStatusCode('Server Error')
      
            })
          }
      
        };
    
    this.updateCropCycle = function (cropcycleId, req, res) {


       
        var sql = `UPDATE TblCropCycle SET LandInAcres='${req.body.LandInAcres}',CropMaturityDays='${req.body.CropMaturityDays}',CropStartDate='${req.body.CropStartDate}',CropEndDate='${req.body.CropEndDate}',CropOutputQuantity='${req.body.CropOutputQuantity}',TblLand_ID='${req.body.TblLand_ID}',TblCropCOP_ID='${req.body.TblCropCOP_ID}',TblCropMaster_ID='${req.body.TblCropMaster_ID}',TblPloting_ID='${req.body.TblPloting_ID}',TblCropLane_ID='${req.body.TblCropLane_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${cropcycleId} `;
        try {
            connection.query(sql, animalcycleId).then(result => {
              if (result) {
                res.json({ data: "Successfully Updated" })
              }
              else {
                res.status(HttpStatus.getStatusCode('Bad Request')).json({
                  status: HttpStatus.getStatusCode('Bad Request'),
                })
              }
            })
          }
          catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
              message: error.message,
              status: HttpStatus.getStatusCode('Server Error')
            })
          }
        };
    this.removeCropCycle = function (cropcycleId, res) {

        var sql = "UPDATE  TblCropCycle SET isDeleted=0 WHERE ID=?";
        try {
            connection.query(sql, cropreportdiseaseId).then(result => {
              if (result) {
                res.json({ data: 'Successfully Deleted' });
              }
              else {
                res.status(HttpStatus.getStatusCode('Bad Request')).json({
                  status: HttpStatus.getStatusCode('Bad Request'),
                })
              }
            })
          }
          catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
              message: error.message,
              status: HttpStatus.getStatusCode('Server Error')
            })
          }
        }
}


module.exports = new CropcCycleDAO();