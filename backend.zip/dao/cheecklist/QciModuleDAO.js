var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function QCIDAO() {
  this.getAllqcifarmer = async function (req, res) {


    //console.log("error", err);


    //   var sql="SELECT a.*,q.Module_Name FROM TblCivilforceCheckList_Farmer a  LEFT JOIN TblQCIModule q ON a.QCIModuleID=q.ID";
    var sql =
      "SELECT a.*,q.Module_Name FROM TblCivilforceCheckList a  LEFT JOIN TblQCIModule q ON a.TblQCIModule_ID=q.ID";

    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //for all qci module
  this.getAllqcimodule = async function (req, res) {
    var sql = "SELECT * FROM TblQCIModule"


    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };


  this.getAllchecklist = async function (req, res) {
    var sql = "SELECT * FROM TblCivilforceCheckList_Farmer"


    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };



  this.getChecklistByfarmerid = async function (req, farmerID, res) {
    var sql = `SELECT a.ID,a.Module_Name,(SELECT  JSON_ARRAYAGG(JSON_OBJECT("ID",b.ID,"QCIModuleID",b.QCIModuleID,"CheckListID",b.CheckListID,"Action",b.Action,"extraAction",b.extraAction,"desc",c.Desc)))as checkList FROM TblQCIModule a LEFT JOIN TblCivilforceCheckList_Farmer b ON b.QCIModuleID=a.ID 	LEFT JOIN TblCivilforceCheckList c ON a.ID=c.TblQCIModule_ID WHERE b.FarmerID=${req
      .params.farmerID} AND a.ID=c.TblQCIModule_ID AND b.CheckListID=c.CheckListID  GROUP BY a.ID`;
    try {
      await connection.query(sql, farmerID).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };


  this.getfarmerid = async function (req, farmerId, res) {
    var sql = `SELECT c.FarmerName,c.SurName, b.FarmerID FROM TblFarmer c LEFT JOIN TblCivilforceCheckList_Farmer b ON c.ID=b.FarmerID WHERE c.isDeleted=1 AND b.FarmerID=${req
      .params.farmerID}`;
    try {
      await connection.query(sql, farmerId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data[0])
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  }


  this.getfarmerId = async function (req, getfarmerId, res) {

    var sql = "SELECT * FROM TblCivilforceCheckList_Farmer WHERE FarmerID=?";

    try {
      await connection.query(sql, getfarmerId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };



  this.getqcifarmerId = async function (TblQCIModule_ID, res) {

    var sql =
      "SELECT a.*,q.Module_Name,p.Actions FROM TblCivilforceCheckList a  LEFT JOIN TblQCIModule q ON a.TblQCIModule_ID=q.ID  LEFT JOIN Tbl_checkList p ON a.CheckListID=p.ID  WHERE a.TblQCIModule_ID=?";
    try {
      await connection.query(sql, TblQCIModule_ID).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };


  this.createqcifarmer = function (req, res) {
    for (let index = 0; index < req.body.length; index++) {
      var dataToPostQciFarmer = {
        QCIModuleID: req.body[index].QCIModuleID,
        CheckListID: req.body[index].CheckListID,
        Action: req.body[index].Action,
        FarmerID: req.body[index].FarmerID,
        extraAction: req.body[index].extraAction
      };
      var sql = "INSERT INTO TblCivilforceCheckList_Farmer SET ?";
      connection.query(sql, dataToPostQciFarmer, function (err, result) {
        if (err) console.log('error from ', err);
      })
    }
    res.json({ data: 'Success' });

  }

};









module.exports = new QCIDAO();
