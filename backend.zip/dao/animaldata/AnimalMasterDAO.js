var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function AnimalMasterDAO() {
	this.getAllanimalmaster = async function (req, res) {
		// console.log('error', err);
		var sql =
			'SELECT  f.*, a.BreedName,b.AnimalCatName,c.FarmerName,c.SurName FROM TblAnimalMaster f  LEFT JOIN TblBreed a ON  f.TblBreed_ID=a.ID  LEFT JOIN TblFarmer c ON  f.TblFarmer_ID=c.ID  LEFT JOIN TblAnimalCategory b ON f.TblAnimalCategory_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get gy id
	this.getanimalmasterId = async function (Id, res) {
		// console.log('error', err);
		var sql =
			'SELECT  f.*, a.BreedName,b.AnimalCatName,c.FirstName,c.LastName FROM TblAnimalMaster f  LEFT JOIN TblBreed a ON  f.TblBreed_ID=a.ID  LEFT JOIN TblFarmer c ON  f.TblFarmer_ID=c.ID  LEFT JOIN TblAnimalCategory b ON f.TblAnimalCategory_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND f.ID=?';
		try {
			await connection.query(sql, Id).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	//for post

	this.createAnimalMaster = function (req, res) {
		// console.log('error', err);
		var post = {
			AnimalGEOTAG: req.body.AnimalGEOTAG,
			AnimalName: req.body.AnimalName,
			Sex: req.body.Sex,
			DOB: req.body.DOB,
			Age: req.body.Age,
			AgeGroup: req.body.AgeGroup,
			RemainingYears: req.body.RemainingYears,
			AnimalParentID: req.body.AnimalParentID,
			Purpose: req.body.Purpose,
			HealthCondition: req.body.HealthCondition,
			Presentvalue: req.body.Presentvalue,
			CullValue: req.body.CullValue,
			FeedingscheduleTime: req.body.FeedingscheduleTime,
			FeedType: req.body.FeedType,
			DrinkingwaterTime: req.body.DrinkingwaterTime,
			DrinkingwaterCapacity: req.body.DrinkingwaterCapacity,
			WashingTime: req.body.WashingTime,
			CleaningTime: req.body.CleaningTime,
			TblBreed_ID: req.body.TblBreed_ID,
			TblFarmer_ID: req.body.TblFarmer_ID,
			TblAnimalCategory_ID: req.body.TblAnimalCategory_ID,
			created_by: req.body.created_by
		};
		var sql='INSERT INTO TblAnimalMaster SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};


	//for checking samelabour
	this.checkAnimalMasterExists = function (AnimalName) {
		return new Promise(function (resolve, reject) {
			// console.log('error', err);
			var sql =
				'SELECT count(*) totalCount FROM TblAnimalMaster where isDeleted=1 AND upper(AnimalName) like ?';
			try {
				connection.query(sql, AnimalName.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};
	//for update
	this.updateById = function (req, animalbreedId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
	
		let sql = `UPDATE TblAnimalMaster SET AnimalGEOTAG='${req.body.AnimalGEOTAG}',AnimalName='${req.body.AnimalName}',Sex='${req.body.Sex}',DOB='${req.body.DOB}',Age='${req.body.Age}',AgeGroup='${req.body.AgeGroup}',RemainingYears='${req.body.RemainingYears}',AnimalParentID='${req.body.AnimalParentID}',Purpose='${req.body.Purpose}',HealthCondition='${req.body.HealthCondition}',Presentvalue='${req.body.Presentvalue}',CullValue='${req.body.CullValue}',FeedingscheduleTime='${req.body.FeedingscheduleTime}',FeedType='${req.body.FeedType}',DrinkingwaterTime='${req.body.DrinkingwaterTime}',DrinkingwaterCapacity='${req.body.DrinkingwaterCapacity}',WashingTime='${req.body.WashingTime}',CleaningTime='${req.body.CleaningTime}',TblBreed_ID='${req.body.TblBreed_ID}',TblFarmer_ID='${req.body.TblFarmer_ID}',TblAnimalCategory_ID='${req.body.TblAnimalCategory_ID}',modified_by='${req.body.modified_by}' WHERE isDeleted=1 AND ID=${animalbreedId} `;

		try {
			 connection.query(sql, animalbreedId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	//for delete
	this.deleteById = function (Id, res) {

		// console.log('error', err);

		let sql = `UPDATE TblAnimalMaster m
      LEFT JOIN TblAnimalCycle c ON c.TblAnimalMaster_ID = m.ID
      SET m.isDeleted=0,
      c.isDeleted=0
      WHERE m.ID = ${Id}`;
		try {
			connection.query(sql, Id).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new AnimalMasterDAO();
