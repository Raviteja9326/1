var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function AnimalCycleDAO() {
  this.getAllAnimalCycle = async function (req, res) {

    var sql = "SELECT a.*,b.AnimalName,c.Name,d.FarmerName,JSON_ARRAYAGG(JSON_OBJECT('activity', g.Activity,'duration',g.Duration)) as animalactivities FROM TblAnimalCycle a LEFT JOIN TblAnimalMaster b ON a.TblAnimalMaster_ID=b.ID LEFT JOIN TblShed c ON a.TblShed_ID=c.ID LEFT JOIN TblFarmer d ON d.ID=a.TblFarmer_ID  LEFT JOIN TBLAnimalCOP g ON a.TblAnimalMaster_ID=g.TblAnimalMaster_ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1 AND c.isDeleted=1 AND g.isDeleted=1  group by g.TblAnimalMaster_ID, a.ID";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  // //get gy id
  // this.getAnimalCycleById = function (animalcycleId, res) {
  //   console.log("testing in dao", animalcycleId);
  //   connection.init();
  //   // get id as parameter to passing into query and return filter data
  //   connection.acquire(function (err, con) {
  //     console.log("error", err);
  //     var sql =
  //       "SELECT a.*,b.AnimalName,c.Name,d.FarmerName FROM TblAnimalCycle a LEFT JOIN TblAnimalMaster b ON a.TblAnimalMaster_ID=b.ID LEFT JOIN TblShed c ON a.TblShed_ID=c.ID LEFT JOIN TblFarmer d ON d.ID=a.TblFarmer_ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1 AND c.isDeleted=1  AND f.ID=?";
  //     con.query(sql, animalcycleId, function (err, result) {
  //       console.log(err);
  //       console.log(result);
  //       con.release();
  //       if (result == "") {
  //         res.json({ data: "No Data Available with this ID :-(" });
  //       } else {
  //         res.json(result);
  //       }
  //     });
  //   });
  // };

  this.getAnimalCycleById = function (animalcycleId, res) {
    console.log(animalcycleId, "ghdjfh")



    var sql =
      "SELECT a.*,b.AnimalName,c.Name,d.FarmerName FROM TblAnimalCycle a LEFT JOIN TblAnimalMaster b ON a.TblAnimalMaster_ID=b.ID LEFT JOIN TblShed c ON a.TblShed_ID=c.ID LEFT JOIN TblFarmer d ON d.ID=a.TblFarmer_ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1 AND c.isDeleted=1  AND a.ID=?";

    connection.query(sql, animalcycleId, function (err, data) {
      if (err) console.log('err in first quert', err);
      else {
        var sql1 = "SELECT g.Activity,g.Duration FROM TBLAnimalCOP g LEFT JOIN TblAnimalCycle h ON g.TblAnimalMaster_ID=h.TblAnimalMaster_ID WHERE h.ID=?"
        connection.query(sql1, animalcycleId, function (err, data1) {
          if (err) {
            console.log(err, ' this is error from first');
          } else {
            let result1 = data1;
            var object = {
              ID: data[0].ID,
              startdate: data[0].startdate,
              maturedate: data[0].maturedate,
              Status: data[0].Status,
              BatchNumber: data[0].BatchNumber,
              BatchCount: data[0].BatchCount,
              OutputType: data[0].OutputType,
              TblShed_ID: data[0].TblShed_ID,
              TblAnimalMaster_ID: data[0].TblAnimalMaster_ID,
              FarmerName: data[0].FarmerName,
              Name: data[0].Name,
              AnimalName: data[0].AnimalName,
              result: result1
            };
            //console.log('thiss =is relut ', object);
            res.json({ status: true, object });
          }
        })
        return res.data;
      }
      console.log("error", err);
      con.release();
      res.json(result);
    })

  }



  //for post

  this.createAnimalcycle = function (req, res) {

    var post = {
      startdate: req.body.startdate,
      maturedate: req.body.maturedate,
      Status: req.body.Status,
      BatchNumber: req.body.BatchNumber,
      BatchCount: req.body.BatchCount,
      OutputType: req.body.OutputType,
      TblShed_ID: req.body.TblShed_ID,
      TblAnimalMaster_ID: req.body.TblAnimalMaster_ID,
      TblFarmer_ID: req.body.TblFarmer_ID,
      created_by: req.body.created_by
    };
    var sql = "INSERT INTO TblAnimalCycle SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  //for update

  this.updateById = function (req, animalcycleId, res) {

    // get id as parameter to passing into query and return filter data



    var sql = `UPDATE TblAnimalCycle SET startdate='${req.body.startdate}',maturedate='${req.body.maturedate}',Status='${req.body.Status}',BatchNumber='${req.body.BatchNumber}',BatchCount='${req.body.BatchCount}',OutputType='${req.body.OutputType}',TblShed_ID='${req.body.TblShed_ID}',TblAnimalMaster_ID='${req.body.TblAnimalMaster_ID}',TblFarmer_ID='${req.body.TblFarmer_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${animalcycleId} `;

    try {
      connection.query(sql, animalcycleId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };
  //for delete
  this.deleteById = function (animalcycleId, res) {


    let sql = `UPDATE TblAnimalCycle SET isDeleted=0 WHERE ID ='${animalcycleId}'`;
    try {
      connection.query(sql, cropreportdiseaseId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}


module.exports = new AnimalCycleDAO();
