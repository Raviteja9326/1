var connection = require("../MySQLConnect");

function VaccinationDAO() {
  this.getAllVaccines = function (req, res) {

    return new Promise(function (resolve, reject) {
      var sql =
        "SELECT  f.*, a.Companyname,b.AnimalCatName FROM TblVaccination f  LEFT JOIN TblCompanyMaster a ON  f.TblCompanyMaster_ID=a.ID   LEFT JOIN TblAnimalCategory b ON f.TblAnimalCategory_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1";
      try {
        connection.query(sql, function (err, result) {
          res.json(result);
        });
      } catch (err) {
        res.json("Some Error Occured");
      }
    }).catch(() => {
      res.json("Some Error Occured");
    });
  };

  this.getVaccineByID = function (vaccineID, res) {


    // console.log("error", err);
    var sql =
      "SELECT  f.*, a.Companyname,b.AnimalCatName FROM TblVaccination f  LEFT JOIN TblCompanyMaster a ON  f.TblCompanyMaster_ID=a.ID   LEFT JOIN TblAnimalCategory b ON f.TblAnimalCategory_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1 AND f.ID=?";
      try {
        connection.query(sql, vaccineID).then(data => {
         if (data.length == 0) {
           res.json({
             data: "No Data Available with this ID"
           })
         }
         else {
           res.status(HttpStatus.OK).json(data)
         }
       })
     }
     catch (error) {
       res.status(HttpStatus.getStatusCode('Server Error')).json({
         message: error.message,
         status: HttpStatus.getStatusCode('Server Error')
 
       })
     }
   };

  this.createVaccines = function (req, res) {


    // console.log("error", err);
    var post = {
      Name: req.body.Name,
      Units: req.body.Units,
      BatchCode: req.body.BatchCode,
      Function: req.body.Function,
      PlaceOfOrigin: req.body.PlaceOfOrigin,
      TblCompanyMaster_ID: req.body.TblCompanyMaster_ID,
      TblAnimalCategory_ID: req.body.TblAnimalCategory_ID,
      created_by: req.body.created_by
    };
    try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
  this.checkVaccineExists = function (Name) {

    // console.log("getting checkVaccineExists ", name.toUpperCase());
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblVaccination where isDeleted=1 AND upper(Name) like ?";
        try {
          connection.query(sql, Name.toUpperCase().trim()).then(data => {
           if (data[0].totalCount == 0) {
             return resolve()
           }
           else {
             reject()
           };
         })
       }
       catch (error) {
         res.status(HttpStatus.getStatusCode('Server Error')).json({
           message: error.message,
           status: HttpStatus.getStatusCode('Server Error')
         })
       }
     })
 };

  this.updateVaccineById = function (req, vaccineID, res) {
    // console.log(req.body);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
   
    var sql = `UPDATE TblVaccination SET Name='${req.body.Name}',Units='${req.body.Units}',BatchCode='${req.body.BatchCode}',Function='${req.body.Function}',PlaceOfOrigin='${req.body.PlaceOfOrigin}',TblCompanyMaster_ID='${req.body.TblCompanyMaster_ID}',TblAnimalCategory_ID='${req.body.TblAnimalCategory_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${vaccineID} `;

    try {
			connection.query(sql, vaccineID).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
  this.deleteVaccineById = function (vaccineID, res) {



    // console.log("error", err);
    let sql = `UPDATE TblVaccination SET isDeleted=0 WHERE ID =${vaccineID}`;
    try {
      connection.query(sql, vaccineID).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
  }
module.exports = new VaccinationDAO();
