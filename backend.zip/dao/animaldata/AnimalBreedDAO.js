var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function AnimalBreedDAO() {
	this.getAllanimalbreed = async function (req, res) {
		var sql =
			'SELECT a.*,b.AnimalCatName FROM TblBreed a LEFT JOIN TblAnimalCategory b ON b.ID=a.TblAnimalCategory_ID WHERE a.isDeleted=1 AND b.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};


	//get gy id
	this.getanimalbreedId = async function (animalbreedId, res) {
		// console.log('testing in dao', animalbreedId);
		var sql =
			'SELECT a.*,b.AnimalCatName FROM TblBreed a LEFT JOIN TblAnimalCategory b ON b.ID=a.TblAnimalCategory_ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND a.ID=?';
		try {
			await connection.query(sql, animalbreedId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};


	this.getBreedByCatName = async function (catName, res) {
		var sql = 'SELECT ID,BreedName FROM TblBreed WHERE TblAnimalCategory_ID=?';
		try {
			await connection.query(sql, catName).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this Name"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	//for post

	this.createAnimalBreed = function (req, res) {
		var post = {
			BreedName: req.body.BreedName,
			ImprovedBreedName: req.body.ImprovedBreedName,
			LocalBreedName: req.body.LocalBreedName,
			BreedType: req.body.BreedType,
			PercentageOfimprovedbreed: req.body.PercentageOfimprovedbreed,
			PercentageOfLocalbreed: req.body.PercentageOfLocalbreed,
			TotalNoOfImprovedbreed: req.body.TotalNoOfImprovedbreed,
			MostAvilableLocation: req.body.MostAvilableLocation,
			TblAnimalCategory_ID: req.body.TblAnimalCategory_ID,
			created_by: req.body.created_by
		};
		var sql = 'INSERT INTO TblBreed SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};

	//for checking samesoiltype
	this.checkAnimalBreedExists = function (BreedName, res) {
		// console.log('testing  ', BreedName);

		return new Promise(function (resolve, reject) {
			var sql = 'SELECT count(*) totalCount FROM TblBreed where isDeleted=1 AND upper(BreedName) like ?';
			try {
				connection.query(sql, BreedName.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};
	//for update

	this.updateById = function (req, animalbreedId, res) {
		console.log(req.body);
		
	
		let sql = `UPDATE TblBreed SET BreedName='${req.body.BreedName}',ImprovedBreedName='${req.body.ImprovedBreedName}',LocalBreedName='${req.body.LocalBreedName}',BreedType='${req.body.BreedType}',PercentageOfimprovedbreed='${req.body.PercentageOfimprovedbreed}',PercentageOfLocalbreed='${req.body.PercentageOfLocalbreed}',TotalNoOfImprovedbreed='${req.body.TotalNoOfImprovedbreed}',MostAvilableLocation='${req.body.MostAvilableLocation}',TblAnimalCategory_ID='${req.body.TblAnimalCategory_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${animalbreedId} `;

		try {
			connection.query(sql, animalbreedId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	//for delete
	this.deleteById = function (animalbreedId, res) {
		let sql = `UPDATE TblBreed a
      LEFT JOIN TblAnimalMaster b ON a.ID=b.TblBreed_ID
      SET a.isDeleted=0,b.isDeleted=0 WHERE a.ID =${animalbreedId}`;
		try {
			connection.query(sql, animalbreedId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}
module.exports = new AnimalBreedDAO();
