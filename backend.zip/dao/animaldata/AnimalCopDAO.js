var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function AnimalCOPDAO() {
    this.getAllAnimalCOP = async function (req, res) {

        var sql = "SELECT a.*,d.AnimalName,JSON_ARRAYAGG(JSON_OBJECT('TblMaterials_ID',b.TblMaterials_ID,'Quantity',b.Quantity, 'UnitID',b.UnitID)) as Rawmaterialdata FROM TBLAnimalCOP a LEFT JOIN TblAnimalRawMaterial b ON b.TblAnimalCOP_ID=a.ID  LEFT JOIN TblAnimalMaster d ON a.TblAnimalMaster_ID=d.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND d.isDeleted=1  GROUP BY a.ID"
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };

    this.getAnimalCOPById = async function (cropcopId, res) {
        var sql = "SELECT a.*,b.CropVarietyName,c.CropCatName   FROM TblCropCOP a LEFT JOIN TblCropMaster b ON a.TblCropMaster_ID=b.ID  LEFT JOIN TblCropCategory c ON b.TblCropCategory_ID=c.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND a.ID=?";
        try {
            await connection.query(sql, cropcopId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };
    this.updateAnimalCOP = function (AnimalCopID, req, res) {
        // console.log(req.body)

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
       
        var sql = `UPDATE TBLAnimalCOP SET COPNO='${req.body.COPNO}',Activity='${req.body.Activity}',AnimalMilestoneID='${req.body.AnimalMilestoneID}',CriticalActivity='${req.body.CriticalActivity}',Dependency='${req.body.Dependency}',Dose='${req.body.Dose}',AgeofDose='${req.body.AgeofDose}',TblAnimalMaster_ID='${req.body.TblAnimalMaster_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${AnimalCopID} `;



        try {
            connection.query(sql, AnimalCopID).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };

    this.removeCropCOP = function (cropcopId, res) {

        try {
            connection.query(sql, cropcopId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}


module.exports = new AnimalCOPDAO();