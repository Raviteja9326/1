var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
//for get
function AnimalCategoryDAO() {
	this.getAllanimalCategory = async function (req, res) {
		var sql = 'SELECT * FROM TblAnimalCategory WHERE isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};


	//get gy id
	this.getAnimalCategoryById = async function (animalcategoryId, res) {
		var sql = 'SELECT * FROM TblAnimalCategory WHERE isDeleted=1 AND ID=?';
		try {
			await connection.query(sql, animalcategoryId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	//for post

	this.createAnimalCategory = function (req, res) {
		var post = {
			AnimalCatName: req.body.AnimalCatName,
			created_by: req.body.created_by
		};
		var sql = 'INSERT INTO TblAnimalCategory SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for checking samesoiltype
	this.checkAnimalCategoryExists =async function (AnimalCatName,res) {
		// console.log('testing  ', AnimalCategory);
		// console.log('getting checkAnimalCategoryExists ', AnimalCategory.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(async function (resolve, reject) {
			var sql =
				'SELECT count(*) totalCount FROM TblAnimalCategory where isDeleted=1 AND upper(AnimalCatName) like ?';
			try {
				connection.query(sql, AnimalCatName.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};
	//for update

	this.updateById = function (req, animalcategoryId, res) {
		
		
		let sql = `UPDATE TblAnimalCategory SET AnimalCatName='${req.body.AnimalCatName}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${animalcategoryId} `;
		try {
			connection.query(sql, animalcategoryId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	//for delete
	this.deleteById = function (animalcategoryId, res) {
		let sql = `UPDATE TblAnimalCategory a
      LEFT JOIN TblAnimalMaster b ON a.ID=b.TblAnimalCategory_ID
      SET a.isDeleted=0,b.isDeleted=0 WHERE a.ID =${animalcategoryId}`;
		try {
			connection.query(sql, animalcategoryId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}
module.exports = new AnimalCategoryDAO();
