var connection = require('../MySQLConnect');

var HttpStatus = require('http-status-codes');

function plottingDAO() {
    this.getAllplotting = async function (res) {


        // console.log("error", err);
        var sql = "SELECT a.*,b.LandName FROM TblPloting a LEFT JOIN TblLand b ON b.ID=a.TblLand_ID  WHERE a.isDeleted=1 AND b.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };
    this.getplottingById = function (plottingId, res) {


        // console.log("error", err);
        var sql = "SELECT ID,PlotingName,PlottingPurpose,PlottingArea,PlottingDirection,TblLand_ID FROM TblPloting WHERE ID=?";
        try {
            connection.query(sql, plottingId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };


    this.getplottingByLandId = function (plottingId, res) {


        // console.log("error", err);
        var sql = "SELECT ID,PlotingName,PlottingPurpose,PlottingArea,PlottingDirection FROM TblPloting WHERE TblLand_ID=?";
        try {
            connection.query(sql, plottingId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };




    this.createplotting = function (req, res) {


        // console.log("error", err);

        var post = {
            PlotingName: req.body.PlotingName,
            PlottingPurpose: req.body.PlottingPurpose,
            PlottingArea: req.body.PlottingArea,
            PlottingDirection: req.body.PlottingDirection,
            TblLand_ID: req.body.TblLand_ID,

        };
        var sql = "INSERT INTO TblPloting SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };
    this.updateplottingById = function (req, plottingId, res) {
        // console.log(req.body);

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.PlotingName,
            req.body.PlottingPurpose,
            req.body.PlottingArea,
            req.body.PlottingDirection,
            req.body.TblLand_ID,
            plottingId
        ];
        var sql = `UPDATE TblPloting SET PlotingName=?,PlottingPurpose=?,PlottingArea=?,PlottingDirection=?,TblLand_ID=?  WHERE isDeleted=1 AND ID=? `;
        try {
            connection.query(sql, plottingId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };
    this.deleteplottingById = function (plottingId, res) {
        // console.log(plottingId, "ima plottingId")


        // console.log("error", err);
        var sql = `UPDATE TblPloting m
            LEFT JOIN TblCropCycle c ON c.TblPloting_ID=m.ID
            LEFT JOIN TblCropLane e ON e.TblPloting_ID=m.ID
            SET m.isDeleted=0,
            c.isDeleted=0,
            e.isDeleted=0
            WHERE m.ID='${plottingId}'`;
        try {
            connection.query(sql, plottingId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}
module.exports = new plottingDAO();