var connection = require('../MySQLConnect');

var HttpStatus = require('http-status-codes');

function croplinesDAO() {
    this.getAllcroplines = async function (res) {


        // console.log("error", err);
        var sql = "SELECT a.*,b.LandName,c.PlotingName FROM TblCropLane a LEFT JOIN TblLand b ON b.ID=a.TblPloting_TblLand_ID LEFT JOIN TblPloting c ON c.ID=a.TblPloting_ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };
    this.getcroplinesById = function (croplinesId, res) {


        // console.log("error", err);
        var sql = "SELECT ID,Name,Area,NoOfLines,Spacing,Utilization,TblPloting_ID,TblPloting_TblLand_ID FROM TblCropLane WHERE ID=?";
        try {
            connection.query(sql, croplinesId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };


    this.getcroplinesByLandId = function (landId, res) {


        // console.log("error", err);
        var sql = `SELECT ID,Name,Area,NoOfLines,Spacing,Utilization FROM TblCropLane  WHERE TblPloting_TblLand_ID='${landId}'`;
        try {
            connection.query(sql, landId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };


    this.getcroplinesByPlottingId = function (plottingId, res) {


        // console.log("error", err);
        var sql = `SELECT ID,Name,Area,NoOfLines,Spacing,Utilization FROM TblCropLane  WHERE TblPloting_ID='${plottingId}'`;
        try {
            connection.query(sql, plottingId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };




    this.createcroplines = function (req, res) {


        // console.log("error", err);

        var post = {

            Name: req.body.Name,
            Area: req.body.Area,
            NoOfLines: req.body.NoOfLines,
            Spacing: req.body.Spacing,
            Utilization: req.body.Utilization,
            TblPloting_ID: req.body.TblPloting_ID,
            TblPloting_TblLand_ID: req.body.TblPloting_TblLand_ID,
        };
        var sql = "INSERT INTO TblCropLane SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };
    this.updatecroplinesById = function (req, croplinesId, res) {
        // console.log(req.body);

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.Name,
            req.body.Area,
            req.body.NoOfLines,
            req.body.Spacing,
            req.body.Utilization,
            req.body.TblPloting_ID,
            req.body.TblPloting_TblLand_ID,
            croplinesId
        ];
        var sql = `UPDATE TblCropLane SET Name=?,Area=?,NoOfLines=?,Spacing=?,Utilization=?,TblPloting_ID=?,TblPloting_TblLand_ID=?  WHERE isDeleted=1 AND ID=? `;


        try {
            connection.query(sql, croplinesId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };

    this.deletecroplinesById = function (croplinesId, res) {
        // console.log(croplinesId, "ima croplinesId")


        // console.log("error", err);
        var sql = `UPDATE TblCropLane m
            LEFT JOIN TblCropCycle c ON c.TblCropLane_ID=m.ID
            SET m.isDeleted=0,
            c.isDeleted=0 
             WHERE m.ID='${croplinesId}'`;
        try {
            connection.query(sql, croplinesId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }
}

module.exports = new croplinesDAO();