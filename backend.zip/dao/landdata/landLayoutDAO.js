var connection = require('../MySQLConnect');
var HttpStatus = require('http-status-codes');


function landLayoutDAO() {
    this.getAlllandLayout = async function (res) {
        var sql = "SELECT a.*,b.FarmerName,b.SurName,c.SoilType FROM TblLand a  LEFT JOIN TblFarmer b ON b.ID=a.TblFarmer_ID  LEFT JOIN TblSoilType c ON c.ID=a.TblSoilType_ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1";
        try {
            await connection.query(sql).then(data => {
                res.status(HttpStatus.OK).json(data);
            })
        } catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                err: {
                    message: error.message,
                    status: HttpStatus.getStatusCode('Server Error')
                }
            })
        }
    };
    this.getlandLayoutById = function (landlayoutId, res) {


        // console.log("error", err);
        var sql = "SELECT ID,Tenure,LandinUse,UnderBorders,LandValue,Irrigation,Topography,Leased,Drinage,SoilErrotions,LandRevenueValue,RentalValue,TblFarmer_ID,TblSoilType_ID,Area FROM TblLand WHERE ID=?";
        try {
            connection.query(sql, landlayoutId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };

    this.getlandlayoutByFarmerId = function (landlayoutId, res) {


        // console.log("error", err);
        var sql = "SELECT ID,Tenure,LandinUse,UnderBorders,LandValue,Irrigation,Topography,Leased,Drinage,SoilErrotions,LandRevenueValue,RentalValue,Area,TblSoilType_ID FROM TblLand WHERE TblFarmer_ID=?";
        try {
            connection.query(sql, landlayoutId).then(data => {
                if (data.length == 0) {
                    res.json({
                        data: "No Data Available with this ID"
                    })
                }
                else {
                    res.status(HttpStatus.OK).json(data)
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }
    };



    this.createlandLayout = function (req, res) {


        // console.log("error", err);

        var post = {
            LandName: req.body.LandName,
            Tenure: req.body.Tenure,
            LandinUse: req.body.LandinUse,
            UnderBorders: req.body.UnderBorders,
            LandValue: req.body.LandValue,
            Irrigation: req.body.Irrigation,
            Topography: req.body.Topography,
            Leased: req.body.Leased,
            Drinage: req.body.Drinage,
            SoilErrotions: req.body.SoilErrotions,
            LandRevenueValue: req.body.LandRevenueValue,
            RentalValue: req.body.RentalValue,
            TblFarmer_ID: req.body.TblFarmer_ID,
            TblSoilType_ID: req.body.TblSoilType_ID,
            Area: req.body.Area,

        };
        var sql = "INSERT INTO TblLand SET ?";
        try {
            connection.query(sql, post).then(result => {
                if (result) {
                    res.status(HttpStatus.CREATED).json({ data: "Successfully Posted", lanId: result.insertId })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')

            })
        }

    };


    this.updatelandLayoutById = function (req, landlayoutId, res) {
        // console.log(req.body)

        // get id as parameter to passing into query and return filter data

        // console.log("error", err);
        var dataToBeUpdated = [
            req.body.LandName,
            req.body.Tenure,
            req.body.LandinUse,
            req.body.UnderBorders,
            req.body.LandValue,
            req.body.Irrigation,
            req.body.Topography,
            req.body.Leased,
            req.body.Drinage,
            req.body.SoilErrotions,
            req.body.LandRevenueValue,
            req.body.RentalValue,
            req.body.TblFarmer_ID,
            req.body.TblSoilType_ID,
            req.body.Area,
            landlayoutId
        ]
        var sql = `UPDATE TblLand SET LandName=?,Tenure=?,LandinUse=?,UnderBorders=?,LandValue=?,Irrigation=?,Topography=?,Leased=?,Drinage=?,SoilErrotions=?,LandRevenueValue=?,RentalValue=?,TblFarmer_ID=?,TblSoilType_ID=?,Area=?  WHERE isDeleted=1 AND ID=? `;

        try {
            connection.query(sql, landlayoutId).then(result => {
                if (result) {
                    res.json({ data: "Successfully Updated" })
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    };



    this.deletelandLayoutById = function (landlayoutId, res) {
        // console.log(landlayoutId, "ima landlayoutId")


        // console.log("error", err);
        var sql = `UPDATE TblLand m
            LEFT JOIN TblPloting c ON c.TblLand_ID=m.ID
            LEFT JOIN TblCropCycle e ON e.TblLand_ID=m.ID
            LEFT JOIN TblCropLane h ON h.TblPloting_TblLand_ID=m.ID
            LEFT JOIN TblIrrigation f ON f.TblLand_ID=m.ID
            SET m.isDeleted=0,
            c.isDeleted=0,
            e.isDeleted=0,
            h.isDeleted=0,
            f.isDeleted=0
            WHERE m.ID='${landlayoutId}'`;
        try {
            connection.query(sql, landlayoutId).then(result => {
                if (result) {
                    res.json({ data: 'Successfully Deleted' });
                }
                else {
                    res.status(HttpStatus.getStatusCode('Bad Request')).json({
                        status: HttpStatus.getStatusCode('Bad Request'),
                    })
                }
            })
        }
        catch (error) {
            res.status(HttpStatus.getStatusCode('Server Error')).json({
                message: error.message,
                status: HttpStatus.getStatusCode('Server Error')
            })
        }
    }

}


module.exports = new landLayoutDAO();