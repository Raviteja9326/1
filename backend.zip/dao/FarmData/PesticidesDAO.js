var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function pesticidesDAO() {
  this.getAllpesticides = async function (req, res) {


    // console.log("error", err);
    var sql =
      "SELECT  f.*, a.DealerName,b.Companyname FROM TblPesticides f  LEFT JOIN TblDealer a ON  f.TblDealer_ID=a.ID  LEFT JOIN TblCompanyMaster b ON f.TblFertilizerCompanyMaster_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data);
      })
    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  //get gy id
  this.getpesticidesId = async function (pesticidesId, res) {
    // console.log("testing in dao", pesticidesId);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
    var sql =
      "SELECT  f.*, a.DealerName,b.Companyname FROM TblPesticides f  LEFT JOIN TblDealer a ON  f.TblDealer_ID=a.ID  LEFT JOIN TblCompanyMaster b ON f.TblFertilizerCompanyMaster_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1  AND f.ID=?";

    try {
      await connection.query(sql, pesticidesId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  //for post

  this.createpesticides = function (req, res) {


    // console.log("error", err);
    var post = {
      PestName: req.body.PestName,
      PestType: req.body.PestType,
      PestGivingMethod: req.body.PestGivingMethod,
      TblFertilizerCompanyMaster_ID: req.body.TblFertilizerCompanyMaster_ID,
      TblDealer_ID: req.body.TblDealer_ID,
      created_by: req.body.created_by
    };
    var sql = "INSERT INTO TblPesticides SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };


  //for checking samepesticides
  this.checkpesticidesExists = function (PestName) {
    // console.log("testing type", PestName);

    // console.log("getting checkfertilizerExists ", PestName.toUpperCase());
    // get id as parameter to passing into query and return filter data
    return new Promise(function (resolve, reject) {

      // console.log("error", err);
      var sql =
        "SELECT count(*) totalCount FROM TblPesticides where isDeleted=1 AND upper(PestName) like ?";
      try {
        connection.query(sql, PestName.toUpperCase().trim()).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    })
  };

  //for update
  this.updateById = function (req, pesticidesId, res) {
    // console.log(req.body);

    // get id as parameter to passing into query and return filter data

    // console.log("error", err);
   
    var sql = `UPDATE TblPesticides SET PestName='${req.body.PestName}',PestType='${req.body.PestType}',PestGivingMethod='${req.body.PestGivingMethod}',TblDealer_ID='${req.body.TblDealer_ID}',TblFertilizerCompanyMaster_ID='${req.body.TblFertilizerCompanyMaster_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${pesticidesId} `;

    try {
      connection.query(sql, pesticidesId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };
  //for delete
  this.deleteById = function (Id, res) {



    // console.log("error", err);
    let sql = `UPDATE TblPesticides SET isDeleted=0 WHERE ID =${Id}`;
    try {
      connection.query(sql, Id).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new pesticidesDAO();
