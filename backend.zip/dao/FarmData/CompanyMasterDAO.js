var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function CompanyMasterDAO() {
	this.getAllcompanymaster = async function (req, res) {


		// console.log("error", err);
		var sql = "SELECT * FROM TblCompanyMaster WHERE isDeleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};



	this.getcompanymasterId = async function (companymasterId, res) {


		// console.log("error", err);
		var sql = "SELECT * FROM TblCompanyMaster WHERE isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, companymasterId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};



	this.createcompanymaster = function (req, res) {


		// console.log("error", err);
		
		var sql = "INSERT INTO TblCompanyMaster   SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	this.updateById = function (req, companymasterId, res) {
		// console.log(req.body)

		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		
		var sql = `UPDATE TblCompanyMaster SET Companyname='${req.body.Companyname}',modified_by='${req.body.modified_by}' WHERE isDeleted=1 AND ID=${companymasterId} `;

		try {
			connection.query(sql, companymasterId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteById = function (companymasterId, res) {


		// console.log("error", err);
		var sql = `UPDATE TblCompanyMaster SET isDeleted=0 WHERE ID=${companymasterId}`;
		try {
			connection.query(sql, companymasterId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}

}

module.exports = new CompanyMasterDAO();