var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function DealerDAO() {
	this.getAllfertilizers = async function (req, res) {


		// console.log('error', err);
		var sql =
			'SELECT  f.*, a.DealerName,b.Companyname FROM TblFertilizer f  LEFT JOIN TblDealer a ON  f.TblDealer_ID=a.ID  LEFT JOIN TblCompanyMaster b ON f.TblFertilizerCompanyMaster_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1';

		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	//get gy id
	this.getfertilizersId = async function (fertilizersId, res) {
		// console.log('testing in dao', fertilizersId);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
		var sql =
			'SELECT  f.*, a.DealerName,b.Companyname FROM TblFertilizer f  LEFT JOIN TblDealer a ON  f.TblDealer_ID=a.ID  LEFT JOIN TblCompanyMaster b ON f.TblFertilizerCompanyMaster_ID=b.ID  WHERE f.isDeleted=1 AND a.isDeleted=1 AND b.isDeleted=1  AND f.ID=?';
		try {
			await connection.query(sql, fertilizersId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};


	//for post

	this.createfertilizers = function (req, res) {


		// console.log('error', err);
		var post = {
			FertilizerType: req.body.FertilizerType,
			FertilizerName: req.body.FertilizerName,
			VarietyOfFertilizer: req.body.VarietyOfFertilizer,
			QuantityOfFertilizer: req.body.QuantityOfFertilizer,
			NoOfFertilizerOutlets: req.body.NoOfFertilizerOutlets,
			NameOfFertilizerOutlets: req.body.NameOfFertilizerOutlets,
			TblDealer_ID: req.body.TblDealer_ID,
			TblFertilizerCompanyMaster_ID: req.body.TblFertilizerCompanyMaster_ID,
			created_by: req.body.created_by
		};
		var sql = 'INSERT INTO TblFertilizer SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};
	//for checking samefertilizers
	this.checkfertilizerExists = function (FertilizerName) {
		// console.log('testing type', FertilizerName);

		// console.log('getting checkfertilizerExists ', FertilizerName.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(function (resolve, reject) {

			// console.log('error', err);
			var sql =
				'SELECT count(*) totalCount FROM TblFertilizer where isDeleted=1 AND upper(FertilizerName) like ?';
			try {
				connection.query(sql, FertilizerName.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};
	//for update
	this.updateById = function (req, fertilizersId, res) {
		// console.log(req.body);

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
	
		var sql = `UPDATE TblFertilizer SET FertilizerType='${req.body.FertilizerType}',FertilizerName='${req.body.FertilizerName}',VarietyOfFertilizer='${req.body.VarietyOfFertilizer}',QuantityOfFertilizer='${req.body.QuantityOfFertilizer}',NoOfFertilizerOutlets='${req.body.NoOfFertilizerOutlets}',NameOfFertilizerOutlets='${req.body.NameOfFertilizerOutlets}',TblDealer_ID='${req.body.TblDealer_ID}',TblFertilizerCompanyMaster_ID='${req.body.TblFertilizerCompanyMaster_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${fertilizersId} `;

		try {
			connection.query(sql, fertilizersId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	//for delete
	this.deleteById = function (Id, res) {



		// console.log('error', err);
		let sql = `UPDATE TblFertilizer SET isDeleted=0 WHERE ID =${Id}`;
		try {
			connection.query(sql, Id).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new DealerDAO();
