
var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function DiseaseDAO() {
	this.getAllDiseases = async function (req, res) {

		var sql = "SELECT a.*,b.Type  FROM TblDiseaseType a LEFT JOIN TblTypeOfDisease b ON a.Type=b.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 ";

		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	this.getallDiseaseTypes = async function (req, res) {

		var sql = "SELECT *  FROM TblTypeOfDisease WHERE isDeleted=1 ";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	this.getallCropDiseaseTypes = async function (req, res) {

		var sql = "SELECT a.*,b.Type  FROM TblDiseaseType a LEFT JOIN TblTypeOfDisease b ON a.Type=b.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 And a.Type=2";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	this.getallAnimalDiseaseTypes = async function (req, res) {

		var sql = "SELECT a.*,b.Type  FROM TblDiseaseType a LEFT JOIN TblTypeOfDisease b ON a.Type=b.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 And a.Type=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	this.getDiseaseById = async function (diseaseId, res) {

		var sql = "SELECT a.*,b.Type  FROM TblDiseaseType a LEFT JOIN TblTypeOfDisease b ON a.Type=b.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, diseaseId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};


	this.checkDiseaseExists = function (DiseaseType) {

		return new Promise(function (resolve, reject) {

			var sql =
				"SELECT count(*) totalCount FROM TblDiseaseType WHERE isDeleted=1 AND upper(DiseaseType) like ?";
			try {
				connection.query(sql, DiseaseType.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};

	this.createDisease = function (req, res) {

		var post = {
			Type: req.body.Type,
			DiseaseType: req.body.DiseaseType,
			Description: req.body.Description,
			created_by: req.body.created_by

		};
		var sql = "INSERT INTO TblDiseaseType SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	}
	this.updateCropMaster = function (req, diseaseId, res) {

		
		var sql = `UPDATE TblDiseaseType SET  Type='${req.body.Type}',DiseaseType='${req.body.DiseaseType}',Description='${req.body.Description}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID='${diseaseId}' `;

		try {
			connection.query(sql, diseaseId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	this.removeDisease = function (diseaseId, res) {

		var sql = "UPDATE TblDiseaseType SET isDeleted=0 WHERE ID=?";
		try {
			connection.query(sql, diseaseId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new DiseaseDAO();