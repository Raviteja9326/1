var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropDiseaseDAO() {
	this.getAllCropReportDisease = async function (req, res) {

		var sql = "SELECT a.*,b.CropVarietyName,c.Cause,d.DiseaseType  FROM TblCropDisease a LEFT JOIN TblCropMaster b ON a.CropCycleID=b.ID  LEFT JOIN TblDisease c ON a.DiseaseID=c.ID LEFT JOIN TblDiseaseType d ON a.Type=d.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND d.isDeleted=1 ";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getCropReportDiseaseById = async function (cropreportdiseaseId, res) {

		var sql = "SELECT a.*,b.CropVarietyName,c.Cause,d.DiseaseType  FROM TblCropDisease a LEFT JOIN TblCropMaster b ON a.CropCycleID=b.ID  LEFT JOIN TblDisease c ON a.DiseaseID=c.ID LEFT JOIN TblDiseaseType d ON a.Type=d.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND d.isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, cropreportdiseaseId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};


	this.createCropReportDisease = function (req, res) {

		var post = {
			CropCycleID: req.body.CropCycleID,
			DiseaseID: req.body.DiseaseID,
			Symptoms: req.body.Symptoms,
			RiskID: req.body.RiskID,


			DiseaseDate: req.body.DiseaseDate,
			Impact: req.body.Impact,
			Type: req.body.Type,
			ContingencyPlan: req.body.ContingencyPlan,
			created_by: req.body.created_by
		};
		var sql = "INSERT INTO TblCropDisease SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};



	this.updateCropReportDisease = function (cropreportdiseaseId, req, res) {

		
		var sql = `UPDATE TblCropDisease SET CropCycleID='${req.body.CropCycleID}',DiseaseID='${req.body.DiseaseID}',Symptoms='${req.body.Symptoms}',RiskID='${req.body.RiskID}',DiseaseDate='${req.body.DiseaseDate}',Impact='${req.body.Impact}',Type='${req.body.Type}',ContingencyPlan='${req.body.ContingencyPlan}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${cropreportdiseaseId} `;
		try {
			connection.query(sql, cropreportdiseaseId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	this.removeCropReportDisease = function (cropreportdiseaseId, res) {

		var sql = "UPDATE TblCropDisease SET  isDeleted=0 WHERE ID=?";
		try {
			connection.query(sql, cropreportdiseaseId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new CropDiseaseDAO();