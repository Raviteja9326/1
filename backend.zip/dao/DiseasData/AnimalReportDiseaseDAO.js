var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function AnimalDiseaseDAO() {
	this.getAllAnimalReportDisease = async function (req, res) {

		var sql = "SELECT a.*,b.AnimalName,c.Cause,d.DiseaseType  FROM TblAnimalReportDisease a LEFT JOIN TblAnimalMaster b ON a.AnimalCycleID=b.ID  LEFT JOIN TblAnimalDisease c ON a.DiseaseID=c.ID LEFT JOIN TblDiseaseType d ON a.Type=d.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND d.isDeleted=1";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getAnimalReportDiseaseById = async function (animalreportdiseaseId, res) {

		var sql = "SELECT a.*,b.AnimalName,c.Cause,d.DiseaseType  FROM TblAnimalReportDisease a LEFT JOIN TblAnimalMaster b ON a.AnimalCycleID=b.ID  LEFT JOIN TblAnimalDisease c ON a.DiseaseID=c.ID LEFT JOIN TblDiseaseType d ON a.Type=d.ID  WHERE a.isDeleted=1 AND b.isDeleted=1 AND c.isDeleted=1 AND d.isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, animalreportdiseaseId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.createAnimalReportDisease = function (req, res) {

		var post = {
			AnimalCycleID: req.body.AnimalCycleID,
			DiseaseID: req.body.DiseaseID,
			Symptoms: req.body.Symptoms,
			RiskID: req.body.RiskID,
			DiseaseDate: req.body.DiseaseDate,
			Impact: req.body.Impact,
			Type: req.body.Type,
			ContingencyPlan: req.body.ContingencyPlan,
			created_by: req.body.created_by
		};
		var sql = "INSERT INTO TblAnimalReportDisease SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};


	this.updateAnimalReportDisease = function (animalreportdiseaseId, req, res) {

		
		var sql = `UPDATE TblAnimalReportDisease SET AnimalCycleID='${req.body.AnimalCycleID}',DiseaseID='${req.body.DiseaseID}',Symptoms='${req.body.Symptoms}',RiskID='${req.body.RiskID}',DiseaseDate='${req.body.DiseaseDate}',Impact='${req.body.Impact}',Type='${req.body.Type}',ContingencyPlan='${req.body.ContingencyPlan}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${animalreportdiseaseId} `;
		try {
			connection.query(sql, animalreportdiseaseId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.removeAnimalReportDisease = function (animalreportdiseaseId, res) {

		var sql = "UPDATE TblAnimalReportDisease SET  isDeleted=0 WHERE ID=?";
		try {
			connection.query(sql, animalreportdiseaseId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new AnimalDiseaseDAO();