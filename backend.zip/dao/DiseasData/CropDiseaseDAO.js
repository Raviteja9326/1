var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function CropDiseaseDAO() {
	this.getAllCropDisease = async function (req, res) {

		var sql = "SELECT a.*,b.CropVarietyName  FROM TblDisease a LEFT JOIN TblCropMaster b ON a.TblCropMaster_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 ";
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};
	this.getCropDiseaseById = async function (cropdiseaseId, res) {

		var sql = "SELECT a.*,b.CropVarietyName  FROM TblDisease a LEFT JOIN TblCropMaster b ON a.TblCropMaster_ID=b.ID WHERE a.isDeleted=1 AND b.isDeleted=1 AND ID=?";
		try {
			await connection.query(sql, cropdiseaseId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.createCropDisease = function (req, res) {

		var post = {
			DiseaseDesc: req.body.DiseaseDesc,
			Symptoms: req.body.Symptoms,
			Cause: req.body.Cause,
			Treatment: req.body.Treatment,
			Image: req.body.Image,
			ReferanceURL: req.body.ReferanceURL,
			TblCropMaster_ID: req.body.TblCropMaster_ID,
			created_by: req.body.created_by
		};
		var sql = "INSERT INTO TblDisease SET ?";
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};


	this.updateCropDisease = function (cropdiseaseId, req, res) {

		//  console.log("error", err);
	
		var sql = `UPDATE TblDisease SET DiseaseDesc='${req.body.DiseaseDesc}',Symptoms='${req.body.Symptoms}',Cause='${req.body.Cause}',Treatment='${req.body.Treatment}',Image='${req.body.Image}',ReferanceURL='${req.body.ReferanceURL}',TblCropMaster_ID='${req.body.TblCropMaster_ID}',modified_by='${req.body.modified_by}'  WHERE isDeleted=1 AND ID=${	cropdiseaseId} `;
		try {
			connection.query(sql, cropdiseaseId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};
	this.removeCropDisease = function (cropdiseaseId, res) {

		var sql = "UPDATE TblDisease SET  isDeleted=0 WHERE ID=?";
		try {
			connection.query(sql, cropdiseaseId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new CropDiseaseDAO();