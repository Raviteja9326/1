var connection = require('../MySQLConnect');
var HttpStatus = require('http-status-codes');

function C3OfficeDAO() {
	this.getAllC3Offices = function (res) {
		var sql =
			'SELECT ID,Name,Address,TblCountry_ID,TblState_ID,TblDistrict_ID,created_at,updated_at FROM TblC3Office WHERE isDeleted=1';
		connection.query(sql, function (err, result) {
			res.json(result);
		});
	};

	this.getC3OfficeById = function (c3OfficeId, res) {
		var sql =
			'SELECT ID,Name,Address,TblCountry_ID,TblState_ID,TblDistrict_ID,created_at,updated_at FROM TblC3Office WHERE isDeleted=1 AND ID= ?';
		connection.query(sql, c3OfficeId, function (err, result) {

			if (result == '') {
				res.json({ data: 'No Data Available with this ID' });
			} else {
				res.json(result);
			}
		});
	};


	this.getC3OfficeByDistrictId = function (districtId, res) {
		var sql = 'SELECT ID,Name FROM TblC3Office WHERE TblDistrict_ID=? AND isDeleted=1'
		try {
			connection.query(sql, districtId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No c3Office Available With This ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};






	this.getC3OfficeByCountryId = (countryId, res) => {
		try {
			connection.query('SELECT ID,Name FROM TblC3Office WHERE TblCountry_ID=? AND isDeleted=1', countryId).then((data) => {
				if (data === []) {
					res.json({ data: 'No c3Office Available With This ID' });
				} else {
					res.json(data);
				}
			});
		} catch (error) {
			res.json({ data: 'Internal Server Error' });
		}
	};

	this.getC3OfficeByStateID = (stateId, res) => {
		try {
			connection.query('SELECT ID,Name FROM TblC3Office WHERE TblState_ID=? AND isDeleted=1', stateId).then((data) => {
				if (data === []) {
					res.json({ data: 'No c3Office Available With This ID' });
				} else {
					res.json(data);
				}
			});
		} catch (error) {
			res.json({ data: 'Internal Server Error' });
		}
	};



	this.checkC3OfficeExists = async function (req, res) {
		return new Promise(async function (resolve, reject) {
			var dataToCheck = [
				req.body.Name.toUpperCase().trim(),
				req.body.TblDistrict_ID,
				req.body.TblState_ID,
				req.body.TblCountry_ID
			];
			var sql = 'SELECT count(*) totalCount FROM TblC3Office WHERE upper(Name)=? AND TblDistrict_ID=? AND TblState_ID=? AND TblCountry_ID=? AND isDeleted=1';
			try {
				await connection.query(sql, dataToCheck).then((data) => {
					if (data[0].totalCount == 0) {
						return resolve();
					} else {
						reject();
					}
				});
			} catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				});
			}
		});
	};

	this.createC3Office = function (req, res) {
		// console.log("error", err);

		var post = {
			Name: req.body.Name,
			Address: req.body.Address,
			TblCountry_ID: req.body.TblCountry_ID,
			TblState_ID: req.body.TblState_ID,
			TblDistrict_ID: req.body.TblDistrict_ID
		};
		var sql = 'INSERT INTO TblC3Office SET ?';
		connection.query(sql, post, function (err, result) {
			// console.log("error", err);
			// console.log("result", result);

			res.json({ data: 'Successfully Posted' });
		});
	};

	this.updateC3OfficeById = function (req, c3OfficeId, res) {
		// get id as parameter to passing into query and return filter data

		// console.log("error", err);
		let sql = `UPDATE TblC3Office  SET  Name='${req.body.Name}', Address='${req.body.Address}',TblCountry_ID='${req
			.body.TblCountry_ID}',TblState_ID='${req.body.TblState_ID}', TblDistrict_ID='${req.body
				.TblDistrict_ID}' WHERE ID= ${c3OfficeId}`;
		connection.query(sql, c3OfficeId, function (err, result) {
			// console.log("error", err);

			res.json({ data: 'Successfully Updated' });
		});
	};

	this.deleteC3OfficeById = function (c3OfficeId, res) {
		//removing mandal from data base by using mandalId
		let sql = `UPDATE TblC3Office m
      LEFT JOIN TblMandal c ON c.TblC3Office_C3OfficeID = m.ID
      SET m.isDeleted=0,
      c.isDeleted=0

      WHERE m.ID = ${c3OfficeId}`;
		try {
			connection.query(sql, c3OfficeId).then((result) => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				} else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request')
					});
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			});
		}
	};
}
module.exports = new C3OfficeDAO();

