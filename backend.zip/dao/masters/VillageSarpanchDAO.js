var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function VillageSarpanchDAO() {
	this.getAllVillageSarpanches = async function (res) {

		// console.log('in VillageSarpanchDAO.getAllVillageSarpanches');
		// getting all states data to passing into query  to data

		// console.log('error', err);
		var sql =
			'SELECT c.* FROM TblVillageSarpanch c LEFT JOIN TblVillage cu ON cu.ID=c.TblVillage_ID  WHERE c.isDeleted=1 AND cu.isDeleted=1';
		try {
			await connection.query(sql).then(data => {

				res.status(HttpStatus.OK).json(data)

			})

		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getVillageSarpanchById = async function (villageSarpanchId, res) {

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
		var sql =
			'SELECT ID,VillageSarpanchName,VillageSarpanchContactnumber,VillageSarpanchAddress,TblVillage_ID,TblCountry_CountryID,TblState_StateID,Tbldist_distID,Tblmandal_mandalID,created_at,updated_at FROM TblVillageSarpanch where isDeleted=1 And ID= ?';
		try {
			await connection.query(sql, villageSarpanchId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.checkVillageSarpanchExists = async function (req, res) {
		return new Promise(async function (resolve, reject) {

			// console.log('error', err);
			var dataToCheck = [
				req.body.VillageSarpanchName.toUpperCase().trim(),

				req.body.TblVillage_ID,
				req.body.TblCountry_CountryID,
				req.body.TblState_StateID,
				req.body.Tblmandal_mandalID,
				req.body.Tbldist_distID
			];
			var sql = "SELECT count(*) totalCount FROM TblVillageSarpanch WHERE upper(VillageSarpanchName)=?  AND TblVillage_ID=?  AND TblCountry_CountryID=? AND TblState_StateID=? AND Tblmandal_mandalID=? AND Tbldist_distID=?  AND isDeleted=1";
			try {
				await connection.query(sql, dataToCheck).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}

		});
	};

	this.createVillageSarpanch = function (req, res) {


		// console.log('error', err);

		var post = {
			VillageSarpanchName: req.body.VillageSarpanchName.trim(),
			VillageSarpanchContactnumber: req.body.VillageSarpanchContactnumber,
			VillageSarpanchAddress: req.body.VillageSarpanchAddress,
			TblVillage_ID: req.body.TblVillage_ID,
			TblCountry_CountryID: req.body.TblCountry_CountryID,
			TblState_StateID: req.body.TblState_StateID,
			Tblmandal_mandalID: req.body.Tblmandal_mandalID,
			Tbldist_distID: req.body.Tbldist_distID
		};
		var sql = 'INSERT INTO TblVillageSarpanch SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.updateVillageSarpanchById = function (req, villageSarpanchId, res) {

		// get id as parameter to passing into query and return filter data

		// console.log('error', err);
		let sql = `UPDATE TblVillageSarpanch  SET VillageSarpanchName='${req.body.VillageSarpanchName.trim()}', VillageSarpanchAddress='${req
			.body.VillageSarpanchAddress}', VillageSarpanchContactnumber='${req.body
				.VillageSarpanchContactnumber}' , TblVillage_ID='${req.body.TblVillage_ID}',TblCountry_CountryID='${req
					.body.TblCountry_CountryID}',TblState_StateID='${req.body.TblState_StateID}',Tblmandal_mandalID='${req
						.body.Tblmandal_mandalID}' ,Tbldist_distID='${req.body
							.Tbldist_distID}'  WHERE isDeleted=1 AND ID= ${villageSarpanchId}`;
		try {
			connection.query(sql, villageSarpanchId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteVillageSarpanchById = function (villageSarpanchId, res) {



		// console.log('error', err);
		let sql = `UPDATE TblVillageSarpanch SET isDeleted=0 WHERE ID ='${villageSarpanchId}' `;
		try {
			connection.query(sql, villageSarpanchId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new VillageSarpanchDAO();
