var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function RevenueDivisionDAO() {
	this.getAllRevenueDivisions = async function (res) {
		// getting all states data to passing into query  to data
		var sql =
			'SELECT c.* FROM TblRevenuDevision c LEFT JOIN TblMandal cu ON cu.ID=c.TblMandal_MandalID  WHERE c.isDeleted=1 AND cu.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})

		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getRevenueDivisionById = async function (revenuedivisionId, res) {
		// get id as parameter to passing into query and return filter dat
		var sql =
			'SELECT c.* FROM TblRevenuDevision c LEFT JOIN TblMandal cu ON cu.ID=c.TblMandal_MandalID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.ID= ?';
		try {
			await connection.query(sql, revenuedivisionId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.checkRevenueDivisionExists = async function (req, res) {
		//// console.log("getting checkRevenueDivisionExists ", revenueDivisionName.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(async function (resolve, reject) {
			var dataToCheck = [
				req.body.RevenueDivisionName.toUpperCase().trim(),
				req.body.TblMandal_MandalID,
				req.body.TblMandal_TblDistrict_DistrictID,
				req.body.TblCountry_ID,
				req.body.TblState_ID
			];
			var sql = "SELECT count(*) totalCount FROM TblRevenuDevision WHERE upper(RevenueDivisionName)=? AND TblMandal_MandalID=? AND TblMandal_TblDistrict_DistrictID=? AND TblCountry_ID=? AND TblState_ID=? AND  isDeleted=1"
			try {
				await connection.query(sql, dataToCheck).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}

		});
	};

	this.createRevenueDivision = function (req, res) {


		var post = {
			RevenueDivisionName: req.body.RevenueDivisionName.trim(),
			TblMandal_MandalID: req.body.TblMandal_MandalID,
			TblMandal_TblDistrict_DistrictID: req.body.TblMandal_TblDistrict_DistrictID,
			TblCountry_ID: req.body.TblCountry_ID,
			TblState_ID: req.body.TblState_ID
		};
		var sql = 'INSERT INTO TblRevenuDevision SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.updateRevenueDivisionById = function (req, revenuedivisionId, res) {

		let sql = `UPDATE TblRevenuDevision  SET  RevenueDivisionName='${req.body.RevenueDivisionName.trim()}', TblMandal_MandalID='${req
			.body.TblMandal_MandalID}',TblMandal_TblDistrict_DistrictID='${req.body
				.TblMandal_TblDistrict_DistrictID}',TblCountry_ID='${req.body.TblCountry_ID}',TblState_ID='${req.body
					.TblState_ID}' WHERE isDeleted=1 AND ID= ${revenuedivisionId}`;
		try {
			connection.query(sql, revenuedivisionId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteRevenueDivisionById = function (revenuedivisionId, res) {
		let sql = `UPDATE TblRevenuDevision SET isDeleted=0 WHERE ID ='${revenuedivisionId}'`;
		try {
			connection.query(sql, revenuedivisionId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new RevenueDivisionDAO();
