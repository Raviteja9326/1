var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function villagesDAO() {
	this.getAllVillages = async function (res) {
		let sql =
			'SELECT c.* FROM TblVillage c LEFT JOIN TblMandal cu ON cu.ID=c.TblMandal_MandalID  WHERE c.isDeleted=1 AND cu.isDeleted=1';
		try {
			await connection.query(sql).then(data => {

				res.status(HttpStatus.OK).json(data)


			})

		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getVillageById = async function (villageId, res) {

		// console.log('error', err);
		var sql =
			'SELECT c.* FROM TblVillage c LEFT JOIN TblMandal cu ON cu.ID=c.TblMandal_MandalID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.ID=?';
		try {
			await connection.query(sql, villageId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.getVillagesByMandalId = async function (mandalId, res) {

		// console.log('error', err);
		var sql =
			'SELECT c.* FROM TblVillage c LEFT JOIN TblMandal cu ON cu.ID=c.TblMandal_MandalID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND TblMandal_MandalID=?';
		try {
			await connection.query(sql, mandalId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.checkVillageExists = async function (req, res) {

		//// console.log("getting checkVillageExists ", villageName.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(async function (resolve, reject) {
			var dataToCheck = [
				req.body.VillageName.toUpperCase().trim(),
				req.body.TblMandal_MandalID,
				req.body.TblCountry_CountryID,
				req.body.TblDist_DistID,
				req.body.TblState_StateID
			];
			var sql = "SELECT count(*) totalCount FROM TblVillage WHERE upper(VillageName)=? AND TblMandal_MandalID=? AND TblCountry_CountryID=? AND TblDist_DistID=? AND TblState_StateID=? AND isDeleted=1";
			try {
				await connection.query(sql, dataToCheck).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}

		});
	};

	this.createVillage = function (req, res) {

		// console.log('error', err);

		var post = {
			VillageName: req.body.VillageName.trim(),
			TblMandal_MandalID: req.body.TblMandal_MandalID,
			TblCountry_CountryID: req.body.TblCountry_CountryID,
			TblState_StateID: req.body.TblState_StateID,
			TblDist_DistID: req.body.TblDist_DistID
		};
		var sql = 'INSERT INTO TblVillage SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.updateVillageById = function (req, villageId, res) {

		// console.log('error', err);
		let sql = `UPDATE TblVillage  SET VillageName='${req.body.VillageName.trim()}',TblMandal_MandalID='${req
			.body.TblMandal_MandalID}',TblCountry_CountryID='${req.body.TblCountry_CountryID}',TblDist_DistID='${req
				.body.TblDist_DistID}'  WHERE isDeleted=1 AND ID= ${villageId}`;
		try {
			connection.query(sql, villageId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteVillageById = function (villageId, res) {

		// console.log('error', err);
		let sql = `UPDATE TblVillage m
      LEFT JOIN TblVillageSarpanch c ON c.TblVillage_ID = m.ID
      SET m.isDeleted=0,c.isDeleted=0 WHERE m.ID = '${villageId}'`;
		try {
			connection.query(sql, villageId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new villagesDAO();
