var connection = require("../MySQLConnect");

function IsocodesDAO() {


  this.getISOcodes = function (req, res) {
    var sql = "SELECT name,code,dial_code,currency_name,currency_symbol,currency_code FROM TblCountryCode";
    connection.query(sql, function (err, result) {
      if (result == "") {
        res.json({ data: "NO data Available with this name" });

      } else {
        res.json(result);
      }
    })
  };


}

module.exports = new IsocodesDAO();  
