var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function StatesDAO() {
	this.getAllStates = async function (res) {
		// getting all states data to passing into query  to data
		var sql =
			'SELECT c.* FROM TblState c LEFT JOIN TblCountry cu ON cu.ID=c.TblCountry_CountryID  WHERE c.isDeleted=1 AND cu.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data)
			})

		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getStateById = async function (stateId, res) {
		// get id as parameter to passing into query and return filter data
		var sql =
			'SELECT c.* FROM TblState c LEFT JOIN TblCountry cu ON cu.ID=c.TblCountry_CountryID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.ID= ?';
		try {
			await connection.query(sql, stateId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.getStatesByCountryId = async function (countryId, res) {
		var sql =
			'SELECT c.* FROM TblState c LEFT JOIN TblCountry cu ON cu.ID=c.TblCountry_CountryID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.TblCountry_CountryID=?';
		try {
			await connection.query(sql, countryId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.checkStateExists = async function (countryID, stateName, res) {
		console.log(countryID)
		// get id as parameter to passing into query and return filter data
		return new Promise(async function (resolve, reject) {
			var dataToCheck = [countryID, stateName.toUpperCase().trim()];

			var sql = "SELECT count(*) totalCount FROM TblState WHERE  isDeleted=1 AND TblCountry_CountryID=? AND upper(StateName) like ?";
			try {
				await connection.query(sql, dataToCheck).then(data => {
					console.log(data)
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}

		});
	};

	this.createState = function (req, res) {
		var post = {
			StateName: req.body.StateName,
			StateCode: req.body.StateCode,
			TblCountry_CountryID: req.body.TblCountry_CountryID
		};
		var sql = 'INSERT INTO TblState SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.updateStateById = function (stateId, req, res) {
		// get id as parameter to passing into query and return filter data
		let sql = `UPDATE TblState  SET StateName='${req.body.StateName}',StateCode='${req.body
			.StateCode}', TblCountry_CountryID='${req.body
				.TblCountry_CountryID}' WHERE isDeleted=1 AND ID= ${stateId}`;
		try {
			connection.query(sql, stateId).then(result => {
				if (result) {
					res.json({ 'data': "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteStateById = function (stateId, res) {
		let sql = `UPDATE TblState m
      LEFT JOIN TblDistrict c ON c.TblState_StateID = m.ID
      LEFT JOIN TblMandal e ON e.TblState_StateID = m.ID
      LEFT JOIN TblRevenuDevision f ON f.TblState_ID = m.ID
      LEFT JOIN TblVillage g ON g.TblState_StateID = m.ID
	  LEFT JOIN TblVillageSarpanch i ON i.TblState_StateID = m.ID
	  LEFT JOIN TblC3Office l ON l.TblState_ID = m.ID
      SET m.isDeleted=0,
      c.isDeleted=0,
      e.isDeleted=0,
      f.isDeleted=0,
	  g.isDeleted=0,
	  l.isDeleted=0,
      i.isDeleted=0
      WHERE m.ID = '${stateId}'`;
		try {
			connection.query(sql, stateId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new StatesDAO();
