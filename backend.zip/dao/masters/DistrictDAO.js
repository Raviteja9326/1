var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function DistrictsDAO() {
	this.getAllDistricts = async function (res) {
		// getting all districts data to passing into query  to data
		var sql =
			'SELECT c.* FROM TblDistrict c LEFT JOIN TblState cu ON cu.ID=c.TblState_StateID  WHERE c.isDeleted=1 AND cu.isDeleted=1';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data)
			})

		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getDistrictById = async function (districtId, res) {
		// get id as parameter to passing into query and return filter data
		// console.log('error', err);
		var sql =
			'SELECT c.* FROM TblDistrict c LEFT JOIN TblState cu ON cu.ID=c.TblState_StateID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.ID=?';
		try {
			await connection.query(sql, districtId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.getDistrictsByStateId = async function (stateId, res) {
		var sql =
			'SELECT c.* FROM TblDistrict c LEFT JOIN TblState cu ON cu.ID=c.TblState_StateID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.TblState_StateID=?';
		try {
			await connection.query(sql, stateId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {

					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.checkDistrictExists = async function (districtName, stateId, countryId, res) {
		return new Promise(async function (resolve, reject) {
			var dataToCheck = [districtName.toUpperCase().trim(), stateId, countryId];
			var sql = "SELECT count(*) totalCount FROM TblDistrict WHERE upper(DistrictName)=? AND TblState_StateID=? AND TblState_TblCountry_CountryID=? AND isDeleted=1"
			try {
				await connection.query(sql, dataToCheck).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}

		});
	};

	this.createDistrict = function (req, res) {
		var post = {
			DistrictName: req.body.DistrictName,
			DistrictCollector: req.body.DistrictCollector,
			TblState_StateID: req.body.TblState_StateID,
			TblState_TblCountry_CountryID: req.body.TblState_TblCountry_CountryID
		};
		var sql = 'INSERT INTO TblDistrict SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.updateDistrictById = function (req, districtId, res) {
		// get id as parameter to passing into query and return filter data
		let sql = `UPDATE TblDistrict  SET DistrictName='${req.body.DistrictName}', DistrictCollector='${req.body
			.DistrictCollector}',TblState_StateID='${req.body
				.TblState_StateID}',TblState_TblCountry_CountryID='${req.body
					.TblState_TblCountry_CountryID}' WHERE isDeleted=1 AND ID= ${districtId}`;
		try {
			connection.query(sql, districtId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteDistrictById = function (districtId, res) {
		let sql = `UPDATE TblDistrict m
      LEFT JOIN TblMandal c ON c.TblDistrict_DistrictID = m.ID
      LEFT JOIN TblRevenuDevision f ON f.TblMandal_TblDistrict_DistrictID = m.ID
      LEFT JOIN TblVillage g ON g.TblDist_DistID = m.ID
	  LEFT JOIN TblVillageSarpanch i ON i.Tbldist_distID = m.ID
	  LEFT JOIN TblC3Office l ON l.TblDistrict_ID = m.ID
      SET m.isDeleted=0,
      c.isDeleted=0,
      f.isDeleted=0,
	  g.isDeleted=0,
	  l.isDeleted=0,
      i.isDeleted=0
      WHERE m.ID = ${districtId}`;
		try {
			connection.query(sql, districtId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new DistrictsDAO();
