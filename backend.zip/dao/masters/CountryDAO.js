var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');
function CountriesDAO() {

	this.getAllCountries = async function (res) {
		var sql =
			'SELECT ID,CountryName ,CountryCode,ISOCode,created_at,updated_at FROM TblCountry WHERE isDeleted=1  ORDER BY ID DESC';
		try {
			await connection.query(sql).then(data => {
				res.status(HttpStatus.OK).json(data);
			})

		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			})
		}
	};

	this.getCountryById = async function (countriesId, res) {
		// get id as parameter to passing into query and return filter data
		var sql =
			'SELECT ID,CountryName ,CountryCode,ISOCode,created_at,updated_at FROM TblCountry WHERE isDeleted=1 AND ID=?';
		try {
			await connection.query(sql, countriesId).then(data => {
				if (data.length == 0) {
					res.json({
						data: "No Data Available with this ID"
					})
				}
				else {
					res.status(HttpStatus.OK).json(data)
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}
	};

	this.checkCountryExists = async function (countryName, res) {
		return new Promise(async function (resolve, reject) {
			var sql = 'SELECT count(*) totalCount FROM TblCountry WHERE isDeleted=1 AND upper(CountryName) like ?';
			try {
				await connection.query(sql, countryName.toUpperCase().trim()).then(data => {
					if (data[0].totalCount == 0) {
						return resolve()
					}
					else {
						reject()
					};
				})
			}
			catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				})
			}
		})
	};

	this.createCountry = function (req, res) {
		var post = {
			CountryName: req.body.CountryName,
			CountryCode: req.body.CountryCode,
			ISOCode: req.body.ISOCode
		};
		var sql = 'INSERT INTO TblCountry SET ?';
		try {
			connection.query(sql, post).then(result => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		}

	};

	this.updateCountryById = function (req, countriesId, res) {
		// get id as parameter to passing into query and return filter data
		let sql = `UPDATE TblCountry  SET CountryName='${req.body.CountryName}',CountryCode='${req.body
			.CountryCode}',ISOCode='${req.body.ISOCode}' WHERE isDeleted=1 AND ID= ${countriesId}`;
		try {
			connection.query(sql, countriesId).then(result => {
				if (result) {
					res.json({ data: "Successfully Updated" })
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	};

	this.deleteCountryById = function (countryId, res) {
		var sql = `UPDATE TblCountry m
      LEFT JOIN TblState c ON c.TblCountry_CountryID = m.ID
      LEFT JOIN TblCurrency h ON h.TblCountry_CountryID = m.ID
      LEFT JOIN TblDistrict d ON d.TblState_TblCountry_CountryID = m.ID
      LEFT JOIN TblMandal e ON e.TblCountry_CountryID = m.ID
      LEFT JOIN TblRevenuDevision f ON f.TblCountry_ID = m.ID
      LEFT JOIN TblVillage g ON g.TblCountry_CountryID = m.ID
	  LEFT JOIN TblVillageSarpanch i ON i.TblCountry_CountryID = m.ID
	  LEFT JOIN TblC3Office l ON l.TblCountry_ID = m.ID
      SET m.isDeleted=0,
      c.isDeleted=0,
      d.isDeleted=0,
      e.isDeleted=0,
      f.isDeleted=0,
      g.isDeleted=0,
	  h.isDeleted=0,
	  l.isDeleted=0,
      i.isDeleted=0
	  WHERE m.ID = '${countryId}'`;
		try {
			connection.query(sql, countryId).then(result => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				}
				else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request'),
					})
				}
			})
		}
		catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			})
		}
	}
}

module.exports = new CountriesDAO();
