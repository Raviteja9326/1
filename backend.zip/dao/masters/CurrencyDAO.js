var connection = require("../MySQLConnect");
var HttpStatus = require('http-status-codes');

function CurrencyDAO() {
  this.getAllCurrency = async function (res) {
    var sql =
      "SELECT c.*,b.Countryname FROM TblCurrency c LEFT JOIN TblCountry b ON c.TblCountry_CountryID=b.ID  WHERE c.isDeleted=1 AND b.isDeleted=1";
    try {
      await connection.query(sql).then(data => {
        res.status(HttpStatus.OK).json(data)
      })

    } catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        err: {
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        }
      })
    }
  };

  this.getCurrencyById = async function (currencyId, res) {
    var sql =
      "SELECT c.* FROM TblCurrency c LEFT JOIN TblCountry cu ON cu.ID=c.TblCountry_CountryID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.ID=?";
    try {
      await connection.query(sql, currencyId).then(data => {
        if (data.length == 0) {
          res.json({
            data: "No Data Available with this ID"
          })
        }
        else {
          res.status(HttpStatus.OK).json(data)
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }
  };

  this.checkCurrencyExists = async function (TblCountry_CountryID, res) {
    // get id as parameter to passing into query and return filter data
    return new Promise(async function (resolve, reject) {
      var sql =
        "SELECT count(*) totalCount FROM TblCurrency WHERE isDeleted=1 AND TblCountry_CountryID like ?";
      try {
        await connection.query(sql, TblCountry_CountryID).then(data => {
          if (data[0].totalCount == 0) {
            return resolve()
          }
          else {
            reject()
          };
        })
      }
      catch (error) {
        res.status(HttpStatus.getStatusCode('Server Error')).json({
          message: error.message,
          status: HttpStatus.getStatusCode('Server Error')
        })
      }
    });
  };

  this.createCurrency = function (req, res) {
    var post = {
      CurrencyName: req.body.CurrencyName,
      CurrCode: req.body.CurrCode,
      TblCountry_CountryID: req.body.TblCountry_CountryID
    };
    var sql = "INSERT INTO TblCurrency SET ?";
    try {
      connection.query(sql, post).then(result => {
        if (result) {
          res.status(HttpStatus.CREATED).json({ data: "Successfully Posted" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')

      })
    }

  };

  this.updateCurrencyById = function (req, currencyId, res) {
    let sql = `UPDATE TblCurrency  SET CurrencyName='${req.body.CurrencyName}', CurrCode='${req.body.CurrCode}' , TblCountry_CountryID='${req.body.TblCountry_CountryID}' WHERE isDeleted=1 AND ID= ${currencyId}`;
    try {
      connection.query(sql, currencyId).then(result => {
        if (result) {
          res.json({ data: "Successfully Updated" })
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  };

  this.deleteCurrencyById = function (currenciesId, res) {

    // console.log("error", err);
    let sql = `UPDATE TblCurrency SET isDeleted=0 WHERE ID ='${currenciesId}'`;
    try {
      connection.query(sql, currenciesId).then(result => {
        if (result) {
          res.json({ data: 'Successfully Deleted' });
        }
        else {
          res.status(HttpStatus.getStatusCode('Bad Request')).json({
            status: HttpStatus.getStatusCode('Bad Request'),
          })
        }
      })
    }
    catch (error) {
      res.status(HttpStatus.getStatusCode('Server Error')).json({
        message: error.message,
        status: HttpStatus.getStatusCode('Server Error')
      })
    }
  }
}

module.exports = new CurrencyDAO();
