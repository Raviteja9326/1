var connection = require('../MySQLConnect'); var HttpStatus = require('http-status-codes');

function mandalsDAO() {
	this.getAllMandals = async function (res) {
		let sql =
			'SELECT c.* FROM TblMandal c LEFT JOIN TblDistrict cu ON cu.ID=c.TblDistrict_DistrictID  WHERE c.isDeleted=1 AND cu.isDeleted=1';
		try {
			await connection.query(sql).then((data) => {
				res.status(HttpStatus.OK).json(data);
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				err: {
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				}
			});
		}
	};

	this.getMandalById = async function (mandalId, res) {
		let sql =
			'SELECT c.* FROM TblMandal c LEFT JOIN TblDistrict cu ON cu.ID=c.TblDistrict_DistrictID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.ID=? ';
		try {
			await connection.query(sql, mandalId).then((data) => {
				if (data.length == 0) {
					res.json({
						data: 'No Data Available with this ID'
					});
				} else {
					res.status(HttpStatus.OK).json(data);
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			});
		}
	};

	this.getMandalsByDistrictId = async function (districtId, res) {
		let sql =
			'SELECT c.* FROM TblMandal c LEFT JOIN TblDistrict cu ON cu.ID=c.TblDistrict_DistrictID  WHERE c.isDeleted=1 AND cu.isDeleted=1 AND c.TblDistrict_DistrictID=?';
		try {
			await connection.query(sql, districtId).then((data) => {
				if (data.length == 0) {
					res.json({
						data: 'No Data Available with this ID'
					});
				} else {
					res.status(HttpStatus.OK).json(data);
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			});
		}
	};

	this.getMandalsByC3OfficeId = function (c3officeId, res) {
		// console.log("error", err);
		let sql = 'SELECT ID,MandalName FROM TblMandal WHERE  TblC3Office_C3OfficeID=?';
		connection.query(sql, c3officeId, function (err, result) {
			// console.log('error', err);

			if (result == '') {
				res.json({ data: 'No mandals Available With This ID' });
			} else {
				res.json(result);
			}
		});
	};

	this.deleteMandalById = function (mandalId, res) {
		//removing mandal from data base by using mandalId
		let sql = `UPDATE TblMandal m
      LEFT JOIN TblRevenuDevision c ON c.TblMandal_MandalID = m.ID
      LEFT JOIN TblVillage e ON e.TblMandal_MandalID = m.ID
      LEFT JOIN TblVillageSarpanch i ON i.Tblmandal_mandalID = m.ID
      SET m.isDeleted=0,
      e.isDeleted=0,
      c.isDeleted=0,
      i.isDeleted=0

      WHERE m.ID = ${mandalId}`;
		try {
			connection.query(sql, mandalId).then((result) => {
				if (result) {
					res.json({ data: 'Successfully Deleted' });
				} else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request')
					});
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			});
		}
	};

	this.checkMandalExists = async function (req, res) {
		//// console.log("getting checkMandalExists ", MandalName.toUpperCase());
		// get id as parameter to passing into query and return filter data
		return new Promise(async function (resolve, reject) {
			var dataToCheck = [
				req.body.MandalName.toUpperCase().trim(),
				req.body.TblDistrict_DistrictID,
				req.body.TblState_StateID,
				req.body.TblCountry_CountryID,
				req.body.TblC3Office_C3OfficeID
			];
			var sql = "SELECT count(*) totalCount FROM TblMandal WHERE upper(MandalName)=? AND TblDistrict_DistrictID=? AND TblState_StateID=? AND  TblCountry_CountryID=? AND TblC3Office_C3OfficeID=? AND isDeleted=1"
			try {
				await connection.query(sql, dataToCheck).then((data) => {
					if (data[0].totalCount == 0) {
						return resolve();
					} else {
						reject();
					}
				});
			} catch (error) {
				res.status(HttpStatus.getStatusCode('Server Error')).json({
					message: error.message,
					status: HttpStatus.getStatusCode('Server Error')
				});
			}
		});
	};

	this.createMandal = function (req, res) {
		var post = {
			MandalName: req.body.MandalName.trim(),
			TblDistrict_DistrictID: req.body.TblDistrict_DistrictID,
			TblState_StateID: req.body.TblState_StateID,
			TblCountry_CountryID: req.body.TblCountry_CountryID,
			TblC3Office_C3OfficeID: req.body.TblC3Office_C3OfficeID
		};
		var sql = 'INSERT INTO TblMandal SET ? ';
		try {
			connection.query(sql, post).then((result) => {
				if (result) {
					res.status(HttpStatus.CREATED).json({ data: 'Successfully Posted' });
				} else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request')
					});
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			});
		}
	};

	this.updateMandalById = function (req, mandalId, res) {
		let sql = `UPDATE TblMandal  SET MandalName='${req.body.MandalName.trim()}',TblDistrict_DistrictID='${req.body
			.TblDistrict_DistrictID}',TblState_StateID='${req.body.TblState_StateID}',TblCountry_CountryID='${req.body
				.TblCountry_CountryID}', 'TblC3Office_C3OfficeID'='${req.body.TblC3Office_C3OfficeID}' WHERE isDeleted=1 AND ID= ${mandalId}`;
		try {
			connection.query(sql, mandalId).then((result) => {
				if (result) {
					res.json({ data: 'Successfully Updated' });
				} else {
					res.status(HttpStatus.getStatusCode('Bad Request')).json({
						status: HttpStatus.getStatusCode('Bad Request')
					});
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')
			});
		}
	};
}

module.exports = new mandalsDAO();
