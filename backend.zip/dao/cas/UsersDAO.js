const connection = require('../MySQLConnect');
const bcrypt = require('bcrypt');
const Otp = require('../../shared/mobileOTP');
const jwt = require('jsonwebtoken');
const secretKey = 'this is Secret';
var HttpStatus = require('http-status-codes');



function UsersDAO() {
	this.getAllUsers = function (req, res) {
		var sql =
			'SELECT a.ID,a.UserName,b.Countryname,c.StateName from TblUser a LEFT JOIN TblState c ON a.TblState_ID=c.ID LEFT JOIN TblCountry b ON a.TblCountry_ID=b.ID  WHERE a.isDeleted=1';

		connection
			.query(sql)
			.then((result) => {
				res.json({ status: true, data: result, message: '' });
			})
			.catch((err) => {
				res.json({ status: false, data: [], message: 'Internal Server Error' });
			});
	};

	this.getUserByID = function (userID, res) {
		var ID = userID;
		var sql = `SELECT a.ID,a.UserName,a.Location,a.Address,a.PhoneNo,a.TblCountry_ID,a.TblState_ID,a.TblDistrict_ID,b.Countryname,c.StateName,d.DistrictName,( SELECT JSON_ARRAYAGG(JSON_OBJECT('ID',g.ID,'Role',g.RoleName )) FROM TblRole g  WHERE g.ID IN (SELECT  ur.TblRole_ID FROM TblUserRoles ur WHERE ur.TblUser_ID=${ID})) as roles,( SELECT JSON_ARRAYAGG(JSON_OBJECT('ID',h.ID,'C3OfficeName',h.Name )) FROM TblC3Office h  WHERE h.ID IN (SELECT  um.TblC3Office_ID FROM TblUserC3 um WHERE um.TblUser_ID=${ID})) as C3Office FROM TblUser a LEFT JOIN TblState c ON a.TblState_ID=c.ID LEFT JOIN TblCountry b ON a.TblCountry_ID=b.ID LEFT JOIN TblDistrict d ON a.TblDistrict_ID=d.ID   WHERE a.isDeleted=1 AND a.ID=${ID}`;
		connection
			.query(sql)
			.then((result) => {
				if (result.length === 0) {
					res.json({ status: false, data: [], message: 'No data available with this ID ' });
				} else {
					var roles = JSON.parse(result[0].roles);
					var c3offices = JSON.parse(result[0].C3Office);

					var data = {
						ID: result[0].ID,
						UserName: result[0].UserName,
						Location: result[0].Location,
						Address: result[0].Address,
						PhoneNo: result[0].PhoneNo,
						TblCountry_ID: result[0].TblCountry_ID,
						TblState_ID: result[0].TblState_ID,
						TblDistrict_ID: result[0].TblDistrict_ID,
						Countryname: result[0].Countryname,
						StateName: result[0].StateName,
						DistrictName: result[0].DistrictName,

						TblRole1_ID: roles.map((dat) => {
							return dat.ID;
						}),
						TblC3Office_ID: c3offices.map((dta) => {
							return dta.ID;
						}),
						roles,
						c3offices
					};
					res.json({ status: true, data: data, message: '' });
				}
			})
			.catch((err) => {
				console.log(err);
				res.json({
					status: false,
					data: [],
					message: 'Internal Server Error or No Data Available  with this ID '
				});
			});
	};


	this.updateUser = async function (req, userID, res) {
		var dataToUpdate = [
			req.body.FirstName,
			req.body.LastName,
			req.body.UserName,
			req.body.Address,
			req.body.PhoneNo,
			req.body.TblCountry_ID,
			req.body.TblState_ID,
			req.body.TblDistrict_ID,
			req.body.modified_by,
			userID
		];
		var roles = req.body.TblRole1_ID;
		var c3 = req.body.TblC3Office_ID;
		var sql =
			'UPDATE TblUser SET FirstName=?, LastName=? ,UserName=?,Address=?,PhoneNo=?,TblCountry_ID=?,TblState_ID=?,TblDistrict_ID=?,modified_by=? WHERE ID=?';
		try {
			connection
				.query(sql, dataToUpdate)
				.then((result) => {
					if (result.affectedRows > 0) {
						connection
							.query('DELETE FROM TblUserRoles WHERE TblUser_ID=?', userID)
							.then((result1) => {
								console.log(result1.affectedRows);
								if (result1.affectedRows > 0) {
									var rolesData = roles.map((ele) => [userID, ele]);
									connection.query('INSERT INTO TblUserRoles (TblUser_ID,TblRole_ID) VALUES ?  ', [
										rolesData
									]);
								}
							})
							.catch((err) => {
								res.json({ status: false, data: [], message: 'ohh nooo' });
							})
							.then(
								connection
									.query('DELETE FROM TblUserC3 WHERE TblUser_ID=?', userID)
									.then((result3) => {
										if (result3.affectedRows > 0) {
											var c3Offices = c3.map((ele) => [userID, ele]);
											connection.query(
												'INSERT INTO TblUserC3 (TblUser_ID,TblC3Office_ID) VALUES ?  ',
												[c3Offices]
											);
											res.json({ status: true, data: [], message: 'success' });
										}
									})
									.catch((err) => {
										res.json({ status: false, data: [], message: 'error in Updating userC3' });
									})
							)
							.catch((err) => {
								res.json({ status: false, data: [], message: 'Internal Server Error' });
							});
					}
				})
				.catch((err) => {
					res.json({ status: false, data: [], message: 'Internal Server Error' });
				});
		} catch (error) {
			res.json({ status: false, data: [], message: '' });
		}
	};






	this.createUser = async function (req, res) {
		bcrypt.hash(req.body.Password, 6, async function (err, hashedPassword) {
			bcrypt.hash(req.body.AadharNo, 6, async function (err, hashedAadhaar) {
				var post = {
					FirstName: req.body.FirstName,
					LastName: req.body.LastName,
					UserName: req.body.UserName,
					Password: hashedPassword,
					AadharNo: hashedAadhaar,
					Address: req.body.Address,
					PhoneNo: req.body.PhoneNo,
					Email: req.body.Email,
					TblCountry_ID: req.body.TblCountry_ID,
					TblState_ID: req.body.TblState_ID,
					TblDistrict_ID: req.body.TblDistrict_ID,
					created_by: req.body.created_by,
				};
				var roles = req.body.TblRole1_ID;
				var c3 = req.body.TblC3Office_ID;
				var sql = 'INSERT INTO TblUser SET ?';
				try {
					connection.query(sql, post).then(result => {
						var lastInsertId = result.insertId;
						var rolesData = roles.map((ele) => [lastInsertId, ele]);
						try {
							connection.query('INSERT INTO TblUserRoles (TblUser_ID,TblRole_ID) VALUES ?  ', [rolesData])
								.then(result => {
									if (result)
										var c3Offices = c3.map((ele) => [lastInsertId, ele]);
									connection.query('INSERT INTO TblUserC3 (TblUser_ID,TblC3Office_ID) VALUES ?  ', [c3Offices]).then((result) => {
										if (result)
											res.status(HttpStatus.CREATED).json({ data: "Successfully Posted", userId: lastInsertId })
									});
								})
								.catch((error) => {
									res.status(HttpStatus.getStatusCode('Server Error')).json({
										message: error.message,
										status: HttpStatus.getStatusCode('Server Error')

									})
								});
						}
						catch (error) {
							res.status(HttpStatus.getStatusCode('Server Error')).json({
								message: error.message,
								status: HttpStatus.getStatusCode('Server Error')

							})
						}
					})
				}
				catch (error) {
					res.status(HttpStatus.getStatusCode('Server Error')).json({
						message: error.message,
						status: HttpStatus.getStatusCode('Server Error')

					})
				};
			});
		})

	};

	/* checking password after matching one of the email */
	this.loginUser = async function (req, res) {
		try {
			var sql = 'SELECT ID,Email,Password,Location  FROM TblUser WHERE isDeleted=1 AND Email=?';
			await connection.query(sql, req.body.Email.trim(), function (err, result) {
				if (err) {
					res.status(HttpStatus.getStatusCode('Server Error')).json({
						status: HttpStatus.getStatusCode('Server Error'),
					})
				}
				else if (!result || result.length === 0) {
					res.json({ status: false, data: [], message: 'Invalid Email' });
				}
				else {
					var userID = result[0].ID;
					bcrypt.compare(req.body.Password.trim(), result[0].Password, function (err, compared) {
						if (err) throw err;
						if (compared === false) {
							res.json({ status: false, data: [], message: 'Invalid Password' });
						} else {
							jwt.sign({ Email: req.body.Email }, secretKey, { expiresIn: '1h' }, function (err, token) {
								if (err) throw err;
								var sql1 = `SELECT a.ID,a.Email,a.Password,a.UserName,a.Location,JSON_ARRAYAGG(JSON_OBJECT('ID',b.ID, 'Role',b.RoleName,
								'ActivityMaster', (SELECT JSON_ARRAYAGG(JSON_OBJECT('ID',uram.ID,'ActiyMasterName',uram.ActyMasterName, 'Activities',
								(SELECT JSON_ARRAYAGG(JSON_OBJECT('ID',ua.ID,'ActiyName',ua.ActyName,'operations',
								(CASE WHEN op.Name != "null" THEN op.Name ELSE '' END))) FROM TblActivity ua 
								LEFT JOIN TblRoleActivity ra ON ra.TblActivity_ID = ua.ID 
								LEFT JOIN TblCRUD op ON op.ID =ra.operations
								WHERE ua.ID IN (SELECT distinct a.ID FROM TblActivity a  LEFT JOIN TblRoleActivity ra ON ra.TblActivity_ID = a.ID
								LEFT JOIN TblUserRoles ur ON ur.TblRole_ID = ra.TblRole_ID 
								LEFT JOIN TblUser u ON u.ID = ur.TblUser_ID  WHERE u.ID = ${userID} and ur.TblRole_ID =b.ID and a.TblActivityMaster_ID =uram.ID
								) and ra.TblRole_ID IN (SELECT distinct b.ID FROM TblRole as b1 WHERE b1.ID = b.ID)))) FROM TblActivityMaster uram WHERE uram.ID IN (SELECT distinct ma.ID FROM TblActivityMaster ma LEFT JOIN TblActivity a ON ma.ID = a.TblActivityMaster_ID LEFT JOIN TblRoleActivity ra ON ra.TblActivity_ID = a.ID LEFT JOIN TblRole r ON r.ID = ra.TblRole_ID
								LEFT JOIN TblUserRoles ur ON ur.TblRole_ID = r.ID LEFT JOIN TblUser u ON u.ID = ur.TblUser_ID WHERE u.ID = ${userID} and ur.TblRole_ID =b.ID
								)) )) as roles FROM TblUser a  
								LEFT JOIN TblUserRoles f ON a.ID=f.TblUser_ID 
								LEFT JOIN TblRole b ON f.TblRole_ID=b.ID WHERE a.ID=${userID}`;
								//	var sql1 = `SELECT ID,Email,UserName from TblUser where ID=${userID}`;

								connection
									.query(sql1)
									.then((data) => {
										var data2 = {
											ID: data[0].ID,
											Email: data[0].Email,
											UserName: data[0].UserName,
											Location: data[0].Location,
											roles: JSON.parse(data[0].roles),
											token: token
										};
										if (!data) {
											res.json({ status: false, data: [], message: '' });
										} else {
											res.json({
												status: true,
												data: data2,
												message: 'Success'
											});
										}
									})
									.catch((err) => {
										console.log(err);
										res.json({ status: false, data: [], message: 'query error' });
									});
							});
						}
					});
				}
			});
		} catch (error) {
			res.status(HttpStatus.getStatusCode('Server Error')).json({
				message: error.message,
				status: HttpStatus.getStatusCode('Server Error')

			})
		};
	};

	this.delloite = function (userID, res) {
		connection
			.query('UPDATE TblUser SET isDeleted=0 WHERE ID=?', userID)
			.then((data) => {
				res.json({ status: true, data: [], message: 'Success' });
			})
			.catch((err) => {
				res.json({ status: false, data: [], message: 'Internal server Error' });
			});
	};

	this.checkMobileUser = function (number) {
		return new Promise((resolve, reject) => {
			connection
				.query('SELECT count(*) totalCount from TblUser WHERE PhoneNo like ?', number)
				.then((data) => {
					data[0].totalCount > 0 ? resolve(true) : resolve(false);
				})
				.catch((err) => {
					reject(false);
				});
		});
	};

	this.updatePassword = function (ID, req, res) {
		bcrypt
			.hash(req.body.Password, 6)
			.then((hashedPassowrd) => {
				connection
					.query(`UPDATE  TblUser SET Password='${hashedPassowrd}' WHERE ID=${ID}`)
					.then((result) => {
						res.json({ status: true, data: [], message: 'Success' });
					})
					.catch((err) => {
						console.log(err);
						res.json({ status: false, data: [], message: 'Error In Updating Password' });
					});
			})
			.catch((err) => {
				res.json({ status: false, data: [], message: 'Internal Server Error' });
			});
	};
	this.forgotPassword = function (number, res) {
		number = parseInt(number);
		this.checkMobileUser(number)
			.then((isExists) => {
				if (isExists) {
					const random = Math.floor(Math.random() * (999999 - 100000) + 100000);
					connection
						.query('SELECT ID,UserName FROM TblUser WHERE isDeleted=1 AND PhoneNo=?', number)
						.then((result) => {
							Otp.mobileMessage(
								number,
								`Welcome to AgriXRP. Enter the given OTP to verify your phonenumber ${random}`
							).then((isSuccess) => {
								var success = JSON.parse(isSuccess);
								if (success.status === 'success') {
									res.json({
										status: true,
										data: [
											{
												ID: result[0].ID,
												UserName: result[0].UserName,
												otp: random
											}
										],
										message: 'Otp Sent SuccessFully'
									});
								} else {
									res.json({ status: false, data: [], message: ' Sending Otp Failed' });
								}
							});
						})
						.catch((err) => {
							res.json({ status: false, data: [], message: 'Sending Otp Failed' });
						});
				} else {
					res.json({ status: false, data: [], message: 'Mobile Number Not Registered' });
				}
			})
			.catch((err) => res.json({ status: false, data: [], message: 'Internal Server Error' }));
	};
}

module.exports = new UsersDAO();
