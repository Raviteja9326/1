const connection = require('../MySQLConnect');

function ReceivingData() {
	this.post = function (tableName, data) {
		return new Promise((resolve, reject) => {
			connection.query(`INSERT INTO ${tableName} SET ?`, data, (err, result) => {
				if (err) reject(err);
				resolve(result);
			});
		});
	};

	this.get = (tableName) => {
		return new Promise((resolve, reject) => {
			connection.query(`SELECT * FROM  ${tableName} WHERE isDeleted=1`, (err, result) => {
				if (err) reject(err);
				resolve(result);
			});
		});
	};

	this.getByID = (tableName, ID) => {
		return new Promise((resolve, reject) => {
			connection.query(`SELECT * FROM ${tableName} WHERE isDeleted=1 AND ID=?`, ID, (err, result) => {
				if (err) reject(err);
				resolve(result);
			});
		});
	};
}



module.exports = new ReceivingData();
