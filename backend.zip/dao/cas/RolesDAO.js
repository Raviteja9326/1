const connection = require('../MySQLConnect');

function RoleDAO() {
	this.getAllRoles = function (req, res) {
		try {
			var sql = 'SELECT ID,RoleName FROM TblRole WHERE isDeleted=1';
			connection.query(sql, (err, result) => {
				if (err) throw err;
				res.json({ status: true, data: result });
			});
		} catch (error) {
			res.json({ status: false, data: [], message: 'Internal Server Error' });
		}
	};

	this.checkRole = function (Role) {
		return new Promise(function (resolve, reject) {
			connection.query(
				'SELECT count(*) totalCount FROM TblRole WHERE isDeleted=1 AND upper(RoleName) like ?',
				Role.toUpperCase(),
				function (err, result) {
					if (err) {
						return resolve(false);
					}
					return result[0].totalCount === 0 ? resolve(true) : resolve(false);
				}
			);
		});
	};

	this.updateRole = async function (req, ID, res) {
		var dataToUpdate = [req.body.RoleName, ID];

		const data = await this.checkRole(req.body.RoleName);
		if (data === true) {
			connection
				.query('UPDATE TblRole SET RoleName=? WHERE ID=?', dataToUpdate)
				.then((data) => {
					res.json({ status: true, data: [], message: 'Success' });
				})
				.catch((err) => {
					console.log(err);
					res.json({ status: false, data: [], message: 'Internal server error' });
				});
		} else {
			res.json({ status: false, data: [], message: 'Already Exists' });
		}
	};

	this.createRole = async function (req, res) {
		var dataToPost = {
			RoleName: req.body.RoleName
		};
		const data = await this.checkRole(req.body.RoleName);
		if (data === true) {
			connection
				.query('INSERT INTO TblRole SET ?', dataToPost)
				.then((data) => {
					res.json({ status: true, data: [], message: 'Success' });
				})
				.catch((err) => {
					res.json({ status: false, data: [], message: 'Internal server error' });
				});
		} else {
			res.json({ status: false, data: [], message: 'Already Exists' });
		}
	};

	this.getAllActivities = function (req, res) {
		try {
			var sql = 'SELECT ID,ActyMasterName FROM TblActivityMaster';
			connection.query(sql, function (err, result) {
				if (err) throw err;
				res.json({ status: true, data: result, message: 'Success' });
			});
		} catch (error) {
			res.json({ status: false, data: [], message: 'Internal server error' });
		}
	};

	this.getAllActivitiesByMasterID = function (req, res) {
		try {
			var activity = req.body.TblActivityMaster_ID;

			var sql = `SELECT ID,ActyName,"false" as isSelected,0 as operations from TblActivity WHERE TblActivityMaster_ID IN(${activity}) `;
			connection.query(sql, function (err, result) {
				if (err) throw err;

				console.log(result);
				res.json(result);
			});
		} catch (error) {
			res.json({ status: false, data: [], message: 'Internal server error' });
		}
	};

	this.getAllActivitiesByRoleID = function (roleID, res) {
		var ID = roleID;
		var sql = `SELECT  DISTINCT d.RoleName, (SELECT DISTINCT JSON_ARRAYAGG(JSON_OBJECT('ID',a.ID,'ActyName',a.ActyName,'operations',op.ID, 'isSelected', (CASE WHEN (a.ID = ra.TblActivity_ID AND ra.TblRole_ID=${ID}) THEN "true" ELSE "false" END)))FROM TblActivity a LEFT JOIN TblActivityMaster b ON b.ID=a.TblActivityMaster_ID 
		 LEFT JOIN TblRoleActivity ra ON ra.TblActivity_ID = a.ID and ra.TblRole_ID=${ID}
		 LEFT JOIN TblCRUD op ON op.ID =ra.operations
		 		 WHERE b.ID IN(SELECT DISTINCT b.ID FROM TblRoleActivity c LEFT JOIN  TblActivity a ON c.TblActivity_ID=a.ID LEFT JOIN TblActivityMaster b ON a.TblActivityMaster_ID=b.ID WHERE c.TblRole_ID=${ID}))as Activities, (SELECT JSON_ARRAYAGG(JSON_OBJECT('ID',b.ID,'ActyMasterName',b.ActyMasterName))FROM TblActivityMaster b WHERE b.ID IN(SELECT am.TblActivityMaster_ID FROM TblActivity am WHERE am.ID IN(SELECT ra.TblActivity_ID FROM TblRoleActivity ra WHERE ra.TblRole_ID=${ID})))as 	ActivityMaster FROM TblRoleActivity ra   LEFT JOIN TblRole d   ON ra.TblRole_ID=d.ID  WHERE ra.TblRole_ID=${ID}`;
		connection
			.query(sql, ID)
			.then((data) => {
				var dataToSend = {
					RoleID: JSON.parse(ID),
					RoleName: data[0].RoleName,
					Activities: JSON.parse(data[0].Activities),
					ActivityMaster: JSON.parse(data[0].ActivityMaster)
				};
				res.json({ status: true, data: dataToSend, message: '' });
			})
			.catch((err) => {
				console.log(err);
				res.json({ status: false, data: [], message: 'Internal server error' });
			});
	};

	this.updateRoleActivites = function (req, roleID, res) {
		var activities = req.body.TblActivities;
		connection
			.query('DELETE FROM TblRoleActivity WHERE TblRole_ID=?', roleID)
			.then((data) => {
				if (data.affectedRows > 0) {
					// activities.forEach((element) => {
					// 	var dataToPost = {
					// 		TblRole_ID: roleID,
					// 		TblActivity_ID: element.TblActivity_ID,
					// 		operations: element.operations
					// 	};
					// 	var sql = 'INSERT INTO TblRoleActivity SET ?';
					// 	connection.query(sql, dataToPost, function(err, result) {
					// 		if (err) throw err;
					// 	});
					// });

					// res.json({ status: true, data: [], message: 'Success' });

					this.createRoleActivites(req, res);
				}
			})
			.catch((err) => {
				res.json({ status: false, data: [], message: 'Internal Server error' });
			});
	};

	this.createRoleActivites = function (req, res) {
		roleID = req.body.TblRole_ID;
		try {
			const data = req.body.TblActivities.map((item) => [item.TblActivity_ID, roleID, item.operations]);
			console.log('this is dataa after', data)
			connection
				.query('INSERT INTO TblRoleActivity (TblActivity_ID,TblRole_ID,operations) VALUES ?  ', [data])
				.then((result) => {
					res.json({ status: true, data: [], message: 'Success' });
				})
		} catch (error) {
			res.json({ status: false, data: [], message: 'Internal server error' });
		}
	};

	this.deleteRole = function (roleID, res) {
		var isActive = false;
		connection
			.query(
				'SELECT  count(*)  totalCount FROM TblUserRoles b LEFT JOIN TblUser a ON a.ID=b.TblUser_ID WHERE a.isDeleted=1 AND b.TblRole_ID=?',
				roleID
			)
			.then((data) => {
				console.log(data[0].totalCount);
				if (data[0].totalCount > 0) {
					res.json({ status: false, data: [], message: "This Role Is In Use Can't Delete" });
				} else {
					connection
						.query('UPDATE TblRole SET isDeleted=0 WHERE ID=?', roleID)
						.then((data) => {
							res.json({ status: true, data: [], message: 'Success' });
						})
						.catch(() => {
							res.json({ status: false, data: [], messapge: 'Internal Server Error' });
						});
				}
			})
			.catch((err) => {
				res.json({ status: false, data: [], message: 'Internal server error' });
			});
	};

	this.getOpeations = function (req, res) {
		try {
			var sql = 'SELECT * FROM TblCRUD';
			connection.query(sql, function (error, result) {
				if (error) throw error;
				res.json({ status: true, data: result, message: 'Success' });
			});
		} catch (error) {
			res.json({ status: false, data: [], message: 'Internal server error' });
		}
	};
}

module.exports = new RoleDAO();
